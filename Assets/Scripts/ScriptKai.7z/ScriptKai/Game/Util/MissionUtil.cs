using System.Collections;
using System.Collections.Generic; using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Takasho.Schema.Score.ResourceCn.Character.V1;
using Takasho.Schema.Score.ResourceCn.Equipment.V1;
using System.Linq;
using Takasho.Schema.Score.ResourceCn.Mission.V1;

public class MissionUtil
{
    public static MissionViewModel BuildViewModel(PlayerMission data)
    {
        var model = new MissionViewModel();
        model.master = DataManager.Instance.Master.Mission[data.MissionMasterId];
        model.receiveRewardsAt = data.ReceiveRewardsAt;
        model.canReceive = data.CanReceive;
        return model;
    }

    public static async UniTask OpenPageOfMissionTarget(CnMissionMaster master)
    {
        var type = DataManager.Instance.Master.MissionType[master.missionTypeId];
        if (type == null)
        {
            return;
        }
        
        // switch ((CnMissionTypeMaster.MissionType)type.id)
        // {
        //     // 乐装
        // case CnMissionTypeMaster.MissionType.MISSION_TYPE_20007: 
        // case CnMissionTypeMaster.MissionType.MISSION_TYPE_20008: 
        // case CnMissionTypeMaster.MissionType.MISSION_TYPE_20009: 
        // case CnMissionTypeMaster.MissionType.MISSION_TYPE_20010:
        //     await UI.Page.OpenPage<UIHomeEquipmentListPage>();
        //     break;
        // // 章节
        // case CnMissionTypeMaster.MissionType.MISSION_TYPE_10001:
        // case CnMissionTypeMaster.MissionType.MISSION_TYPE_10002:
        //     {
        //         UIHomeScenarioSelectPage.PageParam p = new UIHomeScenarioSelectPage.PageParam();
        //         var chapter = DataManager.Instance.Master.Chapter[(int)master.missionTypeValue1];
        //         p.showType = UIHomeScenarioSelectPage.PageParam.ShowType.Section;
        //         p.selectChapter = chapter.chapter;
        //         await UI.Page.ChangePage<UIHomeScenarioSelectPage>(p);
        //         break;
        //     }
        // }
    }

    public static bool IsMissionCompelte(long missionId)
    {
        var mission = DataManager.Instance.Player.Mission.TryGet(missionId);
        return mission!=null && mission.CanReceive;
    }

    public static bool IsMissionNewReceive()
    {
        var mission = DataManager.Instance.Player.Mission.TryGet(600010);
        return mission!=null && mission.ReceiveRewardsAt>0;
    }
}

public class MissionViewModel
{
    public bool canReceive;
    public CnMissionMaster master;
    public long receiveRewardsAt;
}