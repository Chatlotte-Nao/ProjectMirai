﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Explore.V1;
using UnityEngine;

public static class ShopUtil 
{

    public static long GetRemainingTime(DateTime times,out int timeType)
    {
        var expTime = GlobalTime.GetDateTime(times);
        var remain = expTime - GlobalTime.Now.DateTime;
        if (remain.TotalDays > 1)
        {
            timeType = 1;
            return (long)remain.TotalDays;
        }else if (remain.TotalHours > 1)
        {
            timeType = 2;
            return (long)remain.TotalHours;
        }
        else
        {
            timeType = 3;
            return 1;
        }
    }

    public static bool IsConstrain(int constrainType,int constrianValue,out string str)
    {
        str = "";
        switch ((ShopProductMaster.ConstrainType)constrainType)
        {
            case ShopProductMaster.ConstrainType.Level:
                str = string.Format( LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SHOP, "Shop_ConstrainType_Level"),constrianValue);
                return DataManager.Instance.Player.Player.GetLevel() < constrianValue;
            case ShopProductMaster.ConstrainType.Scenario:
                var chapter = DataManager.Instance.Master.Chapter[constrianValue];
                var section = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{constrianValue}_name");
                str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SHOP, "Shop_ConstrainType_Scenario"), chapter.chapter,section);
                return  DataManager.Instance.Player.Chapter.TryGet(constrianValue) == null;
            case ShopProductMaster.ConstrainType.MemoryQuest:
                var memoryQuest = DataManager.Instance.Master.MemoryQuest[constrianValue];
                var questName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, $"{memoryQuest.id}_name"); 
                str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SHOP, "Shop_ConstrainType_MemoryQuest"), new object[] { memoryQuest.chapter , questName});
                return  DataManager.Instance.Player.MemoryQuest.TryGet(constrianValue) == null;
            case ShopProductMaster.ConstrainType.Explore:
                var explore = DataManager.Instance.Player.Explore.GetData().Events.FirstOrDefault(a=>a.ExploreEventMasterId == constrianValue);
                var name = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.REQUEST, $"{constrianValue}_title");
                str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SHOP, "Shop_ConstrainType_Explore"), new object[] { name});
                return explore == null || explore.TotalFinishedCount == 0;
            case ShopProductMaster.ConstrainType.Character:
                var characterName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER_NAME, constrianValue.ToString());
                str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SHOP, "Shop_ConstrainType_Character"), new object[] { characterName});
                return DataManager.Instance.Player.Character.TryGet(constrianValue) == null;
        }
        return false;
    }

    public static long HaveItemCount(long itemId)
    {
        var itemType = DataManager.Instance.Master.Content[itemId].contentTypeMasterId;
        long value = 0 ;
        switch (itemType)
        {
            case 106:
                value = DataManager.Instance.Player.Wallet.GetCount("GAME_MONEY");
                break;
            case 107:
                value = DataManager.Instance.Player.Wallet.GetCount("FREE_STONE");
                break;
            case 108:
                value = DataManager.Instance.Player.Wallet.GetCount("PAID_STONE");
                break;
            case 110:
                DataManager.Instance.Player.Player.GetCurrentStaimina();
                break;
            default:
                value = DataManager.Instance.Player.Item.GetCount(itemId);
                break;
        }
        
        return value;
    }

    public static List<long> ConsuneItemIds(int categoryId)
    {
        var shopProductMasters =  DataManager.Instance.Master.ShopProductMaster.Values.Where(a=>a.shopCategoryMasterId == categoryId && a.IsOpen).OrderByDescending(a=>a.sortId).ToArray();
        return shopProductMasters.Select(a => a.costId).Distinct().ToList();
    }
    
    public static bool isAccordFormer(ShopProductMaster master)
    {
        bool isAccord = true;
        var count = DataManager.Instance.Player.Shop.GetPurchaseCount(master.id);
        if (master.isFormerProduct)
        {
            isAccord = count < master.purchaseLimit;
        }
        if (master.formerProductId > 0)
        {
            var formerMaster =  DataManager.Instance.Master.ShopProductMaster[master.formerProductId];
            var formerCount =  DataManager.Instance.Player.Shop.GetPurchaseCount(master.formerProductId);
            isAccord = isAccord && formerCount >= formerMaster.purchaseLimit;
        }
        return isAccord;
    }
}
