using System;
using System.Collections;
using System.Collections.Generic;
using Cinemachine;
using UnityEngine;

public class HideObjectManager : MonoBehaviour
{
    public List<string> m_HideList = new List<string>();

    private List<string> m_CloneHideList = new List<string>();

    private Coroutine m_HideCoroutine;
    private List<GameObject> m_HideObjectList = new List<GameObject>();

    private CinemachineVirtualCamera vc;

    private void Awake()
    {
        GetObjects();
        vc = GetComponent<CinemachineVirtualCamera>();
        if (vc != null)
        {
            vc.m_Transitions.m_OnCameraLive.AddListener(OnVCLive);
        }
    }

    private void Update()
    {
        if (enabled)
        {
            HideObjects();
        }
    }

    private void OnDisable()
    {
        if (m_HideCoroutine != null)
        {
            StopCoroutine(m_HideCoroutine);
        }
        ShowObjects();
    }

    //virtualcamera的solo事件
    private void OnVCLive(ICinemachineCamera c1, ICinemachineCamera c2)
    {
        GetObjects();
    }

    //获取所有物体的协程
    private IEnumerator GetAllObjects()
    {
        m_CloneHideList.Clear();
        m_HideObjectList.Clear();
        m_HideList.ForEach(i=>m_CloneHideList.Add(i));

        while (m_CloneHideList.Count > 0)
        {
            for (int i = m_CloneHideList.Count - 1; i >= 0; i--)
            {
                var hideGO = GameObject.Find(m_CloneHideList[i]);
                if (hideGO != null)
                {
                    m_HideObjectList.Add(hideGO);
                    m_CloneHideList.RemoveAt(i);
                }
            }

            yield return new WaitForEndOfFrame();
        }
    }

    //获取所有物体
    private void GetObjects()
    {
        if (m_HideCoroutine != null)
        {
            StopCoroutine(m_HideCoroutine);
        }
        m_HideCoroutine = StartCoroutine(GetAllObjects());
    }

    //隐藏物体
    private void HideObjects()
    {
        bool isAllExist = true;
        if (m_HideObjectList.Count > 0)
        {
            for (int i = 0; i < m_HideObjectList.Count; i++)
            {
                if (m_HideObjectList[i] != null)
                {
                    m_HideObjectList[i].SetActive(false);
                }else if (m_CloneHideList.Count <= 0)
                {
                    isAllExist = false;
                }
            }
        }
        else
        {
            isAllExist = false;
        }

        if (!isAllExist)
        {
            GetObjects();
        }
    }

    //显示物体
    private void ShowObjects()
    {
        if (m_HideObjectList.Count > 0)
        {
            for (int i = 0; i < m_HideObjectList.Count; i++)
            {
                if (m_HideObjectList[i] != null)
                {
                    m_HideObjectList[i].SetActive(true);
                }
            }
        }
    }
}
