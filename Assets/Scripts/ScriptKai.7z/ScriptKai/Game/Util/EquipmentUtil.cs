﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Takasho.Schema.Score.ResourceCn.Equipment.V1;
using UnityEngine;

public static class EquipmentUtil
{
    private static Dictionary<long, EquipmentMaster> cache_equipments_dictionary = new Dictionary<long, EquipmentMaster>();

    public static EquipmentViewModel BuildEquipmentViewModel(PlayerEquipment equipment)
    {
        EquipmentViewModel model = new EquipmentViewModel();
        var equipMaster = DataManager.Instance.Master.Equipment[equipment.EquipmentMasterId];

        model.id = equipment.EquipmentMasterId;
        model.uniqueId = equipment.PlayerEquipmentId;
        model.sortId = equipMaster.sortId;
        model.rank = (int)equipment.Rank;//star
        model.grade = (int)equipment.Grade;
        model.locked = equipment.IsLock;
        model.equippedCharacter = equipment.BattleCharacterMasterId;
        model.updateTime = equipment.UpdatedAt;

        //get skillID
        EquipmentRankUpMaster rankUpStaticDataConfig = GetRankUpStaticConfig(model.id, model.rank);
        if(rankUpStaticDataConfig!=null)
            model.skillId = rankUpStaticDataConfig.skillId;

        // level and exp
        model.totalExp = equipment.Exp;
        model.baseSupplyExp = equipMaster.expSupply;
        EquipmentGradeUpMaster gradeUpMaster = GetGradeUpStaticConfig(model.id, model.grade);
        int playerLevel = DataManager.Instance.Player.Player.GetLevel();
        //model.maxLevel = Mathf.Min(playerLevel + DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.EquipmentLevelLimitCap].data, gradeUpMaster.levelCap);
        model.maxLevel = gradeUpMaster.levelCap;

        long[] levelCalRes = CalculateLevelByExp(model, equipment.Exp);
        model.level = (int)levelCalRes[0];
        model.levelUpExp = levelCalRes[1];
        model.curExp = levelCalRes[2];
        model.isMaxLevel = model.level >= model.maxLevel;

        model.rarity = GetStaticConfig(model.id).rarity;
        //calculate attribute
        _calculateAttribute(model);

        model.isSkillAvaliable = false;
        if (model.equippedCharacter != 0)
        {
            foreach (long activeCharID in equipMaster.skillAvailableCharacter)
            {
                if (activeCharID == model.equippedCharacter)
                {
                    model.isSkillAvaliable = true;
                    break;
                }
            }
        }

        //check is both max level and max grade
        if (model.isMaxLevel)
        {
            long keyInGradeUpTable = EquipmentUtil.FindKeyInGradeUpTable(model.id, model.grade + 1);
            model.isMaxLevelAndGrade = keyInGradeUpTable == 0;
        }

        return model;
    }

    private static long _getLevelUpExp(int level, int rarity)
    {
        var curLevelMaster = DataManager.Instance.Master.EquipmentLevelUpMaster[level + 1];
        long res = 0;

        switch (rarity)
        {
            case 1:
                res = curLevelMaster.expN;
                break;
            case 2:
                res = curLevelMaster.expR;
                break;
            case 3:
                res = curLevelMaster.expSR;
                break;
            case 4:
                res = curLevelMaster.expSSR;
                break;
            default:
                res = curLevelMaster.expN;
                break;
        }
        return res;
    }

    public static void SortEquipments(EquipmentSortType sortType, EquipmentSortOrder sortOrder, ref List<EquipmentViewModel> equipments, out List<EquipmentViewModel> filteredEquipmentsStaticData)
    {
        if (cache_equipments_dictionary.Count == 0)
            cache_equipments_dictionary = DataManager.Instance.Master.Equipment;

        filteredEquipmentsStaticData = new List<EquipmentViewModel>();
        //稀有度、等级、星级。相同情况下的比较优先级：稀有度>等级>星级>界面索引排序，再相同随意排
        equipments.Sort((a, b) =>
        {
            int result = 0;
            EquipmentMaster staticDataA = cache_equipments_dictionary[a.id];
            EquipmentMaster staticDataB = cache_equipments_dictionary[b.id];

            switch (sortType)
            {
                case EquipmentSortType.Rare:
                    if (_sortHelper(staticDataA.rarity, staticDataB.rarity, sortOrder) == 0) //rare
                        if (_sortHelper(a.level, b.level, sortOrder) == 0) //level
                            if (_sortHelper(a.rank, b.rank, sortOrder) == 0) //star
                                if(_sortHelper(a.sortId, b.sortId, sortOrder) == 0)
                                    result = string.Compare(a.uniqueId, b.uniqueId);
                                else
                                    result = _sortHelper(a.sortId, b.sortId, sortOrder);
                            else
                                result = _sortHelper(a.rank, b.rank, sortOrder);
                        else
                            result = _sortHelper(a.level, b.level, sortOrder);
                    else
                        result = _sortHelper(staticDataA.rarity, staticDataB.rarity, sortOrder);
                    break;
                case EquipmentSortType.Level:
                    if (_sortHelper(a.level, b.level, sortOrder) == 0)
                        if (_sortHelper(staticDataA.rarity, staticDataB.rarity, sortOrder) == 0) //rare
                            if (_sortHelper(a.rank, b.rank, sortOrder) == 0) //star
                                if(_sortHelper(a.sortId, b.sortId, sortOrder) == 0)
                                    result = string.Compare(a.uniqueId, b.uniqueId);
                                else
                                    result = _sortHelper(a.sortId, b.sortId, sortOrder);
                            else
                                result = _sortHelper(a.rank, b.rank, sortOrder);
                        else
                            result = _sortHelper(staticDataA.rarity, staticDataB.rarity, sortOrder);
                    else
                        result = _sortHelper(a.level, b.level, sortOrder);
                    break;
                case EquipmentSortType.Rank:
                    if (_sortHelper(a.rank, b.rank, sortOrder) == 0)
                        if (_sortHelper(staticDataA.rarity, staticDataB.rarity, sortOrder) == 0) //rare
                            if (_sortHelper(a.level, b.level, sortOrder) == 0) //level
                                if(_sortHelper(a.sortId, b.sortId, sortOrder) == 0)
                                    result = string.Compare(a.uniqueId, b.uniqueId);
                                else
                                    result = _sortHelper(a.sortId, b.sortId, sortOrder);
                            else
                                result = _sortHelper(a.level, b.level, sortOrder);
                        else
                            result = _sortHelper(staticDataA.rarity, staticDataB.rarity, sortOrder);
                    else
                        result = _sortHelper(a.rank, b.rank, sortOrder);
                    break;
                default:
                    break;
            }

            return result;
        });

        for (int i = 0; i < equipments.Count; i++)
        {
            filteredEquipmentsStaticData.Add(equipments[i]);
        }
    }

    public static void FilterEquipments(ref List<EquipmentViewModel> equipmentVMs, ref List<EquipmentViewModel> exceptEquiptmentVMs, out List<EquipmentViewModel> filteredEquipmentsStaticData, EquipmentFilterType type, 
        bool isFilterLockedEquipment = false, bool isFilterEquippedEquipment = false,bool isFilterRankUpEquipment = false,bool isFilterGradeEquipment = false)
    {
        filteredEquipmentsStaticData = new List<EquipmentViewModel>();

        switch (type)
        {
            case EquipmentFilterType.ExceptLevelList:
                foreach (EquipmentViewModel e1 in equipmentVMs)
                {
                    if (isFilterLockedEquipment && e1.locked  ||isFilterEquippedEquipment && e1.equippedCharacter > 0)
                    { }
                    else
                    {
                        foreach (EquipmentViewModel e2 in exceptEquiptmentVMs)
                        {
                            if (!string.Equals(e1.uniqueId, e2.uniqueId))
                                filteredEquipmentsStaticData.Add(e1);
                        }
                    }
                }

                break;
                case EquipmentFilterType.ExcepRankList:
                    foreach (EquipmentViewModel e1 in equipmentVMs)
                    {
                        if (isFilterLockedEquipment && e1.locked  ||isFilterEquippedEquipment && e1.equippedCharacter > 0
                                                                  ||isFilterGradeEquipment && e1.grade > 1 || isFilterRankUpEquipment && e1.rank > 1)
                        { }
                        else
                        {
                            foreach (EquipmentViewModel e2 in exceptEquiptmentVMs)
                            {
                                if (!string.Equals(e1.uniqueId, e2.uniqueId))
                                    filteredEquipmentsStaticData.Add(e1);
                            }
                        }
                    }
                break;
            default:
                break;
        }
    }

    private static int _sortHelper(long a, long b, EquipmentSortOrder sortOrder)
    {
        if (a == b)
            return 0;

        if (sortOrder == EquipmentSortOrder.Decreasing)
            return a > b ? 1 : -1;
        else
            return a > b ? -1 : 1;
    }

    public static long[] CalculateLevelByExp(EquipmentViewModel equipmentVM, long addExp, bool isInit = true)
    {
        long[] result = new long[3];
        int maxLevel = DataManager.Instance.Master.EquipmentGradeUpMaster[(long)equipmentVM.grade].levelCap;
        var master = DataManager.Instance.Master.Equipment[equipmentVM.id];

        long remainExp = isInit ? addExp : equipmentVM.totalExp + addExp;
        long requireExpForCurLevel = 0;
        int lv = 1;
        while (lv < maxLevel)
        {
            requireExpForCurLevel = _getLevelUpExp(lv, master.rarity);
            if (remainExp >= requireExpForCurLevel)
            {
                lv++;
                remainExp -= requireExpForCurLevel;
            }
            else
            {
                break;
            }
        }

        result[0] = (long)lv;
        result[1] = requireExpForCurLevel;
        result[2] = remainExp > requireExpForCurLevel ? requireExpForCurLevel : remainExp;

        return result;
    }

    public static long CalculateLevelMaxExp(EquipmentViewModel equipmentVM)
    {
        long maxExp = 0;
        int maxLevel = DataManager.Instance.Master.EquipmentGradeUpMaster[(long)equipmentVM.grade].levelCap;
        var master = DataManager.Instance.Master.Equipment[equipmentVM.id];
        int lv = equipmentVM.level;
        while (lv < maxLevel)
        {
            maxExp += _getLevelUpExp(lv, master.rarity);
            lv++;
        }

        return maxExp;
    }

    public static long[] CalculateLevelByExp(EquipmentViewModel equipmentVM, List<EquipmentViewModel> selectedEquipments)
    {
        long totalExp = 0;
        foreach (EquipmentViewModel e in selectedEquipments)
        {
            totalExp += e.totalExp;
        }

        return CalculateLevelByExp(equipmentVM, totalExp);
    }

    public static long FindKeyInGradeUpTable(long equipmentMasterID, int grade)
    {
        List<EquipmentGradeUpMaster> res = DataManager.Instance.Master.EquipmentGradeUpMaster.Values.Where(x => (x.equipmentMasterId == equipmentMasterID && x.grade == grade)).ToList();

        if (res.Count() > 0)
            return res[0].id;
        else
            return 0;
    }

    public static EquipmentGradeUpMaster GetGradeUpStaticConfig(long equipmentMasterID, int grade)
    {
        List<EquipmentGradeUpMaster> res = DataManager.Instance.Master.EquipmentGradeUpMaster.Values.Where(x => (x.equipmentMasterId == equipmentMasterID && x.grade == grade)).ToList();

        if (res != null && res.Count() > 0)
            return res[0];
        else
            return null;
    }

    public static long FindKeyInRankUpTable(long equipmentMasterID, int rank)
    {
        List<EquipmentRankUpMaster> res = DataManager.Instance.Master.EquipmentRankUpMaster.Values.Where(x => (x.equipmentMasterId == equipmentMasterID && x.rank == rank)).ToList();

        if (res != null && res.Count() > 0)
            return res[0].id;
        else
            return 0;
    }

    public static EquipmentRankUpMaster GetRankUpStaticConfig(long equipmentMasterID, int rank)
    {
        List<EquipmentRankUpMaster> res = DataManager.Instance.Master.EquipmentRankUpMaster.Values.Where(x => (x.equipmentMasterId == equipmentMasterID && x.rank == rank)).ToList();

        if (res != null && res.Count() > 0)
            return res[0];
        else
            return null;
    }
    public static EquipmentMaster GetStaticConfig(long id)
    {
        var res = DataManager.Instance.Master.Equipment.Values.FirstOrDefault(x => (x.id == id ));
        return res;
    }
    public static long GetGradeUpAllExp(EquipmentViewModel model)
    {
        long allExp = 0;
        var masters = DataManager.Instance.Master.EquipmentLevelUpMaster.Values.Where(e => e.level <= model.maxLevel);
        foreach (var master in masters)
        {
            allExp += _getLevelExp(master, model.rarity);
        }
        return allExp - model.totalExp;
    }
    private static long _getLevelExp(EquipmentLevelUpMaster model, int rarity)
    {
        long res = 0;

        switch (rarity)
        {
            case 1:
                res = model.expN;
                break;
            case 2:
                res = model.expR;
                break;
            case 3:
                res = model.expSR;
                break;
            case 4:
                res = model.expSSR;
                break;
            default:
                res = model.expN;
                break;
        }
        return res;
    }
    public static EquipmentViewModel BuildFakeEquipmentViewModelByPointGrade(EquipmentViewModel currentEVM, int newGrade)
    {
        //clone
        PlayerEquipment pe = DataManager.Instance.Player.Equipment.Get(currentEVM.uniqueId);
        EquipmentViewModel newEVM = BuildEquipmentViewModel(pe);

        newEVM.grade = newGrade;

        EquipmentGradeUpMaster gradeUpMaster = GetGradeUpStaticConfig(newEVM.id, newEVM.grade);

        //recalculate level and exp
        newEVM.totalExp = pe.Exp;
        newEVM.maxLevel = gradeUpMaster.levelCap;

        long[] levelCalRes = CalculateLevelByExp(newEVM, pe.Exp);
        newEVM.level = (int)levelCalRes[0];
        newEVM.levelUpExp = levelCalRes[1];
        newEVM.curExp = levelCalRes[2];
        newEVM.isMaxLevel = newEVM.level >= newEVM.maxLevel;

        //update atrribute
        _calculateAttribute(newEVM);

        return newEVM;
    }

    public static EquipmentViewModel BuildFakeEquipmentViewModelByPointLevel(EquipmentViewModel currentEVM, int newLevel)
    {
        //clone
        PlayerEquipment pe = DataManager.Instance.Player.Equipment.Get(currentEVM.uniqueId);
        EquipmentViewModel newEVM = BuildEquipmentViewModel(pe);
        newEVM.level = newLevel;
        //update atrribute
        _calculateAttribute(newEVM);

        return newEVM;
    }
    public static EquipmentViewModel BuildFakeEquipmentViewModelByPointRank(EquipmentViewModel currentEVM, int newRank)
    {
        //clone
        PlayerEquipment pe = DataManager.Instance.Player.Equipment.Get(currentEVM.uniqueId);
        EquipmentViewModel newEVM = BuildEquipmentViewModel(pe);

        newEVM.rank = newRank;

        EquipmentGradeUpMaster gradeUpMaster = GetGradeUpStaticConfig(newEVM.id, newEVM.grade);

        //recalculate level and exp
        newEVM.totalExp = pe.Exp;
        newEVM.maxLevel = gradeUpMaster.levelCap;

        long[] levelCalRes = CalculateLevelByExp(newEVM, pe.Exp);
        newEVM.level = (int)levelCalRes[0];
        newEVM.levelUpExp = levelCalRes[1];
        newEVM.curExp = levelCalRes[2];
        newEVM.isMaxLevel = newEVM.level >= newEVM.maxLevel;

        //update atrribute
        _calculateAttribute(newEVM);

        return newEVM;
    }
    
    public static EquipmentViewModel BuildFakeEquipmentViewModel(long equipmentId)
    { 
        var equipMaster = DataManager.Instance.Master.Equipment[equipmentId];
        //clone
        PlayerEquipment pe = new PlayerEquipment();
        pe.EquipmentMasterId = equipmentId;
        pe.Rank = equipMaster.initialRank;
        pe.Grade = 1;
        pe.IsLock = true;
        pe.Exp = 0;
        var newEVM = BuildEquipmentViewModel(pe);
        return newEVM;
    }
    private static void _calculateAttribute(EquipmentViewModel evm)
    {
        // TODO : 装备属性算法： 总属性 = （装备基础属性+装备升级属性+装备升阶属性）*（1+该阶乐装升星系数），展现逻辑和奏者属性相同
        EquipmentMaster equipMaster = DataManager.Instance.Master.Equipment[evm.id];
        evm.attributeDict = new Dictionary<CharacterAttribute, int>();
        //base attribute
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            evm.attributeDict.Add(eAtt, 0);
            //evm.attributeDict[eAtt] = equipMaster.GetInitialAttribute(eAtt) + equipMaster.GetLevelGrowthAttribute(eAtt) * (evm.level-1);
            evm.attributeDict[eAtt] = equipMaster.GetInitialAttribute(eAtt) + (int)((float)(equipMaster.GetMaxAttribute(eAtt) - equipMaster.GetInitialAttribute(eAtt))/(equipMaster.maxLevel - 1) * (evm.level - 1));
        }

        //garde add-on
        for (int i = 1; i <= evm.grade; i++)
        {
            long _keyInGradeUpTable = EquipmentUtil.FindKeyInGradeUpTable(evm.id, i);
            if (_keyInGradeUpTable != 0)
            {
                EquipmentGradeUpMaster gradeUpMaster = DataManager.Instance.Master.EquipmentGradeUpMaster[_keyInGradeUpTable];
                for (int i2 = 1; i2 < (int)CharacterAttribute.Max; i2++)
                {
                    CharacterAttribute eAtt = (CharacterAttribute)i2;
                    evm.attributeDict[eAtt] += gradeUpMaster.GetGradeUpAttribute(eAtt);
                }
            }
        }

        long _keyInRankUpTable = EquipmentUtil.FindKeyInRankUpTable(evm.id, evm.rank);
        if (_keyInRankUpTable != 0)
        {
            EquipmentRankUpMaster rankUpMaster = DataManager.Instance.Master.EquipmentRankUpMaster[_keyInRankUpTable];
            for (int i2 = 1; i2 < (int)CharacterAttribute.Max; i2++)
            {
                CharacterAttribute eAtt = (CharacterAttribute)i2;
                evm.attributeDict[eAtt] = (int) ((evm.attributeDict[eAtt] + rankUpMaster.GetRankUpAttributeAddVaule(eAtt) )*( 1 + rankUpMaster.GetRankUpAttribute(eAtt) *0.0001f));
            }
        }
    }
    public static bool IsGradeUp(long modelId)
    {
        var data = DataManager.Instance.Master.EquipmentGradeUpMaster[modelId];
        foreach (var item in data.requireContents)
        {
            var s = item.Split(':');
            var itemId = long.Parse(s[0]);
            var needNum = long.Parse(s[1]);
            long cur;
            if (DataManager.Instance.Master.Content[itemId].contentTypeMasterId == 106)
            {
                cur = DataManager.Instance.Player.Wallet.GetCount(DataManager.Instance.Master.ContentToTakashoResource[itemId].takashoName);
            }
            else
            {
                cur = DataManager.Instance.Player.Item.GetCount(itemId);
            }
            if (cur < needNum)
                return false;
        }
        return true;
    }
}


public static class EquipmentAttributeExtention
{
    public static int GetInitialAttribute(this EquipmentMaster master, CharacterAttribute attribute)
    {
        switch (attribute)
        {
            case CharacterAttribute.Hp:
                return master.initialHp;
            case CharacterAttribute.PAtk:
                return master.initialAtk;
            case CharacterAttribute.PDef:
                return master.initialDef;
            case CharacterAttribute.Spd:
                return master.initialDex;
            case CharacterAttribute.MAtk:
                return master.initialInt;
            case CharacterAttribute.MDef:
                return master.initialRes;
            case CharacterAttribute.Crt:
                return master.initialCrt;
            case CharacterAttribute.CrtDmg:
                return master.initialCrd;
            case CharacterAttribute.CrtResist:
                return master.initialAcrt;
            case CharacterAttribute.CrtDmgResist:
                return master.initialCrdr;
            default:
                return 0;
        }
    }

    // public static int GetLevelGrowthAttribute(this EquipmentMaster master, CharacterAttribute attribute)
    // {
    //     switch (attribute)
    //     {
    //         case CharacterAttribute.Hp:
    //             return master.hpGrowthValue;
    //         case CharacterAttribute.PAtk:
    //             return master.atkGrowthValue;
    //         case CharacterAttribute.PDef:
    //             return master.defGrowthValue;
    //         case CharacterAttribute.Spd:
    //             return master.dexGrowthValue;
    //         case CharacterAttribute.MAtk:
    //             return master.intGrowthValue;
    //         case CharacterAttribute.MDef:
    //             return master.resGrowthValue;
    //         case CharacterAttribute.Crt:
    //             return master.crtGrowthValue;
    //         case CharacterAttribute.CrtDmg:
    //             return master.crdGrowthValue;
    //         case CharacterAttribute.CrtResist:
    //             return master.acrtGrowthValue;
    //         case CharacterAttribute.CrtDmgResist:
    //             return master.crdrGrowthValue;
    //         default:
    //             return 0;
    //     }
    // }
    public static int GetMaxAttribute(this EquipmentMaster master, CharacterAttribute attribute)
    {
        switch (attribute)
        {
            case CharacterAttribute.Hp:
                return master.maxHp;
            case CharacterAttribute.PAtk:
                return master.maxAtk;
            case CharacterAttribute.PDef:
                return master.maxDef;
            case CharacterAttribute.Spd:
                return master.maxDex;
            case CharacterAttribute.MAtk:
                return master.maxInt;
            case CharacterAttribute.MDef:
                return master.maxRes;
            case CharacterAttribute.Crt:
                return master.maxCrt;
            case CharacterAttribute.CrtDmg:
                return master.maxCrd;
            case CharacterAttribute.CrtResist:
                return master.maxAcrt;
            case CharacterAttribute.CrtDmgResist:
                return master.maxCrdr;
            default:
                return 0;
        }
    }
    public static int GetGradeUpAttribute(this EquipmentGradeUpMaster master, CharacterAttribute attribute)
    {
        switch (attribute)
        {
            case CharacterAttribute.Hp:
                return master.hpGradeUpValue;
            case CharacterAttribute.PAtk:
                return master.atkGradeUpValue;
            case CharacterAttribute.PDef:
                return master.defGradeUpValue;
            case CharacterAttribute.Spd:
                return master.dexGradeUpValue;
            case CharacterAttribute.MAtk:
                return master.intGradeUpValue;
            case CharacterAttribute.MDef:
                return master.resGradeUpValue;
            case CharacterAttribute.Crt:
                return master.crtGradeUpValue;
            case CharacterAttribute.CrtDmg:
                return master.crdGradeUpValue;
            case CharacterAttribute.CrtResist:
                return master.acrtGradeUpValue;
            case CharacterAttribute.CrtDmgResist:
                return master.crdrGradeUpValue;
            default:
                return 0;
        }
    }
    //升阶百分比提升
    public static int GetRankUpAttribute(this EquipmentRankUpMaster master, CharacterAttribute attribute)
    {
        switch (attribute)
        {
            case CharacterAttribute.Hp:
                return master.hpRankUpValue;
            case CharacterAttribute.PAtk:
                return master.atkRankUpValue;
            case CharacterAttribute.PDef:
                return master.defRankUpValue;
            case CharacterAttribute.Spd:
                return master.dexRankUpValue;
            case CharacterAttribute.MAtk:
                return master.intRankUpValue;
            case CharacterAttribute.MDef:
                return master.resRankUpValue;
            case CharacterAttribute.Crt:
                return master.crtRankUpValue;
            case CharacterAttribute.CrtDmg:
                return master.crdRankUpValue;
            case CharacterAttribute.CrtResist:
                return master.acrtRankUpValue;
            case CharacterAttribute.CrtDmgResist:
                return master.crdrRankUpValue;
            default:
                return 0;
        }
    }
    //升阶固定提升
    public static int GetRankUpAttributeAddVaule(this EquipmentRankUpMaster master, CharacterAttribute attribute)
    {
        switch (attribute)
        {
            case CharacterAttribute.Hp:
                return master.hpRankUpAddValue;
            case CharacterAttribute.PAtk:
                return master.atkRankUpAddValue;
            case CharacterAttribute.PDef:
                return master.defRankUpAddValue;
            case CharacterAttribute.Spd:
                return master.dexRankUpAddValue;
            case CharacterAttribute.MAtk:
                return master.intRankUpAddValue;
            case CharacterAttribute.MDef:
                return master.resRankUpAddValue;
            case CharacterAttribute.Crt:
                return master.crtRankUpAddValue;
            case CharacterAttribute.CrtDmg:
                return master.crdRankUpAddValue;
            case CharacterAttribute.CrtResist:
                return master.acrtRankUpAddValue;
            case CharacterAttribute.CrtDmgResist:
                return master.crdrRankUpAddValue;
            default:
                return 0;
        }
    }

}

public class EquipmentViewModel
{
    public long id;
    public string uniqueId;
    public int sortId;
    public int level;
    public int maxLevel;
    public int grade;
    public int rank;
    public long baseSupplyExp;
    public long totalExp;
    public long curExp;
    public long levelUpExp;
    public bool isMaxLevel;
    public bool isMaxLevelAndGrade;
    public long skillId;
    public bool locked;
    public long equippedCharacter;
    public int rarity;
    public Dictionary<CharacterAttribute, int> attributeDict = null;

    public bool isSkillAvaliable;
    public long updateTime;
}

public enum EquipmentSortType
{
    Rare = 0,
    Level = 1,
    Rank = 2,
}

public enum EquipmentFilterType
{
    ExceptLevelList,
    ExcepRankList,
}

public enum EquipmentSortOrder
{
    Increasing = 0,
    Decreasing = 1,
}

public enum EquipmentRarity
{
    N = 1,
    R = 2,
    SR = 3,
    SSR = 4,
}