﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Takasho.Schema.Score.ResourceCn.System.V1;
using UnityEngine.Rendering;

public static class CommonUtil
{
    public static async UniTask ShowReward(List<string> rewards)
    {
        Dictionary<long, int> items = new Dictionary<long, int>();
        List<long> charas = new List<long>();
        //List<long> equips = new List<long>();
        foreach (var item in rewards)
        {
            var s = item.Split(':');
            var itemId = long.Parse(s[0]);
            var itemNum = int.Parse(s[1]);
            if (DataManager.Instance.Master.Content[itemId].contentTypeMasterId == 101)
            {
                charas.Add(itemId);
            }
            // else if (DataManager.Instance.Master.Content[itemId].contentTypeMasterId == 102)
            // {
            //     equips.Add(itemId);
            // }
            else
            {
                items.Add(itemId, itemNum);
            }

        }

        if (items.Count > 0)
        {
            var popup = await UI.Popup.ShowItemGetPopupAsync(items);
            await UniTask.WaitUntil(() => (popup == null));
        }

        // if (equips.Count > 0)
        // {
        //
        // }
        if (charas.Count > 0)
        {
            var popup = await UI.Popup.ShowCharacterGetPopupAsync(charas);
            await UniTask.WaitUntil(() => (popup == null));
        }
    }

    public static Vector3 ConvertStringToVector3(string pos)
    {
        var s = pos.Split(',');
        if (s.Length >= 3)
        {
            return new Vector3(float.Parse(s[0]), float.Parse(s[1]), float.Parse(s[2]));
        }
        else if (s.Length >= 2)
        {
            return new Vector3(float.Parse(s[0]), float.Parse(s[1]), 0);
        }
        else if (s.Length >= 1)
        {
            return Vector3.zero;
        }

        return Vector3.zero;
    }


    public static async UniTask JumpToTargetPage(string targetContent)
    {
        var s = targetContent.Split(':');

        if (s.Length == 0) return;

        int pageId = int.Parse(s[0]); //0 永远是类型
        switch ((JumpFunctionType) pageId)
        {
            case JumpFunctionType.ScenarioMain:
                var scenarioMain = new UIHomeScenarioSelectPage.PageParam();
                scenarioMain.showType = UIHomeScenarioSelectPage.PageParam.ShowType.Chapter;
                await UI.Page.OpenPage<UIHomeScenarioSelectPage>(scenarioMain);
                break;
            case JumpFunctionType.ScenarioSection:
            case JumpFunctionType.ScenarioLevel: //暂无跳转到具体关卡
                var scenarioSection = new UIHomeScenarioSelectPage.PageParam();
                scenarioSection.showType = UIHomeScenarioSelectPage.PageParam.ShowType.Section;
                scenarioSection.selectChapter = int.Parse(s[1]);
                await UI.Page.OpenPage<UIHomeScenarioSelectPage>(scenarioSection);
                break;
            case JumpFunctionType.CharacterMain:
                await UI.Page.OpenPage<UIHomeCharacterMainPage>();
                break;
            case JumpFunctionType.CharacterUnit:
                await UI.Page.OpenPage<UIHomeCharacterMainPage>();
                var characterParam = new UIHomeCharacterUnitPage.PageParam();
                if (s[1] != string.Empty)
                {
                    characterParam.characterId = long.Parse(s[1]);
                }
                else
                {
                    if (DataManager.Instance.Player.Character.GetList().Count <= 0)
                        return;
                    characterParam.characterId =
                        DataManager.Instance.Player.Character.GetList()[0].BattleCharacterMasterId;
                }

                characterParam.showType = (UIHomeCharacterUnitPage.PageParam.ShowType) int.Parse(s[2]);
                await UI.Page.OpenPage<UIHomeCharacterUnitPage>(characterParam);
                break;
            case JumpFunctionType.EquipmentMain:
                await UI.Page.OpenPage<UIHomeEquipmentListPage>();
                break;
            case JumpFunctionType.EquipmentUnit:
                var equipmentList = DataManager.Instance.Player.Equipment.GetList();
                if (equipmentList.Count <= 0)
                {
                    await UI.Page.OpenPage<UIHomeEquipmentListPage>();
                    return;
                }

                EquipmentParam equipmentParam = new EquipmentParam();
                equipmentParam.type = (EquipmentMainPagePanelType) int.Parse(s[1]);
                equipmentParam.model =
                    EquipmentUtil.BuildEquipmentViewModel(DataManager.Instance.Player.Equipment.GetList()[0]);
                await UI.Page.OpenPage<UIHomeEquipmentMainPage>(equipmentParam);
                break;
            case JumpFunctionType.MemoryQuestMain:
                await MemoryQuestService.GetDataAsync();
                UIMqScenarioSelectPageParam memoryQuestChapterParam = new UIMqScenarioSelectPageParam();
                memoryQuestChapterParam.showType = UIMqScenarioSelectPageParam.ShowType.Chapter;
                await UI.Page.OpenPage<UIMqScenarioSelectPage>(memoryQuestChapterParam);
                break;
            case JumpFunctionType.MemoryQuestDifficulty:
            case JumpFunctionType.MemoryQuestLevel:
                await MemoryQuestService.GetDataAsync();
                var memoryQuestSectionParam = new UIMqScenarioSelectPageParam();
                memoryQuestSectionParam.showType = UIMqScenarioSelectPageParam.ShowType.Section;
                memoryQuestSectionParam.SelectedChapter = int.Parse(s[1]);
                memoryQuestSectionParam.mqType = int.Parse(s[2]);
                await UI.Page.OpenPage<UIMqScenarioSelectPage>(memoryQuestSectionParam);
                break;
            case JumpFunctionType.DailyQuestMain:
                if (!IsFunctionUnlock(10,true)) return;
                await DailyQuestService.GetAvailable();
                await DailyQuestService.GetToday();
                await UI.Page.OpenPage<UIHomeDailyQuestMainPage>();
                break;
            case JumpFunctionType.DailyQuestSection:
                if (!IsFunctionUnlock(10,true)) return;
                await DailyQuestService.GetAvailable();
                await DailyQuestService.GetToday();
                var dailyQuestShowChaptersParam = new DailyQuestUtil.OpenDailyQuestParam();
                dailyQuestShowChaptersParam.ID = int.Parse(s[1]);
                dailyQuestShowChaptersParam.T = DailyQuestUtil.OpenDailyQuestParam.OpenPageType.ShowChapters;
                await UI.Page.OpenPage<UIHomeDailyQuestMainPage>(dailyQuestShowChaptersParam);
                break;
            case JumpFunctionType.DailyQuestLevel:
                if (!IsFunctionUnlock(10,true)) return;
                await DailyQuestService.GetAvailable();
                await DailyQuestService.GetToday();
                var dailyQuestParam = new DailyQuestUtil.OpenDailyQuestParam();
                dailyQuestParam.ID = int.Parse(s[2]);
                dailyQuestParam.T = DailyQuestUtil.OpenDailyQuestParam.OpenPageType.ShowDetail;
                await UI.Page.OpenPage<UIHomeDailyQuestMainPage>(dailyQuestParam);
                break;
            case JumpFunctionType.Explore:
                // await ExploreService.RequestExploreData();
                // GameSceneManager.Instance.ChangeScene<ExploreScene>("ExploreScene");
                break;
            case JumpFunctionType.Gacha:
                var param = await GachaService.GetGachaList();
                await UI.Page.OpenPage<UIGachaMainPage>(param);
                break;
            case JumpFunctionType.Shop:
                //await ExploreService.RequestExploreData();
                if (!IsFunctionUnlock(15,true)) return;
                var shopTableId = s.Length > 1 ? int.Parse(s[1]) : 0;
                await UI.Page.OpenPage<UIShopPage>(shopTableId);
                break;
            case JumpFunctionType.Mossion:
                await MissionService.RequestMissionData();
                await UI.Page.OpenPage<UIMissionPage>(int.Parse(s[1]));
                break;
            case JumpFunctionType.Undeground:
                // //TODO XZF 临时注释
                // await UI.Popup.ShowPopupMessageAsync("功能正在研发中...");
                // return;
                var type = s.Length > 1 ? int.Parse(s[1]) : 1;
                await UI.Page.OpenPage<UIUndergroundPage>(type);
                break;
        }
    }

    public static bool IsFunctionUnlock(int lockId, bool showPop = false)
    {
        if (lockId == 0) return true;
        if (DataManager.Instance.Master.FunctionUnlock[lockId].requirePlayerLevel > DataManager.Instance.Player.Player.GetLevel())
        {
            if (showPop)
            {
                var msg = string.Format(
                    LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Level_Format"),
                    DataManager.Instance.Master.FunctionUnlock[lockId].requirePlayerLevel);
                UI.Popup.ShowPopMessage(msg);
            }

            return false;
        }
        var stageId = DataManager.Instance.Master.FunctionUnlock[lockId].requireStageId;
        if (stageId > 0 && !StoryUtil.IsClear(stageId))
        {
            if (showPop)
            {
                var chapterName =
                    LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{stageId}_name");
                int chapterNum = DataManager.Instance.Master.Chapter[stageId].chapter;
                var msg = string.Format(
                    LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Stage_Format"),
                    chapterNum, chapterName);
                UI.Popup.ShowPopMessage(msg);
            }
            return false;
        }

        return true;
    }

    public static void SortDictionary(List<string> content)
    {
        content.Sort((a, b) =>
        {
            var sA = a.Split(':');
            long itemAId = 0;
            string itemANum = string.Empty;
            itemAId = long.Parse(sA.Length > 1 ? sA[0] : a);
            var sB = b.Split(':');
            long itemBId = 0;
            string itemNum = string.Empty;
            itemBId = long.Parse(sB.Length > 1 ? sB[0] : b);
            var contentTypeMasterA =
                DataManager.Instance.Master.ContentTypeMaster[
                    DataManager.Instance.Master.Content[itemAId].contentTypeMasterId];
            var contentTypeMasterB =
                DataManager.Instance.Master.ContentTypeMaster[
                    DataManager.Instance.Master.Content[itemBId].contentTypeMasterId];

            if (_sortHelper(contentTypeMasterA.sortId, contentTypeMasterB.sortId) == 0)
            {
                switch (contentTypeMasterA.id)
                {
                    case 102:
                        var equipmentMasterA = DataManager.Instance.Master.Equipment[itemAId];
                        var equipmentMasterB = DataManager.Instance.Master.Equipment[itemBId];
                        if (_sortHelper(equipmentMasterA.rarity, equipmentMasterB.rarity, false) == 0)
                            return _sortHelper(equipmentMasterA.id, equipmentMasterB.id);
                        else
                            return _sortHelper(equipmentMasterA.rarity, equipmentMasterB.rarity, false);
                    default:
                        var master1 = DataManager.Instance.Master.Item.TryGetValue(itemAId, out var itemMaster1);
                        var master2 = DataManager.Instance.Master.Item.TryGetValue(itemBId, out var itemMaster2);
                        if (master1 && master2)
                        {
                            if (_sortHelper(itemMaster1.rarity, itemMaster2.rarity, false) == 0)
                                return _sortHelper(itemMaster1.sortId, itemMaster1.sortId);
                            else
                                return _sortHelper(itemMaster1.rarity, itemMaster2.rarity, false);
                        }
                        else
                            return _sortHelper(itemAId, itemBId);

                        ;
                }
            }
            else
            {
                return _sortHelper(contentTypeMasterA.sortId, contentTypeMasterB.sortId);
            }
        });
    }

    private static int _sortHelper(long a, long b, bool sortOrder = true)
    {
        if (a == b)
            return 0;
        if (sortOrder)
            return a > b ? 1 : -1;
        else
            return a > b ? -1 : 1;
    }


    public static void SetIsPoPAnnouncement()
    {
        var isPopAnnouncement = true;
        if (DataManager.Instance.Local.ConfigStorage.notAnnouncement)
        {
            var totalSeconds = DataManager.Instance.Local.ConfigStorage.loginTime;
            if (totalSeconds == 0)
            {
                isPopAnnouncement = true;
            }
            else
            {
                var nowTime = GlobalTime.Now;
                var oldTime = GlobalTime.GetDateTime(totalSeconds);
                if (nowTime.Hour > 3 && (nowTime.Day != oldTime.Day) || (oldTime.Hour < 4))
                {
                    isPopAnnouncement = true;
                }
                else
                {
                    isPopAnnouncement = false;
                }
            }
        }

        DataManager.Instance.Local.ConfigStorage.isPopAnnouncement = isPopAnnouncement;
        DataManager.Instance.Local.ConfigStorage.loginTime = GlobalTime.Now.ToUnixTimeSeconds();
        DataManager.Instance.Local.SaveConfig();

    }

    public static long GetCountDownTime(DateTime endTime, out int timeType)
    {
        timeType = 0;
        if (endTime <= GlobalTime.Now.DateTime)
            return 0;
        var remain = endTime - GlobalTime.Now.DateTime;
        if (remain.TotalDays > 1)
        {
            timeType = 1;
            return (long) remain.TotalDays;
        }

        if (remain.TotalHours > 1)
        {
            timeType = 2;
            return (long) remain.TotalHours;
        }

        if (remain.TotalMinutes > 1)
        {
            timeType = 3;
            return (long) remain.TotalMinutes;
        }

        if (remain.Seconds > 0)
        {
            timeType = 4;
            return (long) remain.Seconds;
        }
        

        return 0;

    }
}


//跳转的 功能类型
public enum JumpFunctionType
{
    ScenarioMain = 1,               //主线故事主界面
    ScenarioSection = 2,            //主线故事阶段界面 {0} 乐章id
    ScenarioLevel = 3,              //主线故事阶段界面 {0} 乐章id {1}关卡id 
    CharacterMain = 4,              //奏者主界面
    CharacterUnit = 5,              //{0}奏者{1}界面  {0}填奏者id，不填默认第一位奏者{1}填页签  0 详情 1 乐装 2乐谱 3换装
    EquipmentMain = 6,              //乐装主界面
    EquipmentUnit = 7,              //乐装{0}  {0}填页签，0详情，1升级，2升星，默认第一张乐装
    MemoryQuestMain = 8,            //战律记忆主界面
    MemoryQuestDifficulty = 9,      //战律记忆第{0}乐章{1}  {0}填乐章序号，{1}填难度，1代表normal，2代表hard
    MemoryQuestLevel = 10,          //战律记忆第{0}乐章{1}{2}  {0}填乐章序号，{1}填难度，1代表normal，2代表hard，{2}填具体关卡Id 
    DailyQuestMain = 11,            //作战任务主界面
    DailyQuestSection = 12,         //作战任务第{0}章节  {0}填章节id
    DailyQuestLevel = 13,           //{0}填章节id，{1}填阶段id 
    Explore = 14,                   //探索
    Gacha = 15,                     //扭蛋
    Shop = 16,                      //商店 {0}  {0} 代表商店页签 id
    Mossion = 17,                   //任务{0}  {0}代表任务类别 1 每日 3 成就 6新手
    Undeground = 18,                //地下城界面 {0}  1普通 2 困难
}

public static class PpsFindExtension
{
    public static T GetSetting<T>(this VolumeProfile profile) where T : VolumeComponent
	{
		foreach (var item in profile.components)
		{
			if (item is T)
			{
				return item as T;
			}
		}
		return null;
	}
}
