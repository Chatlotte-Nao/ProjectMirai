﻿using UnityEngine;

public static class MapConstants {

	// -----------------------------------------------------------------------------------------------------------------------------------
	// セクション種類名
	// -----------------------------------------------------------------------------------------------------------------------------------

	/// <summary>ストーリーパート</summary>
	public static readonly int SECTION_STORY = 1;
	/// <summary>バトルパート ※α1以前にあったすごろく状のバトルマップのこと</summary>
	public static readonly int SECTION_BATTLE = 2;
	/// <summary>インタールード</summary>
	public static readonly int SECTION_INTERLUDE = 3;
	/// <summary>ADV</summary>
	public static readonly int SECTION_ADV = 4;
	/// <summary>ダンジョン</summary>
	public static readonly int SECTION_DUNGEON = 5;
	/// <summary>ストーリーイベントのバトルマップ</summary>
	public static readonly int SECTION_STORY_EVENT_BATTLE = 6;


	/// <summary>
	/// ダンジョンマップの開始ルート名
	/// </summary>
	public static readonly string DUNGEON_START_ROUTE_NAME = "route (1)";
	/// <summary>
	/// ダンジョンマップのクリア時ルート名
	/// </summary>
	public static readonly string DUNGEON_CLEAR_ROUTE_NAME = "route (2)";
	/// <summary>
	/// ダンジョンのバトルマップ（敵が配置されている階層）名
	/// </summary>
	public static readonly string DUNGEON_BATTLE_MAP_NAME = "DungeonBattleMap";
	/// <summary>
	/// ダンジョンの区分マップ（中間地点や最終地点となる場所）名
	/// </summary>
	public static readonly string DUNGEON_SECTION_MAP_NAME = "DungeonSectionMap";

	/// <summary>
	/// 特に条件を設定しない時のランクS条件ID
	/// </summary>
	public static readonly int BASE_RANK_S_ID = 900001;

	/// <summary>
	/// チュートリアル1で使用するバトルキャラID
	/// </summary>
	public static readonly int TUTORIAL_1_BATTLE_CHARACTER_ID = 100000001;

	/// <summary>
	/// 現在動いているマップ挙動タイプ
	/// </summary>
	public enum MAP_CONDUCT_TYPE
	{
		/// <summary>(マップは動いていない) </summary>
		NONE = 0,
		/// <summary>通常マップ　どの部屋に行ったか等が保存される</summary>
		BASE,
		/// <summary>ホーム画面マップ　生産施設が動いたりする</summary>
		HOME,
		/// <summary>ダンジョンマップ</summary>
		DUNGEON,
	}
}
