using System;
using System.Collections.Generic;
using System.Linq;
//using BattleResult;
using Takasho.Schema.Score.ResourceCn.DailyQuest.V1;
using Cysharp.Threading.Tasks;
using UnityEngine;

public static class DailyQuestUtil
{
    
    public class OpenDailyQuestParam
    {
        public enum OpenPageType
        {
            ShowType,
            ShowChapters,
            ShowDetail
        }

        public OpenPageType T;
        public int ID;

    }
    

    public static DailyQuestTypeMaster FindDailyQuestTypeConfig(long type)
    {
        _ = DataManager.Instance.Master.DailyQuestsType.TryGetValue(Convert.ToInt32(type),
            out var dailyQuestTypeMaster);
        return dailyQuestTypeMaster;
    }

    public static DailyQuestTypeMaster FindDailyQuestTypeMaster(this DailyQuestMaster master)
    {
        var charaterMaster = DataManager.Instance.Master.DailyQuestsChapter[master.chapterMasterId].dailyQuestTypeMasterId;
        return DataManager.Instance.Master.DailyQuestsType[charaterMaster];
    }

    public static string GetRewardContentIconKey(long itemId, out string id)
    {
        var ok = DataManager.Instance.Master.Content.TryGetValue(itemId, out var contentMaster);
        if (!ok)
        {
            id = string.Empty;
            return  string.Empty;
        }

        switch (contentMaster.contentTypeMasterId)
        {
            case 102:
                id = itemId.ToString().Substring(5, 4);
                return "Equipment/Icons";
            default:
                id = itemId.ToString();
                return "ItemIcon";
        }
    }

    public static long GetFirstAbleChapterId(long typeId)
    {
        var chapter = DataManager.Instance.Master.DailyQuestsChapter.Values.
            Where(x => x.dailyQuestTypeMasterId == typeId).
            Where(x => DataManager.Instance.Player.DailyQuest.TodayDailyQuestChapters.Contains(x.id)).First();
        return chapter is null ? 0: chapter.id;

    }

    public static bool SectionCanActive(DailyQuestMaster section)
    {
        var playerRecord = DataManager.Instance.Player.DailyQuest.TryGet(section.id);
        var preSatisfied = false;
        if (section.preDailyQuestMasterId == 0)
        {
            preSatisfied = true;
        }
        else
        {
            preSatisfied =DataManager.Instance.Player.DailyQuest.TryGet(section.preDailyQuestMasterId) is PlayerDailyQuest;
        }

        var levelSatisfied = DataManager.Instance.Player.Player.GetLevel() >= section.requirePlayerLevel ;
        var staminaSatisfied = DataManager.Instance.Player.Player.GetCurrentStaimina() >= section.useStamina ;
        //Debug.Log($"{levelSatisfied}_{staminaSatisfied}_{preSatisfied}");
        return (playerRecord is PlayerDailyQuest) ||
               (levelSatisfied && staminaSatisfied && preSatisfied);

    }
    public static bool SectionActive(DailyQuestMaster section)
    {
        var playerRecord = DataManager.Instance.Player.DailyQuest.TryGet(section.id);
        var preSatisfied = false;
        if (section.preDailyQuestMasterId == 0)
        {
            preSatisfied = true;
        }
        else
        {
            preSatisfied =DataManager.Instance.Player.DailyQuest.TryGet(section.preDailyQuestMasterId) is PlayerDailyQuest;
        }

        var levelSatisfied = DataManager.Instance.Player.Player.GetLevel() >= section.requirePlayerLevel ;
        return (playerRecord is PlayerDailyQuest) ||
               (levelSatisfied && preSatisfied);

    }

    public static bool SectionCanClear(DailyQuestMaster section)
    {
        var playerRecord = DataManager.Instance.Player.DailyQuest.TryGet(section.id);
        return playerRecord != null;
    }

    public static bool SectionAllClear(DailyQuestTypeMaster master)
    {
        var chapters = DataManager.Instance.Master.DailyQuestsChapter.Values.Where(m => m.dailyQuestTypeMasterId == master.id);
        foreach (var chapter in chapters)
        {
            var sections = DataManager.Instance.Master.DailyQuestsSection.Values.Where(m => m.chapterMasterId == chapter.id);
            foreach (var section in sections)
            {
                if (DataManager.Instance.Player.DailyQuest.TryGet(section.id) == null)
                {
                    return false;
                }
            }
        }
        return true;
    }
    public static bool chapterAllClear(DailyQuestChapterMaster master)
    {
        var sections = DataManager.Instance.Master.DailyQuestsSection.Values.Where(m => m.chapterMasterId == master.id);
        foreach (var section in sections)
        {
            if (DataManager.Instance.Player.DailyQuest.TryGet(section.id) == null)
            {
                return false;
            }
        }
        return true;
    }

    public static bool SectionCanSkip(DailyQuestMaster section)
    {
        if (section.useStamina >= DataManager.Instance.Player.Player.GetCurrentStaimina())
        {
            return false;
        }
        var playerRecord = DataManager.Instance.Player.DailyQuest.TryGet(section.id);
        return !(playerRecord is null) && DataManager.Instance.Player.DailyQuest.SkipTimes > 0;
    }

}
