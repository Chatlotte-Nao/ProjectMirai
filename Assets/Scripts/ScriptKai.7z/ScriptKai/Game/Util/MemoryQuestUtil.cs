using System;
using System.Collections.Generic;
using System.Linq;
using Battle.Messager;
//using Common.Resource;
//using Game.Core.Io;
//using Game.Core.Net;
using Takasho.Schema.Score.ResourceCn.Chapter.V1;
using Takasho.Schema.Score.ResourceCn.MemoryQuest.V1;
using UnityEditor;
using UnityEngine;

public static class MemoryQuestUtil
{
    public static bool IsReceived(long receiveTime)
    {
        // if time is zero time, then false, otherwise true
        // we assume time before unix zero time as zero time
        return receiveTime > 0;
    }

    public static MqChapterStatusViewModel BuildMqChapterStatusViewModel(int chapter)
    {
        MqChapterStatusViewModel model = new MqChapterStatusViewModel();
        model.Chapter = chapter;
        model.IsLocked = true;
        model.MqSectionStatus = new Dictionary<int, MqMemoryQuestStatusViewModel>();

        var masters = DataManager.Instance.Master.MemoryQuest.Values.Where(x => x.chapter == chapter);
        var totalNormal = 0;
        var totalHard = 0;
        var currentNormal = 0;
        var currentHard = 0;
        foreach (var memoryQuestMaster in masters)
        {
            var memoryQuestModel = BuildMqMemoryQuestStatusViewModel(memoryQuestMaster.id);
            
            model.MqSectionStatus.Add(memoryQuestMaster.id, memoryQuestModel);

            if (memoryQuestModel.MemoryQuestType == MqMemoryQuestStatusViewModel.MqType.Normal && memoryQuestModel.soreType == MqMemoryQuestStatusViewModel.SoreType.Big)
            {
                totalNormal += memoryQuestModel.StarNumTotal;
                currentNormal += memoryQuestModel.StarNumGot;
            } else if (memoryQuestModel.MemoryQuestType == MqMemoryQuestStatusViewModel.MqType.Hard && memoryQuestModel.soreType == MqMemoryQuestStatusViewModel.SoreType.Big)
            {
                totalHard += memoryQuestModel.StarNumTotal;
                currentHard += memoryQuestModel.StarNumGot;
            }

            // 只要任何一个memoryQuest解锁，那么这一章就已经解锁
            model.IsLocked = model.IsLocked && memoryQuestModel.lockedType != MqMemoryQuestStatusViewModel.LockedType.Normal;
        }

        model.StarNumNormalTotal = totalNormal;
        model.StarNumHardTotal = totalHard;
        model.StarNumNormalGot = currentNormal;
        model.StarNumHardGot = currentHard;

        var chapterMasters = DataManager.Instance.Master.MemoryQuestChapter.Values.Where(_ => _.chapter == chapter);
        foreach (var chapterMaster in chapterMasters)
        {
            // Normal
            if (chapterMaster.memoryQuestType == 1)
            {
                model.StarRewards1Normal = chapterMaster.requireStarNum1;
                model.StarRewards2Normal = chapterMaster.requireStarNum2;
                model.StarRewards3Normal = chapterMaster.requireStarNum3;
            }
            else
            {
                model.StarRewards1Hard = chapterMaster.requireStarNum1;
                model.StarRewards2Hard = chapterMaster.requireStarNum2;
                model.StarRewards3Hard = chapterMaster.requireStarNum3;
                model.HardRequireStarNum = chapterMaster.requireStarNum;
            }
        }

        model.StarRewards1NormalCanReceive = false;
        model.StarRewards2NormalCanReceive = false;
        model.StarRewards3NormalCanReceive = false;
       if ( currentNormal >= model.StarRewards1Normal)
       {
           model.StarRewards1NormalCanReceive = true;
           if (currentNormal >= model.StarRewards2Normal)
           {
               model.StarRewards2NormalCanReceive = true;
               if (currentNormal >= model.StarRewards3Normal)
               {
                   model.StarRewards3NormalCanReceive = true;
               }
           }
       }

       model.StarRewards1HardCanReceive = false;
       model.StarRewards2HardCanReceive = false;
       model.StarRewards3HardCanReceive = false;
       if ( currentHard >= model.StarRewards1Hard)
       {
           model.StarRewards1HardCanReceive = true;
           if (currentHard >= model.StarRewards2Hard)
           {
               model.StarRewards2HardCanReceive = true;
               if (currentHard >= model.StarRewards3Hard)
               {
                   model.StarRewards3HardCanReceive = true;
               }
           }
       }

       model.StarRewards1NormalReceived = false;
       model.StarRewards2NormalReceived = false;
       model.StarRewards3NormalReceived = false;
       model.StarRewards1HardReceived = false;
       model.StarRewards2HardReceived = false;
       model.StarRewards3HardReceived = false;
       var playerChapters = DataManager.Instance.Player.MemoryQuestChapter.GetList();
       foreach (var playerChapter in playerChapters)
       {
           var correspondingChapterMaster = DataManager.Instance.Master.MemoryQuestChapter.Values.First(_ => _.id == playerChapter.MemoryQuestChapterMasterId);
           if (correspondingChapterMaster.chapter != chapter)
           {
               continue;
           }
               // normal case
           if (correspondingChapterMaster.memoryQuestType == 1)
           {
               model.StarRewards1NormalReceived = IsReceived(playerChapter.ReceivedStarRewardContents1Time);
               model.StarRewards2NormalReceived = IsReceived(playerChapter.ReceivedStarRewardContents2Time);
               model.StarRewards3NormalReceived = IsReceived(playerChapter.ReceivedStarRewardContents3Time);
           }
           // hard case
           else
           {
               model.StarRewards1HardReceived = IsReceived(playerChapter.ReceivedStarRewardContents1Time);
               model.StarRewards2HardReceived = IsReceived(playerChapter.ReceivedStarRewardContents2Time);
               model.StarRewards3HardReceived = IsReceived(playerChapter.ReceivedStarRewardContents3Time);
           }
       }

       // model.RewardViewModel = new List<MqMemoryQuestRewardViewModel>();
       // var chapterMasterss = DataManager.Instance.Master.MemoryQuestChapter.Values.Where(_ => _.chapter == chapter);
       // foreach (var chapterMaster in chapterMasterss)
       // {
       //     var playerChapterss = DataManager.Instance.Player.MemoryQuestChapter.GetList();
       //   
       //     for (int i = 0; i < 3; i++)
       //     {
       //         var reward = new MqMemoryQuestRewardViewModel();
       //         reward.MemoryQuestType = (MqMemoryQuestStatusViewModel.MqType) chapterMaster.memoryQuestType;
       //         reward.StarRewardNum = chapterMaster.GetStarRewardsNum(i);
       //         reward.RewardType = MqMemoryQuestRewardViewModel.StarRewardType.Not;
       //         if (currentNormal >= reward.StarRewardNum)
       //             reward.RewardType = MqMemoryQuestRewardViewModel.StarRewardType.CanReceivel;
       //         var playerChapter = playerChapterss.First(p => p.MemoryQuestChapterMasterId == chapterMaster.id );
       //         if (playerChapter.IsReceiveds(i))
       //         {
       //             reward.RewardType = MqMemoryQuestRewardViewModel.StarRewardType.Received;
       //         }
       //     }
       //     
       //
       //     // Normal
       //
       // }
        
       return model;
    }

    public static int GetStarRewardsNum(this MemoryQuestChapterMaster master,int index)
    {
        int num = 0;
        switch ((MemoryQuestRewardType)index)
        {
            case MemoryQuestRewardType.Reward1:
                num = master.requireStarNum1;
                break;
            case MemoryQuestRewardType.Reward2:
                num = master.requireStarNum2;
                break;
            case MemoryQuestRewardType.Reward3:
                num = master.requireStarNum3;
                break;
        }

        return num;
    }
    
    public static bool IsReceiveds(this PlayerMemoryQuestChapter chapter,int index)
    {
        long receiveTime = 0;
        switch ((MemoryQuestRewardType)index)
        {
            case MemoryQuestRewardType.Reward1:
                receiveTime = chapter.ReceivedStarRewardContents1Time;
                break;
            case MemoryQuestRewardType.Reward2:
                receiveTime = chapter.ReceivedStarRewardContents2Time;
                break;
            case MemoryQuestRewardType.Reward3:
                receiveTime = chapter.ReceivedStarRewardContents3Time;
                break;
        }
        
        return receiveTime > 0;
    }
    public static MqMemoryQuestStatusViewModel BuildMqMemoryQuestStatusViewModel(int memoryQuestId)
    {
        var master = DataManager.Instance.Master.MemoryQuest[memoryQuestId];

        var model = new MqMemoryQuestStatusViewModel();
        model.Chapter = master.chapter;
        model.MasterId = master.id;
        model.QuestId = master.questId;
        model.StaminaCost = master.useStamina;
        model.MemoryQuestType = master.memoryQuestType == 1
            ? MqMemoryQuestStatusViewModel.MqType.Normal
            : MqMemoryQuestStatusViewModel.MqType.Hard;
        model.BattleMasterId = master.battleMasterId;

        var star = 0;
        // decide whether unlocked
        model.PreMasterId = master.preMemoryQuestMasterId;
        model.RequireChapterMasterId = master.requireChapterMasterId;
        
        model.lockedType = MqMemoryQuestStatusViewModel.LockedType.Normal;
        model.soreType =  (MqMemoryQuestStatusViewModel.SoreType)master.memoryQuestSort;
        model.StarNumTotal = model.soreType == MqMemoryQuestStatusViewModel.SoreType.Small ? 0 : 3;
        model.vertical = master.verticalTopVaule;
        model.isWin = true;
        var data = DataManager.Instance.Player.MemoryQuest.TryGet(memoryQuestId);
        // data不为空说明已经解锁
        if (data != null)
        {
           
            if (model.soreType == MqMemoryQuestStatusViewModel.SoreType.Small)
            {
                model.isWin = data.Star1;
                model.DailyCountLeft = 1;
                model.StarNumGot = 3;
            }
            else
            {
                if (data.Star1) star++;
                if (data.Star2) star++;
                if (data.Star3) star++;
                model.StarNumGot = star;
                model.isWin = data.Star1;
                model.DailyCountLeft = master.limitDailyCount - (int) data.ChallengedCount;
            }

            return model;
        }
        
        if (model.lockedType == MqMemoryQuestStatusViewModel.LockedType.Normal && model.RequireChapterMasterId != 0)
        {
            var playerChapter = DataManager.Instance.Player.Chapter.TryGet(master.requireChapterMasterId);
            if (playerChapter ==null || playerChapter.Status != Status.Clear)
            {
                model.lockedType =  MqMemoryQuestStatusViewModel.LockedType.Chapter;
            }
        }
        if (model.lockedType == MqMemoryQuestStatusViewModel.LockedType.Normal && model.PreMasterId != 0)
        {
            var preModel = DataManager.Instance.Player.MemoryQuest.TryGet(master.preMemoryQuestMasterId);
            if (preModel == null || !preModel.Star1)
            {
                model.lockedType = MqMemoryQuestStatusViewModel.LockedType.Master;
            }
        }
        if (model.lockedType == MqMemoryQuestStatusViewModel.LockedType.Normal && model.MemoryQuestType == MqMemoryQuestStatusViewModel.MqType.Hard)
        {
            var chapterModel = DataManager.Instance.Master.MemoryQuestChapter.Values.First(_ => _.chapter==model.Chapter && _.memoryQuestType == 2);
            var requireStars = chapterModel.requireStarNum;
            

            var normalStarGot = 0;
            var normalMqs =
                DataManager.Instance.Master.MemoryQuest.Values.Where(_ =>
                    _.chapter == master.chapter && _.memoryQuestType == 1);
            {
                foreach (var normalMq in normalMqs)
                {
                    var playerMq = DataManager.Instance.Player.MemoryQuest.TryGet(normalMq.id);
                    if (playerMq != null && normalMq.memoryQuestSort == 2)
                    {
                        if (playerMq.Star1) normalStarGot++;
                        if (playerMq.Star2) normalStarGot++;
                        if (playerMq.Star3) normalStarGot++;   
                    }
                }
            }
            
            if (normalStarGot < requireStars)
            {
                model.lockedType = MqMemoryQuestStatusViewModel.LockedType.StatNum;
            }
        }
        // 说明已经解锁但是还没有通关 -> 新規
        model.DailyCountLeft =
            model.soreType == MqMemoryQuestStatusViewModel.SoreType.Small ? 0 : master.limitDailyCount;

        return model;
    }

    public static bool IsChapterStatusClear(this MqChapterStatusViewModel viewModel)
    {
        var masters = DataManager.Instance.Master.MemoryQuest.Values.Where(x => x.chapter == viewModel.Chapter);
        foreach (var memoryQuestMaster in masters)
        {
            var player = DataManager.Instance.Player.MemoryQuest.TryGet(memoryQuestMaster.id);
            if (player == null)
                return false;
        }

        return true;
    }
    public static bool IsChapterStatusNew(this MqChapterStatusViewModel viewModel)
    {
        var playerChapters = DataManager.Instance.Player.MemoryQuest.GetList();
        foreach (var memoryQuestMaster in playerChapters)
        {
            var player = DataManager.Instance.Master.MemoryQuest[(int)memoryQuestMaster.MemoryQuestMasterId];
            if (player!=null && player.chapter == viewModel.Chapter)
                return false;
        }

        return true;
    }

    public static float GetHorizontalNormalized(this MqChapterStatusViewModel viewModel,MqMemoryQuestStatusViewModel.MqType type)
    {
        var maxList = viewModel.MqSectionStatus.Values.Where(a => a.MemoryQuestType == type).OrderBy(a=>a.MasterId).ToArray();
        var length = maxList.Length;
        foreach (var memory in maxList)
        {
            var player = DataManager.Instance.Player.MemoryQuest.TryGet(memory.MasterId);
            if (player == null)
            {
                var master =  DataManager.Instance.Master.MemoryQuest[memory.MasterId];
                if (master.questId > 3 && master.questId < length -3 )
                    return (master.questId -2 )* 1.0f / (length-1);
                else if (master.questId > length -4 )
                    return 1;
                else
                    return 0;
            }
        }
        
        return 1;
    }
}

public class MqChapterStatusViewModel
{
    public int Chapter;
    public bool IsLocked;
    
    public int StarNumNormalTotal;
    public int StarNumHardTotal;
    public int StarNumNormalGot;
    public int StarNumHardGot;
    
    public int HardRequireStarNum;

    public int StarRewards1Normal;
    public int StarRewards2Normal;
    public int StarRewards3Normal;
    public int StarRewards1Hard;
    public int StarRewards2Hard;
    public int StarRewards3Hard;
    
    public bool StarRewards1NormalCanReceive;
    public bool StarRewards2NormalCanReceive;
    public bool StarRewards3NormalCanReceive;
    public bool StarRewards1HardCanReceive;
    public bool StarRewards2HardCanReceive;
    public bool StarRewards3HardCanReceive;

    public bool StarRewards1NormalReceived;
    public bool StarRewards2NormalReceived;
    public bool StarRewards3NormalReceived;
    public bool StarRewards1HardReceived;
    public bool StarRewards2HardReceived;
    public bool StarRewards3HardReceived;

    public List<MqMemoryQuestRewardViewModel> RewardViewModel;
    public Dictionary<int, MqMemoryQuestStatusViewModel> MqSectionStatus;
}

public class MqMemoryQuestRewardViewModel
{
    public int StarRewardNum;
    public MqMemoryQuestStatusViewModel.MqType MemoryQuestType;
    public StarRewardType RewardType;
    public enum StarRewardType
    {
        Not = 1,
        CanReceivel = 2,
        Received = 3
    }
}

public enum MemoryQuestRewardType
{
    Reward1 = 1,
    Reward2 = 2,
    Reward3 = 3,
}

public class MqMemoryQuestStatusViewModel
{
    public int MasterId;
    public int QuestId;
    public int PreMasterId;
    public int RequireChapterMasterId;
    public int Chapter;
    public LockedType lockedType;
    public bool isWin;
    public int StarNumGot;
    public int StarNumTotal;
    public MqType MemoryQuestType;
    public int DailyCountLeft;
    public int StaminaCost;
    public int BattleMasterId;
    public SoreType soreType;
    public int vertical;
    public bool IsLocked()
    {
        return lockedType != LockedType.Normal;
    }

    public bool IsSmallPass()
    {
        return soreType == SoreType.Small && DailyCountLeft > 0 && isWin;
    }

    public enum SoreType
    {
        Small = 1,
        Big = 2
    }

    public enum MqType
    {
        Normal = 1,
        Hard = 2,
    }

    public enum LockedType
    {
        Normal = 0,
        Chapter = 1,
        Master = 2,
        StatNum = 3,
    }
}