﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Base.Util;
using Takasho.Schema.Score.PlayerApi;
using Takasho.Schema.Score.ResourceCn.Mail.V1;
using UnityEngine;


public static class GachaUtil
{
 
    public static bool IsGachaContent(long itemId,int itemNum)
    {
        var haveNumber=  DataManager.Instance.Player.Item.GetCount(itemId);
        if (itemId == 108000001)
            haveNumber = DataManager.Instance.Player.Wallet.GetCount("PAID_STONE");
        return haveNumber >= itemNum;
    }
    public static int GetGachalotteryIndex(UIGachaResultModel resultModel,GachaDrawType type,GachaDrawItemType gachaDrawItemType )
    {
        if (type == GachaDrawType.One)
        {
            if (gachaDrawItemType == GachaDrawItemType.Charater)
            {
                return resultModel.itemList.Max(a => DataManager.Instance.Master.BattleCharacter[a.id].initialRank)-1 ;
            }
            else
            {
                return resultModel.itemList.Max(a => DataManager.Instance.Master.Equipment[a.id].rarity)-2;
            }
        }
        else
        {
            if (gachaDrawItemType == GachaDrawItemType.Charater)
            {
                var max = resultModel.itemList.Max(a => DataManager.Instance.Master.BattleCharacter[a.id].initialRank);
                return max == 3 ? 2 : 1;
            }
            else
            {
                var max = resultModel.itemList.Max(a =>  DataManager.Instance.Master.Equipment[a.id].rarity);
                return max == 3 ? 2 : 1;
            }
        }
    }

    public static List<long> GetFirstCharacterIds(this UIGachaResultModel resultModel)
    {
        return resultModel.itemList.Where(a => !a.isConverted).Select(a=>a.id).ToList();
    }
}

public class UIGachaListModel
{
    public List<UIGachaViewModel> gachaList;
}

public class UIGachaViewModel
{
    public GachaMaster master;
    public long id;
    public long openAt;
    public long closeAt;
    public long availableCount;
    public bool isDailyLlimit;
}

public class UIGachaMachineResult
{
    public string scenarioId;
    public Dictionary<long, long> scenarioRewards;
    public Dictionary<long, long> gachaRewards;
}

public class UIGachaResultModel
{
    public List<UIGachaResultViewModel> itemList = null;
}

public class UIGachaResultViewModel
{
    public long id;
    public bool isConverted;
    public Dictionary<long, long>  converted;
    public int type;

}
public class UIGachaHistoryViewModel
{
    public string historieId;
    public long gachaMasterId;
    public bool isSingle;
    public bool isCombo;
    public long createdAt;
    public UIGachaResultViewModel resultModel = new UIGachaResultViewModel();
}

public enum GachaDrawType
{
    One = 1,
    Ten = 2,
    DailyLimit = 3
}
public enum GachaDrawItemType
{
    Charater = 1,
    Equipment = 2,
    Item = 3,
}
