﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Takasho.Schema.Score.ResourceCn.Character.V1;
using Takasho.Schema.Score.ResourceCn.Equipment.V1;
using System.Linq;

public static class CharacterUtil
{
    public static CharacterViewModel BuildViewModel(PlayerBattleCharacter data, IEnumerable<PlayerEquipment> equipmentList, int playerRank = 0,int characterRank = 0)
    {
        CharacterViewModel model = new CharacterViewModel();
        model.id = data.BattleCharacterMasterId;
        if(characterRank == 0)
            model.rank = (int)data.Rank;
        else
            model.rank = characterRank;

        model.grade = (int)data.Grade;
        if (playerRank == 0) playerRank = DataManager.Instance.Player.Player.GetLevel();
        var levelCap =  DataManager.Instance.Master.CharacterGradeUp[model.grade].levelCap;
        model.maxLevel = levelCap;
        model.maxLevel = Mathf.Min(playerRank+DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.CharacterLevelLimitCap].data, model.maxLevel);
        model.contract = data.Engaged == 0? false:true;
        long remainExp = data.Exp;
        int lv = 1;
        while (lv < model.maxLevel)
        {
            var curLevelMaster = DataManager.Instance.Master.CharacterLevelUp[lv+1];
            if (remainExp >= curLevelMaster.exp)
            {
                lv++;
                remainExp -= curLevelMaster.exp;
            }
            else
            {
                break;
            }
        }

        model.level = lv;
        model.curExp = remainExp;
        var maxlevel = lv +1 > levelCap  ? levelCap : lv+1;
        //maxlevel =  Mathf.Min(maxlevel, model.maxLevel);
        model.maxExp = DataManager.Instance.Master.CharacterLevelUp[maxlevel].exp;

        model.ap = model.contract? DataManager.Instance.Master.BattleCharacter[model.id].afterContractAp:DataManager.Instance.Master.BattleCharacter[model.id].initialAp;

        var characterMaster = DataManager.Instance.Master.BattleCharacter[model.id];
        var characterRankMaster = DataManager.Instance.Master.CharacterRankUp.Values.FirstOrDefault((r)=>(r.battleCharacterMasterId==model.id&&r.rank==model.rank));

        if (characterRankMaster != null)    
        {
            model.meId = characterRankMaster.musicalEffectId;
        }
        else
        {
            model.meId = characterMaster.musicalEffectId;
        }
        
        model.attributeDict = new Dictionary<CharacterAttribute, int>();
        model.equipAttributeDict = new Dictionary<CharacterAttribute, int>();
        model.equipments = new Dictionary<int, EquipmentViewModel>();
        model.sphereAttributeDict = new Dictionary<CharacterAttribute, int>();
        foreach (var equip in equipmentList)
        {
            if (equip.BattleCharacterMasterId != data.BattleCharacterMasterId) continue;

            var equipMaster = DataManager.Instance.Master.Equipment[equip.EquipmentMasterId];
            model.equipments.Add(equipMaster.position, EquipmentUtil.BuildEquipmentViewModel(equip));
        }

        var levelAttr = CharacterUtil.CalculateLevelAttribute(model.id, model.level);

        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            CharacterAttribute eEquipAtt = (CharacterAttribute)i;

            model.attributeDict[eAtt] = levelAttr[eAtt];

            int equipVal = 0;
            foreach (var kv in model.equipments)
            {
                equipVal += kv.Value.attributeDict[eEquipAtt];
            }

            model.equipAttributeDict[eAtt] = equipVal;

            model.sphereAttributeDict[eAtt] = 0;
        }

        model.unlockedPanels = new List<long>();
        model.learnedSkills = new List<long>();
        model.selectedSkills = new List<long>();
        model.passiveSkills = new List<long>();
        model.skillSlotStatus = new List<long>();
        
        model.learnedSkills.Add(characterMaster.skill2Id);
        model.learnedSkills.Add(characterMaster.skill3Id);

        foreach (var panelId in data.ActivatedCharacterPanelMasterIds)
        {
            model.unlockedPanels.Add(panelId);
            var attDict = DataManager.Instance.Master.CharacterPanel[panelId].GetAttribute();
            foreach (var att in attDict)
            {
                model.attributeDict[att.Key] += att.Value;
                model.sphereAttributeDict[att.Key] += att.Value;
            }

            var skillId = DataManager.Instance.Master.CharacterPanel[panelId].getSkillId;
            if (skillId > 0)
            {
                model.learnedSkills.Add(skillId);
                if(DataManager.Instance.Master.Skill[skillId].skillType == 3)
                    model.passiveSkills.Add(skillId);
            }
        }

        for (int i = 1; i < (int) CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute) i;
            int val = model.attributeDict[eAtt];
            if (model.rank > 0 && characterRankMaster != null)
            {
                val = Mathf.FloorToInt(val * (1f + characterRankMaster.GetRankGrowthAttribute(eAtt) * 0.0001f));
            }

            model.attributeDict[eAtt] = val;
        }
        
        // model.learnedSkills.Add(characterMaster.passiveSkill1Id);
        // model.learnedSkills.Add(characterMaster.passiveSkill2Id);
        foreach (var skillid in data.SkillIds)
        {
            if(skillid>0)
                model.selectedSkills.Add(skillid);
        }
        foreach (var status in data.SkillSlotStatus)
        {
            model.skillSlotStatus.Add(status);
        }
        // if (data.ProfileSkill2Id > 0) model.selectedSkills.Add(data.ProfileSkill2Id);
        // if (data.ProfileSkill3Id > 0) model.selectedSkills.Add(data.ProfileSkill3Id);
        return model;
    }

    public static int CalculateBondLevel(long value)
    {
        long remainExp = value;
        int lv = CalculateBondLevel(value, out remainExp);

        return lv;
    }

    public static int CalculateBondLevel(long value, out long remain)
    {
        long remainExp = value;
        int lv = 1;
        while (DataManager.Instance.Master.BondsLvUp.ContainsKey(lv+1))
        {
            var curLevelMaster = DataManager.Instance.Master.BondsLvUp[lv+1];
            if (remainExp >= curLevelMaster.exp)
            {
                lv++;
                remainExp -= curLevelMaster.exp;
            }
            else
            {
                break;
            }
        }

        remain = remainExp;

        return lv;
    }

    public static bool IsGradeUp(long modelId)
    {
        var data = DataManager.Instance.Master.CharacterPanel[modelId];
        foreach (var item in data.requireContents)
        {
            var s = item.Split(':');
            var itemId = long.Parse(s[0]);
            var needNum = long.Parse(s[1]);
            long cur;
            if (DataManager.Instance.Master.Content[itemId].contentTypeMasterId == 106)
            {
                cur = DataManager.Instance.Player.Wallet.GetCount(DataManager.Instance.Master.ContentToTakashoResource[itemId].takashoName);
            }
            else
            {
                cur = DataManager.Instance.Player.Item.GetCount(itemId);
            }
            if (cur < needNum)
                return false;
        }
        return true;
    }
    
    
    public static bool CanOpenDoor(long doorID)
    {

        var data = DataManager.Instance.Master.ExploreDailyEvent[doorID].keyRequireList;
        
        List<Dictionary<int, int>> needToCheckList = new List<Dictionary<int, int>>();
        foreach (var item in data)
        {
            var tempStr = item.Split('_');
            Dictionary<int, int> checkListItem = new Dictionary<int, int>();
            for (int i = 0; i < tempStr.Length; i++)
            {
                var temp = tempStr[i].Split(':');
                var k = Convert.ToInt32(temp[0]);
                var v = Convert.ToInt32(temp[1]);
                checkListItem.Add(k,v);
            }
            needToCheckList.Add(checkListItem);
        }
        
        foreach (var item in needToCheckList)
        {
            foreach (var kv in item)
            {
                Debug.Log(kv.Key+" "+kv.Value);
            }
        }
        
        for (int i = 0; i < needToCheckList.Count; i++)
        {
            var flag = true;
            foreach (var kv in needToCheckList[i])
            {
                var haveNumber=DataManager.Instance.Player.Item.GetCount(kv.Key);
                if (haveNumber<kv.Value)
                {
                    flag = false;
                    break;
                }
            }

            if (flag)
            {
                foreach (var item in needToCheckList[i])
                {
                    Debug.Log(item.Key+" "+item.Value);
                }
                return true;
                
            }
        }

        return false;






        // foreach (var checkDic in needToCheckList)
        // {
        //     
        //     foreach (var kv in checkDic)
        //     {
        //         var haveNumber=DataManager.Instance.Player.Item.GetCount(kv.Key);
        //         if (haveNumber<kv.Value)
        //         {
        //             CanOpen = false;
        //             break;
        //         }
        //     }
        //     
        // }

        // Dictionary<int, int> keyRequireDic = new Dictionary<int, int>();
        // foreach (var VARIABLE in data)
        // {
        //     var t = VARIABLE.Split(':');
        //     var keyID = Convert.ToInt32(t[0]) ;
        //     var requireNumber = Convert.ToInt32(t[1]);
        //     keyRequireDic.Add(keyID,requireNumber);
        // }
        //
        // foreach (var VARIABLE in keyRequireDic)
        // {
        //     Debug.Log("消耗"+VARIABLE.Key+"  "+VARIABLE.Value + " 拥有"+DataManager.Instance.Player.Item.GetCount(VARIABLE.Key));
        //
        //     if (VARIABLE.Value<=DataManager.Instance.Player.Item.GetCount(VARIABLE.Key))
        //     {
        //
        //         return true;
        //     }
        // }
        // return false;




    }

    public static Dictionary<CharacterAttribute, int> CalculateLevelAttribute(long characterMasterId, int level)
    {
        Dictionary<CharacterAttribute, int> result = new Dictionary<CharacterAttribute, int>();

        var levelGrowth = DataManager.Instance.Master.BattleCharacterGrowth.Values.Where(x=>x.characterId == characterMasterId);
        
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            var eAttr = (CharacterAttribute)i;

            var value = DataManager.Instance.Master.BattleCharacter[characterMasterId].GetInitialAttribute(eAttr);
            foreach (var item in levelGrowth)
            {
                if (level >= item.maxLevel)
                {
                    value += item.GetLevelGrowthAttribute(eAttr);
                }
                else if (level > item.minLevel)
                {
                    value += (level-item.minLevel)*item.GetLevelGrowthAttribute(eAttr)/(item.maxLevel-item.minLevel);
                }
                else
                {
                    break;
                }
            }

            result.Add(eAttr, value);
        }

        return result;
    }

    public static bool GetExpOverflow(CharacterViewModel model,int itemId,long nowTotleExp)
    {
        var itemExp = DataManager.Instance.Master.Item[itemId].exp;
        var maxLevelCap = DataManager.Instance.Master.CharacterGradeUp[model.grade].levelCap;
        int lv = 1;
        long totleExp = 0;
        while (lv <= model.maxLevel)
        {
            var level = lv+1;
            if (level > maxLevelCap)
                break;
            var curLevelMaster = DataManager.Instance.Master.CharacterLevelUp[level];
            totleExp += curLevelMaster.exp;
            lv++;
        }
        var newExp = DataManager.Instance.Player.Character.TryGet(model.id).Exp + nowTotleExp;
        return (totleExp-newExp)<itemExp;
    }
}


public class CharacterViewModel
{
    public long id;
    public long curExp;
    public long maxExp;
    public int level;
    public int maxLevel;
    public int grade;
    public int rank;
    public Dictionary<int, EquipmentViewModel> equipments = null;
    public long meId;
    public List<long> learnedSkills = null;
    public List<long> selectedSkills = null;
    public List<long> passiveSkills = null;
    public List<long> skillSlotStatus = null;
    public Dictionary<CharacterAttribute, int> attributeDict = null;
    public Dictionary<CharacterAttribute, int> equipAttributeDict = null;
    public Dictionary<CharacterAttribute, int> sphereAttributeDict = null;
    public List<long> unlockedPanels = null;
    public bool contract;
    public int ap;
}

public enum CharacterAttribute : int
{
    Hp = 1,
    Spd,
    PAtk,
    PDef,
    MAtk,
    MDef,
    Crt,
    CrtDmg,
    CrtResist,
    CrtDmgResist,
    Max,
}

public static class CharacterAttributeExtention
{
    public static int GetInitialAttribute(this BattleCharacterMaster master, CharacterAttribute attribute)
    {
        switch (attribute)
        {
            case CharacterAttribute.Hp:
                return master.initialHp;
            case CharacterAttribute.PAtk:
                return master.initialAtk;
            case CharacterAttribute.PDef:
                return master.initialDef;
            case CharacterAttribute.Spd:
                return master.initialDex;
            case CharacterAttribute.MAtk:
                return master.initialInt;
            case CharacterAttribute.MDef:
                return master.initialRes;
            case CharacterAttribute.Crt:
                return master.initialCrt;
            case CharacterAttribute.CrtDmg:
                return master.initialCrd;
            case CharacterAttribute.CrtResist:
                return master.initialAcrt;
            case CharacterAttribute.CrtDmgResist:
                return master.initialCrdr;
            default:
                return 0;
        }
    }

    //delete later
    public static int GetLevelGrowthAttributeObsolete(this BattleCharacterMaster master, CharacterAttribute attribute)
    {
        switch (attribute)
        {
            case CharacterAttribute.Hp:
                return master.hpGrowthValue;
            case CharacterAttribute.PAtk:
                return master.atkGrowthValue;
            case CharacterAttribute.PDef:
                return master.defGrowthValue;
            case CharacterAttribute.Spd:
                return master.dexGrowthValue;
            case CharacterAttribute.MAtk:
                return master.intGrowthValue;
            case CharacterAttribute.MDef:
                return master.resGrowthValue;
            case CharacterAttribute.Crt:
                return master.crtGrowthValue;
            case CharacterAttribute.CrtDmg:
                return master.crdGrowthValue;
            case CharacterAttribute.CrtResist:
                return master.acrtGrowthValue;
            case CharacterAttribute.CrtDmgResist:
                return master.crdrGrowthValue;
            default:
                return 0;
        }
    }

    public static int GetLevelGrowthAttribute(this BattleCharacterGrowthMaster master, CharacterAttribute attribute)
    {
        switch (attribute)
        {
            case CharacterAttribute.Hp:
                return master.incrHp;
            case CharacterAttribute.PAtk:
                return master.incrAtk;
            case CharacterAttribute.PDef:
                return master.incrDef;
            case CharacterAttribute.Spd:
                return master.incrDex;
            case CharacterAttribute.MAtk:
                return master.incrInt;
            case CharacterAttribute.MDef:
                return master.incrRes;
            case CharacterAttribute.Crt:
                return master.incrCrt;
            case CharacterAttribute.CrtDmg:
                return master.incrCrd;
            case CharacterAttribute.CrtResist:
                return master.incrAcrt;
            case CharacterAttribute.CrtDmgResist:
                return master.incrCrdr;
            default:
                return 0;
        }
    }

    public static int GetRankGrowthAttribute(this CharacterRankUpMaster master, CharacterAttribute attribute)
    {
        switch (attribute)
        {
            case CharacterAttribute.Hp:
                return master.hpGrowthValue;
            case CharacterAttribute.PAtk:
                return master.atkGrowthValue;
            case CharacterAttribute.PDef:
                return master.defGrowthValue;
            case CharacterAttribute.Spd:
                return master.dexGrowthValue;
            case CharacterAttribute.MAtk:
                return master.intGrowthValue;
            case CharacterAttribute.MDef:
                return master.resGrowthValue;
            case CharacterAttribute.Crt:
                return master.crtGrowthValue;
            case CharacterAttribute.CrtDmg:
                return master.crdGrowthValue;
            case CharacterAttribute.CrtResist:
                return master.acrtGrowthValue;
            case CharacterAttribute.CrtDmgResist:
                return master.crdrGrowthValue;
            default:
                return 0;
        }
    }

    public static Dictionary<CharacterAttribute, int> GetAttribute(this CharacterPanelMaster master)
    {
        Dictionary<CharacterAttribute, int> res = new Dictionary<CharacterAttribute, int>();

        foreach (var att in master.getAttributes)
        {
            var s = att.Split(':');
            res.Add((CharacterAttribute)int.Parse(s[0]), int.Parse(s[1]));
        }

        return res;
    }

    public static string GetAttributePercent(this CharacterAttribute attributeType ,int attribute)
    { 
        switch (attributeType)
        {
            case CharacterAttribute.Hp:
            case CharacterAttribute.PAtk:
            case CharacterAttribute.PDef:
            case CharacterAttribute.Spd:
            case CharacterAttribute.MAtk:
            case CharacterAttribute.MDef:
                return attribute.ToString();
            case CharacterAttribute.Crt:
            case CharacterAttribute.CrtDmg:
            case CharacterAttribute.CrtResist:
            case CharacterAttribute.CrtDmgResist:
                return $"{(attribute*0.01f):0.00}%";
            default:
                return "";
        }
    }

    public static string GetAttributeRateStr(this CharacterViewModel model, CharacterAttribute attribute)
    {
        var master = DataManager.Instance.Master.BattleCharacter[model.id];
        switch (attribute)
        {
            case CharacterAttribute.Hp:
                return ((AttributeRateType) master.rateHp).ToString();
            case CharacterAttribute.PAtk:
                return ((AttributeRateType) master.rateAtk).ToString();
            case CharacterAttribute.PDef:
                return ((AttributeRateType) master.rateDef).ToString();
            case CharacterAttribute.Spd:
                return ((AttributeRateType) master.rateInt).ToString();
            case CharacterAttribute.MAtk:
                return ((AttributeRateType) master.rateDex).ToString();
            case CharacterAttribute.MDef:
                return ((AttributeRateType) master.rateCrt).ToString();
            case CharacterAttribute.Crt:
                return ((AttributeRateType) master.rateCrd).ToString();
            case CharacterAttribute.CrtDmg:
                return ((AttributeRateType) master.rateAtk).ToString();
            case CharacterAttribute.CrtResist:
                return ((AttributeRateType) master.rateAcrt).ToString();
            case CharacterAttribute.CrtDmgResist:
                return ((AttributeRateType) master.rateCrdr).ToString();
            default:
                return "";
        }
    }
    
    public enum AttributeRateType :int
    {
        B = 1,
        A = 2,
        S = 3
    }
}

public enum CharacterRole : int
{
    Attacker = 1,
    Shooter,
    Magician,
    Assassin,
    Healer,
    Defender,
    Max,
}