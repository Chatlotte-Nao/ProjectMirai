using System.Collections.Generic;
using System.Linq;
using Adventure.Util;
using Base.Sound;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.UI;

public class CharacterTouchHandler : MonoBehaviour
{
    private int soundIndex = -1;

    enum InteractionType
    {
        touch = 1,
        passtive = 2,
        enter = 3,
        spec = 4,
    }
    // 接受UI事件

    // 控制动画

    //Content
    [SerializeField] private GameObject Bubble_frame;
    [SerializeField] private UIText content;


    //uibutton
    [SerializeField] private RawImage characterImage;
    [SerializeField] private UIButton button;

    //skeletonanimation
    [SerializeField] private SkeletonAnimation skeletonAnimation;

    private int CharaID;
    UIRTCamera mRTCamera = null;
    private TrackEntry mouthTrack;
    private TrackEntry bodyTrack;
    private TrackEntry expressionTrack;
    private bool isPlay;
    private float endTime;

    public float guardTime = 1; //连点保护


    float passtiveCountDown = 15f;
    float passtiveTimer;
    private long charaID = -1;
    private GameObject interactionObj;

    string actionFace = "";
    string actionBody = "";
    string endActionFace = "";
    string endActionBody = "";
    string voice = "";
    long length;
    string text = "";
    private bool firstIn = true;

    /// <summary>
    /// key为类型 
    /// </summary>
    /// <returns></returns>
    public Dictionary<int, List<CharacterReactionMaster>> actionMasterDic =
        new Dictionary<int, List<CharacterReactionMaster>>();


    public async UniTask Init(bool refresh, float openWaitTime = -1f, int _soundIndex = -1, float _guardTime = 1)
    {
        this.soundIndex = _soundIndex;
        this.guardTime = _guardTime;
        SetUp();
        SoundManager.StopVoice();
        var rtc = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/RTCamera");
        mRTCamera = rtc.GetComponent<UIRTCamera>();
        if (refresh) await RefreshChara();

        if (openWaitTime > 0)
        {
            Invoke(nameof(mPlayOpenning), openWaitTime);
        }
    }

    void SetUp()
    {
        passtiveTimer = 99999;
        endTime = 99999;
        isPlay = false;
    }


    public async UniTask RefreshChara(int id = -1)
    {
        endTime = 99999;
        if (Time.time < lastClickTime + guardTime)
        {
            return;
        }

        if (charaID != DataManager.Instance.Player.Player.GetData().ProfileIconId || id != -1) // 没更换角色时不刷新
        {
            charaID = id == -1 ? DataManager.Instance.Player.Player.GetData().ProfileIconId : id;

            // var resourceMaster =DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[charaID].characterResourceId];

            var resourceMaster =
                DataManager.Instance.Master.CharacterResource[
                    DataManager.Instance.Master.BattleCharacter[charaID].characterResourceId];

            var mCharacterViewModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get(charaID),
                DataManager.Instance.Player.Equipment.GetList());
            var engage = mCharacterViewModel.contract ? 1 : 0; //目前只有签订未签订状态区别

            //
            actionMasterDic.Clear();
            var master = DataManager.Instance.Master.CharacterReaction;

            foreach (var item in master)
            {
                if (item.Value.charaID == charaID && item.Value.engage >= engage) //签订契约后也可以触发签订契约之前的交互
                {
                    var actionType = item.Value.actionType;
                    if (!actionMasterDic.ContainsKey(actionType))
                        actionMasterDic[actionType] = new List<CharacterReactionMaster>();
                    actionMasterDic[actionType].Add(item.Value);
                }
            }

            if (interactionObj != null)
            {
                Destroy(interactionObj);
            }

            interactionObj =
                await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/chara/" +
                                                                             resourceMaster.advModelId);
            if (skeletonAnimation!=null)
            {
                Log.Debug("StopIndex"+soundIndex+"B");
                SoundManager.StopVoice();
            }
            skeletonAnimation = interactionObj.GetComponent<SkeletonAnimation>();
            

            if (Bubble_frame.activeSelf)
            {
                Bubble_frame.SetActive(false);
                CancelInvoke("BubbleFrameDeactive");
            }

            mRTCamera.Setup(interactionObj);
            characterImage.texture = mRTCamera.GetRenderTexture();

            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(TouchInteraction);
        }


        // if (string.IsNullOrEmpty(overrideEnterAnimation))
        // {
        //     if (firstIn)
        //     {
        //         if(openAnimation) mPlayOpenning();
        //     }
        //     else
        //     {
        //         mPlayOpenning();
        //     }
        // }
        // else
        // {
        //     var animations = skeletonAnimation.AnimationState?.Data?.SkeletonData?.Animations;
        //     var animation = animations.FirstOrDefault(tempAnimation => tempAnimation.Name.StartsWith(overrideEnterAnimation));
        //     if (animation != null)
        //     {
        //         skeletonAnimation.AnimationState.SetAnimation(0, animation, true);
        //     }                   
        // }
        //
        // firstIn = false;
    }


    public void PlayOpenning(string overrideEnterAnimation = "")
    {
        if (string.IsNullOrEmpty(overrideEnterAnimation))
        {
            if (!firstIn)
            {
                mPlayOpenning();
            }
        }
        else
        {
            var animations = skeletonAnimation.AnimationState?.Data?.SkeletonData?.Animations;
            var animation =
                animations.FirstOrDefault(tempAnimation => tempAnimation.Name.StartsWith(overrideEnterAnimation));
            if (animation != null)
            {
                skeletonAnimation.AnimationState.SetAnimation(0, animation, false);
                skeletonAnimation.AnimationState.Complete+= AnimationStateOnComplete;
            }
        }

        firstIn = false;
    }

    private void AnimationStateOnComplete(TrackEntry trackentry)
    {
        skeletonAnimation.AnimationState.Complete -= AnimationStateOnComplete;
        TouchInteraction(this.gameObject); 
        // throw new System.NotImplementedException();
    }


    public void Dispose()
    {
        Destroy(mRTCamera.gameObject);
        Destroy(skeletonAnimation.gameObject);
        mRTCamera = null;
        skeletonAnimation = null;
        actionFace = null;
        actionBody = null;
        endActionFace = null;
        endActionBody = null;
        actionMasterDic = null;
    }


    // Update is called once per frame
    void Update()
    {
        if (isPlay)
        {
            if (Time.time > endTime)
            {
                EndAction();
                isPlay = false;
                passtiveTimer = Time.time;
            }
        }
        else
        {
            if (Time.time > passtiveTimer + passtiveCountDown)
            {
                isPlay = true;
                Play(InteractionType.passtive);
            }
        }
    }

    private int lastRandomKey = -1;

    CharacterReactionMaster GetRandomActionByType(InteractionType type)
    {
        CharacterReactionMaster crm = null;
        if (!actionMasterDic.ContainsKey((int) type)) return null;

        var randomKey = UnityEngine.Random.Range(0, actionMasterDic[(int) type].Count);
        if (lastRandomKey == randomKey)
        {
            randomKey = (randomKey + 1) % actionMasterDic[(int) type].Count;
        }

        lastRandomKey = randomKey;
        crm = actionMasterDic[(int) type][randomKey];
        return crm;
    }


    private void TouchInteraction(GameObject arg0)
    {
        Play(InteractionType.touch);
    }

    private void mPlayOpenning()
    {
        Play(InteractionType.enter);
    }

    private float lastClickTime = float.NegativeInfinity;


    private void OnDisable()
    {
        EndAction();
        isPlay = false;
        passtiveTimer = Time.time;
        if (SoundManager.GetInstance().VoiceSourceCountainIndex(soundIndex))
        {
            SoundManager.StopVoice(soundIndex);
        }
        if (Bubble_frame.activeSelf)
        {
            Bubble_frame.SetActive(false);
            CancelInvoke("BubbleFrameDeactive");
        }
    }


    void Play(InteractionType type)
    {
        if (Time.time < lastClickTime + guardTime)
        {
            return;
        }

        lastClickTime = Time.time;
        isPlay = true;
        var action = GetRandomActionByType(type);
        if (action == null)
        {
            Log.Debug($"reaction not found! type={type}");
            return;
        }

        actionFace = action.actionFace;
        actionBody = action.actionBody;
        endActionFace = action.endActionFace;
        endActionBody = action.endActionBody;
        voice = action.voice;
        text = action.id.ToString();
        length = SoundManager.GetVoiceTime() > 10000 ? SoundManager.GetVoiceTime() : 10000;
        AdvSpineMaster bodyMaster = new AdvSpineMaster();
        AdvSpineMaster faceMaster = new AdvSpineMaster();
        try
        {
            bodyMaster = DataManager.Instance.Master.AdvSpine[actionBody];
            faceMaster = DataManager.Instance.Master.AdvSpine[actionFace];
        }
        catch
        {
            Log.Debug("actionList为空");
            return;
        }

        var voiceLength = SoundExpansion.GetVoiceLength(voice);
        SoundManager.PlayVoice(voice);
        Log.Debug("C");
        if (Bubble_frame.activeSelf)
        {
            Bubble_frame.SetActive(false);
            CancelInvoke("BubbleFrameDeactive");
        }
        Bubble_frame.SetActive(true);

        if (Bubble_frame.activeSelf)
        {
            content.SetLabel(LocalizeManager.DATA_TYPE.CharacterBubbleText, $"{text}_content");
            Invoke("BubbleFrameDeactive", length / 1000);
        }



        bodyTrack = skeletonAnimation.AnimationState.SetEmptyAnimation(0, 0f);
        skeletonAnimation.AnimationState.SetEmptyAnimations(0);


        if (!string.IsNullOrEmpty(bodyMaster.body))
        {
            bodyTrack = skeletonAnimation.AnimationState.SetAnimation(0, bodyMaster.body, false);
            bodyTrack = skeletonAnimation.AnimationState.AddAnimation(0, bodyMaster.waiting, true, 0);
        }
        else
        {
            bodyTrack = skeletonAnimation.AnimationState.SetAnimation(0, bodyMaster.waiting, true);
        }


        expressionTrack = skeletonAnimation.AnimationState.SetAnimation(1, faceMaster.expression, false);
        if (string.IsNullOrEmpty(faceMaster.expression_loop))
        {
            expressionTrack = skeletonAnimation.AnimationState.SetAnimation(1, faceMaster.expression, true);
            // expressionTrack= skeletonAnimation.AnimationState.AddAnimation(1, faceMaster.expression_loop, true,0);
        }
        else
        {
            expressionTrack = skeletonAnimation.AnimationState.SetAnimation(1, faceMaster.expression, false);
            expressionTrack = skeletonAnimation.AnimationState.AddAnimation(1, faceMaster.expression_loop, true, 0);
        }

        if (string.IsNullOrEmpty(faceMaster.mouthPark_loop))
        {
            mouthTrack = skeletonAnimation.AnimationState.SetAnimation(2, faceMaster.openMouth, true);
            Log.Debug("无嘴部循环动画 AdvSpineMaster mouthPark_loop不能为空");
        }
        else
        {
            mouthTrack = skeletonAnimation.AnimationState.SetAnimation(2, faceMaster.openMouth, false);
            try
            {
                mouthTrack = skeletonAnimation.AnimationState.AddAnimation(2, faceMaster.mouthPark_loop, true, 0);
            }
            catch
            {
                Log.Debug("mouthPark_loop " + faceMaster.mouthPark_loop + " 动画未找到 检查配置表");
            }
        }
        // mouthTrack= skeletonAnimation.AnimationState.SetAnimation(2, faceMaster.openMouth, false);
        // if(!string.IsNullOrEmpty(faceMaster.mouthPark_loop)) mouthTrack= skeletonAnimation.AnimationState.AddAnimation(2, faceMaster.mouthPark_loop, true,0);


        endTime = voiceLength / 1000f + Time.time;
    }


    void EndAction()
    {
        
        AdvSpineMaster bodyMaster = null;
        AdvSpineMaster faceMaster = null;
        if (!string.IsNullOrEmpty(endActionBody)) bodyMaster = DataManager.Instance.Master.AdvSpine[endActionBody];
        if (!string.IsNullOrEmpty(endActionFace)) faceMaster = DataManager.Instance.Master.AdvSpine[endActionFace];


        if (bodyMaster != null)
        {
            if (!string.IsNullOrEmpty(bodyMaster.body))
            {
                bodyTrack = skeletonAnimation.AnimationState.SetAnimation(0, bodyMaster.body, false);
                bodyTrack = skeletonAnimation.AnimationState.AddAnimation(0, bodyMaster.waiting, true, 0);
            }
            else
            {
                if (!string.IsNullOrEmpty(bodyMaster.waiting))
                    bodyTrack = skeletonAnimation.AnimationState.SetAnimation(0, bodyMaster.waiting, true);
            }
        }


        if (faceMaster != null)
        {
            expressionTrack = skeletonAnimation.AnimationState.SetAnimation(1, faceMaster.expression, false);
            if (!string.IsNullOrEmpty(faceMaster.expression_loop))
                expressionTrack = skeletonAnimation.AnimationState.AddAnimation(1, faceMaster.expression_loop, true, 0);
        }

        if (mouthTrack != null)
        {
            mouthTrack = skeletonAnimation.AnimationState.SetAnimation(2, faceMaster.mouthClosed, false);
        }
    }

    void BubbleFrameDeactive()
    {
        Bubble_frame.SetActive(false);
    }
}