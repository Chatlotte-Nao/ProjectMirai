﻿
using Game.Util;
using System.Collections.Generic;
using System.Linq;

namespace Map
{
	/// <summary>
	/// ADV条件チェック管理
	/// </summary>
	public class CheckAdvMaster
	{
		/// <summary>
		/// 現在有効なADVマスターを参照する
		/// </summary>
		public static List<AdvMaster> Check()
		{
			var master = DataManager.Instance.Master.Adv.Values;

			List<AdvMaster> masters = new List<AdvMaster>();

			foreach (var m in master)
			{
				//今行っている章とは違う物は追加せずに次へ
				if (m.chapter != AdvManager.Instance.CurrentChapter)
					continue;
				if (m.section != AdvManager.Instance.CurrentSection)
					continue;

				//登場条件がありつつ、条件を満たしていなげれば追加せずに次へ
				if (m.routeCond.Count > 0 &&
					!CondUtil.IsCheckCond(m.selectRouteCond, m.routeCond))
					continue;

				//消滅条件を満たしていたら追加せずに次へ
				if (GetExitNo(m) > 0)
					continue;

				//非共存ルートだったら追加せずに次へ
				if (IsCheckAbsent(masters, m.absentRoute))
					continue;
				//同キャラ優先度
				if (!IsPriority(ref masters, m.miniCharacterId, m.priority))
					continue;

				//追加
				masters.Add(m);
			}

			return masters;
		}

		/// <summary>
		/// 出現条件を満たしているか ※出現条件を満たしているかと、実際に出るかはまた別物なので注意
		/// </summary>
		public static bool IsMeetAppearanceCondition(AdvMaster master)
		{
			if (master == null)
				return false;

			//登場条件がありつつ、条件を満たしていなげればfalse
			if (master.routeCond.Count > 0 &&
				!CondUtil.IsCheckCond(master.selectRouteCond, master.routeCond))
				return false;

			//消滅条件を満たしていたらfalse
			if (GetExitNo(master) > 0)
				return false;
			return true;
		}

		/// <summary>
		/// ADV終了後、フェードクリアしない（暗転を元に戻さない）でマップ強制移動を行う物か
		/// </summary>
		public static bool IsAfterMapChangeWithoutFadeClear(AdvMaster master)
		{
			if (master == null)
				return false;

			if (master.isAfterMapChangeWithoutFadeClear == 0)
				return false;

			if (string.IsNullOrEmpty(master.afterLocationLabel) &&
				string.IsNullOrEmpty(master.afterRouteName))
			{
				UnityEngine.Debug.LogWarning("移動先設定が無いのにisAfterMapChangeWithoutFadeClearが設定されています！　master:" + master.routeName);
				return false;
			}
			return true;
		}

		/// <summary>
		/// 今の場所内で起こりうるサブADVリストを取得
		/// </summary>
		public static List<AdvMaster> GetLocationNonPlaySubList(string locationLabel)
		{
			var master = DataManager.Instance.Master.Adv.Values;
			List<AdvMaster> masters = new List<AdvMaster>();

			foreach (var m in master)
			{
				if (m.chapter != AdvManager.Instance.CurrentChapter)
					continue;
				if (m.section != AdvManager.Instance.CurrentSection)
					continue;
				if (m.mainRouteType != 1)
					continue;
				//※場所指定があるADVのみチェック（場所指定が無いADV=場所はどこでもいい）
				if (!string.IsNullOrEmpty(m.locationLabel) &&
					!locationLabel.Equals(m.locationLabel))
					continue;
				//進行度を満たしていないADVは無視
				//if (UserData.GetPlayerData().progressNum < m.openProgressNum)
					//continue;
				if (ScenarioParameterUtil.IsParamValue("Read_" + m.routeName))
					continue;
				masters.Add(m);
			}

			return masters;
		}

		/// <summary>
		/// マップ上に表示設定されるADV取得
		/// </summary>
		/// <returns></returns>
		public static List<AdvMaster> GetMapDisplayAdvMaster()
		{
			//有効なADVマスターリスト
			var advMasterList = CheckAdvMaster.Check();
			//※退避演出がまだの物も追加
			advMasterList.AddRange(CheckAdvMaster.GetStartExitEffectMaster(MapSceneManager.Instance.CurrentScene.GetNowMapLabel()));
			return advMasterList;
		}

		/// <summary>
		/// 今の場所内で有効になっているADVリストを取得
		/// </summary>
		/// <param name="locationLabel">今の場所のロケーションラベル(LocationMasterのlabel)</param>
		public static List<AdvMaster> GetLocationActiveList(string locationLabel)
		{
			var master = Check();
			List<AdvMaster> masters = new List<AdvMaster>();
			foreach (var m in master)
			{
				//※場所指定があるADVのみチェック（場所指定が無いADV=場所はどこでもいい）
				if (!string.IsNullOrEmpty(m.locationLabel) &&
					!locationLabel.Equals(m.locationLabel))
					continue;
				masters.Add(m);
			}
			return masters;
		}

		/// <summary>
		/// どのセクション開始マスタが発生しているか
		/// </summary>
		/// <returns></returns>
		public static int? ExistsSectionStart()
		{
			var masters = Check();
			var start = masters.Find(m => m.sectionStart == 1);

			if (start == null)
				return null;

			return start.section;
		}

		/// <summary>
		/// どの強制遷移が発生しているか
		/// </summary>
		/// <returns></returns>
		public static AdvMaster ExistsTransitionSection()
		{
			var masters = Check();
			var change = masters.Find(m => m.isStartTransition == 1);
			if (change == null)
				return null;

			return change;
		}

		/// <summary>
		/// 探索コスト超過状態になっている目標マスターを取得
		/// </summary>
		/// <returns></returns>
		public static GoalMessageMaster GetCostOverGoalMaster()
		{
			
   //         var goalMessageList = UserData.GetPlayerData().goalMessageList;

			////※総コスト自体がまだ設定されていなかったらnullを返す

   //         if (UserData.GetPlayerData().searchTotalCount <= 0)
   //             return null;

   //         foreach (var id in goalMessageList)
   //         {
   //             var m = DataManager.Instance.Master.GoalMessage[id];
   //             if (m == null) continue;
   //             if (!m.IsParent()) continue;
   //             if (m.totalCost <= 0) continue;
   //             if (UserData.GetPlayerData().searchCount < UserData.GetPlayerData().searchTotalCount) continue;
   //             //コスト超過していても、目標達成していた時には除外
   //             if (GoalMessageController.IsMeetClearConditions(m)) continue;

   //             return m;
   //         }
            return null;
		}

		/// <summary>
		/// 今の場所内でこれから出現演出が行われるADVリストを取得
		/// </summary>
		/// <param name="locationLabel">今の場所のロケーションラベル(LocationMasterのlabel)</param>
		public static List<AdvMaster> GetStartAppearsEffectMaster(string locationLabel)
		{
			//var playerData = UserData.GetPlayerData();
			var list = GetLocationActiveList(locationLabel);
            //list = list.Where(l => l.appearsEffect > 0 &&
            //            !IsAppearsEffectOnData(l) &&
            //            !IsExitEffectOnData(l)
            //            ).ToList();
            return list;
		}

		/// <summary>
		/// 今の場所内でこれから退避演出が行われるADVリストを取得
		/// </summary>
		public static List<AdvMaster> GetStartExitEffectMaster(string locationLabel)
		{
			var master = DataManager.Instance.Master.Adv.Values;

			List<AdvMaster> masters = new List<AdvMaster>();

			//登場・消滅条件を両方満たしたものが対象
			foreach (var m in master)
			{
				//今行っている章とは違う物は追加せずに次へ
				if (m.chapter != AdvManager.Instance.CurrentChapter)
					continue;
				if (m.section != AdvManager.Instance.CurrentSection)
					continue;

				var exitNo = GetExitNo(m);

				if (exitNo == 0)
					continue;

				if ((exitNo == 1 && m.exitEffect == 0) ||
					(exitNo == 2 && m.exitEffectB == 0))
				{
					continue;
				}

				//※場所指定があるADVのみチェック（場所指定が無いADV=場所はどこでもいい）
				if (!string.IsNullOrEmpty(m.locationLabel) &&
					!locationLabel.Equals(m.locationLabel))
					continue;

				//追加
				masters.Add(m);
			}

			return masters;
		}

		/// <summary>
		/// 有効なADVルートの中からスクリプト開始可能な要素を取得
		/// </summary>
		/// <returns></returns>
		public static AdvMaster GetStartMaster(string locationLabel)
		{
			var list = GetStartMasterList(locationLabel);
			if (list.Count <= 0) return null;

			return list[0];
		}

		/// <summary>
		/// 今開始されようとしているADVが存在するか
		/// </summary>
		/// <returns></returns>
		public static bool IsNowStartAdv(string locationLabel)
		{
			if (GetStartMaster(locationLabel) != null)
			{
				return true;
			}
			var overMaster = GetCostOverGoalMaster();
			if (overMaster != null && !string.IsNullOrEmpty(overMaster.costOverScenarioId))
			{
				return true;
			}
			return false;
		}

		/// <summary>
		/// 有効なADVルートの中から、もうこれからスクリプトが開始される(リングコマンドの時はそのコマンドが出る)という状態になっているマスターのリスト取得
		/// </summary>
		public static List<AdvMaster> GetStartMasterList(string locationLabel)
		{
			var list = new List<AdvMaster>();
			var masters = GetLocationActiveList(locationLabel);

			foreach (var m in masters)
			{
				//有効になったら発生する条件がないもの、もしくは発生条件を満たしたものが対象
				if (m.startScript.Count > 0 &&
					!CondUtil.IsCheckCond(m.selectStartCond, m.startScript))
				{
					continue;
				}

				list.Add(m);
			}
			
			//ホーム画面時の時に同じ場所の複数キャラスクリプトが動く状態の時
			if (MapManager.GetNowPlayingConductType() == MapConstants.MAP_CONDUCT_TYPE.HOME &&
				list.Count > 1)
			{
                //ADV後バトルステージを取得
               // var stageMasters = new List<AreaStageMaster>();
               // foreach (var m in list)
               // {
               //     var stage = AreaStageMaster.GetFromNumber(UserData.GetPlayerData().questNowId, m.afterBattleNumber);
               //     if (stage == null)
               //         continue;
               //     stageMasters.Add(stage);
               // }
               //// バトルステージ設定がされていないときは、選択されたキャラのスクリプトのみが動く

               // if (stageMasters.Count <= 0)
               // {
               //     var pointList = new List<string>();
               //     var samePointList = new List<string>();
               //     foreach (var one in list)
               //     {
               //         if (pointList.Any(p => p.Equals(one.entryRoom)))
               //         {
               //             samePointList.Add(one.entryRoom);
               //         }
               //         else
               //         {
               //             pointList.Add(one.entryRoom);
               //         }
               //     }

               //     if (samePointList.Count > 0)
               //     {
               //         var charaId = ScenarioParameterUtil.GetTouchChara();
               //         if (!string.IsNullOrEmpty(charaId))
               //         {
               //             list.RemoveAll(l => !charaId.Equals(l.miniCharacterId) && samePointList.Any(s => s.Equals(l.entryRoom)));
               //         }
               //         else
               //         {
               //             list.Clear();
               //         }
               //     }
               // }
            }

			return list;
		}
		/// <summary>
		/// 有効なADVルートの中からスクリプト開始可能でリングコマンドがないものを取得
		/// </summary>
		public static List<AdvMaster> GetStartNonCommandMasterList(string locationLabel)
		{
			var masters = GetStartMasterList(locationLabel);

			var list = new List<AdvMaster>();
			foreach (var m in masters)
			{
				//有効になったら発生する条件がないもの、もしくは発生条件を満たしたものが対象
				if (m.startScript.Count <= 0 ||
					(CondUtil.IsCheckCond(m.selectStartCond, m.startScript) &&
					string.IsNullOrEmpty(m.searchCommandId)))
				{
					list.Add(m);
				}
			}

			return list;
		}

		/// <summary>
		/// 条件を満たしたランダムADVの発生を設定する
		/// </summary>
		public static void SetRandomAdvParam()
		{
			//var master = MasterData.GetInstance().advRandomOpenCondMaster.Values;
			//foreach (var m in master)
			//{
			//	//今行っている章とは違う物は無視して次へ
			//	if (m.chapter != AdvManager.Instance.CurrentChapter)
			//		continue;
			//	if (m.section != AdvManager.Instance.CurrentSection)
			//		continue;

			//	//登場条件がありつつ、条件を満たしていなげれば無視して次へ
			//	if (m.startCond.Count > 0 &&
			//		!CondUtil.IsCheckCond(m.startCondType, m.startCond))
			//		continue;

			//	var list = new List<string>();
			//	list.Add("SetRand_" + m.label);
			//	if (CondUtil.IsCheckCond(0, list))
			//		continue;

			//	//ランダム決定
			//	var max = m.openRatio.Sum();
			//	var value = UnityEngine.Random.Range(0, 100);
			//	var checkValue = 0;
			//	for (int i = 0;i < m.openRatio.Count;i++)
			//	{
			//		checkValue += m.openRatio[i];
			//		if (checkValue > 100)
			//		{
			//			UnityEngine.Debug.LogWarning("SetRandomAdvParam() ランダム確率比率が100を超えています！openRatioの設定が正しいか確認してください！");
			//		}

			//		if (value < checkValue)
			//		{
			//			ScenarioParameterUtil.SetParamValue(m.openCond[i], true);
			//			break;
			//		}
			//	}

			//	//ランダム生成を行ったことを記録
			//	ScenarioParameterUtil.SetParamValue(list[0], true);
			//}
		}

		/// <summary>
		/// 指定キャラクターのティーブレイクADVマスターを取得する
		/// </summary>
		public static AdvMaster GetTeabreakAdvMaster(int characterId)
		{
			var master = DataManager.Instance.Master.Adv.Values;
			foreach (var m in master)
			{
				//if (m.chapter != PlayerDataConstants.HOME_CHAPTER_NO)
				//	continue;
				var condName = "DataChara_" + characterId;
				if (!m.routeCond.Any(r => condName.Equals(r)))
					continue;

				return m;
			}
			return null;
		}

		/// <summary>
		/// 指定イベント開始ルート名リスト取得
		/// </summary>
		public static List<string> GetStartRouteNameList(AdvMaster advMaster)
		{
			var list = new List<string>();
			foreach (var startScript in advMaster.startScript)
			{
				if (!startScript.Contains("Route_"))
					continue;
				var split = startScript.Split('_');
				if (split.Length <= 2)
					continue;
				list.Add(split[2]);
			}
			return list;
		}

		// -----------------------------------------------------------------------------------------------------------------------------------
		// 条件判定
		// -----------------------------------------------------------------------------------------------------------------------------------

		/// <summary>
		/// 非共存かどうか
		/// </summary>
		/// <param name="masters">ADVマスターリスト</param>
		/// <param name="absentRoute">非共存IDリスト</param>
		/// <returns></returns>
		static bool IsCheckAbsent(List<AdvMaster> masters, List<int> absentRoute)
		{
			if (absentRoute.Count == 0)
				return false;

			foreach (var m in masters)
			{
				int absent = 0;
				absent = absentRoute.Find(a => a == m.id);

				if (absent > 0)
					return true;
			}
			return false;
		}

		/// <summary>
		/// 同キャラ優先度判定
		/// </summary>
		/// <param name="charaId">キャラクターID</param>
		/// <param name="priority">優先度</param>
		/// <returns></returns>
		static bool IsPriority(ref List<AdvMaster> masters, string charaId, int priority)
		{
			//キャラ不在の場合はtrue
			if (charaId == null)
				return true;

			if (priority == 0)
				return true;

			var list = new List<AdvMaster>();
			foreach (var m in masters)
			{
				if (m.miniCharacterId == charaId)
				{
					list.Add(m);
				}
			}

			if (list.Count <= 0)
				return true;

			var sort = list.OrderBy(m => m.priority);
			var first = sort.FirstOrDefault();
			//優先度が高ければtrue
			if (priority > first.priority)
			{
				//登録していた前の優先マスターを削除
				masters.Remove(first);
				return true;
			}

			return false;
		}

		/// <summary>
		/// 消滅条件を満たしている番号取得 0:満たしていない　1～:満たしている条件番号
		/// </summary>
		public static int GetExitNo(AdvMaster m)
		{
			if (m.exitRoute.Count > 0 && CondUtil.IsCheckCond(m.selectExitRoute, m.exitRoute))
			{
				return 1;
			}
			if (m.exitRouteB.Count > 0 && CondUtil.IsCheckCond(m.selectExitRouteB, m.exitRouteB))
			{
				return 2;
			}
			return 0;
		}

		/// <summary>
		/// 消滅しおわったものか
		/// </summary>
		/// <param name="m"></param>
		/// <returns></returns>
		public static bool IsExitEnd(AdvMaster m)
		{
			//var playerData = UserData.GetPlayerData();

			//まだ消滅条件を満たしていない
			var exitNo = GetExitNo(m);
			if (exitNo == 0)
				return false;

			//消滅演出があるのに、まだ演出を見ていないならば消滅していない
			if ((exitNo == 1 && m.exitEffect != 0) ||
				(exitNo == 2 && m.exitEffectB != 0))
			{
                //if (!IsExitEffectOnData(m))
                //    return false;
            }
			return true;
		}

		/// <summary>
		/// ADVで部屋が指定されていて、その部屋に立ち寄ってADVが開始される状態になっているか
		/// </summary>
		public static bool IsRoomStartAdv(AdvMaster m)
		{
			if (string.IsNullOrEmpty(m.entryRoom))
				return false;
			if (!m.startScript.Contains(m.entryRoom))
				return false;
			if (!ScenarioParameterUtil.IsParamValue(m.entryRoom))
				return false;
			return true;
		}

        //public static bool IsAppearsEffectOnData(AdvMaster m)
        //{
        //    if (MapManager.GetNowPlayingConductType() == MapConstants.MAP_CONDUCT_TYPE.HOME)
        //    {
        //        var requestQuestId = AdvMasterDataContext.GetRequestQuestId(m.id);
        //        return RequestQuest.RequestQuestDataManager.GetExistRequestQuestMapEnemyStatus(requestQuestId) >= RequestQuestConstants.MapEnemyStatus.InEffectEnd;
        //    }
        //    else
        //    {
        //        return DataManager.Instance.Local.Story.AdvAppearList.Any(a => a.Equals(m.routeName));
        //    }
        //}

        //public static bool IsExitEffectOnData(AdvMaster m)
        //{
        //    if (MapManager.GetNowPlayingConductType() == MapConstants.MAP_CONDUCT_TYPE.HOME)
        //    {
        //        var requestQuestId = AdvMasterDataContext.GetRequestQuestId(m.id);
        //        return RequestQuest.RequestQuestDataManager.GetExistRequestQuestMapEnemyStatus(requestQuestId) >= RequestQuestConstants.MapEnemyStatus.OutEffectEnd;
        //    }
        //    else
        //    {
        //        return DataManager.Instance.Local.Story.AdvExitList.Any(a => a.Equals(m.routeName));
        //    }
        //}
    }
}
