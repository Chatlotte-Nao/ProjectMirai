﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using LCX.User;
using Takasho;
using Takasho.Utility;

public static class ClientEventUtil
{
    public static ClientEvent ClientGameStart(long action_id)
    {
        ClientEvent res = new ClientEvent();

     
        res.payload.Add("event_name", "client_game_start");
        res.event_id = "client_game_start";
        res.a_tar.Add("event_id", 100010);
        res.a_tar.Add("action_id", action_id);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body",res.body);

        return res;
    }
    public static ClientEvent ClientMoviePlay(string movie_name, int state)
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_movie_play");
        res.event_id = "client_movie_play";
        res.a_tar.Add("event_id", 100020);
        res.a_tar.Add("movie_name", movie_name);
        res.a_tar.Add("state", state);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);
        return res;
    }
    public static ClientEvent ClientLandInto()
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_land_into");
        res.event_id = "client_land_into";
        res.a_tar.Add("event_id", 100030);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);
        return res;
    }
    public static ClientEvent ClientSDKReg(int state)
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_sdk_reg");
        res.event_id = "client_sdk_reg";
        res.a_tar.Add("event_id", 100040);
        res.a_tar.Add("state", state);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);
        return res;
    }
    public static ClientEvent ClientSDKLogin(int state)
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_sdk_login");
        res.event_id = "client_sdk_login";
        res.a_tar.Add("event_id", 100050);
        res.a_tar.Add("state", state);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);



        return res;
    }

    public static ClientEvent ClientUpdateAfterSDK(long action_id,float pack, int state)
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_update_aftersdk");
        res.event_id = "client_update_aftersdk";
        res.a_tar.Add("event_id", 100060);
        res.a_tar.Add("action_id", action_id);
        res.a_tar.Add("pack", pack);
        res.a_tar.Add("state", state);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);



        return res;
    }
    public static ClientEvent ClientGameLoading(long action_id, int state)
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_game_loading");
        res.event_id = "client_game_loading";
        res.a_tar.Add("event_id", 100090);
        res.a_tar.Add("action_id", action_id);
        res.a_tar.Add("state", state);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);


        return res;
    }
    public static ClientEvent ClientRoleCreate( int state, string fail_reason)
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_role_create");
        res.event_id = "client_role_create";
        res.a_tar.Add("event_id", 100100);
        res.a_tar.Add("state", state);
        res.a_tar.Add("fail_reason", fail_reason);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);


        return res;
    }
    public static ClientEvent ClientRoleLogin(int state, string fail_reason)
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_role_login");
        res.event_id = "client_role_login";
        res.a_tar.Add("event_id", 100110);
        res.a_tar.Add("state", state);
        res.a_tar.Add("fail_reason", fail_reason);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);


        return res;
    }
    public static ClientEvent ServerRoleGuide( long guide_id,long action_id,int state)
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_role_guide");
        res.event_id = "client_role_guide";
        res.a_tar.Add("event_id", 100120);
        res.a_tar.Add("guide_id", guide_id);
        res.a_tar.Add("action_id", action_id);
        res.a_tar.Add("state", state);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);



        return res;
    }
    public static ClientEvent ClientHallInto()
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_hall_into");
        res.event_id = "client_hall_into";
        res.a_tar.Add("event_id", 100130);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);


        return res;
    }
    public static ClientEvent ClientRoleLogout( long scene_id,int state)
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_role_logout");
        res.event_id = "client_role_logout";
        res.a_tar.Add("event_id", 100140);
        res.a_tar.Add("scene_id", scene_id);
        res.a_tar.Add("state", state);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);



        return res;
    }

    public static ClientEvent ClientPageArrive(long leave_page_id,long arrive_page_id, int state)
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_page_arrive");
        res.event_id = "client_page_arrive";
        res.a_tar.Add("event_id", 900002);
        res.a_tar.Add("leave_page_id", leave_page_id);
        res.a_tar.Add("arrive_page_id", arrive_page_id);
        res.a_tar.Add("state", state);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);




        return res;
    }
    public static ClientEvent ClientButtonClick(string button_type, long button_id,string button_name ,int state)
    {
        ClientEvent res = new ClientEvent();
        res.payload.Add("event_name", "client_button_click");
        res.event_id = "client_button_click";
        res.a_tar.Add("event_id", 900003);
        res.a_tar.Add("button_type", button_type);
        res.a_tar.Add("button_id", button_id);
        res.a_tar.Add("button_name", button_name);
        res.a_tar.Add("state", state);
        res.body.Add("a_tar", res.a_tar);
        res.body.Add("a_rst", res.a_rst);
        res.payload.Add("body", res.body);



        return res;
    }


    public static InGameUserInfo ClientGameUserInfo(string eventStr)
    {
        string eventName = eventStr;
        string roleId = DataManager.Instance.Player.Player.GetData().PlayerId;
        string roleName =DataManager.Instance.Player.Player.GetData().Name;
        long roleLevel =  DataManager.Instance.Player.Player.GetLevel();
        long createRoleTime = GlobalTime.Now.ToUnixTimeSeconds();
        string zoneId = DataManager.Instance.Local.UserInfo.currentServer.id;
        string zoneName = DataManager.Instance.Local.UserInfo.currentServer.serverName;
        string partyName = "";
        int vip = 0;
        long balance = 0;
        RoleInfo roleInfo = new RoleInfo(roleId, roleName, (int)roleLevel, createRoleTime, zoneId, zoneName, partyName, (int)vip, (int)balance);
        InGameUserInfo inGameUserInfo = new InGameUserInfo(eventName, roleInfo);
        return inGameUserInfo;
    }

}
public class ClientEvent
{
    public Dictionary<string, object> payload = new Dictionary<string, object>();
    public Dictionary<string, object> role_info = new Dictionary<string, object>();
    public Dictionary<string, object> extra_info = new Dictionary<string, object>();
    public Dictionary<string, object> body = new Dictionary<string, object>();
    public Dictionary<string, object> a_tar = new Dictionary<string, object>();
    public Dictionary<string, object> a_rst = new Dictionary<string, object>();
    public string category = "Takasho";
    public string event_id = "";
    public ClientEvent()
    {
        payload.Add("log_store", "client");
       

        if(LCXHandler.Instance.Authorized)
        {
            payload.Add("session_id", LCXHandler.Instance.LcxUser.SignInSessionId + "-" + GlobalTime.Now.ToUnixTimeMilliseconds());
            payload.Add("log_id", System.Guid.NewGuid() + "-" + GlobalTime.Now.ToUnixTimeMilliseconds());
            payload.Add("app_id", 15002002);
            payload.Add("lcx_id", LCXHandler.Instance.LcxUser.LCXUserId);
            if (TakashoHandler.Instance.ApiClientService.IsLoggedIn && DataManager.Instance.Player.Player.GetData()!=null)
            {
                if(DataManager.Instance.Local.UserInfo.currentServer!= null)
                    role_info.Add("role_key", DataManager.Instance.Local.UserInfo.currentServer.id + "#" + DataManager.Instance.Player.Player.GetData().PlayerId);
                else
                    role_info.Add("role_key","");

                role_info.Add("role_id", DataManager.Instance.Player.Player.GetData().PlayerId);
                role_info.Add("level", DataManager.Instance.Player.Player.GetLevel());
            }
            payload.Add("role_info", role_info);
            payload.Add("extra_info", extra_info);
            payload.Add("event_time", GlobalTime.Now.ToUnixTimeMilliseconds());
            


        }
        else
        {
            payload.Add("session_id", "");
            payload.Add("log_id", System.Guid.NewGuid() + "-" + GlobalTime.Now.ToUnixTimeMilliseconds());
            payload.Add("app_id", 15002002);
            payload.Add("lcx_id", "");
            payload.Add("role_info", role_info);
            payload.Add("extra_info", extra_info);
            payload.Add("event_time", GlobalTime.Now.ToUnixTimeMilliseconds());
            
         
        }

      
        
       
    }
}
