﻿
using System.Collections.Generic;

namespace Game.Util
{
	/// <summary>
	/// 条件チェック
	/// </summary>
	public class CondUtil
	{

		/// <summary>
		/// 条件判定
		/// </summary>
		/// <param name="select">条件タイプ 0:AND 1:OR</param>
		/// <param name="Cond">条件フラグリスト</param>
		/// <returns></returns>
		public static bool IsCheckCond(int select, List<string> Cond)
		{
			//条件がなければfalse
			if (Cond.Count == 0) return false;

			bool isAnd = select == 0 ? true : false;

			if (isAnd)//AND条件
			{
				foreach (var c in Cond)
				{
					if (!ScenarioParameterUtil.IsParamValue(c))
					{
						return false;
					}
				}
				return true;
			}
			else//OR条件
			{
				foreach (var c in Cond)
				{
					if (ScenarioParameterUtil.IsParamValue(c))
					{
						return true;
					}
				}
				return false;
			}
		}
	}
}
