
using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine.Rendering;
public static class UndergroundUtil
{
    public static bool IsLock(List<string> lockCondition,out string content )
    {
        content = "";
        bool isLock = false;
        foreach (var condition in lockCondition)
        {
            var str= condition.Split(':');
            switch (int.Parse(str[0]))
            {
                case 1:
                    if (DataManager.Instance.Player.Player.GetLevel() < int.Parse(str[1]))
                    {
                        content = string.Format(
                            LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Level_Format"),int.Parse(str[1]));
                        isLock = true;
                    }
                    break;
                case 6:
                    if (DataManager.Instance.Player.Chapter.TryGet(int.Parse(str[1])) == null)
                    {
                        var chapterName =
                            LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{int.Parse(str[1])}_name");
                        int chapterNum = DataManager.Instance.Master.Chapter[int.Parse(str[1])].chapter;
                        content = string.Format(
                            LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Stage_Format"),
                            chapterNum, chapterName);
                        isLock = true;
                    }
                    break;
                case 201:
                    if (!DataManager.Instance.Player.underground.IsOpenedEvent(int.Parse(str[1])))
                    {
                        var data = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.UNDERGROUND,
                            $"Event_Content_{long.Parse(str[1])}");
                        content = string.Format(
                            LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.UNDERGROUND,
                                "Underground_Chapter_UnLock"), data);
                        isLock = true;
                    }

                    break;
            }
        }
        return isLock;
    }
}
