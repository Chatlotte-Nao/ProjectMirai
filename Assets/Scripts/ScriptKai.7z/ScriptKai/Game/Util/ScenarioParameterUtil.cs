using Base.Util;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;

/// <summary>
/// シナリオなどで設定されるパラメーター
/// これの有り/無しでADVイベント発生等を判定する
/// </summary>
public static class ScenarioParameterUtil
{
    public static string PARAM_TENSION_BONUS_EFFECT_END = "TensionBonusEffectEnd";
    /// <summary>
    /// 探索状態を示すパラメーター
    /// 1：部屋探索状態
    /// 2：人物に話しかけた状態
    /// 3：アイテムを調べた状態
    /// </summary>
    public static string PARAM_SEARCH_STATE = "SearchState";
    /// <summary>探索コマンドを示すパラメーター</summary>
    public static string PARAM_SEARCH_COMMAND = "SearchCommand";
    /// <summary>達成状態が残ったままになっているデータを参照するパラメーター先頭</summary>
    public static string PARAM_START_REMAIN = "Remain_";
    /// <summary>タッチしたキャラを示すパラメーター</summary>
    public static string PARAM_TOUCH_CHARA = "TouchChara_";
    /*
    [keyの種類]
    ・バトルに勝った		・・・Win_[バトルステージNo]
    ・バトルに負けた		・・・Lose_[バトルステージNo]
    ・目標をクリアした		・・・goal_[ID]
                                ※GoalMessageMasterに設定されているもの
    ・ステージに入った		・・・Stage_[StageData.number]
    ・ADVを見た				・・・ScenarioScript.CommandAction.args[0]
        ※ScenarioMaster.xlsxに纏められていて、シナリオスクリプトから設定される
    ・指定ロケーションエリアにいる
                            ・・・Move_[LocationMasterのlabel]　※エリアに入っている間のみ値がある、エリアから出たら消える
    ・部屋にいる			・・・[ステージlabel]　　　 ※部屋に入っている間のみ値がある、部屋から出たら消える 
    ・指定ルートにいる		・・・Route_[フロアlabel]_[ルート名]
    ・指定シナリオを読んだ	・・・Read_[シナリオ名]
    ・指定チュートリアルを読んだ			・・・TutoRead_[チュートリアル Read ID]
    ・指定クエストのバトルマップクリア		・・・ClearBattleMap_[クエスト番号]
    ・指定クエストの指定難易度バトルマップクリア
                                            ・・・ClearBattleMap_[Normal/Hard/VeryHard/Extra/Bonus]_[クエスト番号]
    ・指定ランダムADV発生を行った			・・・SetRand_[ランダムADV条件Label]
    ・指定解放条件の解放演出を行った		・・・ReleaseMapAnim_[ReleaseMapMasterのフラグ]
    
    ※下記の物は取得時に特殊な処理をしているので、paramには存在しないが結果は取得できる([Remain_]の必要なし)
    ・アイテムを[個数]個持っている			・・・DataItem_[アイテムID]_[個数]
    ・キーワードを持っている				・・・DataKeyword_[キーワードID]
    ・アーカイブを見た						・・・DataArchive_[アーカイブID]
    ・キャラクターがいる					・・・DataChara_[キャラクターID]
    ・バトルキャラクターがいる				・・・DataBattleChara_[バトルキャラクターID]

    ・部屋に入った事がある					・・・HaveBeenRoom_[ステージlabel]
    ・プレイヤーランクが[値]以上			・・・PlayerRank_[値]
    ・キャラクターレベルが[値]以上			・・・DataCharaLv_[キャラクターID]_[値]
    ・バトルキャラクターレベルが[値]以上	・・・DataBattleCharaLv_[バトルキャラクターID]_[値]
    ・合計戦力値が[値]以上					・・・TotalForcesValue_[値]
    ・テンションが[値]以上					・・・DataTension_[値]
    ・キャラクターのテンション値が[値]以上	・・・DataBondValue_[キャラクターID]_[値]
    ・最後にプレイヤーが選択した部屋が[部屋ラベル]か	・・・DataLastRoom_[部屋ラベル]
    ・フェードしていない時か(フェードしていない時のみ動く)
                                            ・・・NonFade
    ・小話を停止させているか				・・・StopSmallStory
    ・ホーム画面のキャラ配置番号が[値]か	・・・DataHomeCharaSetting_[キャラクターID]_[値]
    ・指定バトルステージを１度でもクリアしているか
                                            ・・・ClearBattleStageOne_[クエストID]_[ステージNumber]
    ・指定ダンジョンをクリアしているか		・・・DungeonClear_[DungeonBaseMasterのID]
    ・指定イベントのボーナスルート条件を満たしているか
    　※イベントのボスを倒しているか。ただし、一度イベントルートをクリアしたら、再度ボスを倒すまで鍵が閉まる
                                            ・・・EventQuestBonusRoute_[クエストID]
    ・指定イベントの指定話を見ているか		・・・EventRead_[イベントID]_[指定話のセクション値]
    ・指定イベントの後半になっているか		・・・EventSecondHalf_[イベントID]
    ・指定イベント前半を[値]回以上クリア	・・・EventClearFirstHalf_[イベントID]_[値]
    ・指定イベント後半を[値]回以上クリア	・・・EventClearSecondHalf_[イベントID]_[値]
    ・指定時間を超えているか				・・・Time_[yyyy/MM/dd HH:mm:ss]
    ・指定お願いクエストが終了状態か		・・・RequestQuestEnd_[お願いクエストID]
    ・指定お願いクエストが時間切れ状態か	・・・RequestQuestTimeOver_[お願いクエストID]

    ・探索行動回数が[値]以上か				・・・SearchCommandCount_[値]
    ・[数値]/100の確率で発生				・・・RandStart_[数値]
        ※ToDo:現状は下記タイミングで確率決定
        ・画面遷移時
        ・移動開始時
        「実際の確率決定タイミング」
        「一度発生させたランダムイベントを見てる途中、中断復帰したらどうするか（100％また見れるのか、再抽選か）」は本開発時に決める
    ・[値]章がクリア状態になっている		・・・ClearScenarioChapter_[値]

    キャラクター：絆値を共有するキャラクター			バトルキャラクターデータの[キャラクターID]
    バトルキャラクター：個別でデータを持つキャラクター	バトルキャラクターデータの[ID]


    ※先頭に[Remain_]とつけると、「ストーリーが進んでも達成状態が残ったままになっているデータ」を見に行くようになります。
    　1回しか見られないイベントや、チャプター跨ぎする条件などに使用してください。
    */

    /// <summary>残り続けるパラメーター</summary>
    public static List<string> RemainParam
    {
        get
        {
            return DataManager.Instance.Local.Scenarios.RemainScenarioParam;
        }
    }

    /// <summary>1ストーリーでリセットされるパラメーター</summary>
    public static List<string> Param
    {
        get
        {
            return DataManager.Instance.Local.Scenarios.ScenarioParam;
        }
    }

    //プレイヤーデータから参照するものリスト
    static List<string> playerDataNameList = new List<string>
    {
        "DataItem_",
        "DataKeyword_",
        "DataArchive_",
        "DataChara_",
        "DataBattleChara_",
        "PlayerRank_",
        "DataCharaLv_",
        "DataBattleCharaLv_",
        "TotalForcesValue_",
        "DataTension_",
        "DataBondValue_",
        "DataLastRoom_",
        "RandStart_",
        "DataHomeCharaSetting_",
        "ClearBattleStageOne_",
        "DungeonClear_",
        "EventRead_",
        "EventQuestBonusRoute_",
        "EventSecondHalf_",
        "EventClearFirstHalf_",
        "EventClearSecondHalf_",
        "ClearBattleMap_Normal_",
        "ClearBattleMap_Hard_",
        "ClearBattleMap_VeryHard_",
        "ClearBattleMap_Extra_",
        "ClearBattleMap_Extra2_",
        "ClearBattleMap_Bonus_",
        "SearchCommandCount_",
        "TutoRead_",
        "ClearScenarioChapter_",
        "Time_",
        "RequestQuestEnd_",
        "RequestQuestTimeOver_",
    };

    //最後に個数が指定されているものリスト
    static List<string> lastNumList = new List<string>
    {
        "DataItem_",
        "PlayerRank_",
        "DataCharaLv_",
        "DataBattleCharaLv_",
        "TotalForcesValue_",
        "DataTension_",
        "DataBondValue_",
        "SearchCommandCount_",
    };

    /// <summary>
    /// 「指定のルートに来たら（Route_[フロアlabel]_[ルート名]）」という条件stringを取得する
    /// </summary>
    public static string GetRouteParamName(string routeName)
    {
        var map = MapSceneManager.Instance.CurrentScene;
        if (map == null)
            return string.Empty;
        var name = GetRouteParamName(map.GetNowMapLabel(), routeName);
        return name;
    }

    public static string GetRouteParamName(string mapLabel, string routeName)
    {
        var name = "Route_" + mapLabel + "_" + routeName;
        return name;
    }

    // -----------------------------------------------------------------------------------------------------------------------------------
    // パラメーターアクセサ
    // -----------------------------------------------------------------------------------------------------------------------------------
    public static int GetParamValue(string key)
    {
        //プレイヤーデータ参照物対応
        if (playerDataNameList.Any(name => key.Contains(name)))
        {
            var split = key.Split('_');
            if (split.Length < 2)
            {
                return 0;
            }
            var typeString = playerDataNameList.Where(name => key.Contains(name)).FirstOrDefault();

            //後ろに設定されているものが文字列の物のときの判別
            switch (typeString)
            {
                case "DataLastRoom_":
                    var name = DataManager.Instance.Local.Scenarios.lastSelectRoomName;
                    if (!string.IsNullOrEmpty(name) && name.Equals(split[1]))
                    {
                        return 1;
                    }
                    return 0;
                case "Time_":
                {
                    var endTime = System.DateTime.Parse(split[1]);
                    var nowTime = System.DateTime.Now;
                    return (nowTime >= endTime) ? 1 : 0;
                }
            }

            //後ろに設定されているものが数字のときの判別
            int id;
            if (key.Contains("ClearBattleMap_"))
            {
                if (!int.TryParse(split[2], out id))
                {
                    return 0;
                }
            }
            else
            {
                if (!int.TryParse(split[1], out id))
                {
                    return 0;
                }
            }
            switch (typeString)
            {
                case "DataItem_":
                    var num = DataManager.Instance.Player.Item.GetCount(id);
                    return (int)num;
                case "DataKeyword_":
                    return DataManager.Instance.Player.Keyword.TryGet(id) == null ? 1 : 0;
                //return Game.Data.UserData.GetPlayerData().getKeywordIdList.Any(i => i == id) ? 1: 0;
                //case "DataArchive_":
                //    return Game.Data.PlayerData.GetArchiveNum(id);
                case "DataChara_":
                    return DataManager.Instance.Player.Character.TryGet(id) != null ? 1 : 0;
                case "DataBattleChara_":
                    return DataManager.Instance.Player.Character.TryGet(id) != null ? 1 : 0;
                case "PlayerRank_":
                    return DataManager.Instance.Player.Player.GetLevel();
                case "DataCharaLv_":
                {
                    var c = DataManager.Instance.Player.Character.TryGet(id);
                    if (c != null)
                    {
                        var m = CharacterUtil.BuildViewModel(c, DataManager.Instance.Player.Equipment.GetList(), DataManager.Instance.Player.Player.GetLevel());
                        return m.level;
                    }
                    return 0;
                }
                case "DataBattleCharaLv_":
                {
                    var c = DataManager.Instance.Player.Character.TryGet(id);
                    if (c != null)
                    {
                        var m = CharacterUtil.BuildViewModel(c, DataManager.Instance.Player.Equipment.GetList(), DataManager.Instance.Player.Player.GetLevel());
                        return m.level;
                    }
                    return 0;
                }
                case "TotalForcesValue_":
                    return 0;
                case "DataTension_":
                    return 0;
                case "DataBondValue_":
                {
                    return (int)DataManager.Instance.Player.Bond.Get(id);
                }
                case "RandStart_":
                {
                    //id部分の値を「出る確率の値」として扱う
                    //ランダム値は事前にSetRandValue()を呼んで生成しておく
                    if (id < DataManager.Instance.Local.Scenarios.RandValue)
                    {
                        return 1;
                    }
                    return 0;
                }
                case "DataHomeCharaSetting_":
                {
                    return 0;
                }
                case "ClearBattleStageOne_":
                {
                    return 0;
                }
                case "DungeonClear_":
                {
                    return 0;
                }
                case "EventRead_":
                {
                    return 0;
                }
                case "EventQuestBonusRoute_":
                {
                    return 0;
                }
                case "EventSecondHalf_":
                {
                    return 0;
                }
                case "EventClearFirstHalf_":
                {
                    return 0;
                }
                case "EventClearSecondHalf_":
                {
                    return 0;
                }
                case "ClearBattleMap_Normal_":
                {
                    return 0;
                }
                case "ClearBattleMap_Hard_":
                {
                    return 0;
                }
                case "ClearBattleMap_VeryHard_":
                {
                    return 0;
                }
                case "ClearBattleMap_Extra_":
                {
                    return 0;
                }
                case "ClearBattleMap_Extra2_":
                {
                    return 0;
                }
                case "ClearBattleMap_Bonus_":
                {
                    return 0;
                }
                case "SearchCommandCount_":
                {
                    return DataManager.Instance.Local.Scenarios.searchCount;
                }
                case "TutoRead_":
                {
                    if (id == 116 || id == 117)
                        return 0;
                    return 0;
                }
                case "ClearScenarioChapter_":
                {
                    var status = DataManager.Instance.Player.Chapter.Get(id);
                    return (status != null &&
                            status.Status == Takasho.Schema.Score.ResourceCn.Chapter.V1.Status.Clear) ? 1 : 0;
                }
                case "RequestQuestEnd_":
                {
                    return 0;
                }
                case "RequestQuestTimeOver_":
                {
                    return 0;
                }
            }
            return 0;
        }

        int remainValue = 0;
        if (key.StartsWith(PARAM_START_REMAIN))
        {
            key = key.Replace(PARAM_START_REMAIN, string.Empty);
            remainValue = GetParamValue(RemainParam, key);
        }
        var normalValue = GetParamValue(Param, key);
        var value = (normalValue < remainValue) ? remainValue : normalValue;
        return value;
    }

    static int GetParamValue(List<string> param, string key)
    {
        //特殊物対応
        //条件HaveBeenRoom_[ステージlabel]は、[ステージlabel]がパラメータのkeyに存在するかどうかで判定
        if (key.Contains("HaveBeenRoom_"))
        {
            var roomKey = key.Replace("HaveBeenRoom_", "");
            return param.Contains(roomKey) ? 1 : 0;
        }
        //条件[NonFade]はフェード状態を見る
        if (key.Equals("NonFade"))
        {
            //return (!CommonScene.IsFade()) ? 1: 0;
        }

        if (!param.Contains(key))
            return 0;
        else
            return 1;
    }

    public static bool IsParamValue(string key)
    {
        var getValue = GetParamValue(key);
        int value = 1;
        //個数が一番後ろに設定されているものは、最後の数値を判断値とする
        if (lastNumList.Any(name => key.Contains(name)))
        {
            var split = key.Split('_');
            if (split.Length <= 0)
                return false;
            if (!int.TryParse(split[split.Length - 1], out value))
            {
                Log.Warn("keyから個数の取得が出来ませんでした！　key:" + key);
                return false;
            }
        }
        return getValue >= value;
    }

    public static void SetParamValue(string key, int value)
    {
        if (string.IsNullOrEmpty(key))
            return;
        if (key == PARAM_SEARCH_STATE)
        {
            DataManager.Instance.Local.Scenarios.searchState = value;
            return;
        }

        if (key.StartsWith(PARAM_START_REMAIN, System.StringComparison.Ordinal))
        {
            key = key.Replace(PARAM_START_REMAIN, string.Empty, System.StringComparison.Ordinal);
        }

        if (playerDataNameList.Any(name => key.Contains(name)))
        {
            Log.Info(key + "の情報はPlayerDataから出しています。SetParamValue()で設定するものではありません。");
            return;
        }

        Log.Info("SetParamValue(" + key + ", " + value + ")");
        //			var setParam = (isFixedBase) ? SaveData.GetInstance().param : Param; 
        //var setParam = (isFixedBase) ? param : Param; 
        var setParam = Param;
        setParam.Add(key);
    }

    public static void SetParamValue(string key, bool b)
    {
        if (string.IsNullOrEmpty(key))
            return;

        if (key.StartsWith(PARAM_START_REMAIN))
        {
            key = key.Replace(PARAM_START_REMAIN, string.Empty);
        }

        if (playerDataNameList.Any(name => key.Contains(name)))
        {
            Log.Warn(key + "の情報はPlayerDataから出しています。SetParamValue()で設定するものではありません。");
            return;
        }

        Log.Info("SetParamValue(" + key + ", " + b + ")");
        //			var setParam = (isFixedBase) ? SaveData.GetInstance().param : Param; 
        var setParam = Param;
        if (b)
        {
            if (!setParam.Contains(key))
                setParam.Add(key);
        }
        else
        {
            setParam.Remove(key);
        }
    }

    public static string GetTouchChara()
    {
        if (!Param.Any(p => p.StartsWith(PARAM_TOUCH_CHARA)))
        {
            return string.Empty;
        }
        var param = Param.Where(p => p.StartsWith(PARAM_TOUCH_CHARA)).FirstOrDefault();
        var name = param.Replace(PARAM_TOUCH_CHARA, "");
        return name;
    }

    /// <summary>
    /// 「居残り続けるシナリオパラメータ」をアップデートし、現在のシナリオパラメータを反映する
    /// </summary>
    public static void UpdateRemainData()
    {
        var builder = new System.Text.StringBuilder();
        builder.Append("下記の物がRemain保存されました。");
        foreach (var oneParam in Param)
        {
            if (RemainParam.Contains(oneParam))
            {
                continue;
            }
            RemainParam.Add(oneParam);
            builder.Append("\nkey:" + oneParam);
        }
    }

    /// <summary>
    /// 「ルート上に居る」というパラメータをリセット
    /// </summary>
    public static void ResetRouteParamValue()
    {
        var param = Param;
        var list = param.Where(p => p.StartsWith("Route_")).ToList();
        foreach (var p in list)
        {
            SetParamValue(p, false);
        }
        list = param.Where(p => p.StartsWith("advRoom")).ToList();
        foreach (var p in list)
        {
            SetParamValue(p, false);
        }
    }

    /// <summary>
    /// 「キャラをタッチした」というパラメータをリセット
    /// </summary>
    public static void ResetCharaTouch()
    {
        var param = Param;
        var list = param.Where(p => p.StartsWith(PARAM_TOUCH_CHARA)).ToList();
        foreach (var p in list)
        {
            SetParamValue(p, false);
        }
    }

    /// <summary>
    /// ランダム値抽選
    /// </summary>
    public static void SetRandValue()
    {
        DataManager.Instance.Local.Scenarios.RandValue = UnityEngine.Random.Range(0, 100);
    }
}
