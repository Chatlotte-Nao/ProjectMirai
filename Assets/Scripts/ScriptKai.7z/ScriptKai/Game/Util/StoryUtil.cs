﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Linq;

public static class StoryUtil
{

    public static bool IsUnlocked(int chaptermasterId)
    {
        var master = DataManager.Instance.Master.Chapter[chaptermasterId];

        if (master.preId == 0) return true;

        var data = DataManager.Instance.Player.Chapter.TryGet(master.preId);
        if (data == null) return false;
        if (data.Status == Takasho.Schema.Score.ResourceCn.Chapter.V1.Status.Clear) return true;



        return false;
    }

    public static ChapterStatusViewModel BuildChapterViewModel(int chapter)
    {
        ChapterStatusViewModel model = new ChapterStatusViewModel();
        model.chapter = chapter;
        model.isNew = true;
        model.isClear = true;
        model.isComplete = true;
        model.isLocked = true;
        model.sectionStatus = new Dictionary<int, SectionStatusViewModel>();

        var masters = DataManager.Instance.Master.Chapter.Values.Where(x => x.chapter == chapter).OrderBy(a=>a.section);
        int total = 0;
        int current = 0;
        model.requireLevel = 9999;
        foreach (var sectionMaster in masters)
        {
            var sectionModel = BuildSectionViewModel(sectionMaster.id);

            model.sectionStatus.Add(sectionMaster.id, sectionModel);

            total += sectionModel.totalRewardNum;
            current += sectionModel.currentRewardNum;

            if (!sectionModel.isClear) model.isClear = false;
            if (!sectionModel.isComplete) model.isComplete = false;
            if (!sectionModel.isNew && !sectionModel.isLocked) model.isNew = false;
            if (!sectionModel.isLocked ) model.isLocked = false;

            if (sectionMaster.requirePlayerLevel < model.requireLevel) model.requireLevel = sectionMaster.requirePlayerLevel;
        }
        
        model.totalRewardNum = total;
        model.currentRewardNum = current;

        return model;
    }

    public static SectionStatusViewModel BuildSectionViewModel(int chapterMasterId)
    {
        var master = DataManager.Instance.Master.Chapter[chapterMasterId];

        SectionStatusViewModel model = new SectionStatusViewModel();
        model.masterId = chapterMasterId;
        model.chapter = master.chapter;
        model.section = master.section;

        var advRewards = DataManager.Instance.Master.AdvReward.Values.Where(x => x.chapter == master.chapter && x.section == master.section);
        model.totalRewardNum = advRewards.Count();

        if (master.sectionType == 3)
        {
            //dungeon
            var chests = DataManager.Instance.Master.BattleZoneChests.Values.Where(x => x.battleZoneMasterId == master.battleZoneId);
            model.totalRewardNum += chests.Count();
            if (DataManager.Instance.Master.BattleZone[master.battleZoneId].hasStarRewards)
            {
                model.totalStarRewardNum = 3;
            }
        }

        

        var data = DataManager.Instance.Player.Chapter.TryGet(master.id);
        if (data == null)
        {
            model.currentRewardNum = 0;
            model.isClear = false;
            model.isComplete = false;
            if (IsUnlocked(chapterMasterId))
            {
                model.isNew = true;

                if (master.requirePlayerLevel > DataManager.Instance.Player.Player.GetLevel() )
                {
                    model.isLocked = true;
                }
                else
                {
                    model.isLocked = false;
                }

            }
            else
            {
                model.isNew = false;
                model.isLocked = true;
            }
        }
        else
        {
            model.isNew = false;
            model.isLocked = false;
            foreach (var r in advRewards)
            {
                if (data.Flags.Contains(r.flag)) model.currentRewardNum++;
            }

            if (master.sectionType == 3)
            {
                //dungeon
                var battlezoneData = DataManager.Instance.Player.BattleZone.TryGet(master.battleZoneId);
                if (battlezoneData != null)
                {
                    model.currentRewardNum += battlezoneData.BattleZoneChests.Count;
                    if (DataManager.Instance.Master.BattleZone[master.battleZoneId].hasStarRewards)
                    {
                        if (battlezoneData.StageOneUpdateTime > 0) model.currentStarRewardNum++;
                        if (battlezoneData.StageTwoUpdateTime > 0) model.currentStarRewardNum++;
                        if (battlezoneData.StageThreeUpdateTime > 0) model.currentStarRewardNum++;
                    }
                }
            }

            if (data.Status == Takasho.Schema.Score.ResourceCn.Chapter.V1.Status.Clear)
            {
                model.isClear = true;
                model.isComplete = (model.currentRewardNum == model.totalRewardNum && model.totalStarRewardNum == model.currentStarRewardNum);
            }
            else
            {
                model.isClear = false;
                model.isComplete = false;
            }
        }

        return model;
    }

    public static bool IsClear(int chapterMasterId)
    {
        var data = DataManager.Instance.Player.Chapter.TryGet(chapterMasterId);
        if (data == null)
        {
            return false;
        }

        if (data.Status == Takasho.Schema.Score.ResourceCn.Chapter.V1.Status.Clear)
        {
            return true;
        }

        return false;
    }

    public static bool IsHaveReward(int chapterId)
    {
        var items = DataManager.Instance.Master.ChapterUnlockMaster[chapterId].item;
        foreach (var item in items)
        {
            var s = item.Split(':');
            var itemId = long.Parse(s[0]);
            var needNum = long.Parse(s[1]);
            long cur = DataManager.Instance.Player.Item.GetCount(itemId);
            if (cur < needNum)
                return false;
        }
        return true;
    }
}

public class ChapterStatusViewModel
{
    public int chapter;
    public bool isNew;
    public bool isClear;
    public bool isComplete;
    public bool isLocked;
    public int requireLevel;

    public int totalRewardNum;
    public int currentRewardNum;

    public Dictionary<int, SectionStatusViewModel> sectionStatus = null;
}

public class SectionStatusViewModel
{
    public int masterId;
    public int chapter;
    public int section;
    public bool isNew;
    public bool isClear;
    public bool isComplete;
    public bool isLocked;
    public int totalRewardNum;
    public int currentRewardNum;
    public int totalStarRewardNum;
    public int currentStarRewardNum;
}

public class BattleResultInfo
{
    public class RewardItem
    {
        public long id { get; private set; }
        public long count { get; private set; }
        public bool isFirst { get; private set; }

        public RewardItem()
        {

        }

        public RewardItem(long id, long count, bool isFirst)
        {
            this.id = id;
            this.count = count;
            this.isFirst = isFirst;
        }
    }

    public bool first = false;
    public bool playerLevelUp = false;
    public bool[] starStatus = { false, false, false};
    public List<RewardItem> rewards = new List<RewardItem>();
}