﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Map
{
	/// <summary>
	/// マップ外部からマップに渡す各種設定
	/// </summary>
	public class MapContext
	{
		static MapContext instance = null;
		/// <summary>ダンジョンを開始する</summary>
		public bool IsPlayDungeon = false;
		/// <summary>ストーリーイベントバトルを開始する ※未使用</summary>
		public bool IsPlayStoryEventBattle = false;
		/// <summary>外側から開始時状態を設定する</summary>
		public bool IsOutsideStartSetting = false;

		/// <summary>UIを表示にする(UIを消しておきたいならfalseにする)</summary>
		public bool IsAbleUI = true;
		/// <summary>InitState（会話の設定やマップ移動受付前）で止める　trueの間ずっと止まるので、動かしたいタイミングで外部からfalseを入れる必要がある</summary>
		public bool IsWaitInitState = false;
		/// <summary>チュートリアルが開始可能か</summary>
		public bool CanStartTutorial = false;
		/// <summary>フェードイン処理が実行されたか</summary>
		public bool IsExecutedFadeIn = false;

		public string OutsideStartSettingSceneName{ get; private set; }
		public string OutsideStartSettingRouteName{ get; private set; }

		public int SelectRequestQuestId { get; private set; }

		public static MapContext GetInstance()
		{
			if (instance == null)	instance	= new MapContext();
			return instance;
		}

		/// <summary>
		/// 外部からマップ開始時の状態を設定する
		/// </summary>
		public void SetOutsideStartSetting(string sceneName, string routeName)
		{
			IsOutsideStartSetting = true;
			OutsideStartSettingSceneName = sceneName;
			OutsideStartSettingRouteName = routeName;
		}

		/// <summary>
		/// 外部（お願いクエスト選択画面）から、指定お願いクエストを選択してマップに移動したことを設定
		/// </summary>
		public void SetSelectRequestQuestId(int requestQuestId)
		{
			SelectRequestQuestId = requestQuestId;
		}

		public void Clear()
		{
			IsPlayDungeon = false;
			IsPlayStoryEventBattle = false;
			IsOutsideStartSetting = false;
			IsAbleUI = true;
			IsWaitInitState = false;
			OutsideStartSettingSceneName = string.Empty;
			OutsideStartSettingRouteName = string.Empty;
			SelectRequestQuestId = 0;
		}
	}
}
