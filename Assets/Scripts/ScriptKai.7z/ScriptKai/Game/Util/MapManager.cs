﻿using Base.Util;

using Game.Ui;
using ScenarioSelect;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;


namespace Map
{
	/// <summary>
	/// マップ総合管理処理　ADVマップなのかダンジョンマップなのかなどもここで設定
	/// </summary>
	public class MapManager : MonoBehaviour
	{

		static MapManager	instance	= null;


		//ここに遷移する際に押されたデバックボタン
		public static string testButtonName = null;

		static int testAwakeChapter = 0;
		static int testAwakeSection = 0;

		/// <summary>現在表示中のマップ</summary>
		BaseMapScene	currentMap;

		//MapMenuScene	scene;

		public static void SetTextAwakeChapterSection(int chapter, int section)
		{
			testAwakeChapter = chapter;
			testAwakeSection = section;
		}

		/// <summary>
		/// 対象ステージのBattleContext設定
		/// </summary>
		/// <param name="master">対象ステージマスター</param>
		/// <returns>固定バトルキャラクターを設定したか</returns>
		//public static bool SetStageBattleContext(AreaStageMaster master)
		//{
		//	return false;
		//}

		/// <summary>
		/// 今実際に動いているマップ挙動を取得する
		/// </summary>
		public static MapConstants.MAP_CONDUCT_TYPE GetNowPlayingConductType()
		{
			if (instance == null)
				return MapConstants.MAP_CONDUCT_TYPE.NONE;
			if (Map.MapContext.GetInstance().IsPlayDungeon)
				return MapConstants.MAP_CONDUCT_TYPE.DUNGEON;
			//if (UserData.GetPlayerData().chapter == PlayerDataConstants.HOME_CHAPTER_NO)
				//return MapConstants.MAP_CONDUCT_TYPE.HOME;
			return MapConstants.MAP_CONDUCT_TYPE.BASE;
		}

		/// <summary>今行っているセクションの種類を取得(MapConstants)</summary>
		public static int GetNowSectionType()
		{
			if (Map.MapContext.GetInstance().IsPlayStoryEventBattle)
			{
				return MapConstants.SECTION_STORY_EVENT_BATTLE;
			}

			if (GetNowPlayingConductType() == MapConstants.MAP_CONDUCT_TYPE.DUNGEON)
			{
				return MapConstants.SECTION_DUNGEON;
			}
			return 0;
		}

		void Awake()
		{
			if (instance != null)	return;
			instance	= this;
			//scene	= GetComponent<MapMenuScene>();
			//Todo:Half-α　ここに来るときに押されたデバックボタンに応じて処理内容
			
		}


		public static void ChangeMap(string sceneName)
		{
		}


		public static MapManager GetInstance()
		{
			return instance;
		}



		/// <summary>
		/// マップ移動制御を無効にしてからスクリプトを実行します。
		///		※SetTapGuardはここを抜けた時点ではtrueのままになります。その後マップタッチさせたいときはSetTapGuard(false);を呼んでください
		/// </summary>
		/// <param name="name">スクリプト名</param>
		/// <param name="onFinish">終了時処理</param>
		public static void StartScript(string name, string label, Action<string> onFinish = null)
		{
		}

		/// <summary>
		/// 表示中マップの取得
		/// </summary>
		/// <returns></returns>
		public static BaseMapScene GetCurrentMap()
		{
			if (instance == null)	return null;
			return instance.currentMap;
		}

		/// <summary>
		/// 表示中ADVマップの取得
		/// </summary>
		/// <returns></returns>
		//public static BaseAdvMapScene GetCurrentAdvMap()
		//{
		//	if (instance == null)	return null;
		//	return instance.currentMap.GetComponent<BaseAdvMapScene>();
		//}
		//public static BaseDungeonMapScene GetCurrentDungeonMap()
		//{
		//	if (instance == null)	return null;
		//	return instance.currentMap.GetComponent<BaseDungeonMapScene>();
		//}


		//public static MapMenuScene GetScene()
		//{
		//	if (instance == null)	return null;
		//	return instance.scene;
		//}


		/// <summary>
		/// マップ画面の表示、非表示を切り替えます。
		/// </summary>
		/// <param name="b">表示する場合は true、非表示の場合は false</param>
		public static void SetVisibleMap(bool b)
		{
		}

		/// <summary>
		/// マップに関連するユーザーデータをリセット
		/// </summary>
		public static void ResetMapUserData()
		{
		}

		/// <summary>
		/// このマップで使用されているカメラコントローラーを取得
		/// </summary>
		/// <returns></returns>
		public static CameraController GetCameraController()
		{
			CameraController cameraController = null;
			return cameraController;
		}

	}
}
