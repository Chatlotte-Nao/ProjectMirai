using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Takasho.Schema.Score.ResourceCn.Explore.V1;
using System.Linq;

public static class ExploreUtil
{
    public static ExploreViewModel BuildViewModelFromData()
    {
        ExploreViewModel result = new ExploreViewModel();

        var eventList = DataManager.Instance.Player.Explore.GetData().Events;

        result.eventList = new Dictionary<long, ExploreEventViewModel>();

        foreach (var item in eventList)
        {
            var e = BuildEventViewModel(item);
            result.eventList.Add(e.masterId, e);
        }

        var freeEventList = DataManager.Instance.Player.Explore.GetData().FreeExplores;

        result.freeEventList = new Dictionary<long, ExploreFreeEventViewModel>();

        foreach (var item in freeEventList)
        {
            var e = BuildFreeEventViewModel(item);
            result.freeEventList.Add(e.masterId, e);
        }

        return result;
    }

    public static ExploreEventViewModel BuildEventViewModel(PlayerExploreEvent item)
    {
        var e = new ExploreEventViewModel();

        e.triggerType = ExploreEventViewModel.EventTriggerType.Normal;
        e.masterId = item.ExploreEventMasterId;

        e.eventStatus = (ExploreEventViewModel.EventStatus)item.Status;
        e.eventType = (ExploreEventViewModel.EventType)e.Master.eventType;

        e.finishedHistory = new List<int>();
        foreach (var adv in item.UnlockedExploreAdvMasterIdsHistory)
        {
            e.finishedHistory.Add((int)adv);
        }

        e.finishCount = (int)item.TotalFinishedCount;
        e.fav = item.Liked;

        e.finishedAdv = new List<int>();
        e.flags = new List<string>();
        e.remainTime = e.Master.totalClock;

        bool isFinished = false;
        e.complete = false;
        foreach (var adv in item.UnlockedExploreAdvMasterIds)
        {
            e.finishedAdv.Add((int)adv);
            e.remainTime -= DataManager.Instance.Master.ExploreAdv[(int)adv].clockCost;
            if (DataManager.Instance.Master.ExploreAdv[(int)adv].sectionEnd > 0)
            {
                isFinished = true;
                e.complete = true;
            }
        }
        foreach (var f in item.Flags)
        {
            e.flags.Add(f);
        }
        if (e.remainTime <= 0)
        {
            isFinished = true;
        }

        if (isFinished && e.eventStatus == ExploreEventViewModel.EventStatus.Accepted)
        {
            e.eventStatus = ExploreEventViewModel.EventStatus.Finished;
        }

        return e;
    }

    public static ExploreFreeEventViewModel BuildFreeEventViewModel(PlayerExploreFreeExplore item)
    {
        var e = new ExploreFreeEventViewModel();

        e.masterId = item.ExploreFreeExploreMasterId;
        e.objectId = item.ExploreObjectMasterId;
        e.positionId = item.ExplorePointMasterId;

        e.eventType = (ExploreEventViewModel.EventType)e.Master.eventType;

        return e;
    }

}

public class ExploreViewModel
{
    public Dictionary<long, ExploreEventViewModel> eventList;
    public Dictionary<long, ExploreFreeEventViewModel> freeEventList;
}


public class ExploreEventViewModel
{
    public enum EventTriggerType
    {
        Normal,
        Daily
    }
    public EventTriggerType triggerType;
    public long masterId;
    public int finishCount;
    public List<int> finishedAdv;
    public List<int> finishedHistory;
    public List<string> flags;
    public int remainTime;
    public bool complete;
    public bool fav;

    public enum EventType
    {
        Invite = 1,
        PsvInvite = 2,
        Request = 3,
        Item = 4,
        Puzzle = 5,
        Enemy = 6,
        Other,
    }

    public EventType eventType;

    public enum EventStatus
    {
        Unavailable = 0,
        Pending = 1,
        Accepted = 2,
        Finished = 3,
    }

    public EventStatus eventStatus;

    public ExploreEventMaster Master => DataManager.Instance.Master.ExploreEvent[masterId];

    public bool CanStart()
    {
        foreach (var item in Master.startCondition)
        {
            var s = item.Split(':');
            int type = int.Parse(s[0]);

            switch (type)
            {
                case 3:
                    // 完成{0}{1}次
                    var explore = DataManager.Instance.Local.Explore.playerData.eventList.Values
                        .FirstOrDefault(a => a.masterId == long.Parse(s[1]));
                    if (explore == null || explore.finishCount == 0)
                    {
                        return false;
                    }

                    break;
                case 6:
                // 完成主线关卡{0}
                    if (!StoryUtil.IsClear(int.Parse(s[1])))
                    {
                        // conditionText[i].SetColor(Color.red);
                        return false;
                    }
                    break;
                default:
                    break;
            }
        }

        return true;
    }

}

public class ExploreFreeEventViewModel
{
    public ExploreFreeExploreMaster Master => DataManager.Instance.Master.ExploreDailyEvent[masterId];
    public long masterId;
    public string uniqueId;
    public long characterId;
    public long objectId;
    public long positionId;

    public ExploreEventViewModel.EventType eventType;
}