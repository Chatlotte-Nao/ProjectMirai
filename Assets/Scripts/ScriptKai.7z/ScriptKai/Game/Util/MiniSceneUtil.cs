﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Takasho.Schema.Score.ResourceCn.Player.V1;
using System.Linq;

public static class MiniSceneUtil
{
    public static UIMiniSceneViewModel BuildViewModel(IList<ProfileDeck> deck)
    {
        UIMiniSceneViewModel model = new UIMiniSceneViewModel();
        model.characters = new Dictionary<int, UIMiniSceneViewModel.UIMiniSceneCharacterModel>();
        for (int i = 0; i < deck.Count; i++)
        {
            var d = deck[i];
            if (d.BattleCharacterMasterId > 0)
            {
                var c = new UIMiniSceneViewModel.UIMiniSceneCharacterModel();
                c.id = d.BattleCharacterMasterId;
                c.dir = d.Direction;
                c.action = d.ActionId;

                model.characters.Add(i, c);
            }
        }

        return model;
    }

    public static void ChangeCharacter(UIMiniSceneViewModel model, int slot, long characterId)
    {
        UIMiniSceneViewModel.UIMiniSceneCharacterModel oldChara = null; // 本来在这个位置的角色
        UIMiniSceneViewModel.UIMiniSceneCharacterModel newChara = null; // 要被交换到这个位置的角色
        int oldSlot = -1; // 要被交换到这个位置的角色原来所在的位置

        if (model.characters.ContainsKey(slot))
        {
            oldChara = model.characters[slot];
        }
        foreach (var kp in model.characters)
        {
            if (kp.Value.id == characterId)
            {
                oldSlot = kp.Key;
                newChara = kp.Value;
                break;
            }
        }

        if (oldChara == newChara && oldChara != null) return;

        if (newChara != null)
        {
            model.characters[slot] = newChara;
            if (oldChara != null)
            {
                model.characters[oldSlot] = oldChara;
            }
            else
            {
                model.characters.Remove(oldSlot);
            }
        }
        else
        {
            if (oldChara == null)
            {
                model.characters.Add(slot, new UIMiniSceneViewModel.UIMiniSceneCharacterModel());
                model.characters[slot].dir = 0;
                model.characters[slot].action = 0;
            }
            model.characters[slot].id = characterId;
        }

    }
}
