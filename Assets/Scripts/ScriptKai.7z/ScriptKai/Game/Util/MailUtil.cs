﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Base.Util;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Mail.V1;
using UnityEngine;

public static class MailUtil
{
 
    public static  MailStatusViewModel BuildMailStatusViewModel(PlayerMail playerMail)
    {
        var model = new MailStatusViewModel();
        model.mailId = playerMail.MailId;
        model.title = playerMail.Title;
        model.senderType = playerMail.SenderType;
        model.sender = playerMail.Sender;
        model.createdTime = playerMail.CreatedAt;
        model.lifeTimeEndAt = playerMail.LifeTimeEndAt;

        model.textContent = playerMail.TextContent;
        model.rewards = playerMail.Rewards.ToList();
        model.openState = playerMail.ReadAt > 0
            ? MailStatusViewModel.MailOpenState.Read
            : MailStatusViewModel.MailOpenState.Unread;
        model.rewardState = playerMail.RewardsReceivedAt > 0
            ? MailStatusViewModel.MailRewardState.Received
            : MailStatusViewModel.MailRewardState.NotClaimed;

        model.contentTypes = new List<MailStatusViewModel.MailContentType>();
        if (playerMail.FunctionLink != string.Empty)
        {
            model.functionLink = playerMail.FunctionLink;
            model.contentTypes.Add(MailStatusViewModel.MailContentType.FunctionLink);
        }

        if (playerMail.ExternalUrl != string.Empty)
        {
            model.webLink = playerMail.ExternalUrl;
            model.contentTypes.Add(MailStatusViewModel.MailContentType.WebLink);
            model.webStr = playerMail.ExternalUrlDesc;
        }

        if (playerMail.ImageUrl != string.Empty)
        {
            model.imagePath = playerMail.ImageUrl;
            model.contentTypes.Add(MailStatusViewModel.MailContentType.Image);
        }

        return model;
    }
   
    public static List<string> GetAllRewards(List<MailStatusViewModel> mailModels)
    {
        var allRewards = new List<string>();
        foreach (var mailModel in mailModels)
        {
            if (mailModel.rewards.Count>0 && mailModel.rewardState == MailStatusViewModel.MailRewardState.NotClaimed)
            {
                allRewards.AddRange(mailModel.rewards);
            }
        }
        return allRewards;
    }

    public static long GetExpirationTime(long times,out int timeType)
    {
        //Debug.Log(GlobalTime.UtcNow);
        var expTime = GlobalTime.GetDateTime(times);
        var remain = expTime - GlobalTime.Now.DateTime;
        if (remain.TotalDays > 1)
        {
            timeType = 1;
            return (long)remain.TotalDays;
        }else if (remain.TotalHours > 1)
        {
            timeType = 2;
            return (long)remain.TotalHours;
        }else if (remain.TotalMinutes > 1)
        {
            timeType = 3;
            return (long)remain.TotalMinutes;
        }
        else 
        {
            timeType = 4;
            return (long)remain.Seconds;
        }
    }
}

public class MailStatusViewModel
{
    public string mailId;
    public string title;
    public SenderType senderType;
    public string sender;
    public long createdTime;
    public long lifeTimeEndAt;
    public MailOpenState openState;
    public MailRewardState rewardState;
    public List<MailContentType> contentTypes = null;
    public string textContent = string.Empty;
    public string functionLink= string.Empty;
    public string webLink= string.Empty;
    public string imagePath= string.Empty;
    public List<string> rewards = null;
    public string webStr= string.Empty;
    public enum MailOpenState
    {
        Unread = 1,
        Read = 2
    }

    public enum MailRewardState
    {
        NotClaimed = 1,
        Received = 2,
    }

    public enum MailContentType
    {
        FunctionLink = 1,
        WebLink = 2,
        Image = 3
    }
}
