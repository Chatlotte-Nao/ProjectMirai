﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UIDebugStoryPanel : UIBehaviourComponent
{
    [SerializeField] UIButton unlockBtn;
    [SerializeField] UIButton skipBtn;

    [Space]
    [SerializeField] UIButton undergroundUnlockBtn;
    [SerializeField] InputField undergroundChapterId;
    [SerializeField] UIButton undergroundBtn;
    [SerializeField] InputField undergroundEventId;

#if BUILD_DEBUG || UNITY_EDITOR

    // Start is called before the first frame update
    void Start()
    {
        unlockBtn.OnTouchUpInside.SubscribeAsync(OnClickUnlock).AddTo(mSubscriptions);
        skipBtn.OnTouchUpInside.SubscribeAsync(onClickSkip).AddTo(mSubscriptions);
        undergroundBtn.OnTouchUpInside.SubscribeAsync(OnClickUnderground).AddTo(mSubscriptions);
        undergroundUnlockBtn.OnTouchUpInside.SubscribeAsync(OnClickUndergroundUnlock).AddTo(mSubscriptions);
    }
    

    private async UniTask OnClickUnlock()
    {
        
        
       // await StoryService.FinishAllChapter();
       
        // var chapterList = new List<ChapterMaster>(DataManager.Instance.Master.Chapter.Values);
        // foreach (var master in chapterList)
        // {
        //     if (master.chapter == 0) continue;
        //     var data = DataManager.Instance.Player.Chapter.TryGet(master.id);
        //     if (data != null && data.Status == Takasho.Schema.Score.ResourceCn.Chapter.V1.Status.Clear) continue;
        //
        //     await StoryService.StartSection(master.chapter, master.section);
        //     
        //     await StoryService.FinishSection(master.chapter, master.section);
        //     
        // }
        
        
        
        var request = new Takasho.Schema.Score.PlayerApi.ScoreDebugFinishAllChapterV1.Types.Request()
        {
            PlayerId=TakashoHandler.Instance.PlayerId,
        };
    
        var op = ApiEndpoints.FinishAllChapter.Instance.CreateOperation(request);
        
        await TakashoHandler.Instance.ExecuteOperationAsync(op);
        
        DataManager.Instance.Player.UpdateCommon(op.Response.Common, op.RespondTimestamp);
        
        
        
        
        
        
        
        
        
        
        
        
        UI.Popup.ShowPopMessage("解锁完成");
    }

    async UniTask onClickSkip()
    {
        if (Game.ScriptEngine.ScriptEngine.GetInstance().IsRunning())
            await Game.ScriptEngine.ScriptEngine.GetInstance().SkipToEnd();

    }
    
    private async UniTask OnClickUnderground()
    {
        if (!DataManager.Instance.Master.UndergroundEventMaster.ContainsKey(int.Parse(undergroundEventId.text)))
        {
            await UI.Popup.ShowPopupMessageAsync("请输入正确的eventID");
            return;
        }

        var request = new Takasho.Schema.Score.PlayerApi.ScoreDebugFinishUndergroundEventV1.Types.Request();
        request.UndergroundEventMasterId = int.Parse(undergroundEventId.text);
    
        var op = ApiEndpoints.DebugFinishUndergroundEvent.Instance.CreateOperation(request);
        
        await TakashoHandler.Instance.ExecuteOperationAsync(op);
        DataManager.Instance.Player.underground.OnUpdateStored(op.Response.Event);
    }
    private async UniTask OnClickUndergroundUnlock()
    {
        if (!DataManager.Instance.Master.UndergroundChapterMaster.ContainsKey(int.Parse(undergroundChapterId.text)))
        {
            await UI.Popup.ShowPopupMessageAsync("请输入正确的charpterID");
            return;
        }

        var request = new Takasho.Schema.Score.PlayerApi.ScoreDebugUnlockChapterV1.Types.Request();
        request.UndergroundChapterMasterId = int.Parse(undergroundChapterId.text);

        var op = ApiEndpoints.DebugUnlockUndergroundChapter.Instance.CreateOperation(request);
        await TakashoHandler.Instance.ExecuteOperationAsync(op);
        DataManager.Instance.Player.underground.OnUpdateStored(op.Response.Chapter);
    }
    
    
#endif
}
