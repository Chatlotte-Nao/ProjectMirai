﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UIDebugItemPanel : UIBehaviourComponent
{
    [SerializeField] InputField charaId;
    [SerializeField] Button charaProcess;
    [SerializeField] InputField equipId;
    [SerializeField] InputField equipNum;
    [SerializeField] Button equipProcess;
    [SerializeField] InputField itemId;
    [SerializeField] InputField itemNum;
    [SerializeField] Button itemProcess;
    [SerializeField] Button itemCost;
    [SerializeField] InputField AchievementString;
    [SerializeField] Button AchievementProcess;
    [SerializeField] InputField serviceShutdownCountdownTime;
    [SerializeField] Button serviceShutdownCountdownButton;

#if UNITY_EDITOR || BUILD_DEBUG


    // Start is called before the first frame update
    void Start()
    {
        charaProcess.onClick.GuardSubscribeAsync(processChara).AddTo(mSubscriptions);
        equipProcess.onClick.GuardSubscribeAsync(processEquip).AddTo(mSubscriptions);
        itemProcess.onClick.GuardSubscribeAsync(processItem).AddTo(mSubscriptions);
        itemCost.onClick.GuardSubscribeAsync(costItem).AddTo(mSubscriptions);

        AchievementProcess.onClick.GuardSubscribeAsync(ProcessAchievement).AddTo(mSubscriptions);

        serviceShutdownCountdownButton.onClick.GuardSubscribeAsync(ProcessServiceTimedown).AddTo(mSubscriptions);
    }

    private async UniTask ProcessAchievement()
    {
        //List<long> getAllAchievements = new List<long>();
        //if (AchievementString.text != "")
        //{
        //    for (int i = 0; i < AchievementString.text.Split(';').Length; i++)
        //    {
        //        getAllAchievements.Add(long.Parse(AchievementString.text.Split(';')[i]));
        //    }
        //}
        Dictionary<string, int> dic = new Dictionary<string, int>() { { "asdadad", 1 } };
        await UI.Popup.ShowAchievementPopup(dic);

        //await DataManager.Instance.Player.Mission.ETLAchievement(getAllAchievements);
        
    }

    private async UniTask ProcessServiceTimedown()
    {
        UI.Popup.ShowServiceShutdownCountdownPopup(long.Parse(serviceShutdownCountdownTime.text));
    }


    private async UniTask processChara()
    {
        if (long.TryParse(charaId.text, out var id))
        {
            await process(id, 1);
        }
    }

    private async UniTask processEquip()
    {
        if (long.TryParse(equipId.text, out var id))
        {
            int num = 1;
            int.TryParse(equipNum.text, out num);
            await process(id, num);
        }
    }

    private async UniTask processItem()
    {
        if (long.TryParse(itemId.text, out var id))
        {
            int num = 1;
            int.TryParse(itemNum.text, out num);
            await process(id, num);
        }
    }

    private async UniTask process(long id, int num)
    {
        var request = new Takasho.Schema.Score.PlayerApi.ScoreDebugGiveItemV1.Types.Request();
        request.Items.Add(new Takasho.Schema.Score.PlayerApi.ScoreDebugGiveItemV1.Types.Request.Types.Item()
        {
            ContentMasterId = id,
            Count = num
        });


        var op = ApiEndpoints.DebugCompensate.Instance.CreateOperation(request);
        await TakashoHandler.Instance.ExecuteOperationAsync(op);

        DataManager.Instance.Player.UpdateCommon(op.Response.Common, op.RespondTimestamp);
    }

    private async UniTask costItem()
    {
        if (long.TryParse(itemId.text, out var id))
        {
            int num = 1;
            int.TryParse(itemNum.text, out num);
            await processCost(id, num);
        }
    }

    private async UniTask processCost(long id, int num)
    {
        var request = new Takasho.Schema.Score.PlayerApi.ScoreDebugConsumeContentV1.Types.Request();
        request.Items.Add(new Takasho.Schema.Score.PlayerApi.ScoreDebugConsumeContentV1.Types.Request.Types.Item()
        {
            ContentMasterId = id,
            Count = num
        });


        var op = ApiEndpoints.DebugCostItem.Instance.CreateOperation(request);
        await TakashoHandler.Instance.ExecuteOperationAsync(op);

        DataManager.Instance.Player.UpdateCommon(op.Response.Common, op.RespondTimestamp);
    }


#endif

}
