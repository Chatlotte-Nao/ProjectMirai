﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UIDebugMenuDialog : UIDialogBase
{
    [SerializeField] UIButton srdebugButton;
    [SerializeField] UIButton rebootButton;

    [SerializeField] Toggle[] toggles;
    [SerializeField] GameObject[] panels;


    public UnityEngine.UI.Image _backIamge;

#if BUILD_DEBUG || UNITY_EDITOR
    // Start is called before the first frame update
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        //rebootButton.OnTouchUpInside.GuardSubscribeAsync(OnClickReboot).AddTo(mSubscriptions);
        //srdebugButton.OnTouchUpInside.GuardSubscribeAsync(OnClickSRDebug).AddTo(mSubscriptions);
        for (int i = 0; i < toggles.Length; i++)
        {
            var idx = i;
            toggles[i].onValueChanged.Subscribe((v)=>
            {
                panels[idx].SetActive(v);
            });
        }
        panels[0].SetActive(true);
    }

    public void OnClickSRDebug()
    {
        SRDebug.Instance.ShowDebugPanel(!SRDebug.Instance.IsDebugPanelVisible);
    }

    public void OnClickReboot()
    {
         GameSceneManager.Instance.ChangeSceneAsync<TitleScene>("TitleScene");
    }


    public void SRDebugB()
    {
        SRDebug.Instance.ShowDebugPanel(!SRDebug.Instance.IsDebugPanelVisible);
        gameObject.SetActive(false);
    }


    public void OnClickQuit()
    {
        gameObject.SetActive(false);
    }


    public void ForceQuitFade()
    {
        Debug.Log("强制解除黑屏");
        UI.ScreenEffect.ForceClear();
    }

    public void OnSpeedStory(bool val)
    {
        DebugState.canSpeedStory = val;
    }

    public void OnDebugLogPop(bool val)
    {
        DebugState.canDebugLog = val;
    }

#endif
}
