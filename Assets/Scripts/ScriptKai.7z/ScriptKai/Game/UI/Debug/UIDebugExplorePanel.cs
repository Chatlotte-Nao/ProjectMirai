﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using System;
using Game.ScriptEngine;

public class UIDebugExplorePanel : UIBehaviourComponent
{
    [SerializeField] Button Enter;
    [SerializeField] UIButton resetButton;
    [SerializeField] InputField eventId;
    [SerializeField] UIButton updateButton;
    [SerializeField] InputField scenarioId;
    [SerializeField] UIButton scenarioButton;
    [SerializeField] InputField mapId;
    [SerializeField] UIButton jumpMapButton;
    [SerializeField] InputField minigameId;
    [SerializeField] UIButton startMinigameButton;
    [SerializeField] UIButton memoryStorageRoom;

    [SerializeField] UIButton TinyGame;
    [SerializeField] UIButton TinyGame2;
    [SerializeField] UIButton TinyGame4;
    [SerializeField] UIButton TinyGame5;
    [SerializeField] UIButton TinyGame6;
    [SerializeField] UIButton TinyGame7;
    [SerializeField] UIButton TinyGame8;
    [SerializeField] UIButton TinyGame9;
    [SerializeField] UIButton TinyGame10;
    [SerializeField] UIButton TinyGame11;
    [SerializeField] UIButton TinyGame12;

    [SerializeField] UIButton Dungeon_Channel_01;
    [SerializeField] UIButton Dungeon_Channel_02;


#if UNITY_EDITOR || BUILD_DEBUG
    private void Start()
    {
        Enter.onClick.GuardSubscribeAsync(EnterExplore).AddTo(mSubscriptions);

        resetButton.OnTouchUpInside.GuardSubscribeAsync(doDebugReset).AddTo(mSubscriptions);
        updateButton.OnTouchUpInside.GuardSubscribeAsync(doDebugUpdate).AddTo(mSubscriptions);
        scenarioButton.OnTouchUpInside.GuardSubscribeAsync(playScenario).AddTo(mSubscriptions);
        jumpMapButton.OnTouchUpInside.GuardSubscribeAsync(jumpMap).AddTo(mSubscriptions);
        startMinigameButton.OnTouchUpInside.GuardSubscribeAsync(startMinigame).AddTo(mSubscriptions);
        // memoryStorageRoom.OnTouchUpInside.GuardSubscribeAsync(openMemoryStorageRoom).AddTo(mSubscriptions);


        TinyGame.OnTouchUpInside.GuardSubscribeAsync(EnterTinyGame).AddTo(mSubscriptions);
        TinyGame2.OnTouchUpInside.GuardSubscribeAsync(EnterTinyGame2).AddTo(mSubscriptions);
        TinyGame4.OnTouchUpInside.GuardSubscribeAsync(EnterTinyGame4).AddTo(mSubscriptions);
        TinyGame5.OnTouchUpInside.GuardSubscribeAsync(EnterTinyGame5).AddTo(mSubscriptions);
        TinyGame6.OnTouchUpInside.GuardSubscribeAsync(EnterTinyGame6).AddTo(mSubscriptions);
        TinyGame7.OnTouchUpInside.GuardSubscribeAsync(EnterTinyGame7).AddTo(mSubscriptions);
        TinyGame8.OnTouchUpInside.GuardSubscribeAsync(EnterTinyGame8).AddTo(mSubscriptions);
        TinyGame9.OnTouchUpInside.GuardSubscribeAsync(EnterTinyGame9).AddTo(mSubscriptions);
        TinyGame10.OnTouchUpInside.GuardSubscribeAsync(EnterTinyGame10).AddTo(mSubscriptions);
        TinyGame11.OnTouchUpInside.GuardSubscribeAsync(EnterTinyGame11).AddTo(mSubscriptions);
        TinyGame12.OnTouchUpInside.GuardSubscribeAsync(EnterTinyGame12).AddTo(mSubscriptions);

        Dungeon_Channel_01.OnTouchDown.GuardSubscribeAsync(EnterDungeon_Channel).AddTo(mSubscriptions);
    }

    async UniTask EnterDungeon_Channel()
    {
        Log.Warn("EnterDungeon_Channel");
        await MapSceneManager.Instance.ShowAsync("chapter_01/Dungeon_Channel_01", null, null, MapSceneManager.SceneType.Dungeon);
    }

    async UniTask EnterTinyGame()
    {
        var pushUpDialog = await UI.Dialog.CreateAndShowAsync(UIPrefabId.UIPushUpMainWindow, CanvasType.App0) as UIPushUpMainWindow;
    }

    async UniTask EnterTinyGame2()
    {
        var fishingDialog = await UI.Dialog.CreateAndShowAsync(UIPrefabId.UIFishingMainWindow, CanvasType.App0) as UIFishingMainWindow;
    }
    async UniTask EnterTinyGame4()
    {
        var rhythmDialog = await UI.Dialog.CreateAndShowAsync(UIPrefabId.UIRhythmMainWindow, CanvasType.App0) as UIRhythmMainWindow;

        await rhythmDialog.Setup(40001);
    }
    async UniTask EnterTinyGame5()
    {
        var circuitDialog = await UI.Dialog.CreateAndShowAsync(UIPrefabId.UICircuitMainWindow, CanvasType.App0) as UICircuitMainWindow;
        int wa = 40001;
        try
        {
            string str = TinyGame5.transform.GetChild(0).GetComponent<InputField>().text;
            wa = Convert.ToInt32(str);
        }
        catch
        {

        }
        await circuitDialog.Setup(wa);

    }
    async UniTask EnterTinyGame6()
    {

        var slidingDialog = await UI.Dialog.CreateAndShowAsync(UIPrefabId.UISlidingMainWindow, CanvasType.App0) as UISlidingMainWindow;
        int wa = 60001;
        //try
        //{
        //    string str = TinyGame6.transform.GetChild(0).GetComponent<InputField>().text;
        //    wa = Convert.ToInt32(str);
        //}
        //catch
        //{

        //}
        await slidingDialog.Setup(wa);
    }
    async UniTask EnterTinyGame7()
    {
        var fruitcutDialog = await UI.Dialog.CreateAndShowAsync(UIPrefabId.UIFruitCutMainWindow, CanvasType.App0) as UIFruitCutMainWindow;
        int wa = 70001;
        //try
        //{
        //    string str = TinyGame7.transform.GetChild(0).GetComponent<InputField>().text;
        //    wa = Convert.ToInt32(str);
        //}
        //catch
        //{

        //}
        await fruitcutDialog.Setup(wa);

    }
    async UniTask EnterTinyGame8()
    {
        Camera cam = GameObject.Find("Main Camera").GetComponent<Camera>();

        while (cam.orthographicSize > 2.6f)
        {
            float lerpnum = Mathf.Lerp(cam.orthographicSize, 2.6f, 0.5f);
            cam.orthographicSize = lerpnum;
            await UniTask.Delay(10);
        }

        var makeBreadDialog = await UI.Dialog.CreateAndShowAsync(UIPrefabId.UIMakeBreadMainWindow, CanvasType.App0) as UIMakeBreadMainWindow;
        int wa = 80001;
        //try
        //{
        //    string str = TinyGame7.transform.GetChild(0).GetComponent<InputField>().text;
        //    wa = Convert.ToInt32(str);
        //}
        //catch
        //{

        //}

        await makeBreadDialog.Setup(80001);

    }


    async UniTask EnterTinyGame9()
    {

        var catchDollDialog = await UI.Dialog.CreateAndShowAsync(UIPrefabId.UICatchDollMainWindow, CanvasType.App0) as UICatchDollMainWindow;
        int wa = 40001;
        //try
        //{
        //    string str = TinyGame6.transform.GetChild(0).GetComponent<InputField>().text;
        //    wa = Convert.ToInt32(str);
        //}
        //catch
        //{

        //}

        await catchDollDialog.Setup(wa);
    }
    async UniTask EnterTinyGame10()
    {
        UIOrganParam organParam = new UIOrganParam();
        organParam.onFinish = (b) =>
        {
            Debug.Log("Over");
        };
        await UI.Page.OpenPage<UIOrganPage>(organParam);

    }

    async UniTask EnterTinyGame11()
    {
        var resoningDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIReasoningMainWindow, CanvasType.App0) as UIReasoningMainWindow;
        int wa = 110001;
        try
        {
            string str = TinyGame11.transform.GetChild(0).GetComponent<InputField>().text;
            wa = Convert.ToInt32(str);
        }
        catch
        {

        }


        await resoningDialog.SetUpLines(wa);
        await resoningDialog.ShowAsync();
        resoningDialog.Setup(wa);

    }
    async UniTask EnterTinyGame12()
    {

        await UI.Page.OpenPage<UIBrewTeaPage>();

    }

    private async UniTask EnterExplore()
    {
        await ExploreService.RequestExploreData();
        GameSceneManager.Instance.ChangeScene<ExploreScene>("ExploreScene");
    }

    private async UniTask doDebugReset()
    {
        var request = new Takasho.Schema.Score.PlayerApi.ScoreDebugResetExploreV1.Types.Request();
        var op = ApiEndpoints.DebugExploreReset.Instance.CreateOperation(request);
        await TakashoHandler.Instance.ExecuteOperationAsync(op);

        await ExploreService.RequestExploreData();
    }

    private async UniTask doDebugUpdate()
    {
        var request = new Takasho.Schema.Score.PlayerApi.ScoreDebugAddExploreEventV1.Types.Request()
        {
            ExploreEventMasterId = long.Parse(eventId.text)
        };
        var op = ApiEndpoints.DebugExploreTriggerEvent.Instance.CreateOperation(request);
        await TakashoHandler.Instance.ExecuteOperationAsync(op);

        DataManager.Instance.Player.Explore.UpdateStored(op.Response.Profile, op.RespondTimestamp);
    }

    private async UniTask playScenario()
    {
        var scriptName = scenarioId.text;

        await UI.Page.OpenPage<UIAdvMainPage>();
        ScenarioScript script = await ResourceManager.Instance.LoadLocalizeAssetAsync<ScenarioScript>("Scenario/" + scriptName);

        ScriptEngine.GetInstance().LoadScript(scriptName, script);
        ScriptEngine.GetInstance().SetStartScript(scriptName, null, null);
    }

    private async UniTask jumpMap()
    {
        var label = mapId.text;
        var master = DataManager.Instance.Master.Location[label];
        await MapSceneManager.Instance.ChangeAsync(master.scene, master.startPos);

    }

    private async UniTask startMinigame()
    {
        var gameId = int.Parse(minigameId.text);
        var master = DataManager.Instance.Master.PuzzleExplore[gameId];

        UITinyGameParam puzzleParam = new UITinyGameParam();
        puzzleParam.id = gameId;

        if (master.typeId == 12)
        {
            await UI.Page.OpenPage<UIExploreTracingPage>(puzzleParam);
        }

    }
    // private async UniTask openMemoryStorageRoom()
    // {
    //     await UI.Dialog.CreateAndShowAsync(UIPrefabId.UIMemoryStorageRoomDialog, CanvasType.App2);
    // }


#endif
}
