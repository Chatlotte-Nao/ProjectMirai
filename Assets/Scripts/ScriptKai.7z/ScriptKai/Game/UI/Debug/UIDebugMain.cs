﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System;
using System.Linq;
using UnityEngine.Events;
using UnityEngine.UI;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;
using LCX.Internal.Util.MiniJSON;


public class UIDebugMain : UIDialogBase
{
    [SerializeField] UIButton startBtn;
    [SerializeField] InputField serverUrlInput;

    [SerializeField] InputField mockModeUserName;
    [SerializeField] Toggle mockModeToggle;
    [SerializeField] public Toggle quickModeToggle;
    [Space] [SerializeField] private UIButton serverListBtn;
    [SerializeField] private GameObject serverListObj;
    [SerializeField] private List<UIButton> serverCell;
    Text mVersion;


#if BUILD_DEBUG
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        serverUrlInput.text = TakashoHandler.Instance.serverUrl;

        if (PlayerPrefs.HasKey("takasho_server"))
        {
            serverUrlInput.text = PlayerPrefs.GetString("takasho_server");
        }

        if (PlayerPrefs.HasKey("http_server"))
        {
            OutgameService.http_server = PlayerPrefs.GetString("http_server");
        }

        if (PlayerPrefs.HasKey("mock_username"))
        {
            mockModeUserName.text = PlayerPrefs.GetString("mock_username");
            mockModeToggle.isOn = true;
        }


        startBtn.OnTouchUpInside.GuardSubscribeAsync(OnClickStart).AddTo(mSubscriptions);
        mockModeToggle.onValueChanged.Subscribe(OnMockToggle).AddTo(mSubscriptions);
        mVersion = transform.Find("ver").GetComponent<Text>();
        mVersion.text = Application.productName + Application.version; //Application.identifier
        quickModeToggle.gameObject.SetActive(false);
        quickModeToggle.isOn = false;


        serverListBtn.OnTouchUpInside.Subscribe(OnClickServerList).AddTo(mSubscriptions);
        await loadServerListData();
#if TEST_BIRD
        serverListBtn.gameObject.SetActive(false);
        mockModeToggle.gameObject.SetActive(false);
        mockModeToggle.isOn = true;
        await SetServerUrl(serverCell[5].gameObject);
        serverUrlInput.interactable = false;
#endif
    }

    public override void OnShow()
    {
        base.OnShow();
        Log.Info("Show UIDebugMain");
    }

    #region 服务器列表

    private void OnClickServerList()
    {
        serverListObj.SetActive(true);
    }

    private async UniTask loadServerListData()
    {
        for (int i = 0; i < serverCell.Count; i++)
        {
            serverCell[i].onClick.GuardSubscribeAsync(SetServerUrl).AddTo(mSubscriptions);
        }
    }

    private async UniTask SetServerUrl(GameObject obj)
    {
        var texts = obj.transform.GetComponentsInChildren<Text>();
        serverUrlInput.text = texts[1].text;
        OutgameService.http_server = texts[2].text;
        serverListObj.SetActive(false);
    }

    #endregion

    private void OnMockToggle(bool val)
    {
        if (val)
        {
            if (string.IsNullOrEmpty(mockModeUserName.text))
            {
                mockModeUserName.text = SystemInfo.deviceUniqueIdentifier;
            }
        }
        else
        {
        }
    }

    public void OnQuickModeToggle(bool val)
    {
        DebugState.quickMode = val;
    }


    private async UniTask OnClickStart()
    {
        if (mockModeUserName.text == "webview")
        {
            var _webViewDialog =
                (UIWebViewDialog) await UI.Dialog.CreateAsync(UIPrefabId.UIWebAnnouncementDialog, CanvasType.System);

            // _webViewDialog.OnBack.Subscribe(_ =>
            // {
            //     _webViewDialog.Dispose();
            //     _webViewDialog = null;
            // });

            var platform = "";
#if UNITY_ANDROID
            platform = "android";
#elif UNITY_IOS
			platform = "ios";
#endif
            var affcode = LCXHandler.Instance.AffCode;
            var realmid = "0";

            var url = $"https://h5.mbgadev.cn/takt/notice/?platform={platform}&affcode={affcode}&realmid={realmid}";
            await _webViewDialog.SetupAsync(url);
            await _webViewDialog.ShowAsync();
            return;
        }

        if (serverUrlInput.text.Contains(" "))
        {
            UI.Popup.ShowPopMessage("服务器地址包含空格");
            return;
        }

        if (!string.IsNullOrEmpty(serverUrlInput.text))
        {
            //if (serverUrlInput.text != TakashoHandler.Instance.serverUrl)
            {
                PlayerPrefs.SetString("takasho_server", serverUrlInput.text);
                PlayerPrefs.SetString("http_server", OutgameService.http_server);
                PlayerPrefs.Save();
            }
            TakashoHandler.Instance.serverUrl = serverUrlInput.text;
        }
        else
        {
            PlayerPrefs.DeleteKey("takasho_server");
            PlayerPrefs.DeleteKey("http_server");
            PlayerPrefs.Save();
        }

        if (!string.IsNullOrEmpty(mockModeUserName.text) && mockModeToggle.isOn)
        {
            TakashoHandler.Instance.Account = mockModeUserName.text;
            TakashoHandler.Instance.MockLoginMode = true;
            PlayerPrefs.SetString("mock_username", mockModeUserName.text);
            PlayerPrefs.Save();
        }
        else
        {
            TakashoHandler.Instance.Account = string.Empty;
            TakashoHandler.Instance.MockLoginMode = false;
            PlayerPrefs.DeleteKey("mock_username");
            PlayerPrefs.Save();
        }

        ClientEvent clientEvent = ClientEventUtil.ClientGameStart(2);
        LCXHandler.Instance.ReportEvent(clientEvent.event_id, clientEvent.payload);

        await UI.Page.ChangePage<UITitlePage>();
    }

#endif
}