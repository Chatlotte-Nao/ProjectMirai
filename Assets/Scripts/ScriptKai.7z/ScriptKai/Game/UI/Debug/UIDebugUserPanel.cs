﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UIDebugUserPanel : UIBehaviourComponent
{
    [SerializeField] Text userId;
    [SerializeField] Text serverUrl;
    [SerializeField] UIButton copyBtn;
    [SerializeField] UIButton signoutBtn;
    [SerializeField] UIButton wechatShare;
    [SerializeField] InputField wechatShareInputField;
    [SerializeField] UIButton deleteUserBtn;

    [SerializeField] UIButton changeTimeBtn;
    [SerializeField] InputField[] timeInputs;


#if BUILD_DEBUG

    void Awake()
    {
        copyBtn.OnTouchUpInside.Subscribe(OnClickCopy).AddTo(mSubscriptions);
        signoutBtn.OnTouchUpInside.Subscribe(OnClickSignOut).AddTo(mSubscriptions);
        wechatShare.OnTouchUpInside.SubscribeAsync(OnClickWechatShare).AddTo(mSubscriptions);
        deleteUserBtn.OnTouchUpInside.SubscribeAsync(OnClickDeleteUser).AddTo(mSubscriptions);
        changeTimeBtn.OnTouchUpInside.Subscribe(OnClickChangeTime).AddTo(mSubscriptions);
    } 

    void OnEnable()
    {
        Setup();

        timeInputs[0].text = GlobalTime.Now.Year.ToString();
        timeInputs[1].text = GlobalTime.Now.Month.ToString();
        timeInputs[2].text = GlobalTime.Now.Day.ToString();
        timeInputs[3].text = GlobalTime.Now.Hour.ToString();
        timeInputs[4].text = GlobalTime.Now.Minute.ToString();
        timeInputs[5].text = GlobalTime.Now.Second.ToString();
    }


    void OnDisable()
    {
    }

    void Setup()
    {
        
       

        if (!LCXHandler.Instance.Authorized && !TakashoHandler.Instance.MockLoginMode)
        {
            userId.text	= "lcx にサインインしていません。";
            return;
        }

        if (string.IsNullOrEmpty(TakashoHandler.Instance.PlayerId) && TakashoHandler.Instance.MockLoginMode)
        {
            userId.text	= "mock mode: not login";
            return;
        }


        userId.text	= "id:" + TakashoHandler.Instance.PlayerId;

    }


    void OnClickCopy()
    {
        GUIUtility.systemCopyBuffer = TakashoHandler.Instance.PlayerId;
    }

    void OnClickSignOut()
    {
        if (!TakashoHandler.Instance.MockLoginMode)
            LCXHandler.Instance.SignOut();

    }
    
    async UniTask OnClickWechatShare()
    {
        var weChatShareDialog = (UIWeChatShareDialog) await UI.Dialog.CreateAndShowAsync(UIPrefabId.UIWeChatShareDialog, CanvasType.App2);
        await weChatShareDialog.SetUp(wechatShareInputField.text.ToString());
    }
    
    
    async UniTask OnClickDeleteUser()
    {
        if (!TakashoHandler.Instance.MockLoginMode)
            await LCXHandler.Instance.DeleteUserAsync();

        var path = System.IO.Path.Combine(TakashoHandler.Instance.GetCurrentDCPath(), "dc.bin");
		Debug.Log(path);
        if (System.IO.File.Exists(path))
        {
            System.IO.File.Delete(path);
			Debug.Log(path);
        }

        DataManager.Instance.Local.Clear();
    }

    void OnClickChangeTime()
    {
        var date = new System.DateTime(int.Parse(timeInputs[0].text), int.Parse(timeInputs[1].text), int.Parse(timeInputs[2].text), int.Parse(timeInputs[3].text), int.Parse(timeInputs[4].text), int.Parse(timeInputs[5].text));
        var offset = date - System.DateTime.Now;
        GlobalTime.SetOffset((long)offset.TotalSeconds);
    }

#endif
}
