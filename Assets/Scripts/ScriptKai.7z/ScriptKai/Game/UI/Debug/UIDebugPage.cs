﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIDebugPage : UIPageBase
{
    UIDebugMain mDebugMain = null;



    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        mDebugMain = await UI.Dialog.CreateAsync(UIPrefabId.UIDebugMainWindow, CanvasType.App0) as UIDebugMain;
        // mDebugMain = GameObject.Find("UIDebugMain").GetComponent<UIDebugMain>();
        await mDebugMain.ShowAsync();
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await mDebugMain.HideAsync(showType);
    }

    public override void Dispose()
    {
        if (mDebugMain != null)
        {
            mDebugMain.Dispose();
            mDebugMain = null;
        }
        base.Dispose();
    }
}
