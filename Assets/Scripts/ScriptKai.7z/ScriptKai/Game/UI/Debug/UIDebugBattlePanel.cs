﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using Battle;

public class UIDebugBattlePanel : UIBehaviourComponent
{
    [SerializeField] Button skipTurn;
    [SerializeField] Button skipRound;
    [SerializeField] Button win;
    [SerializeField] Button lose;
    [SerializeField] Dropdown clearCdDropdown;
    [SerializeField] Button clearCdSureBtn;
    [SerializeField] InputField energyInput;
    [SerializeField] Button energyBtn;
    [SerializeField] Toggle fullStarSwitch;
    [SerializeField] Dropdown timeScaleList;
    [SerializeField] Button timeScaleSureBtn;
    [SerializeField] Text curTimescale;
    #region 角色属性相关
    [SerializeField] Button characterEnterBtn;
    [SerializeField] Button characterBackBtn;
    [SerializeField] Button allEnemyBtn;
    [SerializeField] Button allPlayerBtn;
    [SerializeField] GameObject characterPanel;
    [SerializeField] Dropdown characterList1;
    [SerializeField] Dropdown characterList2;
    [SerializeField] Dropdown characterList3;
    [SerializeField] Dropdown characterList4;
    [SerializeField] UIDebugBattleWidget widget1;
    [SerializeField] UIDebugBattleWidget widget2;
    [SerializeField] UIDebugBattleWidget widget3;
    [SerializeField] UIDebugBattleWidget widget4;
    #endregion
    [SerializeField] Dropdown addHpDropdown;
    [SerializeField] Button addHpSureBtn;
    [SerializeField] InputField hpInput;

#if UNITY_EDITOR || BUILD_DEBUG

    void Start()
    {
        skipTurn.onClick.GuardSubscribeAsync(SkipTurn).AddTo(mSubscriptions);
        skipRound.onClick.GuardSubscribeAsync(SkipRound).AddTo(mSubscriptions);
        win.onClick.GuardSubscribeAsync(Win).AddTo(mSubscriptions);
        lose.onClick.GuardSubscribeAsync(Lose).AddTo(mSubscriptions);
        clearCdSureBtn.onClick.GuardSubscribeAsync(ClearCd).AddTo(mSubscriptions);
        energyBtn.onClick.GuardSubscribeAsync(AddEnergy).AddTo(mSubscriptions);
        fullStarSwitch.onValueChanged.GuardSubscribeAsync(SwitchFullStarTog).AddTo(mSubscriptions);
        timeScaleSureBtn.onClick.GuardSubscribeAsync(SetTimescale).AddTo(mSubscriptions);

        #region 角色属性相关
        characterEnterBtn.onClick.GuardSubscribeAsync(EnterCharacter).AddTo(mSubscriptions);
        characterBackBtn.onClick.GuardSubscribeAsync(BackCharacter).AddTo(mSubscriptions);
        allEnemyBtn.onClick.GuardSubscribeAsync(ShowAllEnemy).AddTo(mSubscriptions);
        allPlayerBtn.onClick.GuardSubscribeAsync(ShowAllPlayer).AddTo(mSubscriptions);
        characterList1.onValueChanged.GuardSubscribeAsync(OnCharacterList1Selected).AddTo(mSubscriptions);
        characterList2.onValueChanged.GuardSubscribeAsync(OnCharacterList2Selected).AddTo(mSubscriptions);
        characterList3.onValueChanged.GuardSubscribeAsync(OnCharacterList3Selected).AddTo(mSubscriptions);
        characterList4.onValueChanged.GuardSubscribeAsync(OnCharacterList4Selected).AddTo(mSubscriptions);
        #endregion

        addHpSureBtn.onClick.GuardSubscribeAsync(OnAddHpBtnClicked).AddTo(mSubscriptions);
    }

    private void OnEnable()
    {
        // 默认是否直接满足三星条件
        // fullStarSwitch.isOn = false;

        // 每次打开GMTool，更新显示出当前的Timescale
        curTimescale.text = "Cur Speed: " + Time.timeScale;

        // 角色详情相关
        characterPanel.SetActive(false);
    }

    private async UniTask SkipTurn()
    {
        SignalBus.GlobalSignal.Dispatch(UIEventId.CharacterCommandOnClickSkipTurn);
    }

    private async UniTask SkipRound()
    {
        // 暂时不做这个，不太重要，且会引起较多问题。
        SignalBus.GlobalSignal.Dispatch(UIEventId.DebugOnSkipCurRound);
    }

    private async UniTask Win()
    {
#if !UWA
        SignalBus.GlobalSignal.Dispatch(UIEventId.DebugOnWinCallback);
#endif
    }

    private async UniTask Lose()
    {
#if !UWA
        SignalBus.GlobalSignal.Dispatch(UIEventId.DebugOnLoseCallback);
#endif
    }

    private async UniTask ClearCd()
    {
        if (clearCdDropdown.value <= 0)
            return;
        SignalBus.GlobalSignal.Dispatch(UIEventId.DebugOnRemoveCDCallback, clearCdDropdown.value);
    }

    private async UniTask AddEnergy()
    {
        int defultNum = 0;
        if (string.IsNullOrEmpty(energyInput.text))
            return;
        if (!int.TryParse(energyInput.text, out defultNum))
            return;
        if (defultNum == 0)
            return;

        SignalBus.GlobalSignal.Dispatch(UIEventId.DebugOnAddConductorEnergy, defultNum);
    }

    private async UniTask SwitchFullStarTog(bool isTogOn)
    {
        SignalBus.GlobalSignal.Dispatch(UIEventId.DebugOnSwitchFullStarTog, isTogOn);
    }

    private async UniTask SetTimescale()
    {
        SignalBus.GlobalSignal.Dispatch(UIEventId.DebugOnSetTimescale, timeScaleList.value);
        curTimescale.text = "Cur Speed: " + Time.timeScale;
    }

    #region 角色属性相关
    private async UniTask EnterCharacter()
    {
        if (BattleMain.Instance == null)
            return;
        characterPanel.SetActive(true);
        await ShowAllPlayer();
    }
    private async UniTask BackCharacter()
    {
        if (!BattleMain.Instance.battleLogic.battleInfoCollector.isInBattle)
            return;
        characterPanel.SetActive(false);
    }

    private async UniTask ShowAllEnemy()
    {
        if (!BattleMain.Instance.battleLogic.battleInfoCollector.isInBattle)
            return;
        characterList1.value = 4;
        characterList2.value = 5;
        characterList3.value = 6;
        characterList4.value = 7;
    }

    private async UniTask ShowAllPlayer()
    {
        if (!BattleMain.Instance.battleLogic.battleInfoCollector.isInBattle)
            return;
        characterList1.value = 0;
        characterList2.value = 1;
        characterList3.value = 2;
        characterList4.value = 3;
    }

    private async UniTask OnCharacterList1Selected(int value)
    {
        if (!BattleMain.Instance.battleLogic.battleInfoCollector.isInBattle)
            return;
        await widget1.InitDetailInfoWidget(characterList1.value < 4, characterList1.value % 4);
    }

    private async UniTask OnCharacterList2Selected(int value)
    {
        if (!BattleMain.Instance.battleLogic.battleInfoCollector.isInBattle)
            return;
        await widget2.InitDetailInfoWidget(characterList2.value < 4, characterList2.value % 4);
    }

    private async UniTask OnCharacterList3Selected(int value)
    {
        if (!BattleMain.Instance.battleLogic.battleInfoCollector.isInBattle)
            return;
        await widget3.InitDetailInfoWidget(characterList3.value < 4, characterList3.value % 4);
    }

    private async UniTask OnCharacterList4Selected(int value)
    {
        if (!BattleMain.Instance.battleLogic.battleInfoCollector.isInBattle)
            return;
        await widget4.InitDetailInfoWidget(characterList4.value < 4, characterList4.value % 4);
    }
    #endregion

    private async UniTask OnAddHpBtnClicked()
    {
        if (BattleMain.Instance == null)
            return;

        int defultNum;
        if (string.IsNullOrEmpty(hpInput.text))
            return;
        if (!int.TryParse(hpInput.text, out defultNum))
            return;
        if (defultNum == 0)
            return;

        if (addHpDropdown.value <= 0)
            return;
        if (!BattleMain.Instance.battleLogic.battleInfoCollector.isInBattle)
            return;

        SignalBus.GlobalSignal.Dispatch(UIEventId.DebugOnAddHpCallback, addHpDropdown.value, defultNum);
    }
#endif
}
