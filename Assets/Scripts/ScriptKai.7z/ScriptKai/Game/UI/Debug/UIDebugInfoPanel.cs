using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;

public class UIDebugInfoPanel : MonoBehaviour
{
    [SerializeField] Text binary;
    [SerializeField] Text masterData;
    [SerializeField] Text assetBundle ;
    
    public Text _serverUrl;
#if UNITY_EDITOR || BUILD_DEBUG
    private void Start()
    {
        _serverUrl.text = "服务器地址: " + TakashoHandler.Instance.serverUrl;
        binary.text = $"客户端版本: {Application.version}";
        
    }


    void OnEnable()
    {
        masterData.text = $"数据版本: {DataManager.Instance.Local.UserInfo.masterDataVersion}";
        assetBundle.text =  $"资源版本: {DataManager.Instance.Local.UserInfo.assetDataVersion}";
    }
#endif
}
