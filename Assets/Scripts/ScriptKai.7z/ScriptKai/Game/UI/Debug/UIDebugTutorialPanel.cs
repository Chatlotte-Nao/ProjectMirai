﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UIDebugTutorialPanel : UIBehaviourComponent
{
    [SerializeField] InputField curOpeningStep;
    [SerializeField] Button startOpeningBtn;
    [SerializeField] InputField curTutorialId;
    [SerializeField] Button finishCurrentBtn;
    [SerializeField] Button disableBtn;
    [SerializeField] InputField removeGroupId;
    [SerializeField] Button removeBtn;
    [SerializeField] InputField nameStr;
    
    [SerializeField] Button startBattleBtn;
    [SerializeField] InputField battleStage;

    private const int QUICK_NAME_STEP = 11;


#if BUILD_DEBUG 

    void Start()
    {
        startOpeningBtn.onClick.Subscribe(OnClickStartOpenning).AddTo(mSubscriptions);
        curTutorialId.onEndEdit.Subscribe(OnEditId).AddTo(mSubscriptions);
        finishCurrentBtn.onClick.Subscribe(OnClickFinishCurrent).AddTo(mSubscriptions);
        disableBtn.onClick.Subscribe(OnClickDisable).AddTo(mSubscriptions);
        removeBtn.onClick.SubscribeAsync(OnClickRemove).AddTo(mSubscriptions);
        startBattleBtn.onClick.SubscribeAsync(OnClickBattle).AddTo(mSubscriptions);
    }


    void OnEnable()
    {
        curOpeningStep.text = TutorialManager.Instance.GetCurrentOpeningStep().ToString();
        curTutorialId.text = TutorialManager.Instance.CurrentTutorialId.ToString();
    }

    void OnClickStartOpenning()
    {
        int v = int.Parse(curOpeningStep.text);
        TutorialManager.Instance.SetOpeningStep(v);
        TutorialManager.Instance.TryStartOpeningTutorial();
    }

    void OnEditId(string val)
    {
        int v = int.Parse(val);
        TutorialManager.Instance.StartFunctionTutorial(v);
    }

    void OnClickFinishCurrent()
    {
        TutorialManager.Instance.FinishCurrentTutorialStep();
    }

    void OnClickDisable()
    {
        TutorialManager.Instance.IsRunningFunctionTutorial = false;
        TutorialManager.Instance.clearGoalTutoral();
        UI.Canvas.GetCanvas(CanvasType.Tutorial).enabled = false;
    }

    async UniTask OnClickRemove()
    {
        int v = int.Parse(removeGroupId.text);

        var request = new Takasho.Schema.Score.PlayerApi.ScoreDebugClearTutorialFeatureV1.Types.Request()
        {
            FeatureId = v
        };


        var op = ApiEndpoints.DebugRemoveTutorial.Instance.CreateOperation(request);
        await TakashoHandler.Instance.ExecuteOperationAsync(op);

        DataManager.Instance.Player.Tutorial.RemoveFunctionComplete(v);
    }

    public void QuickToName()
    {
        if (string.IsNullOrEmpty(nameStr.text))
        {
            UI.Popup.ShowPopMessage("请输入名称");
            return;
        }
        AsyncManager.Instance.StartAsync(SetUserName);
       
    }

    private async UniTask SetUserName()
    {
        await ProfileService.SetUserName(nameStr.text);
        TutorialManager.Instance.SetOpeningStep(QUICK_NAME_STEP);
        TutorialManager.Instance.TryStartOpeningTutorial();
    }

    private async UniTask OnClickBattle()
    {
        var stageId = int.Parse(battleStage.text);
        if (!DataManager.Instance.Master.BattleZoneBattle.ContainsKey(stageId))
        {
            await UI.Popup.ShowPopupMessageAsync("请输入正确的stageID");
            return;
        }
        BattleSceneParam param = new BattleSceneParam()
        {
            stageID = stageId,
            battleID = DataManager.Instance.Master.BattleZoneBattle[stageId].battleMasterId
        };

        await GameSceneManager.Instance.ChangeSceneAsync<BattleScene>("BattleScene", param);
    }
    
#endif
}