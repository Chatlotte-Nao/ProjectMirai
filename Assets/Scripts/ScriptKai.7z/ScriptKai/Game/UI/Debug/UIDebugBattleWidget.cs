﻿using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using Battle;
using System.Collections.Generic;
using Battle.Messager;
using System.Text;

public class UIDebugBattleWidget : UIBehaviourComponent
{
    [SerializeField] Text characterId;
    [SerializeField] Text characterName;
    [SerializeField] Text hpText;
    [SerializeField] Text pAtkText;
    [SerializeField] Text pDefText;
    [SerializeField] Text mAtkText;
    [SerializeField] Text mDefText;
    [SerializeField] Text speedText;
    [SerializeField] Text critRateText;
    [SerializeField] Text critDmgText;
    [SerializeField] Text reCritRateText;
    [SerializeField] Text reCritDmgText;
    [SerializeField] Button BuffEntranceBtn;
    [SerializeField] Button BuffDetailBtn;
    [SerializeField] Text BuffIDText;
    [SerializeField] Text BuffDetailText;
    [SerializeField] GameObject ScrollGo;

#if UNITY_EDITOR || BUILD_DEBUG

    private void Start()
    {
        BuffEntranceBtn.onClick.AddListener(OnBuffEntranceBtnClicked);
        BuffDetailBtn.onClick.AddListener(OnBuffDetailBtnClicked);
    }
    private void OnEnable()
    {
        BuffDetailBtn.gameObject.SetActive(false);
        ScrollGo.gameObject.SetActive(false);
    }
    private void OnBuffEntranceBtnClicked()
    {
        BuffDetailBtn.gameObject.SetActive(true);
        ScrollGo.gameObject.SetActive(true);
    }
    private void OnBuffDetailBtnClicked()
    {
        BuffDetailBtn.gameObject.SetActive(false);
        ScrollGo.gameObject.SetActive(false);
    }


    public async UniTask InitDetailInfoWidget(bool isPlayer, int posIndex)
    {
        BuffDetailBtn.gameObject.SetActive(false);
        ScrollGo.gameObject.SetActive(false);
        Battle.Logic.Party selectedParty = isPlayer ? BattleMain.Instance.battleLogic.battlePartyManager.playerParty : BattleMain.Instance.battleLogic.battlePartyManager.enemyParty;
        Battle.Logic.BattleCharacter characterInParty = selectedParty.GetCharacterByIndex(posIndex);

        if (characterInParty == null)
        {
            InitWidgetDefault();
        }
        else
        {
            KeyValuePair<int, int> uidMasterIDPair = new KeyValuePair<int, int>(characterInParty.battleUid, (int)characterInParty.status.masterID);
            var response = await QueryCharacterDetail.Execute(uidMasterIDPair.Key, uidMasterIDPair.Value);
            List<Battle.Logic.Buff> buffs = characterInParty.BuffManager.GetBuffs();
            InitWidgetByModel(response.characterDetailModel, buffs);
        }
    }

    private void InitWidgetByModel(CharacterDetailModel model, List<Battle.Logic.Buff> buffs)
    {
        characterId.text = model.masterID.ToString();
        characterName.text = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER_NAME, model.masterID.ToString());
        hpText.text = model.hp + "/" + model.maxHp;
        pAtkText.text = (model.patk + model.diff_patk).ToString();
        pDefText.text = (model.pdef + model.diff_pdef).ToString();
        mAtkText.text = (model.matk + model.diff_matk).ToString();
        mDefText.text = (model.mdef + model.diff_mdef).ToString();
        speedText.text = (model.spd + model.diff_spd).ToString();
        critRateText.text = "-";
        critDmgText.text = "-";
        reCritRateText.text = "-";
        reCritDmgText.text = "-";

        // Buffs
        BuffIDText.text = "Buff:";
        BuffDetailText.text = "Empty！ Click to return！";

        if (buffs.Count < 1) return;
        string buffIdStr = "Buff:";
        StringBuilder buffDetailStr = new StringBuilder();
        foreach (var buff in buffs)
        {
            buffIdStr = buffIdStr + buff.buffId + "、";
            // var buffMaster = BattleMain.Instance.masterDataReader.GetMasterData<int, BuffMaster>(buff.buffId);
            string name = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.BUFF, buff.buffId + "_name");
            string detail = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.BUFF, buff.buffId + "_desc");
            buffDetailStr.Append(name);
            buffDetailStr.Append(buff.buffId);
            buffDetailStr.Append(":  ");
            buffDetailStr.Append(detail);
            buffDetailStr.AppendLine("\n------------");
        }
        BuffIDText.text = buffIdStr;
        BuffDetailText.text = buffDetailStr.ToString();
    }

    private void InitWidgetDefault()
    {
        characterId.text = "-";
        characterName.text = "-";
        hpText.text = "-";
        pAtkText.text = "-";
        pDefText.text = "-";
        mAtkText.text = "-";
        mDefText.text = "-";
        speedText.text = "-";
        critRateText.text = "-";
        critDmgText.text = "-";
        reCritRateText.text = "-";
        reCritDmgText.text = "-";

        // Buffs
        BuffIDText.text = "Buff:";
        BuffDetailText.text = "Empty！ Click to return！";
    }

#endif
}