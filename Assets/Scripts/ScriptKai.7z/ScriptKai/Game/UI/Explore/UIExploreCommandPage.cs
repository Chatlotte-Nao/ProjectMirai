using System;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Map;
using UnityEngine;
using UnityEngine.Events;

public class UIExploreCommandPage : UIPageBase
{
    private bool _isChara;
    private UIExploreCommandParam commandParam;

    CharacterMessage mMessage = null;

    // UIExploreSecondDialog mSecondDialog = null;
    // UIExploreCommandDialog mCommandDialog = null;
    UIInteractiveSecondDialog mSecondDialog = null;


    private bool Zooming;
    public UnityEvent Close => mSecondDialog.Close;

    public override async UniTask InitializeAsync(object param = null)
    {
        
        commandParam ??= param as UIExploreCommandParam;
        _isChara = string.IsNullOrEmpty(commandParam.interactiveTargetId);
        await base.InitializeAsync(param);
        var interactiveTargetId = _isChara ? commandParam.characterId.ToString() : commandParam.interactiveTargetId;
        if (_isChara)
        {
            //     
            mMessage = await UI.Dialog.CreateAsync(UIPrefabId.CharacterMessage, CanvasType.App0) as CharacterMessage;
            mMessage.gameObject.SetActive(false);
            await mMessage.Setup(int.Parse(interactiveTargetId));
        }
        mSecondDialog =
            await UI.Dialog.CreateAsync(UIPrefabId.UIInteractiveSecondDialog, CanvasType.App0) as
                UIInteractiveSecondDialog;
        Debug.Log(interactiveTargetId);
        mSecondDialog.SetUp(interactiveTargetId);
        mSecondDialog.teabreakClick.SubscribeAsync(hideMessage).AddTo(mSubscriptions);
        Close.SubscribeAsync(HidePage).AddTo(mSubscriptions);


        
        //     mCommandDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIExploreCommandDialog, CanvasType.App0) as UIExploreCommandDialog;
        //     mCommandDialog.teabreakClick.SubscribeAsync(hideMessage).AddTo(mSubscriptions);
        //     await mCommandDialog.Setup(commandParam as UIExploreCommandParam);
        //     var charaID =(int) (commandParam).characterId;
        // }
        // else
        // {
        //     mSecondDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIExploreSecondDialog, CanvasType.App0) as UIExploreSecondDialog;
        //     // await mSecondDialog.Setup(param as UIExploreCommandParam);
        //     foreach (var item in DataManager.Instance.Master.InteractiveButtonMaster)
        //     {
        //         if (item.Value.interactiveTargetId == commandParam.interactiveTargetId)
        //         {
        //             mSecondDialog.ShowCount(item.Value.secondaryInteractiveButtonId);
        //         } 
        //     }
        //     Close.SubscribeAsync(async () =>
        //     {
        //         MapSceneManager.Instance.CurrentScene.GetCameraController().GetVirtualCameraManager().ZoomPlayer(false, 0.6f);
        //         await UI.Page.CloseCurrentPage();
        //     }).AddTo(mSubscriptions);
        // }

        SignalBus.GlobalSignal.Dispatch<bool>(UIEventId.SwitchExploreCommandPage, true);
    }

    private async UniTask HidePage()
    {
        await HideAsync(UIPageShowType.Back);
        await UI.Page.CloseCurrentPage();
        UIInteractiveSecondDialog.SecondTime = false;
        MapSceneManager.Instance.CurrentScene.GetCameraController().GetVirtualCameraManager().ZoomPlayer(false, 0.6f);
    }

    private async UniTask hideMessage()
    {
        await mMessage.HideAsync();
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        UIInteractiveSecondDialog.SecondTime = true;
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHeaderHide);
        if (showType == UIPageShowType.Back)
            MapSceneManager.Instance.ShowCurrent();

        ZoomPlayer(true, 0.6f);
        await mSecondDialog.ShowAsync(showType);
        // if (_isChara)
        // {
        //     await mCommandDialog.ShowAsync(showType);
        // }
        // else
        // {
        //     await mSecondDialog.ShowAsync(showType);
        // }
    }

    void ZoomPlayer(bool isIn, float duration)
    {
        try
        {
            if (Zooming && isIn)
            {
                MapSceneManager.Instance.CurrentScene.GetCameraController().GetVirtualCameraManager()
                    .ZoomPlayer(isIn, 0);
            }

            var t = MapSceneManager.Instance.CurrentScene.GetCameraController().GetVirtualCameraManager()
                .ZoomPlayer(isIn, duration);
            t.onComplete = () =>
            {
                if (isIn)
                {
                    mMessage.Show();
                    AsyncManager.Instance.StartAsync(mMessage.ShowChild());
                }
            };
            Zooming = true;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            // throw;
        }
    }


    public override async UniTask HideAsync(UIPageShowType showType)
    {
        UIInteractiveSecondDialog.SecondTime = false;
        if (_isChara)
        {
        //     ZoomPlayer(false, 0.6f);
        //     await mCommandDialog.HideAsync();
        await mMessage.HideAsync();
        }
        // else
        // {
        await mSecondDialog.HideAsync();
        // }
        await base.HideAsync(showType);
    }

    public override void Dispose()
    {
        // if (mCommandDialog != null)
        // {
        //     mCommandDialog.Dispose();
        //     mCommandDialog = null;
        // }

        if (mMessage != null)
        {
            mMessage.Dispose();
            mMessage = null;
        }
        UIInteractiveSecondDialog.SecondTime = false;
        if (mSecondDialog != null)
        {
            mSecondDialog.Dispose();
            mSecondDialog = null;
        }

        base.Dispose();
        SignalBus.GlobalSignal.Dispatch<bool>(UIEventId.SwitchExploreCommandPage, false);
    }
}


public class UIExploreCommandParam
{
    public long characterId = 0;
    public string interactiveTargetId = "";

    public ExploreEventViewModel inviteEvent = null;
    public ExploreEventViewModel requestEvent = null;
}