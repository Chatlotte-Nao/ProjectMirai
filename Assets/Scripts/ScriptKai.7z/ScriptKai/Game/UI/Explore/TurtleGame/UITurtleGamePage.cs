﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using System;

public class UITurtleGamePage : UIPageBase
{
    private bool isCardDrawn = false;
    private UITurtleGameDialog mUITurtleGameDialog = null;
    private long characterId;
    private float playerNoOperateTime = 0f;
    private float playerStayTime = 0f;
    private bool isStay = false;
    private int stayCardId = -1;
    private string oldBgm = "";
    private bool isStart = false;

    private Queue<Func<UniTask>> playerJobs = new Queue<Func<UniTask>>();

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);

        if (!TurtleGame.HasInstance) TurtleGame.CreateInstance();

        oldBgm = "";
        isStart = false;
        characterId = long.Parse(param.ToString());
        await TurtleGame.Instance.InitializeAsync(characterId);

        mUITurtleGameDialog = await UI.Dialog.CreateAsync(UIPrefabId.UITurtleGameDialog, CanvasType.App1) as UITurtleGameDialog;
        mUITurtleGameDialog.OnCloseBtnClicked.GuardSubscribeAsync(StopTurtleGame).AddTo(mSubscriptions);
        mUITurtleGameDialog.OnStartBtnClicked.GuardSubscribeAsync(StartTurtleGame).AddTo(mSubscriptions);
        // mUITurtleGameDialog.OnRuleBtnClicked.GuardSubscribeAsync(OnRuleBtnClicked).AddTo(mSubscriptions);

        SignalBus.GlobalSignal.Subscribe<int>(UIEventId.PlayerSelectingCard, OnPlayerSelectingCard).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe<int>(UIEventId.PlayerDetermineFinalCard, OnPlayerDetermineFinalCard).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe<int>(UIEventId.PlayerExitSelectCard, OnPlayerExitSelectCard).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);

        oldBgm = Game.Sound.SoundPlayer.GetBgmName();
        AdvTurtleGameMaster master = DataManager.Instance.Master.AdvTurtleGame.GetValueOrDefault(characterId);
        Game.Sound.SoundPlayer.FadeToBgm(master.Bgm, 0.5f, 0.5f, true);

        await mUITurtleGameDialog.ShowAsync();
    }
    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await mUITurtleGameDialog.HideAsync();
    }
    private async UniTask StartTurtleGame(GameObject o)
    {
        await mUITurtleGameDialog.ShowFirsthand();
        await mUITurtleGameDialog.DealCards();
        await mUITurtleGameDialog.DealCardsGx();

        AsyncManager.Instance.StartAsync(RunTurtleGame());
    }

    private async UniTask RunTurtleGame()
    {
        isStart = true;

        while (!TurtleGame.Instance.isGameOver)
        {
            await mUITurtleGameDialog.ShowNpcDefaultAdv();

            if (TurtleGame.Instance == null) return;
            await mUITurtleGameDialog.RefreshCards();


            await UniTask.Delay(1600);// 主界面停留2s左右,以便玩家看牌。

            mUITurtleGameDialog.PlayEnterAinm();
            await UniTask.Delay(700);// 界面切换效果所需时间
            await mUITurtleGameDialog.ShowCardParentActive(false);
            await mUITurtleGameDialog.RefreshCardsGx();
            mUITurtleGameDialog.ShowSelectCardPanel();
            await PlayRound();
            mUITurtleGameDialog.HideSelectCardPanel();
            await mUITurtleGameDialog.RefreshCards(true);
            await mUITurtleGameDialog.ShowCardParentActive(true);
            mUITurtleGameDialog.PlayExitAinm();
            await UniTask.Delay(700);// 界面切换效果所需时间
        }

        isStart = false;
        if (mUITurtleGameDialog != null) await mUITurtleGameDialog.ShowGameResult(oldBgm);
    }



    private async UniTask PlayRound()
    {
        isCardDrawn = false;
        playerStayTime = 0f;
        playerNoOperateTime = 0f;
        while (!isCardDrawn)
        {
            if (TurtleGame.Instance == null) return;

            // 不可调整此While中下列代码的前后顺序，因OnCardDrawn()方法中对curTurn进行了更改。
            if (TurtleGame.Instance.curTurn == CoinSurface.Back)
            {
                await NpcDrawCard();
            }
            else
            {

                while (playerJobs.Count > 0)
                {
                    var job = playerJobs.Dequeue();
                    await job.Invoke();
                }


                playerNoOperateTime += 0.02f;
                if (isStay)
                {
                    playerStayTime += 0.02f;
                }

                // 谁先到播谁
                if (playerNoOperateTime > 12)
                {
                    await mUITurtleGameDialog.ShowAdvWhenPlayerNoOperate();
                    playerNoOperateTime = 0f;
                    playerStayTime = 0f;
                }
                else if (playerStayTime > 12)
                {
                    await mUITurtleGameDialog.ShowAdvWhenPlayerStay();
                    playerStayTime = 0f;
                    playerNoOperateTime = 0f;
                }
            }

            await UniTask.Yield(PlayerLoopTiming.PostLateUpdate);
            // Debug.LogError($"No Time: {playerNoOperateTime},    Stay Time: {playerStayTime}");
        }

        TurtleGamePlayer frontPlayer = TurtleGame.Instance.frontPlayer;
        TurtleGamePlayer backPlayer = TurtleGame.Instance.backPlayer;
        if (frontPlayer.HandCard.Count == 0 || (backPlayer.HandCard.Count == 1 && backPlayer.HandCard[0] == TurtleGame.Instance.TurtleCardInDeck))
        {
            TurtleGame.Instance.SetGameResult(CoinSurface.Front);
        }
        if (backPlayer.HandCard.Count == 0 || (frontPlayer.HandCard.Count == 1 && frontPlayer.HandCard[0] == TurtleGame.Instance.TurtleCardInDeck))
        {
            TurtleGame.Instance.SetGameResult(CoinSurface.Back);
        }
    }

    private void OnPlayerSelectingCard(int cardId)
    {
        playerNoOperateTime = 0f;

        isStay = true;
        if (cardId != stayCardId)
        {
            playerStayTime = 0f;
            stayCardId = cardId;
        }
    }

    private void OnPlayerExitSelectCard(int cardId)
    {
        playerNoOperateTime = 0f;
        playerStayTime = 0f;
    }


    private void OnPlayerDetermineFinalCard(int cardId)
    {
        Func<UniTask> task = async () =>
        {
            await mUITurtleGameDialog.PlayerDrawCardMotion(cardId);

            isStay = false;
            stayCardId = -1;

            await mUITurtleGameDialog.ShowNpcEmojiWhenPlayerDetermineFinalCard(cardId);
            OnCardDrawn(cardId);
        };

        playerJobs.Enqueue(task);
    }

    private async UniTask NpcDrawCard()
    {
        int selectCardId = await mUITurtleGameDialog.NpcSelectPlayerCard();
        OnCardDrawn(selectCardId);
    }

    private void OnCardDrawn(int cardId)
    {
        PxSoundManager.Instance.PlaySe("SE_drawcard");
        mUITurtleGameDialog.CardDrawn(cardId);
        mUITurtleGameDialog.CardDrawnGx(cardId);

        TurtleGame.Instance.DrawCard(cardId);
        isCardDrawn = true;
    }

    private async UniTask StopTurtleGame(GameObject o)
    {
        
        UI.Popup.ShowConfirm(
            LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "MutaCard_Title"),
            LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "MutaCard_Text"),
            CanvasType.App2,
            (r) =>
            {
                if (r == UIPopupDialog.Result.OK)
                {
                    // 如果While循环还未开始，可以直接关闭Page并且停掉Bgm。
                    // 如果While循环已经开始，那么就停掉While，由While循环自己去处理Close Page(弹结算界面)，否则会有时序问题。
                    if (isStart)
                    {
                        isCardDrawn = true;
                        TurtleGame.Instance.SetGameResult(CoinSurface.Back);
                        mUITurtleGameDialog.HideCloseButton();
                    }
                    else
                    {
                        Game.Sound.SoundPlayer.FadeToBgm(oldBgm, 0.5f, 0.5f, true);
                        UI.Page.CloseCurrentPage();
                    }
                }
            });
    }

    private async UniTask OnRuleBtnClicked(GameObject o)
    {
        // 直接在按钮上添加 UIRuleController组件，填写对应界面的规则ID即可。不用走这里。
    }

    public override void Dispose()
    {
        base.Dispose();

        if (mUITurtleGameDialog != null)
        {
            mUITurtleGameDialog.Dispose();
            mUITurtleGameDialog = null;
        }
        if (TurtleGame.HasInstance)
        {
            TurtleGame.Instance.Dispose();
        }
    }
}
