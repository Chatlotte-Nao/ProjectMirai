﻿using TMPro;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Collections.Generic;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class TurtleGameCard : MonoBehaviour, IPointerClickHandler, IBeginDragHandler, IEndDragHandler, IDragHandler
{
    [SerializeField] private GameObject cardBack;
    [SerializeField] private GameObject cardFront;
    [SerializeField] private GameObject turtleIcon;
    [SerializeField] private TextMeshProUGUI cardIdText;
    [SerializeField] private TextMeshProUGUI cardIdBtmText;
    [SerializeField] private List<Sprite> cardIcons;
    [SerializeField] private Image cardIcon;

    public int CardId { get; private set; }
    public bool IsTurtleCard { get; private set; }

    // why it doesn't work ???
    // private float cardDeterminedOffsetY = 100.0f;
    // private float cardSelectedOffsetY = 60.0f;
    // private float cardDragSafeOffset = 2.0f;

    private bool isTriggerEmoji;
    private bool isUIEventEnable;
    private Vector2 startDragPos;
    private Vector3 startPos;
    private TurtleGameCard curRaycastedCard;

    public TurtleGameCard(int cardId)
    {
        isTriggerEmoji = false;
        isUIEventEnable = false;
        CardId = cardId;
        IsTurtleCard = cardId == TurtleGame.Instance.TurtleCardInDeck;
    }

    public void Refresh(int cardId, bool isUIEventEnable, bool isShowCardback, bool isEmoji, bool isActive)
    {
        CardId = cardId;
        IsTurtleCard = cardId == TurtleGame.Instance.TurtleCardInDeck;
        this.isUIEventEnable = isUIEventEnable;
        isTriggerEmoji = isEmoji;

        turtleIcon.SetActive(IsTurtleCard);
        cardIdText.text = IsTurtleCard ? "" : cardId.ToString();
        cardIdBtmText.text = IsTurtleCard ? "" : cardId.ToString();
        cardBack.SetActive(isShowCardback);
        gameObject.SetActive(isActive);

        if (!IsTurtleCard)
        {
            cardIcon.sprite = cardIcons[cardId - 1];
        }
    }

    public void SetLocalPosition(Vector3 pos)
    {
        startPos = pos;
        transform.localPosition = pos;
    }

    public void SetLocalRotation(Vector3 angle)
    {
        transform.localEulerAngles = angle;
    }

    #region UI事件

    public void OnPointerClick(PointerEventData eventData)
    {
        if (!isUIEventEnable) return;
        if (TurtleGame.Instance.IsDraging) return;

        if (isTriggerEmoji)
        {
            SignalBus.GlobalSignal.Dispatch<int>(UIEventId.PlayerSelectingCard, CardId);
        }
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        TurtleGame.Instance.SetDragingState(true);

        if (!isUIEventEnable) return;
        if (TurtleGame.Instance.CurSelectedCardID == 0) return;

        startDragPos = eventData.position;
        if (Mathf.Abs(startDragPos.x - startPos.x) > 2.0f || Mathf.Abs(startDragPos.y - startPos.y) > 2.0f)
        {
            SignalBus.GlobalSignal.Dispatch<int>(UIEventId.PlayerBeginDragCard, CardId);
        }
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (!isUIEventEnable) return;
        if (TurtleGame.Instance.CurSelectedCardID == 0) return;

        curRaycastedCard = eventData.pointerCurrentRaycast.gameObject.GetComponent<TurtleGameCard>();
        if (curRaycastedCard != null && curRaycastedCard.isUIEventEnable)
        {
            if (eventData.pointerCurrentRaycast.gameObject == gameObject)
            {
                if (TurtleGame.Instance.LatestRaycastCardWhileDraging != null && TurtleGame.Instance.LatestRaycastCardWhileDraging.CardId != CardId)
                {
                    TurtleGame.Instance.LatestRaycastCardWhileDraging.BackToTeam();
                    TurtleGame.Instance.SetLatestRaycastCard(curRaycastedCard);
                }
                UpdatePos(eventData.position.y - startDragPos.y);
                TurtleGame.Instance.SetCurSelectedCard(CardId);
            }
            else
            {
                if (TurtleGame.Instance.CurSelectedCardID != curRaycastedCard.CardId)
                {
                    SignalBus.GlobalSignal.Dispatch<int>(UIEventId.PlayerSelectingCard, curRaycastedCard.CardId);
                    TurtleGame.Instance.SetLatestRaycastCard(curRaycastedCard);
                }
            }
        }
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        TurtleGame.Instance.SetDragingState(false);

        if (!isUIEventEnable) return;
        if (TurtleGame.Instance.CurSelectedCardID == 0) return;

        TurtleGameCard tempCurRaycastedCard = eventData.pointerCurrentRaycast.gameObject.GetComponent<TurtleGameCard>();
        if (tempCurRaycastedCard != null && tempCurRaycastedCard.isUIEventEnable)
        {
            if (eventData.pointerCurrentRaycast.gameObject == gameObject)
            {
                TryDetermineFinalCard(eventData.position.y - startDragPos.y);
            }
            else
            {
                SignalBus.GlobalSignal.Dispatch<int>(UIEventId.PlayerSelectingCard, tempCurRaycastedCard.CardId);
                TurtleGame.Instance.SetLatestRaycastCard(tempCurRaycastedCard);
            }
        }
        else
        {
            TryDetermineFinalCard(eventData.position.y - startDragPos.y);
        }
    }

    private void TryDetermineFinalCard(float offsetY)
    {
        TurtleGameCard turtleGameCard = TurtleGame.Instance.LatestRaycastCardWhileDraging;
        if (turtleGameCard == null)
        {
            turtleGameCard = this;
        }

        if (offsetY > 100.0f)
        {
            SignalBus.GlobalSignal.Dispatch<int>(UIEventId.PlayerDetermineFinalCard, turtleGameCard.CardId);
        }
        else
        {
            turtleGameCard.BackToTeam();
        }
        TurtleGame.Instance.SetCurSelectedCard(0);
    }
    #endregion


    #region PlayerDetermingCard
    public void UpdatePos(float gxDistanceY)
    {
        if (gxDistanceY > 100.0f) return;

        float angle = transform.localEulerAngles.z;
        if (angle > 180)
        {
            angle -= 360;
        }

        float x = Mathf.Sin(Mathf.Abs(angle) * Mathf.Deg2Rad) * gxDistanceY;
        if (angle > 0)
        {
            x = -x;
        }
        float y = Mathf.Cos(Mathf.Abs(angle) * Mathf.Deg2Rad) * gxDistanceY;

        // >= 0, 一个等号调死我了。
        if (gxDistanceY >= 0 && transform.localPosition.y - startPos.y >= Mathf.Cos(Mathf.Abs(angle) * Mathf.Deg2Rad) * 100.0f) return;

        transform.localPosition = new Vector3(startPos.x + x, startPos.y + y, 0);
    }
    #endregion

    #region PlayerSelectCard
    public void OutTeam()
    {
        float angle = transform.localEulerAngles.z;

        if (angle > 180)
        {
            angle -= 360;
        }

        float x = Mathf.Sin(Mathf.Abs(angle) * Mathf.Deg2Rad) * 60.0f;
        if (angle > 0)
        {
            x = -x;
        }
        float y = Mathf.Cos(Mathf.Abs(angle) * Mathf.Deg2Rad) * 60.0f;

        transform.localPosition = new Vector3(startPos.x + x, startPos.y + y, 0);
    }

    public void BackToTeam()
    {
        transform.localPosition = startPos;
    }
    #endregion


    #region NpcSelectCard
    public void SelectCard()
    {
        transform.localPosition = new Vector3(startPos.x, startPos.y + 60.0f, 0);
        // Npc 抽卡时，不走这个来触发表情了，直接在调用处切换ADV。
        //if (isTriggerEmoji)
        //{
        //    SignalBus.GlobalSignal.Dispatch<int>(UIEventId.TurtleGameADVEmoji, CardId);
        //}
    }
    public void CancelSelectCard()
    {
        transform.localPosition = startPos;
    }
    #endregion


    #region CommonUE
    public void DisableUIEventEnable()
    {
        isUIEventEnable = false;
    }

    public void ShowCardAtFirstPos(int tempCardId)
    {
        cardBack.SetActive(false);

        if (!IsTurtleCard)
        {
            turtleIcon.SetActive(false);
            cardIcon.sprite = cardIcons[tempCardId - 1];
            cardIdText.text = tempCardId.ToString();
            cardIdBtmText.text = tempCardId.ToString();
        }
        else
        {
            turtleIcon.SetActive(true);
        }
    }
    public void ShowCardAtSecondPos(int tempCardId)
    {
        gameObject.SetActive(true);
        cardBack.SetActive(false);

        if (!IsTurtleCard)
        {
            turtleIcon.SetActive(false);
            cardIcon.sprite = cardIcons[tempCardId - 1];
            cardIdText.text = tempCardId.ToString();
            cardIdBtmText.text = tempCardId.ToString();
        }
        else
        {
            turtleIcon.SetActive(true);
        }
    }

    public void TemporarilyHideCardFront()
    {
        cardFront.SetActive(false);
    }
    public void RestoreCardFrontToDisplay()
    {
        cardFront.SetActive(true);
    }
    #endregion
}
