﻿using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using System;

public enum CoinSurface
{
    Front,
    Back
}

public class TurtleGame : Singleton<TurtleGame>
{
    public bool isGameOver { get; private set; }
    /// <summary>
    /// 本场游戏的获胜方
    /// </summary>
    public CoinSurface winer { get; private set; }
    /// <summary>
    /// 本场游戏谁是先手
    /// </summary>
    public CoinSurface finalSurface { get; private set; }
    /// <summary>
    /// 当前轮到谁出牌
    /// </summary>
    public CoinSurface curTurn { get; private set; }
    public TurtleGamePlayer frontPlayer { get; private set; }
    public TurtleGamePlayer backPlayer { get; private set; }
    public long characterMasterId { get; private set; }

    /// <summary>
    /// 乌龟牌(鬼牌)的ID
    /// </summary>
    public readonly int TurtleCardInDeck = 999;
    private List<int> NormalCardInDeck = new() { 1, 2, 3, 4, 5, 6, 7 };

    public async UniTask InitializeAsync(long characterMasterId)
    {
        finalSurface = (CoinSurface)UnityEngine.Random.Range(0, 2);
        curTurn = finalSurface;
        winer = finalSurface;
        isGameOver = false;
        frontPlayer = new TurtleGamePlayer(finalSurface == CoinSurface.Front, true);
        backPlayer = new TurtleGamePlayer(finalSurface == CoinSurface.Back, false);
        this.characterMasterId = characterMasterId;
    }

    public List<int> GetCardInDeck(bool isFirstMove)
    {
        List<int> tempList = new List<int>();

        for (int i = 0; i < NormalCardInDeck.Count; i++)
        {
            tempList.Add(NormalCardInDeck[i]);
        }

        if (!isFirstMove)
        {
            tempList.Add(TurtleCardInDeck);
        }

        return tempList;
    }

    public int GetNormalCardCount()
    {
        return NormalCardInDeck.Count;
    }

    public void SetGameResult(CoinSurface winer)
    {
        this.winer = winer;
        isGameOver = true;
    }

    /// <summary>
    /// 移除掉抽牌方手里的卡牌，并改变当前抽牌方。
    /// </summary>
    public void DrawCard(int cardId)
    {
        switch (curTurn)
        {
            case CoinSurface.Front:
                backPlayer.RemoveCard(cardId);
                curTurn = CoinSurface.Back;
                frontPlayer.AddCard(cardId);
                break;
            case CoinSurface.Back:
                frontPlayer.RemoveCard(cardId);
                curTurn = CoinSurface.Front;
                backPlayer.AddCard(cardId);
                break;
            default:
                break;
        }
    }


    #region UE Operations
    /// <summary>
    /// 当前选中的卡牌(点击和拖拽到一定距离，视为选中。 不选中牌，无法进行滑动抽牌)
    /// </summary>
    public int CurSelectedCardID { get; private set; }
    public void SetCurSelectedCard(int cardID)
    {
        CurSelectedCardID = cardID;
    }

    public bool IsDraging { get; private set; }
    public void SetDragingState(bool isDraging)
    {
        IsDraging = isDraging;
    }
    public TurtleGameCard LatestRaycastCardWhileDraging { get; private set; }
    public void SetLatestRaycastCard(TurtleGameCard latestRaycastCard)
    {
        LatestRaycastCardWhileDraging = latestRaycastCard;
    }
    #endregion
}