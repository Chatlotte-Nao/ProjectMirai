﻿using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Collections.Generic;

public class TurtleGamePlayer
{
    /// <summary>
    /// 是否是先手玩家。 为True表示：该玩家为先手。
    /// </summary>
    public bool IsFirstMovePlayer { get; private set; }
    public List<int> HandCard { get; private set; }
    /// <summary>
    /// 是否是NPC。 为True表示：该玩家为奏者。
    /// </summary>
    public bool IsPlayer { get; private set; }

    public TurtleGamePlayer(bool isFirstMove, bool isPlayer)
    {
        HandCard = new List<int>();
        IsFirstMovePlayer = isFirstMove;
        IsPlayer = isPlayer;

        List<int> tempList = TurtleGame.Instance.GetCardInDeck(isFirstMove);
        for (int i = 0; i < tempList.Count; i++)
        {
            HandCard.Add(tempList[i]);
        }
        ResortHandCard();
    }

    public void RemoveCard(int cardId)
    {
        HandCard.Remove(cardId);
    }

    public void AddCard(int cardId)
    {
        HandCard.Add(cardId);
        DiscardSameCard(cardId);
        if (!IsPlayer)
        {
            ResortHandCard();
        }
        else
        {
            if (cardId == TurtleGame.Instance.TurtleCardInDeck)
            {
                RandomInsertGhostCard();
            }
        }
    }

    private void DiscardSameCard(int cardId)
    {
        int tempCount = 0;
        for (int i = 0; i < HandCard.Count; i++)
        {
            if (cardId == HandCard[i]) tempCount++;
        }

        if (tempCount == 2)
        {
            HandCard.RemoveAll((item) => { return cardId == item; });
        }
    }

    private void ResortHandCard()
    {
        if (HandCard.Count < 1) return;

        System.Random randomCard = new System.Random();
        for (int i = 0; i < 50; i++)
        {
            int randomCardIndex = randomCard.Next(0, HandCard.Count);
            int cardToMove = HandCard[randomCardIndex];
            HandCard.RemoveAt(randomCardIndex);
            HandCard.Add(cardToMove);
        }
    }
    private void RandomInsertGhostCard()
    {
        if (HandCard.Count < 1) return;

        System.Random randomCard = new System.Random();
        int randomCardIndex = randomCard.Next(0, HandCard.Count);
        HandCard.Remove(TurtleGame.Instance.TurtleCardInDeck);
        HandCard.Insert(randomCardIndex, TurtleGame.Instance.TurtleCardInDeck);
    }
}
