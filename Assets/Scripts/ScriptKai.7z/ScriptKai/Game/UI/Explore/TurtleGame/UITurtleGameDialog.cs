﻿using TMPro;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Collections.Generic;
using UnityEngine.UI;
using Spine.Unity;
using System;
using DG.Tweening;
using System.Linq;

public class UITurtleGameDialog : UIDialogBase
{
    [SerializeField] private GameObject coin;
    [SerializeField] private Image coinFront;
    [SerializeField] private Image coinBack;

    [SerializeField] private GameObject TurtleGameCloseBtnArea;
    [SerializeField] private UIButton TurtleGameCloseBtn;

    [SerializeField] private UIButton StartButton;

    // [SerializeField] private UIButton RuleButton;
    [SerializeField] private RectTransform NpcCardParent;
    [SerializeField] private RectTransform PlayerCardParent;
    [SerializeField] private GameObject turtleCardPrefab;

    [SerializeField] private SkeletonGraphic spineGraphic;
    [SerializeField] private GameObject winAnimArea;
    [SerializeField] private GameObject loseAnimArea;


    [SerializeField] private TurtleGameAdv turtleGameAdv;
    [SerializeField] private RectTransform PlayerCardParentGx;
    [SerializeField] private RectTransform NpcCardParentGx;


    [SerializeField] private Transform FirstCardPos;
    [SerializeField] private Transform SecondCardPos;
    [SerializeField] private Transform GhostCardPos;
    [SerializeField] private TurtleGameCard SecondCard;
    [SerializeField] private TurtleGameCard GhostCard;
    [SerializeField] private GameObject Tip;

    // Player卡所需。
    public float distanceX = 100f;

    // Npc卡所需(弧度相关)
    public float width = 80f;
    public float angle = 4;
    private List<TurtleGameCard> backPlayerCard;
    private List<TurtleGameCard> backPlayerCardGx;
    private GameObject bgObject = null;


    private float durationTime = 0.4f;
    // public ClickEvent OnRuleBtnClicked => RuleButton.onClick;

    private List<TurtleGameCard> frontPlayerCard;

    private List<TurtleGameCard> frontPlayerCardGx;

    private bool isQuitHalfway = false;

    public ClickEvent OnCloseBtnClicked => TurtleGameCloseBtn.onClick;
    public ClickEvent OnStartBtnClicked => StartButton.onClick;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        coin.SetActive(false);
        spineGraphic.gameObject.SetActive(false);
        winAnimArea.SetActive(false);
        loseAnimArea.SetActive(false);
        StartButton.gameObject.SetActive(true);
        NpcCardParent.gameObject.SetActive(false);
        PlayerCardParent.gameObject.SetActive(false);
        SecondCard.gameObject.SetActive(false);
        GhostCard.gameObject.SetActive(false);
        TurtleGameCloseBtnArea.SetActive(true);
        Tip.SetActive(false);
        isQuitHalfway = false;

        frontPlayerCard = new List<TurtleGameCard>();
        backPlayerCard = new List<TurtleGameCard>();

        await turtleGameAdv.InitializeAsync();
        PlayerCardParentGx.gameObject.SetActive(false);
        NpcCardParentGx.gameObject.SetActive(false);

        frontPlayerCardGx = new List<TurtleGameCard>();
        backPlayerCardGx = new List<TurtleGameCard>();

        SignalBus.GlobalSignal.Subscribe<int>(UIEventId.PlayerSelectingCard, OnCardClicked).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe<int>(UIEventId.PlayerBeginDragCard, OnBeginDragCard).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        var label = MapSceneManager.Instance.CurrentScene.label;
        var bg = DataManager.Instance.Master.Location[label].advBg;
        if (!string.IsNullOrEmpty(bg))
        {
            bgObject = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/bg/" + bg, UI.Canvas.GetCanvas(CanvasType.BG).transform);

            foreach (var item in bgObject.GetComponentsInChildren<Renderer>())
            {
                item.gameObject.layer = LayerMask.NameToLayer("UI");
            }

            bgObject.transform.localPosition = Vector3.zero;
            bgObject.transform.localScale = new Vector3(52, 52, 1);
        }

        await base.ShowAsync(showType);

        await InitCoin();
    }

    public override async UniTask HideAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.HideAsync(showType);
        if (bgObject != null)
        {
            Destroy(bgObject.gameObject);
            bgObject = null;
        }
    }

    public async UniTask ShowFirsthand()
    {
        StartButton.gameObject.SetActive(false);

        coin.SetActive(true);
        await SetCoinSurfaceFinalIcon();
        coin.SetActive(false);
    }

    public async UniTask ShowCardParentActive(bool isHideCardList)
    {
        NpcCardParent.gameObject.SetActive(isHideCardList);
        PlayerCardParent.gameObject.SetActive(isHideCardList);
    }

    private async UniTask InitCoin()
    {
        // 玩家头像
        long iconId = DataManager.Instance.Player.Player.GetData().ProfileIconId;
        string userIconId = DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[iconId].characterResourceId].userIconId;
        coinFront.sprite = await ResourceManager.Instance.LoadSpriteAsync("RoundIcon", userIconId);

        // 当前跟随奏者
        iconId = TurtleGame.Instance.characterMasterId;
        userIconId = DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[iconId].characterResourceId].userIconId;
        coinBack.sprite = await ResourceManager.Instance.LoadSpriteAsync("RoundIcon", userIconId);
    }

    /// <summary>
    /// 矫正硬币icon至先手player的icon。
    /// </summary>
    private async UniTask SetCoinSurfaceFinalIcon()
    {
        // 等待硬币旋转动画播放完 ...
        await UniTask.Delay(1700);
        // 动画最后停留面为：coinFront。
        if (TurtleGame.Instance.finalSurface == CoinSurface.Front)
        {
            // 抛完硬币，Npc是后手时，Npc的表情变化。
            await turtleGameAdv.PlayAdv(TurtleGameAdvType.NpcSecond);
        }
        else
        {
            long iconId = TurtleGame.Instance.characterMasterId;
            string userIconId = DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[iconId].characterResourceId].userIconId;
            coinFront.sprite = await ResourceManager.Instance.LoadSpriteAsync("RoundIcon", userIconId);

            // 抛完硬币，Npc是先手时，Npc的表情变化。
            await turtleGameAdv.PlayAdv(TurtleGameAdvType.NpcFirst);
        }
        // 硬币最终面展示时间
        await UniTask.Delay(1000);
    }

    private async UniTask PlayDealCardsAnim()
    {
        spineGraphic.gameObject.SetActive(true);
        spineGraphic.startingAnimation = "poker1";
        if (spineGraphic.AnimationState != null)
        {
            spineGraphic.AnimationState.SetAnimation(0, "poker1", false);
        }

        await UniTask.Delay(6500);
        spineGraphic.gameObject.SetActive(false);
    }

    /// <summary>
    /// FrontPlayer、BackPlayer同时发牌，咔咔咔发。
    /// </summary>
    public async UniTask DealCards()
    {
        await PlayDealCardsAnim();


        NpcCardParent.gameObject.SetActive(true);
        PlayerCardParent.gameObject.SetActive(true);

        int tempCount = TurtleGame.Instance.GetNormalCardCount();
        List<int> frontPlayerHandCard = TurtleGame.Instance.frontPlayer.HandCard;
        List<int> backPlayerHandCard = TurtleGame.Instance.backPlayer.HandCard;

        for (int i = 0; i < tempCount; i++)
        {
            GameObject bPlayerCard = Instantiate(turtleCardPrefab, NpcCardParent);
            TurtleGameCard bTurtleCard = bPlayerCard.GetComponent<TurtleGameCard>();
            bTurtleCard.Refresh(backPlayerHandCard[i], false, true, false, true);
            backPlayerCard.Add(bTurtleCard);

            GameObject fPlayerCard = Instantiate(turtleCardPrefab, PlayerCardParent);
            TurtleGameCard fTurtleCard = fPlayerCard.GetComponent<TurtleGameCard>();
            fTurtleCard.Refresh(frontPlayerHandCard[i], false, false, false, true);
            frontPlayerCard.Add(fTurtleCard);

            await UniTask.Delay(200);
        }

        GameObject frontClonePrefab = Instantiate(turtleCardPrefab, PlayerCardParent);
        GameObject backClonePrefab = Instantiate(turtleCardPrefab, NpcCardParent);
        // 鬼牌在Player手里的情况
        TurtleGameCard frontTurtleCard = frontClonePrefab.GetComponent<TurtleGameCard>();
        frontPlayerCard.Add(frontTurtleCard);
        if (!TurtleGame.Instance.frontPlayer.IsFirstMovePlayer)
        {
            frontTurtleCard.Refresh(frontPlayerHandCard[tempCount], false, false, false, true);
            backClonePrefab.SetActive(false);
            await UniTask.Delay(1000);
        }
        // 鬼牌在NPC手里的情况
        TurtleGameCard backTurtleCard = backClonePrefab.GetComponent<TurtleGameCard>();
        backPlayerCard.Add(backTurtleCard);
        if (!TurtleGame.Instance.backPlayer.IsFirstMovePlayer)
        {
            backTurtleCard.Refresh(backPlayerHandCard[tempCount], false, true, false, true);
            frontClonePrefab.SetActive(false);
            await UniTask.Delay(1000);
        }

        // 咔咔咔发完牌后，关掉NpcCardParent上的排序组件。
        NpcCardParent.GetComponent<HorizontalLayoutGroup>().enabled = false;
        NpcCardParent.GetComponent<ContentSizeFitter>().enabled = false;
    }

    public async UniTask RefreshCards(bool onlyRefreshFront = false)
    {
        if (onlyRefreshFront)
        {
            // 界面切换时，玩家手牌需要刷新一下
            RefreshFrontPlayerCard();
        }
        else
        {
            RefreshFrontPlayerCard();
            RefreshBackPlayerCard();
        }
    }

    private void RefreshFrontPlayerCard()
    {
        List<int> tempFL = TurtleGame.Instance.frontPlayer.HandCard;
        for (int i = 0; i < frontPlayerCard.Count; i++)
        {
            if (i < tempFL.Count)
            {
                frontPlayerCard[i].Refresh(tempFL[i], false, false, false, true);
            }
            else
            {
                frontPlayerCard[i].gameObject.SetActive(false);
            }
        }
    }

    private void RefreshBackPlayerCard()
    {
        List<int> tempBL = TurtleGame.Instance.backPlayer.HandCard;
        int count = tempBL.Count;
        float x = 0; float y = 0;
        for (int i = 0; i < backPlayerCard.Count; i++)
        {
            if (i < count)
            {
                x = -(width * ((float)(count - 1) / 2 - i));
                y = -(width * ((float)(count - 1) / 2 - i)) / Mathf.Sin(Mathf.Deg2Rad * angle * ((float)(count - 1) / 2 - i)) + (1f / (Mathf.Tan(Mathf.Deg2Rad * angle * ((float)(count - 1) / 2 - i))) * (width * ((float)(count - 1) / 2 - i)));
                if (double.IsNaN(y)) y = 0;

                backPlayerCard[i].SetLocalRotation(new Vector3(0, 0, angle * ((float)(count - 1) / 2 - i)));
                backPlayerCard[i].SetLocalPosition(new Vector3(x, y, 0));
                backPlayerCard[i].Refresh(tempBL[i], false, true, false, true);
            }
            else
            {
                backPlayerCard[i].gameObject.SetActive(false);
            }
        }
    }

    public void CardDrawn(int cardId)
    {
        /*
        CoinSurface curTurn = TurtleGame.Instance.curTurn;
        List<TurtleGameCard> temp = curTurn == CoinSurface.Front ? frontPlayerCard : backPlayerCard;
        for (int i = 0; i < temp.Count; i++)
        {
            if (temp[i].CardId == cardId)
            {
                // Destroy(temp[i].gameObject);
                temp[i].gameObject.SetActive(false);
            }
        }
        */



        // 现在抽牌方和对方的牌都需要消失掉
        for (int i = 0; i < frontPlayerCard.Count; i++)
        {
            if (frontPlayerCard[i].CardId == cardId)
            {
                frontPlayerCard[i].gameObject.SetActive(false);
            }
        }
        for (int i = 0; i < backPlayerCard.Count; i++)
        {
            if (backPlayerCard[i].CardId == cardId)
            {
                backPlayerCard[i].gameObject.SetActive(false);
            }
        }
    }

    public async UniTask ShowNpcEmojiWhenPlayerDetermineFinalCard(int cardId)
    {
        if (cardId == TurtleGame.Instance.TurtleCardInDeck)
        {
            await turtleGameAdv.PlayAdv(TurtleGameAdvType.PlayerGotGhost);
        }
    }

    // 还需一个当前拖拽ID，
    private void OnBeginDragCard(int cardID)
    {
        // 开始拖拽，000！  除自身外，全部重置。
        foreach (TurtleGameCard card in backPlayerCardGx)
        {
            if (cardID != card.CardId)
            {
                card.BackToTeam();
            }
        }
    }

    private void OnCardClicked(int cardId)
    {
        if (TurtleGame.Instance.curTurn == CoinSurface.Back)
        {
            // Debug.LogError("Not This!  Attention!");
            return;
        }


        // 玩家选牌时，Npc牌的效果
        TurtleGame.Instance.SetCurSelectedCard(cardId);
        foreach (TurtleGameCard card in backPlayerCardGx)
        {
            if (cardId == card.CardId)
            {
                card.OutTeam();
            }
            else
            {
                card.BackToTeam();
            }
        }

        // 玩家选牌时，Npc表情的变化。
        List<int> tempL = TurtleGame.Instance.backPlayer.HandCard;
        bool isNpcHaveGhostCard = tempL.Contains(TurtleGame.Instance.TurtleCardInDeck);
        if (isNpcHaveGhostCard)
        {
            if (cardId == TurtleGame.Instance.TurtleCardInDeck)
            {
                turtleGameAdv.PlayAdv(TurtleGameAdvType.PlayerSelectGhost);
            }
            else
            {
                turtleGameAdv.PlayAdv(TurtleGameAdvType.PlayerSelectNormal);
            }
        }
        else
        {
            turtleGameAdv.PlayAdv(TurtleGameAdvType.PlayerSelectNormal);
        }
    }

    public async UniTask ShowAdvWhenPlayerStay()
    {
        await turtleGameAdv.PlayAdv(TurtleGameAdvType.PlayerStay);
    }

    public async UniTask ShowAdvWhenPlayerNoOperate()
    {
        await turtleGameAdv.PlayAdv(TurtleGameAdvType.PlayerNoOperate);
    }

    public async UniTask ShowNpcDefaultAdv()
    {
        await turtleGameAdv.PlayAdv(TurtleGameAdvType.Default);
    }

    public void ShowSelectCardPanel()
    {
        TurtleGame.Instance.SetCurSelectedCard(0);

        ShowFrontOrBack();
    }

    public void HideSelectCardPanel()
    {
        PlayerCardParentGx.gameObject.SetActive(false);
        NpcCardParentGx.gameObject.SetActive(false);
        Tip.SetActive(false);
    }

    public async UniTask DealCardsGx()
    {
        int tempCount = Mathf.Max(TurtleGame.Instance.frontPlayer.HandCard.Count, TurtleGame.Instance.backPlayer.HandCard.Count);

        for (int i = 0; i < tempCount; i++)
        {
            GameObject bPlayerCard = Instantiate(turtleCardPrefab, NpcCardParentGx);
            TurtleGameCard bTurtleCard = bPlayerCard.GetComponent<TurtleGameCard>();
            backPlayerCardGx.Add(bTurtleCard);

            GameObject fPlayerCard = Instantiate(turtleCardPrefab, PlayerCardParentGx);
            TurtleGameCard fTurtleCard = fPlayerCard.GetComponent<TurtleGameCard>();
            frontPlayerCardGx.Add(fTurtleCard);
        }
    }

    public async UniTask RefreshCardsGx()
    {
        /*
        if (TurtleGame.Instance.curTurn == CoinSurface.Front)
        {
            // 轮到FrontPlayer抽牌了，将BackPlayer的牌显示到NpcCardParent区域。
            RefreshNpcCardGx();
        }
        else if (TurtleGame.Instance.curTurn == CoinSurface.Back)
        {
            // 轮到BackPlayer抽牌了，将FrontPlayer的牌显示到PlayerCardParent区域。
            RefreshPlayerCardGx();
        }
        */

        // 新效果图现在要两个都需要刷新，因为两个都要展示

        if (TurtleGame.Instance.curTurn == CoinSurface.Front)
        {
            RefreshNpcCardGx();
            RefreshPlayerCardGx();
        }
        else if (TurtleGame.Instance.curTurn == CoinSurface.Back)
        {
            RefreshPlayerCardGx();
        }
    }

    private void ShowFrontOrBack()
    {
        if (TurtleGame.Instance.curTurn == CoinSurface.Front)
        {
            Tip.SetActive(true);
            NpcCardParentGx.gameObject.SetActive(true);
            PlayerCardParentGx.gameObject.SetActive(true);
        }
        else
        {
            PlayerCardParentGx.gameObject.SetActive(true);
            NpcCardParentGx.gameObject.SetActive(false);
            Tip.SetActive(false);
        }
    }

    private void RefreshNpcCardGx()
    {
        List<int> backPlayerHandCard = TurtleGame.Instance.backPlayer.HandCard;
        int count = backPlayerHandCard.Count;
        if (count == 0) return;

        float x = 0; float y = 0;
        for (int i = 0; i < backPlayerCardGx.Count; i++)
        {
            if (i > count - 1)
            {
                backPlayerCardGx[i].gameObject.SetActive(false);
            }
            else
            {
                x = -(width * ((float)(count - 1) / 2 - i));
                y = -(width * ((float)(count - 1) / 2 - i)) / Mathf.Sin(Mathf.Deg2Rad * angle * ((float)(count - 1) / 2 - i)) + (1f / (Mathf.Tan(Mathf.Deg2Rad * angle * ((float)(count - 1) / 2 - i))) * (width * ((float)(count - 1) / 2 - i)));
                if (double.IsNaN(y)) y = 0;


                backPlayerCardGx[i].SetLocalRotation(new Vector3(0, 0, angle * ((float)(count - 1) / 2 - i)));
                backPlayerCardGx[i].SetLocalPosition(new Vector3(x, y, 0));
                backPlayerCardGx[i].Refresh(backPlayerHandCard[i], true, true, true, true);
            }
        }
    }

    private void RefreshPlayerCardGx()
    {
        List<int> frontPlayerHandCard = TurtleGame.Instance.frontPlayer.HandCard;
        int count = frontPlayerHandCard.Count;
        if (count == 0) return;

        int tempR = count % 2;
        float x;
        if (tempR == 0)
        {
            x = (1 - count) * distanceX * 0.5f;
            for (int i = 0; i < count; i++)
            {
                frontPlayerCardGx[i].Refresh(frontPlayerHandCard[i], false, false, false, true);
                frontPlayerCardGx[i].SetLocalPosition(new Vector3(x, 0, 0));
                x += distanceX;
            }
        }
        else
        {
            x = -count / 2 * distanceX;
            for (int i = 0; i < count; i++)
            {
                frontPlayerCardGx[i].Refresh(frontPlayerHandCard[i], false, false, false, true);
                frontPlayerCardGx[i].SetLocalPosition(new Vector3(x, 0, 0));
                x += distanceX;
            }
        }

        for (int i = 0; i < frontPlayerCardGx.Count; i++)
        {
            if (i > count - 1)
            {
                frontPlayerCardGx[i].gameObject.SetActive(false);
            }
        }
    }

    public void CardDrawnGx(int cardId)
    {
        /*
        CoinSurface curTurn = TurtleGame.Instance.curTurn;
        List<TurtleGameCard> temp = curTurn == CoinSurface.Front ? frontPlayerCardGx : backPlayerCardGx;
        for (int i = 0; i < temp.Count; i++)
        {
            if (temp[i].CardId == cardId)
            {
                // Destroy(temp[i].gameObject);
                temp[i].gameObject.SetActive(false);
            }
        }
         */


        // 现在抽牌方和对方的牌都需要消失掉
        for (int i = 0; i < frontPlayerCardGx.Count; i++)
        {
            if (frontPlayerCardGx[i].CardId == cardId)
            {
                frontPlayerCardGx[i].gameObject.SetActive(false);
            }
        }
        for (int i = 0; i < backPlayerCardGx.Count; i++)
        {
            if (backPlayerCardGx[i].CardId == cardId)
            {
                backPlayerCardGx[i].gameObject.SetActive(false);
            }
        }
    }

    public async UniTask<int> NpcSelectPlayerCard()
    {
        // 轮到NPC抽牌时，确定好本轮要选择多少次牌。
        System.Random random = new System.Random();
        int hasitateCount = random.Next(2, 8);

        byte[] buffer = Guid.NewGuid().ToByteArray();
        int tempSeed = BitConverter.ToInt32(buffer, 0);
        System.Random battleRandom = new System.Random(tempSeed);

        TurtleGamePlayer frontPlayer = TurtleGame.Instance.frontPlayer;
        List<int> indexList = new List<int>();
        for (int i = 0; i < hasitateCount; i++)
        {
            int index = battleRandom.Next(0, frontPlayer.HandCard.Count);
            if (!indexList.Contains(index))
            {
                indexList.Add(index);
            }
        }

        // 轮到NPC抽牌时，在这里播放犹豫ADV。
        await turtleGameAdv.PlayAdv(TurtleGameAdvType.NpcHesitate);

        // 轮到NPC抽牌时，NPC开始犹豫，模拟选牌。
        int cardListindex = 0;
        for (int i = 0; i < indexList.Count; i++)
        {
            // 如果此时强制退出，那么直接break，以提前结束模拟选牌。
            if (isQuitHalfway) break;

            cardListindex = indexList[i];
            frontPlayerCardGx[cardListindex].SelectCard();

            // 直到剩余抽牌次数不足1时，切换到抽牌动作ADV，否则继续模拟选牌。
            if (i == indexList.Count - 1)
            {
                await turtleGameAdv.PlayAdv(TurtleGameAdvType.NpcDrawCard);
                await UniTask.Delay(1500);
            }
            else
            {
                await UniTask.Delay(1000);
            }

            if (i < indexList.Count - 1) frontPlayerCardGx[cardListindex].CancelSelectCard();
        }

        int cardNpcFinalSelected = frontPlayer.HandCard[indexList[^1]];

        if (!isQuitHalfway)
        {
            await NpcDrawCardMotion(cardNpcFinalSelected);
            if (cardNpcFinalSelected == TurtleGame.Instance.TurtleCardInDeck)
            {
                await turtleGameAdv.PlayAdv(TurtleGameAdvType.NpcGotGhost);
                await UniTask.Delay(1000);
            }
        }

        return cardNpcFinalSelected;
    }

    public async UniTask PlayerDrawCardMotion(int drawnCardId)
    {
        // 取消掉所有Npc牌的UI响应，避免误操作！
        foreach (TurtleGameCard card in backPlayerCardGx)
        {
            card.DisableUIEventEnable();
        }

        if (drawnCardId == TurtleGame.Instance.TurtleCardInDeck)
        {
            await GGGGGGG(drawnCardId);
        }
        else
        {
            await NNNNNNN(drawnCardId);
        }
    }

    async UniTask GGGGGGG(int drawnCardId)
    {
        Debug.Log($"Gx ####### GGGGGGG FUNCTION GGGGGGGG FUNC");

        // Npc的牌
        TurtleGameCard drawnCard = backPlayerCardGx.Find(x => x.CardId == drawnCardId);
        await drawnCard.transform.DOMove(GhostCardPos.position, durationTime);
        await drawnCard.transform.DOLocalRotate(new Vector3(0, 0, 0), durationTime);

        // Player的牌(在预制体中双方牌和额外的牌锚点都是一样的，所以可以这么移动。)
        GGG_1();
        GhostCard.Refresh(drawnCardId, false, false, false, true);
        drawnCard.gameObject.SetActive(false);
        await UniTask.Delay(500);

        int index = 0;
        for (int i = 0; i < frontPlayerCardGx.Count; i++)
        {
            if (i == TurtleGame.Instance.frontPlayer.HandCard.Count)
            {
                index = i;
                break;
            }
        }

        Debug.Log($"Gx ####### GGGG：frontPlayerCardGx_Count:{frontPlayerCardGx.Count},   index:{index}");

        GhostCard.transform.DOScale(1, durationTime);
        Vector3 targetPos = frontPlayerCardGx[index - 1].transform.position;
        targetPos.x += distanceX;
        await GhostCard.transform.DOMove(targetPos, durationTime);
        await UniTask.Delay(1500);
        GhostCard.gameObject.SetActive(false);
    }

    void GGG_1()
    {
        GhostCard.transform.position = GhostCardPos.position;
    }


    async UniTask NNNNNNN(int drawnCardId)
    {
        Debug.Log($"Gx ______ NNNNNNN FUNCTION NNNNNNN FUNC");

        // Npc的牌
        TurtleGameCard drawnCard = backPlayerCardGx.Find(x => x.CardId == drawnCardId);

        Debug.Log($"Gx ______ NNNNNNN 111");

        await drawnCard.transform.DOMove(FirstCardPos.position, durationTime);
        Debug.Log($"Gx ______ NNNNNNN 222");
        await drawnCard.transform.DOLocalRotate(new Vector3(0, 0, 0), durationTime);
        drawnCard.ShowCardAtFirstPos(drawnCardId);
        await UniTask.Delay(500);
        int siblingIndex = drawnCard.transform.GetSiblingIndex();
        drawnCard.transform.SetAsLastSibling();

        // Player的牌 (另一张牌)
        TurtleGameCard cardInHand = frontPlayerCardGx.Find(x => x.CardId == drawnCardId);
        Debug.Log($"Gx ______ NNNNNNN 333");
        await cardInHand.transform.DOMove(SecondCardPos.position, durationTime);
        Debug.Log($"Gx ______ NNNNNNN 444");
        await cardInHand.transform.DOScale(0.8f, durationTime);
        await UniTask.Delay(1500);

        drawnCard.gameObject.SetActive(false);
        drawnCard.transform.SetSiblingIndex(siblingIndex);
        cardInHand.gameObject.SetActive(false);
        cardInHand.transform.localScale = Vector3.one;
    }


    public async UniTask NpcDrawCardMotion(int drawnCardId)
    {
        await turtleGameAdv.PlayAdv(TurtleGameAdvType.Default);

        if (drawnCardId == TurtleGame.Instance.TurtleCardInDeck)
        {
            // Player的牌
            TurtleGameCard drawnCard = frontPlayerCardGx.Find(x => x.CardId == drawnCardId);
            await drawnCard.transform.DOMove(GhostCardPos.position, durationTime);
            await drawnCard.transform.DOLocalRotate(new Vector3(0, 0, 0), durationTime);
            await UniTask.Delay(500);

            drawnCard.gameObject.SetActive(false);
        }
        else
        {
            // Player的牌
            TurtleGameCard drawnCard = frontPlayerCardGx.Find(x => x.CardId == drawnCardId);
            await drawnCard.transform.DOMove(FirstCardPos.position, durationTime);
            await drawnCard.transform.DOLocalRotate(new Vector3(0, 0, 0), durationTime);
            await UniTask.Delay(500);
            // Npc的牌(另一张牌)
            int siblingIndex = drawnCard.transform.GetSiblingIndex();
            drawnCard.transform.SetAsLastSibling();
            SecondCard.ShowCardAtSecondPos(drawnCardId);
            await UniTask.Delay(1500);

            drawnCard.gameObject.SetActive(false);
            drawnCard.transform.SetSiblingIndex(siblingIndex);
            SecondCard.gameObject.SetActive(false);
        }
    }

    public void HideCloseButton()
    {
        TurtleGameCloseBtnArea.SetActive(false);
        isQuitHalfway = true;
    }

    public void PlayEnterAinm()
    {
        ResetPosition();
        float durTime;

        if (TurtleGame.Instance.curTurn == CoinSurface.Front)
        {
            durTime = 0.7f;
            float pFinalY = -105f;
            float nFinalY = 254f;
            PlayerCardParent.DOAnchorPosY(pFinalY, durTime);
            NpcCardParent.DOAnchorPosY(nFinalY, durTime);
            NpcCardParent.DOScale(0.8f, durTime);
            turtleGameAdv.AdvEnterAnim(durTime);

            Vector3 pos = Vector3.zero;
            pos.y = nFinalY;
            NpcCardParentGx.anchoredPosition = pos;
            NpcCardParentGx.localScale = new Vector3(0.8f, 0.8f, 0.8f);

            pos.y = pFinalY;
            PlayerCardParentGx.anchoredPosition = pos;
        }
        else
        {
            durTime = 0.5f;
            float pFinalY = 168f;
            for (int i = 0; i < backPlayerCard.Count; i++)
            {
                backPlayerCard[i].TemporarilyHideCardFront();
            }
            NpcCardParent.GetComponent<CanvasGroup>().DOFade(0, durTime);
            PlayerCardParent.DOAnchorPosY(pFinalY, durTime);

            PlayerCardParentGx.anchoredPosition = new Vector3(0, pFinalY, 0);
        }
    }

    private void ResetPosition()
    {
        Vector3 pos = Vector3.zero;
        pos.y = 380f;
        NpcCardParent.anchoredPosition = pos;
        NpcCardParent.localScale = new Vector3(0.6f, 0.6f, 1);

        pos.y = 49f;
        PlayerCardParent.anchoredPosition = pos;

        turtleGameAdv.transform.localScale = Vector3.one;
    }

    public void PlayExitAinm()
    {
        float durTime;
        float pStartY = 49f;

        // TurtleGame.Instance.curTurn 在抓牌之后已经发生了变化，所以这里是CoinSurface.Back
        if (TurtleGame.Instance.curTurn == CoinSurface.Back)
        {
            durTime = 0.7f;

            float nStartY = 380f;
            PlayerCardParent.DOAnchorPosY(pStartY, durTime);
            NpcCardParent.DOAnchorPosY(nStartY, durTime);
            NpcCardParent.DOScale(0.6f, durTime);
            turtleGameAdv.AdvExitAnim(durTime);
        }
        else
        {
            durTime = 0.5f;
            NpcCardParent.GetComponent<CanvasGroup>().DOFade(1, durTime).onComplete += () =>
            {
                for (int i = 0; i < backPlayerCard.Count; i++)
                {
                    backPlayerCard[i].RestoreCardFrontToDisplay();
                }
            };
            PlayerCardParent.DOAnchorPosY(pStartY, durTime);
        }
    }

    public async UniTask ShowGameResult(string oldBgm)
    {
        // HideSelectCardPanel();
        PlayerCardParent.gameObject.SetActive(false);
        NpcCardParent.gameObject.SetActive(false);

        // ADV表情,特效。
        GameObject tempAnimArea;
        if (TurtleGame.Instance.winer == CoinSurface.Front)
        {
            tempAnimArea = winAnimArea;
            await turtleGameAdv.PlayAdv(TurtleGameAdvType.PlayerWin);
        }
        else
        {
            tempAnimArea = loseAnimArea;
            await turtleGameAdv.PlayAdv(TurtleGameAdvType.NpcWin);
        }
        tempAnimArea.SetActive(true);

        // 结算
        if (isQuitHalfway)
        {
            Game.Sound.SoundPlayer.FadeToBgm(oldBgm, 0.5f, 0.5f, true);
            await UniTask.Delay(1200);
            await UI.Page.CloseCurrentPage();
        }
        else
        {
            var master = DataManager.Instance.Master.PuzzleExplore.FirstOrDefault(
            	a => a.Value.battleCharacterMasterId == TurtleGame.Instance.characterMasterId && a.Value.typeId == 13);
            var isFirst = await MissionService.MissionFinishExplorePuzzle(master.Key, TurtleGame.Instance.winer == CoinSurface.Front);
            await UI.Popup.ShowTinyGameResultAsync(master.Key, isFirst, TurtleGame.Instance.winer == CoinSurface.Front,
                () =>
                {
                    Game.Sound.SoundPlayer.FadeToBgm(oldBgm, 0.5f, 0.5f, true);
                    UI.Page.CloseCurrentPage();
                });
        }
    }

    public override void Dispose()
    {
        base.Dispose();

        turtleGameAdv.Dispose();
        if (bgObject != null)
        {
            Destroy(bgObject.gameObject);
            bgObject = null;
        }
    }
}
