﻿using TMPro;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Collections.Generic;
using UnityEngine.UI;
using Spine.Unity;
using DG.Tweening;

public enum TurtleGameAdvType
{
    /// <summary>
    /// 默认状态
    /// </summary>
    Default,
    /// <summary>
    /// Npc抽玩家牌前的犹豫状态
    /// </summary>
    NpcHesitate,
    /// <summary>
    /// Npc抽玩家牌时的动作
    /// </summary>
    NpcDrawCard,
    /// <summary>
    /// 抛完硬币后，Npc是先手
    /// </summary>
    NpcFirst,
    /// <summary>
    /// 抛完硬币后，Npc是后手
    /// </summary>
    NpcSecond,
    /// <summary>
    /// 玩家选中鬼牌
    /// </summary>
    PlayerSelectGhost,
    /// <summary>
    /// 玩家选中正常牌
    /// </summary>
    PlayerSelectNormal,
    /// <summary>
    /// 玩家抽走鬼牌
    /// </summary>
    PlayerGotGhost,
    /// <summary>
    /// 抽走玩家鬼牌
    /// </summary>
    NpcGotGhost,
    /// <summary>
    /// 玩家胜利
    /// </summary>
    PlayerWin,
    /// <summary>
    /// 奏者胜利
    /// </summary>
    NpcWin,
    /// <summary>
    /// 玩家15秒无操作
    /// </summary>
    PlayerNoOperate,
    /// <summary>
    /// 选了牌后，在一张牌停留超过15秒
    /// </summary>
    PlayerStay,
    /// <summary>
    /// 其他
    /// </summary>
    Other
}

public class TurtleGameAdv : MonoBehaviour
{
    private UIRTCamera mRTCamera;
    private RawImage standImage;
    private AdvTurtleGameMaster advTurtleGameMaster;
    private TurtleGameAdvType curAdvType;
    private string curMotionAnimName;
    private string curExpressionAnimName;
    GameObject curCharacterObject;
    SkeletonAnimation curSkeletonAnimation;

    public async UniTask InitializeAsync()
    {
        curAdvType = TurtleGameAdvType.Other;
        curMotionAnimName = "noMotion";
        curExpressionAnimName = "noExpression";
        advTurtleGameMaster = DataManager.Instance.Master.AdvTurtleGame.GetValueOrDefault(TurtleGame.Instance.characterMasterId);

        if (mRTCamera == null)
        {
            var rtc = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/RTCamera");
            mRTCamera = rtc.GetComponent<UIRTCamera>();
        }
        curCharacterObject = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/chara/" + advTurtleGameMaster.objectName);
        curSkeletonAnimation = curCharacterObject.GetComponent<SkeletonAnimation>();
        curSkeletonAnimation.Initialize(false);
        curSkeletonAnimation.Update(0.0f);
        curSkeletonAnimation.LateUpdate();
        mRTCamera.Setup(curCharacterObject);
        standImage = transform.GetComponent<RawImage>();
        standImage.gameObject.SetActive(true);
        standImage.texture = mRTCamera.GetRenderTexture();
        standImage.SetNativeSize();
        standImage.rectTransform.anchoredPosition = new Vector3(0, advTurtleGameMaster.startPosY);

        await PlayAdv(TurtleGameAdvType.Default);
    }

    public void AdvEnterAnim(float durTime)
    {
        standImage.rectTransform.DOAnchorPosY(advTurtleGameMaster.endPosY, durTime);
        transform.DOScale(advTurtleGameMaster.endScale / 100.0f, durTime);
    }
    public void AdvExitAnim(float durTime)
    {
        standImage.rectTransform.DOAnchorPosY(advTurtleGameMaster.startPosY, durTime);
        transform.DOScale(1.0f, durTime);
    }

    public async UniTask PlayAdv(TurtleGameAdvType type)
    {
        if (TurtleGameAdvType.PlayerSelectNormal == type)
        {
            // 这个状态较特殊
        }
        else
        {
            if (curAdvType == type) return;
        }
        curAdvType = type;

        string motionAnimName = advTurtleGameMaster.DefaultBody;
        string expressionAnimName = advTurtleGameMaster.Default;
        int tempIndex = 0;

        switch (type)
        {
            case TurtleGameAdvType.Default:
                motionAnimName = advTurtleGameMaster.DefaultBody;
                expressionAnimName = advTurtleGameMaster.Default;
                break;
            case TurtleGameAdvType.NpcHesitate:
                motionAnimName = advTurtleGameMaster.NpcHesitate;
                expressionAnimName = advTurtleGameMaster.NpcHesitate;
                break;
            case TurtleGameAdvType.NpcDrawCard:
                tempIndex = GetIndexByWeight(advTurtleGameMaster.NpcDrawCardWt);
                motionAnimName = advTurtleGameMaster.NpcDrawCardBody[tempIndex];
                expressionAnimName = advTurtleGameMaster.NpcDrawCard[tempIndex];
                break;
            case TurtleGameAdvType.NpcFirst:
                tempIndex = GetIndexByWeight(advTurtleGameMaster.NpcFirstWt);
                expressionAnimName = advTurtleGameMaster.NpcFirst[tempIndex];
                break;
            case TurtleGameAdvType.NpcSecond:
                tempIndex = GetIndexByWeight(advTurtleGameMaster.NpcSecondWt);
                expressionAnimName = advTurtleGameMaster.NpcSecond[tempIndex];
                break;
            case TurtleGameAdvType.PlayerSelectGhost:
                tempIndex = GetIndexByWeight(advTurtleGameMaster.PlayerSelectGhostWt);
                expressionAnimName = advTurtleGameMaster.PlayerSelectGhost[tempIndex];
                break;
            case TurtleGameAdvType.PlayerSelectNormal:
                tempIndex = GetIndexByWeight(advTurtleGameMaster.PlayerSelectNormalWt);
                expressionAnimName = advTurtleGameMaster.PlayerSelectNormal[tempIndex];
                break;
            case TurtleGameAdvType.PlayerGotGhost:
                tempIndex = GetIndexByWeight(advTurtleGameMaster.PlayerGotGhostWt);
                expressionAnimName = advTurtleGameMaster.PlayerGotGhost[tempIndex];
                break;
            case TurtleGameAdvType.NpcGotGhost:
                tempIndex = GetIndexByWeight(advTurtleGameMaster.NpcGotGhostWt);
                expressionAnimName = advTurtleGameMaster.NpcGotGhost[tempIndex];
                break;
            case TurtleGameAdvType.PlayerWin:
                tempIndex = GetIndexByWeight(advTurtleGameMaster.PlayerWinWt);
                motionAnimName = advTurtleGameMaster.PlayerWinBody[tempIndex];
                expressionAnimName = advTurtleGameMaster.PlayerWin[tempIndex];
                break;
            case TurtleGameAdvType.NpcWin:
                tempIndex = GetIndexByWeight(advTurtleGameMaster.NpcWinWt);
                motionAnimName = advTurtleGameMaster.NpcWinBody[tempIndex];
                expressionAnimName = advTurtleGameMaster.NpcWin[tempIndex];
                break;
            case TurtleGameAdvType.PlayerNoOperate:
                tempIndex = GetIndexByWeight(advTurtleGameMaster.PlayerNoOperateWt);
                expressionAnimName = advTurtleGameMaster.PlayerNoOperate[tempIndex];
                break;
            case TurtleGameAdvType.PlayerStay:
                tempIndex = GetIndexByWeight(advTurtleGameMaster.PlayerStayWt);
                expressionAnimName = advTurtleGameMaster.PlayerStay[tempIndex];
                break;
        }


        AdvSpineMaster motionAdv = DataManager.Instance.Master.AdvSpine[motionAnimName];
        AdvSpineMaster expressionAdv = DataManager.Instance.Master.AdvSpine[expressionAnimName];
        await SetupCharacter(motionAdv.body, motionAdv.waiting, expressionAdv.expression, expressionAdv.expression_loop, expressionAdv.mouthClosed, expressionAdv.openMouth, motionAnimName, expressionAnimName);
    }

    // 有空得再把这个方法改一下： "参数" To "Model"
    // 有空得再把这个方法改一下： "参数" To "Model"
    private async UniTask SetupCharacter(string body, string waiting, string expression, string expressionLoop, string mouthClosed, string openMouth, string motionAnimName, string expressionAnimName)
    {
        if (curMotionAnimName != motionAnimName)
        {
            if (!string.IsNullOrEmpty(body))
            {
                curSkeletonAnimation.AnimationState.SetAnimation(0, body, false);
            }
            else if (!string.IsNullOrEmpty(waiting))
            {
                curSkeletonAnimation.AnimationState.SetAnimation(0, waiting, true);
            }

            curMotionAnimName = motionAnimName;
        }


        if (curExpressionAnimName != expressionAnimName)
        {
            if (!string.IsNullOrEmpty(expression))
            {
                curSkeletonAnimation.AnimationState.SetAnimation(1, expression, false);
            }
            else if (!string.IsNullOrEmpty(expressionLoop))
            {
                curSkeletonAnimation.AnimationState.SetAnimation(1, expressionLoop, true);
            }

            if (!string.IsNullOrEmpty(mouthClosed))
            {
                curSkeletonAnimation.AnimationState.SetAnimation(2, mouthClosed, false);
            }
            else if (!string.IsNullOrEmpty(openMouth))
            {
                curSkeletonAnimation.AnimationState.SetAnimation(2, openMouth, false);
            }

            curExpressionAnimName = expressionAnimName;
        }
    }

    // 从配置表来看，此处不该为权重，应该算是概率。 不过表中列名是某某Wt,这里参数名也同步。
    private int GetIndexByWeight(List<int> weights)
    {
        if (weights.Count == 1) return 0;

        int totalNum = 0;
        foreach (int item in weights)
        {
            totalNum += item;
        }

        int tempPoint = 0;
        totalNum = UnityEngine.Random.Range(1, totalNum + 1);
        for (int i = 0; i < weights.Count; i++)
        {
            tempPoint += weights[i];
            if (totalNum <= tempPoint) return i;
        }

        return 0;
    }

    public void Dispose()
    {
        if (mRTCamera != null)
        {
            Destroy(mRTCamera.gameObject);
            mRTCamera = null;
        }
    }
}