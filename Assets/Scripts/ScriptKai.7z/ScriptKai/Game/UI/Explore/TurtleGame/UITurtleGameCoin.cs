﻿using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using System.Collections.Generic;
using DG.Tweening;
using System.Collections;



public class UITurtleGameCoin : MonoBehaviour
{
    /// <summary>
    /// 当前朝上的是哪一面
    /// </summary>
    private CoinSurface curSurface ;
    [SerializeField] private bool IsClockWise;
    [SerializeField] private GameObject Front;
    [SerializeField] private GameObject Back;


    public async UniTask Init()
    {
        // 默认正面朝上
        curSurface = CoinSurface.Front;
        Front.transform.eulerAngles = new Vector3(0, 0, 0);
        Back.transform.eulerAngles = new Vector3(0, -90, 0);

        // 加载硬币的正、反面图标
        // Front.transform  
        // icon.sprite = BattleMain.Instance.battleAdmin.battleAssetLoader.GetSpriteSmall(AssetPath. , "icon_power");
    }

    public async UniTask StartRotate(CoinSurface finalSurface)
    {
        // 旋转硬币。
        for (int i = 0; i < 10; i++)
        {
            if (curSurface == CoinSurface.Front)
            {
                await RotateToBack();
            }
            else
            {
                await RotateToFront();
            }
        }

        // 根据结果,矫正硬币朝向
        if (finalSurface != curSurface)
        {
            if (curSurface == CoinSurface.Front)
            {
                await RotateToBack();
            }
            else
            {
                await RotateToFront();
            }
        }

        // Debug.Log($"Gx: 哪一面先手<最终显示>：{finalSurface}。");
    }

    private async UniTask RotateToBack()
    {
        Front.transform.DORotate(new Vector3(0, 90, 0), 0.1f).OnComplete(() => { Front.transform.eulerAngles = new Vector3(0, -90, 0); });
        await UniTask.Delay(100);
        Back.transform.DORotate(new Vector3(0, 0, 0), 0.1f);
        await UniTask.Delay(100);
        curSurface = CoinSurface.Back;
    }

    private async UniTask RotateToFront()
    {
        Back.transform.DORotate(new Vector3(0, 90, 0), 0.1f).OnComplete(() => { Back.transform.eulerAngles = new Vector3(0, -90, 0); });
        await UniTask.Delay(100);
        Front.transform.DORotate(new Vector3(0, 0, 0), 0.1f);
        await UniTask.Delay(100);
        curSurface = CoinSurface.Front;
    }
}
