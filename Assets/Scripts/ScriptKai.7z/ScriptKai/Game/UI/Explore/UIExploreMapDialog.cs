﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIExploreMapDialog : UIDialogBase
{
    [SerializeField] UIButton hallButton;
    [SerializeField] UIButton entranceButton;
    [SerializeField] UIButton shopButton;
    [SerializeField] UIButton wingButton;
    [SerializeField] UIButton trainingButton;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        hallButton.OnTouchUpInside.GuardSubscribeAsync(onClickHall).AddTo(mSubscriptions);
        entranceButton.OnTouchUpInside.GuardSubscribeAsync(onClickEntrance).AddTo(mSubscriptions);
        trainingButton.OnTouchUpInside.GuardSubscribeAsync(onClickTraining).AddTo(mSubscriptions);
        wingButton.OnTouchUpInside.GuardSubscribeAsync(onClickWing).AddTo(mSubscriptions);
        shopButton.OnTouchUpInside.GuardSubscribeAsync(onClickShop).AddTo(mSubscriptions);
    }

    private async UniTask onClickHall()
    {
        Hide();
        await gotoMap("advBuilding[10]");
    }

    private async UniTask onClickEntrance()
    {
        Hide();
        await gotoMap("advBuilding[7]");
    }

    private async UniTask onClickTraining()
    {
        Hide();
        await gotoMap("advBuilding[9]");
    }

    private async UniTask onClickShop()
    {
        Hide();
        await gotoMap("advBuilding[11]");
    }

    private async UniTask onClickWing()
    {
        Hide();
        await gotoMap("advBuilding[8]");
    }

    private async UniTask gotoMap(string label)
    {
        var master = DataManager.Instance.Master.Location[label];
        await MapSceneManager.Instance.ChangeAsync(master.scene, master.startPos);
    }
}
