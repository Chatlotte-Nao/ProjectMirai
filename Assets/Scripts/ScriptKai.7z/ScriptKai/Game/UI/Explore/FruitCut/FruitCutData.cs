﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitCutData
{
    public float time = 30;
    public List<int> value = new List<int>();
    public List<int> speed = new List<int>();
    public float a;
    public List<float> comboA = new List<float>();
    public List<int> score = new List<int>();
    public List<int> comboScore = new List<int>();
    public List<int> number = new List<int>();
    public List<string> fruitTypes = new List<string>();
    public int inverval = 0;
    public Dictionary<string, int> fruitValues = new Dictionary<string, int>();
    public Dictionary<string, int> fruitscore = new Dictionary<string, int>();
    public Dictionary<string, int> fruitspeed = new Dictionary<string, int>();
    public int targetScore;



    public void SetUpData(int levelId)
    {
        int id = 0;
        foreach (var item in DataManager.Instance.Master.FruitCut)
        {
            if (item.Value.levelID == levelId)
                id = item.Value.id;
        }
        if (id == 0) return;
        this.targetScore = DataManager.Instance.Master.FruitCut[id].targetScore;
        this.a = ((float) DataManager.Instance.Master.FruitCut[id].a)/10;
        this.value = DataManager.Instance.Master.FruitCut[id].value;
        this.speed = DataManager.Instance.Master.FruitCut[id].speed;
        this.inverval = DataManager.Instance.Master.FruitCut[id].interval;
        this.number = DataManager.Instance.Master.FruitCut[id].number;
        this.fruitTypes = DataManager.Instance.Master.FruitCut[id].fruitsTypes;
        this.score = DataManager.Instance.Master.FruitCut[id].score;
        this.comboScore = DataManager.Instance.Master.FruitCut[id].comboScore;
        for (int i = 0; i < DataManager.Instance.Master.FruitCut[id].comboA.Count; i++)
        {
            this.comboA.Add(DataManager.Instance.Master.FruitCut[id].comboA[i] / 10f);
        }
        for (int i = 0; i < fruitTypes.Count; i++)
        {
            fruitValues[fruitTypes[i]] = value[i];
        }
        for (int i = 0; i < fruitTypes.Count; i++)
        {
            fruitscore[fruitTypes[i]] = score[i];
        }
        for (int i = 0; i < fruitTypes.Count; i++)
        {
            fruitspeed[fruitTypes[i]] = speed[i];
        }

    }




}
