﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;

public class UIFruitCutMainWindow : UIDialogBase
{
    public UIButton exitBtn;
    [SerializeField] GameObject pauseView;

    public UnityEvent OnComplete = new UnityEvent();
    public UnityEvent OnPuzzleFailed = new UnityEvent();


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        exitBtn.OnTouchDown.Subscribe(() => { OnClickExit(FruitCutController.instance.gamRes); }).AddTo(mSubscriptions);
    }

    public async UniTask Setup(int mlevelID)
    {

        FruitCutController.instance.data.SetUpData(mlevelID);
    }
    void OnClickExit(bool suc)
    {
        if (suc)
        {
            OnComplete.Invoke();

        }
        else
        {
            OnPuzzleFailed.Invoke();
        }
    }
}
