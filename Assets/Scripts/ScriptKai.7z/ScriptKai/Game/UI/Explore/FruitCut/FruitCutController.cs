﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Cysharp.Threading.Tasks;
using TMPro;
using Pheonix.Core;
using UnityEngine.EventSystems;
using Spine.Unity;

public class FruitCutController : MonoBehaviour,IDragHandler
{

    [SerializeField] Button continueBtn;
    [SerializeField] Button endBtn;
    [SerializeField] List<GameObject> fruits = new List<GameObject>();
    [SerializeField] GameObject spawnPoint;
    [SerializeField] GameObject[] target;
    [SerializeField] GameObject highest;
    [SerializeField] UIText comboText;
    [SerializeField] UIFruitCutMainWindow fruitMain;
    [SerializeField] GameObject endWindow;
    [SerializeField] UIText lastScore;
    [SerializeField] List<GameObject> hp = new List<GameObject>();
    [SerializeField] Image goalBar;
    [SerializeField] GameObject[] goalTarget;
    [SerializeField] UIText successText;
    [SerializeField] SkeletonGraphic miniCharacter;
    [SerializeField] SkeletonGraphic miniMainCharacter;
    [SerializeField] GameObject cutAni;
    [SerializeField] GameObject result;
    [SerializeField] SkeletonGraphic resultAni;
    public bool gamRes = false;
    public static FruitCutController instance;
    public float a = 0;
    public int realtimeCount;
    public int plusSpeed = 0;
    private float comboTime;
    private int comboCount = 0;
    private Vector3 startPos;
    private int gameScore;
    int numberCount = 0;
    public FruitCutData data = new FruitCutData();
    private bool gaming = true;
    GameObject screenEffect;
    void Awake()
    {
        instance = this;
        fruitMain.exitBtn.gameObject.SetActive(false);
    }
    
    // Start is called before the first frame update
    void Start()
    {
       screenEffect =  GameObject.Find("ScreenEffect");
        if(screenEffect != null)
        {
            screenEffect.SetActive(false);
        }
       
        gameScore = 0;
        goalBar.fillAmount = 0;
        a = data.a;
        goalTarget[0].GetComponentInChildren<UIText>().SetRawText((data.targetScore / 4).ToString());
        goalTarget[1].GetComponentInChildren<UIText>().SetRawText((data.targetScore / 4 * 2).ToString());
        goalTarget[2].GetComponentInChildren<UIText>().SetRawText(data.targetScore.ToString());
        miniCharacter.AnimationState.SetAnimation(0, "wait_01", false);
        miniMainCharacter.AnimationState.SetAnimation(0, "wait_01", false);
        InvokeRepeating("GetRanId", 0, data.inverval);
        if (!cutAni.activeSelf)
        {
            cutAni.SetActive(true);
            cutAni.GetComponent<SkeletonGraphic>().AnimationState.SetAnimation(0, "ani_01", true);
        }

        miniMainCharacter.AnimationState.SetAnimation(0, "act_07", true);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButton(0))
            startPos = Input.mousePosition;
        goalBar.fillAmount = (float)gameScore / (float)data.targetScore;
        if(numberCount >= data.number.Count || hp.Count <= 0)
        {
           if(hp.Count<=0)
            {
                for (int i = 2; i < spawnPoint.transform.childCount; i++)
                {
                    Destroy(spawnPoint.transform.GetChild(i).gameObject,0.2f);
                }
                GameEnd(false);
                return;
            }
            else if (realtimeCount == 0 && gameScore < data.targetScore)
            {
                GameEnd(false);
                return;
            }  
            else
                CancelInvoke();
        }
        if (gameScore >= data.targetScore)
        {
            if (goalTarget[2].GetComponent<Image>().color != Color.yellow)
                goalTarget[2].GetComponent<Image>().color = Color.yellow;
            for (int i = 2; i < spawnPoint.transform.childCount; i++)
            {
                Destroy(spawnPoint.transform.GetChild(i).gameObject, 0.2f);
            }
            GameEnd(true);
            return;
        }
       
        if(comboTime >0)
        {
            if(comboCount > 3)
            {
                comboText.gameObject.SetActive(true);
                comboText.SetRawText($"Combo  X{comboCount.ToString()}");

            }
          
            comboTime -= Time.deltaTime;
        }
        else
        {
            comboCount = 0;
            comboText.gameObject.SetActive(false);
        }

        if ((float)gameScore / (float)data.targetScore > 0.25f)
        {
            if(goalTarget[0].GetComponent<Image>().color != Color.yellow)
                goalTarget[0].GetComponent<Image>().color = Color.yellow;
        }
        if ((float)gameScore / (float)data.targetScore > 0.5f)
        {
            if(goalTarget[1].GetComponent<Image>().color != Color.yellow)
                 goalTarget[1].GetComponent<Image>().color = Color.yellow;
        }
        if (gameScore >= data.targetScore)
        {
            if (goalTarget[2].GetComponent<Image>().color != Color.yellow)
                goalTarget[2].GetComponent<Image>().color = Color.yellow;
        }

    }

    public void RayAndCut()
    {
        var ray = Camera.main.ScreenPointToRay(startPos);

        if (Physics.Raycast(ray, out RaycastHit hit))
        {
           
            foreach (var item in fruits)
            {
                if (hit.collider.gameObject.name == item.name + "(Clone)")
                {
                    hit.collider.enabled = false;
                    comboTime = 5f;
                    if(hit.collider.gameObject.GetComponent<FruitIndex>().score != 0)
                         comboCount++;
                    else
                        comboTime = 0;
                    
                    //水果裂开动画
                    FruitCutAni(hit.collider.gameObject);
                    AsyncManager.Instance.StartAsync(ChangeAnimationAsync(true,false)); //小人动画
                    //算分
                    if (hit.collider.gameObject.GetComponent<FruitIndex>().score == 0)
                    {
                        removeHp();
                        return;
                    }
                    if(comboCount >3)
                    {
                        hit.collider.gameObject.GetComponent<FruitMove>().isCut = true;
                        gameScore += hit.collider.gameObject.GetComponent<FruitIndex>().score * 2;
                    
                        if (comboCount >= data.comboScore.Count)
                        {
                           // Debug.Log("加" + data.comboScore[data.comboScore.Count - 1]);
                            gameScore += data.comboScore[data.comboScore.Count - 1];
                    
                        }
                           
                        
                        else
                        {
                          //  Debug.Log("加" + data.comboScore[comboCount]);
                            gameScore += data.comboScore[comboCount];
                         
                        }
                           
                        if (comboCount > 4)
                        {
                            if (plusSpeed >= data.comboA.Count)
                                return;
                            a = data.comboA[plusSpeed];
                            plusSpeed++;
                        }
                        //score.SetRawText($"Score: {gameScore}");
                    }
                    else
                    {
                        hit.collider.gameObject.GetComponent<FruitMove>().isCut = true;
                        gameScore += hit.collider.gameObject.GetComponent<FruitIndex>().score;
            
                    }
                    
                    
                    //hit.collider.gameObject.GetComponent<FruitIndex>().score;
                    //Destroy(hit.collider.gameObject, 0.5f);
                    
                }
                  
            }
        }
    }
   

    public void Create(string type)
    {
        for (int i = 0; i < fruits.Count; i++)
        {
            if (fruits[i].name == type)
            {
                //int count = Random.Range(1, 4);
                //Debug.Log(count);
                //Debug.Log(type);
                var go = GameObject.Instantiate(fruits[i], spawnPoint.transform);
                
                go.transform.position = spawnPoint.transform.position + new Vector3(Random.Range(target[0].transform.position.x, target[1].transform.position.x), 0, 0);
                //go.GetComponent<Rigidbody>().AddForce(new Vector3(Random.Range(-20,20), 30f,0),ForceMode.Impulse);
                var moveData = go.GetComponent<FruitMove>();
                //moveData.fcc = this;
                moveData.target = Vector3.Distance(go.transform.position, target[0].transform.position) > Vector3.Distance(go.transform.position, target[1].transform.position) ? target[0] : target[1];
                moveData.highest = highest;
                moveData.speed = (float)data.fruitspeed[type];
                go.GetComponent<FruitIndex>().type = type;
                go.GetComponent<FruitIndex>().score = data.fruitscore[type];
                //go.GetComponent<FruitIndex>().score = data.score[i];
            }

        }
    
    }
    private int GetTotalWeight()
    {
        int totalWeight = 0;
        foreach (var weight in data.fruitValues.Values)
        {
            totalWeight += weight;
        }
        return totalWeight;
    }

    int count = 0;
    /// <summary>
    /// 得到随机的id
    /// </summary>
    private void GetRanId()
    {

        if (numberCount > data.number.Count)
            return;
       
        for (int i = 0; i < data.number[numberCount]; i++)
        {
            //Debug.Log(numberCount+ ":   " + data.number[numberCount]);
            int ranNum = Random.Range(0, GetTotalWeight() + 1);
            int counter = 0;
            foreach (var temp in data.fruitValues)
            {
                counter += temp.Value;
                if (ranNum <= counter)
                {
                   // Debug.Log("随机数：" + ranNum + ",随机id：" + temp.Key);
                    //Debug.Log("调用  " + count++ + "次");
                    Create(temp.Key);
                    realtimeCount++;
                    break;
                }
            }
            //Debug.LogError("没有随机到，随机数为：" + ranNum);
        }
        AsyncManager.Instance.StartAsync(ChangeAnimationAsync(false, true));
        numberCount++;
        //Debug.Log(realtimeCount);
        return;
    }
    bool resultOnce = false;
     private void GameEnd(bool isSuccess)
    {
        
        CancelInvoke();
        miniMainCharacter.AnimationState.SetAnimation(0, "wait_01", true);
        cutAni.SetActive(false);
        
       
        if (isSuccess)
        {
            if(gameScore >= data.targetScore)
                successText.SetRawText($"Success!");
            else
                successText.SetRawText($"Failed!");
            lastScore.SetRawText($"Score: {gameScore}");

           
        }
        else
        {
            lastScore.SetRawText($"Score: {gameScore}");
            successText.SetRawText($"Failed!");
        }
        
        if (!resultOnce)
        {
            screenEffect.SetActive(true);
            resultOnce = true;
            result.SetActive(true);
            result.GetComponent<Animator>().Update(1);
            gamRes = isSuccess;
            
           
            AsyncManager.Instance.StartAsync(EndAni(isSuccess));
            fruitMain.exitBtn.gameObject.SetActive(true);

        }
       


    }
    public async  UniTask EndAni(bool b)
    {
        
        if (b)
        {

            resultAni.AnimationState.SetAnimation(0, "chenggong", false);
            await UniTask.DelayFrame(50);
            endWindow.SetActive(true);
            await UniTask.DelayFrame(50);

        }
        else
        {
            resultAni.AnimationState.SetAnimation(0, "shibai", false);
            await UniTask.DelayFrame(50);
            endWindow.SetActive(true);
            await UniTask.DelayFrame(50);
        }
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (hp.Count <= 0)
            return;
        RayAndCut();
    }

    public void removeHp()
    {
        if (hp.Count <= 0)
        {
            CancelInvoke();
            return;
        }
            
        Destroy(hp[0]);
        hp.RemoveAt(0);
        
    }
    bool once = false;
    public async UniTask ChangeAnimationAsync(bool cut,bool throws)
    {


       
        //if (cut && !once)
        //{
          
        //    once = true;

        //}

        if (throws)
            miniCharacter.AnimationState.SetAnimation(0, "sit", false);
        else
            miniCharacter.AnimationState.SetAnimation(0, "walk_01", false);


        await UniTask.Delay(200);
        //if (cutAni.activeSelf)
        //{
        //    cutAni.SetActive(false);
        //}
        miniCharacter.AnimationState.SetAnimation(0, "wait_01", false);
        //miniMainCharacter.AnimationState.SetAnimation(0, "wait_01", false);
       
    }

    public void FruitCutAni(GameObject o)
    {
       // Debug.Log(Random.Range(2, 5).ToString());
        if (o.GetComponent<SkeletonGraphic>() != null)
        {
            switch (o.GetComponent<FruitIndex>().type)
            {
                case "Rapple":
                    o.GetComponent<SkeletonGraphic>().AnimationState.SetAnimation(0, "Rapple_"+Random.Range(2,5).ToString(), false);
                    break;
                case "Ybanana":
                    o.GetComponent<SkeletonGraphic>().AnimationState.SetAnimation(0, "Ybanana1_" + Random.Range(2, 5).ToString(), false);
                    break;
                case "Gbanana":
                    o.GetComponent<SkeletonGraphic>().AnimationState.SetAnimation(0, "Gbanana1_" + Random.Range(2, 5).ToString(), false);
                    break;
                case "Gapple":
                    o.GetComponent<SkeletonGraphic>().AnimationState.SetAnimation(0, "Gapple_" + Random.Range(2, 5).ToString(), false);
                    break;
            }


        }
           
        //GameObject left = o.GetComponent<FruitMove>().left;
        //GameObject right = o.GetComponent<FruitMove>().right;
        //if(left!=null && right!=null)
        //{
        //    o.GetComponent<Image>().color = new Color(0, 0, 0, 0);
        //    left.SetActive(true);
        //    right.SetActive(true);
        //    left.GetComponent<Rigidbody>().AddForce(new Vector3(-o.GetComponent<FruitMove>().Vxt, 0, 0), ForceMode.Impulse);
        //    right.GetComponent<Rigidbody>().AddForce(new Vector3(o.GetComponent<FruitMove>().Vxt, 0, 0), ForceMode.Impulse);
        //}
    }
}
