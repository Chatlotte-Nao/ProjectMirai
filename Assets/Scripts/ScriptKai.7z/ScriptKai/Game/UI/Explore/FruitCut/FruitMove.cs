﻿using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitMove : MonoBehaviour
{
    public float g = 9.8f;

    public GameObject target;
    public GameObject highest;
    public GameObject left;
    public GameObject right;
    public float speed; //水平初速度
    private float verticalSpeed; //垂直速度
    private Vector3 moveDirection;
    private float height;
    private float angleSpeed; //角速度
    private float angle;
    private float offset;
    public float a; //加速度
    public float Vxt = 0;
    public bool isCut = false;
    public bool once = false;
    void Start()
    {
        a = FruitCutController.instance.a;
        height = Random.Range( highest.transform.position.y,highest.transform.position.y*4/3);
        offset = Random.Range(0, target.transform.position.x * 2);
        float tmepDistance = Vector3.Distance(transform.position, target.transform.position + new Vector3(offset,0,0));
        var Vxt = Mathf.Sqrt(Mathf.Abs(2 * a * tmepDistance + speed * speed));
        float tempTime = (Vxt - speed) / a;
        float riseTime, downTime;
        riseTime =  tempTime / 2;
        downTime = tempTime;
        g = 2 * height /(riseTime * riseTime);
        verticalSpeed = Mathf.Sqrt(2 * g * height);

        float tempTan = verticalSpeed / speed;
        double hu = Mathf.Atan(tempTan);
        angle = (float)(180 / Mathf.PI * hu);
        transform.eulerAngles = new Vector3(transform.eulerAngles.x, transform.eulerAngles.y, -angle);
        angleSpeed = angle / riseTime;

        moveDirection = target.transform.position - transform.position;
    }
    private float time;

    void FixedUpdate()
    {
        if (a != FruitCutController.instance.a)
        {
            a = FruitCutController.instance.a;
           // Debug.Log("加速度改变:" + a);
           
        }
            
        time += Time.fixedDeltaTime;
        float test = verticalSpeed - g * time;
        Vxt = (speed + a * time);
        if (transform.position.y >= height)
            g *= 1.5f;
        transform.Translate(moveDirection.normalized * Vxt * Time.fixedDeltaTime, Space.World);
        transform.Translate(Vector3.up * test * Time.fixedDeltaTime, Space.World);
        float testAngle = -angle + angleSpeed * time;
        transform.eulerAngles = new Vector3(transform.eulerAngles.x, transform.eulerAngles.y, testAngle);
        if (transform.position.y < target.transform.position.y)
        {
            //finish
            if (!this.isCut && this.gameObject.GetComponent<FruitIndex>().score != 0)
            {
                Destroy(this.gameObject);
                FruitCutController.instance.removeHp();
                AsyncManager.Instance.StartAsync(FruitCutController.instance.ChangeAnimationAsync(false,false));
                FruitCutController.instance.realtimeCount--;
            }
            
            
            if (this.gameObject!=null)
                Destroy(this.gameObject, 0.5f);
            if(!once)
            {
                FruitCutController.instance.realtimeCount--;
                once = true;
            }
            return;
        }
    }
}
