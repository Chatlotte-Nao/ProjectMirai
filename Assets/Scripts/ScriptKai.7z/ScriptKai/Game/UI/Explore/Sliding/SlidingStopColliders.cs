﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlidingStopColliders : MonoBehaviour
{
   

    public bool AdjustBoxCollider = false;
    private BoxCollider2D boxCollider2D;
    private RectTransform gameObject;
    public bool Updating = false;
    // Use this for initialization
    void Start()
    {
        gameObject = this.GetComponent<RectTransform>();
        boxCollider2D = this.GetComponent<BoxCollider2D>();

        if (boxCollider2D == null)
        {
            Debug.Log("can't find collider");
            return;
        }
        else
        {

            if (AdjustBoxCollider == true)
            {
                boxCollider2D.offset = gameObject.rect.center;      //把box collider设置到物体的中心
                boxCollider2D.size = new Vector2(gameObject.rect.width, gameObject.rect.height);    //改变collider大小
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Updating)
        {
            if (boxCollider2D == null)
            {
                Debug.Log("can't find collider");
                return;
            }
            else
            {

                if (AdjustBoxCollider == true)
                {
                    boxCollider2D.offset = gameObject.rect.center;      //把box collider设置到物体的中心
                    boxCollider2D.size = new Vector2(gameObject.rect.width, gameObject.rect.height);    //改变collider大小
                }
            }
        }
    }
}