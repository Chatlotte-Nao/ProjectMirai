﻿using Cysharp.Threading.Tasks;
using Pheonix.Core;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class SlidingMapController : MonoBehaviour
{
    public static  SlidingMapController instance;

    SlidingDataFormate dataFormate = new SlidingDataFormate();

    public UnityEvent RoundComplete;
    public float MoveSpeed=2f;


    [SerializeField] UIButton BtnOut;
    [SerializeField] UIButton BtnIn;
    [SerializeField] UIButton BtnUp;
    [SerializeField] UIButton BtnDown;
    [SerializeField] UIButton headButton;
    
    [SerializeField] Image headIcon ;
    
    [SerializeField] UIText dialogText;
    
    
    [SerializeField] Rigidbody2D leftRig;
    [SerializeField] Rigidbody2D rightRig;
    GameObject nowRoundMap;

    private int dialogIndex = 0;
    private void Awake()
    {
        instance = this;
    }

    public void Init(SlidingDataFormate dataFormate)
    {
        this.dataFormate= dataFormate;
        MoveSpeed = dataFormate.moveSpeed;
        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(); });
        //headIcon.sprite = ResourceManager.Instance.LoadSprite("RoundIcon",
        //    DataManager.Instance.Master.CharacterResource[dataFormate.charaID].userIconId);
    }
    private void Start()
    {
        
        CreatMap(dataFormate.mapQueue.Dequeue());
        RoundComplete.AddListener(RoundEnd);
        InitBtns();
        SetDialogText();
    }
    Dir nowDir=Dir._zero;
    private void InitBtns()
    {
        BtnIn.onClickDown.AddListener((o) =>
        {
            nowDir = Dir._in;
        });
        
        BtnOut.onClickDown.AddListener((o) =>
        {
            nowDir = Dir._out;
        });
        
        BtnDown.onClickDown.AddListener((o) =>
        {
            nowDir = Dir._down;
        });
        
        BtnUp.onClickDown.AddListener((o) =>
        {
            nowDir = Dir._up;
        });

        BtnIn.onClickUp.AddListener((o) =>
        {
            nowDir = Dir._zero;
        });
        
        BtnOut.onClickUp.AddListener((o) =>
        {
            nowDir = Dir._zero;
        });
        
        BtnDown.onClickUp.AddListener((o) =>
        {
            nowDir = Dir._zero;
        });
        
        BtnUp.onClickUp.AddListener((o) =>
        {
            nowDir = Dir._zero;
        });

        headButton.onClick.AddListener((o) =>
        {
            SetDialogText();
        });


    }

    private void SetDialogText()
    {
        dialogText.SetFormat( LocalizeManager.DATA_TYPE.EXPLORE,dataFormate.dialogKey[dialogIndex]);
        dialogIndex = dialogIndex >= dataFormate.dialogKey.Count-1 ? 0 : dialogIndex+1;
        
    }


    private void FixedUpdate()
    {
        if (leftRig != null && rightRig != null)
        {
            PlayerMove(nowDir);
        }

    }


    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.G))
        {
            RoundComplete.Invoke();
            //UIAnimationPlayer.PlayAsync()
        }
    }

    async private void RoundEnd()
    {
        Destroy(nowRoundMap);
        var animation = UISlidingMainWindow.instance.GetComponent<Animation>();
        var RoundEndAnimationClip = UISlidingMainWindow.instance.NextRoundAnimation;
        int NextRoundIndex=-1;
        if (NextRoundExist(out NextRoundIndex))
        {
            Debug.Log(NextRoundIndex+"animationStart");
            await UIAnimationPlayer.PlayAsync(animation, RoundEndAnimationClip);
            Debug.Log("endAnimation");
            CreatMap(NextRoundIndex);

        }
        else
        {
            Debug.Log("END");
            UISlidingMainWindow.instance.GameOver();
        }
        //throw new NotImplementedException();
    }

    private bool NextRoundExist(out int nextLevelIndex)
    {
        try
        {
            nextLevelIndex = dataFormate.mapQueue.Dequeue();
        }
        catch
        {
            nextLevelIndex = -1;
            return false;
        }
        return true;
    }

    private void CreatMap(int Index)
    {
        nowRoundMap = Instantiate(UISlidingMainWindow.instance.Maps[Index], UISlidingMainWindow.instance.ImageBG);
        // nowRoundMap = Instantiate(UISlidingMainWindow.instance.Maps[0], UISlidingMainWindow.instance.ImageBG);
        leftRig = GameObject.Find("LeftPlayer").GetComponent<Rigidbody2D>();
        rightRig = GameObject.Find("RightPlayer").GetComponent<Rigidbody2D>();
    }

    private async UniTask LoadSpriteAsync()
    {
        headIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("RoundIcon",DataManager.Instance.Master.CharacterResource[dataFormate.charaID].userIconId);
    }


    #region PlayerControll
    enum Dir
    {
        _in,
        _out,
        _down,
        _up,
        _zero,
    }
    void PlayerMove(Dir dir)
    {
        leftRig.GetComponent<RectTransform>().anchoredPosition = new Vector2(-rightRig.GetComponent<RectTransform>().anchoredPosition.x, rightRig.GetComponent<RectTransform>().anchoredPosition.y);

        if (dir == Dir._zero)
        {
            rightRig.velocity = Vector2.zero;
            leftRig.velocity = Vector2.zero;
        }
        switch (dir)
        {
            case Dir._in:
                rightRig.velocity = Vector2.left * MoveSpeed;
                break;
            case Dir._out:
                rightRig.velocity = Vector2.right * MoveSpeed;
                break;
            case Dir._down:
                rightRig.velocity = Vector2.down * MoveSpeed;
                break;
            case Dir._up:
                rightRig.velocity = Vector2.up * MoveSpeed;
                break;
            default:
                break;
        }
    }
    #endregion


}
