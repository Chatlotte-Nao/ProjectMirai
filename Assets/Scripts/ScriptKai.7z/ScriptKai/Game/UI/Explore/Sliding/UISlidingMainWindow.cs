﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using System;
using System.Linq;
using DG.Tweening;
using UnityEngine.UI;

public class UISlidingMainWindow : UIDialogBase
{


    public UnityEvent OnComplete = new UnityEvent();

    public List<GameObject> Maps;
    public static UISlidingMainWindow instance;
    public AnimationClip NextRoundAnimation;
    
    [SerializeField] UIButton skipButton;

    
    public UnityEvent OnCancel => skipButton.OnTouchUpInside;
    
    SlidingDataFormate dataFormate = new SlidingDataFormate();

    [SerializeField] SlidingMapController slidingMapController;
    public RectTransform ImageBG;//地图生成的位置

    [SerializeField] RectTransform GameOverHintPanel;

    protected override void Awake()
    {



        base.Awake();
        instance = this;
        //NextRoundAnimatio

    }
    public async UniTask Setup(int mlevelID)
    {
        SetData(mlevelID);
        slidingMapController.Init(dataFormate);

    }

    private void SetData(int mlevelID)
    {

        var masters = DataManager.Instance.Master.Sliding.Values;
        var master = masters.First(x => x.levelID == mlevelID);
        #region TestData

        //var master = new SlidingMaster();
        //master.id = 1;
        //master.levelID = 40001;
        #endregion
        dataFormate = SlidingDataFormate.Master2Formate(master);
    }


    public void GameOver()
    {
        ShowGameOverHintPanel();
    }

    private void ShowGameOverHintPanel()
    {
        GameOverHintPanel.gameObject.SetActive(true);
        //var objPostion = GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position;
        Tween tween = DOTween.To(() => GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().localPosition, x => GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().localPosition = x, Vector3.zero, 0.2f);

        GameOverHintPanel.GetComponent<UIButton>().onClick.AddListener((o) =>
        {
            Tween tween2 = DOTween.To(() => GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position, x => GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position = x, new Vector3(0, 500, 0), 0.2f);
            tween2.onComplete += () =>
            {
                OnComplete.Invoke();
            };
        });
        //throw new NotImplementedException();
    }

}



public  class SlidingDataFormate
{

    public  int levelID;
    public  Queue<int> mapQueue=new Queue<int>();
    public float moveSpeed;
    public int charaID;
    public List<string> dialogKey;
    


    public static SlidingDataFormate Master2Formate(SlidingMaster master)
    {

        SlidingDataFormate formate = new SlidingDataFormate();
        formate.levelID = master.levelID;
        formate.dialogKey = master.dialogKey;
        formate.charaID = master.charaID;
        foreach (var item in master.mapList)
        {
            formate.mapQueue.Enqueue(item);
            //formate.mapQueue.Dequeue
        }
        formate.moveSpeed = ((float)master.moveSpeed/10f);


        return formate;
    }



}