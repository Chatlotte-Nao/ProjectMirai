﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using D4L.Linq;
using TMPro;
using UnityEngine.Assertions.Must;
using UnityEngine.UI;
using UnityEngine.Events;

public class UIMemoryRoomEventCell : MonoBehaviour
{
    [SerializeField] UIButton button;
    [SerializeField] UIText nameText;
    [SerializeField] UIText indexText;
    [SerializeField] private TextMeshProUGUI textMeshPro;
    [SerializeField] Image cellBg;


    [SerializeField] private GameObject selectGroup;
    public ExploreEventViewModel Model {get; private set;}

    public ClickEvent OnClick => button.onClick;

    private int index=-1;
    public void Setup(ExploreEventViewModel model)
    {
        Model = model;
        
        var t = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.REQUEST, $"{model.masterId}_title");
        string tempIndexStr = t;
        var firstLatter = tempIndexStr[0];
        var t2=tempIndexStr.Substring(1);
        tempIndexStr = $"<size=40>{firstLatter}</size=40>"+t2;
        nameText.SetRawText(tempIndexStr);
        
        var masterData = DataManager.Instance.Master.ExploreEvent[model.masterId];
        // cellBg.sprite= ResourceManager.Instance.LoadSprite("MemoryRoom", masterData.memoryRoomImage);
        // tempIndexStr="0"+masterData.id.ToString().Substring(masterData.id.ToString().Length-2);
        
        var tempStrArr = masterData.memoryRoomTextColor.Split('-');
        Color topColor;
        Color bottomColor;
        ColorUtility.TryParseHtmlString("#"+tempStrArr[0]+"FF", out topColor);
        ColorUtility.TryParseHtmlString("#"+tempStrArr[1]+"FF" ,out bottomColor);
        textMeshPro.colorGradient = new VertexGradient(topColor, topColor, bottomColor, bottomColor);
        
        index = Model.Master.sortIndex;
        string indexStr = index.ToString().PadLeft(3,'0');//补0
        indexText.SetRawText(indexStr);
        
        selectGroup.SetActive(false);
        
        
        
    }

    private void Update()
    {
        if (index!=-1&& gameObject.activeInHierarchy && index - 1 != transform.GetSiblingIndex())
        {
            transform.SetSiblingIndex(index-1);
        }
    }

    // private void OnEnable()
    // {
    //     Invoke("Refresh",0.01f);
    // }
    //
    // void Refresh()
    // {
    //     int index = Model.Master.sortIndex;
    //     for (int i = 0; i < transform.parent.childCount; i++)
    //     {
    //         var obj = transform.parent.GetChild(i).gameObject;
    //         if (obj.activeSelf)
    //         {
    //             string indexStr = index.ToString().PadLeft(3,'0');//补0
    //             indexText.SetRawText(indexStr);
    //             break;
    //         }
    //     }
    //     
    // }

    public void Select(bool val)
    {
        selectGroup.SetActive(val);
    }
}
