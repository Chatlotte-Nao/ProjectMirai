using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;

public class UIExploreItemGetDialog : UIDialogBase
{
    [SerializeField] private UIExploreItemCell prefab;
    [SerializeField] private RectTransform contentTransform;

    private Queue<GameObject> _cellsPool = new Queue<GameObject>();
    private Queue<string> rewards = new Queue<string>();
    private List<UIExploreItemCell> cells = new List<UIExploreItemCell>();
    
    public async UniTask SetupAsync(List<string> content)
    {
        foreach (var reward in content)
        {
            rewards.Enqueue(reward);
        }
      
    }

    async UniTask LoadItemCell(string reward)
    {
        var cell = GetItemCell();
        cell.OnClose.Subscribe((_)=>
        {
            RemoveItemCell(cell);
        }).AddTo(mSubscriptions);
        cell.gameObject.transform.SetAsLastSibling();
        cell.gameObject.SetActive(true);
        cells.Add(cell);
        await cell.SetUpAsync(reward);
    }

    private float time = 0;
    private void Update()
    {
        if (rewards.Count > 0 && cells.Count <3)
        {
            time += Time.deltaTime;
            if (time > 0.2f)
            {
                var reward = rewards.Dequeue();
                AsyncManager.Instance.StartAsync(LoadItemCell(reward));
                //rewards.Remove(reward);
                time = 0;
            }
        }
    }

    private void RemoveItemCell(UIExploreItemCell cell)
    {
        GameObject o;
        (o = cell.gameObject).SetActive(false);
        _cellsPool.Enqueue(o);
        cells.Remove(cell);
        if (rewards.Count < 1 && cells.Count<1)
        {
            this.Dispose();
        }
    }

    private UIExploreItemCell GetItemCell()
    {
        if (_cellsPool.Count > 0)
        {
            var cell = _cellsPool.Dequeue().GetComponent<UIExploreItemCell>();;
            cell.OnClose.RemoveAllListeners();
            return cell;
        }
        else
        {
            var cell = Instantiate(prefab, contentTransform, false);
            return cell;
        }
    }
}
