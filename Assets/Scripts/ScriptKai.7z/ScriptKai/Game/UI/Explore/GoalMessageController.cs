﻿using Base.Util;

using Game.Util;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;

public class GoalMessageController : MonoBehaviour
{
	class NumGetClass
	{
		public int parentNum;
		public int childNum;
		public NumGetClass(int parentNum, int childNum)
		{
			this.parentNum = parentNum;
			this.childNum = childNum;
		}
	}

	[SerializeField] GoalMessageAppearance messageAppearance;
	[SerializeField] GameObject prefabParent;
	[SerializeField] GameObject prefabChild;
	[SerializeField] Transform parent;
	[SerializeField] Map.GoalMessageScrollController scrolController;

	/// <summary>
	/// 実際に出ているメッセージオブジェクトリスト
	/// </summary>
	List<GoalMessage> messages = new List<GoalMessage>();

	float PREFAB_HEIGHT;
	float PREFAB_CHILD_HEIGHT;
	/// <summary>
	/// 目標メッセージの配置間隔
	/// </summary>
	const float DISTANCE = 5.0f;
	const float MOVE_Y_TIME = 0.5f;
	const float CLICK_MOVE_Y_TIME = 0.1f;

	bool isActive = true;
	bool isAppearance = false;
	Coroutine clickToken = null;
	string endHintString = string.Empty;

	/// <summary>
	/// クリア条件を満たしているか
	///		※
	/// </summary>
	public static bool IsMeetClearConditions(GoalMessageMaster master)
	{
		if (master == null)
			return false;

		if (master.chapter > 0 && master.chapter != AdvManager.Instance.CurrentChapter)
			return false;
		if (master.section > 0 && master.section != AdvManager.Instance.CurrentSection)
			return false;

		var isClear = CondUtil.IsCheckCond(master.selectExit, master.exitCond);
		return isClear;
	}

	private void Start()
	{
		var rect = prefabParent.GetComponent<RectTransform>();
		PREFAB_HEIGHT = rect.sizeDelta.y + DISTANCE;
		rect = prefabChild.GetComponent<RectTransform>();
		PREFAB_CHILD_HEIGHT = rect.sizeDelta.y + DISTANCE;

		scrolController.Initialize(DISTANCE);
	}

	private void OnDestroy()
	{
		if (clickToken != null)
		{
			StopCoroutine(clickToken);
		}
		clickToken = null;
	}

	public void SetActive(bool isActive)
	{
		this.isActive = isActive;
		//アクティブOFFならオブジェクトアクティブもOFF　（ONはShow内で行っている）
		if (!isActive)
			gameObject.SetActive(false);
	}

	public IEnumerator SetCurrentMessageRoutine(List<int> goalMessageList)
	{
		isAppearance = false;

		yield return Show(goalMessageList);
	}


	public string GetEndHintString()
	{
		return endHintString;
	}
	public void ResetEndHintString()
	{
		endHintString = string.Empty;
	}

	/// <summary>
	/// 目標達成確認
	/// </summary>
	/// <returns></returns>
	public IEnumerator Clear(List<int> clearIdList)
	{
		if (clearIdList.Count <= 0) yield break;

		foreach (var m in clearIdList)
		{
			messageAppearance.SetMessage(m);
		}

		yield return messageAppearance.ClearAnimationRoutine(false);


		yield return MoveHeight(MOVE_Y_TIME);
		for (int i = 0;i < clearIdList.Count;i++)
		{
			yield return MovePreOutScroll(clearIdList[i]);
			yield return SlideOut(clearIdList[i]);
		}
		yield return SlideOutAfter(clearIdList);
	}

	/// <summary>
	/// 目標表示
	/// </summary>
	/// <returns></returns>
	IEnumerator Show(List<int> goalMessageList)
	{
		var masters = DataManager.Instance.Master.GoalMessage;
		var messageIdList = goalMessageList;

		isAppearance = true;
		//新規目標の登録
		foreach (var id in messageIdList)
		{
			var m = masters[id];
		}

		if (messageIdList.Count <= 0) yield break;

		//目標表示作成
		for (int i = 0; i < messageIdList.Count; i++)
		{
			if (i < messages.Count) continue;
			var masterId = messageIdList[i];
			var master = DataManager.Instance.Master.GoalMessage[masterId];
			if (master == null) continue;

			CreateMessage(masterId);
			if (isAppearance) messageAppearance.SetMessage(masterId);
		}

		//目標があるならばアクティブON
		gameObject.SetActive(messageIdList.Count > 0);

		SortMessage();
		scrolController.SetScrollObjectList(messages.Select(m => m.gameObject).ToList());
		//出現演出を行うとき
		if (isAppearance)
		{
			yield return messageAppearance.Appearance();
			endHintString = messageAppearance.GetLastAppearanceHint();
			//一旦展開
			foreach (var m in messages)
			{
				m.IsFolding = false;
			}
			yield return MoveHeight(MOVE_Y_TIME);
			for (int i = 0; i < messages.Count; i++)
			{
				//表示済み
				if (messages[i].gameObject.activeInHierarchy) continue;
				yield return MovePreInScroll(i);
				yield return SlideIn(i);
			}
		}
		//出現演出は行わない時
		else
		{
			for (int i = 0; i < messages.Count; i++)
			{
				messages[i].IsFolding = false;
				messages[i].SetEndFirstAnim();
			}
			yield return MoveHeight(0.0f);
		}
	}

	void CreateMessage(int masterId)
	{
		var master = DataManager.Instance.Master.GoalMessage[masterId];
		Transform objParent = parent;
		//配置時の座標はスライドインで設定される
		var prefab = (master.IsParent()) ? prefabParent: prefabChild;
		var g = Utility.CreateGameObject(prefab, parent).GetComponent<GoalMessage>();
		g.SetMessage(masterId);
		g.SetMessageAnchor(TextAlignmentOptions.Left);
		g.UpdateDisplay();
		g.parentFlag = master.parentFlag;
		g.gameObject.SetActive(!isAppearance);

		var parentMessage = GetParentMessage(g);
		if (parentMessage != null)
		{
			//親の配置順と同じ場所に指定する→親が下に下がり、結果的に表示が上になる
			var parentSibing = parentMessage.GetComponent<RectTransform>().GetSiblingIndex();
			var rect = g.GetComponent<RectTransform>();
			rect.SetSiblingIndex(parentSibing);
		}

		//メッセージを押したときの挙動設定
		g.onClick.AddListener(() => 
		{
			Game.Sound.SoundPlayer.PlaySe(SoundConstants.SE_BUTTON);
			SignalBus.GlobalSignal.Dispatch<int>(UIEventId.ADVGoalClick, masterId);
		});
		g.onFoldButtonClick.AddListener(() =>
		{
			if (g.IsParent)
			{
				Game.Sound.SoundPlayer.PlaySe("02_クエスト文字表示");
				//クリックした時点でGoalMessage内でFold設定が切り替わるので、その状態で再度高さ調整を行う
				clickToken = StartCoroutine(MoveHeight(CLICK_MOVE_Y_TIME));
			}
		});

		messages.Add(g);
	}


	GoalMessage GetParentMessage(GoalMessage message)
	{
		if (message.IsParent) return null;
		if (!messages.Any(m => DataManager.Instance.Master.GoalMessage[m.masterId].flag.Equals(message.parentFlag))) return null;
		var parent = messages.Where(m => DataManager.Instance.Master.GoalMessage[m.masterId].flag.Equals(message.parentFlag)).FirstOrDefault();
		return parent;
	}

	/// <summary>
	/// 表示目標を、自分の配置場所にあった高さに移動させる
	/// </summary>
	IEnumerator MoveHeight(float time)
	{
		bool isMove = false;
		for (int i = 0; i < messages.Count; i++)
		{
			messages[i].UpdateDisplay();

			var y = GetGoalMessageTrueY(i);
			if (messages[i].IsEqualY(y))	continue;

			if (messages[i].IsEndFirstAnim) messages[i].gameObject.SetActive(true);
			if (messages[i].gameObject.activeInHierarchy && time > 0.0f)
			{
				messages[i].SetMoveY(y, time);
				isMove = true;
			}
			else
			{
				messages[i].SetY(y);
			}
		}
		if (isMove)
		{
			var waitTime = 0.0f;
			while (waitTime < time)
			{
				waitTime += Time.deltaTime;
				scrolController.SetScrollObjectAlpha();
				yield return null;
			}
		}
		else
		{
			//高さに合わせたX位置も同時に設定
			scrolController.SetScrollObjectX();
		}
		
		scrolController.SetScrollObjectAlpha();
		scrolController.UpdateDisplay(GetNowObjectParentHeight());
		//親が閉じた状態の時の子は表示消す
		for (int i = 0; i < messages.Count; i++)
		{
			var parent = GetParentMessage(messages[i]);
			if (parent != null && parent.IsFolding)
			{
				messages[i].gameObject.SetActive(false);
			}
		}

		clickToken = null;
	}

	IEnumerator MovePreInScroll(int index)
	{
		//出現する最後のところが範囲外ならば、そこにスクロール
		var obj = messages[index].gameObject;
		if (!scrolController.IsInRange(obj))
		{
			yield return scrolController.SetTopScroll(obj);
		}
	}

	/// <summary>
	/// 右から左にスライドイン
	/// </summary>
	IEnumerator SlideIn(int index)
	{
		//表示済み
		if (messages[index].gameObject.activeInHierarchy) yield break;

		messages[index].gameObject.SetActive(true);
		Game.Sound.SoundPlayer.PlaySe("04_クエストアニメーション");
		yield return messages[index].SetAnimationRoutine(GoalMessage.AnimationType.SLIDEIN);
		messages[index].UpdateDisplay();
	}

	IEnumerator MovePreOutScroll(int clearId)
	{
		scrolController.UpdateDisplay(GetNowObjectParentHeight());
		if (scrolController.IsNowScroll())
		{
			yield return null;
		}

		//消えるところが範囲外ならば、そこにスクロール
		var index = messages.FindLastIndex(m => m.masterId == clearId);
		var obj = messages[index].gameObject;
		if (!scrolController.IsInRange(obj))
		{
			yield return scrolController.SetTopScroll(obj);
		}
	}

	/// <summary>
	/// 左から右にスライドアウト(消去)
	/// </summary>
	IEnumerator SlideOut(int clearId)
	{
		if (!messages.Any(m => m.masterId == clearId))
		{
			yield break;
		}
		var message = messages.Where(m => m.masterId == clearId).FirstOrDefault();
		yield return message.SetAnimationRoutine(GoalMessage.AnimationType.SLIDEOUT);
		//データは後で消すので、ここでは表示のみ消しておく
		message.gameObject.SetActive(false);
	}
	IEnumerator SlideOutAfter(List<int> clearIdList)
	{
		var loopNum = clearIdList.Count;
		for (int i = 0;i < loopNum;i++)
		{
			if (!messages.Any(m => m.masterId == clearIdList[i])) continue;
			var removeObject = messages.Where(m => m.masterId == clearIdList[i]).FirstOrDefault();
			Destroy(removeObject.gameObject);
			messages.Remove(removeObject);
		}

		SortMessage();
		scrolController.SetScrollObjectList(messages.Select(m => m.gameObject).ToList());
		//繰り上げ演出
		yield return MoveHeight(MOVE_Y_TIME);
	}

	/// <summary>
	/// 表示メッセージをソートする
	/// </summary>
	void SortMessage()
	{
		List<GoalMessage> after = new List<GoalMessage>();
		//親配置
		foreach (var m in messages)
		{
			var master = DataManager.Instance.Master.GoalMessage[m.masterId];
			if (master == null) continue;
			if (!string.IsNullOrEmpty(master.parentFlag)) continue;

			after.Add(m);
		}
		if (after.Count == 0) return;

		//※afterに子供を追加するので、「親だけがまとまったリスト」としてparentListを別に用意しておく
		List<GoalMessage> parentList = new List<GoalMessage>();
		parentList.AddRange(after);
		//親にくっつく子を配置
		foreach (var parent in parentList)
		{
			var parentMaster = DataManager.Instance.Master.GoalMessage[parent.masterId];
			var insertIndex = after.IndexOf(parent) + 1;
			foreach (var m in messages)
			{
				var master = DataManager.Instance.Master.GoalMessage[m.masterId];
				if (!parentMaster.flag.Equals(master?.parentFlag)) continue;

				after.Insert(insertIndex, m);
				//挿入場所をずらす
				insertIndex++;
			}
		}
		if (messages.Count != after.Count)
		{
			Debug.LogWarning("表示メッセージソート前と後で数が合いません！データを確認してください！");
		}

		messages = after;
	}

	/// <summary>
	/// 指定ゴールメッセージの、現在状態での正しいスクロール位置
	/// </summary>
	/// <returns></returns>
	NumGetClass GetUpPoint(int index)
	{
		var data = new NumGetClass(0, 0);
		if (index >= messages.Count) return data;
		var isParentFold = false;
		//指定メッセージより前に設定されているものがどれだけ場所をとっているか加算していく
		for (int i = 0;i < index;i++)
		{
			if (messages[i].IsParent)
			{
				//チェックした箇所が親だった時は、ひとつ前の親が畳まれていた時の未加算分の位置カウントをここで足す
				if (i > 0 && isParentFold)
				{
					data.parentNum++;
				}
				isParentFold = messages[i].IsFolding;
				if (!isParentFold) data.parentNum++;
				continue;
			}
			if (isParentFold) continue;
			data.childNum++;
		}
		//自分が親だった時は、ひとつ前の親が畳まれていた時の未加算分の位置カウントをここで足す
		if (index > 0 && messages[index].IsParent && isParentFold)
		{
			data.parentNum++;
		}
		return data;
	}

	int GetScrollPoint(int index)
	{
		var data = GetUpPoint(index);
		return data.parentNum + data.childNum;
	}

	/// <summary>
	/// 指定ゴールメッセージの、現在状態での正しい高さ取得
	/// </summary>
	float GetGoalMessageTrueY(int index)
	{
		var data = GetUpPoint(index);

		return -(data.parentNum * PREFAB_HEIGHT + data.childNum * PREFAB_CHILD_HEIGHT);
	}

	/// <summary>
	/// ゴール表示オブジェクトの配置親の高さ取得
	/// </summary>
	/// <returns></returns>
	float GetNowObjectParentHeight()
	{
		//メッセージの一番下の配置座標 ＋ それの高さが親の高さ
		var h = Mathf.Abs(GetGoalMessageTrueY(messages.Count - 1));
		h += PREFAB_HEIGHT;
		return h;
	}
}
