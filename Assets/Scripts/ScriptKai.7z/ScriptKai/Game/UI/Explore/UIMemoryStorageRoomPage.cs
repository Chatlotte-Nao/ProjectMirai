﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;

public class UIMemoryStorageRoomPage:UIPageBase
{
    UIHomeHeaderParam headerParam = new UIHomeHeaderParam();
    UIMemoryStorageRoomDialog mMemoryStorageRoom = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        headerParam.visibleBack = true;
        headerParam.visibleNavigation = true;
        headerParam.visibleHome = true;
        mMemoryStorageRoom = await UI.Dialog.CreateAsync(UIPrefabId.UIMemoryStorageRoomDialog, CanvasType.App0) as UIMemoryStorageRoomDialog;
        mMemoryStorageRoom.Close.SubscribeAsync(onClose).AddTo(mSubscriptions);
        await mMemoryStorageRoom.SetUp();
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHomeHeaderUpdate,headerParam);
        await mMemoryStorageRoom.ShowAsync(showType);
        await base.ShowAsync(showType);
    }

    async UniTask onClose()
    {
        await UI.Page.CloseCurrentPage();
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await mMemoryStorageRoom.HideAsync(showType);
        await base.HideAsync(showType);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mMemoryStorageRoom != null)
        {
            mMemoryStorageRoom.Dispose();
            mMemoryStorageRoom = null;
        }
    }
}
