﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIExplorePage : UIPageBase
{
    UIExploreMainWindow mMainWindow = null;
    UIPadController mPad = null;
    // UIExploreRequestInfoDialog mRequestQuestDialog = null;
    UIAdvRequestCompleteDialog mRequestCompleteDialog = null;
    UIExploreMapDialog mMapDialog = null;
    // UIExploreEventListDialog mEventListDialog = null;
    UIMapOperationDialog mOperationDialog = null;
    
    // UIHomeNavigationWindow mNavigationWindow = null;

    private ExploreEventViewModel mOngoingEvent = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIExploreMainWindow, CanvasType.App0) as UIExploreMainWindow;
        mPad = await UI.Dialog.CreateAsync(UIPrefabId.UIPadController, CanvasType.BG) as UIPadController;
        mOperationDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMapOperationDialog, CanvasType.BG) as UIMapOperationDialog;
        // mRequestQuestDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIExploreRequestInfoDialog, CanvasType.App1) as UIExploreRequestInfoDialog;
        mRequestCompleteDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvRequestCompleteDialog, CanvasType.App1) as UIAdvRequestCompleteDialog;
        mMapDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIExploreMapDialog, CanvasType.App1) as UIExploreMapDialog;
        // mNavigationWindow =  await UI.Dialog.CreateAsync(UIPrefabId.UIHomeNavigationWindow, CanvasType.App0) as UIHomeNavigationWindow;
        // mEventListDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIExploreEventListDialog, CanvasType.App1) as UIExploreEventListDialog;

        SignalBus.GlobalSignal.Subscribe<ExploreEventViewModel>(UIEventId.ExploreOngoingEventUpdate, OnOngoingEventUpdate).AddTo(mSubscriptions);

        mMainWindow.OnClickRequest.GuardSubscribeAsync(OnClickRequest).AddTo(mSubscriptions);
        mMainWindow.OnClickMap.GuardSubscribeAsync(OnClickMap).AddTo(mSubscriptions);
        
        // mNavigationWindow.OnNavigationGroup.GuardSubscribeAsync(OnNavigationGroup).AddTo(mSubscriptions);
        // mEventListDialog.OnClickGiveup.GuardSubscribeAsync(OnClickGiveUp).AddTo(mSubscriptions);
        OnOngoingEventUpdate(DataManager.Instance.Local.Explore.GetProcessingEvent());
        
    }

    private void OnOngoingEventUpdate(ExploreEventViewModel eventViewModel)
    {
        mOngoingEvent = eventViewModel;
        mMainWindow.SetOngoingEvent(eventViewModel);
    }

    private async UniTask OnClickRequest()
    {
        // mEventListDialog.Setup(mOngoingEvent);
        // await mEventListDialog.ShowAsync();
    }


    private async UniTask OnClickMap()
    {
        await mMapDialog.ShowAsync();
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {        
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHeaderHide);
        await base.ShowAsync(showType);
        await mMainWindow.ShowAsync(showType);
        await mPad.ShowAsync(showType);
        await mOperationDialog.ShowAsync(showType);
        // await mNavigationWindow.ShowAsync(showType);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);

        await mMainWindow.HideAsync(showType);
        await mPad.HideAsync(showType);
        await mOperationDialog.HideAsync();
        // await mNavigationWindow.HideAsync(showType);
    }
    private async UniTask OnNavigationGroup(bool isActive)
    {
        mMainWindow.gameObject.SetActive(!isActive);
        mPad.gameObject.SetActive(!isActive);
        mOperationDialog.gameObject.SetActive(!isActive);
    }
    public override void Dispose()
    {
        base.Dispose();
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
        if (mPad != null)
        {
            mPad.Dispose();
            mPad = null;
        }
        if (mRequestCompleteDialog != null)
        {
            mRequestCompleteDialog.Dispose();
            mRequestCompleteDialog = null;
        }
        if (mMapDialog != null)
        {
            mMapDialog.Dispose();
            mMapDialog = null;
        }
        if (mOperationDialog != null)
        {
            mOperationDialog.Dispose();
            mOperationDialog = null;
        }
    }

}
