﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UIExploreEventResultDialog : UIDialogBase
{
    [SerializeField] UITexture illustTexture;
    [SerializeField] UIText eventNameText;

    [SerializeField] UIExploreEventAdvCell advBaseCell;

    [SerializeField] GameObject exploreFinishObject;
    [SerializeField] GameObject exploreOverObject;

    [SerializeField] GameObject bondGroup;
    [SerializeField] UITexture charaIcon;
    [SerializeField] Image bondFillBar;
    [SerializeField] RectTransform bondFillBg;
    [SerializeField] RectTransform handle;
    [SerializeField] UIText bondValueText;
    [SerializeField] UIText bondAddValueText;

    [SerializeField] BaseItem itemPrefab;
    [SerializeField] RectTransform itemTransformParent;
    
    [SerializeField] UIButton skipButton;

    [Space]
    [SerializeField] private GameObject newRewardObg;
    [SerializeField] private GameObject expObject;
    [SerializeField] private RankIcon _rankIcon;
    [SerializeField] private UIText addExpText;
    [SerializeField] private UIText addExploreCoinText;
    [SerializeField] private UIText exploreLimitText;
    public UIIntEvent OnFinish = new UIIntEvent();

    Vector3 orignHandlePos;

    long bondBeforeNum = 0;
    long bondAfterNum = 0;
    int bondBeforeLevel = 0;
    int bondAfterLevel = 0;
    List<BaseItem> mItems = new List<BaseItem>();
    List<UIExploreEventAdvCell> mAdvCells = new List<UIExploreEventAdvCell>();
    bool mIsAnimFinished = false;

    private bool mIsSuccess = false;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        skipButton.OnTouchUpInside.Subscribe(onClickSkip).AddTo(mSubscriptions);
        orignHandlePos = handle.anchoredPosition;
    }

    public async UniTask SetupAsync(ExploreEventViewModel model)
    {
        eventNameText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{model.masterId}_title");

        if (model.complete)
        {
            exploreFinishObject.SetActive(true);
            exploreOverObject.SetActive(false);
            mIsSuccess = true;
        }
        else
        {
            exploreFinishObject.SetActive(false);
            exploreOverObject.SetActive(true);
        }

        //adv
        foreach (var item in model.Master.informationAdvId)
        {
            if (model.finishedAdv.Contains(item))
            {
                var newItemObj = Instantiate(advBaseCell.gameObject, advBaseCell.transform.position, advBaseCell.transform.rotation, advBaseCell.transform.parent);
                // newItemObj.SetActive(true);

                var cell = newItemObj.GetComponent<UIExploreEventAdvCell>();
                cell.Setup(item);
                mAdvCells.Add(cell);
            }
        }
        

        //bond
        // var bond = new List<string>();
        // if (model.complete)
        // {
        //     bond.AddRange(model.Master.bondRewards);
        // }
        //
        // foreach (var item in model.finishedAdv)
        // {
        //     bond.AddRange(DataManager.Instance.Master.ExploreAdv[item].bondRewards);
        // }
        //
        // if (bond.Count > 0)
        // {
        //     var bondReward = bond[0].Split(':');
        //     var characterId = long.Parse(bondReward[0]);
        //     var addValue = int.Parse(bondReward[1]);
        //     if (!model.complete)
        //     {
        //         addValue = 0;
        //     }
        //
        //     await charaIcon.LoadAsync("CharacterIcon", DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[characterId].characterResourceId].exploreCharacterIcon);
        //
        //
        //     int afterLevel = DataManager.Instance.Player.Bond.GetLevel(characterId);
        //     long afterValue = DataManager.Instance.Player.Bond.TryGet(characterId);
        //     long beforeValue = afterValue-addValue;
        //     int beforeLevel = CharacterUtil.CalculateBondLevel(beforeValue);
        //     long startNum = beforeValue;
        //     for (int i = 0; i < beforeLevel; i++)
        //     {
        //         startNum -= DataManager.Instance.Master.BondsLvUp[i+1].exp;
        //     }
        //
        //     long afterNum = afterValue;
        //     for (int i = 0; i < afterLevel; i++)
        //     {
        //         afterNum -= DataManager.Instance.Master.BondsLvUp[i+1].exp;
        //     }
        //
        //     bondAddValueText.SetRawText($"+{addValue}");
        //     if (DataManager.Instance.Master.BondsLvUp.ContainsKey(beforeLevel+1))
        //     {
        //         bondValueText.SetRawText($"{startNum}/{DataManager.Instance.Master.BondsLvUp[beforeLevel+1].exp}");
        //     }
        //     else
        //     {
        //         bondValueText.SetRawText($"{startNum}/0");
        //     }
        //
        //     bondBeforeLevel = beforeLevel;
        //     bondBeforeNum = startNum;
        //     bondAfterLevel = afterLevel;
        //     bondAfterNum = afterNum;
        //
        //     SetBar(bondBeforeLevel, bondBeforeNum);
        //
        // }
        // else
        // {
        //     bondGroup.SetActive(false);
        // }
        //
        // //reward
        // Dictionary<long, int> items = new Dictionary<long, int>();
        // foreach (var finishedAdv in model.finishedAdv)
        // {
        //     addReward(items, DataManager.Instance.Master.ExploreAdv[finishedAdv].rewards);
        // }
        // if (model.complete)
        // {
        //     addReward(items, model.Master.rewards);
        //     if (model.finishCount == 0)
        //     {
        //         addReward(items, model.Master.firstTimeRewards);
        //     }
        // }
        //
        //
        // foreach (var item in items)
        // {
        //     var itemId = item.Key;
        //     var itemNum = item.Value;
        //     var newItemObj = GameObject.Instantiate(itemPrefab.gameObject);
        //     newItemObj.transform.parent = itemTransformParent;
        //     newItemObj.transform.localScale = Vector3.one;
        //     newItemObj.transform.localRotation = Quaternion.identity;
        //     newItemObj.transform.localPosition = Vector3.zero;
        //     // newItemObj.SetActive(true);
        //
        //     var sel = newItemObj.GetComponent<BaseItem>();
        //     await sel.SetupAsync(itemId, itemNum.ToString());
        //     mItems.Add(sel);
        //
        // }
        
        //reward
        newRewardObg.gameObject.SetActive(model.complete);
        if (model.complete)
        {
            Dictionary<long, int> rewards = new Dictionary<long, int>();
            if (model.finishCount == 1)
            {
                expObject.SetActive(true);
                addReward(rewards, model.Master.firstTimeRewards);
                addExpText.SetRawText($"+{rewards[113000001]}");
                long remainExp = DataManager.Instance.Player.Player.GetRemainExp();
                int lv = DataManager.Instance.Player.Player.GetLevel();
                var fill = 0f;
                if (DataManager.Instance.Master.PlayerLevel.ContainsKey(lv+1))
                {
                    fill = (float)remainExp/DataManager.Instance.Master.PlayerLevel[lv+1].exp;
                }
                _rankIcon.Set(lv, fill);
            }
            else
            {
                expObject.gameObject.SetActive(false);
            }
            addReward(rewards, model.Master.rewards);
            var exploreCoinLimit = DataManager.Instance.Player.Player.GetData().ExploreCoinLimit;
            var exploreCoinReceived = DataManager.Instance.Player.Player.GetData().ExploreCoinReceived;
            var oldCoin = DataManager.Instance.Player.Player.GetOldExploreCoin();
            exploreLimitText.SetRawText($"{exploreCoinReceived}/{exploreCoinLimit}");
            long allexplore = 0;
            if (rewards.ContainsKey(121000001))
            {
                allexplore += rewards[121000001];
                var num = exploreCoinLimit - oldCoin;
                if (allexplore >= num)
                {
                    allexplore = num;
                }
            }
            if (rewards.ContainsKey(121000002))
                allexplore += rewards[121000002];
            addExploreCoinText.SetRawText($"+{allexplore}");
        }


    }
    
    private void addReward(Dictionary<long, int> result, List<string> rewards)
    {
        foreach (var item in rewards)
        {
            var s = item.Split(':');
            var itemId = long.Parse(s[0]);
            var itemNum = int.Parse(s[1]);
            if (result.ContainsKey(itemId))
            {
                result[itemId] += itemNum;
            }
            else
            {
                result.Add(itemId, itemNum);
            }
            
        }
    }


    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);

        StartCoroutine(animRoutine());
    }

    private void onClickSkip()
    {
        if (!mIsAnimFinished)
        {
            skipAnim();
        }
    }

    protected override async UniTask onClickClose(GameObject o)
    {
        OnFinish.Invoke(mIsSuccess?0:1);
    }

    private void skipAnim()
    {
        StopAllCoroutines();
        SetBar(bondAfterLevel, bondAfterNum);
        foreach (var item in mAdvCells)
        {
            item.gameObject.SetActive(true);
        }
        foreach (var item in mItems)
        {
            item.gameObject.SetActive(true);
        }
        onAnimEnd();
    }

    private void onAnimEnd()
    {
        mIsAnimFinished = true;
        closeButton.gameObject.SetActive(true);
        skipButton.gameObject.SetActive(false);
    }

    IEnumerator animRoutine()
    {
        foreach (var item in mAdvCells)
        {
            item.gameObject.SetActive(true);
            yield return new WaitForSeconds(0.2f);
        }
        yield return BarRoutine(bondBeforeNum, bondAfterNum, bondBeforeLevel, bondAfterLevel);

        foreach (var item in mItems)
        {
            item.gameObject.SetActive(true);
            yield return new WaitForSeconds(0.2f);
        }

        onAnimEnd();
    }

    void SetBar(int level, long val)
    {
        if (DataManager.Instance.Master.BondsLvUp.TryGetValue(level+1, out var nextLevelMaster))
        {
            bondFillBar.fillAmount = (float)val/nextLevelMaster.exp;
            bondValueText.SetRawText($"{val}/{nextLevelMaster.exp}");
            handle.anchoredPosition = new Vector3(orignHandlePos.x + bondFillBar.fillAmount * bondFillBar.GetComponent<RectTransform>().sizeDelta.x, orignHandlePos.y, orignHandlePos.z);
        }
        else
        {
            bondFillBar.fillAmount = 0f;
            bondValueText.SetRawText($"{val}/0");
            handle.anchoredPosition = new Vector3(orignHandlePos.x + bondFillBar.fillAmount * bondFillBar.GetComponent<RectTransform>().sizeDelta.x, orignHandlePos.y, orignHandlePos.z);

        }
    }

    IEnumerator BarRoutine(long startNumber, long afterNumber, int startLevel, int afterLevel)
    {
        long nowNumber = startNumber;
        float startTime = Time.time;
        float effectTime = 1f;
        int currentLevel = startLevel;
        SetBar(currentLevel, nowNumber);
        while (currentLevel <= afterLevel)
        {
            // bondLevelText.SetLabel(LocalizeManager.DATA_TYPE.BOND, currentLevel.ToString());
            //do fill
            long finishNumber = 0;
            if (currentLevel == afterLevel)
            {
                finishNumber = afterNumber;
            }
            else
            {
                finishNumber = (long)DataManager.Instance.Master.BondsLvUp[currentLevel+1].exp;
            }
            
            float barStartTime = Time.time;
            while (nowNumber < finishNumber)
            {
                nowNumber = (long)Mathf.Lerp(startNumber, finishNumber, (Time.time-barStartTime)/effectTime);
                SetBar(currentLevel, nowNumber);
                yield return null;
            }
            
            currentLevel++;
            nowNumber = 0;
            startNumber = 0;
            yield return null;
        }
    }
}
