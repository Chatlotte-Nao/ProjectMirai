﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.EventSystems;

public class UIExploreEventAdvCell : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] GameObject hintObject;
    [SerializeField] UIText hintText;


    private int mAdvId = 0;
    public void Setup(int advId, bool isLock = false)
    {
        mAdvId = advId;
        if (isLock)
        {
            hintText.SetLabel(LocalizeManager.DATA_TYPE.EXPLORE, "Event_Info_Locked");
        }
        else
        {
            hintText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, advId.ToString());
        }
        
    }



    public void OnPointerEnter(PointerEventData eventData)
    {
        hintObject.SetActive(true);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        hintObject.SetActive(false);
    }
}
