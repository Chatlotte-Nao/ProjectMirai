﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIExploreGiftPage : UIPageBase
{
    UIExploreGiftWindow mGiftWindow = null;
    private CharacterViewModel mCharacterViewModel = null;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);

        mCharacterViewModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get((long)param), DataManager.Instance.Player.Equipment.GetList());
        //Debug.Log(param);
        mGiftWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIExploreGiftWindow, CanvasType.App1) as UIExploreGiftWindow;
        mGiftWindow.OnProcessAddLiking.SubscribeAsync(OnProcessLikingUp).AddTo(mSubscriptions);
        await mGiftWindow.SetupAsync(mCharacterViewModel);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);

        await mGiftWindow.ShowAsync(showType);
        MapSceneManager.Instance.ShowCurrent();

    }

    private async UniTask OnProcessLikingUp()
    {
        await ExploreService.AddCharacterBondEvent(mCharacterViewModel.id,mGiftWindow.currentItemId);
       // Debug.Log("数量 - 1");
        mCharacterViewModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get(mCharacterViewModel.id), DataManager.Instance.Player.Equipment.GetList());
        await UpdateCharacter();
        mGiftWindow.ProcessEnd();
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);

        await mGiftWindow.HideAsync(showType);
       
    }
    public override void Dispose()
    {
        base.Dispose();
        if (mGiftWindow != null)
        {
            mGiftWindow.Dispose();
            mGiftWindow = null;
        }
    }

    private async UniTask UpdateCharacter()
    {
        await mGiftWindow.SetupAsync(mCharacterViewModel);
        mGiftWindow.isAdd = true;

    }
}
