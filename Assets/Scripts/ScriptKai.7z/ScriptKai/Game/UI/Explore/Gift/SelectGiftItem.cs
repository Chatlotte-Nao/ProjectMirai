﻿using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;

public class SelectGiftItem : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    [SerializeField] private int threshold = 10;
    [SerializeField] private int thresholdXdivisionY =5;

    private ScrollRect parentScrollRect;
    private Vector2 beginDragPosition;
    private RawImage previewAvatar;
    private Texture floatingIcon;
    private bool avatarLock = true;
    private bool scrollLock = true;
    private List<Transform> trigger;
    private float top;
    private float bottom;
    private float left;
    private float right;
    [SerializeField]private GameObject targetObj;
    [SerializeField] List<Material> SelectedMaterials=new List<Material>();

    [SerializeField] List<Material> NotSelectedMaterials=new List<Material>();
    private Material TempMaterial;

    //[SerializeField] Material[] SelectedMaterials;
    //[SerializeField] Material[] NotSelectedMaterials;

    private Color orignCor;
    private bool canAdd = false;
    public long id { get; private set; }
    public UnityEvent OnProcessEndDrag = new UnityEvent();
    public bool isClickOnce = false;

    public void Initialize(long id, ScrollRect parentScrollRect, RawImage previewAvatar,Image img,List<Transform> trigger)
    {
        this.id = id;
        this.parentScrollRect = parentScrollRect;
        this.beginDragPosition = Vector2.zero;
        this.previewAvatar = previewAvatar;
        floatingIcon = img.mainTexture;
       
        this.trigger = trigger;
        var screenPos0 = Camera.main.WorldToScreenPoint(trigger[0].position);
        var screenPos1 = Camera.main.WorldToScreenPoint(trigger[1].position);

        top = screenPos1.y;
        bottom = screenPos0.y;
        left = screenPos0.x;
        right = screenPos1.x;
        


    }

    public void SetCharacter(GameObject character)
    {
        this.targetObj = character;

        foreach (var item in character.GetComponent<MeshRenderer>().materials) 
        //foreach (var item in character.GetComponent<Renderer>().sharedMaterials)
        {
            TempMaterial = Instantiate(item);
            TempMaterial.name = "_white";
            TempMaterial.color = Color.white;
            //item.color = Color.white;
            NotSelectedMaterials.Add(TempMaterial);
        }

        foreach (var item in character.GetComponent<MeshRenderer>().materials)
        //foreach (var item in character.GetComponent<Renderer>().sharedMaterials)
        {
            TempMaterial = Instantiate(item);
            TempMaterial.name = "_grey";
            TempMaterial.color = Color.grey;
            //item.color = Color.gray;
            SelectedMaterials.Add(TempMaterial);
        }

        // NotSelectedMaterial = new Material(character.GetComponent<MeshRenderer>().material);
        // NotSelectedMaterial.shader = Shader.Find("Score/Score_Spine_CharacterADV");
        
        // SelectedMaterial = new Material(character.GetComponent<MeshRenderer>().material);
        // SelectedMaterial.shader = Shader.Find("Score/Score_Spine_CharacterADV");
        // SelectedMaterial.color = Color.gray;
        // orignCor = character.GetComponent<MeshRenderer>().material.color;
        //material = character.GetComponent<MeshRenderer>().material;
        //material.shader = Shader.Find("Score/Score_Spine_CharacterADV");
        //Debug.Log(material.shader.name);

    }
    public void OnBeginDrag(PointerEventData eventData)
    {
        parentScrollRect.OnBeginDrag(eventData);
        beginDragPosition = eventData.position;
        this.isClickOnce = false;

        avatarLock = true;
        scrollLock = true;
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (avatarLock && scrollLock)
        {
            var delta = eventData.position - beginDragPosition;
            
            if (delta.SqrMagnitude() > threshold)
            {
                if (delta.y == 0)
                {
                    scrollLock = false;
                    avatarLock = true;
                }
                else if (Mathf.Abs(delta.x / delta.y) > thresholdXdivisionY)
                {
                    scrollLock = false;
                    avatarLock = true;
                }
                else
                {
                    scrollLock = true;
                    avatarLock = false;
                }
            }

        }
        UpdateAvatar(eventData);
        UpdateScroll(eventData);
       
       
    }
    private void UpdateAvatar(PointerEventData eventData)
    {
        if (avatarLock)
            return;
        if (!previewAvatar.gameObject.activeSelf)
        {
            previewAvatar.gameObject.SetActive(true);
            previewAvatar.texture = floatingIcon;
        }
        SetDraggedPosition(eventData);
    }

    private void UpdateScroll(PointerEventData eventData)
    {
        if (scrollLock)
            return;
        parentScrollRect.OnDrag(eventData);
    }
    public void OnEndDrag(PointerEventData eventData)
    {
        parentScrollRect.OnEndDrag(eventData);
        previewAvatar.gameObject.SetActive(false);
        if (canAdd)
        {
            OnProcessEndDrag.Invoke();
        }


        canAdd = false;
        scrollLock = true;
        avatarLock = true;
        //if(material.color != orignCor)
        //    material.color = orignCor;
        targetObj.GetComponent<MeshRenderer>().materials = NotSelectedMaterials.ToArray();
        //targetObj.GetComponent<Renderer>().sharedMaterials = NotSelectedMaterials.ToArray();
       
        
    }
    private void SetDraggedPosition(PointerEventData eventData)
    {
        //Debug.Log((int)eventData.position.x + " " + (int)eventData.position.y +" " + (int)bottom + " " + (int)top +" " + (int)left + " " + (int)right );
        var rt = previewAvatar.GetComponent<RectTransform>();
        Vector3 globalMousePos;
        if (RectTransformUtility.ScreenPointToWorldPointInRectangle(rt, eventData.position,
            eventData.pressEventCamera, out globalMousePos))
        {
            rt.position = globalMousePos;
        }
        if (eventData.position.y > bottom && eventData.position.y < top && eventData.position.x > left && eventData.position.x < right)
        {
            //Debug.Log("True");
            // material.color = Color.gray;
            targetObj.GetComponent<MeshRenderer>().materials = SelectedMaterials.ToArray();
            //targetObj.GetComponent<Renderer>().sharedMaterials = SelectedMaterials.ToArray();
        }
        else
        {
            // material.color = orignCor;
            //targetObj.GetComponent<MeshRenderer>().materials = SelectedMaterials.ToArray();
            targetObj.GetComponent<Renderer>().sharedMaterials = NotSelectedMaterials.ToArray();
        }
        if (eventData.position.y > bottom && eventData.position.y < top && eventData.position.x > left && eventData.position.x < right)
        {
            canAdd = true;
        }
        else
        {
            canAdd = false;
        }

    }

}
