﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using Spine.Unity;
using UnityEngine.Events;
using System;
using System.Linq;
using TMPro;
using Spine;

public class UIExploreGiftWindow : UIDialogBase
{
    [SerializeField] RawImage standImage;
    [SerializeField] UIButton backBtn;
    [SerializeField] List<BaseItem> itemButton = new List<BaseItem>();
    [SerializeField] UIText levelText;
    [SerializeField] UIText likText;
    [SerializeField] Image likBarImage;
    [SerializeField] GameObject content;
    [SerializeField] GameObject baseItemPrefab;
    [SerializeField] ScrollRect parentScrollrect;
    [SerializeField] RawImage previewAvatar;
    [SerializeField] List<Image> itemIcon = new List<Image>();
    [SerializeField] List<Transform> trigger = new List<Transform>();
    [SerializeField] RectTransform bondFillEffect;
    [SerializeField] UIText bondAddValueText;
    [SerializeField] GameObject upEffect;
    [SerializeField] GameObject leveUpEffect;
    [SerializeField] GameObject paopao;
    [SerializeField] UIText ChaName;
    [SerializeField] UIText talkText;
    [SerializeField] private UIText bondNumberText;
    [SerializeField] private Image bondImage;
    [SerializeField] private GameObject notItemObj;
    public UnityEvent OnProcessAddLiking = new UnityEvent();

    public long currentItemId = 0;

    // private long characterMasterId = 0;
    public bool isAdd = false;

    //
    [SerializeField] Slider slider;
    readonly List<long> ItemId = new List<long>();

    int afterLevel;
    long afterValue;
    float aniTime;
    int beforeLevel;
    private long beforeValue = 0;
    private GameObject bgObject = null;
    private CharacterGiftMaster characterGift;
    private long characterId = 0;
    private long characterId_;
    private int curBondLevel = 0;
    private long curBonds = 0;

    long currentBonds;
    TrackEntry entry;
    bool inited = false;

    bool isPlaying = false;
    bool levelUp = false;
    GameObject loadCharacter;
    private int maxBondLevel = 8;
    private int maxBonds = 0;
    UIRTCamera mRTCamera = null;

    private UIHomeCharacterUnitSignContract mSignContract;
    private long plusBonds;
    SkeletonAnimation skeletonAnimation;

    public ClickEvent OnClickBack => backBtn.onClick;

    private void Update()
    {
        //1.当最终值与初始值相同时，退出
        //2.当最终值与初始值不相等时，先判断等级是否变化，再增加
        if (beforeValue != afterValue)
        {
            aniTime = 4f;
            if (beforeLevel != afterLevel)
            {
                upEffect.SetActive(false);
                if(!levelUp)
                    levelUp = true;

                likText.SetRawText($"{GetCurWatchValue(beforeValue) + 1}/{DataManager.Instance.Master.BondsLvUp[beforeLevel + 1].exp}");
                slider.value = GetCurWatchValue(beforeValue) + 1 / (float)DataManager.Instance.Master.BondsLvUp[beforeLevel + 1].exp;

                beforeValue += 1;
                likBarImage.fillAmount = (float)(GetCurWatchValue(beforeValue) / (float)DataManager.Instance.Master.BondsLvUp[beforeLevel + 1].exp);
                bondFillEffect.anchoredPosition = new Vector2(0, -53 + 110 * likBarImage.fillAmount);
                if (GetCurWatchValue(beforeValue) == DataManager.Instance.Master.BondsLvUp[beforeLevel + 1].exp)
                {
                    beforeLevel++;
                    if(DataManager.Instance.Master.BondsLvUp.ContainsKey(beforeLevel + 1))
                    {
                        leveUpEffect.SetActive(true);
                        levelText.SetFormat(LocalizeManager.DATA_TYPE.BOND, beforeLevel.ToString());
                        bondNumberText.SetRawText(beforeLevel.ToString());
                        //bondImage.Load("Bond",beforeLevel.ToString(),false);
                        AsyncManager.Instance.StartAsync(LoadSprite(beforeLevel.ToString()));
                        likText.SetRawText($"{0}/{DataManager.Instance.Master.BondsLvUp[beforeLevel + 1].exp}");
                        slider.value = 0;

                        likBarImage.fillAmount = 0;
                        bondFillEffect.anchoredPosition = new Vector2(0, -53 + 110 * likBarImage.fillAmount);
                    }
                    else
                    {
                        levelUp = false;
                    }
                    AsyncManager.Instance.StartAsync(async()=> {
                        await OpenSignContract(beforeLevel - 1, beforeLevel);
                    });
                }
              
            }
            else
            {
                if (DataManager.Instance.Master.BondsLvUp.ContainsKey(beforeLevel + 1))
                {
                    likText.SetRawText($"{GetCurWatchValue(beforeValue) + 1}/{DataManager.Instance.Master.BondsLvUp[beforeLevel + 1].exp}");
                    slider.value = (GetCurWatchValue(beforeValue) + 1) / (float)DataManager.Instance.Master.BondsLvUp[beforeLevel + 1].exp;
                    //Debug.Log($"改变经验  {(float)GetCurWatchValue(beforeValue) + 1}/{(float)DataManager.Instance.Master.BondsLvUp[beforeLevel + 1].exp}   {slider.value}");

                    beforeValue += 1;
                    likBarImage.fillAmount = (float)(GetCurWatchValue(beforeValue) / (float)DataManager.Instance.Master.BondsLvUp[beforeLevel + 1].exp);
                    bondFillEffect.anchoredPosition = new Vector2(0, -53 + 110 * likBarImage.fillAmount);
                }
            }

            if (afterValue >= plusBonds)
                afterValue = plusBonds;
             
            
        }
        else
        {
            isAdd = false;
        }
        aniTime -= Time.deltaTime;
        if (aniTime > 0)
        {
            if(!paopao.activeSelf)
                paopao.SetActive(true);
            if(!bondAddValueText.gameObject.activeSelf)
                bondAddValueText.gameObject.SetActive(true);
            if(!upEffect.activeSelf && !levelUp)
                 upEffect.SetActive(true);
        }
        else
        {
            paopao.SetActive(false);
            bondAddValueText.gameObject.SetActive(false);

            if (upEffect.activeSelf)
            {
                upEffect.SetActive(false);
            }

            if (leveUpEffect.activeSelf)
            {
                leveUpEffect.SetActive(false);
            }
        }

        
    }

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        var label = MapSceneManager.Instance.CurrentScene.label;
        var bg = DataManager.Instance.Master.Location[label].advBg;
        maxBondLevel = DataManager.Instance.Master.BondsLvUp.Values.Max(a => a.lv);
        if (!string.IsNullOrEmpty(bg))
        {
            bgObject = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/bg/"+bg, UI.Canvas.GetCanvas(CanvasType.BG).transform);

            foreach (var item in bgObject.GetComponentsInChildren<Renderer>())
            {
                item.gameObject.layer = LayerMask.NameToLayer("UI");
            }

            bgObject.transform.localPosition = Vector3.zero;
            bgObject.transform.localScale = new Vector3(52,52,1);
        }
        standImage.gameObject.SetActive(true);
    }


    async UniTask LoadSprite(string index)
    {
        bondImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("Bond", index);
    }

    long GetCurWatchValue(long val)
    {
        for (int i = 1; i <= DataManager.Instance.Master.BondsLvUp.Count; i++)
        {
            val -= DataManager.Instance.Master.BondsLvUp[i].exp;
            if(val <=0)
            {
                val =  val + DataManager.Instance.Master.BondsLvUp[i].exp;
                break;
            }
        }
        return val;
    }

    async UniTask  Init()
    {
        for (int i = 1; i <= DataManager.Instance.Master.BondsLvUp.Count; i++)
        {
            plusBonds += DataManager.Instance.Master.BondsLvUp[i].exp;
         
        }
        bondAddValueText.gameObject.SetActive(false);
        paopao.SetActive(false);
        var rtc = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/RTCamera");
        mRTCamera = rtc.GetComponent<UIRTCamera>();
        backBtn.onClick.GuardSubscribeAsync(OnClickBackAsync).AddTo(mSubscriptions);

        foreach (var item in DataManager.Instance.Master.Item)
        {
            if (item.Value.contentType == 119 && DataManager.Instance.Player.Item.GetCount(item.Key) > 0)
            {

                var go = Instantiate(baseItemPrefab, content.transform);
                go.SetActive(true);
                content.GetComponent<RectTransform>().sizeDelta += new Vector2(baseItemPrefab.GetComponent<RectTransform>().sizeDelta.x + content.GetComponent<HorizontalLayoutGroup>().spacing, 0);
                ItemId.Add(item.Value.id);
                itemButton.Add(go.GetComponent<BaseItem>());
                itemIcon.Add(go.GetComponentInChildren<UITexture>().gameObject.GetComponent<Image>());

                //长按出现信息
                //go.GetComponent<BaseItem>().OnLongClick.GuardSubscribeAsync(async (_) => { await Pheonix.Core.UI.Popup.ShowItemInfoPopupAsync(item.Value.id, false); });

            }
        }
        ItemId.Sort(itemSort);
        content.GetComponent<RectTransform>().sizeDelta -= new Vector2(content.GetComponent<HorizontalLayoutGroup>().spacing, 0);
        long totleNumber = 0;
        for (int j = 0; j < ItemId.Count; j++)
        {
            int idx = j;
            var button = itemButton[j];
            var number = DataManager.Instance.Player.Item.GetCount(ItemId[j]);
            await button.SetupAsync(ItemId[j], $"{number}");
            totleNumber += number;
            var go = button.gameObject.AddComponent<SelectGiftItem>();
            go.Initialize(ItemId[j], parentScrollrect, previewAvatar, itemIcon[j], trigger);
            var like = getLikeness(characterId, ItemId[j]);
            go.transform.Find("fav").gameObject.SetActive(like == 3);
            go.transform.Find("like").gameObject.SetActive(like == 2);
            go.OnProcessEndDrag.Subscribe(() => { PxSoundManager.Instance.PlaySe("feedbackSE_date_select01"); DargItems(idx); }).AddTo(mSubscriptions);
        }
        content.gameObject.SetActive(totleNumber > 0);
        notItemObj.SetActive(totleNumber <= 0);
    }

    private int itemSort(long id_a, long id_b)
    {
        var like_a = getLikeness(characterId, id_a);
        var like_b = getLikeness(characterId, id_b);
        if (like_a != like_b) return like_b.CompareTo(like_a);

        return DataManager.Instance.Master.Item[id_b].rarity.CompareTo(DataManager.Instance.Master.Item[id_a].rarity);
    }

    private int getLikeness(long characterId, long itemId)
    {
        var characterMaster = DataManager.Instance.Master.BattleCharacterBond[characterId];

        if (characterMaster.favorite.Contains(itemId)) return 3;
        if (characterMaster.like.Contains(itemId)) return 2;
        if (characterMaster.normal.Contains(itemId)) return 1;
        if (characterMaster.hate.Contains(itemId)) return -1;
        return 0;
    }

    void DargItems(int idx)
    {
        var nowLevel = DataManager.Instance.Player.Bond.GetLevel(characterId);
        //itemButton[idx].gameObject.GetComponent<SelectGiftItem>().isClickOnce = false;
        if (DataManager.Instance.Player.Item.GetCount(ItemId[idx]) <= 0)
            return;
        if (nowLevel >= maxBondLevel && beforeValue >= afterValue)
        {
            long val = 0;
            for (int i = 1; i <= DataManager.Instance.Master.BondsLvUp.Count; i++)
            {
                val += DataManager.Instance.Master.BondsLvUp[i].exp;
            }
            beforeValue = afterValue = val;
            likText.SetRawText($"{GetCurWatchValue(beforeValue)}/{GetCurWatchValue(afterValue)}");
            slider.value = GetCurWatchValue(beforeValue) / (float)GetCurWatchValue(afterValue);
            Debug.Log($"改变经验  {(float)GetCurWatchValue(beforeValue)}/{(float)GetCurWatchValue(afterValue)}   {slider.value}");

            likBarImage.fillAmount = afterValue == 0 ? 0 : (float)beforeValue / afterValue;
            bondFillEffect.anchoredPosition = new Vector2(0, -53 + 110 * likBarImage.fillAmount);
            return;
        }
   
        currentItemId = ItemId[idx];
        //if (!isAdd)
        //{
        //    beforeValue = DataManager.Instance.Player.Bond.TryGet(characterId);
        //}

        currentBonds = DataManager.Instance.Player.Bond.TryGet(characterId);
        OnProcessAddLiking.Invoke();
        //var afterBonds = DataManager.Instance.Player.Bond.TryGet(characterId);
       characterAniChange();

    }


    public void ProcessEnd()
    {
        
        for (int i = 0; i < ItemId.Count; i++)
        {
            if (DataManager.Instance.Player.Item.GetCount(ItemId[i]) != 0)
            {
                AsyncManager.Instance.StartAsync(itemButton[i].SetupAsync(ItemId[i], DataManager.Instance.Player.Item.GetCount(ItemId[i]).ToString()));
            }
            else
            {
                itemButton[i].gameObject.SetActive(false);
                //DestroyImmediate(itemButton[i].gameObject);
                //itemButton.Remove(itemButton[i]);
            }
        }
    }

    public async UniTask SetupAsync(CharacterViewModel model)
    {
        characterId_ = model.id;
        ChaName.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER_NAME, model.id.ToString());
        var nameTextMeshPro = ChaName.GetComponent<TextMeshProUGUI>();
        string firstWord = nameTextMeshPro.text.ToString()[0].ToString();
        string nameLast1 = nameTextMeshPro.text.ToString().Substring(1);

        string nameFirst = firstWord;
        string nameLast2 = "<size=85%>" + nameLast1;
        nameTextMeshPro.text = nameFirst + nameLast2;
        afterValue = DataManager.Instance.Player.Bond.TryGet(model.id);
        afterLevel = DataManager.Instance.Player.Bond.GetLevel(model.id);
        //afterValue = DataManager.Instance.Player.Bond.TryGet(characterId);
        //beforeValue = afterValue - addValue;
        beforeLevel = CharacterUtil.CalculateBondLevel(beforeValue);
        curBondLevel = DataManager.Instance.Player.Bond.GetLevel(model.id);
        if (levelUp)
            levelUp = false;
        long realBonds = DataManager.Instance.Player.Bond.TryGet(model.id);
        var addValue = afterValue - currentBonds;
        bondAddValueText.SetFormat(LocalizeManager.DATA_TYPE.BOND, "AddFormat", addValue);
        paopao.SetActive(false);
        bondAddValueText.gameObject.SetActive(false);

        if (upEffect.activeSelf)
        {
            upEffect.SetActive(false);
        }

        if (leveUpEffect.activeSelf)
        {
            leveUpEffect.SetActive(false);
        }
        if (model.id != characterId)
        {
            characterId = model.id;
            await Init();
           // BattleCharacterMaster id;
            
           // DataManager.Instance.Master.BattleCharacter.TryGetValue(model.id, out id);
           //characterMasterId = id.characterMasterId;
            //Debug.Log(characterMasterId);
            DataManager.Instance.Master.CharacterGift.TryGetValue((int)characterId, out characterGift);
            var resourceMaster = DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[model.id].characterResourceId];
            loadCharacter = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/chara/" + resourceMaster.advModelId);
            skeletonAnimation = loadCharacter.GetComponent<SkeletonAnimation>();
            skeletonAnimation.Initialize(false);
            skeletonAnimation.Update(0.0f);
            skeletonAnimation.LateUpdate();
            



            mRTCamera.Setup(loadCharacter);
            standImage.texture = mRTCamera.GetRenderTexture();
            for (int i = 0; i < ItemId.Count; i++)
            {

                itemButton[i].GetComponent<SelectGiftItem>().SetCharacter(loadCharacter);
                
            }
            
           
            likBarImage.fillAmount = maxBonds == 0 ? 0 : (float)curBonds / maxBonds;
            bondFillEffect.anchoredPosition = new Vector2(0, -53 + 110 * likBarImage.fillAmount);
        }
        
        if (DataManager.Instance.Master.BondsLvUp.ContainsKey(curBondLevel + 1))
            maxBonds = DataManager.Instance.Master.BondsLvUp[curBondLevel + 1].exp;
        else
            maxBonds = DataManager.Instance.Master.BondsLvUp[curBondLevel].exp;

        for (int i = curBondLevel; i > 0; i--)
        {
            if (curBondLevel == maxBondLevel) continue;
            realBonds -= DataManager.Instance.Master.BondsLvUp[i].exp;

        }
        curBonds = realBonds;
        if (curBonds >= maxBonds)
            curBonds = maxBonds;
        likText.SetRawText($"{curBonds}/{maxBonds}");
        slider.value = (float)curBonds / maxBonds;
        Debug.Log($"初始化经验  {(float)curBonds}/{(float)maxBonds}   {slider.value}");

        levelText.SetFormat(LocalizeManager.DATA_TYPE.BOND, curBondLevel.ToString());
        bondNumberText.SetRawText(curBondLevel.ToString());
        if (beforeLevel != afterLevel)
        {
            AsyncManager.Instance.StartAsync(LoadSprite(beforeLevel.ToString()));
        }

        if (!inited)
        {
            inited = true;
            beforeValue = DataManager.Instance.Player.Bond.TryGet(model.id);
            await characterAniChange(true);
        }

        

    }


    private async UniTask OnClickBackAsync(GameObject o)
    {
        await UI.Page.CloseCurrentPage();
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mRTCamera != null)
        {
            mRTCamera.Dispose();
            mRTCamera = null;
        }
        if (bgObject != null)
        {
            Destroy(bgObject);
            bgObject = null;
        }

        if (mSignContract != null)
        {
            mSignContract.Dispose();
            mSignContract = null;
        }
    }

    async UniTask characterAniChange(bool init = false)
    {

        if(!init && !isPlaying)
        {
            isPlaying = true;
            await SetupCharacter(characterGift.afterBody);
            await SetupCharacter(characterGift.afterExpression);
            await UniTask.WaitUntil(() => entry.IsComplete == true);
            if (characterGift.returnBody != "")
            {
                await SetupCharacter(characterGift.returnBody);
                await UniTask.WaitUntil(() => entry.IsComplete == true);
            }
            isPlaying = false;
            await SetupCharacter(characterGift.initialBody);
            await SetupCharacter(characterGift.initialExpression);

        }
    

    }

    public async UniTask SetupCharacter(string anim)
    {

        var advSpineMaster = DataManager.Instance.Master.AdvSpine[anim];
        if (!string.IsNullOrEmpty(advSpineMaster.body))
        {
            entry = skeletonAnimation.AnimationState.SetAnimation(0, advSpineMaster.body, false);
        }
        else if (!string.IsNullOrEmpty(advSpineMaster.waiting))
        {
             skeletonAnimation.AnimationState.SetAnimation(0, advSpineMaster.waiting, true);
        }

        if (!string.IsNullOrEmpty(advSpineMaster.expression))
        {
            skeletonAnimation.AnimationState.SetAnimation(1, advSpineMaster.expression, false);
        }
        else if (!string.IsNullOrEmpty(advSpineMaster.expression_loop))
        {
            skeletonAnimation.AnimationState.SetAnimation(1, advSpineMaster.expression_loop, true);
        }

        if (!string.IsNullOrEmpty(advSpineMaster.mouthClosed))
        {
            skeletonAnimation.AnimationState.SetAnimation(2, advSpineMaster.mouthClosed, false);
        }

        
        
    }

    private async UniTask OpenSignContract(int oldLevel,int newLevel)
    {
        if(mSignContract == null)
            mSignContract = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeCharacterUnitSignContract, CanvasType.App1) as UIHomeCharacterUnitSignContract;
        await mSignContract.SetUpLevelUpAsync(characterId_,oldLevel,newLevel);
        await mSignContract.ShowAsync();
    }
}
