﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using MiniJSON;

public class UIPuzzleMainWindow : UIDialogBase
{   
    [SerializeField] DisPlayPuzzle PlayPuzzleController;
    [SerializeField] DisChoosePuzzle ChoosePuzzleController;

    [SerializeField] Text TipsH;
    [SerializeField] Text TipsV;

    [SerializeField] UIButton skipButton;

    public UnityEvent OnComplete => puzzleControler.onFinishGame;
    public UnityEvent OnCancel => skipButton.OnTouchUpInside;


    private PuzzleDataFormate PuzzleData;

    private PuzzleControl puzzleControler;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        PuzzleData = new PuzzleDataFormate();
        puzzleControler = new PuzzleControl();
        puzzleControler.textH = TipsH;
        puzzleControler.textV = TipsV;
        // skipButton.OnTouchUpInside.GuardSubscribeAsync(onClose).AddTo(mSubscriptions);
    }
    private async UniTask<Dictionary<TId, T>> Parse<TId, T>(string filename) where T : BaseDataParser<TId>, new()
    {
        Dictionary<TId, T> dict = new Dictionary<TId, T>();

        string jsonText = null;

        jsonText = await ResourceManager.Instance.LoadLocalizeAssetsDataAsync(filename);

        if (string.IsNullOrEmpty(jsonText))
        {
            return dict;
        }

        
        var kvList = Json.Deserialize(jsonText) as List<object>;
        foreach (var kv in kvList)
        {
            T data = new T();
            data.Init<T>(kv as Dictionary<string, object>);
#if UNITY_EDITOR
            if (dict.ContainsKey(data.GetId()))
            {
                Log.Error($"file {filename} has duplicate key: {data.GetId()}!!");
                continue;
            }
#endif
            dict.Add(data.GetId(), data);
        }


        return dict;
    }
    public async UniTask Setup(int puzzleId)
    {
        
        Dictionary<int, WordPuzzleMaster> WordPuzzle= await Parse<int, WordPuzzleMaster>("WordPuzzleMaster");
        var wordPuzzles =WordPuzzle.Values;
        foreach (var wordPuzzle in wordPuzzles)
        {
            
            if (wordPuzzle.levelID == puzzleId)
            {
                PuzzleData.AddWords(wordPuzzle);
                if (wordPuzzle.canSkip==0)
                {
                    skipButton.gameObject.SetActive(false);
                }
            }
        }
        await PlayPuzzleController.DrawPuzzle(PuzzleData);
        
        TipsH.text = "";
        TipsV.text = "";

        foreach(GameObject o in PuzzleData.AllButtons.Values){
            if(o!=null) {
                //Debug.Log("Bind "+o.name);
                o.GetComponent<UIButton>().onClick.GuardSubscribeAsync<GameObject>(onClickPlay).AddTo(mSubscriptions);
            } 
        }
        await ChoosePuzzleController.DrawPuzzle(PuzzleData);
        foreach(GameObject i in ChoosePuzzleController.PuzzleButtons){
            //Debug.Log("Bind "+i.name);
            i.GetComponent<UIButton>().onClick.GuardSubscribeAsync<GameObject>(onClickChoose).AddTo(mSubscriptions);
        }

        onClickPlay(PlayPuzzleController.GetStartButton());
        //OnComplete.AddListener(PlayPuzzleController.);
    }

    private async UniTask onClickPlay(GameObject o){
        Debug.Log("Click" + o.name);
        await puzzleControler.PlayPuzzle(o,PuzzleData);

    }
    private async UniTask onClickChoose(GameObject o){
        Debug.Log("Click" + o.name);
        await puzzleControler.ChoosePuzzle(o,PuzzleData);
    }

    private void SetTestData(){
        PuzzleData.AddWords(false,"贝多芬",0,51,"古典主义时期德国作曲家，扼住命运的喉咙","000");
        PuzzleData.AddWords(false,"命途多舛",1,32,"命运充满不顺。指一生坎坷，屡受挫折，出自唐·王勃《滕王阁饯别序》","0001");
        PuzzleData.AddWords(true,"命运交响曲",0,32,"德国作曲家路德维希·凡·贝多芬创作的交响曲，作品67号，又名《c小调第五交响曲》","00000");
        PuzzleData.AddWords(false,"此曲只应天上有",1,26,"人间能得几回闻上一句，出自唐·杜甫《赠花卿》","1000000");
        PuzzleData.AddWords(false,"天籁之音",0,66,"形容声音十分动听悦耳","0001");
        PuzzleData.AddWords(false,"此时无声胜有声",0,81,"别有幽愁暗恨生下一句，出自唐·白居易《琵琶行》","1000001");
    }

    public async UniTask onClose()
    {
        await UI.Page.CloseCurrentPage();
    }
}
