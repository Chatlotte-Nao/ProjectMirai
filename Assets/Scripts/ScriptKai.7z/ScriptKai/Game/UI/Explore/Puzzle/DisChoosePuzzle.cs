﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class DisChoosePuzzle : MonoBehaviour
{   
    public List<GameObject> PuzzleButtons;
    public async UniTask DrawPuzzle(PuzzleDataFormate pd)
    {
        PuzzleButtons = new List<GameObject>();
        int k=0;
        List<string> WList = new List<string>();
        foreach(GameObject i in pd.AllButtons.Values){
            if(i!= null && i.GetComponent<PuzzleButtonInfo>().Character != "" && i.GetComponentInChildren<TextMeshProUGUI>().text == "") 
                WList.Add(i.GetComponent<PuzzleButtonInfo>().Character);
        }

        WList = ListRandom(WList);
        foreach (string i in WList)
        {
            if(i != ""){
                try
                {
                    GameObject button = transform.Find("SelectBg (" + k + ")").gameObject;
                    Debug.Log(button + " " + button.transform.GetComponentInChildren<TMPro.TextMeshPro>());
                    button.transform.GetComponentInChildren<TextMeshProUGUI>().text = i;
                    PuzzleButtons.Add(button);
                }
                catch { Debug.Log(k + " ??"); }
                k++;
            }
        }
    }
    
    private static List<string> ListRandom(List<string> myList)
    {

        var ran = new System.Random();
        List<string> newList = new List<string>();
        int index = 0;
        for (int i = 0; i < myList.Count; i++)
        {
            index = ran.Next(0, myList.Count-1);
            if (index != i)
            {
                var temp = myList[i];
                myList[i] = myList[index];
                myList[index] = temp;
            }
        }
        return myList;
    }
    
}
