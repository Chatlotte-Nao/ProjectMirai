﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using TMPro;

public class DisPlayPuzzle : MonoBehaviour
{
    // ReSharper disable Unity.PerformanceAnalysis

    private GameObject StartButton;
    public async UniTask DrawPuzzle(PuzzleDataFormate pd)
    {
        int WordNum = pd.WordsNum;
        for(int i =0;i<WordNum;i++){
            string WordNow = pd.Words[i];
            string tips = pd.Tips[i];
            int direction = pd.Directions[i];
            int startpos = pd.StartPositions[i];
            int len = WordNow.Length;
            int step = 1 + 9 * direction;
            bool keyword = pd.KeyWord[i];
            string TipsIndex = pd.TipsIndex[i];
            List<GameObject> buttons = new List<GameObject>();
            for(int j = 0;j<len;j++){
                int posNow = startpos + j * step;
                string CharacterNow = WordNow[j].ToString();
                GameObject button = transform.GetChild(posNow).gameObject;
                if (keyword)
                {
                    button.transform.GetChild(1).gameObject.SetActive(true);
                    if (j == 0) StartButton = button;
                }
                Debug.Log(button);
                if(!pd.AllButtons.ContainsKey(posNow)) pd.AllButtons.Add(posNow,button);
                buttons.Add(button);
                PuzzleButtonInfo info = button.GetComponent<PuzzleButtonInfo>();
                info.pos = posNow;
                if(direction == 0) info.TipsH = tips;
                else info.TipsV = tips;
                info.Character = CharacterNow;
                info.Wordindex.Add(i);
                info.WordPos.Add(j);
                info.direction.Add(direction);
                info.setFalseFlag();
                button.transform.GetChild(0).gameObject.SetActive(true);
                if(TipsIndex[j] == '1'){
                    var textObj = button.GetComponentInChildren<TextMeshProUGUI>();
                    textObj.text = CharacterNow;
                    textObj.color = Color.grey;
                    info.setRightFlag();
                }
                else{
                    button.GetComponentInChildren<TextMeshProUGUI>().text = "";
                    info.setFalseFlag();
                }
            }
            pd.Buttons.Add(buttons);
        }
    }

    public GameObject GetStartButton() => StartButton;
}
