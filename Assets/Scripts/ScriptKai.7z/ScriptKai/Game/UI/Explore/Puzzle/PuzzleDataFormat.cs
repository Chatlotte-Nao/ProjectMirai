﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;

public class PuzzleDataFormate
{
    public DisPlayPuzzle DP;
    public List<bool> KeyWord;
    public List<string> Words;
    public List<int> Directions;
    public List<int> StartPositions;
    public List<string> Tips;
    public List<List<GameObject>> Buttons;

    public List<bool> Finish;

    public Dictionary<int,GameObject> AllButtons;

    public List<bool> Check;

    public List<string> TipsIndex;

    public int WordsNum;

    public List<int> InputNum;

    public PuzzleDataFormate()
    {
        KeyWord = new List<bool>();
        Words = new List<string>();
        Directions = new List<int>();
        StartPositions = new List<int>();
        Tips = new List<string>();
        WordsNum = 0;
        Buttons = new List<List<GameObject>>();
        Check = new List<bool>();
        InputNum = new List<int>();
        AllButtons = new Dictionary<int,GameObject>();
        TipsIndex = new List<string>();
        Finish = new List<bool>();

    }

    public void AddWords(bool keyword,string word,int direction,int startpos,string tip,string TipsIndex)
    {
        KeyWord.Add(keyword);
        Words.Add(word);
        Directions.Add(direction);
        StartPositions.Add(startpos);
        Tips.Add(tip);
        
        Check.Add(false);
        InputNum.Add(0);
        Finish.Add(false);
        
        this.TipsIndex.Add(TipsIndex);
        WordsNum++;
    }

    public void AddWords(WordPuzzleMaster wpm)
    {
        KeyWord.Add(wpm.keyWord == 0 ? false : true);
        Words.Add(wpm.word);
        Directions.Add(wpm.direction);
        StartPositions.Add((wpm.position[1] - 1) * 10 + wpm.position[0] - 1);
        Tips.Add(wpm.desc);
        Check.Add(false);
        InputNum.Add(0);
        Finish.Add(false);
        TipsIndex.Add(wpm.hint);
        WordsNum++;

    }

}
