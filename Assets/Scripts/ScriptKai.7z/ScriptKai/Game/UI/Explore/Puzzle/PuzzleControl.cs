﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using TMPro;
using UnityEngine.Events;
using UnityEngine.EventSystems;

public class PuzzleControl
{
    private bool isChoosen;

    private GameObject ChoosenPuzzle;

    public Text textH;
    public Text textV;

    private bool FinishGame = false;
    public UnityEvent onFinishGame = new UnityEvent();

    private int wordNowindex;
    public async UniTask PlayPuzzle(GameObject o,PuzzleDataFormate pd)
    {
        PuzzleButtonInfo info = o.GetComponent<PuzzleButtonInfo>();
        if (info.getFlag() == false)
        {
            int wordsnum = info.Wordindex.Count;
            Debug.Log(wordsnum);
            int tempindex=0;
            for(int i=0;i<wordsnum;i++){
                int temp = info.Wordindex[i];
                if(pd.Finish[temp] == true) continue;
                Debug.Log("Not finish");
                tempindex = temp;
                if(info.direction[i] == 0) break;
            }
            if (!isChoosen)
            {
                ChoosenPuzzle = o;
                ChangeColor(2);
                isChoosen = true;
                textH.text = o.GetComponent<PuzzleButtonInfo>().TipsH;
                textV.text = o.GetComponent<PuzzleButtonInfo>().TipsV;
                wordNowindex = tempindex;
            }
            else
            {
                if (o == ChoosenPuzzle)
                {
                    ChangeColor(1);
                    ChoosenPuzzle = null;
                    isChoosen = false;
                    textH.text = "";
                    textV.text = "";
                    wordNowindex = -1;
                }
                else
                {
                    ChangeColor(1);
                    ChoosenPuzzle = o;
                    ChangeColor(2);
                    textH.text = o.GetComponent<PuzzleButtonInfo>().TipsH;
                    textV.text = o.GetComponent<PuzzleButtonInfo>().TipsV;
                    wordNowindex = tempindex;
                }
            }
        }
    }
    
    

    public async UniTask ChoosePuzzle(GameObject o, PuzzleDataFormate pd)
    {
        TextMeshProUGUI buttonColor = o.GetComponentInChildren<TextMeshProUGUI>();
        if (isChoosen && ChoosenPuzzle != null && buttonColor.color != Color.grey)
        {
            ChoosenPuzzle.GetComponentInChildren<TextMeshProUGUI>().text = o.GetComponentInChildren<TextMeshProUGUI>().text;
            
            PuzzleButtonInfo info = ChoosenPuzzle.GetComponent<PuzzleButtonInfo>();
            int pos = info.pos;
            if(info.ChoosePuzzle != null) info.ChoosePuzzle.GetComponentInChildren<TextMeshProUGUI>().color = Color.black;

            info.ChoosePuzzle = o;
            buttonColor.color = Color.grey;
            ChangeColor(1);
            List<int> index = info.Wordindex;
            Debug.Log(index.Count.ToString());
            bool Check = false;
            foreach (int i in index)
            {
                int InputNum = 0;
                string ans = "";
                foreach (GameObject x in pd.Buttons[i])
                {
                    if (x.GetComponentInChildren<TextMeshProUGUI>().text != "") InputNum++;
                    ans += x.GetComponentInChildren<TextMeshProUGUI>().text;
                }
                if (InputNum == pd.Words[i].Length)
                {
                    CheckAnswer(i, pd);
                    Check = true;
                }
            }
            GameObject posH = null;
            GameObject posV = null;
            if (!Check)
            {
                isChoosen = true;
                int startpos = pd.StartPositions[wordNowindex];
                int length = pd.Words[wordNowindex].Length;
                int step = (1 + 9 * pd.Directions[wordNowindex]);
                int posW = (info.pos - startpos) / step;
                for (int j = 0; j < length; j++)
                {
                    int posN = ((posW + j) % length) * step + startpos;
                    //Debug.Log(startpos + " " + info.pos + " " + posN + " " + posW + " " + step);
                    if (pd.AllButtons[posN].GetComponentInChildren<TextMeshProUGUI>().text == "")
                    {
                        if (step == 1) posH = pd.AllButtons[posN];
                        else if (step == 10) posV = pd.AllButtons[posN];
                        Debug.Log("find" + pd.AllButtons[posN].name);
                        break;
                    }
                }
                    
                if (posH != null) ChoosenPuzzle = posH;
                else ChoosenPuzzle = posV;
            }
            else{
                isChoosen = false;
                if(wordNowindex != -1){
                    foreach(GameObject i in pd.Buttons[wordNowindex]){
                        if(i.GetComponent<PuzzleButtonInfo>().getFlag() == false){
                            isChoosen = true;
                            ChoosenPuzzle = i;
                            break;
                        }
                    }
                }
                else{
                    ChoosenPuzzle = FindNext(pd,pos);
                    if(ChoosenPuzzle != null){
                        isChoosen = true;  
                        textH.text = ChoosenPuzzle.GetComponent<PuzzleButtonInfo>().TipsH;
                        textV.text = ChoosenPuzzle.GetComponent<PuzzleButtonInfo>().TipsV;
                        int tempindex = 0;
                        int indexnum = ChoosenPuzzle.GetComponent<PuzzleButtonInfo>().Wordindex.Count;
                        for(int i=0;i<indexnum;i++){
                            int temp = ChoosenPuzzle.GetComponent<PuzzleButtonInfo>().Wordindex[i];
                            if(pd.Finish[temp] == true) continue;
                            Debug.Log("Not finish");
                            tempindex = temp;
                            Debug.Log(temp);
                            if(info.direction[i] == 0) break;
                        }
                        wordNowindex = tempindex;
                    } 
                }
            }
            ChangeColor(2);
        }
    }

    private void ChangeColor(int state)
    {
        if (ChoosenPuzzle != null)
        {
            GameObject puzzleCHooseBox = ChoosenPuzzle.transform.GetChild(3).transform.gameObject;
            if (state == 1) puzzleCHooseBox.SetActive(false);
            else if (state == 2) puzzleCHooseBox.SetActive(true);
        }
    }

    private bool CheckAnswer(int Wordindex, PuzzleDataFormate pd)
    {
        List<GameObject> buttons = pd.Buttons[Wordindex];
        string word = pd.Words[Wordindex];
        string ansWord = "";
        foreach (GameObject o in buttons)
        {
            ansWord += o.GetComponentInChildren<TextMeshProUGUI>().text;
        }
        Debug.Log(ansWord + " " + word);
        if (word == ansWord)
        {
            //right ans
            pd.Finish[Wordindex] = true;
            if (pd.KeyWord[Wordindex]) onFinishGame.Invoke();
            wordNowindex = -1;
            foreach (GameObject o in buttons)
            {
                o.transform.GetChild(0).GetComponent<Image>().color = Color.green;
                o.GetComponent<PuzzleButtonInfo>().setRightFlag();
                o.GetComponentInChildren<TextMeshProUGUI>().color =Color.black;
            }

            return true;
        }

        else
        {
            foreach (GameObject o in buttons)
            {
                if (!o.GetComponent<PuzzleButtonInfo>().getFlag())
                {
                    o.GetComponentInChildren<TextMeshProUGUI>().text = "";
                    o.GetComponent<PuzzleButtonInfo>().ChoosePuzzle.GetComponentInChildren<TextMeshProUGUI>().color = Color.black;
                    o.GetComponent<PuzzleButtonInfo>().ChoosePuzzle = null;
                }
            }
            return false;
        }
    }

    private GameObject FindNext(PuzzleDataFormate pd , int pos){
        int offset = -1;
        int dis =100;
        foreach(List<GameObject> i in pd.Buttons){
            foreach(GameObject o in i){
                PuzzleButtonInfo info = o.GetComponent<PuzzleButtonInfo>();
                if(info.pos == pos) continue;
                if(info.getFlag() == false){
                    int Ndis = Mathf.Abs(info.pos/10-pos/10)+Mathf.Abs(info.pos%10-pos%10);
                    if(Ndis < dis){
                        offset = info.pos;
                        dis = Ndis;
                        //Debug.Log(pos+" "+)
                    }
                }
            }
        }
        Debug.Log(offset);
        if(offset!=-1) return pd.AllButtons[offset];
        return null;
    } 
}