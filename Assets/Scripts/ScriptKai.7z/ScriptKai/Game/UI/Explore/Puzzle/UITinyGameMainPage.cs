﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System;

public class UITinyGameMainPage : UIPageBase
{

    UITinyGameParam tinyGameParam = null;

    //private UIDialogBase mMainWindow = null;

    private UIPuzzleMainWindow puzzleMainWindow = null;
    private UIPushUpMainWindow pushUpMainWindow = null;
    private UIFishingMainWindow fishingMainWindow = null;
    private UIRhythmMainWindow rhythmMainWindow = null;
    private UICircuitMainWindow circuitMainWindow = null;
    private UISlidingMainWindow slidingMainWindow = null;
	private UIFruitCutMainWindow fruitCutMainWindow = null;
    private UIMakeBreadMainWindow makeBreadMainWindow = null;
    private UICatchDollMainWindow catchDollMainWindow = null;
    private UIReasoningMainWindow reasoningMainWindow = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync();
        tinyGameParam = (UITinyGameParam)param;
        switch (DataManager.Instance.Master.PuzzleExplore[tinyGameParam.id].typeId)
        {
            case 1:
                puzzleMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIPuzzleMainWindow, CanvasType.App0) as UIPuzzleMainWindow;
                await puzzleMainWindow.Setup(tinyGameParam.id);
                puzzleMainWindow.OnComplete.GuardSubscribeAsync(OnPuzzleComplete).AddTo(mSubscriptions);
                puzzleMainWindow.OnCancel.GuardSubscribeAsync(OnPuzzleCancel).AddTo(mSubscriptions);
                break;
            case 2:
                pushUpMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIPushUpMainWindow, CanvasType.App0) as UIPushUpMainWindow;
                await pushUpMainWindow.Setup(tinyGameParam.id);
                pushUpMainWindow.OnComplete.GuardSubscribeAsync(OnPuzzleComplete).AddTo(mSubscriptions);
                pushUpMainWindow.OnPuzzleFailed.GuardSubscribeAsync(OnPuzzleFailed).AddTo(mSubscriptions);
                pushUpMainWindow.OnCancel.GuardSubscribeAsync(OnPuzzleCancel).AddTo(mSubscriptions);
                break;
            case 3:
                fishingMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIFishingMainWindow, CanvasType.App0) as UIFishingMainWindow;
                await fishingMainWindow.Setup(tinyGameParam.id);
                fishingMainWindow.OnComplete.GuardSubscribeAsync(OnPuzzleComplete).AddTo(mSubscriptions);
                fishingMainWindow.OnCancel.GuardSubscribeAsync(OnPuzzleCancel).AddTo(mSubscriptions);
                break;
            case 4:
                rhythmMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIRhythmMainWindow, CanvasType.App0) as UIRhythmMainWindow;
                await rhythmMainWindow.Setup(tinyGameParam.id);
                Debug.Log(tinyGameParam.id);
                rhythmMainWindow.OnComplete.GuardSubscribeAsync(OnPuzzleComplete).AddTo(mSubscriptions);
                break;
            case 5:
                circuitMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIRhythmMainWindow, CanvasType.App0) as UICircuitMainWindow;
                await circuitMainWindow.Setup(tinyGameParam.id);
                circuitMainWindow.OnComplete.GuardSubscribeAsync(OnPuzzleComplete).AddTo(mSubscriptions);
                circuitMainWindow.OnCancel.GuardSubscribeAsync(OnPuzzleCancel).AddTo(mSubscriptions);
                break;
            case 6:
                slidingMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UISlidingMainWindow, CanvasType.App0) as UISlidingMainWindow;
                await slidingMainWindow.Setup(tinyGameParam.id);
                slidingMainWindow.OnComplete.GuardSubscribeAsync(OnPuzzleComplete).AddTo(mSubscriptions);
                slidingMainWindow.OnCancel.GuardSubscribeAsync(OnPuzzleCancel).AddTo(mSubscriptions);
                break;
			  case 7:
                fruitCutMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIFruitCutMainWindow, CanvasType.App0) as UIFruitCutMainWindow;
                await fruitCutMainWindow.Setup(tinyGameParam.id);
                fruitCutMainWindow.OnPuzzleFailed.GuardSubscribeAsync(OnPuzzleFailed).AddTo(mSubscriptions);
                fruitCutMainWindow.OnComplete.GuardSubscribeAsync(OnPuzzleComplete).AddTo(mSubscriptions);  

                break;
            case 8:
                Camera cam = MapSceneManager.Instance.CurrentScene.GetCameraController().GetCamera();
                while (cam.orthographicSize > 2.6f)
                {
                    float lerpnum = Mathf.Lerp(cam.orthographicSize, 2.6f, 0.5f);
                    cam.orthographicSize = lerpnum;
                    await UniTask.Delay(10);
                }
                makeBreadMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIMakeBreadMainWindow, CanvasType.App0) as UIMakeBreadMainWindow;
                await makeBreadMainWindow.Setup(tinyGameParam.id);
                makeBreadMainWindow.OnComplete.GuardSubscribeAsync(OnPuzzleComplete).AddTo(mSubscriptions);
                break;
            case 9:
                catchDollMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UICatchDollMainWindow, CanvasType.App0) as UICatchDollMainWindow;
                await catchDollMainWindow.Setup(tinyGameParam.id);
                catchDollMainWindow.OnComplete.GuardSubscribeAsync(OnPuzzleComplete).AddTo(mSubscriptions);                
                catchDollMainWindow.OnCancel.GuardSubscribeAsync(OnPuzzleCancel).AddTo(mSubscriptions);
                break;

            case 11:
                reasoningMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIReasoningMainWindow, CanvasType.App0) as UIReasoningMainWindow;
                await reasoningMainWindow.SetUpLines(tinyGameParam.id);
                reasoningMainWindow.OnComplete.GuardSubscribeAsync(OnPuzzleComplete).AddTo(mSubscriptions);
                reasoningMainWindow.OnCancel.GuardSubscribeAsync(OnPuzzleCancel).AddTo(mSubscriptions);
                reasoningMainWindow.OnFailed.GuardSubscribeAsync(OnPuzzleFailed).AddTo(mSubscriptions);
                break;
            default:
                break;
        }

    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
        if (puzzleMainWindow != null)
        {
            await puzzleMainWindow.ShowAsync();
        }
        if (pushUpMainWindow != null)
        {
            await pushUpMainWindow.ShowAsync();
        }
        if (fishingMainWindow != null)
        {
            await fishingMainWindow.ShowAsync();
        }
        if (rhythmMainWindow != null)
        {
            await rhythmMainWindow.ShowAsync();
        }
        if (circuitMainWindow != null)
        {
            await circuitMainWindow.ShowAsync();
        }
        if (slidingMainWindow != null)
        {
            await slidingMainWindow.ShowAsync();
        }
		 if (fruitCutMainWindow != null)
        {
            await fruitCutMainWindow.ShowAsync();
        }
        if (makeBreadMainWindow != null)
        {
            await makeBreadMainWindow.ShowAsync();
        }
        if (catchDollMainWindow != null)
        {
            await catchDollMainWindow.ShowAsync();
        }
        if(reasoningMainWindow != null)
        {
            await reasoningMainWindow.ShowAsync();
            reasoningMainWindow.Setup(tinyGameParam.id);
        }

    }


    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        if (puzzleMainWindow != null)
        {
            await puzzleMainWindow.HideAsync();
        }
        if (pushUpMainWindow != null)
        {
            await pushUpMainWindow.HideAsync();
        }
        if (fishingMainWindow != null)
        {
            await fishingMainWindow.HideAsync();
        }
        if (rhythmMainWindow != null)
        {
            await rhythmMainWindow.HideAsync();
        }
        if (circuitMainWindow != null)
        {
            await circuitMainWindow.HideAsync();
        }
        if (slidingMainWindow != null)
        {
            await slidingMainWindow.HideAsync();
        }
		 if (fruitCutMainWindow != null)
        {
            await fruitCutMainWindow.HideAsync();
        }
        if (makeBreadMainWindow != null)
        {
            await makeBreadMainWindow.HideAsync();
        }
        if (catchDollMainWindow != null)
        {
            await catchDollMainWindow.HideAsync();
        }
        if(reasoningMainWindow!=null)
        {
            await reasoningMainWindow.HideAsync();
        }
    }


    private async UniTask OnPuzzleComplete()
    {
        tinyGameParam.onFinish?.Invoke(true);
        await UI.Page.CloseCurrentPage();
    }

    private async UniTask OnPuzzleFailed()
    {
        tinyGameParam.onFinish?.Invoke(false);
        await UI.Page.CloseCurrentPage();
    }

    private async UniTask OnPuzzleCancel()
    {
        tinyGameParam.onCancel?.Invoke();
        await UI.Page.CloseCurrentPage();
    }



    public override void Dispose()
    {
        base.Dispose();
        tinyGameParam = null;

        if (puzzleMainWindow != null)
        {
            puzzleMainWindow.Dispose();
            puzzleMainWindow = null;
        }
        if (pushUpMainWindow != null)
        {
            pushUpMainWindow.Dispose();
            pushUpMainWindow = null;
        }
        if (fishingMainWindow != null)
        {
            fishingMainWindow.Dispose();
            fishingMainWindow = null;
        }
        if (rhythmMainWindow != null)
        {
            rhythmMainWindow.Dispose();
            rhythmMainWindow = null;
        }
        if (circuitMainWindow != null)
        {
            circuitMainWindow.Dispose();
            circuitMainWindow = null;
        }
        if (slidingMainWindow != null)
        {
            slidingMainWindow.Dispose();
            slidingMainWindow = null;
        }
		if (fruitCutMainWindow != null)
        {
            fruitCutMainWindow.Dispose();
            fruitCutMainWindow = null;
        }
        if (makeBreadMainWindow != null)
        {
            makeBreadMainWindow.Dispose();
            makeBreadMainWindow = null;
        }
        if (catchDollMainWindow != null)
        {
            catchDollMainWindow.Dispose();
            catchDollMainWindow = null;
        }
        if(reasoningMainWindow!=null)
        {
            reasoningMainWindow.Dispose();
            reasoningMainWindow = null;
        }
    }
}

public class UITinyGameParam
{
    public int id;
    public Action<bool> onFinish;
    public Action onCancel;
}