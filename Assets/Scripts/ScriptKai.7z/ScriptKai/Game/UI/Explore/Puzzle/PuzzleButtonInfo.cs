﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class PuzzleButtonInfo : MonoBehaviour
{
    private bool ifRight;
    public int pos;
    public string Character;
    public string TipsV; 
    public string TipsH;
    public List<int> Wordindex;

    public List<int> direction;
    public List<int> WordPos;
    public GameObject ChoosePuzzle;

    public void setRightFlag() => ifRight = true;

    public void setFalseFlag() => ifRight = false;

    public bool getFlag() => ifRight;
}