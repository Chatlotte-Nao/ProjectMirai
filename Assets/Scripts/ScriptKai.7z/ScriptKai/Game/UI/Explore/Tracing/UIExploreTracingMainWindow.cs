using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Map;
using UnityEngine.Events;
using UnityEngine.AI;
using UnityEngine.UI;

public class UIExploreTracingMainWindow : UIDialogBase
{
    [SerializeField] Image warnBar;
    [SerializeField] UIText distanceText;


    private MiniCharacter tracingCharacter = null;


    public UIBoolEvent OnTracingEnd = new UIBoolEvent();


    private bool mStarted = false;

    private float radialRed = 0f;
    private List<Vector3> routePoints = new List<Vector3>();

    private int currentPointIdx = 0;


    private float dangerTime = 0f;
    private float restEndTime = 0f;
    private float warnPauseTime = 0f;

    private int mState = 0;

    private TracingMaster master = null;
    NavMeshPath path;

    public async UniTask SetupAsync(int gameId)
    {
        master = DataManager.Instance.Master.Tracing[gameId];

        var miniCharacterId = master.characterName;

        var co = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Map/MiniCharacter/"+miniCharacterId);
        if (co != null)
        {
            tracingCharacter = co.GetComponent<MiniCharacter>();
            tracingCharacter.Initialize();

            tracingCharacter.SetPosition(MapSceneManager.Instance.CurrentScene.locations[master.beginLabel].transform.position);
            await tracingCharacter.CreateMessage();

            tracingCharacter.GetComponent<NavMeshAgent>().speed = 1f;
        }

        foreach (var p in master.pauseLabel)
        {
            routePoints.Add(MapSceneManager.Instance.CurrentScene.locations[p].transform.position);
        }
        routePoints.Add(MapSceneManager.Instance.CurrentScene.locations[master.endLabel].transform.position);

        radialRed = (master.sightAngle/2)*Mathf.Deg2Rad;
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        DoStart();
    }

    public override void Dispose()
    {
        base.Dispose();
        if (tracingCharacter != null)
        {
            Destroy(tracingCharacter.gameObject);
            tracingCharacter = null;
        }
    }

    void Update()
    {
        if (!mStarted) return;

        var distanceVector = tracingCharacter.transform.position - MapSceneManager.Instance.CurrentScene.player.transform.position;
        distanceVector.y = 0;
        

        
        NavMesh.CalculatePath(MapSceneManager.Instance.CurrentScene.player.transform.position, tracingCharacter.transform.position, NavMesh.AllAreas, path);

        var distance = 0f;
        for ( int i = 1; i < path.corners.Length; ++i )
        {
            distance += Vector3.Distance( path.corners[i-1], path.corners[i] );
        }

        distanceText.SetRawText(distance.ToString());

        bool npcPause = false;

        if (distance <= master.sightDistance && Vector3.Dot(-distanceVector, tracingCharacter.transform.rotation.eulerAngles) >= Mathf.Cos(radialRed))
        {
            if (mState != -2)
            {
                mState = -2;
                Debug.Log(Vector3.Dot(-distanceVector, tracingCharacter.transform.rotation.eulerAngles));
                DoFail();
            }
            return;
        }

        if (distance <= master.warnDistance)
        {
            dangerTime += Time.deltaTime;
            if (mState != -1)
            {
                mState = -1;
                warnPauseTime = 0f;
                tracingCharacter.SetMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, master.warnBubbleClew[Random.Range(0, master.warnBubbleClew.Count)]));
                npcPause = true;
            }
            else
            {
                warnPauseTime += Time.deltaTime;
                if (warnPauseTime >= 3f)
                {
                    tracingCharacter.SetMessage(null);
                    npcPause = false;
                }
                else
                {
                    npcPause = true;
                }
            }
            
            if (dangerTime >= master.warnTime)
            {
                DoFail();
                return;
            }
        }
        else if (distance <= master.safeDistance)
        {
            //ok
            if (mState != 0)
            {
                mState = 0;
                tracingCharacter.SetMessage(null);
            }
            dangerTime = 0f;
            
        }
        else if (distance <= master.outsideDistance)
        {
            //ok, balloon
            if (mState != 1)
            {
                mState = 1;
                tracingCharacter.SetMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, master.outsideBubbleClew[Random.Range(0, master.outsideBubbleClew.Count)]));
            }
            dangerTime = 0f;
            
        }
        else
        {
            if (mState != 2)
            {
                mState = 2;
                tracingCharacter.SetMessage(null);
            }
            dangerTime += Time.deltaTime;
            if (dangerTime >= master.warnTime)
            {
                DoFail();
                return;
            }
        }

        if (restEndTime > 0)
        {
            if (Time.realtimeSinceStartup >= restEndTime)
            {
                tracingCharacter.MoveTo(routePoints[currentPointIdx], onMoveComplete);
                restEndTime = -1;
            }
        }

        if (restEndTime <= 0)
        {
            if (npcPause)
            {
                tracingCharacter.GetComponent<NavMeshAgent>().isStopped = true;
                tracingCharacter.PlayIdleAnimation();
            }
            else
            {
                tracingCharacter.GetComponent<NavMeshAgent>().isStopped = false;
                tracingCharacter.PlayMoveAnimation();
            }
        }

        

        warnBar.fillAmount = dangerTime / master.warnTime;
    }

    void DoStart()
    {
        path = new NavMeshPath();
        mStarted = true;
        tracingCharacter.MoveTo(routePoints[0], onMoveComplete);
    }

    void DoSuccess()
    {
        mStarted = false;
        OnTracingEnd.Invoke(true);
    }

    void DoFail()
    {
        mStarted = false;
        OnTracingEnd.Invoke(false);
        tracingCharacter.CancelMove();
    }

    private void onMoveComplete()
    {
        Log.Debug($"到达节点 {currentPointIdx}");
        currentPointIdx++;
        if (currentPointIdx == routePoints.Count)
        {
            //goal
            DoSuccess();
        }
        else
        {
            //rest
            restEndTime = Time.realtimeSinceStartup+master.pauseTime[currentPointIdx-1];
            tracingCharacter.SetMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, master.pauseBubbleClew[currentPointIdx-1]));
            tracingCharacter.PlayIdleAnimation();
        }
    }
}
