using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Map;

public class UIExploreTracingPage : UIPageBase
{
    UIPadController mPad = null;
    UIExploreTracingMainWindow mMainWindow = null;


    private List<AMapRuntimeObject> mMapObjects = new List<AMapRuntimeObject>();

    UITinyGameParam tinyGameParam = null;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);

        tinyGameParam = (UITinyGameParam)param;
        
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIExploreTracingMainWindow, CanvasType.App0) as UIExploreTracingMainWindow;
        await mMainWindow.SetupAsync(tinyGameParam.id);
        mMainWindow.OnTracingEnd.GuardSubscribeAsync(OnTracingEnd).AddTo(mSubscriptions);
        mPad = await UI.Dialog.CreateAsync(UIPrefabId.UIPadController, CanvasType.BG) as UIPadController;

        foreach (var kv in MapSceneManager.Instance.CurrentScene.characters)
        {
            if (kv.Value.gameObject.activeSelf) mMapObjects.Add(kv.Value);
        }
        foreach (var kv in MapSceneManager.Instance.CurrentScene.iconObjects)
        {
            if (kv.Value.gameObject.activeSelf) mMapObjects.Add(kv.Value);
        }

        foreach (var item in mMapObjects)
        {
            item.gameObject.SetActive(false);
        }
        
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
        await mMainWindow.ShowAsync();
        await mPad.ShowAsync();
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await mMainWindow.HideAsync();
        await mPad.HideAsync();
    }

    private async UniTask OnTracingEnd(bool result)
    {
        await UI.ScreenEffect.Fade(1);
        foreach (var item in mMapObjects)
        {
            item.gameObject.SetActive(true);
        }
        await UI.Page.CloseCurrentPage();
        if (tinyGameParam.onFinish != null)
        {
            tinyGameParam.onFinish.Invoke(result);
        }
        await UI.ScreenEffect.Fade(0);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
        if (mPad != null)
        {
            mPad.Dispose();
            mPad = null;
        }
    }
}
