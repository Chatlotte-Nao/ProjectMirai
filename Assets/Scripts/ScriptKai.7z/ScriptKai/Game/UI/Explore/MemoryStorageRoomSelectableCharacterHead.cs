using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using Script.Game.UI.Common;
using UnityEngine;
using UnityEngine.UI;

public class MemoryStorageRoomSelectableCharacterHead : SelectableCharacterHead
{
    [SerializeField] UIButton clickBtn;
    [SerializeField] GameObject selectObject;
    public ClickEvent OnClick => clickBtn.onClick;
    
    public void OnSelect()
    {
        //childRect.anchoredPosition = new Vector2(-70, 0);
        selectObject.SetActive(true);
    }

    public void OnDeselect()
    {
        //childRect.anchoredPosition = Vector2.zero;
        selectObject.SetActive(false);
    }
}
