﻿using Pheonix.Core;
using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class UIOrganPage : UIPageBase
{
    private UIOrganMainWindow organMainWindow = null;

    UIOrganParam uiOrganParam = new UIOrganParam();

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync();
        uiOrganParam = (UIOrganParam)param;

        organMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIOrganMainWindow, CanvasType.App0) as UIOrganMainWindow;
        organMainWindow.OnComplete.GuardSubscribeAsync(OnComplete).AddTo(mSubscriptions);
        organMainWindow.CloseClick.GuardSubscribeAsync(CloseClick).AddTo(mSubscriptions);


    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
        if (organMainWindow != null)
        {
            await organMainWindow.ShowAsync();
        }
    }

    private async UniTask CloseClick(GameObject o)
    {
        var str= LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "Piano_Text");
        UI.Popup.ShowConfirm(string.Empty, str, CanvasType.App2, async (r)=>
        {
            if (r == UIPopupDialog.Result.OK)
            {
                
                Game.Sound.SoundPlayer.PlayBgm("M025");
                await UI.Page.CloseCurrentPage();
            }
        });
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        if (organMainWindow != null)
        {
            await organMainWindow.HideAsync();
        }
    }

    private async UniTask OnComplete()
    {
        uiOrganParam.onFinish?.Invoke(true);
        await UI.Page.CloseCurrentPage();
    }

    public override void Dispose()
    {
        base.Dispose();
        uiOrganParam = null;

        if (organMainWindow != null)
        {
            organMainWindow.Dispose();
            organMainWindow = null;
        }
    }
}


public class UIOrganParam
{
    public int id;
    public Action<bool> onFinish;
}