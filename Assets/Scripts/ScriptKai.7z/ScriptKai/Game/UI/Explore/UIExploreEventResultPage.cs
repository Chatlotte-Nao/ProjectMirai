﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIExploreEventResultPage : UIPageBase
{
    private bool isChangeScene = false;
    private UIExploreEventResultDialog mResultMain;


    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        mResultMain = await UI.Dialog.CreateAsync(UIPrefabId.UIExploreEventResultDialog, CanvasType.App1) as UIExploreEventResultDialog;
        await mResultMain.SetupAsync(param as ExploreEventViewModel);


        mResultMain.OnFinish.GuardSubscribeAsync(onFinish).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
        await mResultMain.ShowAsync(showType);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await mResultMain.HideAsync(showType);
    }

    private async UniTask onFinish(int result)
    {
        if (isChangeScene)
        {
            return;
        }

        isChangeScene = true;
        await UI.Page.CloseCurrentPage();

        if (SceneBase.Current.name == "ExploreScene")
        {
            HomeSceneParam p = new HomeSceneParam();
            p.enterType = HomeSceneParam.EnterType.FromExploreEvent;
            await GameSceneManager.Instance.ChangeSceneAsync<HomeScene>("HomeScene", p);
        }

        isChangeScene = false;
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mResultMain != null)
        {
            mResultMain.Dispose();
            mResultMain = null;
        }
    }
}
