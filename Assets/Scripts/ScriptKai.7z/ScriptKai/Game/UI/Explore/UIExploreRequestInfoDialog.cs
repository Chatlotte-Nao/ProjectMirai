﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;

public class UIExploreRequestInfoDialog : UIDialogBase
{
    [SerializeField] UIText titleText;
    [SerializeField] UIText descText;
    [SerializeField] UIText targetText;
    [SerializeField] UITexture standImage;

    [SerializeField] BaseItem itemPrefab;
    [SerializeField] RectTransform itemTransformParent;

    [SerializeField] UIButton giveupButton;
    [SerializeField] UIButton naviButton;


    public UnityEvent OnClickGiveup => giveupButton.OnTouchUpInside;
    public UnityEvent OnClickNavi => naviButton.OnTouchUpInside;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        
    }


    public void Setup(ExploreEventViewModel eventdata)
    {
        titleText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{eventdata.masterId}_title");
        descText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{eventdata.masterId}_desc");
        targetText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{eventdata.masterId}_target");
        // standImage.Load("CharacterMain/Stand", DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[eventdata.characterId].characterResourceId].standImageName);
    }

    
}
