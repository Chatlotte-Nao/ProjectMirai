﻿using Game.Sound;
using Pheonix.Core;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using System.Linq;
using Cysharp.Threading.Tasks;

public class UIOrganMainWindow : UIDialogBase
{
    [SerializeField] private UIButton closeBtn;
    public static UIOrganMainWindow instance;
    public UnityEvent OnComplete = new UnityEvent();

    public List<OrganKeyBoard> KeyBoards;
    
    public  bool MetronomePlaying = false;
    public ClickEvent CloseClick => closeBtn.onClick;
    public enum MusicTextType
    {
        none=0,
        letter=1,
        note,
        
    }

    public MusicTextType nowMusicTextType = MusicTextType.letter;

    [Serializable]
    public enum ViewType
    {
        Single=0,
        Dual=1,
        Front=2,
    }

    public ViewType nowViewType = 0;
    protected override void Awake()
    {
        base.Awake();
        instance = this;
       
    }

    private void Start()
    {
        SoundPlayer.StopBgm();
        closeButton = KeyBoards[(int)nowViewType].ReturnBtn;
        
    }
    private void Update()
    {

    }
    
    Dictionary<int, int> SoundTempDic = new Dictionary<int, int>();
    public void PlaySE(int soundInt,bool loop=false)
    {

        var t = SoundPlayer.PlaySe(soundInt, loop);
        if (SoundTempDic.ContainsKey(soundInt))
        {
            SoundTempDic[soundInt] = t;
        }
        else
        {
            SoundTempDic.Add(soundInt, t);
        }
    }
    public void StopSE(int soundInt,float fadeTime=0.5f)
    {
        if (SoundTempDic.ContainsKey(soundInt))
        {
            SoundPlayer.StopSe(SoundTempDic[soundInt],fadeTime);
        }
    }



    public void SetKeyBoardActive(UIOrganMainWindow.ViewType type)
    {
        nowViewType = type;
        foreach (var item in KeyBoards)
        {
            item.gameObject.SetActive(false);
        }
        var keyBoardObj = KeyBoards.Find(x => x.ViewType == nowViewType).gameObject;
        keyBoardObj.SetActive(true);
        closeButton = KeyBoards[(int)nowViewType].ReturnBtn;

    }




    public async void MetronomeChange(bool State, OrganKeyBoard.SEIndex MusicName, int speed = 60)
    {
        MetronomePlaying = !MetronomePlaying;
        while (MetronomePlaying)
        {
            await PlayMetroneme1Time(State,MusicName,speed);
        }

    }

    public int MetronomeSpeed = 60;
    private float timeSecond;
    public async UniTask PlayMetroneme1Time(bool State, OrganKeyBoard.SEIndex MusicName, int speed = 60)
    {
        PlaySE((int)MusicName, false);
        await UniTask.Delay(60000 / MetronomeSpeed);
    }

}
