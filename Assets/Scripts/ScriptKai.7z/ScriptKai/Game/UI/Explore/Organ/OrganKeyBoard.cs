﻿using Pheonix.Core;
using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class OrganKeyBoard : MonoBehaviour
{

    public enum SEIndex
    {
        _0A = 107,
        _0B = 108,

        _1C = 109,
        _1D = 110,
        _1E = 111,
        _1F = 112,
        _1G = 113,
        _1A = 114,
        _1B = 115,

        _2C = 116,
        _2D = 117,
        _2E = 118,
        _2F = 119,
        _2G = 120,
        _2A = 121,
        _2B = 122,

        _3C = 123,
        _3D = 124,
        _3E = 125,
        _3F = 126,
        _3G = 127,
        _3A = 128,
        _3B = 129,

        _4C = 130,
        _4D = 131,
        _4E = 132,
        _4F = 133,
        _4G = 134,
        _4A = 135,
        _4B = 136,

        _5C = 137,
        _5D = 138,
        _5E = 139,
        _5F = 140,
        _5G = 141,
        _5A = 142,
        _5B = 143,

        _6C = 144,
        _6D = 145,
        _6E = 146,
        _6F = 147,
        _6G = 148,
        _6A = 149,
        _6B = 150,

        _7C = 151,
        _7D = 152,
        _7E = 153,
        _7F = 154,
        _7G = 155,
        _7A = 156,
        _7B = 157,

        _8C = 158,


        _0AS = 159,

        _1CS = 160,
        _1DS = 161,
        _1FS = 162,
        _1GS = 163,
        _1AS = 164,

        _2CS = 165,
        _2DS = 166,
        _2FS = 167,
        _2GS = 168,
        _2AS = 169,

        _3CS = 170,
        _3DS = 171,
        _3FS = 172,
        _3GS = 173,
        _3AS = 174,

        _4CS = 175,
        _4DS = 176,
        _4FS = 177,
        _4GS = 178,
        _4AS = 179,

        _5CS = 180,
        _5DS = 181,
        _5FS = 182,
        _5GS = 183,
        _5AS = 184,

        _6CS = 185,
        _6DS = 186,
        _6FS = 187,
        _6GS = 188,
        _6AS = 189,

        _7CS = 190,
        _7DS = 191,
        _7FS = 192,
        _7GS = 193,
        _7AS = 194,
    }


    [Space(10)]
    [Header("白")]
    public List<UIButton> WhiteKeys;
    public List<SEIndex> WhiteMusicName;
    [Space(10)]
    [Header("黑")]
    public List<UIButton> BlackKeys;
    public List<SEIndex> BlackMusicName;
    [Space(10)]
    [Header("节拍器")]

    //int MetronomeSpeed = 60;
    [SerializeField] UIButton MetronomeBtn;
    [SerializeField] UIButton MetronomeSpeedUpBtn;
    [SerializeField] UIButton MetronomeSpeedDownBtn;
    [SerializeField] Toggle PedalButton;
    [SerializeField] float pedalFadeTime = 0.5f;

    [SerializeField] UIText MetronomeSpeedText;
    [SerializeField] Animation MetronomeAnimation;
    public SEIndex MetronomeMusicName;

    [Space(10)]
    [Header("音乐按键")]
    [SerializeField] UIButton ShowTextBtn;
    public UIOrganMainWindow.MusicTextType MusicTextType;
    [SerializeField] List<GameObject> MusicTexts = new List<GameObject>();


    public UIOrganMainWindow.ViewType ViewType;

    [SerializeField] UIButton ChangeKeyBoardBtn;
    public UIButton ReturnBtn;


    private bool PedalOn = false;

    void Start()
    {
        ViewType = UIOrganMainWindow.ViewType.Dual;
        InitBtns();
        UIOrganMainWindow.instance.StopSE((int)MetronomeMusicName);
        //MusicTexts.Add

    }

    private void OnEnable()
    {

        MusicTexts.Clear();
        for (int i = 0; i < WhiteKeys.Count; i++)
        {

            MusicTexts.Add(WhiteKeys[i].gameObject.transform.GetChild(0).gameObject);

        }
        foreach (var item in MusicTexts)
        {
            item.gameObject.SetActive(false);
        }
        SetMetronomeAnimation();
        MetronomeSpeedText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, UIOrganMainWindow.instance.MetronomeSpeed.ToString());
        SetMusicTextType();
    }

    void SetMetronomeAnimation()
    {
        if (UIOrganMainWindow.instance.MetronomePlaying)
        {
            MetronomeAnimation.Play();
        }
        else
        {
            MetronomeAnimation.Stop();
        }
    }
    List<string> letterList = new List<string>()
    {
                                 "A0","B0",
        "C1","D1","E1","F1","G1","A1","B1",
        "C2","D2","E2","F2","G2","A2","B2",
        "C3","D3","E3","F3","G3","A3","B3",
        "C4","D4","E4","F4","G4","A4","B4",
        "C5","D5","E5","F5","G5","A5","B5",
        "C6","D6","E6","F6","G6","A6","B6",
        "C7","D7","E7","F7","G7","A7","B7",
        "C8",
    };
    List<string> noteList = new List<string>()
    {
                                  "la","si",
        "do","re","mi","fa","sol","la","si",
        "do","re","mi","fa","sol","la","si",
        "do","re","mi","fa","sol","la","si",
        "do","re","mi","fa","sol","la","si",
        "do","re","mi","fa","sol","la","si",
        "do","re","mi","fa","sol","la","si",
        "do","re","mi","fa","sol","la","si",
        "do",
    };
    void SetMusicTextType()
    {
        switch (UIOrganMainWindow.instance.nowMusicTextType)
        {
            case UIOrganMainWindow.MusicTextType.none:
                foreach (var item in MusicTexts)
                {
                    item.SetActive(false);
                }
                break;
            case UIOrganMainWindow.MusicTextType.letter:
                for (int i = 0; i < MusicTexts.Count; i++)
                {
                    MusicTexts[i].gameObject.SetActive(true);

                    MusicTexts[i].transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = letterList[i % noteList.Count];

                }
                break;
            case UIOrganMainWindow.MusicTextType.note:

                for (int i = 0; i < MusicTexts.Count; i++)
                {
                    MusicTexts[i].gameObject.SetActive(true);

                    MusicTexts[i].transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = noteList[i % noteList.Count];

                }
                break;
        }

        //if (UIOrganMainWindow.instance.nowViewType == UIOrganMainWindow.ViewType.Front)
        //{
        //    for (int i = MusicTexts.Count/2; i < MusicTexts.Count; i++)
        //    {
        //        MusicTexts[i].GetComponent<RectTransform>().rotation= Quaternion.Euler(0.0f, 0.0f, 180f);
        //    }
        //}
        //else
        //{
        //    for (int i = MusicTexts.Count / 2; i < MusicTexts.Count; i++)
        //    {
        //        MusicTexts[i].GetComponent<RectTransform>().rotation = Quaternion.Euler(0.0f, 0.0f, 180f);
        //    }
        //}
    }

    private void InitBtns()
    {
        if (PedalButton != null)
        {
            PedalButton.onValueChanged.AddListener((isOn) =>
            {
                PedalOn = isOn;
            });


            // PedalButton.onClick.AddListener((o) =>
            //     {
            //         PedalOn=!PedalOn;
            //         if (PedalOn)
            //         {
            //             PedalButton.GetComponent<Image>().color = Color.red;
            //         }
            //         else
            //         {
            //             PedalButton.GetComponent<Image>().color = Color.white;
            //
            //         }
            //     
            //     }
            // );
        }

        if (ViewType == UIOrganMainWindow.ViewType.Dual)
        {

            for (int i = 0; i < WhiteKeys.Count; i++)
            {
                var t = i;
                if (t > 51)
                    t = i - 52;
                WhiteMusicName[i] = (SEIndex)(107 + t);
            }
            for (int i = 0; i < BlackKeys.Count; i++)
            {
                var t = i;
                if (t > 35)
                    t = i - 36;
                BlackMusicName[i] = (SEIndex)(159 + t);
            }

        }


        ReturnBtn.onClickDown.AddListener((o) =>
        {
            UIOrganMainWindow.instance.OnComplete.Invoke();
        });

        ShowTextBtn.onClickDown.AddListener((o) =>
        {

            var nextType = (UIOrganMainWindow.MusicTextType)(((int)UIOrganMainWindow.instance.nowMusicTextType + 1) % 3);
            UIOrganMainWindow.instance.nowMusicTextType = nextType;
            SetMusicTextType();

        });

        for (int i = 0; i < WhiteKeys.Count; i++)
        {
            int temp = i;
            var text = WhiteKeys[temp].transform.GetChild(0).GetChild(0).transform;
            WhiteKeys[temp].onEnter.AddListener((o) =>
            {
                // WhiteKeys[temp].GetComponent<Button>().spriteState.pressedSprite;
                //Debug.Log(WhiteMusicName[temp] + " " + temp);
                // text.localPosition=Vector2.zero;
                text.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 46.84f);
                // Tween tween = DOTween.To(() => text.GetComponent<RectTransform>().anchoredPosition, x => text.GetComponent<RectTransform>().anchoredPosition = x, new Vector2(0, 56.84f), 1f);
                // text.DOLocalMove(new Vector2(0,56.84f),1f);


                UIOrganMainWindow.instance.PlaySE((int)WhiteMusicName[temp]);
            });
            WhiteKeys[temp].onExit.AddListener((o) =>
            {
                if (PedalOn)
                {
                    UIOrganMainWindow.instance.StopSE((int)WhiteMusicName[temp], pedalFadeTime);
                }
                text.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 56.84f);
            });
        }
        for (int i = 0; i < BlackKeys.Count; i++)
        {
            int temp = i;
            BlackKeys[temp].onEnter.AddListener((o) =>
            {
                // BlackKeys[temp].GetComponent<Button>().onClick.Invoke();
                UIOrganMainWindow.instance.PlaySE((int)BlackMusicName[temp]);
            });
            BlackKeys[temp].onExit.AddListener((o) =>
            {
                if (PedalOn)
                {

                    UIOrganMainWindow.instance.StopSE((int)BlackMusicName[temp], pedalFadeTime);
                }
            });
        }

        ChangeKeyBoardBtn.onClickDown.AddListener((o) =>
        {
            //Debug.Log("?");
            var nextType = (UIOrganMainWindow.ViewType)(((int)ViewType + 1) % 3);
            //Debug.Log(nextType);
            UIOrganMainWindow.instance.SetKeyBoardActive(nextType);
        });

        MetronomeBtn.onClick.AddListener((o) =>
        {
            UIOrganMainWindow.instance.MetronomeChange(true, MetronomeMusicName, UIOrganMainWindow.instance.MetronomeSpeed);
            SetMetronomeAnimation();
        });

        MetronomeSpeedUpBtn.onClick.AddListener((o) =>
        {
            UIOrganMainWindow.instance.MetronomeSpeed++;
            MetronomeSpeedText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, UIOrganMainWindow.instance.MetronomeSpeed.ToString());
        });

        MetronomeSpeedUpBtn.onLongClick.AddListener((o) =>
        {
            MetronomeLongClicking = true;
            MetronomeLongAdd(1);

        });
        MetronomeSpeedUpBtn.onClickUp.AddListener((o) =>
        {
            MetronomeLongClicking = false;
            if (UIOrganMainWindow.instance.MetronomePlaying == true)
            {

                foreach (AnimationState state in MetronomeAnimation)
                {
                    state.speed = UIOrganMainWindow.instance.MetronomeSpeed / 60;
                }
            }
        });


        MetronomeSpeedDownBtn.onClick.AddListener((o) =>
        {
            UIOrganMainWindow.instance.MetronomeSpeed--;
            MetronomeSpeedText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, UIOrganMainWindow.instance.MetronomeSpeed.ToString());

        });
        MetronomeSpeedDownBtn.onLongClick.AddListener((o) =>
        {
            MetronomeLongClicking = true;
            MetronomeLongAdd(-1);
        });
        MetronomeSpeedDownBtn.onClickUp.AddListener((o) =>
        {
            MetronomeLongClicking = false;
            if (UIOrganMainWindow.instance.MetronomePlaying == true)
            {

                foreach (AnimationState state in MetronomeAnimation)
                {
                    state.speed = UIOrganMainWindow.instance.MetronomeSpeed / 60;

                }
            }
        });

    }

    bool MetronomeLongClicking = false;
    async UniTask MetronomeLongAdd(int value)
    {
        while (MetronomeLongClicking)
        {

            await UniTask.Delay(100);
            UIOrganMainWindow.instance.MetronomeSpeed += value;
            MetronomeSpeedText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, UIOrganMainWindow.instance.MetronomeSpeed.ToString());


        }
    }



}
