﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;

public class UIExploreMainWindow : UIDialogBase
{
    [SerializeField] UIButton backButton;
    [SerializeField] UIText placenameText;
    [SerializeField] UIAdvClock clock;
    [SerializeField] GoalMessage[] goals;
    [SerializeField] UIButton mapButton;
    [SerializeField] GameObject energyGroup;
    [SerializeField] UIText energyText;

    [SerializeField] UIButton requestButton;
    [SerializeField] UIButton navigationButton;
    [SerializeField] GameObject inviteGroup;
    
    


    public UnityEvent OnClickRequest => requestButton.OnTouchUpInside;
    public UnityEvent OnClickMap => mapButton.OnTouchUpInside;


    private List<int> goalIdList = new List<int>();
    private Dictionary<int, GoalMessage> goalObjects = new Dictionary<int, GoalMessage>();

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        backButton.OnTouchUpInside.Subscribe(OnClickBack).AddTo(mSubscriptions);
        navigationButton.OnTouchUpInside.GuardSubscribeAsync(onClickNavigation).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe(UIEventId.MapSceneChanged, OnMapChanged).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe<long>(UIEventId.ExploreEventFinish, OnEventFinish).AddTo(mSubscriptions);
        MapSceneManager.Instance.OnAdvFinish.SubscribeAsync(onAdvFinish).AddTo(mSubscriptions);
        MapSceneManager.Instance.OnAdvRefresh.SubscribeAsync(onAdvRefresh).AddTo(mSubscriptions);

        energyText.SetRawText(DataManager.Instance.Player.Player.GetCurrentStaimina().ToString());
        requestButton.gameObject.SetActive(DataManager.Instance.Local.Explore.playerData.eventList.Count>0);
        clock.gameObject.SetActive(false);
        // placenameText.SetLabel(LocalizeManager.DATA_TYPE.LOCATION_NAME, DataManager.Instance.Master.Location[MapSceneManager.Instance.CurrentScene.GetNowMapLabel()].displayName);
    }

    public void SetOngoingEvent(ExploreEventViewModel eventViewModel)
    {
        goalIdList.Clear();
        goalObjects.Clear();
        if (eventViewModel != null)
        {
            clock.gameObject.SetActive(true);
            clock.SetMaxValue(eventViewModel.Master.totalClock);
            clock.SetValue(eventViewModel.remainTime);
            mapButton.gameObject.SetActive(false);
            requestButton.gameObject.SetActive(false);
            energyGroup.gameObject.SetActive(false);
            if (GameSceneManager.Instance.currentSceneName == "ExploreScene" || GameSceneManager.Instance.currentSceneName == "AdvScene")
            {
                clock.gameObject.SetActive(false);
            }
        }
        else
        {
            clock.gameObject.SetActive(false);
            foreach (var item in goals)
            {
                item.gameObject.SetActive(false);
            }
            mapButton.gameObject.SetActive(true);
            energyGroup.gameObject.SetActive(true);
        }
        
    }

    private void OnEventFinish(long evId)
    {
        energyText.SetRawText(DataManager.Instance.Player.Player.GetCurrentStaimina().ToString());
        requestButton.gameObject.SetActive(DataManager.Instance.Local.Explore.playerData.eventList.Count>0);
    }
    
    async UniTask onClickNavigation()
    {
        var dialog= await UI.Dialog.CreateAsync(UIPrefabId.UIHomeNavigationWindow, CanvasType.App1) as UIHomeNavigationWindow;
        await dialog.SetUpOutSide();
        await dialog.ShowAsync(UIPageShowType.Front);
        await dialog.OpenNavigationGroupOutSide();
    }


    private void OnMapChanged()
    {
        placenameText.SetLabel(LocalizeManager.DATA_TYPE.LOCATION_NAME, DataManager.Instance.Master.Location[MapSceneManager.Instance.CurrentScene.GetNowMapLabel()].displayName);
    }


    private void OnClickBack()
    {
        var hintLabel = "";
        if (DataManager.Instance.Local.Explore.memoryRoomInfo == default)
        {
             hintLabel = "Confirm_Quit_Text";
        }
        else
        {
             hintLabel = "Confirm_QuitMemory_Text";
        }
        UI.Popup.ShowConfirm(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "Explore_Exit"), LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, hintLabel), CanvasType.App2, (r)=>
        {
            if (r == UIPopupDialog.Result.OK)
            {
                Base.Sound.SoundManager.GetInstance().StopAllSe();
                AsyncManager.Instance.StartGuardAsync(async()=>
                {

                    HomeSceneParam p = new HomeSceneParam();
                    p.enterType = HomeSceneParam.EnterType.FromExploreEvent;
                    
                    await GameSceneManager.Instance.ChangeSceneAsync<HomeScene>("HomeScene", p);
                });
            }
        });
    }

    private async UniTask onAdvFinish()
    {

        var advhandler = (MapSceneManager.Instance.CurrentLogic as ExploreMapLogic).GetCurrentAdvHandler();
        var id = advhandler.RunningAdv;
        var cost = DataManager.Instance.Master.ExploreAdv[id].clockCost;
        if (cost > 0)
        {
            await clock.addTime(cost);
        }
    }

    private async UniTask onAdvRefresh()
    {
        var advhandler = (MapSceneManager.Instance.CurrentLogic as ExploreMapLogic).GetCurrentAdvHandler();
        var pendingList = advhandler.GetPendingList();

        var currentGoal = new List<int>(goalIdList);

        foreach (var id in currentGoal)
        {
            if (advhandler.IsFinished(id))
            {
                //finish goal
                goalObjects[id].gameObject.SetActive(false);
                goalIdList.Remove(id);
            }
            else if (!pendingList.Contains(id))
            {
                //fail
                goalObjects[id].gameObject.SetActive(false);
                goalIdList.Remove(id);
            }
        }

        foreach (var item in pendingList)
        {
            if (DataManager.Instance.Master.ExploreAdv[item].keyStep)
            {
                if (!goalIdList.Contains(item) && !advhandler.IsFinished(item))
                {
                    //add goal
                    GoalMessage g = null;
                    foreach (var o in goals)
                    {
                        if (!o.gameObject.activeSelf)
                        {
                            g = o;
                            break;
                        }
                    }
                    goalObjects[item] = g;
                    goalObjects[item].gameObject.SetActive(true);
                    g.SetText(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.GOAL_MESSAGE, item.ToString()));
                    goalIdList.Add(item);
                }
            }
        }
    }


    
}
