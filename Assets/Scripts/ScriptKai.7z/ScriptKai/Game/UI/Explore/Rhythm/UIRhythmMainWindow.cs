﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using Pheonix.Core;
using UnityEngine.Events;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using Game.Sound;

public class UIRhythmMainWindow : UIDialogBase
{
    public override void OnHide()
    {
        base.OnHide();
        SoundPlayer.StopBgm();
        
    }

    public UIText TimerText;
    public UIText TimerText2;
    public UIText ComboText;
    public UIText ScoreText;
    [SerializeField] RhythmUIButton ScreenClick;
    [SerializeField] RhythmDragArea ScreenClick2;
    public UnityEvent OnComplete;
    public bool GameSuccesOver = false;
    
    [SerializeField] private RectTransform target;
    [SerializeField] private RectTransform start;
    
    
    [SerializeField] private RectTransform check;
    
    [SerializeField] private RectTransform activeGroup;
    
    public List<GameObject> monsterPool;
    public List<GameObject> monsterPool2;
    public List<GameObject> monsterPoolBoss;
    public List<GameObject> notePool;
    public List<GameObject> hintPool;
    
    
    
    public List<RhythmMonster> activeMonsters;
    
    
    private RhythmDataFormate rhythmData= new RhythmDataFormate();




    void PlayBGM()
    {
        
        SoundPlayer.PlayBgm(rhythmData.musicName);
    }
    
    
    private bool gaming = false;
    private float startTime;
    private float runTime;
    async void Start()
    {
        
        InitBtnFunc();
        gaming = true;
        startTime=Time.time;
        Invoke("PlayBGM",rhythmData.musicWaitTime);
        for (int i = 0; i < rhythmData.RhythmMonsterDatas.Count; i++)
        {
            var t = rhythmData.RhythmMonsterDatas[i];
            
            await UniTask.Delay((int)(t.bornWaitTime*1000));
            if (t.Type == RhythmMonsterType.single)
            {
                CreatSingleMonster(t);
            }
            if (t.Type == RhythmMonsterType.multi)
            {
                CreatMultiMonster(t);
            }
            if (t.Type == RhythmMonsterType.boss)
            {
                CreatBoss(t);
            }
        }
        
        
    }
    
    private void Update()
    {
        if (gaming)
        {
            runTime = Time.time - startTime;
            TimerText.SetLabel(LocalizeManager.DATA_TYPE.COMMON,runTime.ToString());
            TimerText2.SetLabel(LocalizeManager.DATA_TYPE.COMMON,(runTime-rhythmData.musicWaitTime).ToString());
        }
        
    }



    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }


    public async UniTask Setup(int levelID)
    {
        
        
        await SetData(levelID);
        
        
    }

    async UniTask SetData(int mlevelID)
    {
        
        var masters = DataManager.Instance.Master.Rhythm.Values;
        var t = masters.First(x => x.levelID == mlevelID);
        rhythmData=RhythmDataFormate.Master2Formate(t,check,start,target);
    }


    private bool isLongClick = false;

    private Vector2 point;
    private void InitBtnFunc()
    {
        
        ScreenClick2.Drag.AddListener(() =>
        {
            GetDragCheck();
        });

        ScreenClick.onClickUp.AddListener((o) =>
        {
            // Debug.Log("a");
            if (isLongClick)
            {
                isLongClick = false;
                Debug.Log("LU");
                
                GetUpCheck();
            }
            else
            {
                Debug.Log("Short");
                GetPointCheck();
            }
            
        });
        
        ScreenClick.onLongClick.AddListener((o) =>
        {            
            Debug.Log("LD");
            GetDownCheck();
            isLongClick = true;
        });
        
        
    }


    
    
    
    

    public void CreatSingleMonster(RhythmMonsterData data)
    {
        var monster1 = GetSingleMonster();
        monster1.transform.SetParent(activeGroup);
        var sc1 = monster1.GetComponent<RhythmMonster1>();
        activeMonsters.Add(sc1);
        sc1.CreatInit(start,target,data.checkTimeRange1,data.moveTime);
    }
    
    

    public void CreatBoss(RhythmMonsterData data)
    {
        var boss = GetBoss();
        boss.transform.SetParent(activeGroup);
        var sc3= boss.GetComponent<RhythmMonsterBoss>();
        activeMonsters.Add(sc3);
        sc3.CreatInit(start,target,data.checkTimeRange1,data.moveTime);
    }

    
    
    public GameObject MultiMonsterModel;
    public void CreatMultiMonster(RhythmMonsterData data)
    {
        var monster2 = GetMultiMonster();
        monster2.transform.SetParent(activeGroup);
        var sc2 = monster2.GetComponent<RhythmMonster2>();
        activeMonsters.Add(sc2);
        sc2.CreatInit(start,target,data.checkTimeRange1,data.checkTimeRange2,data.moveTime,data.width);
        
    }


    
    








    private GameObject GetSingleMonster()
    {
        if (monsterPool.Count > 1)
        {
            var go = monsterPool[1];
            monsterPool.RemoveAt(1);

            return go;
        }
        else
        {
            var go = Instantiate(monsterPool[0]);

            go.transform.SetParent(transform);
            go.transform.localScale = monsterPool[0].transform.localScale;
            return go;
        }
    }


    private GameObject GetNote()
    {
        if (notePool.Count > 1)
        {
            var go = notePool[1];
            notePool.RemoveAt(1);

            return go;
        }
        else
        {
            var go = Instantiate(notePool[0]);

            go.transform.SetParent(transform);
            go.transform.localScale = notePool[0].transform.localScale;
            return go;
        }
    }
    private GameObject GetHint()
    {
        if (hintPool.Count > 1)
        {
            var go = hintPool[1];
            hintPool.RemoveAt(1);

            return go;
        }
        else
        {
            var go = Instantiate(hintPool[0]);

            go.transform.SetParent(transform);
            go.transform.localScale = hintPool[0].transform.localScale;
            return go;
        }
    }
    
    private GameObject GetBoss()
    {
        if (monsterPoolBoss.Count > 1)
        {
            var go = monsterPoolBoss[1];
            monsterPoolBoss.RemoveAt(1);

            return go;
        }
        else
        {
            var go = Instantiate(monsterPoolBoss[0]);

            go.transform.SetParent(transform);
            go.transform.localScale = monsterPoolBoss[0].transform.localScale;
            return go;
        }
    }

    private GameObject GetMultiMonster()
    {
        if (monsterPool2.Count > 1)
        {
            var go = monsterPool2[1];
            monsterPool2.RemoveAt(1);

            return go;
        }
        else
        {
            var go = Instantiate(monsterPool2[0]);

            go.transform.SetParent(transform);
            go.transform.localScale = monsterPool2[0].transform.localScale;
            return go;
        }
    }
    
    
    
    
    
    private int comboCounter;
    
    
    public void MonsterMiss(RhythmMonster monster)
    {
        if (monster is RhythmMonster1)
        {
            activeMonsters.Remove(monster);
            monsterPool.Add(monster.gameObject);
            comboCounter = 0;
            Miss();
            Debug.Log("miss");
        }
        if (monster is RhythmMonster2)
        {
            activeMonsters.Remove(monster);
            for (int i = 0; i < monster.transform.childCount; i++)
            {
                monsterPool.Add(monster.transform.GetChild(1).GetChild(i).gameObject);
            }
            monsterPool2.Add(monster.gameObject);
            comboCounter = 0;
            Miss();
        }
        if (monster is RhythmMonsterBoss)
        {
            activeMonsters.Remove(monster);
            monsterPoolBoss.Add(monster.gameObject);
            comboCounter = 0;
            Miss();
        }
    }


    private int score=0;
    
    



    void CreatNote()
    {
        var note = GetNote();
        note.transform.position = check.position;
        note.GetComponent<RhythmNote>().Init(notePool,3000,new Vector2(1000,1000));
    }

    void CreatHint()
    {
        var hint = GetHint();        
        hint.transform.position = check.position;
        hint.GetComponent<RhythmNote>().Init(hintPool,3000,new Vector2(0,1000));
    }


    void CalculaPoint(int result)
    {
        int ComboRate = 1;
        if (comboCounter>=2)
        {
            ComboRate = 2;
        }

        score += result * 100 * ComboRate;
        ScoreText.SetLabel(LocalizeManager.DATA_TYPE.COMMON,score.ToString());
    }
    



    public void Miss()
    {
        comboCounter = 0;
        ComboText.SetLabel(LocalizeManager.DATA_TYPE.COMMON,comboCounter.ToString());
        
    }
    
    
    public void GetPoint(int result)
    {
        comboCounter++;
        ComboText.SetLabel(LocalizeManager.DATA_TYPE.COMMON,comboCounter.ToString());
        CreatNote();
        CreatHint();
        CalculaPoint(result);
        // Debug.Log("comboCounter "+comboCounter+"!"+CalculatorScore(result));

    }


    private void GetDragCheck()
    {

        if (activeMonsters[0] is RhythmMonsterBoss boss)
        {
            var result=boss.Check(runTime);
            if (result!=-1)
            {
                if (result == 0)
                {
                    Miss();
                }
                else
                {
                    GetPoint(result);
                }
                activeMonsters.Remove(boss);
            }
            return;
        }
        // throw new NotImplementedException();
    }



    void GetPointCheck()
    {
        for (int i = 0; i < activeMonsters.Count; i++)
        {
            if (i != 0) return;
            if (activeMonsters[i] is RhythmMonster1 monster1)
            {
                var result=monster1.Check(runTime);
                if (result!=-1)
                {
                    if (result == 0)
                    {
                        Miss();
                    }
                    else
                    {
                        GetPoint(result);
                    }
                    activeMonsters.Remove(monster1);
                }
                return;
            }
        }
    }

    void GetDownCheck()
    {
        for (int i = 0; i < activeMonsters.Count; i++)
        {
            if (activeMonsters[i] is RhythmMonster2 monster2)
            {
                var result=monster2.CheckDown(runTime);
                if (result!=-1)
                {
                    if (result == 0)
                    {
                        Miss();
                    }
                    else
                    {
                        GetPoint(result);
                    }
                    // activeMonsters.Remove(monster2);
                }
            }
        }
    }
    void GetUpCheck()
    {
        for (int i = 0; i < activeMonsters.Count; i++)
        {
            if (activeMonsters[i] is RhythmMonster2 monster2)
            {
                var result=monster2.CheckUp(runTime);
                if (result!=-1)
                {
                    if (result == 0)
                    {
                        Miss();
                    }
                    else
                    {
                        GetPoint(result);
                    }
                    activeMonsters.Remove(monster2);
                }
            }
        }
    }


    
    
    




















}
