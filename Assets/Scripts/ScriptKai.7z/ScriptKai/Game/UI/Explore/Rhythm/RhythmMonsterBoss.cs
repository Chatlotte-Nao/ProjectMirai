using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class RhythmMonsterBoss : RhythmMonster
{
    public Vector4 checkTimeRange1;
    
    RectTransform _rect;

    private void OnEnable()
    {
        active = true;
        angleLineObj.SetActive(false);
    }

    public void ReachEndPoint()
    {
        gameObject.SetActive(false);
    }

    private bool holding=false;
    private void Update()
    {
    }


    private float calibrationTime;
    
    public int Check(float runTime)
    {                
        
        if (runTime<(checkTimeRange1.x-(checkTimeRange1.w-checkTimeRange1.z)))
        {
            return -1;
        }
        
        active = false;
        
        if (checkTimeRange1.x<runTime && runTime<checkTimeRange1.y)
        {
            if (checkTimeRange1.z < runTime && runTime < checkTimeRange1.w)
            {
                //TODO 完美动画
                GetComponent<Image>().color=Color.yellow;
                
                angleLineObj.SetActive(true);
                // Debug.Log(2);
                
                return 2;
            }
            //TODO 普通动画
            
            GetComponent<Image>().color=Color.green;
            angleLineObj.SetActive(true);
            // Debug.Log(1);
            return 1;
            
        }
        //TODO Miss动画
        GetComponent<Image>().color=Color.black;
        // Debug.Log(0);
        return 0;
    }


    
    public void CreatInit(RectTransform start,RectTransform target,Vector4 checkTime1,float duration)
    {
        checkTimeRange1 = checkTime1;
        gameObject.SetActive(true);
        transform.position=start.position;
        var t=DOTween.To(() => transform.position, x => transform.position = x,target.position, duration);
        t.SetEase(Ease.Linear);

    }
    
    







}
