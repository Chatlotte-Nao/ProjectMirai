﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class RhythmDataFormate
{
    // public int score;
    public string musicName;
    public float musicWaitTime;
    
    public List<RhythmMonsterData> RhythmMonsterDatas = new List<RhythmMonsterData>();







    public static RhythmDataFormate Master2Formate(RhythmMaster master,Transform checkPoint,Transform startPoint,Transform targetPoint)
    {
        
        
        var t1 = checkPoint.position.x;
        var t2 = startPoint.position.x;
        var t3 = targetPoint.position.x;
        float TimeRate=(t1-t2)/(t3-t2);
        float perfectRate = checkPoint.GetComponent<RectTransform>().sizeDelta.x / (t2 - t3);
        
        
        RhythmDataFormate formate=new RhythmDataFormate();
        List<float> tempBornTimeList = new List<float>();
        List<string> tempWidthList = new List<string>();
        for (int i = 0; i < master.monsterBornTime.Count; i++)
        {
            var t=master.monsterBornTime[i].Split(':');
            if (i == 0)
            {
                float musicWaitTime = Convert.ToSingle(t[0]) - master.moveTime/10f;
                if (musicWaitTime > 0)
                {
                    formate.musicWaitTime = 0;
                }
                else
                {
                    formate.musicWaitTime = -musicWaitTime;
                }
                
                
            }
            tempBornTimeList.Add(Convert.ToSingle(t[0])-(master.moveTime/10f*TimeRate)+formate.musicWaitTime);
            tempWidthList.Add(t[1]);
        }
        

        for (int i = 0; i < tempBornTimeList.Count; i++)
        {
            var monster=new RhythmMonsterData();
            
            if (i==0)
            {
                monster.bornWaitTime = tempBornTimeList[0];
            }
            else
            {
                monster.bornWaitTime = tempBornTimeList[i]- tempBornTimeList[i-1];
            }

            if (tempWidthList[i]=="0")
            {
                monster.Type = RhythmMonsterType.single;
                float time = tempBornTimeList[i]+master.moveTime / 10.0f*TimeRate;
                // float halfCheck = master.succCheckTime / 20.0f;
                // float halfPerfect = master.perfectCheckTime / 20.0f;
                
                float halfCheck = master.moveTime*perfectRate / 10.0f;
                float halfPerfect = master.moveTime*perfectRate / 20.0f;
                monster.checkTimeRange1 = new Vector4(time - halfCheck, time + halfCheck,time-halfPerfect,time+halfPerfect);
                
            }
            else if (tempWidthList[i]=="-1")
            {
                monster.Type = RhythmMonsterType.boss;
                float time = tempBornTimeList[i]+master.moveTime / 10.0f*TimeRate;
                // float halfCheck = master.succCheckTime / 20.0f;
                // float halfPerfect = master.perfectCheckTime / 20.0f;
                
                float halfCheck = master.moveTime*perfectRate / 10.0f;
                float halfPerfect = master.moveTime*perfectRate / 20.0f;
                monster.checkTimeRange1 = new Vector4(time - halfCheck, time + halfCheck,time-halfPerfect,time+halfPerfect);

            }
            else
            {
                monster.Type = RhythmMonsterType.multi;
                monster.width = Convert.ToSingle(tempWidthList[i]);
                float time = tempBornTimeList[i]+master.moveTime / 10.0f*0.886f;
                // float halfCheck = master.succCheckTime / 20.0f;
                // float halfPerfect = master.perfectCheckTime / 20.0
                
                float halfCheck = master.moveTime*perfectRate / 10.0f;
                float halfPerfect = master.moveTime*perfectRate / 20.0f;
                monster.checkTimeRange1 = new Vector4(time - halfCheck, time + halfCheck,time-halfPerfect,time+halfPerfect);
                monster.checkTimeRange2 = monster.checkTimeRange1+new Vector4(monster.width,monster.width,monster.width,monster.width);
                
            }

            monster.moveTime = master.moveTime / 10.0f;
            formate.RhythmMonsterDatas.Add(monster);
        }

        formate.musicName = master.musicName;



        return formate;
    }
    
}



public class RhythmMonsterData
{
    public Vector4 checkTimeRange1;
    public Vector4 checkTimeRange2;
    public float bornWaitTime;
    public RhythmMonsterType Type;
    public float width;
    public float moveTime;
    
}

