using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class RhythmMonster2 : RhythmMonster
{
    public Vector4 checkTimeRange1;
    public Vector4 checkTimeRange2;
    
    RectTransform _rect;
    public GameObject first;
    public GameObject mids;
    public GameObject last;

    private void OnEnable()
    {
        active = true;
    }

    public void ReachEndPoint()
    {
        gameObject.SetActive(false);
    }

    private bool holding=false;
    private void Update()
    {
    }


    private float calibrationTime;
    public int CheckDown(float runTime)
    {                
        Debug.Log("a");
        if (runTime<checkTimeRange1.x||active==false)
        {
            return -1;
        }
        active = false;
        
        if (checkTimeRange1.x<runTime && runTime<checkTimeRange1.y)
        {
            var t=DOTween.To(() => _rect.sizeDelta, x => _rect.sizeDelta = x,new Vector2(0,_rect.sizeDelta.y), calibrationTime);
            t.SetEase(Ease.Linear);
            holding = true;
            if (checkTimeRange1.z < runTime && runTime < checkTimeRange1.w)
            {
                //TODO 完美动画
                first.GetComponent<Image>().color=Color.yellow;
                
                // Debug.Log(2);
                
                return 2;
            }
            else
            {
                first.GetComponent<Image>().color=Color.green;
                // Debug.Log(1);
                return 1;
            }
            //TODO 普通动画
            
        }
        //TODO Miss动画
        
        first.GetComponent<Image>().color=Color.black;
        // Debug.Log(0);
        return 0;
    }
    public int CheckUp(float runTime)
    {                
        Debug.Log("a");
        if (runTime<checkTimeRange1.x||holding == false)
        {
            return -1;
        }
        active = false;
        if (checkTimeRange2.x<runTime && runTime<checkTimeRange2.y)
        {
                var t=DOTween.To(() => _rect.sizeDelta, x => _rect.sizeDelta = x,new Vector2(0,_rect.sizeDelta.y), calibrationTime);
                t.SetEase(Ease.Linear);
            if (checkTimeRange2.z < runTime && runTime < checkTimeRange2.w)
            {
                //TODO 完美动画
                last.GetComponent<Image>().color=Color.yellow;
                
                // Debug.Log(2);
                
                return 2;
            }
            //TODO 普通动画
            
            last.GetComponent<Image>().color=Color.green;
            // Debug.Log(1);
            return 1;
            
        }
        //TODO Miss动画
        
        last.GetComponent<Image>().color=Color.black;
        // Debug.Log(0);
        return 0;
    }


    public void CreatInit(RectTransform start,RectTransform target,Vector4 checkTime1,Vector4 checkTime2,float duration,float time)
    {
        checkTimeRange1 = checkTime1;
        checkTimeRange2 = checkTime2;
        var length = start.position.x - target.position.x;
        var width = length / duration * time;
        _rect = GetComponent<RectTransform>();
        _rect.sizeDelta= new Vector2(width, 100);
        gameObject.SetActive(true);
        transform.position=start.position+new Vector3(width,0,0);
        calibrationTime = time;
        var t=DOTween.To(() => transform.position, x => transform.position = x,target.position, duration*((length+width)/length));
        t.SetEase(Ease.Linear);
        int counter=((int)width / 200);
        if (counter <= 1) counter = 1;
        
        for (int i = 0; i < counter; i++)
        {
            GameObject obj = Instantiate(mids.transform.GetChild(0).gameObject,mids.transform);
        }


    }
    
    







}
