﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using Cysharp.Threading.Tasks;

public class RhythmNote : MonoBehaviour
{
    
    
    
    
    public async  UniTask Init(List<GameObject> pool,int hideTime,Vector2 dir)
    {
        gameObject.SetActive(true);
        gameObject.GetComponent<Rigidbody2D>().AddForce(dir);
        await UniTask.Delay(hideTime);
        gameObject.SetActive(false);
        pool.Add(gameObject);
    }
}
