using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;

public class RhythmDragArea : MonoBehaviour,IBeginDragHandler,IEndDragHandler,IDragHandler
{
    private Vector2 inputPoint;

    private float dragDis;
    public UnityEvent Drag;
    private bool triggerLocker=false;
    public void OnBeginDrag(PointerEventData eventData)
    {
        triggerLocker = true;
        dragDis = 0;
        inputPoint = eventData.position;
        // Debug.Log(eventData.position);
        // throw new System.NotImplementedException();
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        // var t = Vector2.Distance(inputPoint, eventData.position);
        // Debug.Log(eventData.position+"!!!"+t);
        
        
        Debug.Log(dragDis);

        // throw new System.NotImplementedException();
    }

    public void OnDrag(PointerEventData eventData)
    {
        var t = Vector2.Distance(inputPoint, eventData.position);
        dragDis+=t;
        if (dragDis >= 500&& triggerLocker)
        {
            Drag.Invoke();
            triggerLocker = false;    

        }
        // throw new System.NotImplementedException();
    }
}
