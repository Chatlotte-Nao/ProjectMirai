using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.EventSystems;

public class RhythmUIButton : UIButton
{

    [SerializeField] float holdTime2 = 0.3f;
    
    protected override void Awake()
    {
        base.Awake();
        holdTime = holdTime2;
    }

    protected override void doClick()
    {
        
        // base.doClick();
        
    }
}
