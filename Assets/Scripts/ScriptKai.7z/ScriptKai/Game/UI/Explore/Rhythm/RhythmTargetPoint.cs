using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RhythmTargetPoint : MonoBehaviour
{
    [SerializeField]
    private UIRhythmMainWindow _mainWindow;
    private void OnTriggerEnter2D(Collider2D other)
    {
        var monster=other.gameObject.GetComponent<RhythmMonster>();
        if (monster is RhythmMonster1 monster1)
        {
            monster1.ReachEndPoint(); 
            if(monster1.active)_mainWindow.MonsterMiss(monster1);
        }
        if (monster is RhythmMonster2 monster2)
        {
            monster2.ReachEndPoint(); 
            if(monster2.active)_mainWindow.MonsterMiss(monster2);
        }
        if (monster is RhythmMonsterBoss boss)
        {
            boss.ReachEndPoint(); 
            if(boss.active)_mainWindow.MonsterMiss(boss);
        }
        
    }
}
