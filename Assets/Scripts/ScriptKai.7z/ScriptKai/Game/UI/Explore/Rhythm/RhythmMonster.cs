using System;
using UnityEngine;

public enum RhythmMonsterType
{
    single,
    multi,
    boss,
}

public class RhythmMonster:MonoBehaviour
{
    
    [SerializeField] protected GameObject angleLineObj;
    public bool active = true;
    public RhythmMonsterType rhythmMonsterType;

}
