﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Map
{
	/// <summary>
	/// 目標プレートのスクロール制御 ※微妙なカーブに沿った配置処理も行っています
	/// </summary>
	public class GoalMessageScrollController : MonoBehaviour
	{
		[SerializeField] Button upButton;
		[SerializeField] Button downButton;
		[SerializeField] RectTransform parentBase;
		[SerializeField] RectTransform parent;

		List<GameObject> scrollObjectList = new List<GameObject>();

		const float SCROLL_TIME = 0.1f;
		const float LOCAL_TOP_X = -124.0f;
		const float LOCAL_TOP_Y = 120.0f;
		const float LOCAL_ALPHA_TOP_Y = 0.0f;
		const float LOCAL_BOTTOM_X = -28.0f;
		const float LOCAL_BOTTOM_Y = -400.0f;
		const float LOCAL_ALPHA_BOTTOM_Y = -305.0f;

		float ObjParentH;
		float afterY;
		float distance;

		bool isInitialized = false;
		Coroutine scrollToken = null;

		private void OnDestroy()
		{
			if (scrollToken != null)
			{
				StopCoroutine(scrollToken);
			}
			scrollToken = null;
		}

		public void Initialize(float distance)
		{
			if (isInitialized)
				return;

			isInitialized = true;

			this.distance = distance;
			upButton.onClick.AddListener(() =>
			{
				if (IsNowScroll())
					return;
				var changeNum = (GetNowBottomObjectHeight() + distance);
				afterY -= changeNum;
				if (!IsTop(afterY))
				{
					SetStartScroll(false);
				}
				else
				{
					SetRangeInScroll(afterY);
					//※スクロールが発生してない時は更に値を足してみる
					if (!IsNowScroll())
					{
						while (!IsNowScroll())
						{
							afterY -= changeNum;
							SetRangeInScroll(afterY);
						}
					}
				}
			});
			downButton.onClick.AddListener(() =>
			{
				if (IsNowScroll())
					return;
				var changeNum = (GetNowTopObjectHeight() + distance);
				afterY += changeNum;
				if (!IsBottom(afterY))
				{
					SetStartScroll(false);
				}
				else
				{
					SetRangeInScroll(afterY);
					//※スクロールが発生してない時は更に値を足してみる
					if (!IsNowScroll())
					{
						while (!IsNowScroll())
						{
							afterY += changeNum;
							SetRangeInScroll(afterY);
						}
					}
				}
			});
			upButton.gameObject.SetActive(false);
			downButton.gameObject.SetActive(false);

			var rect = parent.GetComponent<RectTransform>();
			rect.ForceUpdateRectTransforms();
		}

		private void Update()
		{
			SetScrollObjectX();
		}

		/// <summary>
		/// スクロールする場所内に配置しているオブジェクトリストを設定する
		/// </summary>
		public void SetScrollObjectList(List<GameObject> list)
		{
			scrollObjectList = list;
			scrollObjectList.Sort((a, b) => (int)(b.transform.localPosition.y - a.transform.localPosition.y));
		}

		/// <summary>
		/// 表示更新
		/// </summary>
		public void UpdateDisplay(float ObjParentH,float? nowY = null)
		{
			this.ObjParentH = ObjParentH;

			var height = parentBase.sizeDelta.y;
			var y = (nowY.HasValue) ? nowY.Value : GetScrollParentY();
			if (ObjParentH <= height)
			{
				upButton.gameObject.SetActive(false);
				downButton.gameObject.SetActive(false);
			}
			else if (y <= 0.0f)
			{
				upButton.gameObject.SetActive(false);
				downButton.gameObject.SetActive(true);
			}
			else if (y >= ObjParentH - height)
			{
				upButton.gameObject.SetActive(true);
				downButton.gameObject.SetActive(false);

			}
			else
			{
				upButton.gameObject.SetActive(true);
				downButton.gameObject.SetActive(true);
			}
			SetRangeInScroll(y);
		}

		/// <summary>
		/// スクロールする親オブジェ位置が指定値の時、それは移動範囲内に収まるか
		/// </summary>
		bool IsParentYInMoveRange(float y)
		{
			var height = parentBase.sizeDelta.y;
			if (ObjParentH <= height)
			{
				return true;
			}
			else if (y <= 0.0f)
			{
				return false;
			}
			else if (y >= ObjParentH - height)
			{
				return false;
			}
			return true;
		}

		bool IsTop(float y)
		{
			var objHeight = GetNowTopObjectHeight();
			if (y - objHeight / 2.0f <= 0.0f)
			{
				return true;
			}
			return false;
		}

		bool IsBottom(float y)
		{
			var height = parentBase.sizeDelta.y;
			var objHeight = GetNowBottomObjectHeight();
			if (y + objHeight / 2.0f >= ObjParentH - height)
			{
				return true;
			}
			return false;
		}

		/// <summary>
		/// 範囲内にスクロールを収める
		/// </summary>
		public void SetRangeInScroll(float y)
		{
			var height = parentBase.sizeDelta.y;
			var bottomY = ObjParentH - height;
			if (ObjParentH <= height)
			{
				if (y != 0.0f)
				{
					afterY = 0.0f;
					SetStartScroll(true);
				}
			}
			else if (y < 0.0f)
			{
				afterY = 0.0f;
				SetStartScroll(true);
			}
			else if (y > bottomY)
			{
				afterY = bottomY;
				SetStartScroll(true);
			}
		}

		/// <summary>
		/// 今表示されている中で一番上にあるオブジェクトの高さ取得
		/// </summary>
		float GetNowTopObjectHeight()
		{
			foreach (var obj in scrollObjectList)
			{
				if (!IsInRange(obj)) continue;
				var rect = obj.GetComponent<RectTransform>();
				return rect.sizeDelta.y;
			}
			return 0.0f;
		}
		/// <summary>
		/// 今表示されている中で一番下にあるオブジェクトの高さ取得
		/// </summary>
		float GetNowBottomObjectHeight()
		{
			for (int i = scrollObjectList.Count - 1;i >= 0;i--)
			{
				var obj = scrollObjectList[i];
				if (!IsInRange(obj)) continue;
				var rect = obj.GetComponent<RectTransform>();
				return rect.sizeDelta.y;
			}
			return 0.0f;
		}


		/// <summary>
		/// スクロールを行う
		/// </summary>
		/// <param name="isForcibly">true:今スクロール中でもそれを中断して、新たにスクロールを行う</param>
		void SetStartScroll(bool isForcibly)
		{
			if (IsNowScroll())
			{
				if (!isForcibly)
					return;
				StopCoroutine(scrollToken);
			}
			scrollToken = StartCoroutine(ScrollFunction());
		}

		IEnumerator ScrollFunction()
		{
			var rect = parent.GetComponent<RectTransform>();
			var startY = rect.localPosition.y;

			float time = 0.0f;
			while (time < SCROLL_TIME)
			{
				time += Time.deltaTime;
				var nowY = Mathf.Lerp(startY, afterY, time / SCROLL_TIME);
				SetScrollParentY(nowY);
				SetScrollObjectX();
				SetScrollObjectAlpha();
				yield return null;
			}
			SetScrollParentY(afterY);
			SetScrollObjectX();
			SetScrollObjectAlpha();
			scrollToken = null;
			//表示更新
			UpdateDisplay(ObjParentH);
		}

		/// <summary>
		/// 配置オブジェクトのX座標を設定（カーブに沿った形になる）
		/// </summary>
		public void SetScrollObjectX()
		{
			foreach (var obj in scrollObjectList)
			{
				var x = GetScrollObjectX(obj.transform.localPosition.y);
				var rect = obj.GetComponent<RectTransform>();
				Vector3 pos = rect.localPosition;
				pos.x = x;
				rect.localPosition = pos;
			}
		}
		/// <summary>
		/// 指定高さでのオブジェクトX位置を取得
		/// </summary>
		float GetScrollObjectX(float localY)
		{
			var baseY = GetScrollParentY();
			var pointY = (baseY + localY) - LOCAL_BOTTOM_Y;
			var ratio = Mathf.Abs(1.0f * pointY / (LOCAL_TOP_Y - LOCAL_BOTTOM_Y));
			var x = LOCAL_BOTTOM_X + (LOCAL_TOP_X - LOCAL_BOTTOM_X) * Mathf.Sin(90.0f * Mathf.Deg2Rad * ratio);
			return x;
		}

		/// <summary>
		/// スクロール内の各オブジェクトの透過度設定
		/// </summary>
		public void SetScrollObjectAlpha()
		{
			//高さに応じて半透明度を変える
			foreach (var obj in scrollObjectList)
			{
				var canvasGroup = obj.GetComponent<CanvasGroup>();
				if (canvasGroup == null)
					continue;
				canvasGroup.alpha = GetScrollObjectAlpha(obj.transform.localPosition.y);
			}
		}

		/// <summary>
		/// 指定高さでの透過度を取得　（範囲外に行くとだんだん透明になって消えていく）
		/// </summary>
		float GetScrollObjectAlpha(float localY)
		{
			var baseY = GetScrollParentY();
			var pointY = (baseY + localY);
			var height = parentBase.sizeDelta.y;
			if (pointY > LOCAL_ALPHA_TOP_Y)
			{
				var alpha = 1.0f - ((pointY - LOCAL_ALPHA_TOP_Y) / (LOCAL_TOP_Y - LOCAL_ALPHA_TOP_Y));
				alpha = Mathf.Clamp(alpha, 0.0f, 1.0f);
				return alpha;
			}
			else if (pointY < LOCAL_ALPHA_BOTTOM_Y)
			{
				var alpha = 1.0f - ((pointY - LOCAL_ALPHA_BOTTOM_Y) / (LOCAL_BOTTOM_Y - LOCAL_ALPHA_BOTTOM_Y));
				alpha = Mathf.Clamp(alpha, 0.0f, 1.0f);
				return alpha;
			}
			else
			{
				return 1.0f;
			}
		}

		/// <summary>
		/// 指定した物が一番上にくる形になるようにスクロールさせる
		/// </summary>
		public IEnumerator SetTopScroll(GameObject obj)
		{
			var nextAfterY = -obj.transform.localPosition.y;

			if (nextAfterY < 0.0f)
			{
				nextAfterY = 0.0f;
			}
			var height = parentBase.sizeDelta.y;
			var bottomY = ObjParentH - height;
			if (nextAfterY > bottomY)
			{
				nextAfterY = bottomY;
			}

			if (nextAfterY == afterY)
			{
				yield break;
			}

			afterY = nextAfterY;
			SetStartScroll(true);
			if (IsNowScroll())
			{
				yield return null;
			}
		}

		public bool IsInRange(GameObject obj)
		{
			var y = (-obj.transform.localPosition.y) - GetScrollParentY();
			return IsInRange(y);
		}
		public bool IsInRange(float y)
		{
			var height = parentBase.sizeDelta.y;
			//すべて表示範囲内に入っている
			if (ObjParentH <= height)
			{
				return true;
			}
			//表示範囲より上
			else if (y < 0.0f)
			{
				return false;
			}
			//表示範囲より下
			else if (y > height)
			{
				return false;
			}
			//表示範囲内
			return true;
		}


		public bool IsNowScroll()
		{
			return (scrollToken != null);
		}

		void SetScrollParentY(float y)
		{
			var rect = parent.GetComponent<RectTransform>();
			Vector3 pos = rect.localPosition;
			pos.y = y;
			rect.localPosition = pos;
		}
		float GetScrollParentY()
		{
			var rect = parent.GetComponent<RectTransform>();
			return rect.localPosition.y;
		}
	}
}
