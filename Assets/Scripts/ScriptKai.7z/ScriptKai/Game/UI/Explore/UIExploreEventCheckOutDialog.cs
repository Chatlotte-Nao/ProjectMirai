﻿using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class UIExploreEventCheckOutDialog : UIDialogBase
{
    [SerializeField] GameObject newIcon;
    [SerializeField] UIText checkOutTypeText;
    [SerializeField] UIText checkOutTitleText;
    [SerializeField] UIText checkOutDesText;
    [SerializeField] UIButton continueButton;
    [SerializeField] UIButton okButton;
    [SerializeField] UIButton cancelButton;
    long mCurrentId;

    public enum ExplorEventCheckOutType
    {
        invite = 0,
    }

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        continueButton.OnTouchUpInside.GuardSubscribeAsync(onClickContinue).AddTo(mSubscriptions);
        okButton.OnTouchUpInside.GuardSubscribeAsync(onClickStart).AddTo(mSubscriptions);
        cancelButton.OnTouchUpInside.Subscribe(() => { Hide(); }).AddTo(mSubscriptions);;
    }

    public async UniTask SetupAsync(ExploreEventViewModel eventData, ExplorEventCheckOutType type, bool isNew)
    {
        mCurrentId = eventData.masterId;
        switch (type)
        {
            case ExplorEventCheckOutType.invite:
                checkOutTypeText.SetLabel(LocalizeManager.DATA_TYPE.COMMON, "HOME_QUEST");
                break;
        }

        checkOutTitleText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{eventData.masterId}_title");
        checkOutDesText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{eventData.masterId}_desc");
        newIcon.SetActive(isNew);
        okButton.gameObject.SetActive(isNew);
        continueButton.gameObject.SetActive(!isNew);
    }


    public override void OnHide()
    {
        base.OnHide();
        Destroy(gameObject);
    }


    private async UniTask onClickContinue()
    {
        if (mCurrentId == 0)
        {
            return;
        }

        await HideAsync();

        //await UI.ScreenEffect.Fade(1);

        var model = DataManager.Instance.Local.Explore.playerData.eventList[mCurrentId];

        if (model.eventStatus == ExploreEventViewModel.EventStatus.Finished)
        {
            //之前完成了但没有发送完成消息
            await ExploreService.FinishEvent(mCurrentId);
            await UI.Page.OpenPage<UIExploreEventResultPage>(model);
            SignalBus.GlobalSignal.Dispatch(UIEventId.ExploreEventFinish, model.masterId);
            return;
        }
        else
        {
            model.eventStatus = ExploreEventViewModel.EventStatus.Accepted;
        }


        var mapId = DataManager.Instance.Master.ExploreEvent[mCurrentId].initialMap;
        var initialRoute = DataManager.Instance.Master.ExploreEvent[mCurrentId].initialLocation;
        foreach (var item in model.finishedAdv)
        {
            var master = DataManager.Instance.Master.ExploreAdv[item];
            if (!string.IsNullOrEmpty(master.afterLocationLabel))
            {
                mapId = master.afterLocationLabel;
                initialRoute = master.afterRouteName;
            }
        }

        ExploreSceneParam p = new ExploreSceneParam();
        p.mapName = mapId;
        p.startRoute = initialRoute;
        DataManager.Instance.Local.Explore.SetProcessingEvent(mCurrentId);

        await GameSceneManager.Instance.ChangeSceneAsync<ExploreScene>("ExploreScene", p);
        // await MapSceneManager.Instance.ChangeAsync(DataManager.Instance.Master.Location[mapId].scene, initialRoute);
    }

    private async UniTask onClickStart()
    {
        if (mCurrentId == 0)
        {
            return;
        }

        // if (DataManager.Instance.Local.Explore.processingEventId > 0 &&
        //     DataManager.Instance.Local.Explore.processingEventId != mCurrentId)
        // {
        //     UI.Popup.ShowConfirm(string.Empty,
        //         string.Format(
        //             LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "Error_OtherEventProcessing"),
        //             LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER_NAME,
        //                 DataManager.Instance.Local.Explore.GetProcessingEvent().Master.battleCharacterMasterId
        //                     .ToString())), CanvasType.App2, onStartConfirmGiveup);
        //     return;
        // }


        await ExploreService.StartEvent(mCurrentId);

        await HideAsync();

       // await UI.ScreenEffect.Fade(1);

        ExploreSceneParam p = new ExploreSceneParam();
        p.mapName = DataManager.Instance.Master.ExploreEvent[mCurrentId].initialMap;
        p.startRoute = DataManager.Instance.Master.ExploreEvent[mCurrentId].initialLocation;

        await GameSceneManager.Instance.ChangeSceneAsync<ExploreScene>("ExploreScene", p);

        // await MapSceneManager.Instance.ChangeAsync(DataManager.Instance.Master.Location[DataManager.Instance.Master.ExploreEvent[mCurrentId].initialMap].scene, DataManager.Instance.Master.ExploreEvent[mCurrentId].initialLocation);
    }
}