﻿using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Explore.V1;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIMemoryStorageRoomDialog : UIDialogBase
{
    // [SerializeField] UIHomeCharacterSelectObject characterObject;
    [SerializeField] MemoryStorageRoomSelectableCharacterHead characterHead;

    [SerializeField] RectTransform characterObjectRT;
    [SerializeField] Transform content;
    [SerializeField] VerticalLayoutGroup contentVLG;
    [SerializeField] RectTransform contentRT;
    [SerializeField] UIMemoryRoomEventCell listBaseCell;
    [SerializeField] private UIText describeText;
    [SerializeField] private UIButton startButton;
    [SerializeField] private GameObject noMemoryHint;
    [SerializeField] private GameObject charaInvitesGroup;
    [SerializeField] private UIButton closeButton;
    public UnityEvent Close;
    private long currentCharacterId = -1;
    private bool init = true;

    private long mCurrentId = 0;

    Dictionary<long, UIMemoryRoomEventCell> mItems = new Dictionary<long, UIMemoryRoomEventCell>();

    Dictionary<long, MemoryStorageRoomSelectableCharacterHead> mObjects =
        new Dictionary<long, MemoryStorageRoomSelectableCharacterHead>();

    public override async UniTask InitializeAsync()
    {
        await OnInitCharacterViewList();
        var data = DataManager.Instance.Local.Explore.playerData;

        startButton.OnTouchUpInside.GuardSubscribeAsync(onClickStart).AddTo(mSubscriptions);
        closeButton.OnTouchUpInside.Subscribe(()=>Close.Invoke()).AddTo(mSubscriptions);
        List<(int, GameObject)> cellList=new List<(int, GameObject)>();
        foreach (var item in data.eventList)
        {
            if (item.Value.finishCount<=0)
            {
                continue;
            }
            var model = item.Value;
            var newItemObj = Instantiate(listBaseCell.gameObject, listBaseCell.transform.position,
                listBaseCell.transform.rotation, listBaseCell.transform.parent);


            var cell = newItemObj.GetComponent<UIMemoryRoomEventCell>();
            cell.Setup(item.Value);
            cell.OnClick.Subscribe(onClickListCell).AddTo(mSubscriptions);
            mItems.Add(item.Key, cell);
            newItemObj.SetActive(true);
            cellList.Add((model.Master.sortIndex,newItemObj));
        }

        foreach (var item in cellList)
        {
            item.Item2.transform.SetSiblingIndex(item.Item1);
        }
        
        
        
    }

    private async UniTask onClickStart()
    {
        if (mCurrentId == 0)
        {
            return;
        }
        //todo: huangqiang 
        //var sceneName=MapSceneManager.Instance.CurrentScene.name;
        var sceneName = "AdvMap006_0";
        DataManager.Instance.Local.Explore.memoryRoomInfo = (sceneName,"routeMemoryRoom");
        if (DataManager.Instance.Player.Explore.GetEvent(mCurrentId).Status==Status.Started)
        {
            await ExploreService.FinishEvent(mCurrentId);
        }
       await ExploreService.StartEvent(mCurrentId);
        await HideAsync();


        ExploreSceneParam p = new ExploreSceneParam();
        p.mapName = DataManager.Instance.Master.ExploreEvent[mCurrentId].initialMap;
        p.startRoute = DataManager.Instance.Master.ExploreEvent[mCurrentId].initialLocation;

        await GameSceneManager.Instance.ChangeSceneAsync<ExploreScene>("ExploreScene", p);
        
    }
    public async UniTask SetUp()
    {
        if (!init)
        {
            await OnUpdateCharacterViewList();
        }
        init = false;
        var t=characterHead.transform.parent.GetChild(1);
        t.GetComponent<UIButton>().onClick.Invoke(t.gameObject);
    }

    async UniTask OnInitCharacterViewList()
    {
        var characterMasters = DataManager.Instance.Master.BattleCharacter.Values
            .Where(master => (master.characterTypeId == 1)).OrderBy(master => master.sortId);
        foreach (var characterMaster in characterMasters)
        {
            if (DataManager.Instance.Player.Character.TryGet(characterMaster.id) == null) continue;
            GameObject go = Instantiate(characterHead.gameObject, content);
            var cell = go.GetComponent<MemoryStorageRoomSelectableCharacterHead>();
            await cell.SetupAsync(characterMaster.id);
            cell.OnClick.Subscribe(onSelectCharacter).AddTo(mSubscriptions);
            mObjects.Add(characterMaster.id, cell);
            go.SetActive(true);
        }

        contentRT.sizeDelta = new Vector2(contentRT.sizeDelta.x,
            (characterObjectRT.sizeDelta.y + contentVLG.spacing) * mObjects.Count);
        currentCharacterId = mObjects.ElementAt(0).Key;
        mObjects.ElementAt(0).Value.OnSelect();

    }

    private void onSelectCharacter(GameObject o)
    {
        var cell = o.GetComponentInParent<MemoryStorageRoomSelectableCharacterHead>();
        if (cell.CharacterId != currentCharacterId && currentCharacterId > 0)
        {
            mObjects[currentCharacterId].OnDeselect();
        }

        currentCharacterId = cell.CharacterId;
        cell.OnSelect();
        RefreshList(currentCharacterId);
    }

    // long currentCharacterId = 0;
    public void RefreshList(long characterId = 0)
    {
        currentCharacterId = characterId;
        sortList();
    }

    private void sortList()
    {
        var data = DataManager.Instance.Local.Explore.playerData;
        var tempList = data.eventList.Values;
        var sortedList = new List<ExploreEventViewModel>();
        foreach (var item in tempList)
        {
            if (item.finishCount>0)
            {
                sortedList.Add(item);
            }
        }
        sortedList.Sort((x, y) =>
        {
            if (x.eventStatus != y.eventStatus)
            {
                return y.eventStatus.CompareTo(x.eventStatus);
            }

            if (x.fav != y.fav)
            {
                return y.fav.CompareTo(x.fav);
            }
            else if (x.finishCount == 0 || y.finishCount == 0)
            {
                return x.finishCount.CompareTo(y.finishCount);
            }
            else
            {
                return x.masterId.CompareTo(y.masterId);
            }
        });
        for (int i = 0; i < sortedList.Count; i++)
        {
            mItems[sortedList[i].masterId].transform.SetSiblingIndex(i);
            // mItems[sortedList[i].masterId].RefreshNewState();
            mItems[sortedList[i].masterId].gameObject.SetActive(true);
            if (i == 0 || sortedList[i].eventStatus == ExploreEventViewModel.EventStatus.Accepted)
            {
                onClickListCell(mItems[sortedList[i].masterId].gameObject);
            }
        }
        

        if (currentCharacterId != 0)
        {
            var list = new List<ExploreEventViewModel>();
            foreach (var item in sortedList)
            {
                if (item.Master.battleCharacterMasterId == currentCharacterId)
                {
                    list.Add(item);
                }
            }

            for (int i = 0; i < sortedList.Count; i++)
            {
                bool hasCell = false;
                for (int j = 0; j < list.Count; j++)
                {
                    if (list[j].masterId == sortedList[i].masterId)
                    {
                        hasCell = true;
                        break;
                    }
                }

                if (!hasCell)
                {
                    mItems[sortedList[i].masterId].gameObject.SetActive(false);
                }
            }

            for (int i = 0; i < list.Count; i++)
            {
                //mItems[list[i].masterId].transform.SetSiblingIndex(i);
                if (i == 0 || list[i].eventStatus == ExploreEventViewModel.EventStatus.Accepted)
                {
                    onClickListCell(mItems[list[i].masterId].gameObject);
                }
            }
        }


        bool noEvent = true;
        for (int i = 0; i < listBaseCell.transform.parent.childCount; i++)
        {
            if (listBaseCell.transform.parent.GetChild(i).gameObject.activeSelf)
            {
                noEvent = false;
                break;
            }
        }
        noMemoryHint.SetActive(noEvent);
        charaInvitesGroup.SetActive(!noEvent);
        
    }

    async UniTask OnUpdateCharacterViewList()
    {
        foreach (var mObject in mObjects)
        {
            await mObject.Value.SetupAsync(mObject.Key);
        }
    }

    private void onClickListCell(GameObject o)
    {
        var cell = o.GetComponent<UIMemoryRoomEventCell>();
        if (cell.Model.masterId != mCurrentId && mCurrentId > 0)
        {
            mItems[mCurrentId].Select(false);
        }

        mCurrentId = cell.Model.masterId;
        cell.Select(true);

        showDetail(cell.Model);
    }

    private void showDetail(ExploreEventViewModel cellModel)
    {
        var t = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.REQUEST, $"{cellModel.masterId}_desc");
        t = "<line-indent=15%>" + t;
        describeText.SetRawText(t);
        
    }
}