﻿using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class BubbleEmoji : MonoBehaviour
{
    public float EmojiTime = 0f;
    public float PlayTime = 0f;
    public GameObject Emoji;
    public enum EmojiStates
    {
        None,
        Angry,
        Love,
        Wonder,
        Question,
        Note,
        Vertigo,
        Sweating,
        Speechless,
        Tea,
        Sweat,
        Cry,
        Happy,
        Surprised,
        Halo,
        Sweating2,
        Light
    }

    public EmojiStates _emojiStateNow = EmojiStates.None;
    private bool ifFade = false;
    private bool ifGenerate = false;

    Camera main_camera = null;
    [SerializeField] private Vector2 offset=new Vector2(0.2f,0.2f);

    void Awake()
    {
        main_camera = MapSceneManager.Instance.CurrentScene.GetCameraController().GetCamera();
    }

    public void Update()
    {
        if (_emojiStateNow != EmojiStates.None)
        {
            if (PlayTime == 0 && ifGenerate == false)
            {
                AsyncManager.Instance.StartAsync(PlayEmoji());
                ifGenerate = true;
            }

            if (ifGenerate == true && Emoji == null)
            {
                Debug.Log("等待生成emoji");
                return;
            }
            PlayTime += Time.deltaTime;
            
            if (PlayTime >= EmojiTime)
            {
                if (!ifFade)
                {
                    PlayFade();
                }
            }
            else
            {
                // Debug.Log(PlayTime + "");
                // Debug.Log(EmojiTime);
                // Debug.Log(ifFade);
                scale = gameObject.transform.localScale.y;
                var leftPos =MapSceneManager.Instance.CurrentScene.GetCharaScreenLeftWorldPos(gameObject.transform.position, offset,main_camera.transform.position);
                var lerpPos = Vector3.Lerp(leftPos, main_camera.transform.position, 0.2f);
                Emoji.transform.position = lerpPos;
                var euler = main_camera.transform.eulerAngles;
                euler.z = 0;
                Emoji.transform.eulerAngles = euler;
                Emoji.transform.localScale = new Vector3(1, 1, 1) * 0.07f;
            }
           // if (Emoji == null) StopEmoji();
        }
        else
        {
            StopEmoji();
        }
    }

    public void SetEmoji(string emojiName, float EmojiTime)
    {
        BubbleEmoji.EmojiStates state;
        switch (emojiName)
        {
            case "angry":
                state = BubbleEmoji.EmojiStates.Angry;
                break;
            case "love":
                state = BubbleEmoji.EmojiStates.Love;
                break;
            case "note":
                state = BubbleEmoji.EmojiStates.Note;
                break;
            case "question":
                state = BubbleEmoji.EmojiStates.Question;
                break;
            case "speechless":
                state = BubbleEmoji.EmojiStates.Speechless;
                break;
            case "sweat":
                state = BubbleEmoji.EmojiStates.Sweat;
                break;
            case "sweating":
                state = BubbleEmoji.EmojiStates.Sweating;
                break;
            case "tea":
                state = BubbleEmoji.EmojiStates.Tea;
                break;
            case "vertigo":
                state = BubbleEmoji.EmojiStates.Vertigo;
                break;
            case "wonder":
                state = BubbleEmoji.EmojiStates.Wonder;
                break;
            case "cry":
                state = BubbleEmoji.EmojiStates.Cry;
                break;
            case "sweating2":
                state = BubbleEmoji.EmojiStates.Sweating2;
                break;
            case "halo":
                state = BubbleEmoji.EmojiStates.Halo;
                break;
            case "surprised":
                state = BubbleEmoji.EmojiStates.Surprised;
                break;
            case "happy":
                state = BubbleEmoji.EmojiStates.Happy;
                break;
            case "light":
                state = BubbleEmoji.EmojiStates.Light;
                break;
            default:
                state = BubbleEmoji.EmojiStates.None;
                break;
        }

        if (_emojiStateNow != state)
        {
            _emojiStateNow = state;
            this.EmojiTime = EmojiTime;
            PlayTime = 0;
        }
        else
        {
            this.EmojiTime += EmojiTime;
        }
    }

    public void StopEmoji()
    {
        EmojiTime = 0;
        PlayTime = 0;
        _emojiStateNow = EmojiStates.None;

        if (Emoji != null)
        {
            Destroy(Emoji);
        }

        DestroyImmediate(this);
    }

    private async UniTask PlayEmoji()
    {
        ifFade = false;
        string emojipath = GetEmojiPath(_emojiStateNow);
        if (emojipath != "")
        {
            Emoji = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync(emojipath);
            Log.Info("生成该动画" + Emoji.name);
            var EmojiAni = Emoji.GetComponent<Animator>();
            EmojiAni.GetBehaviour<BubbleStateMachine>().bubble = Emoji;
            // Emoji.transform.parent = gameObject.transform;
            scale = gameObject.transform.localScale.y;
            var leftPos =MapSceneManager.Instance.CurrentScene.GetCharaScreenLeftWorldPos(gameObject.transform.position, offset,main_camera.transform.position);
            var lerpPos = Vector3.Lerp(leftPos, main_camera.transform.position, 0.2f);
            Emoji.transform.position = lerpPos;
            Emoji.transform.localScale = new Vector3(1, 1, 1) * scale;
            // EmojiAni.Play("Entry");
        }
    }

    public float scale = 1;

    private void PlayFade()
    {
        var emoji = Emoji.GetComponent<Animator>();
        Log.Info("销毁该动画" + Emoji.name);
        emoji.Play("explore_close");
        ifFade = true;
        ifGenerate = false;
        StopEmoji();
        //emoji.Update(0);
    }

    private string GetEmojiPath(EmojiStates state)
    {
        switch (state)
        {
            case EmojiStates.Angry:
                return "Effect/emoji/explore_sign_angry";
            case EmojiStates.Love:
                return "Effect/emoji/explore_sign_love";
            case EmojiStates.Note:
                return "Effect/emoji/explore_sign_note";
            case EmojiStates.Question:
                return "Effect/emoji/explore_sign_question";
            case EmojiStates.Speechless:
                return "Effect/emoji/explore_sign_speechless";
            case EmojiStates.Sweat:
                return "Effect/emoji/explore_sign_sweat";
            case EmojiStates.Sweating:
                return "Effect/emoji/explore_sign_sweating";
            case EmojiStates.Tea:
                return "Effect/emoji/explore_sign_tea";
            case EmojiStates.Vertigo:
                return "Effect/emoji/explore_sign_vertigo";
            case EmojiStates.Wonder:
                return "Effect/emoji/explore_sign_wonder";
            case EmojiStates.Cry:
                return "Effect/emoji/explore_sign_cry";
            case EmojiStates.Happy:
                return "Effect/emoji/explore_sign_happy";
            case EmojiStates.Surprised:
                return "Effect/emoji/explore_sign_surprised";
            case EmojiStates.Halo:
                return "Effect/emoji/explore_sign_halo";
            case EmojiStates.Sweating2:
                return "Effect/emoji/explore_sign_sweating2";
            case EmojiStates.Light:
                return "Effect/emoji/explore_sign_light";              
            default:
                return "";
        }
    }
}
