﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Map;
using Pheonix.Core;
using UnityEngine;
using Cysharp.Threading.Tasks;
using TMPro;

public class BubbleText : MonoBehaviour
{
    public float TextTime;
    public float PlayTime;
    public GameObject Text;

    public bool BubbleState = false;
    public string TextContent;

    private bool ifFade = false;
    
    public void Start()
    {
        PlayTime = 0;
        TextTime = 0;
        BubbleState = false;
        TextContent = "";
    }
    
    public void Update()
    {
        if (BubbleState)
        {
            if (PlayTime == 0) AsyncManager.Instance.StartAsync(PlayText());
            PlayTime += Time.deltaTime;
            if (PlayTime >= TextTime && ifFade == false) PlayFade();
            if (Text == null) StopText();
        }
    }
    
    public void SetText(bool bubbleState, string textContent, float textTime)
    {
        if (BubbleState != bubbleState)
        {
            BubbleState = bubbleState;
            TextTime = textTime;
            PlayTime = 0;
        }
        else
        {
            TextTime += textTime;
        }

        TextContent = textContent;
        PlayText();
    }

    private void PlayFade()
    {
        Text.GetComponent<CharacterMessage>().Destroy();
        ifFade = true;
    }

    private async UniTask  PlayText()
    {
       
        string BubbleTextPrefabe = "Effect/bubbletext/CharacterMessage";
        ifFade = false;
        if (BubbleTextPrefabe != "")
        {
            Text = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync(BubbleTextPrefabe);
            var message = Text.GetComponent<Map.CharacterMessage>();
            Text.transform.parent = gameObject.transform;
            Text.transform.position = gameObject.transform.position+new Vector3(0,0,0);
            Text.transform.localScale = new Vector3(1, 1, 1) * 0.1f;
            message.SetMessage(TextContent);
            message.SetAnimator();
        }
    }

    public float scale = 1;

    public void StopText()
    {
        TextTime = 0;
        PlayTime = 0;
        BubbleState = false;
        GameObject.Destroy(Text);
    }
}
