﻿using System.Collections;
using System.Collections.Generic;
using Map;
using UnityEngine;

public class Follow : MonoBehaviour
{
    /// <summary>
    /// the follow target
    /// </summary>
    public GameObject Pather = null;

    public float StartSlowDis = 1.5f;

    private MiniCharacter.AnimationType state = MiniCharacter.AnimationType.WAIT_01;

    /// <summary>
    /// the follow distance 
    /// </summary>
    public float FollowDis = 1f;

    //private Vector2 LastPatherPos;

    /// <summary>
    /// the follow speed
    /// </summary>
    public float Speed;

    void Update()
    {
        if(Pather != null){
            FollowPather();
        }
    }
    /// <summary>
    /// the method that can set parament of follow behavior
    /// </summary>
    /// <param name="Pather">the follow target</param>
    /// <param name="FollowDis">the distance between target and follower</param>
    /// <param name="Speed">the speed of follower move</param>
    public void SetFollow(GameObject Pather,float FollowDis = 1f,float Speed = 5f) { 
        this.Pather = Pather;
        this.FollowDis = FollowDis;
        this.Speed = Speed;
    }

    /// <summary>
    /// the method that can stop follow behavior
    /// </summary>
    public void StopFollow(){
        Pather = null;
        Speed = 0;
        FollowDis = 0;
        StartSlowDis = 0;
    }

    // ReSharper disable Unity.PerformanceAnalysis
    /// <summary>
    /// the methodd that can truly achieve the follow behavior
    /// </summary>
    private void FollowPather(){
        Vector3 FollowerPos = gameObject.transform.position;
        Vector3 PatherPos = Pather.transform.position;
        float dis = CalcuDis(FollowerPos, PatherPos);
        Vector3 Direction = PatherPos - FollowerPos;
        Direction.Normalize();
        float adjSpeed = 0;
        if(dis>FollowDis){
            if(dis < StartSlowDis){
                adjSpeed = Speed * (dis - FollowDis) / (StartSlowDis - FollowDis);
            }
            else{
                adjSpeed = Speed;
            }
            FollowerPos += Time.deltaTime * Direction * adjSpeed;
        }
        var miniC = gameObject.GetComponent<Map.MiniCharacter3D>();
        miniC.SetPosition(FollowerPos);
        miniC.SetDir(Direction);
        miniC.gameObject.transform.LookAt(new Vector3(PatherPos.x, miniC.gameObject.transform.position.y, PatherPos.z));
        
        if (adjSpeed > 0.1f)
        {
            miniC.PlayRunAnimation();
        }
        else
        {
            miniC.PlayIdleAnimation();
        }
    }


    /// <summary>
    /// the method that can calculate the distanse between target and follower
    /// </summary>
    /// <param name="a"></param>
    /// <param name="b"></param>
    /// <returns></returns>
    private float CalcuDis(Vector3 a,Vector3 b){
        return Vector3.Distance(a,b);
    }

}
