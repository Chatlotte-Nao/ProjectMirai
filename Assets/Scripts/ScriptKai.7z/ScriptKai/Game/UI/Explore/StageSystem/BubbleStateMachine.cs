﻿using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using UnityEngine;

public class BubbleStateMachine : StateMachineBehaviour
{
    public GameObject bubble = null;
    public override void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (bubble)
        {
            Log.Info(bubble.name);
        }      
        if(stateInfo.IsName("explore_close")) Destroy(bubble);
    }
}
