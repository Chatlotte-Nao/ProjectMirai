﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using TMPro;
using UnityEngine;
using UnityEngine;
using System.Linq;
using System.Collections.Generic;
using Random = UnityEngine.Random;

namespace Map
{
	/// <summary>
	/// マップ上のキャラの吹き出し, 在进入带有动态背景的小游戏后，需要关闭气泡框。
	/// </summary>
	public class CharacterMessage : UIDialogBase
	{
		public GameObject self;
		public bool firesVoice = true;

		[SerializeField] private float offsetY;

		[SerializeField] TextMeshProUGUI text;
		string voice = "";

		int a = 0;

		// [SerializeField] RectTransform sprite;
		Animator ani;

		int chaid = 0;
		float jiange = 2f;
		private int mCharaID = -1;
		private RectTransform mRect;
		float time = 5f;

		void Awake()
		{
			gameObject.SetActive(false);
			ani = gameObject.GetComponent<Animator>();
		}
        private void OnEnable()
        {
			//SetMess();
		}

        private void Update()
		{
			if (this.gameObject.activeInHierarchy&&mCharaID!=-1)
			{
				try
				{
					var charaScreenPos =
						MapSceneManager.Instance.CurrentScene.GetCharaScreenPos(mCharaID,
							new Vector3(0, offsetY, 0)); //去mapscene里找characters这个字典 按id去找角色获取世界坐标 转成屏幕坐标
					mRect.anchoredPosition3D = new Vector3(charaScreenPos.x,charaScreenPos.y,0);
				}
				catch
				{
					Debug.LogWarning("获取屏幕坐标失败");
				}
			}
            if (gameObject.activeSelf)
            {
				time -= Time.deltaTime;
                if (time<=0)
                {
					self.SetActive(false);
					jiange -= Time.deltaTime;
                    if (jiange<=0)
                    {						
						self.SetActive(true);
						SetMess();
						jiange = 2f;
						time = 5f;
					}
					
				}
            }
		}

		public async UniTask Setup(int charaID)
		{
			mRect = this.GetComponent<RectTransform>();
			mCharaID = charaID;
			var charaScreenPos = MapSceneManager.Instance.CurrentScene.GetCharaScreenPos(mCharaID,new Vector2(0,offsetY));//去mapscene里找characters这个字典 按id去找角色获取世界坐标 转成屏幕坐标
			mRect.anchoredPosition3D = new Vector3(charaScreenPos.x,charaScreenPos.y,0);
			chaid = charaID;

			SetMess();

		}

		public void SetMess()
        {
			List<string> list = new List<string>();
			foreach (var item in DataManager.Instance.Master.ExploreBubbleMaster)
			{
				if (item.Value.miniCharacterId == chaid)
				{
                    if (DataManager.Instance.Player.Character.TryGet((long)chaid).Engaged==0)
                    {
                        if (DataManager.Instance.Local.Explore.homeFollowCharacter<=0)
                        {
							list = item.Value.wordBubbleClewBeforeContract;
                        }
                        else
                        {
							list = item.Value.wordBubbleClewFollow;
						}
					
                    }
                    else
                    {
						if (DataManager.Instance.Local.Explore.homeFollowCharacter <= 0)
						{
							list = item.Value.wordBubbleClewAfterContract;
						}
						else
						{
							list = item.Value.wordBubbleClewFollow;
						}
					}

					
				}
			}
            var master = DataManager.Instance.Master.ExploreBubbleMaster.Values.FirstOrDefault(x => x.miniCharacterId == chaid);
			//SetMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, list[Random.Range(0, list.Count - 1)]));

		
            while (true)
            {
				int index = Random.Range(0, list.Count);
				if (index!=a)
                {
					a = index;
					break;
                }
            }
			string textmes = list[a].Split(':')[0];			
			voice = list[a].Split(':')[1];
			if (textmes != "0")
			{
				string mess = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, textmes);
				SetMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, mess));			
			}
		}

		public async UniTask  ShowChild()
		{
			await UniTask.Delay(1000);//等1秒让相机过度完 避免抖动
			try
			{
				gameObject.transform.GetChild(0).gameObject.SetActive(true);
				if (!string.IsNullOrEmpty(voice))
				{				
					if (firesVoice == true)
					{
						Game.Sound.SoundPlayer.StopVoice();
						Game.Sound.SoundPlayer.PlayVoice(voice);
						firesVoice = false;
					}					
				}
			}
			catch
			{
				Log.Debug("无法找到Message物体");
			}
		}
		public async void SetMessage(string message)
		{
			if (string.IsNullOrEmpty(message) || message == "0")
			{
				gameObject.SetActive(false);
				return;
			}
			else
			{
				gameObject.SetActive(true);
			}

			text.text = message;
            if (!string.IsNullOrEmpty(voice))
            {
                if (firesVoice == false)
                {
					Game.Sound.SoundPlayer.StopVoice();
					Game.Sound.SoundPlayer.PlayVoice(voice);

				}
                   
            }


            // int length = message.Length;
            //if (length < 9)
            //{
            //    text.fontSize = 2.7f;
            //    float width = (2.86f - 2.16f) / (9f - 2f) * (length - 2f) + 2.16f;
            //    text.alignment = TextAlignmentOptions.Center;
            //    sprite.size = new Vector2(width, 1f);
            //    gameObject.transform.localPosition = new Vector3(0, 2.5f, 0);
            //}
            //else if (8 < length && 19 > length)
            //{
            //    text.fontSize = 2.6f;
            //    text.alignment = TextAlignmentOptions.Justified;
            //    sprite.size = new Vector2(2.86f, 1.25f);
            //    gameObject.transform.localPosition = new Vector3(0, 2.25f, 0);
            //}
            //else
            //{
            //    text.fontSize = 2.5f;
            //    text.alignment = TextAlignmentOptions.Justified;
            //    sprite.size = new Vector2(2.86f, 1.5f);
            //    gameObject.transform.localPosition = new Vector3(0, 2f, 0);
            //}

            // text.fontSize = 1.8f;

            //         if (length > 6)
            //         {
            // text.alignment = TextAlignmentOptions.Justified;
            // sprite.localScale = new Vector2(1.56f, math.ceil(length/7f)*0.36f);
            //         }
            //         else
            //         {
            // text.alignment = TextAlignmentOptions.Center;
            // sprite.localScale = new Vector2(0.2f * (length + 2), 0.6f);
            //         }
        }


		public void SetAnimator()
		{
			ani = gameObject.GetComponent<Animator>();
			ani.Play("Entry");
			ani.GetBehaviour<BubbleStateMachine>().bubble = gameObject;
		}

		public void Destroy()
		{
			Game.Sound.SoundPlayer.StopVoice();
			ani.Play("explore_close");
		}


		public override void Dispose()
		{
			Game.Sound.SoundPlayer.StopVoice();
			text = null;
			ani = null;
			base.Dispose();
		}
	}
}
