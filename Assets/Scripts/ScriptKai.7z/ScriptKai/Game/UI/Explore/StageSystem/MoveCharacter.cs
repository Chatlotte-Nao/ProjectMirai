﻿using System;
using Map;
using UnityEngine;
using UnityEngine.AI;

public class MoveCharacter : MonoBehaviour
{
    public  Vector3 _goal;
    public Vector3 _speed;
    public bool arrive=false;
    private float movetime;
    public float _time;
    private bool cameraFollow;
    private bool playMoveAnimation;
    const float DISTANCE_OFFSET = 0.13f;
    public MiniCharacter3D miniC;
    private void Update()
    {
        if (cameraFollow)
        {
            MapSceneManager.Instance.CurrentScene.GetCameraController().SetPosition(transform.position);
        }
        //if (arrive) return;
        //if (movetime<_time) Move(Time.deltaTime);
        //else Arrive();
        if (arrive) { return; }
        // if (miniC&&!miniC.navMeshAgent.pathPending && miniC.navMeshAgent.pathStatus == NavMeshPathStatus.PathComplete && miniC.navMeshAgent.remainingDistance <= DISTANCE_OFFSET)
        if (Vector3.Distance(gameObject.transform.position,new Vector3(_goal.x, gameObject.transform.position.y, _goal.z))<= DISTANCE_OFFSET)
        {
            Arrived();
        }
    }

    private void Move(float deltaTime)
    {
        gameObject.transform.position += deltaTime * _speed;
        movetime += deltaTime;
       

        var miniC = gameObject.GetComponent<Map2DCharacter>();
    }

    public void SetGoal(Vector3 goal, float time, bool _cameraFollow, bool _playMove)
    {
        this._goal = goal;
        playMoveAnimation = _playMove;
        _time = time;
        var dir = goal - gameObject.transform.position;
        _speed = dir / _time;
        arrive = false;
        movetime = 0;
        cameraFollow = _cameraFollow;
        var miniC = gameObject.GetComponent<MiniCharacter3D>();
        if (miniC != null && playMoveAnimation)
        {
            miniC.SetDir(dir);
            miniC.PlayMoveAnimation();
        }
    }

    internal void SetGoal(Vector3 goal, int type, float percentage,float animpercentage, int _cameraFollow, int _playMove)//新增方法
    {
     
        this._goal = goal;
        miniC = gameObject.GetComponent<MiniCharacter3D>();
       // miniC.animator.Play("Standing");
        miniC.navMeshAgent.enabled = false;
        if (type == 0)
        {
            miniC.navMeshAgent.speed = 1.5f*percentage;
        }
        else
        {
            miniC.navMeshAgent.speed = 4.5f*percentage;
        }
        if (miniC.navMeshAgent.angularSpeed <= 20)
        {
            Debug.Log("人物移动不能转向 aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        } 
        if (animpercentage == 0)
        {
            animpercentage = 1;
        }
        miniC.navMeshAgent.enabled = true;
        miniC.navMeshAgent.SetDestination(goal);
        playMoveAnimation = _playMove==1;   
        var dir = goal - gameObject.transform.position;
       
        arrive = false;
        movetime = 0;
        this.cameraFollow = _cameraFollow==1;
       
        if (miniC != null)
        {
            miniC.SetDir(dir);
            if (type == 0)
            {
                miniC.animator.speed = animpercentage;
                miniC.PlayMoveAnimation();
            }
            else
            {
                miniC.animator.speed = animpercentage;
                miniC.PlayRunAnimation();
            }
        }
    }

    private void Arrived()               //新增方法
    {       
        var miniC = gameObject.GetComponent<MiniCharacter3D>();
        gameObject.transform.position = this._goal;
        if (miniC != null)
        {
            miniC.PlayIdleAnimation();
        }
        miniC.animator.speed = 1;
       // miniC.navMeshAgent.isStopped = true;
        miniC.CancelMove();
        DestroyImmediate(this);
        arrive = true;
    }


    private void Arrive()
    {
        arrive = true;
        _speed = new Vector3(0,0,0);
        gameObject.transform.position = _goal;
        movetime = 0;
        var miniC = gameObject.GetComponent<MiniCharacter3D>();
        if (miniC != null && playMoveAnimation)
        {
            miniC.PlayIdleAnimation();
        }
        DestroyImmediate(this);
    }

    

    void OnEnable()
    {
        // gameObject.AddComponent<RealtimeScaleController>();
    }

    void OnDisable()
    {
        // DestroyImmediate(gameObject.GetComponent<RealtimeScaleController>());
    }
}