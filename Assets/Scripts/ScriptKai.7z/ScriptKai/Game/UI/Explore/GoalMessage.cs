﻿using System;
using Base.Util;

using Game.Sound;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using TMPro;
using LocalizeManager = Pheonix.Core.LocalizeManager;

public class GoalMessage : MonoBehaviour, IPointerDownHandler, IPointerClickHandler, IPointerExitHandler
{
	const float LONG_TAP_TIME = 0.5f;

	string[] animationName =
	{
		string.Empty,
		"SlideIn",
		"SlideOut",
		"AppearanceOut",
		"MissionClear"
	};
	static readonly string ANIMATION_CLIP_CLEAR = "MissionClear";

	public enum AnimationType
	{
		NONE,
		SLIDEIN,
		SLIDEOUT,
		APPEARANCEOUT,
		CLEAR
	}

	[SerializeField] GameObject unconfirmedMark;
	[SerializeField] TextMeshProUGUI goalText;
	[SerializeField] Button foldButton;
	[SerializeField] Image foldButtonImage;
	[SerializeField] Sprite foldOn;
	[SerializeField] Sprite foldOff;
	[SerializeField] bool isParent;
	[SerializeField] Animator clearAnimator;
	[SerializeField] Image stampImage;
	[SerializeField] Sprite failedSprite;

	[System.NonSerialized]
	public UnityEvent onFoldButtonClick = new UnityEvent();
	[System.NonSerialized]
	public UnityEvent onClick = new UnityEvent();

	[System.NonSerialized]
	public int masterId;
	/// <summary>
	/// 親となるゴールメッセージか
	/// </summary>
	public bool IsParent { get {return isParent; } }
	/// <summary>
	/// 子ゴール表示を畳んだ状態か
	/// </summary>
	public bool IsFolding { get; set; } = false;

	public bool IsEndFirstAnim { get; private set; }

	public string parentFlag { get; set; }

	bool isMarkDisplay = true;

	public Animator animator { get; private set; }
	Coroutine scrollToken = null;
	Coroutine tapToken = null;


	private void Awake()
	{
		animator = GetComponent<Animator>();
		//失敗スタンプ読み込み
		var sceneName = (gameObject.scene != null) ? gameObject.scene.name : string.Empty;
		Game.Ui.LocalizeResourceManager.SetLocalizeResource<Sprite>(sceneName, failedSprite.name, sprite =>
		{
			if (this == null)
				return;
			if (gameObject == null)
				return;
			failedSprite = sprite;
		});

		foldButton.onClick.AddListener(() =>
		{
			IsFolding = !IsFolding;
			onFoldButtonClick.Invoke();
		});
	}

	private void OnDestroy()
	{
		if (scrollToken != null)
		{
			StopCoroutine(scrollToken);
		}
		if (tapToken != null)
		{
			StopCoroutine(tapToken);
		}
		onFoldButtonClick.RemoveAllListeners();
		onClick.RemoveAllListeners();

		scrollToken = null;
		tapToken = null;
		onFoldButtonClick = null;
		onClick = null;
	}

	public void OnPointerDown(PointerEventData eventData)
	{

	}
	public void OnPointerExit(PointerEventData eventData)
	{
		
	}
	public void OnPointerClick(PointerEventData eventData)
	{
		if (tapToken != null)
		{
			StopCoroutine(tapToken);
		}
		tapToken = null;

		onClick.Invoke();
	}

	public void SetText(string val)
	{
		goalText.text = val;
	}

	public void SetMessage(int masterId)
	{
		var master = DataManager.Instance.Master.GoalMessage[masterId];
		if (master == null)
			return;
		if (master.IsParent() != IsParent)
		{
			Debug.LogWarning("使用するゴールメッセージプレハブを間違えています！");
		}


		goalText ??= GetComponentInChildren<TextMeshProUGUI>();
		if (goalText != null)
		{
			goalText.text = master.GetMessage();
		}

		this.masterId = masterId;
	}

	public void SetMessageAnchor(TextAlignmentOptions anchor)
	{
		if (goalText != null)
		{
			goalText.alignment = anchor;
		}
	}

	/// <summary>
	/// マークを表示しない
	/// </summary>
	public void SetMarkUndisplay()
	{
		isMarkDisplay = false;
		UpdateDisplay();
	}

	/// <summary>
	/// 表示更新
	/// </summary>
	public void UpdateDisplay()
	{
		//var list = UserData.GetPlayerData().confirmedGoalMessageList;
		//var isUnconfirmed = !list.Any(l => l == masterId);
		var isUnconfirmed  = DataManager.Instance.Master.GoalMessage.ContainsKey(masterId);
		

		unconfirmedMark.SetActive(isMarkDisplay && isUnconfirmed);

		//foldButton.gameObject.SetActive(isMarkDisplay && IsParent);
		foldButtonImage.sprite = (IsFolding) ? foldOn : foldOff;
	}

	/// <summary>
	/// 指定した高さと同じ位置にいるか
	/// </summary>
	public bool IsEqualY(float y)
	{
		var rect = GetComponent<RectTransform>();
		return rect.localPosition.y == y;
	}

	public void SetMoveY(float endY, float timeLimit)
	{
		if (scrollToken != null)
		{
			StopCoroutine(scrollToken);
		}
		scrollToken = StartCoroutine(MoveYFunction(endY, timeLimit));
	}

	IEnumerator MoveYFunction(float endY, float timeLimit)
	{
		var rect = GetComponent<RectTransform>();
		var startY = rect.localPosition.y;

		float time = 0.0f;
		while (time < timeLimit)
		{
			time += Time.deltaTime;
			var nowY = Mathf.Lerp(startY, endY, time / timeLimit);
			SetY(nowY);
			yield return null;
		}
		SetY(endY);
		scrollToken = null;
	}

	public void SetX(float x)
	{
		var rect = GetComponent<RectTransform>();
		Vector3 pos = rect.localPosition;
		pos.x = x;
		rect.localPosition = pos;
	}

	public void SetY(float y)
	{
		var rect = GetComponent<RectTransform>();
		Vector3 pos = rect.localPosition;
		pos.y = y;
		rect.localPosition = pos;
	}

	public IEnumerator SetAnimationRoutine(AnimationType type)
	{
		if (type == AnimationType.SLIDEOUT)
		{
			unconfirmedMark.SetActive(false);
			foldButton.gameObject.SetActive(false);
		}

		if (animator != null)
		{
			var inTime =
				AnimationUtil.GetAnimationLength(animator.runtimeAnimatorController, animationName[(int) type]);
			animator.Play(animationName[(int) type]);
			yield return AnimationUtil.Wait(animator, inTime);
			animator.Rebind();
		}

		SetEndFirstAnim();
	}

	public void SetEndFirstAnim()
	{
		IsEndFirstAnim = true;
	}

	/// <summary>
	/// クリアアニメーション設定（メッセージとは別アニメを使用しているので別関数）
	/// </summary>
	/// <returns></returns>
	public IEnumerator SetClearAnimationRoutine(bool isFailed)
	{
		if (clearAnimator == null) yield break;
		//
		if (isFailed) stampImage.sprite = failedSprite;

		var waitTime = AnimationUtil.GetAnimationLength(clearAnimator.runtimeAnimatorController, ANIMATION_CLIP_CLEAR);
		clearAnimator.Play(ANIMATION_CLIP_CLEAR);
		SoundPlayer.PlaySe(SoundConstants.SE_COMMON_05_1);
		yield return AnimationUtil.Wait(clearAnimator, waitTime);
	}

	/// <summary>
	/// このメッセージに連動したムータヒントメッセージを取得
	/// </summary>
	/// <returns></returns>
	public string GetHintMessage()
	{
		var master = DataManager.Instance.Master.GoalMessage[masterId];
		if (master == null)
			return string.Empty;
		return LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.GOAL_MESSAGE_HINT, master.hintText);
	}

	IEnumerator LongTapFunction()
	{
		float time = 0.0f;
		while (time < LONG_TAP_TIME)
		{
			time += Time.deltaTime;
			yield return null;
		}
		onFoldButtonClick.Invoke();
		tapToken = null;
	}
}
