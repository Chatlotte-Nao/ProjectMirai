using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using Game.ScriptEngine;
using TMPro;
using DG.Tweening;

public class UIExploreGachaDialog : UIDialogBase
{
    [SerializeField] private UIButton handleBtn;
    [SerializeField] private UIButton slitBtn;
    [SerializeField] UIButton closeBtn;
    [SerializeField] private Camera _camera;
    [SerializeField] private RawImage _rawImage;
    [SerializeField] private Animator _idelAnimator;
    [SerializeField] private Animator _coinAnimator;
    [SerializeField] private Animator _rotateAnimator;
    [SerializeField] private Animator _candyAnimator;
    [SerializeField] private GameObject loop;
    [SerializeField] private GameObject loopover;
    [SerializeField] private UIText _coinCount;
    [SerializeField] private GameObject tips;
    [SerializeField] private UIText systemTipsText;
    [SerializeField] private UIText tipsMesText;
    [SerializeField] private ParticleSystem candyeff1;
    [SerializeField] private ParticleSystem candyeff2;
    [SerializeField] private ParticleSystem candyeff3;
    [SerializeField] private GameObject candy1;
    [SerializeField] private GameObject candy2;
    [SerializeField] private GameObject candy3;
    [SerializeField] private GameObject camera;
    [SerializeField] private UIText remainTimesText;
    [SerializeField] private Image backButton;
    [SerializeField] private Image helpButtonImg;
    [SerializeField] private UIButton helpButton;
    [SerializeField] private TextMeshProUGUI backButtonText;
    [SerializeField] private GameObject titleBar;

    public UnityEvent OnComplete = new UnityEvent();

    private UIGachaMachineResult _mGachaMachineResult;
    private UIGachaResultModel _mGachaResultModel;
    private Vector3 campos = new Vector3();
    private Quaternion camrot = new Quaternion();
    public UIGachaViewModel data;


    public UIGachaParam gachaParam;


    private List<long> gachaRewardsIdList;

    private bool IsCandy = false;

    //private bool IsCoin = false;
    private bool IsEff = true;
    private bool IsRotate = false;

    private bool IsSelect = false;
    ItemMaster item = null;

    private float m_Time;
    private Color previousBackButtonColor;
    private Color previousBackButtonTextColor;

    private Color previousHelpButtonColor;
    private Color previousRemainTimesTextColor;

    private TextMeshProUGUI remainTimesTMP;
    private List<long> senarioRewardsIdList;

    //重置硬币
    //private void RefreshCoin(bool isgo = false)
    //{
    //    var value = DataManager.Instance.Player.Item.GetCount(data.master.gachaContentId);
    //    if (isgo)
    //    {

    //        if (value - 1 > 99999)
    //        {
    //            _coinCount.SetRawText("99999+");
    //        }
    //        else
    //        {
    //            _coinCount.SetRawText((value - 1).ToString());
    //        }

    //    }
    //    else
    //    {
    //        if (value > 99999)
    //        {
    //            _coinCount.SetRawText("99999+");
    //        }
    //        else
    //            _coinCount.SetRawText(DataManager.Instance.Player.Item.GetCount(data.master.gachaContentId).ToString());
    //    }
    //}

    float t = 1.3f;
    long times = 0;
    public ClickEvent OnClose => closeBtn.onClick;
    public UnityEvent OnHandleDownClick => handleBtn.OnTouchDown;

    public ClickEvent OnSlitClick => slitBtn.onClick;

    //bool flag = false;
    private void Update()
    {
        if (tips.activeSelf)
        {
            t -= Time.deltaTime;
            if (t <= 0f)
            {
                tips.SetActive(false);
            }
        }

        if (gachaParam != null)
        {
            titleBar.SetActive(false);
            remainTimesText.gameObject.SetActive(false);
        }

        //if (_coinAnimator && IsCoin)
        //{
        //    AnimatorStateInfo animatorStateInfo = _coinAnimator.GetCurrentAnimatorStateInfo(0);
        //    if (animatorStateInfo.normalizedTime >= 1f)//投币动画结束
        //    {
        //        IsSelect = true;
        //        _coinAnimator.gameObject.SetActive(false);
        //        _idelAnimator.gameObject.SetActive(true);
        //    }
        //}

        if (IsCandy && _candyAnimator)
        {
            AnimatorStateInfo animatorStateInfo1 = _candyAnimator.GetCurrentAnimatorStateInfo(0);
            if (animatorStateInfo1.normalizedTime >= 0.65f && IsEff)  //糖果动画结束
            {
                PlayEff();
            }
            if (animatorStateInfo1.normalizedTime >= 1f)  //糖果动画结束
            {
                ShowItemGet();

                helpButtonImg.color = previousHelpButtonColor;
                backButton.color = previousBackButtonColor;
                backButtonText.color = previousBackButtonTextColor;
                remainTimesText.SetColor(previousRemainTimesTextColor);
                closeBtn.SetLock(true);
                //titleBar.SetActive(true);

                _coinAnimator.SetTrigger("candy");
                _candyAnimator.gameObject.SetActive(false);
                _idelAnimator.gameObject.SetActive(true);
                loop.SetActive(false);
                camera.transform.position = campos;
                camera.transform.rotation = camrot;
                IsRotate = false;
                IsCandy = false;
            }
        }

        if (IsRotate && _rotateAnimator)//扭蛋动画结束
        {
            //if (Input.GetMouseButtonUp(0))
            //{
            //    flag = true;
            //}
            if (true)
            {
                AnimatorStateInfo animatorStateInfo2 = _rotateAnimator.GetCurrentAnimatorStateInfo(0);
                if (animatorStateInfo2.normalizedTime >= 1f)
                {
                    // loopover.GetComponent<ParticleSystem>().Stop();
                    _rotateAnimator.SetBool("isrotate", false);
                    _rotateAnimator.gameObject.SetActive(false);
                    _idelAnimator.gameObject.SetActive(true);
                    Base.Sound.SoundManager.GetInstance().StopAllSe();

                    PlayCandyAnimationAsync();
                    HandleUpClcik();
                    //flag = false;
                    //IsCoin = false;
                    IsSelect = false;
                }
            }
        }
        if (IsSelect)
        {
            //2f消失速度
            m_Time += Time.deltaTime;
            helpButtonImg.color = new Color(helpButtonImg.color.r, helpButtonImg.color.g, helpButtonImg.color.b, Mathf.Lerp(1, 0, m_Time * 2f));
            backButton.color = new Color(backButton.color.r, backButton.color.g, backButton.color.b, Mathf.Lerp(1, 0, m_Time * 2f));
            backButtonText.color = new Color(backButtonText.color.r, backButtonText.color.g, backButtonText.color.b, Mathf.Lerp(1, 0, m_Time * 2f));
            remainTimesTMP.color = new Color(remainTimesTMP.color.r, remainTimesTMP.color.g, remainTimesTMP.color.b, Mathf.Lerp(1, 0, m_Time * 2f));

            //m_Time * 2f透明度
            if (m_Time * 2f > 1)
            {
                closeBtn.SetLock(true);
                //titleBar.SetActive(false);
            }
        }


    }

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        campos = camera.transform.position;
        camrot = camera.transform.rotation;
        loopover.GetComponent<ParticleSystem>().Stop();
        var rt = new RenderTexture(Screen.width, Screen.height, 32);
        rt.filterMode = FilterMode.Trilinear;
        _camera.targetTexture = rt;
        _rawImage.texture = rt;


        data = await GachaService.GetExplpreGachaModel();
        times = data.availableCount;

        //OnSlitClick.GuardSubscribeAsync(SlitClick).AddTo(mSubscriptions);
        OnHandleDownClick.GuardSubscribeAsync(HandleDwonClick).AddTo(mSubscriptions);
        OnClose.GuardSubscribeAsync(ClosePageBase).AddTo(mSubscriptions);
        OnComplete.GuardSubscribeAsync(OnGachaComplete).AddTo(mSubscriptions);


        _idelAnimator.gameObject.SetActive(true);
        _coinAnimator.gameObject.SetActive(false);
        //RefreshCoin();
        remainTimesTMP = remainTimesText.GetComponent<TextMeshProUGUI>();
        previousHelpButtonColor = helpButtonImg.color;
        previousBackButtonColor = backButton.color;
        previousBackButtonTextColor = backButtonText.color;
        previousRemainTimesTextColor = remainTimesTMP.color;

        //await UI.ScreenEffect.Fade(0);
        _rawImage.gameObject.SetActive(true);

        
    }

    private async UniTask OnGachaComplete()
    {
        //先关了这个界面，再看看有没有邀约后续可以触发
        //if (gachaParam == null)
        //{
        await UI.Page.CloseCurrentPage();
        Hide();
        //}
        if (gachaParam != null)
        {
            gachaParam.onFinish?.Invoke(gachaRewardsIdList[0]);
        }
        

    }

    public async UniTask ClosePageBase(GameObject o)
    {
        //if (IsCoin)
        //{
        //    tips.SetActive(true);
        //    t = 1.3f;
        //    systemTipsText.SetLabel(LocalizeManager.DATA_TYPE.GACHA, "Gacha_SystemTips_Title");
        //    tipsMesText.SetLabel(LocalizeManager.DATA_TYPE.GACHA, "Gacha_Explore_Slit2");
        //    return;
        //}
        if (gachaParam == null)
        {
            await UI.Page.CloseCurrentPage();
            Hide();
        }
        else
        {
            gachaParam.onCancel?.Invoke();
        }

    }

    private async UniTask ShowItemGet()
    {
        Dictionary<long, int> gachaItem = new Dictionary<long, int>();
        foreach (var item in gachaRewardsIdList)
        {
            gachaItem.Add(item, 1);
        }

        Dictionary<long, int> senarioItem = new Dictionary<long, int>();
        foreach (var item in senarioRewardsIdList)
        {
            senarioItem.Add(item, (int)_mGachaMachineResult.scenarioRewards[item]);
        }

        var popup = await UI.Popup.ShowItemGetPopupAsync(gachaItem);

        await UniTask.WaitUntil(() => popup == null);


        OnComplete.Invoke();

        //var gachaRewardsCount = DataManager.Instance.Player.Item.GetCount(gachaRewardsIdList[0]);
        //Debug.Log("gacha reward cnt: " + gachaRewardsCount);

        //null说明不是从邀约来的
        if (gachaParam == null && _mGachaMachineResult.scenarioId != "")
        {
            var scriptName = _mGachaMachineResult.scenarioId;
            ScenarioScript script = await ResourceManager.Instance.LoadLocalizeAssetAsync<ScenarioScript>("Scenario/" + scriptName);

            ScriptEngine.GetInstance().LoadScript(scriptName, script);


            await UI.Page.ChangePage<UIAdvPrivateTalkPage>();

            var players = Resources.FindObjectsOfTypeAll(typeof(Map.Player)) as Map.Player[];
            Debug.Log("players length: " + players.Length);

            List<Map.Player> player = new List<Map.Player>();

            foreach (var item in players)
            {
                if (item.gameObject.activeSelf == true)
                {
                    player.Add(item);
                }
            }

            Debug.Log(" active players length: " + player.Count);

            List<GameObject> sceneCharacters = new List<GameObject>();

            foreach (Transform child in player[0].transform.parent)
            {
                Debug.Log(child.gameObject.name);
                if (child.GetComponent<Map.MiniCharacter3D>() && child.gameObject.activeSelf == true && !child.GetComponent<Map.Player>())
                {
                     sceneCharacters.Add(child.gameObject);
                }
               
            }

            var follows = Resources.FindObjectsOfTypeAll(typeof(Follow)) as Follow[];

            foreach (var item in follows)
            {
                sceneCharacters.Add(item.gameObject);
            }

            Debug.Log("chara length: " + sceneCharacters.Count);

            foreach (var item in sceneCharacters)
            {
                item.SetActive(false);
            }
            
            //}
            //else
            //{
            //    MapSceneManager.Instance.HideCurrent();
            //}

            ScriptEngine.GetInstance().SetStartScript(scriptName, null, async (s) =>
            {
                //await UI.ScreenEffect.Fade(0);
                if (senarioRewardsIdList.Count > 0)
                {
                    await UI.Popup.ShowItemGetPopupAsync(senarioItem);
                }

                foreach (var item in sceneCharacters)
                {
                    item.SetActive(true);
                }
            });
            
        }
    }

    private async UniTask HandleDwonClick()//开始扭蛋
    {
        candyeff1.gameObject.SetActive(false);
        candyeff2.gameObject.SetActive(false);
        candyeff3.gameObject.SetActive(false);
        if (times > 0)
        {
            IsSelect = true;
        }
        else
        {
            IsSelect = false;
        }
        if (IsRotate)
        {
            return;
        }
        if (IsSelect)
        {
            //lock close button
            closeBtn.SetLock(true);
            helpButton.SetLock(true);

            if (gachaParam == null)
            {
                //花次数，得奖品
                _mGachaMachineResult = await GachaService.GetGachaMachineResult(data.id);
            }
            //7是邀约扭蛋机
            else
            {
                _mGachaMachineResult = await GachaService.GetGachaMachineResult(7);
            }




            #region test data new version

            //var gacharwds = new Dictionary<long, long>();
            //gacharwds.Add(103002044, 1);
            //var senariorwds = new Dictionary<long, long>();
            //senariorwds.Add(103002047, 100);

            //_mGachaMachineResult = new UIGachaMachineResult()
            //{
            //    scenarioId = "Carmen_date_1-3",
            //    //scenarioId = "Twinkle_date_1_2",
            //    scenarioRewards = senariorwds,
            //    gachaRewards = gacharwds
            //};
            #endregion

            #region test data old version
            //_mGachaResultModel = new UIGachaResultModel()
            //{
            //    itemList = new List<UIGachaResultViewModel>() {
            //        new UIGachaResultViewModel(){
            //            id = 103002044,
            //            isConverted = true,
            //            converted= null,
            //            type = 3
            //        }
            //    }
            //};
            #endregion

            Debug.Log("scenarioid" + _mGachaMachineResult.scenarioId);

            gachaRewardsIdList = new List<long>();
            foreach (var key in _mGachaMachineResult.gachaRewards.Keys)
            {
                gachaRewardsIdList.Add(key);
            }

            senarioRewardsIdList = new List<long>();
            foreach (var key in _mGachaMachineResult.scenarioRewards.Keys)
            {
                senarioRewardsIdList.Add(key);
            }

            //次数--
            times--;

            _idelAnimator.gameObject.SetActive(false);
            _rotateAnimator.gameObject.SetActive(true);
            _rotateAnimator.SetBool("isrotate", true);
            PxSoundManager.Instance.PlaySe("SE_Shakecandy", true);
            IsRotate = true;
            loopover.SetActive(true);
            loopover.GetComponent<ParticleSystem>().Play();

            remainTimesText.SetRawText("今日剩余" + times + "次");
        }
        //没次数，弹tips
        else
        {
            if (IsCandy)
            {
                return;
            }
            tips.SetActive(true);
            t = 1.3f;
            systemTipsText.SetLabel(LocalizeManager.DATA_TYPE.GACHA, "Gacha_SystemTips_Title");
            tipsMesText.SetLabel(LocalizeManager.DATA_TYPE.GACHA, "Gacha_Times_Out");
            
        }

    }

    private async UniTask HandleUpClcik()
    {

        item = DataManager.Instance.Master.Item[gachaRewardsIdList[0]];
        candy2.SetActive(false);
        candy1.SetActive(false);
        candy3.SetActive(false);
        switch (item.rarity)
        {
            case 2:
                candy3.SetActive(true);
                break;
            case 3:
                candy2.SetActive(true);
                break;
            case 4:
                candy1.SetActive(true);
                break;
            default:
                break;
        }
    }

    private void PlayEff()
    {
        IsEff = false;
        candyeff1.gameObject.SetActive(false);
        candyeff2.gameObject.SetActive(false);
        candyeff3.gameObject.SetActive(false);
        switch (item.rarity)
        {
            case 2:
                candyeff1.gameObject.SetActive(true);
                candyeff1.Play();
                break;
            case 3:
                candyeff2.gameObject.SetActive(true);
                candyeff2.Play();
                break;
            case 4:
                candyeff3.gameObject.SetActive(true);
                candyeff3.Play();
                break;
            default:
                break;
        }
    }

    //投币的
    //private async UniTask SlitClick(GameObject o)
    //{
    //    if (IsCandy)
    //    {
    //        return;
    //    }
    //    if (DataManager.Instance.Player.Item.GetCount(data.master.gachaContentId) <= 0)
    //    {
    //        tips.SetActive(true);
    //        t = 1.3f;
    //        systemTipsText.SetLabel(LocalizeManager.DATA_TYPE.GACHA, "Gacha_SystemTips_Title");
    //        tipsMesText.SetLabel(LocalizeManager.DATA_TYPE.GACHA, "Gacha_Explore_Item_Not");
    //        return;
    //    }

    //    if (IsCoin)
    //    {
    //        tips.SetActive(true);
    //        t = 1.3f;
    //        systemTipsText.SetLabel(LocalizeManager.DATA_TYPE.GACHA, "Gacha_SystemTips_Title");
    //        tipsMesText.SetLabel(LocalizeManager.DATA_TYPE.GACHA, "Gacha_Explore_Slit1");
    //        return;
    //    }
    //    else
    //    {
    //        await PlaySlitAnimation();

    //        IsCoin = true;
    //    }

    //}

    //public async UniTask PlaySlitAnimation() //投币方法
    //{
    //    if (_coinAnimator != null)
    //    {
    //        IsSelect = false;
    //        var time = 0f;

    //        PxSoundManager.Instance.PlaySe("SE_Eggcoin");
    //        _idelAnimator.gameObject.SetActive(false);
    //        _coinAnimator.gameObject.SetActive(true);
    //        await UniTask.Delay((int)(1000));
    //        IsEff = true;
    //        RefreshCoin(true);
    //    }
    //}

    private async Task PlayCandyAnimationAsync()//糖果动画
    {
        IsCandy = true;
        Base.Sound.SoundManager.GetInstance().StopAllSe();
        PxSoundManager.Instance.PlaySe("SE_Candy");
        loop.SetActive(false);
        loopover.SetActive(false);
        gameObject.transform.GetComponent<Animation>().Play("UIExploreGachaDialog");
        _idelAnimator.gameObject.SetActive(false);
        _candyAnimator.gameObject.SetActive(true);

    }


    public override void OnShow()
    {
        base.OnShow();
        closeBtn.SetLock(false);
        helpButton.SetLock(false);

    }

    public override void Dispose()
    {
        base.Dispose();
        if (loop)
        {
            loop.GetComponent<ParticleSystem>().Stop();
        }

        if (_mGachaResultModel != null)
        {
            _mGachaResultModel = null;
        }
        if (data != null)
        {
            data = null;
        }
    }
}