using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;


public class UIExploreGachaPage : UIPageBase
{
    private UIExploreGachaDialog _exploreGachaDialog = null;
    private UIGachaViewModel _gachaViewModel;
    UIGachaParam _gachaParam = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        //_gachaViewModel = param as UIGachaViewModel;

        if (param != null)
        {
            _gachaParam = param as UIGachaParam;
        }
        
        
        _exploreGachaDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIExploreGachaDialog, CanvasType.App0) as UIExploreGachaDialog;


        //_exploreGachaDialog.data = _gachaViewModel;
        _exploreGachaDialog.gachaParam = _gachaParam;

        //_exploreGachaDialog.OnClose.GuardSubscribeAsync(ClosePageBase).AddTo(mSubscriptions);
 
    }


    public async UniTask ClosePageBase(GameObject o)
    {
        await UI.Page.CloseCurrentPage();
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
        await _exploreGachaDialog.ShowAsync();
    }

    public override void Dispose()
    {
        base.Dispose();
        if (_exploreGachaDialog != null)
        {
            _exploreGachaDialog.Dispose();
            _exploreGachaDialog = null;
        }
    }
}

public class UIGachaParam
{
    public int id;
    public Action<long> onFinish;
    public Action onCancel;
}
