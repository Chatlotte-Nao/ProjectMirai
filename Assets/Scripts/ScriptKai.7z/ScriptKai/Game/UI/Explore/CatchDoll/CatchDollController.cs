﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using UnityEngine.Events;
using Cysharp.Threading.Tasks;
using System.Linq;
using UnityEngine.UI;

public class CatchDollController : MonoBehaviour
{
    public static CatchDollController instance;
    public RectTransform ClawResetPoint;
    public mState nowState;
    [SerializeField] AnimationClip animationClip;
    public void Init(CatchDollDataFormate catchDollDataFormate)
    {
        
    }
    private void Awake()
    {
        instance = this;
    }
    Rigidbody2D claw;
    private void Start()
    {
        claw = UICatchDollMainWindow.instance.claw;
        nowState = mState.idle;
    }
    public enum mState
    {
        idle,
        righting,
        righted,
        uping,
        cuting,
    }


    private void Update()
    {
        switch (nowState)
        {
            case mState.idle:
                UICatchDollMainWindow.instance.RightBtn.GetComponent<Image>().color = Color.green;
                UICatchDollMainWindow.instance.UpBtn.GetComponent<Image>().color = Color.black;
                claw.velocity = Vector2.zero;

                break;
            case mState.righting:

                UICatchDollMainWindow.instance.RightBtn.GetComponent<Image>().color = Color.green;
                UICatchDollMainWindow.instance.UpBtn.GetComponent<Image>().color = Color.black;
                break;
            case mState.righted:

                UICatchDollMainWindow.instance.RightBtn.GetComponent<Image>().color = Color.black;
                UICatchDollMainWindow.instance.UpBtn.GetComponent<Image>().color = Color.green;
                break;
            case mState.uping:

                UICatchDollMainWindow.instance.RightBtn.GetComponent<Image>().color = Color.black;
                UICatchDollMainWindow.instance.UpBtn.GetComponent<Image>().color = Color.green;
                break;
            case mState.cuting:

                UICatchDollMainWindow.instance.RightBtn.GetComponent<Image>().color = Color.black;
                UICatchDollMainWindow.instance.UpBtn.GetComponent<Image>().color = Color.black;

                break;
            default:
                break;
        }
    }


    public void RightBtnDown(Vector2 vector2)
    {
        if (nowState == mState.idle)
        {
            nowState = mState.righting;
            claw.velocity = new Vector2(10,0)*10;
        }
    }
    public void RightBtnUp(Vector2 vector2)
    {
        if (nowState == mState.righting)
        {
            claw.velocity = Vector2.zero;
            nowState = mState.righted;
        }

    }
    public void UpBtnDown(Vector2 vector2)
    {
        if (nowState == mState.righted)
        {

            nowState = mState.uping;
            claw.velocity = new Vector2(0,10) * 10;
        }


    }
    async public void UpBtnUp(Vector2 vector2)
    {
        if (nowState == mState.uping)
        {
            nowState = mState.cuting;
            claw.velocity = Vector2.zero;
            await UniTask.Delay(1000);
            if (Succ)
            {
                Debug.Log(Succ);
                DollController.instance.DollDrop();
            }
            else
            {
                Debug.Log("fa");
            }
            var animation = UICatchDollMainWindow.instance.GetComponent<Animation>();
            var CutAnimationClip = UICatchDollMainWindow.instance.CutAnimation;
            await UIAnimationPlayer.PlayAsync(animation, CutAnimationClip);
            await UniTask.Delay(1000);
            nowState = mState.idle;
            ClawController.instance.MoveBack2StratPoint();
        }

    }
    public bool Succ;






}