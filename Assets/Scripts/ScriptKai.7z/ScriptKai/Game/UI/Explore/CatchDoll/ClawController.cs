﻿using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClawController : MonoBehaviour
{
    public static ClawController instance;
    private void Awake()
    {
        instance = this;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "ReturnArea")
        {
            Debug.Log("ReturnFail");
            CatchDollController.instance.nowState = CatchDollController.mState.idle;

            Tween tween = DOTween.To(() => GetComponent<RectTransform>().position, x => GetComponent<RectTransform>().position = x, CatchDollController.instance.ClawResetPoint.position, 1f);

        }
    }


    public bool trigered = false;
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (trigered)
            return;
        if (collision.gameObject.name == "DollCutArea" && CatchDollController.instance.nowState == CatchDollController.mState.cuting)
        {
            CatchDollController.instance.Succ = true;
            Debug.Log("ttttttttt");
        }
    }


    public void MoveBack2StratPoint()
    {
        Tween tween = DOTween.To(() => GetComponent<RectTransform>().position, x => GetComponent<RectTransform>().position = x, CatchDollController.instance.ClawResetPoint.position, 1f);
        tween.onComplete += () =>
        {
            trigered = false;
            CatchDollController.instance.Succ = false;
        };
    }
}
