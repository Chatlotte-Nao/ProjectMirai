﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DollController : MonoBehaviour
{
    public static DollController instance;

    [SerializeField] GameObject DollObj;

    Rigidbody2D DollRig;
    Image DollImage;
    private void Awake()
    {
        instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        DollRig = DollObj.GetComponent<Rigidbody2D>();
        DollImage = DollObj.GetComponent<Image>();
    }

    public void DollDrop()
    {
        DollRig.velocity = Vector2.down * 20f;
    }
    public void SetDollImage(Sprite sprite)
    {
        DollImage.sprite = sprite;
    }
}
