﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using UnityEngine.Events;
using Cysharp.Threading.Tasks;
using System.Linq;
using DG.Tweening;
using UnityEngine.UI;

public class UICatchDollMainWindow : UIDialogBase
{
    public static UICatchDollMainWindow instance;
    public UnityEvent OnComplete =new UnityEvent();
    CatchDollDataFormate dataFormate = new CatchDollDataFormate();
    [SerializeField] UIButton skipButton;
    public UnityEvent OnCancel => skipButton.OnTouchUpInside;
    
    

    public CatchDollController catchDollController;
    [SerializeField] RectTransform GameOverHintPanel;
    public UIButton RightBtn;
    public UIButton UpBtn;
    public  Rigidbody2D claw;
    public AnimationClip CutAnimation;
    //public float speed = 2f;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        RightBtn.onClickDown.AddListener(catchDollController.RightBtnDown);
        RightBtn.onClickUp.AddListener(catchDollController.RightBtnUp);
        UpBtn.onClickDown.AddListener(catchDollController.UpBtnDown);
        UpBtn.onClickUp.AddListener(catchDollController.UpBtnUp);
    }
    public async UniTask Setup(int mlevelID)
    {
        SetData(mlevelID);

    }


    private void SetData(int mlevelID)
    {
        var masters = DataManager.Instance.Master.CatchDoll.Values;

        var t = masters.First(x => x.levelID == mlevelID);
        dataFormate = CatchDollDataFormate.Master2Formate(t);

    }

    protected override void Awake()
    {
        base.Awake();
        instance = this;

    }
    public void GameOver()
    {
        ShowGameOverHintPanel();
    }

    private void ShowGameOverHintPanel()
    {
        GameOverHintPanel.gameObject.SetActive(true);
        //var objPostion = GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position;
        Tween tween = DOTween.To(() => GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position, x => GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position = x, Vector3.zero, 0.2f);

        GameOverHintPanel.GetComponent<UIButton>().onClick.AddListener((o) =>
        {
            Tween tween2 = DOTween.To(() => GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position, x => GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position = x, new Vector3(0, 500, 0), 0.2f);
            tween2.onComplete += () =>
            {
                OnComplete.Invoke();
            };
        });
        //throw new NotImplementedException();
    }
}



public class CatchDollDataFormate
{









    public static CatchDollDataFormate Master2Formate(CatchDollMaster master)
    {

        CatchDollDataFormate formate = new CatchDollDataFormate();




        return formate;
    }


}