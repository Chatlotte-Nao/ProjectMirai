﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIExploreEventListDialog : UIDialogBase
{
    [SerializeField] UIExploreEventCell listBaseCell;
    [SerializeField] UIText titleText;
    [SerializeField] UIText descText;
    [SerializeField] GameObject conditionGroup;
    [SerializeField] UIText[] conditionText;
    [SerializeField] UIExploreEventAdvCell advBaseCell;
    [SerializeField] UITexture[] charaIcon;
    [SerializeField] UIText costText;
    [SerializeField] UIButton startButton;
    [SerializeField] UIButton giveupButton;
    [SerializeField] UIButton continueButton;
    [SerializeField] UIButton upButton;
    [SerializeField] UIButton downButton;
    [SerializeField] ScrollRect eventScroll;

    [SerializeField] private UIText rewardTitleText;
    [SerializeField] private BaseItem rewardItem;
    [SerializeField] private RectTransform rewardTransform;
    public UnityEvent OnClickGiveup => giveupButton.OnTouchUpInside;


    private float srcollvalue;
    ExploreEventViewModel mOngoingEvent = null;
    Dictionary<long, UIExploreEventCell> mItems = new Dictionary<long, UIExploreEventCell>();
    List<UIExploreEventAdvCell> mAdvCells = new List<UIExploreEventAdvCell>();
    private List<BaseItem> items = new List<BaseItem>();
    private long mCurrentId = 0;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        upButton.OnTouchDown.Subscribe(upButtonOnclick).AddTo(mSubscriptions);
        downButton.OnTouchDown.Subscribe(downButtonOnclick).AddTo(mSubscriptions);
        var data = DataManager.Instance.Local.Explore.playerData;
    

        foreach (var item in data.eventList)
        {
            var model = item.Value;
            var newItemObj = Instantiate(listBaseCell.gameObject, listBaseCell.transform.position, listBaseCell.transform.rotation, listBaseCell.transform.parent);
            

            var cell = newItemObj.GetComponent<UIExploreEventCell>();
            cell.Setup(item.Value);
            cell.OnClick.Subscribe(onClickListCell).AddTo(mSubscriptions);
            cell.OnClickFav.GuardSubscribeAsync(async(v)=>
            {
                await onClickEventFav(cell.Model.masterId, v);
            }).AddTo(mSubscriptions);

            mItems.Add(item.Key, cell);

            newItemObj.SetActive(true);
            
        }

        sortList();


        srcollvalue = 1.0f / (data.eventList.Count - 1);
        startButton.OnTouchUpInside.GuardSubscribeAsync(onClickStart).AddTo(mSubscriptions);
        continueButton.OnTouchUpInside.GuardSubscribeAsync(onClickContinue).AddTo(mSubscriptions);
        giveupButton.OnTouchUpInside.GuardSubscribeAsync(OnClickGiveUp).AddTo(mSubscriptions);
        
        SignalBus.GlobalSignal.Subscribe<long>(UIEventId.ExploreEventFinish, OnEventFinish).AddTo(mSubscriptions);
    }

    void upButtonOnclick()
    {
        var targetPos = eventScroll.verticalNormalizedPosition + srcollvalue;
        eventScroll.verticalNormalizedPosition = targetPos > 1 ? 1:targetPos;

    }
    void downButtonOnclick()
    {
        var targetPos = eventScroll.verticalNormalizedPosition - srcollvalue;
        eventScroll.verticalNormalizedPosition = targetPos < 0 ? 0 : targetPos;
    }
    public void Setup(ExploreEventViewModel ongoingEvent)
    {
        mOngoingEvent = ongoingEvent;
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
    }

    private void onClickListCell(GameObject o)
    {
        var cell = o.GetComponent<UIExploreEventCell>();
        if (cell.Model.masterId != mCurrentId && mCurrentId > 0)
        {
            mItems[mCurrentId].Select(false);
        }
        mCurrentId = cell.Model.masterId;
        cell.Select(true);

        showDetail(cell.Model);
    }

    private async UniTask onClickEventFav(long eventId, bool val)
    {
        await ExploreService.SetEventLike(eventId, val);
        sortList();
    }


    private void showDetail(ExploreEventViewModel eventdata)
    {
        mCurrentId = eventdata.masterId;
        titleText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{eventdata.masterId}_title");
        descText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{eventdata.masterId}_desc");
        costText.SetRawText(eventdata.Master.energyCost.ToString());

        bool canStart = eventdata.CanStart();

        if (canStart)
        {
            conditionGroup.SetActive(false);
        }
        else
        {
            conditionGroup.SetActive(true);
            for (int i = 0; i < conditionText.Length; i++)
            {
                if (i>=eventdata.Master.startCondition.Count)
                {
                    conditionText[i].gameObject.SetActive(false);
                }
                else
                {
                    conditionText[i].gameObject.SetActive(true);
                    var s = eventdata.Master.startCondition[i].Split(':');
                    int type = int.Parse(s[0]);

                    switch (type)
                    {
                        case 3:
                            // 完成{0}{1}次
                            var request =
                                LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.REQUEST, $"{s[1]}_title");
                            conditionText[i].SetFormat(LocalizeManager.DATA_TYPE.EXPLORE, "Condition_3_Format", request,
                                s[2]);
                            var explore = DataManager.Instance.Local.Explore.playerData.eventList.Values
                                .FirstOrDefault(a => a.masterId == long.Parse(s[1]));
                            if (explore == null || explore.finishCount == 0)
                            {
                                // canStart = false;
                            }

                            break;
                        case 6:
                        // 完成主线关卡{0}
                            var chapterName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{s[1]}_name");
                            int chapterNum = DataManager.Instance.Master.Chapter[int.Parse(s[1])].chapter;
                            conditionText[i].SetFormat(LocalizeManager.DATA_TYPE.EXPLORE, "Condition_6_Format", chapterNum, chapterName);
                            if (!StoryUtil.IsClear(int.Parse(s[1])))
                            {
                                // conditionText[i].SetColor(Color.red);
                            }
                            break;
                        default:
                            conditionText[i].SetRawText(string.Empty);
                            break;
                    }
                    
                }
            }
        }

        

        int advIndex = 0;
        for (advIndex = 0; advIndex < eventdata.Master.informationAdvId.Count; advIndex++)
        {
            if (advIndex >= mAdvCells.Count)
            {
                var newItemObj = Instantiate(advBaseCell.gameObject, advBaseCell.transform.position, advBaseCell.transform.rotation, advBaseCell.transform.parent);
                newItemObj.SetActive(true);

                var cell = newItemObj.GetComponent<UIExploreEventAdvCell>();
                cell.Setup(eventdata.Master.informationAdvId[advIndex], !eventdata.finishedHistory.Contains(eventdata.Master.informationAdvId[advIndex]));
                mAdvCells.Add(cell);
            }
            else
            {
                mAdvCells[advIndex].Setup(eventdata.Master.informationAdvId[advIndex], !eventdata.finishedHistory.Contains(eventdata.Master.informationAdvId[advIndex]));
                mAdvCells[advIndex].gameObject.SetActive(true);
            }
        }

        while (advIndex < mAdvCells.Count)
        {
            mAdvCells[advIndex++].gameObject.SetActive(false);
        }

        for (int i = 0; i < charaIcon.Length; i++)
        {
            if (i < eventdata.Master.displayCharacter.Count)
            {
                charaIcon[i].gameObject.SetActive(true);
                charaIcon[i].Load("CharacterIcon", DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[eventdata.Master.displayCharacter[i]].characterResourceId].exploreCharacterIcon);
            }
            else
            {
                charaIcon[i].gameObject.SetActive(false);
            }
        }



        if (mOngoingEvent != null)
        {
            giveupButton.gameObject.SetActive(mOngoingEvent == eventdata);
            startButton.gameObject.SetActive(false);
            continueButton.gameObject.SetActive(false);
        }
        else
        {
            
            if (eventdata.eventStatus == ExploreEventViewModel.EventStatus.Accepted || eventdata.eventStatus == ExploreEventViewModel.EventStatus.Finished)
            {
                continueButton.gameObject.SetActive(true);
                startButton.gameObject.SetActive(false);
                giveupButton.gameObject.SetActive(true);
            }
            else
            {
                continueButton.gameObject.SetActive(false);
                startButton.gameObject.SetActive(canStart);
                giveupButton.gameObject.SetActive(false);
            }
        }

        LoadRewards(eventdata);
    }

    private void LoadRewards(ExploreEventViewModel eventdata)
    {
        foreach (var item in items)
        {
            item.gameObject.SetActive(false);
        }

        List<string> rewards = new List<string>();
        if (eventdata.finishCount == 0)
        {
            rewardTitleText.SetLabel(LocalizeManager.DATA_TYPE.EXPLORE, "Event_Label_First_Reward");
            rewards.AddRange(eventdata.Master.firstTimeRewards);
            rewards.AddRange(eventdata.Master.rewards);
        }
        else
        {
            rewardTitleText.SetLabel(LocalizeManager.DATA_TYPE.EXPLORE, "Event_Label_Reward");
            rewards.AddRange(eventdata.Master.rewards);
        }

        int index = 0;
        foreach (var reward in rewards)
        {
            var s = reward.Split(':');
            long itemId = 0;
            string itemNum = string.Empty;
            if (s.Length > 1)
            {
                itemId = long.Parse(s[0]);
                itemNum = s[1];
            }
            else
            {
                itemId =  long.Parse(reward);
            }
            if (index < items.Count)
            {
                items[index].Setup(itemId, itemNum);
                items[index].gameObject.SetActive(true);
            }
            else
            {
                var button = Instantiate(rewardItem, rewardTransform, false);
                //button.transform.localScale = new Vector3(0.5f, 0.5f, 1f);
                button.Setup(itemId, itemNum);
                button.gameObject.SetActive(true);
                items.Add(button);
            }

            index++;

        }
    }

    private async UniTask onClickStart()
    {
        if (mCurrentId == 0)
        {
            return;
        }
        if (DataManager.Instance.Local.Explore.processingEventId > 0 && DataManager.Instance.Local.Explore.processingEventId != mCurrentId)
        {
            UI.Popup.ShowConfirm(string.Empty, string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "Error_OtherEventProcessing"), LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER_NAME, DataManager.Instance.Local.Explore.GetProcessingEvent().Master.battleCharacterMasterId.ToString())), CanvasType.App2, onStartConfirmGiveup);
            return;
        }


        await ExploreService.StartEvent(mCurrentId);
        
        await HideAsync();

        //await UI.ScreenEffect.Fade(1);

        ExploreSceneParam p = new ExploreSceneParam();
        p.mapName = DataManager.Instance.Master.ExploreEvent[mCurrentId].initialMap;
        p.startRoute = DataManager.Instance.Master.ExploreEvent[mCurrentId].initialLocation;

        await GameSceneManager.Instance.ChangeSceneAsync<ExploreScene>("ExploreScene", p);
        
        // await MapSceneManager.Instance.ChangeAsync(DataManager.Instance.Master.Location[DataManager.Instance.Master.ExploreEvent[mCurrentId].initialMap].scene, DataManager.Instance.Master.ExploreEvent[mCurrentId].initialLocation);
    }


    private void onStartConfirmGiveup(UIPopupDialog.Result result)
    {
        if (result == UIPopupDialog.Result.OK)
        {
            AsyncManager.Instance.StartGuardAsync(OnClickGiveUp());
        }
    }

    private async UniTask onClickContinue()
    {
        if (mCurrentId == 0)
        {
            return;
        }

        await HideAsync();

        //await UI.ScreenEffect.Fade(1);

        var model = DataManager.Instance.Local.Explore.playerData.eventList[mCurrentId];

        if (model.eventStatus == ExploreEventViewModel.EventStatus.Finished)
        {
            //之前完成了但没有发送完成消息
            await ExploreService.FinishEvent(mCurrentId);
            await UI.Page.OpenPage<UIExploreEventResultPage>(model);
            SignalBus.GlobalSignal.Dispatch(UIEventId.ExploreEventFinish, model.masterId);
            return;
        }
        else
        {
            model.eventStatus = ExploreEventViewModel.EventStatus.Accepted;
        }


        var mapId = DataManager.Instance.Master.ExploreEvent[mCurrentId].initialMap;
        var initialRoute = DataManager.Instance.Master.ExploreEvent[mCurrentId].initialLocation;
        foreach (var item in model.finishedAdv)
        {
            var master = DataManager.Instance.Master.ExploreAdv[item];
            if (!string.IsNullOrEmpty(master.afterLocationLabel))
            {
                mapId = master.afterLocationLabel;
                initialRoute = master.afterRouteName;
            }
        }
        ExploreSceneParam p = new ExploreSceneParam();
        p.mapName = mapId;
        p.startRoute = initialRoute;

        await GameSceneManager.Instance.ChangeSceneAsync<ExploreScene>("ExploreScene", p);
        // await MapSceneManager.Instance.ChangeAsync(DataManager.Instance.Master.Location[mapId].scene, initialRoute);
    }

    private async UniTask OnClickGiveUp()
    {
        if (mCurrentId == 0)
        {
            return;
        }

        var ev = DataManager.Instance.Local.Explore.GetProcessingEvent();

        await ExploreService.FinishEvent(ev.masterId);
        await HideAsync();
        await UI.Page.OpenPage<UIExploreEventResultPage>(ev);
        SignalBus.GlobalSignal.Dispatch(UIEventId.ExploreEventFinish, ev.masterId);
    }

    private void OnEventFinish(long eventId)
    {
        if (mOngoingEvent != null && mOngoingEvent.masterId == eventId)
        {
            mOngoingEvent = null;
        }

        var data = DataManager.Instance.Local.Explore.playerData;
        
        if (data.eventList.ContainsKey(eventId))
        {
            mItems[eventId].Setup(data.eventList[eventId]);
        }
        else
        {
            Destroy(mItems[eventId].gameObject);
            mItems.Remove(eventId);
        }

        sortList();
    }

    private void sortList()
    {
        var data = DataManager.Instance.Local.Explore.playerData;
        var sortedList = new List<ExploreEventViewModel>(data.eventList.Values);
        sortedList.Sort((x,y)=>{
            if (x.eventStatus != y.eventStatus)
            {
                return  y.eventStatus.CompareTo(x.eventStatus);
            }

            if (x.fav != y.fav)
            {
                return y.fav.CompareTo(x.fav);
            }
            else if (x.finishCount == 0 || y.finishCount == 0)
            {
                return x.finishCount.CompareTo(y.finishCount);
            }
            else
            {
                return x.masterId.CompareTo(y.masterId);
            }
        });
       
        for (int i = 0; i < sortedList.Count; i++)
        {
            mItems[sortedList[i].masterId].transform.SetSiblingIndex(i);
            mItems[sortedList[i].masterId].RefreshNewState();
            mItems[sortedList[i].masterId].gameObject.SetActive(true);
            if (i == 0 || sortedList[i].eventStatus == ExploreEventViewModel.EventStatus.Accepted)
            {
                onClickListCell(mItems[sortedList[i].masterId].gameObject);
            }
        }
        if (currentCharacterId != 0)
        {
            var list = new List<ExploreEventViewModel>();
            foreach (var item in sortedList)
            {
                if (item.Master.battleCharacterMasterId == currentCharacterId)
                {
                    list.Add(item);
                }
                
            }
           
            for (int i = 0; i < sortedList.Count; i++)
            {

                bool hasCell = false;
                for (int j = 0; j < list.Count; j++)
                {

                    if (list[j].masterId == sortedList[i].masterId)
                    {
                        hasCell = true;
                        break;
                    }

                }
                if (!hasCell)
                {
                    mItems[sortedList[i].masterId].gameObject.SetActive(false);

                }
              


            }
            for (int i = 0; i < list.Count; i++)
            {
                //mItems[list[i].masterId].transform.SetSiblingIndex(i);
                if (i == 0 || list[i].eventStatus == ExploreEventViewModel.EventStatus.Accepted)
                {
                    onClickListCell(mItems[list[i].masterId].gameObject);
                }
            }

        }
    }

    long currentCharacterId = 0;
    public void RefreshList(long characterId = 0)
    {
        currentCharacterId = characterId;
        sortList();
    }

}
