using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIExploreItemCell : MonoBehaviour
{
    [SerializeField] private RectTransform _gameObject;
    [SerializeField] private UIText nameText;
    [SerializeField] private Image iconImage;
    [SerializeField] private UIText numberText;
    public ClickEvent OnClose = new ClickEvent();

    public async UniTask SetUpAsync(string reward)
    {
        var str = reward.Split(':');
        long itemId = long.Parse(str[0]);
        iconImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("ItemIcon",itemId.ToString() );
        numberText.SetRawText(str[1]);
        nameText.SetRawText(reward);
        nameText.SetLabel(LocalizeManager.DATA_TYPE.ITEM, $"{itemId}_name");
        await CloseWait();
    }

    public async UniTask CloseWait()
    {
        _gameObject.transform.DOLocalMove(new Vector3(0, 0, 0), 0.5f);
        await UniTask.DelayFrame(100);
        _gameObject.anchoredPosition = new Vector2(-360, 0);
        OnClose.Invoke(this.gameObject);
    }
   
}
