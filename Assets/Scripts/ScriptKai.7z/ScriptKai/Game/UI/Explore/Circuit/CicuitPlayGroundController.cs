﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CicuitPlayGroundController : MonoBehaviour
{
    CircuitDataFormate data = new CircuitDataFormate();
    [SerializeField] GameObject EndPoint;
    [SerializeField] GameObject StartPoint;
    [SerializeField] GameObject StopBlock;
    public Dictionary<GameObject, bool> LigtingEndObjDic=new Dictionary<GameObject, bool>();


    public static CicuitPlayGroundController insatnce;

    private void Awake()
    {
        insatnce = this;
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.G))
        {
            foreach (var item in LigtingEndObjDic)
            {
                Debug.Log(item.Key.name + " " + item.Value);
            }
        }
    }

    public void Init(CircuitDataFormate data)
    {
        this.data = data;
    }
    // Start is called before the first frame update
    void Start()
    {
        //SetEndPoints();
    }








}
