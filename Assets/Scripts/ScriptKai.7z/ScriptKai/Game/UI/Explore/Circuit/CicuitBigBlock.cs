﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CicuitBigBlock : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {
        var lps = transform.GetChild(1);
        for (int i = 0; i < lps.childCount; i++)
        {
            LinkPoints.Add(lps.GetChild(i).gameObject);
        }
    }

    // Update is called once per frame
    void Update()
    {
        LightingCheck();
        Moving = transform.parent.parent.GetComponent<CicuitDragBlock1>().Moving;
    }
    bool Moving;
    public bool lighting = false;
    public bool ConnectingSun = false;
    public int lightFromIndex = 99;
    public List<GameObject> LinkPoints;
    public GameObject lightGroup;
    public GameObject darkGroup;
    async void LightingCheck()
    {
        if (Moving || CicuitBlockGroupController.instance.hasBlockMoving) return;
        lightGroup.SetActive(false);
        darkGroup.SetActive(true);
        for (int i = 0; i < LinkPoints.Count; i++)
        {
            if (LinkPoints[i].activeSelf == false) continue;
            var hit2D = Physics2D.OverlapCircleAll(LinkPoints[i].GetComponent<RectTransform>().position, 1f, LayerMask.GetMask("UI"));
            foreach (var item2 in hit2D)
            {
                if (item2.tag == "Player")
                {
                    lighting = true;
                    lightGroup.SetActive(true);
                    darkGroup.SetActive(false);
                    LinkPointsInit(i);
                    return;

                }
                if (item2.tag == "EditorOnly")
                {
                    if (item2.transform.parent.GetComponent<CicuitBigBlock>().lighting == true)
                    {

                        lighting = true;
                        lightGroup.SetActive(true);
                        darkGroup.SetActive(false);
                        LinkPointsInit(i);

                        return;
                    }
                }
            }
        }

        lighting = false;
    }

    void LinkPointsInit(int index = -1)
    {
        if (index == -1)
        {
            foreach (var item in LinkPoints)
            {
                item.SetActive(true);
            }
        }
        else
        {
            for (int i = 0; i < LinkPoints.Count; i++)
            {
                if (i == index) continue;
                LinkPoints[i].SetActive(false);
            }
        }
    }



    float raidos = 5f;

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(GetComponent<RectTransform>().position, raidos);
        foreach (var item in LinkPoints)
        {

            Gizmos.DrawWireSphere(item.GetComponent<RectTransform>().position, 1f);
        }
    }
    public bool TestCanPutDown = true;
}
