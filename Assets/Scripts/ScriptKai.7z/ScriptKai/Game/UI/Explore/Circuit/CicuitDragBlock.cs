﻿using Pheonix.Core;
using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;
//using
using UnityEngine.EventSystems;
using UnityEngine.UI;
using DG.Tweening;
using UnityEditor;

public class CicuitDragBlock : MonoBehaviour,IBeginDragHandler,IEndDragHandler,IDragHandler
{
    [SerializeField] UIButton rotateBtn;
    [SerializeField] UIButton mainImageBtn;
    [SerializeField] Image mainImage;

    [SerializeField] GameObject BigBlock;

    public GameObject obj;
    public bool Moving = false;

    public string mainImagedir = "up";
    bool isShowingRotateBtn = false;
    //private bool avatarLock;
    //private bool scrollLock;
    private Vector2 beginDragPosition;
    [SerializeField] private int threshold = 30;
    [SerializeField] private int thresholdXdivisionY = 2;
    [SerializeField] Transform putDownCheckColliderGroup;
    [SerializeField] List<RectTransform> putDownCheckColliderList;


    public List<GameObject> BigBlockList = new List<GameObject>();


    public void OnBeginDrag(PointerEventData eventData)
    {
        CicuitBlockGroupController.instance.scrollRect.OnBeginDrag(eventData);
        beginDragPosition = eventData.position;
        return;
    }

    void ShowBigBlock()
    {
        if (BigBlock.activeSelf) return;
        BigBlock.SetActive(true);
        transform.SetParent(CicuitBlockGroupController.instance.CicuitBlockOutSideGroup.transform);
        transform.localPosition = Vector3.zero;
    }



    public void OnDrag(PointerEventData eventData)
    {

        if (Moving||BigBlock.activeSelf)
        {
            ShowBigBlock();
            Moving = true;
            CicuitBlockGroupController.instance.hasBlockMoving = Moving;
            var rt = BigBlock.GetComponent<RectTransform>();
            Vector3 globalMousePos;
            if (RectTransformUtility.ScreenPointToWorldPointInRectangle(rt, eventData.position,
                eventData.pressEventCamera, out globalMousePos))
            {
                rt.position = globalMousePos;
            }
            foreach (var item in LinkPoints)
            {
                item.SetActive(true);
            }
            //Debug.Log(BigBlock.GetComponent<RectTransform>().position+"!");
            return;
        }
        //scrollLock = true;
        //avatarLock = false;

        Moving = true;
        CicuitBlockGroupController.instance.hasBlockMoving = Moving;

        #region  能拖
        //if (avatarLock && scrollLock)
        //{
        //    var delta = eventData.position - beginDragPosition;
        //    if (delta.SqrMagnitude() > threshold)
        //    {
        //        if (delta.y == 0)
        //        {
        //            scrollLock = false;
        //            avatarLock = true;
        //            Debug.Log("a");
        //            Moving = false;
        //            //return;
        //        }
        //        else if (Mathf.Abs(delta.x / delta.y) > thresholdXdivisionY)
        //        {
        //            scrollLock = false;
        //            Moving = false;
        //            avatarLock = true;
        //            Debug.Log("b");

        //            //return;

        //            //List.findlast()
        //        }
        //        else
        //        {
        //            scrollLock = true;
        //            avatarLock = false;
        //            Debug.Log("c");

        //            Moving = true;
        //            CicuitBlockGroupController.instance.hasBlockMoving = Moving;

        //            //ShowBigBlock();

        //        }
        //    }

        //}

        #endregion


    }






    async public void OnEndDrag(PointerEventData eventData)
    {
        GameObject Node = null;
        if (PutDownAble(out Node))//TODO判断是否能放下
        {
            var rt = BigBlock.GetComponent<RectTransform>();
            Vector3 globalMousePos;
            if (RectTransformUtility.ScreenPointToWorldPointInRectangle(rt, eventData.position,
                eventData.pressEventCamera, out globalMousePos))
            {

                Vector3 IntPoint = new Vector3(SnapValue((int)globalMousePos.x), SnapValue((int)globalMousePos.y), 1.5f);
                rt.position = IntPoint;
            }
            rt.position = Node.GetComponent<RectTransform>().position;
        }
        else
        {
            transform.SetParent(CicuitBlockGroupController.instance.transform);
            var tween=BigBlock.GetComponent<RectTransform>().DOMove(mainImage.GetComponent<RectTransform>().position, 0.5f);
            tween.SetEase(Ease.OutCubic);
            tween.onComplete += () =>
            {
                BigBlock.SetActive(false);
                mainImage.enabled = true;
            };


        }

        Moving = false;
        CicuitBlockGroupController.instance.hasBlockMoving = Moving;
        LightingCheck();

    }

    private void Update()
    {

        LightingCheck();


        if (Input.GetKeyDown(KeyCode.G))
        {
            TestCanPutDown = !TestCanPutDown;
        }
    }
    public  List<GameObject> LinkPoints=new List<GameObject>();

    public bool lighting = false;
    public bool ConnectingSun = false;
    public int lightFromIndex = 99;
    async void LightingCheck()
    {
        if (Moving|| CicuitBlockGroupController.instance.hasBlockMoving) return;
        BigBlock.GetComponent<CanvasGroup>().alpha = 0.3f;
        for (int i = 0; i < LinkPoints.Count; i++)
        {
            if (LinkPoints[i].activeSelf == false) continue;
            var hit2D = Physics2D.OverlapCircleAll(LinkPoints[i].GetComponent<RectTransform>().position, 1f, targetLayer);
            foreach (var item2 in hit2D)
            {
                if (item2.tag == "Player")
                {
                    lighting = true;
                    BigBlock.GetComponent<CanvasGroup>().alpha = 1f;
                    //LinkPoints[i].gameObject.SetActive(false);
                    LinkPointsInit(i);
                    return;

                }
                if (item2.tag == "EditorOnly")
                {
                    if (item2.transform.parent.parent.GetComponent<CicuitDragBlock>().lighting == true)
                    {

                        lighting = true;
                        BigBlock.GetComponent<CanvasGroup>().alpha = 1f;
                        //LinkPoints[i].gameObject.SetActive(false);
                        LinkPointsInit(i);

                        return;
                    }
                }
            }
        }

        lighting = false;
        //throw new NotImplementedException();
    }

    void LinkPointsInit(int index = -1)
    {
        if (index == -1)
        {
            foreach (var item in LinkPoints)
            {
                item.SetActive(true);
            }
        }
        else
        {
            for (int i = 0; i < LinkPoints.Count; i++)
            {
                if (i == index) continue;
                LinkPoints[i].SetActive(false);
            }
        }
    }


    int SnapValue(int num)
    {
        return num;
    }

    float raidos = 5f;

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(BigBlock.GetComponent<RectTransform>().position, raidos);
        foreach (var item in LinkPoints)
        {

            Gizmos.DrawWireSphere(item.GetComponent<RectTransform>().position, 1f);
        }


    }
    public bool TestCanPutDown = true;
    public LayerMask targetLayer;
    //ref out
    private bool PutDownAble(out GameObject NodePoint)
    {
        bool result = true;

        NodePoint = null;
        foreach (var item2 in putDownCheckColliderList)
        {
            var hit2D2 = Physics2D.OverlapCircleAll(item2.GetComponent<RectTransform>().position, raidos, targetLayer);

            int temp = 0;
            foreach (var item in hit2D2)
            {
                if (item.name.Contains("Check"))
                {
                    temp++;
                }
                if (temp >= 2) return false;
            }
        }
        var hit2D = Physics2D.OverlapCircleAll(BigBlock.GetComponent<RectTransform>().position, raidos, targetLayer);
        foreach (var item in hit2D)
        {
            if (item.tag == "Finish")
            {
                NodePoint = item.gameObject;
                return true;
            }
        }

        return false;
    }





    // Start is called before the first frame update
    void Start()
    {
        mainImageBtn.OnTouchUpInside.AddListener(RotateMainImage);
        obj = this.gameObject;
        for (int i = 0; i < putDownCheckColliderGroup.childCount; i++)
        {
            putDownCheckColliderList.Add(putDownCheckColliderGroup.GetChild(i).GetComponent<RectTransform>());
        }
    }

    private void RotateMainImage()
    {
        switch (mainImagedir)
        {
            case "up":
                mainImagedir = "left";
                mainImage.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 90f);//TODO 动画
                BigBlock.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 90f);//TODO 动画
                break;
            case "left":
                mainImagedir = "down";
                mainImage.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 180f);
                BigBlock.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 180f);

                break;

            case "down":
                mainImagedir = "right";
                mainImage.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 270f);
                BigBlock.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 270f);

                break;
            case "right":
                mainImagedir = "up";
                mainImage.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 360f);
                BigBlock.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 360f);

                break;
            default:
                break;
        }

    }


    private void ShowHideRotateBtn(GameObject arg0)
    {
        isShowingRotateBtn = !isShowingRotateBtn;
        rotateBtn.gameObject.SetActive(isShowingRotateBtn);//TODO 动画
        //throw new NotImplementedException();
    }



}
