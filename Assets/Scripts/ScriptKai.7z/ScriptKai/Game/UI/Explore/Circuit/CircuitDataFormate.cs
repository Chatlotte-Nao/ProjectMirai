﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CircuitDataFormate
{
    public int LevelID;
    public List<GameObject> CicuitBlockList=new List<GameObject>();
    public List<int> StopBlockPostionIndexList;
    public int StartPointIndex;
    public int EndPointIndex;
}
