﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CicuitNode : MonoBehaviour
{
    public bool CanPutDownBlock = true;
    public ConnectInfo mConnectInfo;
    



    public bool PutBlock(ConnectInfo connectInfo)
    {

        if (CanPutDownBlock)
        {

            SetConnectInfo(connectInfo);
            CanPutDownBlock = false;
            return true;
        }
        return false;
    }




    public void SetConnectInfo(ConnectInfo connectInfo)
    {
        mConnectInfo = connectInfo;
    }
}

public class ConnectInfo
{
    List<string> ConnectedList=new List<string>();
}
