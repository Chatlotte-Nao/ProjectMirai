﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Cysharp.Threading.Tasks;
using Pheonix.Core;

public class CicuitBlockGroupController : MonoBehaviour
{

    public static CicuitBlockGroupController instance;


    public List<CicuitDragBlock> OutSideList=new List<CicuitDragBlock>();
    public List<CicuitDragBlock> InSideList = new List<CicuitDragBlock>();
    public GameObject CicuitBlockOutSideGroup;
    public ScrollRect scrollRect; 

    List<GameObject> CicuitBlockList;
    public bool hasBlockMoving = false;
    public void Init(object param)
    {

        CicuitBlockList = (param as CicuitBlockGroupControllerParam).CicuitBlockList;




    }
    private void Start()
    {
        CreatBlocks();
        SetSize();
        instance = this;
    }

    private void SetSize()
    {
        
        //throw new NotImplementedException();
    }

    private void CreatBlocks()
    {
        foreach (var item in CicuitBlockList)
        {
            item.gameObject.transform.parent = this.transform;
            item.SetActive(true);
            item.GetComponent<RectTransform>().localScale = new Vector3(1, 1, 1);
            item.GetComponent<RectTransform>().anchoredPosition3D=Vector3.zero;
        }
        //throw new NotImplementedException();
    }



}
public class CicuitBlockGroupControllerParam
{
    public List<GameObject> CicuitBlockList;
}
