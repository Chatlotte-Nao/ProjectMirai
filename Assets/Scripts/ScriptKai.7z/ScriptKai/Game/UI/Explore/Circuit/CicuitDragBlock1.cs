﻿using Pheonix.Core;
using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;
//using
using UnityEngine.EventSystems;
using UnityEngine.UI;
using DG.Tweening;
using UnityEditor;

public class CicuitDragBlock1 : MonoBehaviour, IBeginDragHandler, IEndDragHandler, IDragHandler
{

    [SerializeField] UIButton mainImageBtn;
    [SerializeField] Image mainImage;
    [SerializeField] GameObject BigBlocks;

    public string mainImagedir = "up";
    public bool Moving = false;


    List<RectTransform> putDownCheckColliderList = new List<RectTransform>();

    private void Start()
    {
        mainImageBtn.onClick.AddListener(RotateMainImage);
        for (int i = 0; i < BigBlocks.transform.childCount; i++)
        {
            for (int ii = 0; ii <
            BigBlocks.transform.GetChild(i).GetChild(0).childCount; ii++)
            {
                putDownCheckColliderList.Add(BigBlocks.transform.GetChild(i).GetChild(0).GetChild(ii).GetComponent<RectTransform>());
            }
        }
    }

    private void RotateMainImage(GameObject o)
    {
        switch (mainImagedir)
        {
            case "up":
                mainImagedir = "left";
                mainImage.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 90f);//TODO 动画
                BigBlocks.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 90f);//TODO 动画
                break;
            case "left":
                mainImagedir = "down";
                mainImage.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 180f);
                BigBlocks.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 180f);
                break;
            case "down":
                mainImagedir = "right";
                mainImage.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 270f);
                BigBlocks.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 270f);
                break;
            case "right":
                mainImagedir = "up";
                mainImage.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 360f);
                BigBlocks.GetComponent<RectTransform>().rotation = Quaternion.Euler(0, 0, 360f);
                break;
            default:
                break;
        }

    }





    void ShowBigBlocks()
    {
        if (BigBlocks.activeSelf) return;
        BigBlocks.SetActive(true);

        Moving = true;
        transform.SetParent(CicuitBlockGroupController.instance.CicuitBlockOutSideGroup.transform);
        transform.localPosition = Vector3.zero;
    }


    void IBeginDragHandler.OnBeginDrag(PointerEventData eventData)
    {

        ShowBigBlocks();
        //throw new NotImplementedException();
    }

    void IDragHandler.OnDrag(PointerEventData eventData)
    {

        if (Moving || BigBlocks.activeSelf)
        {
            Moving = true;
            CicuitBlockGroupController.instance.hasBlockMoving = Moving;
            var rt = BigBlocks.GetComponent<RectTransform>();
            Vector3 globalMousePos;
            if (RectTransformUtility.ScreenPointToWorldPointInRectangle(rt, eventData.position,
                eventData.pressEventCamera, out globalMousePos))
            {
                rt.position = globalMousePos;
            }
            return;
        }

        Moving = true;
        CicuitBlockGroupController.instance.hasBlockMoving = Moving;
        //throw new NotImplementedException();
    }

    void IEndDragHandler.OnEndDrag(PointerEventData eventData)
    {
        for (int i = 0; i < BigBlocks.transform.childCount; i++)
        {
            foreach (var item in
            BigBlocks.transform.GetChild(i).GetComponent<CicuitBigBlock>().LinkPoints)
            {
                item.SetActive(true);
            }
        }
        Moving = false;
        CicuitBlockGroupController.instance.hasBlockMoving = Moving;
        GameObject Node = null;
        if (PutDownAble(out Node)&&Node!=null)//TODO判断是否能放下
        {
            var rt = BigBlocks.GetComponent<RectTransform>();
            Vector3 globalMousePos;
            if (RectTransformUtility.ScreenPointToWorldPointInRectangle(rt, eventData.position,
                eventData.pressEventCamera, out globalMousePos))
            {

                Vector3 IntPoint = new Vector3((int)globalMousePos.x, (int)globalMousePos.y, 1.5f);
                rt.position = IntPoint;
            }

            rt.position = Node.GetComponent<RectTransform>().position;
            
            
            



        }
        else
        {
            transform.SetParent(CicuitBlockGroupController.instance.transform);
            var tween = BigBlocks.GetComponent<RectTransform>().DOMove(mainImage.GetComponent<RectTransform>().position, 0.5f);
            tween.SetEase(Ease.OutCubic);
            tween.onComplete += () =>
            {
                BigBlocks.SetActive(false);
                mainImage.enabled = true;
            };
        }

    }
    

    private bool PutDownAble(out GameObject NodePoint)
    {
        bool result = true;
       NodePoint = null;
        int temp = 0;
        foreach (var item2 in putDownCheckColliderList)
        {
            var hit2D2 = Physics2D.OverlapCircleAll(item2.GetComponent<RectTransform>().position, 3f, LayerMask.GetMask("UI"));

            foreach (var item in hit2D2)
            {
                if (item.name=="Check")
                {
                    temp++;
                    
                }
            }
        }

        int cheackCount=0;
        for (int i = 0; i < BigBlocks.transform.childCount; i++)
        {
            cheackCount+=BigBlocks.transform.GetChild(0).GetChild(i).childCount;
        }
        Debug.Log(temp +" "+ BigBlocks.transform.childCount+" "+cheackCount);
        // if (temp > BigBlocks.transform.childCount) return false;
        if (temp > cheackCount) return false;

        var hit2D = Physics2D.OverlapCircleAll(BigBlocks.GetComponent<RectTransform>().position, 3f, LayerMask.GetMask("UI"));
        
        foreach (var item in hit2D)
        {
            if (item.tag == "Finish")
            {
                if (NodePoint == null)
                {
                    NodePoint = item.gameObject;
                }
            }
        }
        var counter = 0;
        foreach (var item2 in putDownCheckColliderList)
        {
            var hit2D2 = Physics2D.OverlapCircleAll(item2.GetComponent<RectTransform>().position, 3f, LayerMask.GetMask("UI"));

            foreach (var item in hit2D2)
            {
                if (item.tag == "Finish")
                {
                    if (NodePoint == null)
                    {
                        NodePoint = item.gameObject;
                    }
                    counter++;
                }
            }
        }
        if (counter < putDownCheckColliderList.Count) return false;
        return true;
    }

}
