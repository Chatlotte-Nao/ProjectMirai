﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using System;
using System.Linq;
using DG.Tweening;

public class UICircuitMainWindow : UIDialogBase
{
    public static UICircuitMainWindow instance;

    public List<GameObject> CicuitBlockBaseList;


    CircuitDataFormate dataFormate = new CircuitDataFormate();
    public UnityEvent OnComplete = new UnityEvent();
    [SerializeField] UIButton skipButton;

    public UnityEvent OnCancel => skipButton.OnTouchUpInside;


    [SerializeField] CicuitBlockGroupController cicuitBlockGroupController;
    //[SerializeField] CicuitPlayGroundController cicuitPlayGroundController; //读表生成
    [SerializeField] RectTransform TestItem1;
    [SerializeField] RectTransform GameOverHintPanel;
    [SerializeField] GameObject DisableCube;
    [SerializeField] List<GameObject> PlayGroundList;
    [SerializeField] Transform R;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

    }
    public async UniTask Setup(int mlevelID)
    {
        
        //SetTestData();
        SetData(mlevelID);

        CicuitBlockGroupControllerParam param1 = new CicuitBlockGroupControllerParam();
        param1.CicuitBlockList = dataFormate.CicuitBlockList;
        cicuitBlockGroupController.Init(param1);

        //cicuitPlayGroundController.Init(dataFormate); //读表生成
    }

    private void SetData(int mlevelID)
    {
        var masters = DataManager.Instance.Master.Circuit.Values;

        var t = masters.First(x => x.levelID == mlevelID);
        dataFormate = Master2Formate(t);

        
        //throw new NotImplementedException();
    }

    protected override void Awake()
    {
        base.Awake();
        instance = this;

    }
    private void Start()
    {
        CreatPlayRound();
    }

    private void CreatPlayRound()
    {
        Instantiate(PlayGroundList[dataFormate.LevelID], R);
    }

    public void GameOver()
    {
        ShowGameOverHintPanel();
    }

    private void ShowGameOverHintPanel()
    {
        GameOverHintPanel.gameObject.SetActive(true);
        //var objPostion = GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position;
        Tween tween = DOTween.To(() => GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position, x => GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position = x, Vector3.zero, 0.2f);

        GameOverHintPanel.GetComponent<UIButton>().onClick.AddListener((o) =>
        {
            Tween tween2 = DOTween.To(() => GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position, x => GameOverHintPanel.GetChild(0).GetComponent<RectTransform>().position = x, new Vector3(0,500,0), 0.2f);
            tween2.onComplete += () =>
            {
                OnComplete.Invoke();
            };
        });
        //throw new NotImplementedException();
    }

    CircuitDataFormate Master2Formate(CircuitMaster master)
    {

        CircuitDataFormate formate = new CircuitDataFormate();


        foreach (var item in master.cicuitBlockTypeList)
        {
            GameObject block = Instantiate(CicuitBlockBaseList[item]);
            block.SetActive(false);
            formate.CicuitBlockList.Add(block);
        }
        formate.StopBlockPostionIndexList = master.stopBlockPostionIndexList;
        formate.StartPointIndex = master.startPointIndex;
        formate.EndPointIndex = master.endPointIndex;
        formate.LevelID = master.id-1;
        return formate;
    }
}
