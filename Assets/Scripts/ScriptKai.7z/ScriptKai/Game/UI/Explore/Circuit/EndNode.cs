﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndNode : MonoBehaviour
{
    public List<RectTransform> EndPoints;
    // Start is called before the first frame update
    void Start()
    {
        CicuitPlayGroundController.insatnce.LigtingEndObjDic.Add(this.gameObject, false);
    }

    // Update is called once per frame
    void Update()
    {
        EndCheck();
        GameOverCheck();
    }
    bool flag = false;
    private void GameOverCheck()
    {
        foreach (var item in CicuitPlayGroundController.insatnce.LigtingEndObjDic)
        {
            if (item.Value == false)
            {
                return;
            }
        }
        if (flag == false)
        {
            UICircuitMainWindow.instance.GameOver();
            flag = true;
        }
        //throw new NotImplementedException();
    }

    public bool Lighting = false;
    private void EndCheck()
    {
        if (CicuitBlockGroupController.instance.hasBlockMoving) return;
        foreach (var item in EndPoints)
        {
            var hit2D = Physics2D.OverlapCircleAll(item.position, 1f, LayerMask.GetMask("UI"));
            foreach (var item2 in hit2D)
            {
                if (item2.tag == "EditorOnly")
                {
                    if (item2.transform.parent.GetComponent<CicuitBigBlock>().lighting == true)
                    {
                        if (Lighting == false)
                        {
                            Lighting = true;
                            CicuitPlayGroundController.insatnce.LigtingEndObjDic[this.gameObject] = true;

                        }
                        return;
                    }
                }
            }
        }

        Lighting = false;

        CicuitPlayGroundController.insatnce.LigtingEndObjDic[this.gameObject] = false;
    }
}
