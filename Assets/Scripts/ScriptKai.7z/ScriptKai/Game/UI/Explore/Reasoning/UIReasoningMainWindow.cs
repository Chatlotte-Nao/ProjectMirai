﻿using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;
using TMPro;
using Game.Sound;
using Base.Sound;
using DG.Tweening;
using Spine.Unity;

public class UIReasoningMainWindow : UIDialogBase
{
    [HideInInspector]
    public UnityEvent OnComplete = new UnityEvent();
    [HideInInspector]
    public UnityEvent OnCancel = new UnityEvent();
    [HideInInspector]
    public UnityEvent OnCheckPos = new UnityEvent();
    [HideInInspector]
    public UnityEvent OnFailed = new UnityEvent();


    private UIRTCamera mRTCamera;
    [SerializeField] UIButton exitBtn;
    [SerializeField] List<UIReasoningColSet> cols = new List<UIReasoningColSet>();
    [SerializeField] GameObject halfNote;
    [SerializeField] GameObject quaterNote;
    [SerializeField] UIText text;
    [SerializeField] Image character;
    [SerializeField] GameObject guard;
    [SerializeField] UIText charaName;
    [SerializeField] RawImage charaSpine;
    [SerializeField] Image noclick;
    [SerializeField] List<UIReasonNote> _notes=new List<UIReasonNote>();

    [SerializeField] UIButton commitBtn;
    [SerializeField] UIText commitCount;

    [SerializeField] private GameObject blackMask;
    //[SerializeField] private ParticleSystem succParti;

    [SerializeField] private UIButton clickButton;

    [SerializeField] private GameObject advTextWindow;
    [SerializeField] Transform rawImg;
    [SerializeField] private GameObject backBg;
    [SerializeField] private GameObject clickMask;
    
    public Transform blockArea;
    public Transform blockArea2;
    private string curExpressionAnimName;
    private string curMotionAnimName;
   // private AdvTurtleGameMaster advTurtleGameMaster;
    public UIText Text { get { return text; } }

    ReasoningMaster reasonMaster = null;
    private GameObject curCharacterObject;
    SkeletonAnimation curSkeletonAnimation;

    private int TotalTimes = 5;
    private int nowTime = 5;
    private bool success = false;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        await UI.ScreenEffect.Fade(0);
        guard.SetActive(false);
        SoundPlayer.StopBgm();
        clickButton.onClickUp.Subscribe(OnClick).AddTo(mSubscriptions);
        exitBtn.OnTouchUpInside.Subscribe(async ()=>
        {
           await OnClickExit();
        }).AddTo(mSubscriptions);
        //OnCheckPos.SubscribeAsync(OnCheakRightPos).AddTo(mSubscriptions);
        commitBtn.OnTouchUpInside.Subscribe(async ()=>
        {
            await OnCommit();
        }).AddTo(mSubscriptions);
        if (mRTCamera == null)
        {
            var rtc = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/RTCamera");
            mRTCamera = rtc.GetComponent<UIRTCamera>();
        }
        curExpressionAnimName = "noExpression";
        curMotionAnimName = "noMotion";
        noclick.gameObject.SetActive(false);
        clickMask.SetActive(true);
        //advTurtleGameMaster = DataManager.Instance.Master.AdvTurtleGame.GetValueOrDefault(TurtleGame.Instance.characterMasterId);
        curCharacterObject = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/chara/100201_twinklestar");
        curSkeletonAnimation = curCharacterObject.GetComponent<SkeletonAnimation>();
        curSkeletonAnimation.Initialize(false);
        curSkeletonAnimation.Update(0.0f);
        curSkeletonAnimation.LateUpdate();
        mRTCamera.Setup(curCharacterObject);
    }

    public async UniTask SetUpLines(int level)
    {
        int id = 0;
        foreach (var item in DataManager.Instance.Master.Reasoning)
        {
            if (item.Value.levelID == level)
            {
                id = item.Value.id;
                reasonMaster = item.Value;
            }
            if (id == 0) return;

        }
        charaName.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterName.ToString());
        if(!string.IsNullOrEmpty(charaName.ToString()))
        {
            var nameTextMeshPro = charaName.GetComponent<TextMeshProUGUI>();
            string firstWord = nameTextMeshPro.text.ToString()[0].ToString();
            string nameLast1 = nameTextMeshPro.text.ToString().Substring(1);

            string nameFirst = firstWord;
            string nameLast2 = "<size=85%>" + nameLast1;
            nameTextMeshPro.text = nameFirst + nameLast2;
        }
      
        text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterInitLines.ToString());
        var newTexture = await ResourceManager.Instance.LoadSpriteAsync("AdvFaceIcon", reasonMaster.textureName);
        character.overrideSprite = newTexture;
        charaSpine.texture = mRTCamera.GetRenderTexture();

        commitCount.SetRawText(string.Format("{0}/{1}", nowTime, TotalTimes));

    }
                               
    public  void SetupCharacter(string body, string expression ,string expressionLoop, string body1, string expression1, string expressionLoop1)
    {      
            if (!string.IsNullOrEmpty(body))
            {
                curSkeletonAnimation.AnimationState.SetAnimation(0, body, false);
                curSkeletonAnimation.AnimationState.AddAnimation(0, body1, true,1);
            }
               
            if (!string.IsNullOrEmpty(expression))
            {
                curSkeletonAnimation.AnimationState.SetAnimation(1, expression, false);
                curSkeletonAnimation.AnimationState.AddAnimation(1, expression1, true, 1);
            }
            else if (!string.IsNullOrEmpty(expressionLoop))
            {
                curSkeletonAnimation.AnimationState.SetAnimation(1, expressionLoop, true);
                curSkeletonAnimation.AnimationState.AddAnimation(1, expressionLoop1, true, 1);
            }
    }

    public void Setup(int level)
    {
        int id = 0;
       
        foreach (var item in DataManager.Instance.Master.Reasoning) 
        {
            if (item.Value.levelID == level)
            {
                id = item.Value.id;
                reasonMaster = item.Value;
            }
            if (id == 0) return;

        }
        //text.SetRawText(reasonMaster.characterInitLines);
        //var newTexture = await ResourceManager.Instance.LoadSpriteAsync("AdvFaceIcon", reasonMaster.textureName);
        //character.overrideSprite = newTexture;
        for (int i = 0; i < reasonMaster.notePos.Count; i++)
        {
            GameObject go;
            UIReasonNote note=null;
            if (reasonMaster.notePos[i] == 0) continue;
            switch (reasonMaster.type[i])
            {
                case 0:
                    go = Instantiate(quaterNote);
                    
                    note = go.GetComponent<UIReasonNote>();
                    note.id = i;
                    note.curCol = cols[i];
                    note.tags = 0;
                    note.reasonMaster = reasonMaster;
                    note.mainWindow = this;
                    note.currentSpaceIdx = reasonMaster.notePos[i];
                    cols[i].AddItemInSpace(note, reasonMaster.notePos[i]-1);
                    go.SetActive(true);
                    if (reasonMaster.tag[i] == 1)
                    {
                       
                    }
                    else
                    {
                        note.SetNotMove();
                    }
                    break;
                case 1:
                    go = Instantiate(halfNote);
                    note = go.GetComponent<UIReasonNote>();
                    note.id = i;
                    note.curCol = cols[i];
                    note.tags = 1;
                    note.reasonMaster = reasonMaster;
                    note.mainWindow = this;
                    note.currentSpaceIdx = reasonMaster.notePos[i];
                    cols[i].AddItemInSpace(note, reasonMaster.notePos[i]-1);
                    go.SetActive(true);
                    if (reasonMaster.tag[i] == 1)
                    {

                    }
                    else
                    {
                        note.SetNotMove();
                    }
                    break;
            }
            
            _notes.Add(note);
        }

        SetAdv();
    }

    async UniTask  SetAdv()
    {
        await Task.Delay(500);
        clickMask.SetActive(false);
        advTextWindow.SetActive(true);
        int a = Random.Range(0, reasonMaster.characterWLines.Count);
        AdvSpineMaster motionAdvbody = DataManager.Instance.Master.AdvSpine[reasonMaster.spineBodyTrue[a]];
        AdvSpineMaster motionAdvexpress = DataManager.Instance.Master.AdvSpine[reasonMaster.spineFaceTrue[a]];
        AdvSpineMaster motionAdvbody1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterBody];
        AdvSpineMaster motionAdvexpress1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterFace];
        SetupCharacter(motionAdvbody.body, motionAdvexpress.expression, motionAdvexpress.expression_loop, motionAdvbody1.waiting, motionAdvexpress1.expression, motionAdvexpress1.expression_loop);
        //SoundManager.PlayVoice(reasonMaster.voiceFalse[a]);
    }
    private void OnClick(Vector2 p)
    {
        //Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.PressScreen();
        //advAnim.SetInteger("reason",2);
        rawImg.localPosition = new Vector3(666, -85.5f, 0);
        backBg.SetActive(false);
        commitBtn.gameObject.SetActive(true);
        advTextWindow.SetActive(false);
    }
    async UniTask OnClickExit()
    {
        await UI.ScreenEffect.Fade(1);
        await UniTask.Delay(500);
        OnFailed.Invoke();
        await UniTask.Delay(500);
        await UI.ScreenEffect.Fade(0);
    }

    async UniTask OnCheakRightPos()
    {
        for (int i = 0; i < cols.Count; i++)
        {
            if(cols[i].noteSpaceIdx!= reasonMaster.noteRightPos[i])
            {
                return;
            }
        } 
        int a = Random.Range(0, reasonMaster.characterRLines.Count);
       int b = Random.Range(0, 2);
       Text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterWord[b]);
       AdvSpineMaster motionAdvbody = DataManager.Instance.Master.AdvSpine[reasonMaster.spineBodyTrue[a]];
       AdvSpineMaster motionAdvexpress = DataManager.Instance.Master.AdvSpine[reasonMaster.spineFaceTrue[a]];
       AdvSpineMaster motionAdvbody1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterBody];
       AdvSpineMaster motionAdvexpress1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterFace];
       SetupCharacter(motionAdvbody.body, motionAdvexpress.expression, motionAdvexpress.expression_loop, motionAdvbody1.waiting, motionAdvexpress1.expression, motionAdvexpress1.expression_loop);
       //if (reasonMaster.voiceFalse.Contains(a.ToString()))
       //{
           //SoundManager.PlayVoice(reasonMaster.voiceTrue[a]);
       //}

        // mainWindow.SetupCharacter("","","","","","");
        advTextWindow.SetActive(true);
        await UniTask.Delay(2000);
        advTextWindow.SetActive(false);
        foreach (var item in _notes)
        {
            item.SetFade();
        }
        Debug.Log("完全正确啦！！！");
        success = true;
        if (reasonMaster != null || !string.IsNullOrEmpty(reasonMaster.successSound))
        {
            SoundPlayer.StopBgm();
            SoundManager.PlayBgm(reasonMaster.successSound, false);
        }
        //succParti.Play();
        await UniTask.Delay(1000);
        foreach (var item in _notes)
        {
            item.ReserveFade();
            item.gameObject.SetActive(false);
        }
        await UniTask.Delay(500);
        foreach (var item in _notes)
        {
            item.gameObject.SetActive(true);
            await UniTask.Delay(100);
        }
        foreach (var item in _notes)
        {
            if (item.currentSpaceIdx - 1 < item.soundID.Count)
            {
                if (item.tags == 0)
                {
                    var t = SoundPlayer.PlaySe(item.soundID[item.currentSpaceIdx - 1]);
                    SoundPlayer.StopSe(t, 0.5f);
                }
                else
                {
                    var t = SoundPlayer.PlaySe(item.soundID[item.currentSpaceIdx - 1]);
                    SoundPlayer.StopSe(t, 1f);
                }
            }
            UIAnimationPlayer.Play(item.animations[1], item.SetClip(1));
            await UniTask.Delay(250);
            item.SetFade();
            UIAnimationPlayer.Play(item.animations[0], item.SetClip(0));
            await UniTask.Delay(250);
        }

        await UniTask.Delay(2000);
        // foreach (var item in _notes)
        // {          
        //     if (item.currentSpaceIdx - 1 < item.soundID.Count)
        //     {
        //         if (item.tags == 0)
        //         {
        //             var t = SoundPlayer.PlaySe(item.soundID[item.currentSpaceIdx - 1]);
        //             SoundPlayer.StopSe(t, 0.5f);
        //         }
        //         else
        //         {
        //             var t = SoundPlayer.PlaySe(item.soundID[item.currentSpaceIdx - 1]);
        //             SoundPlayer.StopSe(t, 1f);
        //         }
        //     }
        //     await UniTask.Delay(100);
        // }
        await PlayAnimReverse();
        //noclick.gameObject.SetActive(true);
        await UI.ScreenEffect.Fade(1);
        guard.SetActive(true);
        //await UniTask.Delay(2000);
        OnComplete.Invoke();
        guard.SetActive(false);
        await UniTask.Delay(2000);
        await UI.ScreenEffect.Fade(0);
    }

    async UniTask PlayAnimReverse()
    {
        foreach (var anim in _notes)
        {
            anim.gameObject.SetActive(false);
        }
        var anims = GetComponent<Animation>();
        anims[showAnimation.name].time = anims[showAnimation.name].clip.length;
        anims[showAnimation.name].speed = -1;
        UIAnimationPlayer.Play(anims,showAnimation);
        await UniTask.Delay(2000);
    }

    async Task OnCommit()
    {
        // for (int i = 0; i < cols.Count; i++)
        //  if (colRPos[id] == currentSpaceIdx)
        //     {
        //         int a = Random.Range(0, reasonMaster.characterRLines.Count);
        //         int b = Random.Range(0, 2);
        //         Text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterWord[b]);
        //         AdvSpineMaster motionAdvbody = DataManager.Instance.Master.AdvSpine[reasonMaster.spineBodyTrue[a]];
        //         AdvSpineMaster motionAdvexpress = DataManager.Instance.Master.AdvSpine[reasonMaster.spineFaceTrue[a]];
        //         AdvSpineMaster motionAdvbody1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterBody];
        //         AdvSpineMaster motionAdvexpress1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterFace];
        //         SetupCharacter(motionAdvbody.body, motionAdvexpress.expression, motionAdvexpress.expression_loop, motionAdvbody1.waiting, motionAdvexpress1.expression, motionAdvexpress1.expression_loop);
        //         //if (reasonMaster.voiceFalse.Contains(a.ToString()))
        //         //{
        //            // SoundManager.PlayVoice(reasonMaster.voiceTrue[a]);
        //         //}
        //
        //         // mainWindow.SetupCharacter("","","","","","");
        //     }
        //     else
        //     {
        //         int a = Random.Range(0, reasonMaster.characterWLines.Count);
        //         Text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterWLines[a]);
        //  
        //         AdvSpineMaster motionAdvbody = DataManager.Instance.Master.AdvSpine[reasonMaster.spineBodyFalse[a]];
        //         AdvSpineMaster motionAdvexpress = DataManager.Instance.Master.AdvSpine[reasonMaster.spineFaceFalse[a]];
        //         AdvSpineMaster motionAdvbody1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterBody];
        //         AdvSpineMaster motionAdvexpress1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterFace];
        //         SetupCharacter(motionAdvbody.body, motionAdvexpress.expression, motionAdvexpress.expression_loop, motionAdvbody1.waiting, motionAdvexpress1.expression, motionAdvexpress1.expression_loop);
        //         //if (reasonMaster.voiceFalse.Contains(a.ToString()))
        //         //{
        //             SoundManager.PlayVoice(reasonMaster.voiceFalse[a]);
        //         //}
        //         
        //         // mainWindow.SetupCharacter("","","","","","");
        //     }
        clickMask.SetActive(true);
        commitBtn.gameObject.SetActive(false);
        await OnCheakRightPos();
        if (!success)
        {
            foreach (var item in _notes)
            {
                if (item.currentSpaceIdx - 1 < item.soundID.Count)
                {
                    if (item.tags == 0)
                    {
                        var t = SoundPlayer.PlaySe(item.soundID[item.currentSpaceIdx - 1]);
                        SoundPlayer.StopSe(t, 0.5f);
                    }
                    else
                    {
                        var t = SoundPlayer.PlaySe(item.soundID[item.currentSpaceIdx - 1]);
                        SoundPlayer.StopSe(t, 1f);
                    }
                }
                
                await UniTask.Delay(500);
            }

            advTextWindow.SetActive(true);
            int a = Random.Range(0, reasonMaster.characterWLines.Count);
            Text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterWLines[a]);

            AdvSpineMaster motionAdvbody = DataManager.Instance.Master.AdvSpine[reasonMaster.spineBodyFalse[a]];
            AdvSpineMaster motionAdvexpress = DataManager.Instance.Master.AdvSpine[reasonMaster.spineFaceFalse[a]];
            AdvSpineMaster motionAdvbody1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterBody];
            AdvSpineMaster motionAdvexpress1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterFace];
            SetupCharacter(motionAdvbody.body, motionAdvexpress.expression, motionAdvexpress.expression_loop,
                motionAdvbody1.waiting, motionAdvexpress1.expression, motionAdvexpress1.expression_loop);

            for (int i = 0; i < cols.Count; i++)
            {
                if (cols[i].noteSpaceIdx != reasonMaster.noteRightPos[i])
                {
                    var anim = cols[i].transform.GetChild(cols[i].getSpaces().Count - cols[i].noteSpaceIdx).GetChild(0)
                        .GetComponent<UIReasonNote>();
                    UIAnimationPlayer.Play(anim.animations[0], anim.SetClip(0));
                }
            }

            await UniTask.Delay(3000);
            for (int i = 0; i < cols.Count; i++)
            {
                if (cols[i].noteSpaceIdx != reasonMaster.noteRightPos[i])
                {
                    var anim = cols[i].transform.GetChild(cols[i].getSpaces().Count - cols[i].noteSpaceIdx).GetChild(0)
                        .GetComponent<UIReasonNote>();
                    anim.animations[0].Stop();
                }
            }
            clickMask.SetActive(false);
            //if (reasonMaster.voiceFalse.Contains(a.ToString()))
            //{
            //SoundManager.PlayVoice(reasonMaster.voiceFalse[a]);
            --nowTime;
            commitCount.SetRawText(string.Format("{0}/{1}", nowTime, TotalTimes));
            if (nowTime < 1)
            {
                clickMask.SetActive(true);
                await OnClickExit();
            }
        }
    }

    async UniTask cancel()
    {
        clickMask.SetActive(true);
        await UniTask.Delay(1000);
        advTextWindow.SetActive(false);
        commitBtn.gameObject.SetActive(true);
        await UniTask.Delay(1000);
        noclick.gameObject.SetActive(true);
        await UniTask.Delay(500);
        OnFailed.Invoke();
    }
    public override void Dispose()
    {
        base.Dispose();
        SoundPlayer.StopBgm();

    }



}
