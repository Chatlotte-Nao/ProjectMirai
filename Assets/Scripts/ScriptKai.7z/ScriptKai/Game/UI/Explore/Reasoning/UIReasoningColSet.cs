﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIReasoningColSet : MonoBehaviour
{
    [SerializeField] List<Transform> spaces = new List<Transform>(); 
    public int noteSpaceIdx;
    public void AddItemInSpace(UIReasonNote note,int index)
    {
        note.gameObject.transform.SetParent(spaces[index]);
        note.gameObject.transform.localPosition = Vector3.zero;
        note.gameObject.transform.localScale = new Vector3(1, 1, 1);
        note.gameObject.transform.transform.localRotation = Quaternion.identity;
        noteSpaceIdx = index + 1;
    }

    public List<Transform> getSpaces()
    {
        return spaces;
    }
}
