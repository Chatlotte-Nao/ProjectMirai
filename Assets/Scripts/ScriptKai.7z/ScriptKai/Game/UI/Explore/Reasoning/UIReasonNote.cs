﻿using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using Game.Sound;
using Base.Sound;

public class UIReasonNote : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler,IPointerClickHandler
{


    [SerializeField] GameObject[] activeObject;
    [SerializeField] GameObject[] nonactiveObject;
    [SerializeField] AnimationClip[] animationWrong;
    
    public UIReasoningColSet curCol;
    List<int> colRPos = new List<int>();
    List<Transform> spaces = new List<Transform>();
    public List<int> soundID = new List<int>();
    public int currentSpaceIdx = -1;
    Vector3 pos = Vector3.zero;
    bool isDragging = false;
    bool isRotated = false;
    GameObject[] currentObject;

    public UIReasoningMainWindow mainWindow;
    public int tags = 0;
    public int id;
    public bool canMove = true;
    public ReasoningMaster reasonMaster = null;
    public Animation []animations;
    private void Start()
    {
        pos = this.transform.localPosition;
        spaces = curCol.getSpaces();
        colRPos = reasonMaster.noteRightPos;
        if (canMove)
            currentObject = activeObject;
        else
            currentObject = nonactiveObject;
        animations = GetComponentsInChildren<Animation>();
        SetIcon();
    }

    public AnimationClip SetClip(int index)
    {
        return animationWrong[index];
    }

    public void SetFade()
    {
        for (int i = 0; i < activeObject.Length; i++)
        {
            if (nonactiveObject[i].activeSelf)
            {
                activeObject[i].SetActive(true);
                nonactiveObject[i].SetActive(false);           
                break;
            }
        }
    }

    public void ReserveFade()
    {
        for (int i = 0; i < activeObject.Length; i++)
        {
            if (activeObject[i].activeSelf)
            {
                nonactiveObject[i].SetActive(true);
                activeObject[i].SetActive(false);           
                break;
            }
        }
    }
    private void Update()
    {
        
        if (transform.position.y > mainWindow.blockArea.position.y)
        {
            transform.position =
                new Vector3(transform.position.x, mainWindow.blockArea.position.y, transform.position.z);
        }
        if (transform.position.y < mainWindow.blockArea2.position.y)
        {
            transform.position =
                new Vector3(transform.position.x, mainWindow.blockArea2.position.y, transform.position.z);
        }
        if (currentSpaceIdx > 7)
        {
            if (!isRotated)
            {
                currentObject[0].SetActive(false);
                currentObject[1].SetActive(false);
                currentObject[3].SetActive(false);
                currentObject[2].SetActive(true);
                isRotated = true;
            }
        } 
        else
        {
            if (isRotated)
            {

                currentObject[1].SetActive(false);
                currentObject[3].SetActive(false);
                currentObject[0].SetActive(true);
                currentObject[2].SetActive(false);
                isRotated = false;
            }
         
        }
        if(isDragging)
        {
            SetIcon();
            //for (int i = 0; i < spaces.Count; i++)
            //{
            //    if (Vector3.Distance(SceneBase.Current.UICamera.WorldToScreenPoint(spaces[i].position), SceneBase.Current.UICamera.WorldToScreenPoint(this.transform.position)) < 20f)
            //    {
            //        if (currentSpaceIdx - 1 != i)
            //        {
            //            currentSpaceIdx = i + 1;
            //            //playSE
            //            if (currentSpaceIdx - 1 < soundID.Count)
            //            {
            //                if(tags == 0)
            //                {
            //                    var t = SoundPlayer.PlaySe(soundID[currentSpaceIdx - 1]);
            //                    SoundPlayer.StopSe(t, 0.5f);
            //                }
            //                else
            //                {
            //                    var t = SoundPlayer.PlaySe(soundID[currentSpaceIdx - 1]);
            //                    SoundPlayer.StopSe(t, 1f);
            //                }
                               
            //            }
            //        }
            //    }
           // }
            //if (SceneBase.Current.UICamera.WorldToScreenPoint(this.transform.position).y > 600)
            //{

            //    if (currentSpaceIdx != 13 && currentSpaceIdx - 1 < soundID.Count)
            //    {
            //        currentSpaceIdx = 13;
            //        SetIcon();
            //        SoundPlayer.PlaySe(soundID[currentSpaceIdx - 1]);
            //    }
            //}
            //if (SceneBase.Current.UICamera.WorldToScreenPoint(this.transform.position).y < 240)
            //{

            //    if (currentSpaceIdx != 1 && currentSpaceIdx - 1 < soundID.Count)
            //    {
            //        currentSpaceIdx = 1;
            //        SetIcon();
            //        SoundPlayer.PlaySe(soundID[currentSpaceIdx - 1]);
            //    }
            //}

        }


    }
    public void OnBeginDrag(PointerEventData eventData)
    {
        //Debug.Log("Begin");
        
        if (!canMove)
        {
            UIAnimationPlayer.Play(animations[1], animationWrong[0]);
            mainWindow.Text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterWord[Random.Range(0, reasonMaster.characterWord.Count)]);
            return;
        }
        isDragging = true;
    }

    public void OnDrag(PointerEventData eventData)
    {
        //Debug.Log("Draging");
        if (!canMove)
        {    
            return;
        }
        for (int i = 0; i < spaces.Count; i++)
        {
            if (Vector3.Distance(SceneBase.Current.UICamera.WorldToScreenPoint(spaces[i].position), SceneBase.Current.UICamera.WorldToScreenPoint(this.transform.position)) < 5f)
            {
                if (currentSpaceIdx - 1 != i)
                {
                    currentSpaceIdx = i + 1;
                    //playSE
                    if (currentSpaceIdx - 1 < soundID.Count)
                    {
                        if (tags == 0)
                        {
                            var t = SoundPlayer.PlaySe(soundID[currentSpaceIdx - 1]);
                            SoundPlayer.StopSe(t, 0.5f);
                        }
                        else
                        {
                            var t = SoundPlayer.PlaySe(soundID[currentSpaceIdx - 1]);
                            SoundPlayer.StopSe(t, 1f);
                        }

                    }
                }
            }
        }
            //isDragging = true;
            SetDraggedPosition(eventData);
        
        
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        if (!canMove)
        {
            return;
        }
        this.transform.localPosition = pos;
        curCol.AddItemInSpace(this, currentSpaceIdx-1);
        isDragging = false;
       

        // if ((currentSpaceIdx - 1)>colRPos.Count)
        // {
        //     int a = Random.Range(0, reasonMaster.characterWLines.Count);
        //     mainWindow.Text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterWLines[a]);
        //     AdvSpineMaster motionAdvbody = DataManager.Instance.Master.AdvSpine[reasonMaster.spineBodyFalse[a]];
        //     AdvSpineMaster motionAdvexpress = DataManager.Instance.Master.AdvSpine[reasonMaster.spineFaceFalse[a]];
        //     AdvSpineMaster motionAdvbody1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterBody];
        //     AdvSpineMaster motionAdvexpress1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterFace];
        //     mainWindow.SetupCharacter(motionAdvbody.body, motionAdvexpress.expression, motionAdvexpress.expression_loop, motionAdvbody1.waiting, motionAdvexpress1.expression, motionAdvexpress1.expression_loop);
        //     
        //     SoundManager.PlayVoice(reasonMaster.voiceFalse[a]);
        //
        // }
        // else
        // {
        //     if (colRPos[id] == currentSpaceIdx)
        //     {
        //         int a = Random.Range(0, reasonMaster.characterRLines.Count);
        //         int b = Random.Range(0, 2);
        //         mainWindow.Text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterWord[b]);
        //         AdvSpineMaster motionAdvbody = DataManager.Instance.Master.AdvSpine[reasonMaster.spineBodyTrue[a]];
        //         AdvSpineMaster motionAdvexpress = DataManager.Instance.Master.AdvSpine[reasonMaster.spineFaceTrue[a]];
        //         AdvSpineMaster motionAdvbody1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterBody];
        //         AdvSpineMaster motionAdvexpress1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterFace];
        //         mainWindow.SetupCharacter(motionAdvbody.body, motionAdvexpress.expression, motionAdvexpress.expression_loop, motionAdvbody1.waiting, motionAdvexpress1.expression, motionAdvexpress1.expression_loop);
        //         //if (reasonMaster.voiceFalse.Contains(a.ToString()))
        //         //{
        //             SoundManager.PlayVoice(reasonMaster.voiceTrue[a]);
        //         //}
        //
        //         // mainWindow.SetupCharacter("","","","","","");
        //     }
        //     else
        //     {
        //         int a = Random.Range(0, reasonMaster.characterWLines.Count);
        //         mainWindow.Text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterWLines[a]);
        //  
        //         AdvSpineMaster motionAdvbody = DataManager.Instance.Master.AdvSpine[reasonMaster.spineBodyFalse[a]];
        //         AdvSpineMaster motionAdvexpress = DataManager.Instance.Master.AdvSpine[reasonMaster.spineFaceFalse[a]];
        //         AdvSpineMaster motionAdvbody1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterBody];
        //         AdvSpineMaster motionAdvexpress1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterFace];
        //         mainWindow.SetupCharacter(motionAdvbody.body, motionAdvexpress.expression, motionAdvexpress.expression_loop, motionAdvbody1.waiting, motionAdvexpress1.expression, motionAdvexpress1.expression_loop);
        //         //if (reasonMaster.voiceFalse.Contains(a.ToString()))
        //         //{
        //             SoundManager.PlayVoice(reasonMaster.voiceFalse[a]);
        //         //}
        //         
        //         // mainWindow.SetupCharacter("","","","","","");
        //     }
        //}
        mainWindow.OnCheckPos.Invoke();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        //play SE

        if (isDragging) return;
        if (currentSpaceIdx - 1 < soundID.Count)
        {
            if (tags == 0)
            {
                var t = SoundPlayer.PlaySe(soundID[currentSpaceIdx - 1]);
                SoundPlayer.StopSe(t, 0.5f);
            }
            else
            {
                var t = SoundPlayer.PlaySe(soundID[currentSpaceIdx - 1]);
                SoundPlayer.StopSe(t, 1f);
            }
        }


       // // Debug.Log("point");
       //  if ((currentSpaceIdx - 1) > colRPos.Count)
       //  {
       //      int a = Random.Range(0, reasonMaster.characterWLines.Count);
       //     // mainWindow.Text.SetRawText(reasonMaster.characterWLines[a]);
       //      // mainWindow.SetupCharacter("","","","","","");
       //      mainWindow.Text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterWLines[a]);
       //      AdvSpineMaster motionAdvbody = DataManager.Instance.Master.AdvSpine[reasonMaster.spineBodyFalse[a]];
       //      AdvSpineMaster motionAdvexpress = DataManager.Instance.Master.AdvSpine[reasonMaster.spineFaceFalse[a]];
       //      AdvSpineMaster motionAdvbody1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterBody];
       //      AdvSpineMaster motionAdvexpress1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterFace];
       //      mainWindow.SetupCharacter(motionAdvbody.body, motionAdvexpress.expression, motionAdvexpress.expression_loop, motionAdvbody1.waiting, motionAdvexpress1.expression, motionAdvexpress1.expression_loop);
       //      //if (reasonMaster.voiceFalse.Contains(a.ToString()))
       //      //{
       //          SoundManager.PlayVoice(reasonMaster.voiceFalse[a]);
       //      //}
       //    
       //  }
       //  else
       //  {
       //      if (colRPos[id] == currentSpaceIdx)
       //      {
       //          int a = Random.Range(0, reasonMaster.characterRLines.Count);
       //          int b = Random.Range(0, 2);
       //          mainWindow.Text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterWord[b]);
       //          // mainWindow.SetupCharacter("","","","","","");
       //
       //          AdvSpineMaster motionAdvbody = DataManager.Instance.Master.AdvSpine[reasonMaster.spineBodyTrue[a]];
       //          AdvSpineMaster motionAdvexpress = DataManager.Instance.Master.AdvSpine[reasonMaster.spineFaceTrue[a]];
       //          AdvSpineMaster motionAdvbody1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterBody];
       //          AdvSpineMaster motionAdvexpress1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterFace];
       //          mainWindow.SetupCharacter(motionAdvbody.body, motionAdvexpress.expression, motionAdvexpress.expression_loop, motionAdvbody1.waiting, motionAdvexpress1.expression, motionAdvexpress1.expression_loop);
       //
       //          SoundManager.PlayVoice(reasonMaster.voiceTrue[a]);
       //
       //      }
       //      else
       //      {
       //          int a = Random.Range(0, reasonMaster.characterWLines.Count);
       //          mainWindow.Text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, reasonMaster.characterWLines[a]);
       //          // mainWindow.SetupCharacter("","","","","","");
       //        
       //          AdvSpineMaster motionAdvbody = DataManager.Instance.Master.AdvSpine[reasonMaster.spineBodyFalse[a]];
       //          AdvSpineMaster motionAdvexpress = DataManager.Instance.Master.AdvSpine[reasonMaster.spineFaceFalse[a]];
       //          AdvSpineMaster motionAdvbody1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterBody];
       //          AdvSpineMaster motionAdvexpress1 = DataManager.Instance.Master.AdvSpine[reasonMaster.characterFace];
       //          mainWindow.SetupCharacter(motionAdvbody.body, motionAdvexpress.expression, motionAdvexpress.expression_loop, motionAdvbody1.waiting, motionAdvexpress1.expression, motionAdvexpress1.expression_loop);
       //          SoundManager.PlayVoice(reasonMaster.voiceFalse[a]);              
       //      }
       //  }
        mainWindow.OnCheckPos.Invoke();
    }
    void SetDraggedPosition(PointerEventData eventData)
    {
        var rt = GetComponent<RectTransform>();
        Vector3 globalMousePos;

        if (RectTransformUtility.ScreenPointToWorldPointInRectangle(rt, eventData.position,
          eventData.pressEventCamera, out globalMousePos))
        {

            rt.position = new Vector3(rt.position.x, globalMousePos.y, rt.position.z);

        }

    }
    

    public void SetNotMove()
    {
        canMove = false;
      
    }

    public void SetIcon()
    {
        if (currentSpaceIdx <= 7)
        {
            if (currentSpaceIdx == 1)
            {
                currentObject[0].SetActive(false);
                currentObject[1].SetActive(true);
                currentObject[2].SetActive(false);
                currentObject[3].SetActive(false);
            }
            else
            {
              
                currentObject[1].SetActive(false);
                currentObject[0].SetActive(true);
                currentObject[2].SetActive(false);
                currentObject[3].SetActive(false);
            }
        }
        else
        {
            if (currentSpaceIdx == 13)
            {
                currentObject[0].SetActive(false);
                currentObject[1].SetActive(false);
                currentObject[2].SetActive(false);
                currentObject[3].SetActive(true);
            }
            else
            {
                currentObject[0].SetActive(false);
                currentObject[1].SetActive(false);
                currentObject[2].SetActive(true);
                currentObject[3].SetActive(false);
            }
        }
    }
}
