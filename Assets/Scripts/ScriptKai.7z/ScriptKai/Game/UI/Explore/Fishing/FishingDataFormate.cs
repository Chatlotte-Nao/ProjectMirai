﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class FishingDataFormate
{

    public List<Fish> fishTypeList=new List<Fish>();
    public List<Fish> collectedFishList=new List<Fish>();

    public Fish GetRandomFishClone()
    {
        int randomKey = UnityEngine.Random.Range(1, fishTypeList[fishTypeList.Count - 1].randomWeight);
        int randomIndex = fishTypeList.FindLastIndex((Fish item) => item.randomWeight < randomKey);
        Fish baseFish = fishTypeList[randomIndex + 1];
        return baseFish.GetClone();
    }
}


public class Fish
{

    public int fishID;
    public string fishName;
    public float fishSpeedRate;
    public float powerBarFillSpeedRate;
    public int bulbSliderCount;

    public int fishCountDownTime;
    public int randomWeight;
    public float fishingAreaRatio;
    public List<string> movePath;

    public Fish(int fishID, string fishName, float fishSpeedRate, float powerBarFillSpeedRate, int fishCountDownTime, int randomWeight,float fishingAreaRatio,int bulbSliderCount,List<string> movePath)
    {
        this.fishID = fishID;
        this.fishName = fishName;
        this.fishSpeedRate = fishSpeedRate;
        this.powerBarFillSpeedRate = powerBarFillSpeedRate;
        this.fishCountDownTime = fishCountDownTime;
        this.randomWeight = randomWeight;
        this.fishingAreaRatio = fishingAreaRatio;
        this.bulbSliderCount = bulbSliderCount;
        this.movePath = movePath;
    }
    public Fish GetClone()
    {
        return new Fish(this.fishID, this.fishName, this.fishSpeedRate, this.powerBarFillSpeedRate, this.fishCountDownTime, this.randomWeight,this.fishingAreaRatio,this.bulbSliderCount,this.movePath);
    }
}
