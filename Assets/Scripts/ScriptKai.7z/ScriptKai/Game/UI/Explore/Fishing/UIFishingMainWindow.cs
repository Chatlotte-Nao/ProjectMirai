﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using UnityEngine.Events;
using Cysharp.Threading.Tasks;
using System;
using DG.Tweening;
using UnityEngine.UI;

public class UIFishingMainWindow :UIDialogBase
{
    public Dictionary<string, Sprite> FishImageDic=new Dictionary<string, Sprite>();
    public List<Sprite> FishImageList=new List<Sprite>();


    [SerializeField] Image PowerFillBar;
    [SerializeField] Image FishingArea;

    [SerializeField] Image FishInfo;

    [SerializeField] Slider FishSlider;
    //[SerializeField] Slider ProgressSlider;
    [SerializeField] UIButton skipButton;


    [SerializeField] UIButton FishPoleButton;

    [SerializeField] ProgressSlider ProgressSlider;
    [SerializeField] GameObject NextFishPoint;
    [SerializeField] GameObject FishImagePrefab;


    public UnityEvent OnComplete = new UnityEvent();
    public bool GameSuccesOver = false;

    public UnityEvent OnCancel => skipButton.OnTouchUpInside;

    private FishingDataFormate fishingData;




    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        InitBtnFunc();
        //SetData();


        SetData();


        
    }



    public async UniTask Setup(int levelID)
    {
        //读表

    }


    private void SetData()
    {
        fishingData = new FishingDataFormate();
        var data = DataManager.Instance.Master.FishType.Values;
        foreach (var item in data)
        {
            Fish baseFish = new Fish(item.fishID, item.fishName, item.fishSpeedRate, item.powerBarFillSpeedRate, item.fishCountDownTime, item.randomWeight,((float)item.fishingAreaRatio/100f),item.bulbSliderCount,item.movePath);
            fishingData.fishTypeList.Add(baseFish);
        }
        for (int i = 0; i < fishingData.fishTypeList.Count; i++)
        {
            FishImageDic.Add(fishingData.fishTypeList[i].fishName, FishImageList[i]);
        }
    }

    private void InitBtnFunc()
    {
        FishPoleButton.onClickDown.AddListener(FishPoleBtnClickBegin);
        FishPoleButton.onClickUp.AddListener(FishPoleBtnClickUp);
    }






    #region Controller



    int movePointIndex;
    private void Start()
    {
        movePointIndex = 0;
        ReSetData();
    }


    //public UnityEvent test => ProgressSlider.test;




    async void ReSetData()
    {
        gaming = false;
        nowRoundFish = fishingData.GetRandomFishClone();
        float BGHeight = FishSlider.transform.parent.GetComponent<RectTransform>().sizeDelta.y;
        FishingArea.GetComponent<RectTransform>().sizeDelta = new Vector2(0, BGHeight * nowRoundFish.fishingAreaRatio);
        await UniTask.Delay(1000);
        ProgressSlider.ReInit(nowRoundFish);

        //Debug.Log(nowRoundFish.movePath.Count);
        //throw new NotImplementedException();
    }

    Fish nowRoundFish;
    bool gaming;

    bool playing = false;
    void GameStart()
    {
        if (!playing)
        {

            Game.Sound.SoundPlayer.PlaySe("M002");
            playing = true;
        }
        gaming = true;
        FishMoveBegin();
        PowerFillBarAutoDown();
    }

    private async void PowerFillBarAutoDown()
    {
        while (gaming)
        {
            await UniTask.Delay(50);
            ////var t1 = DOTween.To(() => PowerFillBar.fillAmount, x => PowerFillBar.fillAmount = x, PowerFillBar.fillAmount-0.05f, (50f / nowRoundFish.fishSpeedRate));

            PowerFillBar.fillAmount -= 0.005f;
        }
        //throw new NotImplementedException();
    }

    private void FishMoveBegin()
    {
        if (gaming)
        {
            Move2NextPoint();
        }

    }

    void Move2NextPoint()
    {

        var nextPointInfo = GetNextPointData();
        float targetPoint = nextPointInfo.x;
        float waitTime = nextPointInfo.y;
        var s = DOTween.Sequence();
        var slider = FishSlider.GetComponent<Slider>();
        var t1 = DOTween.To(() => slider.value, x => slider.value = x, ((float)targetPoint / 100f), (50f / nowRoundFish.fishSpeedRate));
        t1.SetEase(Ease.Linear);
        s.Append(t1);
        s.AppendInterval(nextPointInfo.y);
        s.onComplete += () =>
        {
            if (gaming)
            {
                Move2NextPoint();
            }
            else
            {
                s.Kill();
            }
            //Debug.Log(((float)targetPoint / 100f)+" "+ (10f / nowRoundFish.fishSpeedRate));
        };
    }



    private Vector2 GetNextPointData()
    {
        Vector2 info = new Vector2();
        var tempStr = nowRoundFish.movePath[movePointIndex].Split('_');
        info.x = Convert.ToSingle(tempStr[0]);
        info.y = Convert.ToSingle(tempStr[1]);
        movePointIndex++;
        if (movePointIndex == nowRoundFish.movePath.Count)
        {
            movePointIndex = 0;
        }

        return info;
        //throw new NotImplementedException();
    }

    private void FishPoleBtnClickUp(Vector2 arg0)
    {
        if (!gaming)
        {
            GameStart();

        }
        //throw new NotImplementedException();
    }

    private void FishPoleBtnClickBegin(Vector2 arg0)
    {
        PowerFillBar.fillAmount += 0.05f;
        //throw new NotImplementedException();
    }


    void FishCatchCheck()
    {
        if (gaming)
        {
            float half = (nowRoundFish.fishingAreaRatio / 2f);
            float fish = FishSlider.value;
            float power = PowerFillBar.fillAmount;
            if ((fish - half <= power) && (fish + half >= power))
            {
                ProgressSlider.FishTimeAdd(0.1f);
            }
            else
            {

                ProgressSlider.FishTimeAdd(-0.01f);
            }
            if (ProgressSlider.isDone)
            {
                NextRound();
                gaming = false;
            }
        }
    }

    private void NextRound()
    {
        ReSetData();
        GetFishAnimation();
        //throw new NotImplementedException();
    }

    private void Update()
    {
        FishCatchCheck();
    }

    bool animationFlag = true;
    async void GetFishAnimation()//捕鱼结束提示
    {
        if (animationFlag)
        {
            animationFlag = false;
            FishInfo.GetComponent<RectTransform>().localPosition = Vector3.zero;
            FishInfo.gameObject.SetActive(true);
            FishInfo.transform.parent.gameObject.SetActive(true);
            FishInfo.transform.GetChild(0).gameObject.GetComponent<Image>().sprite = FishImageDic[nowRoundFish.fishName];
            FishInfo.GetComponent<RectTransform>().sizeDelta = new Vector2(0, 0);
            var tweener = DOTween.To(() => FishInfo.GetComponent<RectTransform>().sizeDelta, x => FishInfo.GetComponent<RectTransform>().sizeDelta = x, new Vector2(1200, 550), 1f);
            tweener.SetEase(Ease.InOutBack);
            await UniTask.Delay(2000);
            tweener.PlayBackwards();
            var tweener2 = DOTween.To(() => FishInfo.GetComponent<RectTransform>().sizeDelta, x => FishInfo.GetComponent<RectTransform>().sizeDelta = x, new Vector2(50, 50), 1f);
            tweener2.SetEase(Ease.InOutBack);

            tweener2.onComplete += async () =>
            {
                var point = NextFishPoint.GetComponent<RectTransform>().position;
                var tweener3 = DOTween.To(() => FishInfo.GetComponent<RectTransform>().position, x => FishInfo.GetComponent<RectTransform>().position = x, point, 2f);
                tweener3.SetEase(Ease.OutQuint);
                await UniTask.Delay(500);
                var obj = Instantiate(FishImagePrefab);
                obj.GetComponent<Image>().sprite = FishImageDic[nowRoundFish.fishName];
                obj.transform.parent = NextFishPoint.transform.parent;
                obj.transform.SetSiblingIndex(obj.transform.parent.childCount - 2);

                obj.GetComponent<RectTransform>().localScale = Vector3.one;
                obj.transform.localScale = Vector3.one;

                FishInfo.gameObject.SetActive(false);
                FishInfo.transform.parent.gameObject.SetActive(false);
                if (NextFishPoint.transform.GetSiblingIndex() % 4 == 0)
                {
                    DOTween.To(() => NextFishPoint.transform.parent.GetComponent<RectTransform>().anchoredPosition, x => NextFishPoint.transform.parent.GetComponent<RectTransform>().anchoredPosition = x, NextFishPoint.transform.parent.GetComponent<RectTransform>().anchoredPosition + new Vector2(0, 100f), 0.5f);
                    //NextFishPoint.transform.parent.GetComponent<RectTransform>().anchoredPosition + new Vector2(0, 100f);
                }
                tweener2 = null;
                animationFlag = true;
            };
        }
    }

    //private void GetFish()
    //{

    //    //throw new NotImplementedException();
    //}






















    #endregion
}
