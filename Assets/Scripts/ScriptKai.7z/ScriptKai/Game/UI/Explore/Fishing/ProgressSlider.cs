﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class ProgressSlider : MonoBehaviour
{
    public float time;
    public float maxTime;
    public bool isDone;
    public List<GameObject> lightBulbList;
    public Color succColor;
    public Color idleColor;

    public float bulbWidth;
    public float bulbHeight;
    public int bulbCount;
    public void ReInit(Fish fish)
    {
        isDone = false;
        time = 0;
        maxTime = fish.fishCountDownTime;
        bulbCount = fish.bulbSliderCount;
        foreach (var item in lightBulbList)
        {
            item.SetActive(false);
            item.GetComponent<Image>().color = idleColor;
        }
        for (int i = 0; i < fish.bulbSliderCount; i++)
        {
            lightBulbList[i].SetActive(true);
        }
        gameObject.GetComponent<RectTransform>().sizeDelta = new Vector2(fish.bulbSliderCount * bulbWidth, bulbHeight);

    }


    private void Update()
    {
        SetAdd();
        SetBulb();
    }

    private void SetAdd()
    {
        if (Input.GetKeyDown(KeyCode.G))
        {
            FishTimeAdd(1f);
        }
        //throw new NotImplementedException();
    }

    //public  UnityEvent PlayCatchFishEvent=new UnityEvent();


    public void FishTimeAdd(float arg )
    {
        if (time + arg <= maxTime)
        {
            time += arg;
        }
        else
        {
            isDone = true;
        }
        //SetBulb();

    }

    private void SetBulb()
    {
        for (int i = 0; i < (int)(bulbCount*(time/maxTime)); i++)
        {
            lightBulbList[i].GetComponent<Image>().color = succColor;
        }
        if (time / maxTime > 0.95)
        {
            lightBulbList[bulbCount-1].GetComponent<Image>().color = succColor;

        }
    }
}
