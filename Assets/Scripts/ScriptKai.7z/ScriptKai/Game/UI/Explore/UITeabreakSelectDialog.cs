using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Game.ScriptEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UITeabreakSelectDialog : UIDialogBase
{
    [SerializeField] UIButton okButton;
    [SerializeField] UIButton cancelButton;
    [SerializeField] RawImage standImage;
    [SerializeField] SelectableCharacter characterBase;
    [SerializeField] SelectableCharacter characterBase2;
    [SerializeField] SelectableItem itemBase;
    [SerializeField] UIText bondValueText;
    [SerializeField] Image bondFillBar;
    [SerializeField] RectTransform bondFillEffect;
    [SerializeField] UIText bondLevelText;
    [SerializeField] private GameObject notItemObj;


    [SerializeField] GameObject itemList;
    [SerializeField] GameObject level;
    [SerializeField] GameObject SummaryBg;
    [SerializeField] UIButton eatMore;
    [SerializeField] UIButton finishTeabreak;

    //
    [SerializeField] UITexture yuanding;
    [SerializeField] Slider slider;
    [SerializeField] UIText newBondTotalValueText;
    public Transform itemsBackpack;

    public UnityEvent closeClick = new UnityEvent();

    private GameObject bgObject = null;

    private bool isLocked = false;
    private Dictionary<long, SelectableCharacter> mCharas = new Dictionary<long, SelectableCharacter>();
    private Dictionary<long, SelectableItem> mItems = new Dictionary<long, SelectableItem>();
    UIRTCamera mRTCamera = null;

    private long mSelectedCharacterId = -1;
    private long mSelectedItemId = -1;


    public override async UniTask InitializeAsync()
    {

        await base.InitializeAsync();

        //��ť�¼�
        okButton.OnTouchUpInside.GuardSubscribeAsync(onClickOk).AddTo(mSubscriptions);
        cancelButton.OnTouchUpInside.GuardSubscribeAsync(onClickCancel).AddTo(mSubscriptions);
        finishTeabreak.OnTouchUpInside.GuardSubscribeAsync(onClickCancel).AddTo(mSubscriptions);
        eatMore.OnTouchUpInside.Subscribe(onClickEatMore).AddTo(mSubscriptions);

        //���ر���
        if (GlobalTime.Now.Hour < 17 && GlobalTime.Now.Hour > 8)
        {
            bgObject = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/bg/bg_0207_01", UI.Canvas.GetCanvas(CanvasType.BG).transform);
        }
        else
        {
            bgObject = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/bg/bg_0207_03", UI.Canvas.GetCanvas(CanvasType.BG).transform);
        }

        foreach (var item in bgObject.GetComponentsInChildren<Renderer>())
        {
            item.gameObject.layer = LayerMask.NameToLayer("UI");
        }
        bgObject.transform.localPosition = Vector3.zero;
        bgObject.transform.localScale = new Vector3(52,52,1);

        //��������camera
        var rtc = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/RTCamera");
        mRTCamera = rtc.GetComponent<UIRTCamera>();
        standImage.texture = mRTCamera.GetRenderTexture();

    }

    public override void Dispose()
    {
        base.Dispose();
        mRTCamera.Dispose();
        Destroy(bgObject);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        bgObject.gameObject.SetActive(false);
        mRTCamera.gameObject.SetActive(false);
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        bgObject.gameObject.SetActive(true);
        mRTCamera.gameObject.SetActive(true);
    }

    //init����Ҫ����
    public async UniTask Setup(long characterId)
    {
        //������
        bgObject.gameObject.SetActive(true);

        foreach (var item in DataManager.Instance.Player.Item.GetList())
        {
            //��ȡ��Ъ��Ʒ
            if (item.Count == 0) 
                continue;

            if (DataManager.Instance.Master.Content[item.ItemMasterId].contentTypeMasterId != 127) 
                continue;

            #region ���ɲ�Ъ��Ʒͼ��
            SelectableItem sel = null;

            //init
            var newItemObj = Instantiate(itemBase.gameObject);
            newItemObj.transform.parent = itemBase.transform.parent;
            newItemObj.transform.localScale = Vector3.one;
            newItemObj.transform.localRotation = Quaternion.identity;
            newItemObj.transform.localPosition = Vector3.zero;
            newItemObj.SetActive(true);

            sel = newItemObj.GetComponent<SelectableItem>();
            #endregion

            //����ͼ��
            await sel.SetupAsync(item.ItemMasterId, item.Count.ToString());

            sel.SetUpLongClick();

            //���ĵ���¼�
            sel.OnClick.Subscribe(()=>
            {  
                onItemSelect(sel);
            }).AddTo(mSubscriptions);

            //�����Ъ��Ʒ�ֵ�
            mItems.Add(item.ItemMasterId, sel);

        }

        //���û����Ʒ��ʾ��ʾ
        notItemObj.SetActive(mItems.Count <= 0);

        //����characterid��������0����ָ����ɫ��-1����ָ����ɫ��
        #region ����characterid �������������
        if (characterId > 0)
        {
            isLocked = true;
            mSelectedCharacterId = characterId;

            ////
            await characterBase.SetupAsync(characterId);
            characterBase.gameObject.SetActive(true);
            // characterBase.Select(true);
            ////
            
            //ѡ�����ߣ�������������߲���ʾ�ˣ�������ѡ��ʱ��������Ʒ��
            onCharacterSelect(characterBase);
        }
        else
        {
            int idx = 0;
            var deltaX = characterBase2.GetComponent<RectTransform>().anchoredPosition.x-characterBase.GetComponent<RectTransform>().anchoredPosition.x;
            var deltaY = characterBase2.GetComponent<RectTransform>().anchoredPosition.y-characterBase.GetComponent<RectTransform>().anchoredPosition.y;
            foreach (var item in DataManager.Instance.Player.Character.GetList())
            {

                #region ��������ͼ��
                SelectableCharacter sel = null;

                var newItemObj = Instantiate(characterBase.gameObject);
                newItemObj.transform.parent = characterBase.transform.parent;
                newItemObj.transform.localScale = Vector3.one;
                newItemObj.transform.localRotation = Quaternion.identity;
                newItemObj.transform.localPosition = Vector3.zero;
                newItemObj.GetComponent<RectTransform>().anchoredPosition = new Vector3(characterBase.GetComponent<RectTransform>().anchoredPosition.x + (idx % 2) * deltaX, characterBase.GetComponent<RectTransform>().anchoredPosition.y + idx * deltaY, 0);
                newItemObj.transform.SetAsFirstSibling();
                newItemObj.SetActive(true);

                sel = newItemObj.GetComponent<SelectableCharacter>();
                #endregion


                //����ͼ��
                await sel.SetupAsync(item.BattleCharacterMasterId);

                //���ĵ���¼�
                sel.OnClick.Subscribe(()=>
                {
                    onCharacterSelect(sel);
                }).AddTo(mSubscriptions);

                //���������ֵ�
                mCharas.Add(item.BattleCharacterMasterId, sel);

                if (idx == 0) 
                    onCharacterSelect(sel);
                idx++;
            }

            characterBase.transform.parent.GetComponent<RectTransform>().sizeDelta = new Vector2(500, -(characterBase.GetComponent<RectTransform>().anchoredPosition.y + idx * deltaY));
        }
        #endregion

        //����Ʒ��һ��ѡ��
        if (mItems.Count > 0)
        {
            onItemSelect(itemBase.transform.parent.GetChild(0).GetComponent<SelectableItem>());
        }

    }


    private void onCharacterSelect(SelectableCharacter sel)
    {
        if (sel.IsSelected) return;

        if (mCharas.ContainsKey(mSelectedCharacterId))
        {
            mCharas[mSelectedCharacterId].Select(false);
        }

        sel.Select(true);

        mSelectedCharacterId = sel.CharacterId;

        AsyncManager.Instance.StartAsync(setupCharacter(mSelectedCharacterId));

        SetBondLevel(mSelectedCharacterId);

        refreshItemList();
    }

    private void SetBondLevel(long characterId)
    {
        var bondValue = DataManager.Instance.Player.Bond.TryGet(characterId);
        int bondLevel = CharacterUtil.CalculateBondLevel(bondValue, out var cur);
        long maxBonds;
        long currentBonds;

        bondLevel = Mathf.Clamp(bondLevel, 0, 8);

        if (DataManager.Instance.Master.BondsLvUp.ContainsKey(bondLevel + 1))
        {
            maxBonds = DataManager.Instance.Master.BondsLvUp[bondLevel + 1].exp;
            currentBonds = cur;
        }
        else
        {
            maxBonds = DataManager.Instance.Master.BondsLvUp[bondLevel].exp;
            currentBonds = maxBonds;
        }



        bondLevelText.SetLabel(LocalizeManager.DATA_TYPE.BOND, bondLevel.ToString());

        bondFillBar.fillAmount = DataManager.Instance.Master.BondsLvUp.ContainsKey(bondLevel + 1) ? currentBonds / (float)DataManager.Instance.Master.BondsLvUp[bondLevel + 1].exp : 1;
        bondFillEffect.anchoredPosition = new Vector2(0, -53 + 110 * bondFillBar.fillAmount);
        slider.value = DataManager.Instance.Master.BondsLvUp.ContainsKey(bondLevel + 1) ? currentBonds / (float)DataManager.Instance.Master.BondsLvUp[bondLevel + 1].exp : 1;

        //bondValueText.SetRawText(string.Format("{0}/{1}", cur, DataManager.Instance.Master.BondsLvUp.ContainsKey(bondLevel + 1) ? DataManager.Instance.Master.BondsLvUp[bondLevel + 1].exp : 0));

        newBondTotalValueText.SetRawText(string.Format("{0}/{1}", currentBonds, maxBonds));

        yuanding.Load("Bond", bondLevel.ToString(), false);
    }

    public async UniTask setupCharacter(long characterId)
    {
        var resourceMaster = DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[characterId].characterResourceId];
        var loadCharacter = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/chara/" + resourceMaster.advModelId);
        var skeletonAnimation = loadCharacter.GetComponent<Spine.Unity.SkeletonAnimation>();
        skeletonAnimation.Initialize(false);
        skeletonAnimation.Update(0.0f);
        skeletonAnimation.LateUpdate();

        mRTCamera.Setup(loadCharacter);
    }

    private void onItemSelect(SelectableItem sel)
    {
        if (sel.IsSelected) return;


        //ȡ������ѡ��
        if (mItems.ContainsKey(mSelectedItemId))
        {
            mItems[mSelectedItemId].Select(false);
        }

        sel.Select(true);
        Debug.Log("selecttrue");
        mSelectedItemId = sel.ItemId;
    }

    private async UniTask UpdateItem()
    {
        if (mItems.ContainsKey(mSelectedItemId))
        {
            mItems[mSelectedItemId].Select(false);
            if(DataManager.Instance.Player.Item.GetCount(mSelectedItemId) > 0)
                await mItems[mSelectedItemId].SetupAsync(mSelectedItemId, DataManager.Instance.Player.Item.GetCount(mSelectedItemId).ToString());
            else
            {
                DestroyImmediate(mItems[mSelectedItemId].gameObject);
                mItems.Remove(mSelectedItemId);
                Debug.Log("destroyed");
                //mItems[mSelectedItemId].gameObject.SetActive(false);
            }
        }
    }

    private void refreshItemList()
    {
        List<long> itemIdList = new List<long>(mItems.Keys);
        //��������ϲ����
        itemIdList.Sort(itemSort);
        for (int i = 0; i < itemIdList.Count; i++)
        {
            var id = itemIdList[i];
            mItems[id].transform.SetSiblingIndex(i);
            var like = getLikeness(mSelectedCharacterId, id);
            mItems[id].transform.Find("fav").gameObject.SetActive(like == 3);
            mItems[id].transform.Find("like").gameObject.SetActive(like == 2);
        }
    }

    private int itemSort(long id_a, long id_b)
    {
        var like_a = getLikeness(mSelectedCharacterId, id_a);
        var like_b = getLikeness(mSelectedCharacterId, id_b);
        if (like_a != like_b) 
            return like_b.CompareTo(like_a);
        return DataManager.Instance.Master.Item[id_a].sortId.CompareTo(DataManager.Instance.Master.Item[id_b].sortId);
    }

    private int getLikeness(long characterId, long itemId)
    {
        var characterMaster = DataManager.Instance.Master.BattleCharacterBond[characterId];

        if (characterMaster.favoriteTeabreak.Contains(itemId)) return 3;
        if (characterMaster.likeTeabreak.Contains(itemId)) return 2;
        if (characterMaster.normalTeabreak.Contains(itemId)) return 1;
        return 0;
    }

    private async UniTask onClickOk()
    {
        #region ������Ʒ������id
        if (mSelectedCharacterId < 0 || mSelectedItemId < 0)
        {
            return;
        }

        DataManager.Instance.Local.Explore.teabreakCharacterId = mSelectedCharacterId;
        DataManager.Instance.Local.Explore.teabreakItemId = mSelectedItemId;
        #endregion

        Debug.Log("mSelectedCharacterId: " + mSelectedCharacterId);
        Debug.Log("characterMasterId: " + DataManager.Instance.Master.BattleCharacter[mSelectedCharacterId].characterMasterId);

 
        //privatetalkcharactermaster�� ͨ��characterMasterid��ȡһ��
        var master = DataManager.Instance.Master.PrivateTalkCharacter[DataManager.Instance.Master.BattleCharacter[mSelectedCharacterId].characterMasterId];

        //��ʼ����adv׼��
        var scriptName = master.scenariosName;

        ScenarioScript script = await ResourceManager.Instance.LoadLocalizeAssetAsync<ScenarioScript>("Scenario/"+scriptName);

        ScriptEngine.GetInstance().LoadScript(scriptName, script);

        MapSceneManager.Instance.HideCurrent();

        await UI.Page.OpenPage<UIAdvPrivateTalkPage>();

        ScriptEngine.GetInstance().SetStartScript(scriptName, null, async (s)=>
        {
            
            Game.Sound.SoundPlayer.PlayBgm("M025");

            if(MapSceneManager.Instance.CurrentScene.player.currentActionObject != null)
                MapSceneManager.Instance.CurrentScene.player.currentActionObject.EndAction();

            await UpdateItem();

            bgObject.SetActive(true);
            itemList.SetActive(false);
            level.SetActive(true);
            SummaryBg.SetActive(true);

            SetBondLevel(mSelectedCharacterId);

            if (!IsOpen())
            {
                finishTeabreak.gameObject.SetActive(true);
            }
            else
            {
                eatMore.gameObject.SetActive(true);
                Debug.Log("set first");
                onItemSelect(itemBase.transform.parent.GetChild(0).GetComponent<SelectableItem>());
            }
        });
    }

    bool IsOpen()
    {
        var items = DataManager.Instance.Player.Item.GetList().Where(item => DataManager.Instance.Master.Content[item.ItemMasterId].contentTypeMasterId == 127).ToArray();

        bool isOpen = false;

        foreach (var item in items)
        {
            if (item.Count != 0)
            {
                isOpen = true;
                break;
            }
        }
        return isOpen;
    }

    private async UniTask onClickCancel()
    {
        await this.HideAsync(UIPageShowType.Back);
        closeClick.Invoke();
    }

    private void onClickEatMore()
    {
        itemList.SetActive(true);
        level.SetActive(false);
        eatMore.gameObject.SetActive(false);
        SummaryBg.SetActive(false);
    }
}
