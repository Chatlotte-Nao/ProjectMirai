﻿using System;
using System.Collections.Generic;

public class PushUpDataFormate
{


    public int CountDownTimer;
    public int AiTargetNumber;
    public int SprintCounter;
    public float AreaPixelLength;
    public float SprintSpeedRate;
    public float IncreaseSpeed;
    public float AreaMinRate;
    public float AreaMaxRate;
    public List<int> AreaAppearDifferentRoundList;
    public Dictionary<int, string> WhichSideDontAppearDic=new Dictionary<int, string>();
    public string CharacterName;
    // public string ActName;
    public string LocalizeName;





    /// <summary>
    /// 
    /// </summary>
    /// <param name="countDownTimer">倒计时时间</param>
    /// <param name="aiTargetNumber">木星完成个数</param>
    /// <param name="sprintCounter">进入冲刺回合数</param>
    /// <param name="areaPixelLength">完成区域的像素长度</param>
    /// <param name="increaseSpeed">区域增加速度</param>
    /// <param name="sprintSpeedRate">冲刺时速度倍率</param>
    /// <param name="areaMinRate">完成区出现区域的最小值0-1</param>
    /// <param name="areaMaxRate">完成区出现区域的最大值0-1</param>
    /// <param name="areaAppearDifferentRoundList">区域高度不同的回合list</param>
    /// <param name="whichSideDontAppearDic">哪个回合哪边不出现区域的dic</param>
    public PushUpDataFormate(
        int countDownTimer,
        int aiTargetNumber, 
        int sprintCounter, 
        float increaseSpeed,
        float sprintSpeedRate, 
        float areaPixelLength,
        float areaMinRate,
        float areaMaxRate,
        List<int> areaAppearDifferentRoundList,
        List<string> whichSideDontAppearDicJson,
        string characterName,
        // string actName,
        string localizeName
        
        
        )
    {

        CountDownTimer = countDownTimer;
        AiTargetNumber = aiTargetNumber;
        SprintCounter = sprintCounter;
        IncreaseSpeed = increaseSpeed;
        SprintSpeedRate = sprintSpeedRate;
        AreaPixelLength = areaPixelLength;
        AreaMinRate = areaMinRate;
        AreaMaxRate = areaMaxRate;
        
        AreaAppearDifferentRoundList = areaAppearDifferentRoundList;
        WhichSideDontAppearDic = List2Dic(whichSideDontAppearDicJson);
        
        CharacterName = characterName;
        // ActName = actName;
        LocalizeName = localizeName;

    }


    //public PushUpDataFormate()
    //{
    //    CountDownTimer = 0;
    //    AiTargetNumber = 0;
    //    AreaPixelLength = 20f;
    //    AreaMaxRate = 0.1f;
    //    AreaMinRate = 0.1f;
    //    AreaAppearDifferentRoundList = new List<int>();
    //    WhichSideDontAppearDic = new Dictionary<int, string>();
    //}
    


    Dictionary<int,string> List2Dic(List<string> list)
    {
        Dictionary<int, string> tempDic=new Dictionary<int, string>();
        foreach (var item in list)
        {
            int key = Convert.ToInt32(item.Split('_')[0]);
            string value = item.Split('_')[1];
            tempDic.Add(key, value);
        }
        return tempDic;
    } 
}
