﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;
using System;
using Spine.Unity;
using DG.Tweening;
using Map;
using TMPro;

public class UIPushUpMainWindow : UIDialogBase
{
    [Space(10)]
    [SerializeField] GameObject gameOverHintPanel;
    [SerializeField] GameObject tutorialPanel;

    [Space(10)]
    [SerializeField] UIButton leftButton;
    [SerializeField] UIButton rightButton;
    [SerializeField] UIButton gameOverHintButton;
    [SerializeField] UIButton tutorialCloseButton;
    [SerializeField] UIButton skipButton;


    [Space(10)]
    [SerializeField] Image rightProcessBar;
    [SerializeField] Image leftProcessBar;
    [SerializeField] Image rightSuccArea;
    [SerializeField] Image leftSuccArea;

    [Space(10)]
    [SerializeField] UIText textTimerText;
    [SerializeField] UIText lNameText;
    [SerializeField] UIText rNameText;
    [SerializeField] UIText lCounterText;
    [SerializeField] UIText rCounterText;


    [Space(10)]
    [SerializeField] SkeletonGraphic jupiterSkeleton;
    [SerializeField] SkeletonGraphic playerSkeleton;
    public string JupiterAnimationName;
    public string PlayerAnimationName;



    public float normalSpeed;
    public float succSpeed;
    public float succTime;


    public UnityEvent OnCancel => skipButton.OnTouchUpInside;

    public UnityEvent OnComplete =new UnityEvent();
    public UnityEvent OnPuzzleFailed =new UnityEvent();
    public bool GameSuccesOver = false;


    private PushUpDataFormate PushUpData;



    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        
        InitBtnFunc();

        // skipButton.OnTouchUpInside.GuardSubscribeAsync(onClose).AddTo(mSubscriptions);

    }


    public async UniTask onClose()
    {
        await UI.Page.CloseCurrentPage();
    }
    private void InitBtnFunc()
    {
        leftButton.onClickDown.AddListener(leftButtonClickBegin);
        leftButton.onClickUp.AddListener(leftButtonClickEnd);
        rightButton.onClickDown.AddListener(rightButtonClickBegin);
        rightButton.onClickUp.AddListener(rightButtonClickEnd);

    }


    public async UniTask Setup(int levelID)
    {
        //读表
        await SetData(levelID);
    
        
        
    }




    async UniTask SetData(int levelID)
    {
        var data =DataManager.Instance.Master.PushUp.Values;

        foreach (var item in data)
        {
            if (item.levelID == levelID)
            {
                PushUpDataFormate dataFormate = new PushUpDataFormate(
                    item.CountDownTimer, 
                    item.AiTargetNumber,
                    item.SprintCounter,
                    item.IncreaseSpeed / 10,
                    item.SprintSpeedRate / 10,
                    item.AreaPixelLength,
                    item.AreaMaxRate / 100, 
                    item.AreaMinRate / 100,
                    item.AreaAppearDifferentRoundList,
                    item.WhichSideDontAppearDicJson,
                    item.characterName,
                    // item.actName,
                    item.localizeName
                    );
                PushUpData = dataFormate;
                break;
            }

            //break;
        }
        
    }

    // private PushUpDataFormate Test_SetData()//test
    // {
    //
    //     List<int> AreaAppearDifferentRoundList = new List<int> { 1, 3, 4, 11 };
    //     List<string> WhichSideDontAppearDicJson = new List<string> { "1_L", "5_R", "7_R" };
    //     PushUpDataFormate dataFormate = new PushUpDataFormate(30, 10, 3, 1f, 2f, 70, 0.3f, 0.8f, AreaAppearDifferentRoundList, WhichSideDontAppearDicJson);
    //     return dataFormate;
    // }








    #region Controller



    IEnumerator Time()
    {
        while (PushUpData.CountDownTimer >= 0)
        {
            var tempTime = FormatTime(PushUpData.CountDownTimer);
            textTimerText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, tempTime);
            yield return new WaitForSeconds(1);
            PushUpData.CountDownTimer--;
            if (PushUpData.CountDownTimer <= 0f)
            {
                GameOver();
            }
        }
    }

    int round = 1;
    float LSuccTop, RSuccTop, LSuccBot, RSuccBot;
    float ProcessBarSize;

    private async void Start()
    {
        InitData();
        ReInitArea();
        
        var co = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Map/MiniCharacter/"+PushUpData.CharacterName);
        // var co = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Map/MiniCharacter/"+"MiniCharaMoonlight");
        co.transform.SetParent(jupiterSkeleton.transform);
        jupiterSkeleton.skeletonDataAsset =
            co.transform.GetChild(1).GetComponent<SkeletonAnimation>().skeletonDataAsset;
        lNameText.SetLabel(LocalizeManager.DATA_TYPE.EXPLORE,PushUpData.LocalizeName);
        // JupiterAnimationName = PushUpData.ActName;
        jupiterSkeleton.Update();
        jupiterSkeleton.startingAnimation = JupiterAnimationName;
        playerSkeleton.startingAnimation = PlayerAnimationName;
        jupiterSkeleton.UpdateMesh();
        jupiterSkeleton.enabled = true;
        jupiterSkeleton.gameObject.SetActive(true);
        playerSkeleton.gameObject.SetActive(true);
        jupiterSkeleton.Update();

        //ShowTuorialPanel();
    }

    async void ShowTuorialPanel()
    {
        tutorialPanel.SetActive(true);
        tutorialCloseButton.onClick.AddListener((o)=>
        {
            tutorialPanel.SetActive(false);
        });
        //throw new NotImplementedException();
    }
    





    void InitData()
    {

        //lNameText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "jupiter");
        //rNameText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "player");
        rCounterText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "0");
        lCounterText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "0");

        var tempTime = FormatTime(PushUpData.CountDownTimer);
        textTimerText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, tempTime);
        SprintCounter = 0;
        defaultSpeed = PushUpData.IncreaseSpeed;
        leftSuccArea.GetComponent<RectTransform>().sizeDelta = new Vector2(0, PushUpData.AreaPixelLength);
        rightSuccArea.GetComponent<RectTransform>().sizeDelta = new Vector2(0, PushUpData.AreaPixelLength);
        ProcessBarSize = leftSuccArea.gameObject.transform.parent.GetComponent<RectTransform>().sizeDelta.y;

    }




    void ReInitArea()
    {



        leftButton.enabled = true;
        leftSuccArea.gameObject.SetActive(true);
        rightButton.enabled = true;
        rightSuccArea.gameObject.SetActive(true);
        if (PushUpData.WhichSideDontAppearDic.ContainsKey(round))
        {
            switch (PushUpData.WhichSideDontAppearDic[round])
            {
                case "L":
                    leftButton.enabled = false;
                    leftSuccArea.gameObject.SetActive(false);
                    break;
                case "R":
                    rightButton.enabled = false;
                    rightSuccArea.gameObject.SetActive(false);
                    break;

            }
        }







        float LAreaHeight = UnityEngine.Random.Range(PushUpData.AreaMinRate, PushUpData.AreaMaxRate) * leftProcessBar.transform.parent.GetComponent<RectTransform>().sizeDelta.y;
        float RAreaHeight;
        if (PushUpData.AreaAppearDifferentRoundList.Contains(round))
        {
            RAreaHeight = UnityEngine.Random.Range(PushUpData.AreaMinRate, PushUpData.AreaMaxRate) * leftProcessBar.transform.parent.GetComponent<RectTransform>().sizeDelta.y;
        }
        else
        {
            RAreaHeight = LAreaHeight;
        }


        LSuccBot = LAreaHeight - PushUpData.AreaPixelLength / 2f;
        LSuccTop = LAreaHeight + PushUpData.AreaPixelLength / 2f;

        RSuccTop = RAreaHeight + PushUpData.AreaPixelLength / 2f;
        RSuccBot = RAreaHeight - PushUpData.AreaPixelLength / 2f;
        leftSuccArea.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, LAreaHeight);
        rightSuccArea.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, RAreaHeight);

        Tween tween = DOTween.To(() => leftProcessBar.fillAmount, x => leftProcessBar.fillAmount = x, 0, 0.2f);
        Tween tween2 = DOTween.To(() => rightProcessBar.fillAmount, x => rightProcessBar.fillAmount = x, 0, 0.2f);

    }



    void Update()
    {
        //KeyBoradInput();
        RoundCheack();

    }

    void KeyBoradInput()
    {


        RoundCheack();
        if (Input.GetKeyDown(KeyCode.A))
        {
            leftButton.OnTouchDown.Invoke();
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            rightButton.OnTouchDown.Invoke();
        }
        if (Input.GetKeyUp(KeyCode.A))
        {
            leftButton.OnTouchUpInside.Invoke();
        }
        if (Input.GetKeyUp(KeyCode.D))
        {
            rightButton.OnTouchUpInside.Invoke();
        }
        if (Input.GetKeyDown(KeyCode.G))
        {
            GameOver();
        }

        //if (Input.GetKeyDown(KeyCode.P))
        //{
        //    Debug.Log("aa");
        //    jupiterSkeleton.AnimationState.SetAnimation(0, "eat_01", false);
        //    //jupiterSkeleton.SetAnimation(0, "eat_01", false);
        //    //DataManager.Instance.Master.WordPuzzle[1].desc;
        //}


    }

    //sprin

    public static string FormatTime(float seconds)
    {
        TimeSpan ts = new TimeSpan(0, 0, Convert.ToInt32(seconds));
        string str = "";

        if (ts.Hours > 0)
        {
            str = ts.Hours.ToString("00") + ":" + ts.Minutes.ToString("00") + ":" + ts.Seconds.ToString("00");
        }
        if (ts.Hours == 0 && ts.Minutes > 0)
        {
            str = ts.Minutes.ToString("00") + ":" + ts.Seconds.ToString("00");
        }
        if (ts.Hours == 0 && ts.Minutes == 0)
        {
            str = "00:" + ts.Seconds.ToString("00");
        }

        return str;
    }



        int PlayerSuccCounter = 0;
    int SprintCounter;
    void PlayerGetPointCheack(bool isSucc)
    {
        if (isSucc)
        {
            
            SprintCounter++;
            //playerSkeleton.AnimationState.SetAnimation(0, PlayerAnimationName, true);//TODO替换主角动画
            playerSkeleton.AnimationState.TimeScale = 3f;
            Tween tween = DOTween.To(() => playerSkeleton.AnimationState.TimeScale, x => playerSkeleton.AnimationState.TimeScale = x, succSpeed, succTime);
            tween.onComplete += () =>
            {
                Tween tween2 = DOTween.To(() => playerSkeleton.AnimationState.TimeScale, x => playerSkeleton.AnimationState.TimeScale = x, normalSpeed, succTime);
            };

            //Tweener tweener=new Tween()
            Debug.Log("冲刺连胜:" + SprintCounter);
            if (SprintCounter >= PushUpData.SprintCounter)
            {
                Debug.Log("进入冲刺");
                EnterSprintMode();
            }
            PlayerSuccCounter++;
            //float tempTime=FormatTime()
            rCounterText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, PlayerSuccCounter.ToString());

        }
        else
        {
            SprintCounter = 0;
            Debug.Log("冲刺连胜结束:" + SprintCounter);
            ExitSprintMode();
            playerSkeleton.AnimationState.TimeScale = normalSpeed;

        }
    }

    float defaultSpeed;
    void EnterSprintMode()
    {
        PushUpData.IncreaseSpeed = defaultSpeed * PushUpData.SprintSpeedRate;

    }
    void ExitSprintMode()
    {

        PushUpData.IncreaseSpeed = defaultSpeed;
    }





    private void RoundCheack()
    {

        if (rightSucc == "t" && leftSucc == "t")
        {
            Debug.Log("回合成功");
            rightSucc = "idle";
            leftSucc = "idle";
            PlayerGetPointCheack(true);

            NextRound();

        }
        if (rightSucc == "t" && leftButton.enabled==false)
        {
            Debug.Log("回合成功");
            rightSucc = "idle";
            leftSucc = "idle";
            PlayerGetPointCheack(true);

            NextRound();
        }
        if (leftSucc == "t" && rightButton.enabled==false)
        {
            Debug.Log("回合成功");
            rightSucc = "idle";
            leftSucc = "idle";
            PlayerGetPointCheack(true);

            NextRound();
        }
        if (rightSucc == "f")
        {

            Debug.Log("失败");
            rightSucc = "idle";
            leftSucc = "idle";
            PlayerGetPointCheack(false);

            NextRound();

        }
        if (leftSucc == "f")
        {

            Debug.Log("失败");
            rightSucc = "idle";
            leftSucc = "idle";

            PlayerGetPointCheack(false);
            NextRound();

        }
    }

    bool roundSucc = false;
    private void NextRound()
    {
        round++;
        Debug.Log("round:" + round);
        ReInitArea();
        roundSucc = false;
        // throw new NotImplementedException();
    }

    bool IsNormalRound()
    {
        return !PushUpData.WhichSideDontAppearDic.ContainsKey(round);
    }

    async UniTask GameOver()
    {
        Gaming = false;
        GameSuccesOver=PlayerSuccCounter > AiSuccCounter ? true :false;
        if (PlayerSuccCounter > AiSuccCounter)
        {
            Debug.Log("succ over");
            GameSuccesOver = true;
        }

        else
        {
            Debug.Log("fail over");
            GameSuccesOver = false;
        }

        ShowGameOverHintPanel();
        await UniTask.WaitUntil(gameOverHintButtonClicked);
        if (GameSuccesOver)
        {
            Debug.Log(GameSuccesOver);
            OnComplete.Invoke();
        }
        else
        {            
            Debug.Log(GameSuccesOver);
            OnPuzzleFailed.Invoke();
        }
        Hide();
    }


    bool ClickedGameOverBtn = false;

    bool gameOverHintButtonClicked()
    {
        return ClickedGameOverBtn;
    }


    void ShowGameOverHintPanel()
    {
        
        gameOverHintButton.onClick.AddListener((o)=> 
        {
            ClickedGameOverBtn = true;

        });
        gameOverHintPanel.SetActive(true);
        if (GameSuccesOver)
        {
            
            gameOverHintPanel.transform.GetChild(0).GetChild(1).GetComponent<UIText>().SetLabel(LocalizeManager.DATA_TYPE.COMMON, "时间到");
        }
        else
        {
            gameOverHintPanel.transform.GetChild(0).GetChild(1).GetComponent<UIText>().SetLabel(LocalizeManager.DATA_TYPE.COMMON, "失败");
        }
        var canvansGroup = gameOverHintPanel.GetComponent<CanvasGroup>();
        //TODO播放哨声
        //Game.Sound.SoundPlayer.PlaySe(SoundConstants.)
        Tween tween = DOTween.To(() => canvansGroup.alpha, x => canvansGroup.alpha = x, 1, 2);
        RectTransform border = gameOverHintPanel.transform.GetChild(0).GetComponent<RectTransform>();
        Tween tween2 = DOTween.To(() => border.localPosition, x => border.localPosition = x, Vector3.zero, 1);
        tween2.SetEase(Ease.InOutBack);
        //tween.onComplete += () =>
        // {
        // };

    }






    private void rightButtonClickBegin(Vector2 vector2)
    {

        GameStart();
        rightProcessBar.fillAmount = 0;
        StartCoroutine("rightFillBarAdd");
    }

    private void rightButtonClickEnd(Vector2 vector2)
    {
        StopCoroutine("rightFillBarAdd");
        IsGetPoint("r");
    }

    private void leftButtonClickBegin(Vector2 vector2)
    {

        GameStart();
        leftProcessBar.fillAmount = 0;
        StartCoroutine("leftFillBarAdd");

    }

    private void leftButtonClickEnd(Vector2 vector2)
    {

        StopCoroutine("leftFillBarAdd");
        IsGetPoint("l");


    }


    string leftSucc;
    string rightSucc;
    private bool IsGetPoint(string side)
    {
        if (side == "l")
        {
            if (leftProcessBar.fillAmount * ProcessBarSize < LSuccTop && leftProcessBar.fillAmount * ProcessBarSize > LSuccBot)
            {
                Debug.Log("左边成功");
                leftSucc = "t";

            }
            else
            {

                Debug.Log("左边失败");
                leftSucc = "f";

            }
        }

        if (side == "r")
        {

            if (rightProcessBar.fillAmount * ProcessBarSize < RSuccTop && rightProcessBar.fillAmount * ProcessBarSize > RSuccBot)
            {
                Debug.Log("右边成功");
                rightSucc = "t";
            }
            else
            {
                Debug.Log("右边失败");
                rightSucc = "f";
            }
        }

        return false;
        // throw new NotImplementedException();
    }






    IEnumerator leftFillBarAdd()
    {
        while (PushUpData.CountDownTimer >= 0)
        {
            //TODO 播放蓄力条上升音效
            yield return new WaitForSeconds(0.01f);
            leftProcessBar.fillAmount += 0.03f*PushUpData.IncreaseSpeed;
        }
    }

    IEnumerator rightFillBarAdd()
    {
        while (PushUpData.CountDownTimer >= 0)
        {

            //TODO 播放蓄力条上升音效
            yield return new WaitForSeconds(0.01f);
            rightProcessBar.fillAmount += 0.03f * PushUpData.IncreaseSpeed;

        }
    }





    bool Gaming = false;
    public void GameStart()
    {
        if (!Gaming)
        {
            Gaming = true;
            StartCoroutine(Time());
            DefaultTimer = PushUpData.CountDownTimer;
            StartCoroutine("PlayOpponentAnimation");
            //TODO 显示游戏开始图片

        }



    }
    float DefaultTimer;


    int AiSuccCounter=0;
    IEnumerator PlayOpponentAnimation()
    {
        while (Gaming)
        {
            yield return new WaitForSeconds((float)DefaultTimer / (float)PushUpData.AiTargetNumber);
            Debug.Log(DefaultTimer + "detimer");
            Debug.Log(PushUpData.AiTargetNumber + "AiTargetNumber");
            //jupiterSkeleton.AnimationState.SetAnimation(0, JupiterAnimationName, false);
            if (!Gaming) break;

            AiSuccCounter++;
            
            lCounterText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, AiSuccCounter.ToString());
        }
    }






    #endregion
}
