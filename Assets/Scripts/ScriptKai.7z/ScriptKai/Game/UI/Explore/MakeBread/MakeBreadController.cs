﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;
using TMPro;
using Pheonix.Core;
using UnityEngine.EventSystems;
using Spine.Unity;
using UnityEngine.UI;
public class MakeBreadController : MonoBehaviour
{
    [SerializeField] List<Button> items = new List<Button>();
    [SerializeField] Button endItem;
    [SerializeField] Button lastItem;
    [SerializeField] UIMakeBreadMainWindow mannWindow;
    [SerializeField] GameObject panel;
    GameObject initPoint;
    GameObject miniCharacter;

    bool[] isClick;
    public static MakeBreadController instance;
    bool clickOnce = false;
    Camera cam;

    private void Awake()
    {
        instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        isClick = new bool[items.Count];
        miniCharacter = MapSceneManager.Instance.CurrentScene.player.gameObject;
        initPoint = GameObject.Find("wing_1_2_table0");
        cam = MapSceneManager.Instance.CurrentScene.GetCameraController().GetCamera();

        Vector2 pos;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(panel.GetComponent<RectTransform>(), cam.WorldToScreenPoint(initPoint.transform.position + new Vector3(-0.1f, .7f, 0)), SceneBase.Current.UICamera, out pos);
        panel.GetComponent<RectTransform>().anchoredPosition = pos;

    }

    public void OnClickItem(int index)
    {


        items[index].enabled = false;
        isClick[index] = true;
        AsyncManager.Instance.StartAsync(ChangeAnimationAsync("walk_01"));
        for (int i = 0; i < isClick.Length; i++)
        {
            if (!isClick[i])
                return;
        }
        endItem.enabled = true;



    }
    public void SetUpData(int levelId)
    {

    }
    public void OnClick()
    {

        if (!clickOnce)
        {
            //大碗消失
            endItem.gameObject.SetActive(false);
            lastItem.gameObject.SetActive(true);
            //播动画s
            for (int i = 0; i < items.Count; i++)
            {
                items[i].gameObject.SetActive(false);
            }
            AsyncManager.Instance.StartAsync(ChangeAnimationAsync("walk_01"));
            clickOnce = true;
        }
        else
        {
            //播动画
            AsyncManager.Instance.StartAsync(ChangeAnimationAsync("walk_01"));
            lastItem.gameObject.SetActive(false);
            //面团消失
            AsyncManager.Instance.StartAsync(CameraMove());

            mannWindow.OnComplete.Invoke();
            //托盘子动作
            // miniCharacter.AnimationState.SetAnimation();

        }

    }

    public async UniTask ChangeAnimationAsync(string ani)
    {
        miniCharacter.GetComponentInChildren<SkeletonAnimation>().state.SetAnimation(0, ani, false);


        await UniTask.Delay(1000);
        miniCharacter.GetComponentInChildren<SkeletonAnimation>().state.SetAnimation(0, "wait_01", false);
    }
    public async UniTask CameraMove()
    {
        await UniTask.Delay(1000);
        if (cam != null)
        {
            while (cam.orthographicSize < 4.6f)
            {
                float lerpnum = Mathf.Lerp(cam.orthographicSize, 4.6f, 0.5f);
                cam.orthographicSize = lerpnum;
                await UniTask.Delay(10);
            }
        }

    }
}
