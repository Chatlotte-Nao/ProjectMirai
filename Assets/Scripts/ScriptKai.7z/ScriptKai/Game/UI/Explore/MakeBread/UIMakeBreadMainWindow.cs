﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;

public class UIMakeBreadMainWindow : UIDialogBase
{
    

    public UnityEvent OnComplete = new UnityEvent();



    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }

    public async UniTask Setup(int levelId)
    {

        MakeBreadController.instance.SetUpData(levelId);
    }
}
