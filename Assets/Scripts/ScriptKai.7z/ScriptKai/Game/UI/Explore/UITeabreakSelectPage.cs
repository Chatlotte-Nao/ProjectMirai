using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UITeabreakSelectPage : UIPageBase
{
    private UITeabreakSelectDialog mainWindow = null;

    public class PageParam
    {
        public long selectCharacterId = -1;
        public bool isPlayEnd = false;
        public PageParam(long id)
        {
            selectCharacterId = id;
        }
    }

    private bool isPlayEnd = false;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync();

        mainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UITeabreakSelectDialog, CanvasType.App0) as UITeabreakSelectDialog;
        mainWindow.closeClick.GuardSubscribeAsync(ClosePage).AddTo(mSubscriptions);
        if (param != null)
        {
            var p = param as PageParam;
            isPlayEnd = p.isPlayEnd;
            await mainWindow.Setup(p.selectCharacterId);
        }
        else
        {
            await mainWindow.Setup(-1);
        }


    }
    public override async UniTask ShowAsync(UIPageShowType showType)
    {
            await mainWindow.ShowAsync();
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        if (mainWindow != null)
        {
            await mainWindow.HideAsync(showType);
        }
    }
    private async UniTask ClosePage()
    {
        if(MapSceneManager.Instance.CurrentScene.player.currentActionObject != null)
            MapSceneManager.Instance.CurrentScene.player.currentActionObject.EndAction();
        if (!isPlayEnd)
        {
            await UI.ScreenEffect.Fade(1);
            ((HomeMapLogic) MapSceneManager.Instance.CurrentLogic).UpdateCharacterInfo();
            await ((HomeMapLogic) MapSceneManager.Instance.CurrentLogic).EndFollow();
            await UI.ScreenEffect.Fade(0);
        }

        MapSceneManager.Instance.ShowCurrent();

        if (isPlayEnd)
        {
            await MapSceneManager.Instance.CurrentScene.MovePlayerRoutePointAsync("2F_route (5)");
            await UI.ScreenEffect.Fade(1);
            await ((HomeMapLogic) MapSceneManager.Instance.CurrentLogic).EndFollow();
            await UI.ScreenEffect.Fade(0);
        } 
        await UI.Page.CloseCurrentPage(true);
     
    }
    public override void Dispose()
    {
        base.Dispose();

        if (mainWindow != null)
        {
            mainWindow.Dispose();
            mainWindow = null;
        }
    }
}
