using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.Events;

public class MusicJukeboxCell : MonoBehaviour
{
    [SerializeField] private UIButton playBtn;
    [SerializeField] private UIText nameTxt;
    [SerializeField] private UIText playTxt;
    [SerializeField] private GameObject noPlayObj;
    [SerializeField] private GameObject playObj;

    public UnityEvent OnClick => playBtn.OnTouchUpInside;

    private long _masterId;
    private string playTitle;
    private string timeName;

    public async UniTask SetUpAsync(ItemMaster master,bool isPlayer = false)
    {
        playTxt.gameObject.SetActive(false);
        var musicName = master.musicName;
        _masterId = master.id;
        playTitle = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "Play_Music");
        timeName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ITEM, $"{master.id}_name");
        nameTxt.SetRawText(timeName);
        playTxt.SetRawText(playTitle + timeName);

        playTxt.gameObject.SetActive(true);


        var cuname = Game.Sound.SoundPlayer.GetBgmName();

        if (string.IsNullOrEmpty(cuname))
        {
            playObj.SetActive(false);
            noPlayObj.SetActive(true);
        }
        else
        {
            if (Game.Sound.SoundPlayer.GetBgmName().Equals(master.musicName))
            {
                playObj.SetActive(true);
                noPlayObj.SetActive(false);
            }
            else
            {
                playObj.SetActive(false);
                noPlayObj.SetActive(true);
            }
        }

        if (isPlayer)
        {
            playObj.SetActive(true);
            noPlayObj.SetActive(false);
        }
    }

    public void SetPlayInfo(long masterId)
    {
        noPlayObj.SetActive(_masterId != masterId);
        playObj.SetActive(_masterId == masterId);
    }
}