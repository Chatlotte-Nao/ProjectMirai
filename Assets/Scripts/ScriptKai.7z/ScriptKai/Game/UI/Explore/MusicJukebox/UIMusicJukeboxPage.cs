using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;

public class UIMusicJukeboxPage : UIPageBase
{
    private UIMusicJukeboxDialog _musicJukeboxDialog = null;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        _musicJukeboxDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMusicJukeboxDialog, CanvasType.App0) as UIMusicJukeboxDialog;
        _musicJukeboxDialog.CloseClick.GuardSubscribeAsync(CloseClick).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
        await UniTask.Yield();
        await _musicJukeboxDialog.ShowAsync();
    }

    private async UniTask CloseClick(GameObject o)
    {
        await UI.Page.CloseCurrentPage(true);
    }
    
    public override void Dispose()
    {
        base.Dispose();
        if (_musicJukeboxDialog != null)
        {
            _musicJukeboxDialog.Dispose();
            _musicJukeboxDialog = null;
        }
    }
}
