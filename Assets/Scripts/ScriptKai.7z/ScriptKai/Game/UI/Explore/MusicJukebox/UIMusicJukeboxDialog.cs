using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using System.Linq;
using UnityEngine.UI;

public class UIMusicJukeboxDialog : UIDialogBase
{
    [SerializeField] private MusicJukeboxCell playCell;
    [SerializeField] private MusicJukeboxCell prefab;
    [SerializeField] private RectTransform rectTransform;
    [SerializeField] private UIButton closeBtn;
    [SerializeField] private ScrollRect rect;
    [SerializeField] private GameObject bg;
    
    public ClickEvent CloseClick => closeBtn.onClick;
    private List<MusicJukeboxCell> cells = new List<MusicJukeboxCell>();

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        var musicsId = DataManager.Instance.Player.Item.GetList()
            .Where(a => DataManager.Instance.Master.Item[a.ItemMasterId].contentType == 126).ToArray();
        foreach (var cell in cells)
        {
            cell.gameObject.SetActive(false);
            cell.OnClick.RemoveAllListeners();
        }
        bg.SetActive(false);
        for (int i = 0; i < musicsId.Length; i++)
        {
            var item = musicsId[i];
            var master = DataManager.Instance.Master.Item[item.ItemMasterId];
            if (master.musicName.Equals(Game.Sound.SoundPlayer.GetBgmName()))
            {
                await playCell.SetUpAsync(master,true);
                bg.SetActive(true);
            }
            if (i < cells.Count)
            {
                await cells[i].SetUpAsync(master);
                await UniTask.Yield();
                cells[i].gameObject.SetActive(true);
                cells[i].OnClick.GuardSubscribeAsync(async() => { await PlayMusic(master);}).AddTo(mSubscriptions);
            }
            else
            {
                var button = Instantiate(prefab, this.rectTransform, false);
                await button.SetUpAsync(master);
                button.OnClick.GuardSubscribeAsync(async() => { await PlayMusic(master);}).AddTo(mSubscriptions);
                await UniTask.Yield();
                button.gameObject.SetActive(true);
                cells.Add(button);
            }
        }
     
    }

    private bool isPlay = false;
    public async UniTask PlayMusic(ItemMaster master)
    {
        Log.Debug(master.musicName);
        Game.Sound.SoundPlayer.PlayBgm(master.musicName);
        bg.SetActive(true);
        await playCell.SetUpAsync(master,true);
        foreach (var cell in cells)
        {
            cell.SetPlayInfo(master.id);
        }
        SetRoomEffActive();
        isPlay = true;
    }

    void SetRoomEffActive()
    {
        if (isPlay) return;
        var rooms = MapSceneManager.Instance.CurrentScene.staticObjects["MusicJukebox"];
        rooms.SetState(1);
    }

    private float time = 0;
    private bool isStart = false;
    private void Update()
    {
        if (playCell.gameObject.activeSelf)
        {
            time += Time.time;
            if (time > 0.1f)
            {
                if (rect.horizontalNormalizedPosition > 1.0f)
                {
                    rect.horizontalNormalizedPosition = 0;
                }
                rect.horizontalNormalizedPosition = rect.horizontalNormalizedPosition + 0.005f;
                time = 0;
            }
        }
    }

}
