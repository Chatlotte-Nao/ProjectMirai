﻿using Pheonix.Core;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIInteractiveSecondDialog : UIDialogBase
{
    public  static bool SecondTime=false;
    [SerializeField] private GameObject interactiveSecondButtonBase;
    [SerializeField] private Sprite highlightSprite;
    [SerializeField] private UIButton closeArea;
    public UnityEvent Close;
    public UnityEvent teabreakClick = new UnityEvent();
    private ExploreEventViewModel eventModel;

    private string interactiveTargetId;
    private bool ongoing = false;

    public async UniTask SetUp(string interactiveTargetId)
    {
        closeArea.OnTouchUpInside.Subscribe(Handler).AddTo(mSubscriptions);
        var buttonDic = new Dictionary<string, UIButton>();
        UIButton teabreakButton = null;//茶歇相关
        
        this.interactiveTargetId = interactiveTargetId;
        var master = DataManager.Instance.Master.InteractiveButtonMaster;
        var secondaryInteractiveButtonIds =
            master.FirstOrDefault(pair => pair.Value.interactiveTargetId == interactiveTargetId).Value
                .secondaryInteractiveButtonId;
        if (secondaryInteractiveButtonIds == null)
        {
            Debug.LogError("InteractiveButtonMaster找不到" + interactiveTargetId);
            return;
        }


        foreach (var interactiveButtonId in secondaryInteractiveButtonIds)
        {
            var button = Instantiate(interactiveSecondButtonBase, interactiveSecondButtonBase.transform.parent);
            button.gameObject.name = interactiveButtonId;
            button.gameObject.SetActive(true);
            button.GetComponentInChildren<UIText>().SetLabel(LocalizeManager.DATA_TYPE.EXPLORE, interactiveButtonId);
            var tempinteractiveButtonId = interactiveButtonId;
            var tempUIButton = button.GetComponentInChildren<UIButton>();
            buttonDic.Add(interactiveButtonId,tempUIButton);
            tempUIButton.OnTouchUpInside.GuardSubscribeAsync(
                async () => { await Call(tempinteractiveButtonId); }
            ).AddTo(mSubscriptions);
            if (interactiveButtonId == "Command_TeaBreak")teabreakButton = button.GetComponentInChildren<UIButton>();//存一下茶歇的按钮
        }


        #region 判断是否有新邀约

        var data = DataManager.Instance.Local.Explore.playerData;
        var sortedList = new List<ExploreEventViewModel>(data.eventList.Values);
        var list = new List<ExploreEventViewModel>();
        foreach (var item in sortedList)
        {
            if (item.Master.battleCharacterMasterId.ToString() == interactiveTargetId)
            {
                list.Add(item);
            }
        }

        foreach (var Model in list)
        {
            ongoing = Model.eventStatus == ExploreEventViewModel.EventStatus.Accepted;
            if (Model.finishCount == 0 && Model.CanStart())
            {
                eventModel = Model;
                break;
            }
        }

        if (eventModel != null)
        {
            var button = Instantiate(interactiveSecondButtonBase, interactiveSecondButtonBase.transform.parent);
            button.gameObject.name = "Command_Invite";
            button.transform.SetSiblingIndex(0);
            button.gameObject.SetActive(true);
            button.transform.GetChild(0).GetComponent<Image>().sprite = highlightSprite;
            var tempUIButton = button.GetComponentInChildren<UIButton>();
            buttonDic.Add("Command_Invite",tempUIButton);
            button.GetComponentInChildren<UIText>()
                .SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{eventModel.masterId}_title");
            tempUIButton.OnTouchUpInside.AddListener(async () =>
                {
                    UIExploreEventCheckOutDialog checkOutDialog =
                        await UI.Dialog.CreateAndShowAsync(UIPrefabId.UIExploreEventCheckOutDialog, CanvasType.App1) as
                            UIExploreEventCheckOutDialog;
                    await checkOutDialog.SetupAsync(eventModel,
                        UIExploreEventCheckOutDialog.ExplorEventCheckOutType.invite,
                        !ongoing);
                }
            );
        }

        #endregion

        #region 判断茶歇是否有新关键词 有的话改变按钮颜色

        if (buttonDic.ContainsKey("Command_TeaBreak"))
        {
            //判断茶歇是否有新关键词
            List<int> masterKeys = new List<int>();
            List<int> type0Keywords = new List<int>();
            List<int> type1Keywords = new List<int>();
            var playerBattleCharacter = DataManager.Instance.Player.Character.TryGet(long.Parse(interactiveTargetId));
            var isContract = !(playerBattleCharacter.Engaged == 0);
            long characterMasterId = 0;

            foreach (var kv in DataManager.Instance.Master.PrivateTalk)
            {
                if (kv.Value.battleCharacterMasterId == long.Parse(interactiveTargetId))
                {
                    characterMasterId = kv.Value.characterMasterId;
                    masterKeys.Add(DataManager.Instance.Master.PrivateTalk[kv.Key].keywordId);
                }
            }

            foreach (var keywordId in masterKeys)
            {
                var keywordMaster = DataManager.Instance.Master.Keyword[keywordId];
                if (keywordMaster.type == 0)
                {
                    type0Keywords.Add(keywordId);
                }
                else if (keywordMaster.type == 1)
                {
                    type1Keywords.Add(keywordId);
                }
            }

            bool HasNewKeyword = false;

            foreach (var keywordId in masterKeys)
            {
                var keywordMaster = DataManager.Instance.Master.Keyword[keywordId];

                if (isKeywordLocked())
                {
                    continue;
                }

                if (isReaded(keywordId, characterMasterId))
                {
                    continue;
                }
                else
                {
                    HasNewKeyword = true;
                    break;
                }

                #region 茶歇local函数

                bool isKeywordLocked()
                {
                    return (type0Keywords.Contains(keywordId) && (keywordMaster.level > GetBondsLevel()) ||
                            (keywordMaster.level >= 4 && !isContract)) || (type1Keywords.Contains(keywordId) &&
                                                                           DataManager.Instance.Player.Keyword.TryGet(
                                                                               keywordId) == null);
                }

                #endregion
            }

            if (!IsTeaBreakOpen())
            {
                HasNewKeyword = false;
            }

            Debug.Log(HasNewKeyword);

            if (HasNewKeyword)
            {
                teabreakButton.GetComponent<Image>().sprite = highlightSprite;
            }
        }

        #endregion

        
        #region 按钮阶段开放相关
        //lockConditionId
        var functionMaster = DataManager.Instance.Master.InteractiveButtonFunctionMaster;
        foreach (var kv in buttonDic)
        {
            if (functionMaster.ContainsKey(kv.Key))
            {
                var lockId = functionMaster[kv.Key].lockConditionId;
                var sc=kv.Value.GetComponent<CommandButtonDisableObject>();
                sc.SetUp(lockId);
                sc.enabled = true;
            }
            else
            {
                if (kv.Key!="Command_Invite")
                {
                    Debug.LogError("未知命令 "+kv.Key+" Master.InteractiveButtonFunctionMaster");
                }

            }
        }

        #endregion
        
        
        
    }

    private void Handler()
    {
        Close.Invoke();
    }

    private async UniTask Call(string interactiveButtonId)
    {
        Debug.Log(interactiveButtonId);
        switch (interactiveButtonId)
        {
            case "Command_Underground":
                // //TODO XZF 临时注释
                // await UI.Popup.ShowPopupMessageAsync("功能正在研发中...");
                // return;
                await UI.Page.OpenPage<UIUndergroundPage>();
                break;
            case "Command_DailyQuest": //dailyquest
                await DailyQuestService.GetAvailable();
                await DailyQuestService.GetToday();
                await UI.Page.OpenPage<UIHomeDailyQuestMainPage>();
                break;
            case "Command_Begginer":
            case "Command_Daily":
            case "Command_Achievement":
                await MissionService.RequestMissionData();
                var master = DataManager.Instance.Master.InteractiveButtonFunctionMaster;
                int uitype = -1;
                foreach (var item in master.Values)
                {
                    if (item.secondaryInteractiveButtonId == interactiveButtonId)
                    {
                        uitype = int.Parse(item.uiType);
                    }
                }

                await UI.Page.OpenPage<UIMissionPage>(uitype);
                break;
            case "Command_BondItem":
            case "Command_Gold":
            case "Command_Equipment":
            case "Command_Note":
            case "Command_Diamond":
                await ExploreService.RequestExploreData();
                var master2 = DataManager.Instance.Master.InteractiveButtonFunctionMaster;
                int uitype2 = -1;
                foreach (var item in master2.Values)
                {
                    if (item.secondaryInteractiveButtonId == interactiveButtonId)
                    {
                        uitype2 = int.Parse(item.uiType);
                    }
                }

                await UI.Page.OpenPage<UIShopPage>(uitype2);
                break;

            case "Command_Gacha":
                await UI.Page.OpenPage<UIExploreGachaPage>();
                break;
            case "Command_MakeDrinks":
                await UI.Page.OpenPage<UIHomeBrewTeaPage>();

                break;
            case "Command_PlayMusic":
                var musicsIds = DataManager.Instance.Player.Item.GetList()
                    .Where(a => DataManager.Instance.Master.Item[a.ItemMasterId].contentType == 126).ToArray();
                if (musicsIds.Length > 0)
                    await UI.Page.OpenPage<UIMusicJukeboxPage>();
                else
                {
                    await UI.Popup.ShowPopupMessageAsync(
                        LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "Music_Jukebox_Not"));
                }

                break;
            case "Command_PluckMusic":
                UIOrganParam organParam = new UIOrganParam();
                organParam.onFinish = (b) => { Debug.Log("Over"); };
                await UI.Page.OpenPage<UIOrganPage>(organParam);
                break;
            case "Command_Story":
                UIHomeScenarioSelectPage.PageParam pageparam = new UIHomeScenarioSelectPage.PageParam();
                pageparam.showType = UIHomeScenarioSelectPage.PageParam.ShowType.Chapter;
                await UI.Page.OpenPage<UIHomeScenarioSelectPage>(pageparam);
                break;


            case "Command_Gift":
                await onClickGift();
                break;

            case "Command_TeaBreak":
                await onClickTeabreak();
                break;

            case "Command_Game":
                using (UI.TouchGuard.Guard("UIExploreCommandDialog.OnClickGame()"))
                {
                    await UI.Page.OpenPage<UITurtleGamePage>(long.Parse(interactiveTargetId));
                }

                break;

            case "Command_Quit":
            case "Command_Pardon":
                Close.Invoke();
                break;


            default:
                Debug.LogWarning(interactiveButtonId + "交互未注册");
                break;
        }
    }


    public static bool IsTeaBreakOpen()
    {
        var items = DataManager.Instance.Player.Item.GetList().Where(item =>
            DataManager.Instance.Master.Content[item.ItemMasterId].contentTypeMasterId == 127).ToArray();
        bool isOpen = false;
        foreach (var item in items)
        {
            if (item.Count != 0)
            {
                isOpen = true;
                break;
            }
        }

        return isOpen;
    }

    private async UniTask onClickTeabreak()
    {
        if (DataManager.Instance.Local.Explore.homeFollowCharacter != 0 && interactiveTargetId !=
            DataManager.Instance.Local.Explore.homeFollowCharacter.ToString())
        {
            //有正在跟随的角色
            await ((HomeMapLogic) MapSceneManager.Instance.CurrentLogic).EndFollow();
            return;
        }

        if (!IsTeaBreakOpen())
        {
            await UI.Popup.ShowNoneItemPopupAsync("NoneItemHintInterformation_Teabreak");
            //AsyncManager.Instance.StartGuardAsync(UI.Page.OpenPage<UINoneItemPage>());
            return;
        }

        //// TODO ： xzf 临时关闭
        //await UI.Popup.ShowPopupMessageAsync("功能装修装修中");
        //return;
        //await UI.ScreenEffect.Fade(1);
        teabreakClick?.Invoke();
        await HideAsync();
        UITeabreakSelectPage.PageParam p = new UITeabreakSelectPage.PageParam(long.Parse(interactiveTargetId));
        await ((HomeMapLogic) MapSceneManager.Instance.CurrentLogic).StartFollow(long.Parse(interactiveTargetId));
        var mapData = DataManager.Instance.Master.Location["advBuilding[11]"];
        if (MapSceneManager.Instance.mCurrentSceneName != mapData.scene)
        {
            //await UI.ScreenEffect.Fade(1);
            await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home,
                mapData.startPos);
            //await UI.ScreenEffect.Fade(0);
            p.isPlayEnd = true;
        }

        DataManager.Instance.Local.UserInfo.currentHomeMap = "advBuilding[11]";
        MapSceneManager.Instance.CurrentScene.GetCameraController().GetVirtualCameraManager().ZoomPlayer(false, 0.6f);
        await MapSceneManager.Instance.CurrentScene.MovePlayerRoutePointAsync("2F_route (25)");
        await UI.Page.ChangePage<UITeabreakSelectPage>(p);
    }


    private async UniTask onClickGift()
    {
        var items = DataManager.Instance.Player.Item.GetList().Where(item =>
            DataManager.Instance.Master.Content[item.ItemMasterId].contentTypeMasterId == 119).ToArray();
        bool isOpen = false;
        foreach (var item in items)
        {
            if (item.Count != 0)
            {
                isOpen = true;
                break;
            }
        }

        if (!isOpen)
        {
            await UI.Popup.ShowNoneItemPopupAsync("NoneItemHintInterformation_Gift");
            return;
        }

        await UI.Page.OpenPage<UIExploreGiftPage>(long.Parse(interactiveTargetId));
    }


    #region 茶歇判断相关代码

    private int GetBondsLevel()
    {
        return DataManager.Instance.Player.Bond.GetLevel(long.Parse(interactiveTargetId));
    }

    private bool isReaded(int keywordId, long characterId)
    {
        var keyword = DataManager.Instance.Player.Keyword.TryGet(keywordId);
        if (keyword != null)
        {
            return keyword.CharacterMasterIds.Contains(characterId);
        }

        return false;
    }

    #endregion
}