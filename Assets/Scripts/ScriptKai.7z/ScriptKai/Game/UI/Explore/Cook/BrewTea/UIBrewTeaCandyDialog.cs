using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

public class UIBrewTeaCandyDialog : UIDialogBase
{
    [SerializeField] private UIButton FinishButton;
    [SerializeField] private UIButton AddButton;
    // [SerializeField] Animation candyAddAnimation;
    // [SerializeField] AnimationClip candyAdd;
    [SerializeField] private GameObject effObj;
    [SerializeField] private List<Image> candyImages;
    private int candyCount = 0;

    public ClickEvent OnFinishBtnClicked => FinishButton.onClick;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        if (AddButton != null) AddButton.onClick.GuardSubscribeAsync(OnAddButtonClicked).AddTo(mSubscriptions);
    }

    async UniTask OnAddButtonClicked(GameObject o)
    {
        if (candyCount < candyImages.Count)
        {
            effObj.SetActive(false);
            candyImages[candyCount].color = Color.white;
            PxSoundManager.Instance.PlaySe("SE_poursugar");
            //await UIAnimationPlayer.PlayAsync(candyAddAnimation, candyAdd);
            candyCount++;
            effObj.SetActive(true);
        }

    }
    
    
}
