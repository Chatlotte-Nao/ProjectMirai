﻿using System.Collections;
using System.Collections.Generic;
using System.Linq.Expressions;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

public class UIBrewTeaDialog : UIDialogBase
{

    public ClickEvent OnCloseBtnClicked => closeButton.onClick;
    [SerializeField] GameObject[] resultobjects;
    [SerializeField] UITexture[] resultTitles;

    public async UniTask ShowBrewTeaResult(UIBrewTeaPage.BrewTeaResult result)
    {
        string titleIcon = "";
        string resultImageStr = "";
        
        switch (result)
        {
            case UIBrewTeaPage.BrewTeaResult.S:
                titleIcon = "ylzz_font_1_1";
                break;
            case UIBrewTeaPage.BrewTeaResult.A:
                titleIcon = "ylzz_font_2_1";
                break;
            case UIBrewTeaPage.BrewTeaResult.B:
                titleIcon = "ylzz_font_3_1";
                break;
            case UIBrewTeaPage.BrewTeaResult.C:
                titleIcon = "ylzz_font_4_1";
                break;
        }
        resultobjects[(int)result].gameObject.SetActive(true);
        await resultTitles[(int)result].LoadAsync("Font", titleIcon, true);
        // 成品展示
        
    }
}