﻿using System;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using System.Collections.Generic;

public class UIBrewTeaMilkDialog : UIDialogBase
{
    private const float DistanceLimit = 0.0f;
    private Vector3 prevPos;
    private Vector3 lastPos;
    private bool isPlayingAnim = false;

    [SerializeField] private UIButton FinishButton;
    [SerializeField] private Color[] _colors;
    [SerializeField] private Color[] _lighcolors;
    [SerializeField] private GameObject eff;
    private Animator mixingAnimator;
    private static readonly int IsMixing = Animator.StringToHash("isMixing");
    public UIIntEvent OnScoreClick = new UIIntEvent();
    public ClickEvent OnFinishBtnClicked = new ClickEvent();
    private float time = 0.0f;

    private Animator _blacktea;

    public void SetScoreBlacktea( GameObject blacktea)
    {
        _blacktea =  blacktea.GetComponent<Animator>();
        _blacktea.Play("Blacktea_Blend",0);
        _blacktea.speed = 0;
    }

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        FinishButton.onClick.Subscribe(FinishClick).AddTo(mSubscriptions);
    }

    private int score = 0;
    void FinishClick(GameObject o)
    {
        mixingAnimator.enabled = false;
        SetScore();
        OnScoreClick.Invoke(score);
        OnFinishBtnClicked.Invoke(o);
    }

    private void SetScore()
    {
        //Log.Debug(time);
        if (time > 0 && time <= 3 && score != 30)
        {
            score = 30;
            //_blacktea.SetMaterialColor(_colors[0], _lighcolors[0]);
        }
        else if (time > 3 && time <= 8 && score != 60)
        {
            score = 60;
            //_blacktea.SetMaterialColor(_colors[1], _lighcolors[1]);
        }
        else if (time > 8 && time <= 13 && score != 100)
        {
            score = 100;
            //_blacktea.SetMaterialColor(_colors[2], _lighcolors[2]);
        }

        else if (time > 13 && time <= 18 && score != 70)
        {
            score = 70;
            //_blacktea.SetMaterialColor(_colors[3], _lighcolors[3]);
        }

        else if (time > 18 && score != 40)
        {
            score = 40;
            //_blacktea.SetMaterialColor(_colors[4], _lighcolors[4]);
        }
    }

    public void SetAnimator(GameObject obj)
    {
        time = 0;
        mixingAnimator = obj.GetComponent<Animator>();
        mixingAnimator.enabled = true;
    }

    private bool isEnd = false;
    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        await PlayStartAnim();
        eff.SetActive(true);
        isPlayingAnim = false;
        isEnd = false;
    }

    private async UniTask PlayStartAnim()
    {
        if (isPlayingAnim) return;
        isPlayingAnim = true;
        await UniTask.Delay(500);
        isPlayingAnim = false;
    }

    private bool isPlay = false;
    private float speed = 0.35f;
    private float speedTime = 0;
    private async UniTask  PlayStirAnim()
    {
        if (!isEnd && !mixingAnimator.GetBool(IsMixing))
        {
            eff.SetActive(false);
            mixingAnimator.SetBool(IsMixing, true);
            speedTime = 0;
            //_blacktea.Speed = speedTime;
            isPlay = true;
            PxSoundManager.Instance.PlaySe("SE_Stir");
        }
    }

    private bool isStop = false;
    private async UniTask PlayStopAnim()
    {
        isStop = true;
        mixingAnimator.SetBool(IsMixing,false);
    }

    private void Update()
    {

        if (Input.GetMouseButton(0))
        {

            prevPos = Input.mousePosition;
            time += Time.deltaTime;
            //SetScore();
            AsyncManager.Instance.StartAsync(PlayStirAnim());
        }

        if (Input.GetMouseButtonUp(0))
        {
            AsyncManager.Instance.StartAsync(PlayStopAnim());
        }

        if (time>1.5f && isPlay)
        {
            _blacktea.speed = 1f;
            // if (speedTime <= speed )
            // {
            //     speedTime += Time.deltaTime;
            //     //_blacktea.Speed = speedTime;
            // }
            // else
            // {
            //     isPlay = false;
            // }
        }
        if (isStop)
        {
            _blacktea.speed = 0;
            // if (speedTime > 0 )
            // {
            //     speedTime -= Time.deltaTime;
            //     //_blacktea.Speed = speedTime;
            // }
            // else
            // {
            //     isStop = false;
            //     //_blacktea.Speed = 0f;
            // }
        }
    }

    // Video

    // Color

    // ...
}
