﻿using System;
using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Map;
using UnityEngine;

public class UIBrewTeaPage : UIPageBase
{
    
    public enum BrewTeaResult
    {
        // 震撼灵魂的佳作
        // 余味无穷的美味
        // 芳香四溢的佳肴
        // 平平无奇的食品
        S = 0,
        A = 1,
        B = 2,
        C = 3
    }
    private UIBrewTeaDialog mUIBrewTeaDialog = null;
    private UIBrewTeaWaterDialog mUIBrewTeaWaterDialog = null;
    private UIBrewTeaMilkDialog mUIBrewTeaMilkDialog = null;
    private UIBrewTeaCandyDialog mUIBrewTeaCandyDialog = null;

    private BrewTeaResult result = BrewTeaResult.C;
    private BrewTeaCandy.BrewTeaCandyParam _param;
    private int allScore = 0;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        _param = param as BrewTeaCandy.BrewTeaCandyParam;
        mUIBrewTeaDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIBrewTeaDialog, CanvasType.App1) as UIBrewTeaDialog;
        mUIBrewTeaDialog.OnCloseBtnClicked.GuardSubscribeAsync(CloseBrewTeaPage).AddTo(mSubscriptions);
        
        mUIBrewTeaWaterDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIBrewTeaWaterDialog, CanvasType.App1) as UIBrewTeaWaterDialog;
        mUIBrewTeaWaterDialog.SetAnimation(_param.brewTeaObjects[0]);
        mUIBrewTeaWaterDialog.OnNextStepBtnClicked.GuardSubscribeAsync(CloseBrewTeaWaterDialog).AddTo(mSubscriptions);
        mUIBrewTeaWaterDialog.OnScoreClick.GuardSubscribeAsync(ScoreClick).AddTo(mSubscriptions);
        
        mUIBrewTeaMilkDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIBrewTeaMilkDialog, CanvasType.App1) as UIBrewTeaMilkDialog;
        mUIBrewTeaMilkDialog.OnFinishBtnClicked.GuardSubscribeAsync(CloseBrewTeaCandyDialog).AddTo(mSubscriptions);
        mUIBrewTeaMilkDialog.OnScoreClick.GuardSubscribeAsync(ScoreClick).AddTo(mSubscriptions);
        // mUIBrewTeaCandyDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIBrewTeaCandyDialog, CanvasType.App1) as UIBrewTeaCandyDialog;
        // mUIBrewTeaCandyDialog.OnFinishBtnClicked.GuardSubscribeAsync(CloseBrewTeaCandyDialog).AddTo(mSubscriptions);
        SetObjectActive(false);
        
    }

    private async UniTask ScoreClick(int score)
    {
        allScore += score;
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        allScore = 0;
        await base.ShowAsync(showType);
        // UIBrewTeaDialog 常显， mUIBrewTeaWaterDialog为第一步。
        await mUIBrewTeaDialog.ShowAsync();
       
        await mUIBrewTeaWaterDialog.ShowAsync();
    }

    private async UniTask CloseBrewTeaPage(GameObject o)
    {
        await UI.ScreenEffect.Fade(1);
        SetObjectActive(false);
        await UIAnimationPlayer.PlayAsync(_param.animation, _param.hide);
        _param.Click.Invoke();
        await UI.Page.CloseCurrentPage();
        await UI.ScreenEffect.Fade(0);
    }

    private async UniTask CloseBrewTeaWaterDialog(GameObject o)
    {
        SetObjectActive(true);
        await mUIBrewTeaWaterDialog.HideAsync();
        mUIBrewTeaMilkDialog.SetScoreBlacktea(_param.blackTea);
        await UIAnimationPlayer.PlayAsync(_param.animation, _param.show);
        mUIBrewTeaMilkDialog.SetAnimator(_param.brewTeaObjects[1]);
        await mUIBrewTeaMilkDialog.ShowAsync();
    }

    private void SetObjectActive(bool isChabei)
    {
        _param.brewTeaObjects[0].SetActive(!isChabei);
        _param.brewTeaObjects[1].SetActive(isChabei);
    }

    private async UniTask CloseBrewTeaMilkDialog(GameObject o)
    {
        SetObjectActive(false);

        await mUIBrewTeaMilkDialog.HideAsync();
        await mUIBrewTeaCandyDialog.ShowAsync();

    }

    private async UniTask CloseBrewTeaCandyDialog(GameObject o)
    {
        SetObjectActive(true);
        await mUIBrewTeaMilkDialog.HideAsync();
        await mUIBrewTeaDialog.ShowBrewTeaResult(GetResult());
        int masterId = 0;
        switch (result)
        {
            case BrewTeaResult.S:
                masterId = 140001;
                break;
            case BrewTeaResult.A:
                masterId = 140002;
                break;
            case BrewTeaResult.B:
                 masterId = 140003;
                break;
            case BrewTeaResult.C:
                masterId = 140004;
                break;
            default:
                throw new ArgumentOutOfRangeException();
        }
        var isFirst = await MissionService.MissionFinishExplorePuzzle(masterId, true);
        await UI.Popup.ShowTinyGameResultAsync(masterId, false, true,
            () =>
            {
                AsyncManager.Instance.StartAsync(CloseBrewTeaPage(null));
            });
    }



    BrewTeaResult GetResult()
    {
        if (allScore >= 200)
        {
            result = BrewTeaResult.S;
        }
        else if (allScore >= 190 && allScore < 200)
        {
            result = BrewTeaResult.A;
        }
        else if (allScore > 80 && allScore < 190)
        {
            result = BrewTeaResult.B;
        }
        else if (allScore > 0 && allScore <= 80)
        {
            result = BrewTeaResult.C;
        }

        return result;
    }
    
    
    
    

    public override void Dispose()
    {
        base.Dispose();

        if (mUIBrewTeaDialog != null)
        {
            mUIBrewTeaDialog.Dispose();
            mUIBrewTeaDialog = null;
        }
        if (mUIBrewTeaWaterDialog != null)
        {
            mUIBrewTeaWaterDialog.Dispose();
            mUIBrewTeaWaterDialog = null;
        }
        if (mUIBrewTeaMilkDialog != null)
        {
            mUIBrewTeaMilkDialog.Dispose();
            mUIBrewTeaMilkDialog = null;
        }
        if (mUIBrewTeaCandyDialog != null)
        {
            mUIBrewTeaCandyDialog.Dispose();
            mUIBrewTeaCandyDialog = null;
        }
    }
}
