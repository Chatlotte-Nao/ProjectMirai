﻿using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Playables;

public class UIBrewTeaWaterDialog : UIDialogBase
{
    private const float MaxValue = 2.0f;
    private bool stopBtnClieked;
    private float lerpNum;
    private float startIndex;
    private bool startLerp = false;
    private bool clockSwitch = false;
    [SerializeField] private UIButton StartButton;
    [SerializeField] private UIButton StopButton;
    [SerializeField] private UIButton NextButton;
    [SerializeField] private GameObject Clock;
    [SerializeField] private GameObject ClockHand;
    [SerializeField] private GameObject centerPoint;
    [SerializeField] private GameObject handPoint;
    [SerializeField] private List<GameObject> Points;
    
    [SerializeField] private GameObject effObj;
    PlayableDirector pourInAnimation;
    [SerializeField] private UITexture titleImage;
    
    public ClickEvent OnNextStepBtnClicked => NextButton.onClick;
    public UIIntEvent OnScoreClick = new UIIntEvent();
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        stopBtnClieked = false;
        lerpNum = MaxValue;
        startIndex = 0;
        startLerp = false;
        clockSwitch = false;
        Clock.SetActive(false);
        StartButton.gameObject.SetActive(false);
        StopButton.gameObject.SetActive(false);
        NextButton.gameObject.SetActive(false);
        if (StartButton != null) StartButton.onClick.Subscribe(OnStartButtonClicked).AddTo(mSubscriptions);
        if (StopButton != null) StopButton.onClick.GuardSubscribeAsync(OnStopButtonClicked).AddTo(mSubscriptions);
        
        // await titleImage.LoadAsync("Font", iconId, true);

    }
    public void SetAnimation(GameObject obj)
    {
        pourInAnimation = obj.GetComponent<PlayableDirector>();
    }
    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        //pourInAnimation.enabled = true;
        await PlayVideo();
    }

    async UniTask PlayVideo()
    {
        // Debug.LogError("Gx: PlayVideo .. Have No Video Yet");
        PxSoundManager.Instance.PlaySe("SE_pourwater");
        //await UIAnimationPlayer.PlayAsync(pourInAnimation, pourIn);
        pourInAnimation.time = 0;
        pourInAnimation.Resume();
        pourInAnimation.Play();
        await UniTask.Delay(500);
        ShowClock();
        
    }
    
    public void PourInDone()
    {
    }
    
    
    

    void ShowClock()
    {
        Clock.SetActive(true);
        StartButton.gameObject.SetActive(true);
    }

    void OnStartButtonClicked(GameObject paramGo)
    {
        clockSwitch = true;
        StartButton.gameObject.SetActive(false);
        StopButton.gameObject.SetActive(true);
        //pourInAnimation.enabled = false;
    }

    async UniTask OnStopButtonClicked(GameObject paramGo)
    {
        effObj.gameObject.SetActive(true);
        if (stopBtnClieked) return;
        stopBtnClieked = true;
        startLerp = true;
        await UniTask.Delay(500);

        clockSwitch = false;
        NextButton.gameObject.SetActive(true);
        StopButton.gameObject.SetActive(false);

        int score = 0;
        //
        // Vector3 handDirct = handPoint.transform.position - centerPoint.transform.position;
        // Vector3 v1 = Points[0].transform.position - centerPoint.transform.position;
        // Vector3 v2 = Points[1].transform.position - centerPoint.transform.position;
        // Vector3 v3 = Points[2].transform.position - centerPoint.transform.position;
        // Vector3 v4 = Points[3].transform.position - centerPoint.transform.position;
        //
        // float handAngle = Vector3.SignedAngle(new Vector3(0, 1, 0), handDirct, Vector3.back);
        // float angle1 = Vector3.SignedAngle(new Vector3(0, 1, 0), v1, Vector3.back);
        // float angle2 = Vector3.SignedAngle(new Vector3(0, 1, 0), v2, Vector3.back);
        // float angle3 = Vector3.SignedAngle(new Vector3(0, 1, 0), v3, Vector3.back);
        // float angle4 = Vector3.SignedAngle(new Vector3(0, 1, 0), v4, Vector3.back);
        //
        // if (handAngle >= angle1 && handAngle <= angle4)
        // {
        //     if (handAngle >= angle2 && handAngle <= angle3)
        //     {
        //         score = UIBrewTeaPage.BrewTeaResult.S;
        //     }
        //     else
        //     {
        //         score = UIBrewTeaPage.BrewTeaResult.A;
        //     }
        // }
        int z = 360 - (int)ClockHand.transform.localEulerAngles.z;
        if (z > 0 && z < 90)
        {
            score = 10;
        }
        else if (z >= 90 && z < 180 || z > 270 && z <= 360)
        {
            score = 40;
        }
        else if (z >= 180 && z < 200 || z > 250 && z <= 270)
        {
            score = 70;
        }
        else if (z >= 200 && z < 210 || z > 240 && z <= 250)
        {
            score = 80;
        }
        else if (z >= 210 && z < 220 || z > 230 && z <= 240)
        {
            score = 90;
        }
        else if (z >= 220 && z < 223 || z > 227 && z <= 230)
        {
            score = 95;
        }
        else if (z >= 223 && z <= 227 )
        {
            score = 100;
        }

        OnScoreClick.Invoke(score);
        //Debug.LogError($"Gx: 当前评级为： {score}、 { z}");
        
    }

    private void Update()
    {
        if (clockSwitch)
        {
            if (startLerp) lerpNum = Mathf.Lerp(MaxValue, 0, startIndex += 0.2f);
            if (lerpNum < 0.2f) lerpNum = 0;
            ClockHand.transform.Rotate(Vector3.back, 0.5f + lerpNum);
        }
    }



    /*
    public bool IsInRange(float sectorAngle, float sectorRadius, Transform attacker, Transform target)
    {
        Vector3 direction = target.position - attacker.position;

        float dot = Vector3.Dot(direction.normalized, transform.forward);

        float offsetAngle = Mathf.Acos(dot) * Mathf.Rad2Deg; //弧度转度
        return offsetAngle < sectorAngle * .5f && direction.magnitude < sectorRadius;
    }

    float VectorAngle(Vector2 from, Vector2 to)
    {
        float angle;
   
        Vector3 cross=Vector3.Cross(from, to);
        angle = Vector2.Angle(from, to);
        return cross.z > 0 ? -angle : angle;
    }

    */
}
