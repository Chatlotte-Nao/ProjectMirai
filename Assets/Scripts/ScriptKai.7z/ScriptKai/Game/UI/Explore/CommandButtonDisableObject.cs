using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.Serialization;

public class CommandButtonDisableObject : MonoBehaviour
{
    [SerializeField] private GameObject lockGroup;
    [SerializeField] private Animation lockAnimation;
    [SerializeField] private UIButton disableButton;
    [SerializeField] private int unlockId;
    [SerializeField] private string lockedScenarioId;

    
    private void OnDisable()
    {
        disableButton.OnTouchUpInside.RemoveAllListeners();
    }

    private void OnEnable()
    {
        
        
        disableButton.OnTouchUpInside.SubscribeAsync(async () =>
        {
            var t = unlockId;
            var t2 = lockedScenarioId;
            if (!string.IsNullOrEmpty(t2))
            {
                await CallScenario(t2);
            }
            CommonUtil.IsFunctionUnlock(t, true);
        });
    }

    public void SetUp(int unlockId)
    {
        this.unlockId = unlockId;
        if (unlockId != 0)
        {
            if (!CommonUtil.IsFunctionUnlock(unlockId))
            {
                lockGroup.SetActive(true);
                GetComponent<UIButton>().enabled = false;    
                return;
            }

            if (!DataManager.Instance.Local.Scenarios.UnlockCommandButtonIds.Contains(unlockId))
            {
                lockGroup.SetActive(true);
                DataManager.Instance.Local.Scenarios.UnlockCommandButtonIds.Add(unlockId);
                DataManager.Instance.Local.Save();
                lockAnimation.Play();
                PlayAnimation();
            }
            lockedScenarioId = DataManager.Instance.Master.FunctionUnlock[unlockId].lockedScenarioId;
        }

    }

    //todo 播adv演出 lockedScenarioId
    private async UniTask CallScenario(string lockedScenarioId)
    {
    }
    

    void PlayAnimation()
    {
        AsyncManager.Instance.StartAsync(PlayAnimationAsync);
    }

    private async UniTask PlayAnimationAsync()
    {
        var time = lockAnimation.clip.length;
        await UniTask.Delay((int) (time * 1000));
        lockGroup?.SetActive(false);
        disableButton.enabled = true;
        GetComponent<UIButton>().enabled = true;
    }
}