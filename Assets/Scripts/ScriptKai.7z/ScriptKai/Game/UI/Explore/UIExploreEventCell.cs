﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;

public class UIExploreEventCell : MonoBehaviour
{
    [SerializeField] UIButton button;
    [SerializeField] GameObject selectGroup;
    [SerializeField] GameObject unselectGroup;
    [SerializeField] UIText nameText;
    [SerializeField] UIText selectNameText;
    [SerializeField] GameObject newGroup;
    [SerializeField] UIText numText;
    [SerializeField] UIText selectNumText;
    [SerializeField] GameObject ongoingGroup;
    [SerializeField] Toggle favButton;
    [SerializeField] GameObject chearGroup;
    public ExploreEventViewModel Model {get; private set;}

    public ClickEvent OnClick => button.onClick;
    public Toggle.ToggleEvent OnClickFav => favButton.onValueChanged;
    

    public  void Setup(ExploreEventViewModel model)
    {
        Model = model;

        nameText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{model.masterId}_title");
        selectNameText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{model.masterId}_title");
        numText.SetRawText(model.finishCount.ToString());
        selectNumText.SetRawText(model.finishCount.ToString());
        favButton.SetIsOnWithoutNotify(model.fav);

        bool ongoing = false;
        if (model.eventStatus == ExploreEventViewModel.EventStatus.Accepted)
            ongoing = true;

        newGroup.SetActive(false);
        ongoingGroup.SetActive(ongoing);
        chearGroup.SetActive(model.finishCount > 0 && !ongoing);
        selectGroup.SetActive(false);
        unselectGroup.SetActive(true);
    }

    public void RefreshNewState()
    {
        bool ongoing = false;
        if (Model.eventStatus == ExploreEventViewModel.EventStatus.Accepted)
            ongoing = true;

        newGroup.SetActive(Model.finishCount == 0 && !ongoing && Model.CanStart());
    }

    public void Select(bool val)
    {
        if (val)
        {
            selectGroup.SetActive(true);
            unselectGroup.SetActive(false);
        }
        else
        {
            selectGroup.SetActive(false);
            unselectGroup.SetActive(true);
        }
    }

}
