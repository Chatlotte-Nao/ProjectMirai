﻿using Base.Util;

using Game.Sound;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class GoalMessageAppearance : MonoBehaviour
{
	[SerializeField] GoalMessage goalMessagePrefab;
	[SerializeField] GoalMessage goalMessagePrefabChild;
	[SerializeField] Transform messageParent;
	[SerializeField] VerticalLayoutGroup layout;

	const int DISPLAY_MAX = 3;
	const float waitTime = 1f;
	const float CLEAR_START_WAIT_SECOND = 0.2f;

	List<GoalMessage> messages = new List<GoalMessage>();
	string lastAppearanceHint = string.Empty;

	int index { get { return messages.Count; } }

	private void Awake()
	{

	}

	public void SetMessage(int masterId)
	{
		var master = DataManager.Instance.Master.GoalMessage[masterId];
		if (master == null)
		{
			return;
		}

		if (index >= DISPLAY_MAX)
		{
			Debug.LogWarning("現状" + DISPLAY_MAX + "以上同時に目標は出ない仕様です。演出も規定以上登録すると見た目がおかしくなります。設定目標の確認、または仕様変更が無いか確認してください");
			return;
		}

		var prefab = (master.IsParent()) ? goalMessagePrefab : goalMessagePrefabChild;
		var mes = Instantiate(prefab);
		mes.transform.SetParent(messageParent, false);
		var rect = mes.GetComponent<RectTransform>();
		var pivot = rect.pivot;
		pivot.x = 0.5f;
		rect.pivot = pivot;

		mes.SetMessage(masterId);
		mes.SetMessageAnchor(TextAlignmentOptions.Center);
		mes.SetMarkUndisplay();
		mes.gameObject.SetActive(false);
		messages.Add(mes);
	}

	/// <summary>
	/// 出現演出
	/// </summary>
	/// <returns></returns>
	public IEnumerator Appearance()
	{
		if (index <= 0) yield break;

		List<Image> image = new List<Image>();

		gameObject.SetActive(true);
		layout.enabled = true;

		yield return new WaitForSeconds(waitTime);
		//目標表示の設定
		for (int i = 0; i < index; i++)
		{
			messages[i].gameObject.SetActive(true);
			image.Add(messages[i].GetComponentInChildren<Image>());
			if (i > 0) image[i].gameObject.SetActive(false);
			lastAppearanceHint = messages[i].GetHintMessage();
		}

		SoundPlayer.PlaySe("03_クエスト内容表示");
		yield return new WaitForSeconds(waitTime);

		//１番目以降の目標を時間差で表示
		for (int i = 1; i < index; i++)
		{
			image[i].gameObject.SetActive(true);
			SoundPlayer.PlaySe("03_クエスト内容表示");
			yield return new WaitForSeconds(waitTime);
		}
		
		yield return new WaitForSeconds(waitTime);
		
		//動き出したらレイアウトは停止
		layout.enabled = false;

		for (int i = 0; i < index; i++)
		{
			yield return messages[i].SetAnimationRoutine(GoalMessage.AnimationType.APPEARANCEOUT);
			messages[i].gameObject.SetActive(false);
		}

		Refresh();
		gameObject.SetActive(false);
	}

	/// <summary>
	/// 最後に表示した目標一覧のヒント文章を取得
	/// </summary>
	/// <returns></returns>
	public string GetLastAppearanceHint()
	{
		return lastAppearanceHint;
	}

	public IEnumerator ClearAnimationRoutine(bool isFailed)
	{
		layout.enabled = true;
		for (int i = 0; i < index; i++)
		{
			messages[i].gameObject.SetActive(true);
		}
		gameObject.SetActive(true);

		yield return new WaitForSeconds(CLEAR_START_WAIT_SECOND);
		for (int i = 0; i < index; i++)
		{
			yield return messages[i].SetClearAnimationRoutine(isFailed);
		}

		gameObject.SetActive(false);
		Refresh();
	}

	public void Refresh()
	{
		for (int i = 0; i < messages.Count; i++)
		{
			Destroy(messages[i].gameObject);
		}
		messages.Clear();
	}
}
