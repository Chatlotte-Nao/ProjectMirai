using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using Map;
using Pheonix.Core;
using Base.Sound;

public class MiniCharacterExploreMessage : MonoBehaviour
{
    ExploreBubbleMaster bubbleMaster = null;

    CharacterMessage message = null;

    public float time = 10f;
    public bool isShowMes = false;
    public float waitTime = 5f;
    public bool noWait = true;
    public int soundIdx;
    public string sound = "";
    Camera _mainCamera;


    public void Setup(ExploreBubbleMaster master, CharacterMessage msg)
    {
        bubbleMaster = master;
        message = msg;
        message.gameObject.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        _mainCamera = RenderHandler.Instance.GetMainCamera();
        // if (GameObject.Find("Main Camera").GetComponent<Camera>() != null)
        // {
        //     _mainCamera = GameObject.Find("Main Camera").GetComponent<Camera>();
        // }
    }

    public GameObject GetNearestId()
    {
        var characterList = MapSceneManager.Instance.CurrentScene.characters;
        GameObject nearest = null;
        float minD = 2f;

        foreach (var item in characterList)
        {
            var d = Vector3.Distance(item.Value.transform.position,
                MapSceneManager.Instance.CurrentScene.player.transform.position);
            if (d < minD)
            {
                nearest = item.Value.gameObject;
                minD = d;
            }
        }

        return nearest;
    }

    public void SetTextAndSound()
    {
        isShowMes = true;
        List<string> list = bubbleMaster.wordBubbleClewBeforeContract;
        int count = list.Count;
        int a = Random.Range(0, count);
        string textmes = list[a].Split(':')[0];
        sound = list[a].Split(':')[1];
        waitTime = 5f;
        time = 10f;
        if (sound != null && sound != "0")
        {
            Base.Sound.SoundManager.PlayVoice(sound);
        }
        else
        {
            if (SoundManager.IsPlayingVoice())
            {
                SoundManager.StopVoice();
            }
        }

        if (textmes != "0")
        {
            string mess = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, textmes);
            message.SetMessage(mess);
            //text.SetLabel(LocalizeManager.DATA_TYPE.MINI_CHARA_MESSAGE, textmes);
        }
        else
        {
            message.gameObject.SetActive(false);
        }

        int length = textmes.Length;
    }

    private void Update()
    {
        if (!MapSceneManager.Instance.CurrentScene)
        {
            return;
        }
        
        if (_mainCamera == null)
        {
            return;
        }
        var rotation = Quaternion.LookRotation(_mainCamera.transform.TransformVector(Vector3.forward),
            _mainCamera.transform.TransformVector(Vector3.up));
        rotation = new Quaternion(0, rotation.y, 0, rotation.w);
        message.gameObject.transform.rotation = rotation;

        var d = Vector3.Distance(gameObject.transform.position,
            MapSceneManager.Instance.CurrentScene.player.transform.position);
        if (d <= 2f && gameObject == GetNearestId())
        {
            if (isShowMes == false)
            {
                SetTextAndSound();
            }
            else
            {
                time -= Time.deltaTime;
                if (time <= 0)
                {
                    SoundManager.StopVoice();
                    message.gameObject.SetActive(false);
                    waitTime -= Time.deltaTime;
                    if (waitTime <= 0 && message.gameObject.activeSelf == false)
                    {
                        if (!message.gameObject.activeSelf)
                        {
                            SetTextAndSound();
                        }

                        time = 10f;
                    }
                }
            }
        }
        else
        {
            if (isShowMes)
            {
                SoundManager.StopVoice();
                isShowMes = false;
            }

            if (message.gameObject.activeSelf)
            {
                message.gameObject.SetActive(false);
            }
        }
    }
}