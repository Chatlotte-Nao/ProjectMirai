using System;
using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.AI;

public class MiniCharacterMoveAI : MonoBehaviour
{
    private void Awake()
    {
        SignalBus.GlobalSignal.Subscribe<bool>(UIEventId.SwitchExploreCommandPage, SwitchExploreCommandPage);
        originalPosition = transform.position;
        agent = this.gameObject.GetComponent<NavMeshAgent>();
        minicharacter = this.gameObject.GetComponent<Map.Map3DCharacter>();
        if (agent.enabled)
            agent.ResetPath();
        if (speed != 0)
        {
            agent.speed = speed;
        }
    }

    private void OnDestroy()
    {
        SignalBus.GlobalSignal.RemoveListener<bool>(UIEventId.SwitchExploreCommandPage, SwitchExploreCommandPage);
    }

    void SwitchExploreCommandPage(bool a)
    {
        _inCommandUI = a;
        Refresh();
    }


    void Refresh()
    {
        if (!gameObject.activeSelf)
        {
            return;
        }
        StopAllCoroutines();
        if (!_inCommandUI)
        {
            if (MapSceneManager.Instance.CurrentType == MapSceneManager.SceneType.Home)
            {
                isActive = true;
                StartCoroutine(delayCoroutine());
                return;
            }
        }

        isActive = false;
        CanCelMove();
    }

    private void OnEnable()
    {
        Refresh();
    }


    // Update is called once per frame
    void Update()
    {
        if (isActive && agent.enabled)
        {
            if (canMoving)
            {
                bool isOk = false;
                if (moveStart)
                {
                    moveStart = false;
                    isOk = agent.SetDestination(currentDestination);
                    if (isOk)
                        minicharacter.PlayMoveAnimation();
                }

                if (agent.hasPath)
                {
                    minicharacter.SetDir(agent.velocity);
                    if (agent.pathStatus == NavMeshPathStatus.PathComplete && agent.remainingDistance < 0.5f)
                    {
                        agent.isStopped = true;
                        agent.ResetPath();
                        agent.velocity = Vector3.zero;
                        StartCoroutine(delayCoroutine());
                    }
                }
                else
                {
                    if (isOk == false)
                    {
                        StartCoroutine(delayCoroutine());
                    }
                }
            }
        }
    }


    public void CanCelMove()
    {
        isActive = false;
        if (!gameObject.activeSelf)
        {
            return;
        }
        if (agent.isStopped) return;
        agent.isStopped = true;
        agent.ResetPath();
        agent.velocity = Vector3.zero;
        minicharacter.PlayIdleAnimation();
    }

    IEnumerator delayCoroutine()
    {
        canMoving = false;
        minicharacter.PlayIdleAnimation();
        newPosition = GetCirclePoint(radius);
        currentDestination = newPosition;
        yield return new WaitForSeconds(UnityEngine.Random.Range(3, 5));
        canMoving = true;
        moveStart = true;
    }

    public Vector3 GetCirclePoint(float m_Radius)
    {
        float radin = UnityEngine.Random.Range(0f, 2 * Mathf.PI);
        float x = m_Radius * Mathf.Cos(radin);
        float z = m_Radius * Mathf.Sin(radin);
        Vector3 endPoint = new Vector3(x, 0, z) + originalPosition;
        return endPoint;
    }


    Map.Map3DCharacter minicharacter;
    Vector3 originalPosition;
    Vector3 newPosition = Vector3.zero;
    Vector3 currentDestination = Vector3.zero;

    bool canMoving = false;
    bool moveStart = false;
    public bool isActive = false;
    public float radius = 0;
    public int speed = 0;
    NavMeshAgent agent;

    private bool _inCommandUI = false;
}