using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Takasho.Schema.Score.ResourceCn.Item.V1;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using DG.Tweening;
using System.Threading.Tasks;
using System;
using UnityEngine.UI;

public class UIHomeBubbleTeaAssistMaterialDialog : UIDialogBase
{
    [SerializeField] GameObject main;
    [SerializeField] UIHomeBubbleTeaAssistMaterialItemList itemList;
    [SerializeField] UIButton prompt;
    [SerializeField] UIButton lefp;
    [SerializeField] UIButton right;
    public UnityEvent<string> openClick = new UnityEvent<string>();
    [SerializeField] float uintLength;
    [SerializeField] RectTransform moveView;
    [SerializeField] RectTransform moveIcon;
    [SerializeField] UIHomeBubbleTeaAssistMaterialTrigger enterTrigger;

    UIHomeBubbleTeaNeededItenFrame downItem = null;
    public async UniTask SetUp(List<int> accessory)
    {
        moveIcon.gameObject.SetActive(false);
        enterTrigger.gameObject.SetActive(false);
        main.SetActive(false);
        List<PuzzleDrinkAccessoryMaster> makeAcc = new List<PuzzleDrinkAccessoryMaster>();
        foreach (var parameter in accessory)
        {
            makeAcc.Add(DataManager.Instance.Master.PuzzleDrinkAccessoryMaster[parameter]);
        }
        await itemList.SetUp(makeAcc,this);

        prompt.onClick.RemoveAllListeners();
        prompt.onClick.GuardSubscribeAsync(async (o) => { await UI.Popup.ShowUIHomeBubbleTeaUserGuide("���븨����ʾ"); });


        lefp.onEnter.GuardSubscribeAsync(async (v) =>
        {
            isLeftEnter = true;
        });
        lefp.onExit.GuardSubscribeAsync(async (v) =>
        {
            isLeftEnter = false;
        });
        right.onEnter.GuardSubscribeAsync(async (v) =>
        {
            isRightEnter = true;
        });
        right.onExit.GuardSubscribeAsync(async (v) =>
        {
            isRightEnter = false;
        });

        DOTween.To(() => 2, value => { }, 0, 3).OnComplete(() => { main.SetActive(true); });
    }

    bool isLeftEnter = false;
    bool isRightEnter = false;
    private void Update()
    {
        if (isLeftEnter && moveView.anchoredPosition3D.x >= -moveView.childCount * 100.0f + 500.0f)
        {
            moveView.anchoredPosition3D = new Vector3(moveView.anchoredPosition3D.x - uintLength, moveView.anchoredPosition3D.y, moveView.anchoredPosition3D.z);
        }

        if (isRightEnter && moveView.anchoredPosition3D.x <= 200.0f)
        {
            moveView.anchoredPosition3D = new Vector3(moveView.anchoredPosition3D.x + uintLength, moveView.anchoredPosition3D.y, moveView.anchoredPosition3D.z);
        }

        if (downItem != null)
        {
            MoveIcon();
        }
    }
    int id;

    public async UniTask MoveIcon()
    {
        var endPos = Input.mousePosition - new Vector3(Camera.main.pixelWidth, Camera.main.pixelHeight, 0) / 2;
        moveIcon.anchoredPosition = Vector2.Lerp(moveIcon.anchoredPosition, endPos, 10.0f * Time.deltaTime);
    }
    public async UniTask SetMoveIcon(int id, UIHomeBubbleTeaNeededItenFrame item)
    {
        this.id = id;
        moveIcon.GetComponent<Image>().sprite = await ResourceManager.Instance.LoadSpriteAsync("BrewTeaIcon", $"{id}");
        moveIcon.gameObject.SetActive(true);
        enterTrigger.gameObject.SetActive(true);
        downItem = item;
        moveIcon.GetComponent<RectTransform>().anchoredPosition = downItem.GetComponent<RectTransform>().anchoredPosition;
    }
    public async UniTask LayDown()
    {

    }
    public async UniTask UpTriggerClick()
    {
        if (enterTrigger.action.Invoke() && downItem != null)
        {
            downItem.onclick.Invoke(async ()=> { });
        }
        moveIcon.gameObject.SetActive(false);
        enterTrigger.gameObject.SetActive(false);
        downItem = null;
    }

    public async UniTask NextWindow(string s)
    {
        openClick.Invoke(s);
        await Task.Delay(2000);
        main.SetActive(false);
    }
}
