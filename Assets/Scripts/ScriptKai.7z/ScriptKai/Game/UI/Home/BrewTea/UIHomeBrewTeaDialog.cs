using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using UnityEngine.Events;
using Cysharp.Threading.Tasks;
using System;
using DG.Tweening;

public class UIHomeBrewTeaDialog : UIDialogBase
{
    [SerializeField] UIButton close;
    [SerializeField] UIButton closeWindow;
    [SerializeField] UIButton closeWindow2;
    [SerializeField] UIButton yes;
    [SerializeField] UIButton no;
    [SerializeField] GameObject window;
    [SerializeField] UIText windowText;
    [SerializeField] UIText title;
    [SerializeField] GameObject hintWindow;
    [SerializeField] UIButton hintCloseBtn;
    [HideInInspector] public UnityEvent openClick = new UnityEvent();
    [SerializeField] UIButton close2;
    bool isOpenWindow = false;

    public async UniTask SetUp(Func<UniTask> func)
    {
        await ShowAsync();
        hintWindow.SetActive(false);
        close.onClick.RemoveAllListeners();
        yes.onClick.RemoveAllListeners();
        no.onClick.RemoveAllListeners();
        closeWindow.onClick.RemoveAllListeners();
        closeWindow2.onClick.RemoveAllListeners();
        window.SetActive(false);
        
        yes.onClick.GuardSubscribeAsync(async (o) =>
        {
            DOTween.KillAll();
            window.SetActive(false);
            await func.Invoke();
            return;
            windowText.SetRawText("确定要退出吗？");
            title.SetRawText("提示");
            if (isOpenWindow)
            {
                window.SetActive(false);
                await func.Invoke();
            }
            isOpenWindow = !isOpenWindow;
        });
        no.onClick.GuardSubscribeAsync(async (o) =>
        {
            window.SetActive(false);
        });
        closeWindow.onClick.GuardSubscribeAsync(async (o) =>
        {
            window.SetActive(false);
        });
        closeWindow2.onClick.GuardSubscribeAsync(async (o) =>
        {
            window.SetActive(false);
        });
        close.onClick.GuardSubscribeAsync(async (o) =>
        {
            openClick.Invoke();
        });
    }

    public async UniTask OpenWindow()
    {
        windowText.SetRawText("确定要退出吗？");
        title.SetRawText("提示");
        window.SetActive(true);
        isOpenWindow = false;
        return;
        window.SetActive(true);
        isOpenWindow = false;
        windowText.SetRawText("中途退出时，不会返还已消耗的材料。");
        title.SetRawText("确认");
    }

    public async UniTask ShowHint()
    {
        hintWindow.SetActive(true);
        hintCloseBtn.onClick.RemoveAllListeners();
        close2.onClick.RemoveAllListeners();
        hintCloseBtn.onClick.GuardSubscribeAsync(async (_) =>
        {
            hintWindow.SetActive(false);
        });
        close2.onClick.GuardSubscribeAsync(async (o) =>
        {
            hintWindow.SetActive(false);
        });
    }
}
