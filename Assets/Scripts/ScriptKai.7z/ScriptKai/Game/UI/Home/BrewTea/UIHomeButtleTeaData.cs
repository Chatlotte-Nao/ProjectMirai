﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Item.V1;
using Cysharp.Threading.Tasks;
using System;

public class UIHomeButtleTeaData
{
    public enum StirEstate
    {
        inferior,
        midium,
        upper,
    }

    public static UIHomeButtleTeaData Instance = new UIHomeButtleTeaData();
    public List<int> accessory = new List<int>();
    public float blendTime = 0;
    public UIHomeBrewTeaDialog brewTeaHint;
    public int id;
    public List<StirEstate> stir = new List<StirEstate>();

    public UIHomeBubbleTeaMap teaMap;
    public float water;
    public bool isTutoria = false;
    int value = 0;
    public async UniTask<AwardAndGrad> GetAward()
    {
        List<PlayerItem> playerItems = new List<PlayerItem>();
        value = 0;
        if (water < 230.0f / 755)
        {
            value += 0;
        }
        else if (water < 290.0f / 755)
        {
            value += 50;
        }
        else if (water < 350.0f / 755)
        {
            value += 100;
        }
        else if (water < 405.0f / 755)
        {
            value += 50;
        }
        else
        {
            value += 0;
        }
        var favore = DataManager.Instance.Master.PuzzleDrinkMakingMaster[id].favoredAccessories;
        var normal = DataManager.Instance.Master.PuzzleDrinkMakingMaster[id].normalAccessories;
        var unsuitable = DataManager.Instance.Master.PuzzleDrinkMakingMaster[id].unsuitableAccessories;

        var math = 0;
        foreach (var item in accessory)
        {
            math += favore.Contains(item) ? 20 : 0;
            math += normal.Contains(item) ? 0 : 0;
            math += unsuitable.Contains(item) ? -10 : 0;
        }
        value += math;

        value += (int)(100.0f * blendTime / 15.0f);
        string parameter = "";
        int grad = 0;
        if (value >= 200)
        {
            parameter = "sLevelRewards";
            grad = 1;
        }
        else if (value >= 130)
        {
            parameter = "aLevelRewards";
            grad = 2;
        }
        else
        {
            parameter = "bLevelRewards";
            grad = 3;
        }
        var type = DataManager.Instance.Master.PuzzleDrinkMakingMaster[id].GetType();
        var awords = type.GetField(parameter).GetValue(DataManager.Instance.Master.PuzzleDrinkMakingMaster[id]) as List<string>;

        foreach (var item in awords)
        {
            var t = item.Split(":");
            PlayerItem playeritem = new PlayerItem();
            playeritem.ItemMasterId = long.Parse(t[0]);
            playeritem.Count = long.Parse(t[1]);
            playerItems.Add(playeritem);
            parameter += " - " + item;
        }
        Debug.Log($"{GetType()}  {parameter}  {playerItems.Count}  {value}");
        AwardAndGrad awardAndGrad = new AwardAndGrad(playerItems, grad);

        //服务器指令
        //await Server();
        return awardAndGrad;
    }
    public async UniTask Server()
    {
        await MissionService.MissionFinishDrinkMakingPuzzle(id, value, accessory);
    }

    public struct AwardAndGrad
    {
        public List<PlayerItem> playerItems;
        public int grad;
        public AwardAndGrad(List<PlayerItem> playerItems, int grad)
        {
            this.playerItems = playerItems;
            this.grad = grad;
        }
    }
}
