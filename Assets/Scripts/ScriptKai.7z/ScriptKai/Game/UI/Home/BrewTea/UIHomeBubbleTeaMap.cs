using Cysharp.Threading.Tasks;
using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using System.Reflection;
using UnityEditor;

public class UIHomeBubbleTeaMap : MonoBehaviour
{
    public enum particleSystems
    {
        blendParticle,
        assistMatParticle,
        finishParticle,
    }

    [SerializeField] Animator anima;
    [SerializeField] Camera camera;

    [SerializeField] GameObject teacup;
    [SerializeField] GameObject cosmetics_02;
    [SerializeField] GameObject kettle;
    [SerializeField] GameObject teaspoon;
    [SerializeField] GameObject charging_tank;
    [SerializeField] GameObject leftTeaCup;

    [SerializeField] ParticleSystem blendParticle;
    [SerializeField] ParticleSystem assistMatParticle;
    [SerializeField] ParticleSystem finishParticle;

    public async UniTask PlayParticle(particleSystems selectParticleSystem)
    {
        //var ins = GetType().GetField(selectParticleSystem.ToString(), BindingFlags.Instance | BindingFlags.NonPublic).GetValue(this);
        //var type = ins.GetType();
        //par.GetType().GetMethod("Clear").Invoke(par, new object[] { });
        //par.GetType().GetField("time").SetValue(par, 0);
        await StopAllParticle();
        switch (selectParticleSystem)
        {
            case particleSystems.blendParticle:
                if (!blendParticle.isPlaying)
                {
                    blendParticle.gameObject.SetActive(true);
                    blendParticle.time = 0;
                    blendParticle.Play();
                }
                break;
            case particleSystems.assistMatParticle:
                if (!assistMatParticle.isPlaying)
                {
                    assistMatParticle.gameObject.SetActive(true);
                    assistMatParticle.time = 0;
                    assistMatParticle.Play();
                }
                break;
            case particleSystems.finishParticle:
                if (!finishParticle.isPlaying)
                {
                    finishParticle.gameObject.SetActive(true);
                    finishParticle.time = 0;
                    finishParticle.Play();
                }
                break;
            default:
                break;
        }
        //blendParticle.Clear();
        //blendParticle.time = 0;
        //blendParticle.Play();
    }

    public async UniTask StopAllParticle()
    {
        blendParticle.Clear();
        assistMatParticle.Clear();
        finishParticle.Clear();
        blendParticle.Stop();
        assistMatParticle.Stop();
        finishParticle.Stop();
        blendParticle.gameObject.SetActive(false);
        assistMatParticle.gameObject.SetActive(false);
        finishParticle.gameObject.SetActive(false);
    }

    public async UniTask SetUpShowAsync()
    {
        await StopAllParticle();
        anima.SetBool("Stir IsActive", true);
        anima.SetBool("Stir Direction", true);
        anima.SetInteger("Water", 0);
        anima.SetInteger("Stir Speed", 0);
        await SetCharacteranimatorStatus("Layer.Think_01");

        MoveCamera(new Vector3(-5.29f, 2.32f, 5.0f), Quaternion.Euler(12, 141.1f, 0), 30.0f);
    }

    public async UniTask SetCharacteranimatorStatus(string statusName)
    {
        anima.Play(statusName);
        await SetItemActive(false);
        if (statusName == "Layer.Think_01" || statusName == "Layer.Standing")
        {
            teacup.SetActive(false);
            leftTeaCup.SetActive(false);
        }
        if (statusName == "Layer.TakeOut_01" || statusName == "Layer.PourWater_01" || statusName == "Layer.PourWater_03")
        {
            //��ʼ����
            teacup.SetActive(true);
            //��ˮ
            kettle.SetActive(true);
            teacup.transform.localPosition = new Vector3(0.001f, 0.197f, 0.167f);
        }
        if (statusName == "Layer.TakeOut_02" || statusName == "Layer.Feeding")
        {
            //����
            teacup.SetActive(true);
            charging_tank.SetActive(true);
        }
        if (statusName == "Layer.TakeOut_02 0" || statusName == "Layer.Stir_01")
        {
            //����
            teaspoon.SetActive(true);
            leftTeaCup.SetActive(true);
            teacup.SetActive(false);
        }
        if (statusName == "Layer.Show_01" || statusName == "Layer.Show_01")
        {
            //��������
            leftTeaCup.SetActive(false);
            teacup.SetActive(true);
            teacup.transform.DOLocalMove(new Vector3(-0.2f, 1, 0.5f), 1, false);
        }
        //Debug.Log($"{GetType()}  {statusName}");
    }

    public async UniTask SetSpeed(float value)
    {
        anima.speed = value;
    }

    public async UniTask<Animator> GetAnimatorController()
    {
        return anima;
    }

    public void MoveCamera(Vector3 pos,Quaternion qua, float fov)
    {
        camera.transform.DOLocalMove(pos, 1, false).SetEase(ease: Ease.InOutSine).SetUpdate(false);
        camera.transform.DOLocalRotateQuaternion(qua, 1).SetEase(ease: Ease.InOutSine).SetUpdate(false);
        camera.DOFieldOfView(fov, 1).SetUpdate(false);
    }

    public void KettleActiveFalse()
    {
        kettle.SetActive(false);
        teacup.SetActive(false);
    }

    public void SetLeftTeacupActive()
    {
        leftTeaCup.SetActive(false);
    }

    async UniTask SetItemActive(bool active)
    {
        cosmetics_02.SetActive(active);
        kettle.SetActive(active);
        teaspoon.SetActive(active);
        charging_tank.SetActive(active);
    }
}
