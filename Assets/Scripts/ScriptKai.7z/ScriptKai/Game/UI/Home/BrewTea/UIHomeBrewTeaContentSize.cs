using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIHomeBrewTeaContentSize : MonoBehaviour
{
    [SerializeField] RectTransform contentSize;
    [SerializeField] RectTransform accordingToChildren;
    [SerializeField] RectTransform toChildren;
    [SerializeField] int accordingToChildrenAmendment;
    [SerializeField, Tooltip("Left-Top_Right_Bottom")] Vector4 fourInterval;
    [SerializeField] Direction direction;
    [SerializeField] float objectInterval;

    private void Update()
    {
        Active();
    }

    public void Active()
    {
        var chilNumber = accordingToChildren.childCount + accordingToChildrenAmendment;
        var unitSizeDelta = toChildren.sizeDelta;
        var interval = new Vector2();
        var chilLenght = new Vector2();
        switch (direction)
        {
            case Direction.Vertical:
                interval = new Vector2(0, objectInterval * (chilNumber - 1));
                chilLenght = new Vector2(0, (chilNumber * unitSizeDelta).y);
                break;
            default:
                interval = new Vector2(0, objectInterval * (chilNumber - 1));
                chilLenght = new Vector2(0, (chilNumber * unitSizeDelta).y);
                break;
        }
        var fourIntervals = new Vector2(fourInterval.x + fourInterval.z + unitSizeDelta.x, fourInterval.y + fourInterval.w);
        var sizeDelat = interval + chilLenght + fourIntervals;
        contentSize.sizeDelta = sizeDelat;
    }

    enum Direction
    {
        Horizontal,
        Vertical,
    }
}
