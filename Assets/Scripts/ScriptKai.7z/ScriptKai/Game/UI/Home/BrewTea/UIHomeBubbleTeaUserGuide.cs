using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIHomeBubbleTeaUserGuide : UIDialogBase
{
    [SerializeField] UIText prompt;
    public async UniTask SetUp(string prompt)
    {
        await ShowAsync();
        this.prompt.SetRawText(prompt);
    }
}
