using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using Takasho.Schema.Score.ResourceCn.Item.V1;
using System;
using UnityEngine.UI;

public class UIHomeBubbleTeaFinishPopup : UIDialogBase
{
    [SerializeField] GameObject main;
    [SerializeField] UIText scros;
    [SerializeField] UIButton closeBtn;
    [SerializeField] GameObject select;
    [SerializeField] UIHomeBubbleTeaNeededItenFrame award;
    [SerializeField] RectTransform awardsParent;
    [SerializeField] Image titleIcon;
    [SerializeField] Image teaIcon;
    [SerializeField] List<Image> startFour = new List<Image>();

    [SerializeField] List<GameObject> intervalTimeActiveObj = new List<GameObject>();

    WJHPool<GameObject> itemPrefabPool = new WJHPool<GameObject>();
    List<GameObject> tempPool = new List<GameObject>();

    public async UniTask SetUp(List<PlayerItem> awards,Func<UniTask> func, int grad)
    {
        await ShowAsync();
        await SetTeaIcon(grad);

        award.gameObject.SetActive(false);
        closeBtn.onClick.RemoveAllListeners();
        closeBtn.onClick.GuardSubscribeAsync(async (o) => { await HideAsync(); await func.Invoke(); });
        foreach (var poo in tempPool)
        {
            poo.SetActive(false);
            await itemPrefabPool.PutBack(poo);
        }
        tempPool = new List<GameObject>();
        closeBtn.enabled = false;
        select.SetActive(false);
        foreach (var parameter in intervalTimeActiveObj)
        {
            parameter.SetActive(false);
        }
        await DOTween.To(() => 2, value => { }, 0, 1.0f).OnComplete(async () =>
        {
                await UIHomeButtleTeaData.Instance.teaMap.PlayParticle(UIHomeBubbleTeaMap.particleSystems.finishParticle);
                closeBtn.enabled = true;
                  select.SetActive(true);
                  teaIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("BrewTeaIcon", $"DrinkMaker_{UIHomeButtleTeaData.Instance.id}");

                  foreach (var award in awards)
                  {
                      UIHomeBubbleTeaNeededItenFrame obj = (await itemPrefabPool.GetObj(this.award.gameObject)).GetComponent<UIHomeBubbleTeaNeededItenFrame>();
                      CommonAttrite att = new CommonAttrite(int.Parse(award.ItemMasterId.ToString("0")), 
                          LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ITEM, 
                          $"{award.ItemMasterId}_name"), int.Parse(award.Count.ToString("0")), 
                          int.Parse(award.ItemMasterId.ToString("0"))
                          );
                      obj.gameObject.SetActive(true);
                      tempPool.Add(obj.gameObject);
                      Debug.Log($"{GetType()}  {obj.name}   {att.id}");
                      obj.transform.SetParent(awardsParent);
                      obj.GetComponent<RectTransform>().localScale = Vector3.one;
                      obj.GetComponent<RectTransform>().anchoredPosition3D = Vector3.zero;

                      Debug.Log($"{GetType()}  {att.id}");
                      await obj.SetUp(
                            id: async () => att.id,
                            itemName: async () =>
                            {
                                string name = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ITEM, $"{att.id}_name");
                                return name;
                            },
                            count: async () => $"+{att.count}",
                            icon: async () => await ResourceManager.Instance.LoadSpriteAsync("ItemIcon", $"{att.id}"),
                            isItemFarame: false
                            );;
                  }

              });
        UIHomeButtleTeaData.Instance.teaMap.MoveCamera(new Vector3(-3.73f, 3.87f, 7.36f), Quaternion.Euler(23.8f, 170.8f, 0), 15.0f);
        await DOTween.To(() => 2, value => { }, 0, 1.0f).OnComplete(async () =>
        {
            foreach (var parameter in intervalTimeActiveObj)
            {
                parameter.SetActive(true);
            }
        });
    }

    async UniTask SetTeaIcon(int grad)
    {
        List<Color> starColors = new List<Color>(new Color[4]);
        Color color = new Color();
        string iconName = "";
        switch (grad)
        {
            case 1:
                iconName = "wm_01";
                starColors[0] = new Color(255 / 255.0f, 220 / 255.0f, 150 / 255.0f);
                starColors[1] = new Color(255 / 255.0f, 247 / 255.0f, 148 / 255.0f);
                starColors[2] = new Color(255 / 255.0f, 253 / 255.0f, 197 / 255.0f);
                starColors[3] = new Color(245 / 255.0f, 230 / 255.0f, 128 / 255.0f);
                break;
            case 2:
                iconName = "yx_01";
                ColorUtility.TryParseHtmlString("#7ad5ff", out color);
                starColors[0] = color;
                ColorUtility.TryParseHtmlString("#a7ffff", out color);
                starColors[1] = color;
                ColorUtility.TryParseHtmlString("#bfffff", out color);
                starColors[2] = color;
                ColorUtility.TryParseHtmlString("#7ad5ff", out color);
                starColors[3] = color;
                break;
            case 3:
                iconName = "yb_01";
                ColorUtility.TryParseHtmlString("#92ff7a", out color);
                starColors[0] = color;
                ColorUtility.TryParseHtmlString("#ceff9d", out color);
                starColors[1] = color;
                ColorUtility.TryParseHtmlString("#dfffbf", out color);
                starColors[2] = color;
                ColorUtility.TryParseHtmlString("#92ff7a", out color);
                starColors[3] = color;
                break;
            default:
                break;
        }
        this.titleIcon.sprite = ResourceManager.Instance.LoadSprite("BrewTeaIcon", "yl_word_" + iconName);
        teaIcon.sprite = ResourceManager.Instance.LoadSprite("BrewTeaIcon", 
            "yl_pj_icon0" + DataManager.Instance.Master.PuzzleDrinkMakingMaster[UIHomeButtleTeaData.Instance.id].drinkVariety.ToString());
        for (int i = 0; i < startFour.Count; i++)
        {
            startFour[i].color = starColors[i];
        }
    }
}
