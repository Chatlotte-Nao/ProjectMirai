using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Threading.Tasks;

public class WJHPool<T> : Singleton<WJHPool<T>> where T : UnityEngine.Object
{
    private List<T> pool = new List<T>();

    public async UniTask<T> GetObj(T obj)
    {
        T t = null;
        if (pool.Count != 0)
        {
            t = pool[0];
            pool.Remove(t);
        }
        else
        {
            t = GameObject.Instantiate(obj as GameObject) as T;
        }
        await Task.Delay(System.TimeSpan.Zero);
        return t;
    }

    public async UniTask PutBack(T t)
    {
        pool.Add(t);
        await Task.Delay(System.TimeSpan.Zero);
    }
}

public struct CommonAttrite
{
    public int id;
    public string name;
    public int count;
    public int icon;

    public CommonAttrite(int id, string name, int count,int icon)
    {
        this.id = id;
        this.name = name;
        this.count = count;
        this.icon = icon;
    }
}
