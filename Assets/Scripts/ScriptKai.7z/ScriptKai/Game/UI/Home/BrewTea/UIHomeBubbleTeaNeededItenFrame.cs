using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine.UI;
using Takasho.Schema.Score.ResourceCn.Item.V1;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using System;

public class UIHomeBubbleTeaNeededItenFrame : MonoBehaviour, IPointerClickHandler,IPointerDownHandler, IPointerUpHandler, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] UIText name;
    [SerializeField] Image icon;
    [SerializeField] UIText number;
    [SerializeField] Image background;
    [SerializeField] Image back2;
    [SerializeField] Image selectedFrame;
    [SerializeField] ButtonStatus status;
    public bool isConclude = false;
    [HideInInspector] public UnityEvent<Func<UniTask>> onclick = new UnityEvent<Func<UniTask>>();
    int id;
    [HideInInspector] private UnityEvent longClick = new UnityEvent();
    UnityEvent onDownClick = new UnityEvent();
    UnityEvent onUpClick = new UnityEvent();

    private void Update()
    {
        if ((status & ButtonStatus.Down) != 0)
        {
            longClick.Invoke();
        }
    }


    public void OnPointerClick(PointerEventData eventData)
    {
        AsyncManager.Instance.StartAsync(OnClick());
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if ((status & ButtonStatus.Down) == 0)
        {
            status = (int)status + ButtonStatus.Down;
        }
        onDownClick.Invoke();
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if ((status & ButtonStatus.Enter) == 0)
        {
            status = (int)status + ButtonStatus.Enter;
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if ((status & ButtonStatus.Enter) != 0)
        {
            status = (int)status - ButtonStatus.Enter;
        }
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if ((status & ButtonStatus.Down) != 0)
        {
            status = (int)status - ButtonStatus.Down;
        }
        onUpClick.Invoke();
    }

    public async UniTask SetUp(Func<Task<long>> id, Func<Task<string>> itemName, Func<Task<string>> count, Func<Task<Sprite>> icon, bool isItemFarame = false)
    {
        //selectedFrame.GetComponent<RectTransform>().sizeDelta = new Vector2(118.0f, 108.0f);
        var ids = await id.Invoke();
        if (selectedFrame != null)
        {
            selectedFrame.enabled = false;
        }
        name.SetRawText(await itemName.Invoke());
        this.icon.sprite = await icon.Invoke();

        var counts = await count.Invoke();
        var number2 = DataManager.Instance.Player.Player.GetData().ExploreCoinLimit;
        var number3 = DataManager.Instance.Player.Player.GetData().ExploreCoinReceived;
        if (ids == 121000001)
        {
            string[] str = counts.Split('+');
            var num = long.Parse(str[str.Length - 1]);
            num = number2 - number3 <= num ? number2 - number3 : num;
            counts = $"+{num}  <color=#FFFFFF>{number3 + num}</color><color=#E2BF7B>/{number2}</color>";
        }
        number.SetRawText(counts.ToString());

        if (isItemFarame && back2 != null)
        {
            back2.sprite = await ResourceManager.Instance.LoadSpriteAsync("FrameBg", $"frame_item_{DataManager.Instance.Master.Item[ids].rarity}");
        }

    }

    async UniTask OnClick()
    {
        onclick.Invoke(async () => { await Task.Delay(System.TimeSpan.Zero); });
        await Task.Delay(System.TimeSpan.Zero);
    }
    public async UniTask SetFrameSprite(Sprite sprite)
    {
        selectedFrame.sprite = sprite;
    }
    public async UniTask<Image> GetIcon()
    {
        return icon;
    }
    public async UniTask SetColor(bool isSelected)
    {
        if (selectedFrame != null)
        {
            selectedFrame.enabled = (isSelected);
        }
    }

    public void AddLongDownClick(params Action[] clicks)
    {
        longClick.RemoveAllListeners();
        foreach (var click in clicks)
        {
            longClick.AddListener(() => { click.Invoke(); });
        }
    }

    public void Move(Func<Vector3> getPosFunc,RectTransform rect)
    {
        var pos = getPosFunc.Invoke();
    }

    public async UniTask AddOnDownClick(Func<UniTask> func)
    {
        onDownClick.GuardSubscribeAsync(func);
    }

    public async UniTask AddOnUpClick(Func<UniTask> func)
    {
        onUpClick.GuardSubscribeAsync(func);
    }

    enum ButtonStatus
    {
        None = 1<<0,
        Down = 1 << 1,
        Up = 1 << 2,
        Enter = 1 << 3,
        Exit = 1 << 4,
    }
}