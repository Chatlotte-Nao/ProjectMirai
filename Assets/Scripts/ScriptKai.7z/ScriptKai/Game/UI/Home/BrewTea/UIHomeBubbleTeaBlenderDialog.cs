﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using UnityEngine.EventSystems;
using Cysharp.Threading.Tasks;
using System.Threading.Tasks;
using Takasho.Schema.Score.ResourceCn.Item.V1;
using System;
using DG.Tweening;
using UnityEngine.Events;

public class UIHomeBubbleTeaBlenderDialog : UIDialogBase
{
    [SerializeField] UIButton button;
    [SerializeField] UIButton sphereButton;
    [SerializeField] UIButton prompt;
    [SerializeField] RectTransform sphere;
    [SerializeField, Range(0, 10)] float speed;
    [SerializeField] float maxDir;

    [SerializeField] RectTransform referenceRect;
    [SerializeField] RectTransform sphereParent;
    [SerializeField] float peremeter;

    [SerializeField,Range(0,1)] float schedule = 0;//设置动画进度参数
    [SerializeField] float num = 0;
    [SerializeField] Vector2 normSpeedInterval;
    [SerializeField] GameObject speedTextBG;
    [SerializeField] UIText speedText;
    [SerializeField] RectTransform hint;
    [SerializeField] bool isActive = false;
    [HideInInspector] public UnityEvent<string> openClick = new UnityEvent<string>();
    [SerializeField] float intervalTime;
    [SerializeField] float testNumber = 10;
    float blendTime = 0;
    Tween blendTween;
    [SerializeField] bool isDirTrue = true;
    [SerializeField] bool isInScope = false;
    [SerializeField] bool leftOrRight;
    [SerializeField] bool rotDir = true;
    [SerializeField] bool speedTextActive = true;
    [SerializeField] Vector3 speedTextUpPos = Vector3.zero;

    [SerializeField] Vector3 upPos = Vector3.zero;
    [SerializeField] Vector3 upVector = Vector3.zero;
    [SerializeField] int stirSpeed;
    [SerializeField] bool isPlayEff = false;

    private void Update()
    {
        if (isInScope 
            && Input.mousePosition.x < Camera.main.pixelWidth 
            && Input.mousePosition.y < Camera.main.pixelHeight
            && Input.mousePosition.x > 0 
            && Input.mousePosition.y > 0)
        {
            Move();
        }
    }
    private void OnDisable()
    {
        if (tween != null)
        {
            tween.Kill();
            tween = null;
        }
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        await UIHomeButtleTeaData.Instance.teaMap.SetCharacteranimatorStatus("Base Layer.Blend");
        (await UIHomeButtleTeaData.Instance.teaMap.GetAnimatorController()).SetInteger("Stir Speed", 0);
        prompt.onClick.RemoveAllListeners();
        prompt.onClick.GuardSubscribeAsync(async (o) => { await UI.Popup.ShowUIHomeBubbleTeaUserGuide("搅拌提示"); });
        rotDir = true;
        isActive = false;
        blendTime = 0.0f;
        speedTextBG.SetActive(false);
        blendTween = DOTween.To(() => blendTime, value => { blendTime = value; }, 15, 15).SetEase(Ease.Linear);
        DOTween.To(() => 2, value => { }, 0, 2)
            .OnStart(() =>
            {
                sphereButton.gameObject.SetActive(false);
                button.onClickUp.RemoveAllListeners();
                sphereButton.OnTouchDown.RemoveAllListeners();
                sphereButton.onClickUp.RemoveAllListeners();
            })
            .OnComplete(() =>
            {
                sphereButton.gameObject.SetActive(true);
                sphereButton.OnTouchDown.GuardSubscribeAsync(SphereButtonOnTouchClick);
                sphereButton.onClickUp.GuardSubscribeAsync(async (o) => { await SphereButtonOnClickUp(); });
                //button.onClickUp.GuardSubscribeAsync(async (o) => { await ButtonOnClickUp(); });
            });
        peremeter = sphereParent.rect.height * 2 * Mathf.PI;
    }

    async UniTask SphereButtonOnTouchClick()
    {
        isInScope = true;
        speedTextActive = true;
        isPlayEff = false;
        upVector = sphere.position;
        if (!isActive)
        {
            delay();
            await UIHomeButtleTeaData.Instance.teaMap.SetCharacteranimatorStatus("Layer.Stir_01");
            SetSpeedText();
        }
        isActive = true;
        (await UIHomeButtleTeaData.Instance.teaMap.GetAnimatorController()).SetBool("Stir IsActive", true);
        await UIHomeButtleTeaData.Instance.teaMap.SetSpeed(1);
    }

    async UniTask SphereButtonOnClickUp()
    {
        isInScope = false;
        blendTween.Pause();
        sphere.anchoredPosition3D = new Vector3(0, 0, 0);
        upPos = sphere.position;
        num = 0;
        schedule = 0;
    }

    private void Move()
    {
        //搅拌进度
        num += Vector3.Distance(upPos, sphere.position);
        schedule = num % peremeter / peremeter;
        upPos = sphere.position;

        //滚动
        var v1 = new Vector3(
                    Input.mousePosition.x - Camera.main.pixelWidth / 2,
                    Input.mousePosition.y - Camera.main.pixelHeight / 2,
                    0)
            - referenceRect.anchoredPosition3D;

        var doc = Mathf.Acos(Vector3.Dot(v1.normalized, new Vector3(0, 1, 0))) * Mathf.Rad2Deg;

        var cross = Vector3.Cross( new Vector3(0, 1, 0), v1);



        var t = cross.z / Mathf.Abs(cross.z);
        var angle = doc * t;
        sphereParent.rotation = Quaternion.Euler(new Vector3(0, 0, angle));

        var dis = Vector3.Distance(referenceRect.anchoredPosition3D, 
            new Vector3(
                    Input.mousePosition.x - Camera.main.pixelWidth / 2,
                    Input.mousePosition.y - Camera.main.pixelHeight / 2,
                    0));
        dis = dis > sphereParent.rect.height ? sphereParent.rect.height : dis;
        sphere.anchoredPosition3D = new Vector3(0, dis, 0);
    }

    Tween tween = null;
    int textIndex = 3;
    private async UniTask SetSpeedText()
    {
        speedTextActive = true;
        //int value = 0;
        textIndex = 3;
        Tween tween = null;
        bool temporlate = false;
        await UIHomeButtleTeaData.Instance.teaMap.StopAllParticle();
        speedText.SetRawText(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, $"DrinkMaker_Speed_{textIndex}"));
        tween = DOTween.To(() => 2, value => { }, 0, intervalTime * testNumber);
        while (speedTextActive)
        {
            if (isDirTrue)
            {
                if (isInScope)
                {
                    DOTween.To(() => 2, value => { }, 0, intervalTime)
                       .OnComplete(async () =>
                       {
                           var vec = (sphere.position - sphereParent.position);
                           var dot2 = Mathf.Acos(Vector3.Dot(vec.normalized, upVector.normalized)) * Mathf.Rad2Deg;
                           var cross2 = Vector3.Cross(vec.normalized, upVector.normalized).z;
                           leftOrRight = cross2 > 0 ? false : true; // false : left
                           int nowSpeed = 1;

                           var angle2 = Mathf.Acos(Vector3.Dot(upVector.normalized, vec.normalized)) * Mathf.Rad2Deg;
                           var intercal = angle2;
                           var dir = Vector3.Distance(speedTextUpPos, sphere.position);
                           speedTextUpPos = sphere.position;
                           if (intercal < normSpeedInterval.x)
                           {
                               stirSpeed = 1;
                               await UIHomeButtleTeaData.Instance.teaMap.StopAllParticle();
                           }
                           else if (intercal > normSpeedInterval.y)
                           {
                               stirSpeed = 3;
                               if (temporlate && isPlayEff)
                               {
                                   await UIHomeButtleTeaData.Instance.teaMap.PlayParticle(UIHomeBubbleTeaMap.particleSystems.blendParticle);
                               }
                           }
                           else
                           {
                               stirSpeed = 2;
                               await UIHomeButtleTeaData.Instance.teaMap.StopAllParticle();
                           }
                           (await UIHomeButtleTeaData.Instance.teaMap.GetAnimatorController()).SetInteger("Stir Speed", stirSpeed);
                           if (rotDir != leftOrRight)
                           {

                               if (intercal < normSpeedInterval.x)
                               {
                                   textIndex = 2;
                                   blendTween.Pause();
                               }
                               else if (intercal > normSpeedInterval.y)
                               {
                                   textIndex = 1;
                                   blendTween.Pause();
                               }
                               else
                               {
                                   textIndex = 3;
                                   blendTween.Play();
                               }
                           }
                           else
                           {
                               blendTween.Pause();
                               textIndex = 4;
                           }
                           await UIHomeButtleTeaData.Instance.teaMap.SetSpeed(nowSpeed);
                       });
                    DOTween.To(() => 2, value => { }, 0, intervalTime * testNumber)
                        .OnComplete(async () =>
                        {
                            isPlayEff = true;
                            textIndex = speedTextActive ? textIndex : 2;
                            speedText.SetRawText(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, $"DrinkMaker_Speed_{textIndex}"));
                        });
                }
                else
                {
                    speedText.SetRawText(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, $"DrinkMaker_Speed_2"));
                    await UIHomeButtleTeaData.Instance.teaMap.StopAllParticle();
                    if (isDirTrue)
                    {
                        await UIHomeButtleTeaData.Instance.teaMap.SetCharacteranimatorStatus("Layer.Stir_01");
                    }
                    await UIHomeButtleTeaData.Instance.teaMap.SetSpeed(0);
                }
            }
            temporlate = true;
            tween.Kill();
            upVector = (sphere.position - sphereParent.position);
            await DOTween.To(() => 2, value => { }, 0, intervalTime * testNumber);
        }
    }
    

    public async UniTask delay()
    {
        (await UIHomeButtleTeaData.Instance.teaMap.GetAnimatorController()).SetBool("Stir Direction", rotDir);
        isDirTrue = true;
        for (int i = 0; i < 3; i++)
        {
            await DOTween.To(() => 2, value => { }, 5, 5).OnStart(() =>
            {
                int x = 0;
                switch (rotDir)
                {
                    case true:
                        x = 1;
                        break;
                    case false:
                        x = -1;
                        break;
                }
                hint.localScale = new Vector3(x, 1, 1);
                SpeedTextActive();
            }).OnComplete(async () =>
            {
                rotDir = !rotDir;
                (await UIHomeButtleTeaData.Instance.teaMap.GetAnimatorController()).SetBool("Stir Direction", rotDir);
            });
        }
        //DOTween.KillAll();
        isDirTrue = false;
        //isPlayEff = false;
        await DOTween.To(() => 2, value => { }, 0, 1.1f);
        speedTextBG.SetActive(false);
        await UIHomeButtleTeaData.Instance.teaMap.StopAllParticle();
        (await UIHomeButtleTeaData.Instance.teaMap.GetAnimatorController()).SetBool("Stir IsActive", false);
        await UIHomeButtleTeaData.Instance.teaMap.SetSpeed(1);
        await UIHomeButtleTeaData.Instance.teaMap.SetCharacteranimatorStatus("Base Layer.Stir_08");
        DOTween.To(() => 2, value => { }, 0, 1)
            .OnComplete(() =>
            {
                UIHomeButtleTeaData.Instance.teaMap.SetLeftTeacupActive();
            });
        UIHomeButtleTeaData.Instance.blendTime = blendTime;
        isInScope = false;
        speedTextActive = false;
        sphere.anchoredPosition3D = new Vector3(0, 0, 0);
        upPos = sphere.position;
        num = 0;
        schedule = 0;

        string str = "";
        int index = 0;
        if (blendTime < 15.0f * 0.33f)
        {
            index = 3;
        }
        else if (blendTime < 15.0f * 0.66f)
        {
            index = 2;
        }
        else
        {
            index = 1;
        }
        str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, $"DrinkMaker_Evaluate_{index}");
        openClick.Invoke(str);
    }

    public void SpeedTextActive()
    {
        hint.gameObject.SetActive(true);
        speedTextBG.SetActive(false);

        DOTween.To(() => 2, value => { }, 5, 4.6f).OnComplete(()=> 
        {
            hint.gameObject.SetActive(false);
        });
        DOTween.To(() => 2, value => { }, 5, 1).OnComplete(() =>
        {
            speedTextBG.SetActive(true);
        });
    }
}
