using Cysharp.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using DG.Tweening;
using System;

public class UIHomeBubbleTeaPourWaterSlider : MonoBehaviour
{
    [SerializeField] RectTransform targetGraphic;
    [SerializeField] RectTransform fillRect;
    [SerializeField] RectTransform water;
    [SerializeField] float endTime = 3;
    Tween tween = null;
    public async UniTask SetUp()
    {
        targetGraphic.anchoredPosition3D = new Vector3(0, 0, 0);
        //water.sizeDelta = new Vector2(fillRect.rect.width, 0);

        fillRect.sizeDelta = new Vector2(0, fillRect.sizeDelta.y);

        tween = DOTween.To(() => 0.0f, temp => { 
            targetGraphic.anchoredPosition3D = new Vector3(-temp, 0, 0);
            fillRect.sizeDelta = new Vector2(temp, fillRect.sizeDelta.y);
        }, water.rect.width, endTime).SetEase(Ease.Linear).Pause();
        await Task.Delay(TimeSpan.Zero);
    }
    public async UniTask Loop(bool act,Func<UniTask> func = null)
    {
        switch (act)
        {
            case true:
                await tween.Play();
                break;
            case false:
                await tween.Pause();
                break;
        }
        await func.Invoke();
        await GetScale();
    }
    public async UniTask<float> GetScale()
    {
        //Debug.Log($"{GetType()}     {targetGraphic.anchoredPosition3D.x}   {water.rect.width}");
        return Mathf.Abs(targetGraphic.anchoredPosition3D.x) / Mathf.Abs(water.rect.width);
    }
}
