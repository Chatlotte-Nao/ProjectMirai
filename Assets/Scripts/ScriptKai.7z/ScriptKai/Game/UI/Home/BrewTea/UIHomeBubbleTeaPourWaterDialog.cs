using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Threading.Tasks;
using DG.Tweening;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIHomeBubbleTeaPourWaterDialog : UIDialogBase
{
    [SerializeField] GameObject main;
    [SerializeField] UIText stopText;
    [SerializeField] UIButton stopButton;
    [SerializeField] UIButton prompt;
    [SerializeField] bool active = false;
    [SerializeField] GameObject activeImage;
    [SerializeField] GameObject finishImage;

    [SerializeField] UIHomeBubbleTeaPourWaterSlider slider;
    [SerializeField] GameObject sliderAndButton;


    [HideInInspector] public UnityEvent<string,List<int>> openClick = new UnityEvent<string,List<int>>();
    Dictionary<bool, string> stopDic = new Dictionary<bool, string>();

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync();
        stopDic.Clear();
        stopDic.Add(true, LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "DrinkMaker_Pause"));
        stopDic.Add(false, LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "DrinkMaker_Start"));

        sliderAndButton.SetActive(true);
        main.SetActive(false);
        active = false;
        stopText.SetRawText(stopDic[active]);
        activeImage.SetActive(!active);
        finishImage.SetActive(active);
        stopButton.onClick.RemoveAllListeners();
        stopButton.onClick.GuardSubscribeAsync((o) => StopOnClick());
        await slider.SetUp();
        prompt.onClick.RemoveAllListeners();
        prompt.onClick.GuardSubscribeAsync(async (o) => { await UI.Popup.ShowUIHomeBubbleTeaUserGuide("��ˮ��ʾ"); });
        DOTween.To(() => 2, value => { }, 0, 3).OnComplete(() => { main.SetActive(true); });

    }

    public async UniTask StopOnClick()
    {
        active = !active;

        if (!active)
        {
            stopButton.onClick.RemoveAllListeners();
            await DOTween.To(() => 2, (value) => { }, 0, 0.3f).OnComplete(async () => 
            {
                stopText.SetRawText(stopDic[active]);
                activeImage.SetActive(!active);
                finishImage.SetActive(active);
                slider.Loop(active, async () => { /*stopText.SetRawText("���");*/});

                List<int> asseccory = new List<int>();
                foreach (var item in DataManager.Instance.Master.PuzzleDrinkAccessoryMaster)
                {
                    asseccory.Add(item.Key);
                }
                string str = await GetText();
                openClick.Invoke(str, asseccory);
                await DOTween.To(() => 2, value => { }, 0, 1).OnComplete(async () => 
                {
                    sliderAndButton.SetActive(false); 
                    await UIHomeButtleTeaData.Instance.teaMap.SetCharacteranimatorStatus("Layer.PourWater_03");
                    UIHomeButtleTeaData.Instance.teaMap.KettleActiveFalse();
                });
            });
        }
        else
        {
            await UIHomeButtleTeaData.Instance.teaMap.SetCharacteranimatorStatus("Layer.PourWater_01");
            stopText.SetRawText(stopDic[active]);
            activeImage.SetActive(!active);
            finishImage.SetActive(active);
            slider.Loop(active, async () => 
            {
                stopText.SetRawText(stopDic[active]);
                List<int> asseccory = new List<int>();
                foreach (var item in DataManager.Instance.Master.PuzzleDrinkAccessoryMaster)
                {
                    asseccory.Add(item.Key);
                }
                string str = await GetText();
                openClick.Invoke(str, asseccory);
                Debug.Log($"{GetType()}  {UIHomeButtleTeaData.Instance.water}");
                await DOTween.To(() => 2, value => { }, 0, 1).OnComplete(async () =>
                {
                    sliderAndButton.SetActive(false);
                    await UIHomeButtleTeaData.Instance.teaMap.SetCharacteranimatorStatus("Layer.PourWater_03");
                    UIHomeButtleTeaData.Instance.teaMap.KettleActiveFalse();
                });
            });
        }
    }

    public async UniTask<string> GetText()
    {
        string str = "";
        int integer = 0;
        var waterPos = await slider.GetScale();
        if (waterPos < 230.0f / 755)
        {
            str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE,"DrinkMaker_Evaluate_3");
            integer = 1;
        }
        else if (waterPos < 290.0f / 755)
        {
            str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "DrinkMaker_Evaluate_2");
            integer = 2;
        }
        else if (waterPos < 350.0f / 755)
        {
            str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "DrinkMaker_Evaluate_1");
            integer = 2;
        }
        else if (waterPos < 405.0f / 755)
        {
            str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "DrinkMaker_Evaluate_2");
            integer = 2;
        }
        else
        {
            str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "DrinkMaker_Evaluate_3");
            integer = 3;
        }
        (await UIHomeButtleTeaData.Instance.teaMap.GetAnimatorController()).SetInteger("Water", integer);
        UIHomeButtleTeaData.Instance.water = waterPos;
        Debug.Log($"{GetType()}  {waterPos}  {UIHomeButtleTeaData.Instance.water}");
        return str;
    }
}
