using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using System;

public class UIHomeButtleTeaTaMuDialog : UIDialogBase
{
    [SerializeField] UIButton closeBtn;
    [SerializeField] UIText talk;

    public async UniTask SetShowAsync(string talk,Func<UniTask> func)
    {
        await base.ShowAsync();

        transform.SetSiblingIndex(transform.parent.childCount - 1);

        this.talk.SetRawText(talk);
        closeBtn.onClick.RemoveAllListeners();
        closeBtn.onClick.GuardSubscribeAsync(async (o) => { gameObject.SetActive(false); await func.Invoke();  });
    }
}
