using Cysharp.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using Takasho.Schema.Score.ResourceCn.Item.V1;
using UnityEngine;
using Pheonix.Core;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIHomeBubbleTeaAssistMaterialItemList : MonoBehaviour
{
    [SerializeField] UIHomeBubbleTeaNeededItenFrame item;
    [SerializeField] RectTransform itemParent;
    [SerializeField] UIText title;

    [SerializeField] List<int> selected = new List<int>();


    Color clo = new Color();

    WJHPool<GameObject> itemPool = new WJHPool<GameObject>();
    UIHomeBubbleTeaAssistMaterialDialog parentDialog = null;
    List<GameObject> tempObj = new List<GameObject>();

    private void OnDisable()
    {
    }

    public async UniTask SetUp(List<PuzzleDrinkAccessoryMaster> items, UIHomeBubbleTeaAssistMaterialDialog dialog)
    {
        this.item.gameObject.SetActive(false);
        foreach (var pa in tempObj)
        {
            itemPool.PutBack(pa);
        }
        tempObj = new List<GameObject>();
        selected.Clear();
        UpdateTitle();
        parentDialog = dialog;
        selected.Clear();
        foreach (var parm in items)
        {
            UIHomeBubbleTeaNeededItenFrame item = (await itemPool.GetObj(this.item.gameObject)).GetComponent<UIHomeBubbleTeaNeededItenFrame>();
            item.gameObject.GetComponent<RectTransform>().SetParent(itemParent);
            item.GetComponent<RectTransform>().anchoredPosition3D = Vector3.zero;
            item.GetComponent<RectTransform>().rotation = Quaternion.Euler(Vector3.zero);
            item.GetComponent<RectTransform>().localScale = Vector3.one;
            item.transform.SetSiblingIndex(item.transform.parent.childCount - 1);
            CommonAttrite att = new(parm.id,parm.name,0,parm.id);
            await item.SetColor(false);
            await item.SetUp(
                id: async () => att.id,
                itemName: async () =>
                {
                    string name = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, $"DrinkMaker_Accessory_{att.id}");
                    return name;
                },
                count: async () => att.count.ToString(),
                icon: async () => await ResourceManager.Instance.LoadSpriteAsync("BrewTeaIcon", $"yl_frame_icon1_0{att.id}"),
                isItemFarame: false
                );
            (await item.GetIcon()).enabled = true;
            item.GetComponent<Image>().enabled = false;
            var frameSprite = await ResourceManager.Instance.LoadSpriteAsync("BrewTeaIcon", $"yl_frame_icon2_0{att.id}");
            await item.SetFrameSprite(frameSprite);

            item.onclick.GuardSubscribeAsync(async (o) => { await SetSelected(item, att.id); });
            await item.AddOnDownClick(async () =>
            {
                await parentDialog.SetMoveIcon(att.id,item);
            });
            await item.AddOnUpClick(async () =>
            {
                await parentDialog.UpTriggerClick();
            });
            tempObj.Add(item.gameObject);
            item.gameObject.SetActive(true);
        }
    }

    public async UniTask SetSelected(UIHomeBubbleTeaNeededItenFrame item,int id)
    {
        var info = (await UIHomeButtleTeaData.Instance.teaMap.GetAnimatorController()).GetCurrentAnimatorStateInfo(0).IsName("Feeding");
        if (!selected.Contains(id) && !info)
        {
            selected.Add(id);
            await UpdateTitle();
            (await item.GetIcon()).enabled = false;
            item.GetComponent<Image>().enabled = true;
            
            await UIHomeButtleTeaData.Instance.teaMap.SetCharacteranimatorStatus("Layer.Feeding");
            await UIHomeButtleTeaData.Instance.teaMap.PlayParticle(UIHomeBubbleTeaMap.particleSystems.assistMatParticle);
            if (selected.Count >= 2)
            {
                var favore = DataManager.Instance.Master.PuzzleDrinkMakingMaster[UIHomeButtleTeaData.Instance.id].favoredAccessories;
                var normal = DataManager.Instance.Master.PuzzleDrinkMakingMaster[UIHomeButtleTeaData.Instance.id].normalAccessories;
                var unsuitable = DataManager.Instance.Master.PuzzleDrinkMakingMaster[UIHomeButtleTeaData.Instance.id].unsuitableAccessories;
                string str = "";
                var math = 0;
                foreach (var para in selected)
                {
                    math += favore.Contains(para) ? 20 : 0;
                    math += normal.Contains(para) ? 0 : 0;
                    math += unsuitable.Contains(para) ? -10 : 0;
                }
                if (math <= 0)
                {
                    str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "DrinkMaker_Evaluate_3");
                }
                else if (math <= 20)
                {
                    str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "DrinkMaker_Evaluate_2");
                }
                else
                {
                    str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, "DrinkMaker_Evaluate_1");
                }
                await parentDialog.NextWindow(str);
                UIHomeButtleTeaData.Instance.accessory = selected;


            }
        }
    }

    async UniTask UpdateTitle()
    {
        title.SetRawText($"{selected.Count}");
    }
}
