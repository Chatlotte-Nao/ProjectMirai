using Cysharp.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeMissionMainWindow3DBox : MonoBehaviour
{
    [SerializeField] RawImage rawImage;
    [SerializeField] Camera rendererCamera;
    [SerializeField] Animation boxAnimation;
    [SerializeField] int width = 500;
    [SerializeField] int height = 500;
    [SerializeField] int depth = 100;

    private void Start()
    {
        //rawImage
        var texture = new RenderTexture(width, height, depth);
        rendererCamera.targetTexture = texture;
        rawImage.texture = texture;
    }
}
