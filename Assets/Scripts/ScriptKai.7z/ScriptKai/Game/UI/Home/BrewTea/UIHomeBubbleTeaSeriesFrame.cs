﻿using Cysharp.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading.Tasks;
using Pheonix.Core;
using UnityEngine.UI;
using Takasho.Schema.Score.ResourceCn.Item.V1;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using System;

public class UIHomeBubbleTeaSeriesFrame : MonoBehaviour
{
    [SerializeField] UIHomeBubbleTeaDialog teaDialog;
    [SerializeField] UIButton button;
    public ClickEvent onClick => button.onClick;
    [SerializeField] UIText seriesName;
    [SerializeField] Image seriesIcon;
    public GameObject makeList;

    [SerializeField] UIHomeBubbleTeaNeededItenFrame childrenItem;
    [SerializeField] RectTransform childrenItemPar;

    public List<UIHomeBubbleTeaNeededItenFrame> itemList = new List<UIHomeBubbleTeaNeededItenFrame>();
    [SerializeField] List<UIHomeBubbleTeaNeededItenFrame> itemPool = new List<UIHomeBubbleTeaNeededItenFrame>();
    public async UniTask Initializetion()
    {
        makeList.SetActive(false);
        await Task.Delay(System.TimeSpan.Zero);
    }
    public async UniTask SetUp(List<PuzzleDrinkMakingMaster> items, CommonAttrite thisItem, Func<UniTask> func)  
    {
        seriesName.SetRawText($"{LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE,$"DrinkMaker_Type_{thisItem.id}")}");
        seriesIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("BrewTeaIcon", $"DrinkMaker_Type_{thisItem.id}");
        childrenItem.gameObject.SetActive(false);
        foreach (var item in this.itemList)
        {
            await item.gameObject.GetComponent<UIHomeBubbleTeaNeededItenFrame>().SetColor(false);
            item.gameObject.SetActive(false);
            itemPool.Add(item);
        }
        this.itemList = new List<UIHomeBubbleTeaNeededItenFrame>();

        foreach (var item in items)  // 便利每种饮料 用的具体材料
        {
            UIHomeBubbleTeaNeededItenFrame temp = null;   // 提提的材料列表
            if (itemPool.Count != 0)
            {
                temp = itemPool[0];
                itemPool.Remove(temp);
            }
            else
            {
                temp = Instantiate(this.childrenItem.gameObject, childrenItemPar).GetComponent<UIHomeBubbleTeaNeededItenFrame>();
                temp.gameObject.SetActive(false);
            }
            CommonAttrite att = new CommonAttrite(item.id, item.targetDrink, 0, item.id);

            await temp.SetUp(
                id:async() => att.id,
                itemName: async () => 
                {
                    string name = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, $"DrinkMaker_{item.id}");
                    return name;
                },
                count: async() => att.count.ToString(),
                icon: async() =>
                {
                    Sprite sprite = await ResourceManager.Instance.LoadSpriteAsync("BrewTeaIcon", $"{item.id}");
                    return sprite;
                });
            temp.onclick.RemoveAllListeners();
            await temp.GetComponent<UIHomeBubbleTeaNeededItenFrame>().SetColor(false);
            Dictionary<int, int> costs = new Dictionary<int, int>();
            foreach (var parameter in item.costs)
            {
                string[] str = parameter.Split(':');
                costs.Add(int.Parse(str[0]), int.Parse(str[1]));
            }
            temp.onclick.AddListener(async (o) => 
            {
                UIHomeButtleTeaData.Instance.id = item.id;
                await teaDialog.SetMakeTeaBubbleMaterial(costs);
                await func.Invoke();
                foreach (var par in itemList)
                {
                    await par.GetComponent<UIHomeBubbleTeaNeededItenFrame>().SetColor(false);
                }
                await temp.GetComponent<UIHomeBubbleTeaNeededItenFrame>().SetColor(true);
            });
            this.itemList.Add(temp);
            temp.gameObject.SetActive(true);
        }
    }
    public async UniTask HideList()
    {
        makeList.SetActive(false);
    }
}
