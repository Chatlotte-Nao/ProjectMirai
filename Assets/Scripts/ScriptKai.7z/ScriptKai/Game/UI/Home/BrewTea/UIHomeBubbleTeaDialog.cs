using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Threading.Tasks;
using Takasho.Schema.Score.ResourceCn.Item.V1;
using UnityEngine.Events;
using System;
using UnityEngine.UI;
using DG.Tweening;

public class UIHomeBubbleTeaDialog : UIDialogBase
{
    [Header("---------")]
    [SerializeField] UIButton makeButton;

    //[SerializeField] UIButton discription;
    [SerializeField] GameObject main;
    [SerializeField] UIHomeBubbleTeaSeriesFrame seriesPrefab;
    [SerializeField] RectTransform seriesPrefabPar;
    [SerializeField] GameObject makeInformation;
    [SerializeField] UIHomeBubbleTeaNeededItenFrame neededItem;
    [SerializeField] RectTransform neededItemPar;

    [SerializeField] List<UIHomeBubbleTeaSeriesFrame> seriesList = new List<UIHomeBubbleTeaSeriesFrame>();
    [SerializeField] List<UIHomeBubbleTeaSeriesFrame> seriesPool = new List<UIHomeBubbleTeaSeriesFrame>();

    public UnityEvent<string> openClick = new UnityEvent<string>();
    [SerializeField] RectTransform moveView;

    bool isMake = false;

    private WJHPool<GameObject> needPool = new WJHPool<GameObject>();

    float startPos;
    string str = "";
    private List<GameObject> tempPool = new List<GameObject>();

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            startPos = Input.mousePosition.y;
        }
        if (Input.GetMouseButton(0))
        {
            var pos = moveView.anchoredPosition3D.y + (Input.mousePosition.y - startPos);
            if (pos > moveView.childCount * 90.0f + 200.0f)
            {
                pos = moveView.childCount * 90.0f + 100.0f;
            }
            if (pos < 0)
            {
                pos = 0;
            }
            startPos = Input.mousePosition.y;
            if(!UIHomeButtleTeaData.Instance.isTutoria)
                moveView.anchoredPosition3D = new Vector3(moveView.anchoredPosition3D.x, pos, moveView.anchoredPosition3D.z);
        }
    }

    public async UniTask SeriesSetUp(List<int> drinkId)
    {

        await ShowAsync();
        // discription.onClick.RemoveAllListeners();
        // discription.onClick.GuardSubscribeAsync(async (o) => { await UI.Popup.ShowUIHomeBubbleTeaUserGuide("饮料制作提示");});

        neededItem.gameObject.SetActive(false);
        makeInformation.gameObject.SetActive(false);
        seriesPrefab.gameObject.SetActive(false);
        List<PuzzleDrinkMakingMaster> items = new List<PuzzleDrinkMakingMaster>();
        List<int> drikVariety = new List<int>();
        List<string> targetDrink = new List<string>();

        Dictionary<int, List<PuzzleDrinkMakingMaster>> drinkVar = new Dictionary<int, List<PuzzleDrinkMakingMaster>>();
        foreach (var item in drinkId)
        {
            PuzzleDrinkMakingMaster t = DataManager.Instance.Master.PuzzleDrinkMakingMaster[int.Parse(item.ToString())];
            items.Add(t);
            drikVariety.Add(t.drinkVariety);
            targetDrink.Add(t.targetDrink);

            if (drinkVar.ContainsKey(t.drinkVariety))
            {
                drinkVar[t.drinkVariety].Add(t);
            }
            else
            {
                drinkVar.Add(t.drinkVariety, new List<PuzzleDrinkMakingMaster>(new PuzzleDrinkMakingMaster[]{ t}));
            }
        }
        foreach (var item in tempPool)
        {
            item.SetActive(false);
            await needPool.PutBack(item);
        }
        tempPool = new List<GameObject>();

        foreach (var item in items)
        {
            str += item.id + " - ";
        }
        Debug.Log($"{GetType()}  获取到 PlayerItem number {items.Count} \n id: {str}");
        foreach (var item in this.seriesList)
        {
            item.gameObject.SetActive(false);
            seriesPool.Add(item);
        }
        this.seriesList = new List<UIHomeBubbleTeaSeriesFrame>();

        foreach (var parm in drinkVar) //遍历每个系类
        {
            UIHomeBubbleTeaSeriesFrame temp = null;

            if (seriesPool.Count != 0)
            {
                temp = seriesPool[0];
                seriesPool.Remove(temp);
            }
            else
            {
                temp = Instantiate(this.seriesPrefab.gameObject, seriesPrefabPar).GetComponent<UIHomeBubbleTeaSeriesFrame>();
                temp.gameObject.SetActive(false);
            }
            await temp.Initializetion();
            CommonAttrite att = new CommonAttrite(parm.Key, DataManager.Instance.Master.PuzzleDrinkTypeMaster[parm.Key].name, 0, DataManager.Instance.Master.PuzzleDrinkTypeMaster[parm.Key].id);
            await temp.SetUp(parm.Value, att, async () =>
            {
                makeInformation.gameObject.SetActive(true); 
            });
            temp.onClick.GuardSubscribeAsync(async (o) => 
            {
                await OnClick(temp.makeList);
                makeInformation.gameObject.SetActive(false);
            });

            this.seriesList.Add(temp);
            temp.gameObject.SetActive(true);
        }
    }

    public async UniTask ShowMakeListSetUp(GameObject o)
    {
        foreach (var item in seriesList)
        {
            await item.HideList();
        }
        o.SetActive(!o.activeSelf);
        for (int i = 0; i < o.transform.childCount; i++)
        {
            await o.transform.GetChild(i).GetComponent<UIHomeBubbleTeaNeededItenFrame>().SetColor(false);
        }
    }

    async UniTask OnClick(GameObject o)
    {
        await ShowMakeListSetUp(o);
        await Task.Delay(System.TimeSpan.Zero);
    }

    public async UniTask SetMakeTeaBubbleMaterial(Dictionary<int,int> items)
    {
        isMake = true;
        //makeInformation.SetActive(false);
        makeButton.GetComponent<Image>().color = Color.white;

        foreach (var item in tempPool)
        {
            item.SetActive(false);
            await needPool.PutBack(item);
        }
        tempPool = new List<GameObject>();
        neededItemPar.gameObject.SetActive(false);
        foreach (var item in items)
        {
            UIHomeBubbleTeaNeededItenFrame need = (await needPool.GetObj(neededItem.gameObject)).GetComponent<UIHomeBubbleTeaNeededItenFrame>();
            tempPool.Add(need.gameObject);
            need.gameObject.SetActive(true);
            need.gameObject.GetComponent<RectTransform>().SetParent(neededItemPar);
            need.transform.SetSiblingIndex(need.transform.parent.childCount - 1);
            need.gameObject.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(0, 0, 0);
            CommonAttrite att = new CommonAttrite(item.Key, LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ITEM,$"{item.Key}_name"),item.Value, item.Key);

            await need.SetUp(
                id: async () => att.id,
                itemName: async () =>
                {
                    string name = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ITEM, $"{att.id}_name");
                    return name;
                },
                count: async () => 
                {
                    long haveItemNumber = 0;
                    var playeritem = DataManager.Instance.Player.Item.TryGet(att.id);
                    if (playeritem != null)
                        haveItemNumber = playeritem.Count;

                    var number = ($"{haveItemNumber}/{att.count}");
                    return number;
                },
                icon: async () =>
                {
                    Sprite sprite = await ResourceManager.Instance.LoadSpriteAsync("ItemIcon", $"{att.id}");
                    return sprite;
                },
                isItemFarame: true
                );



            //判断是否有足够多的物品
            Debug.Log($"{GetType()}  -----------------------   这里需要判断物品是否足够   ----------------------");

            if (DataManager.Instance.Player.Item.TryGet(item.Key) == null || (item.Value > DataManager.Instance.Player.Item.TryGet(item.Key).Count))
            {
                isMake = false;
                makeButton.GetComponent<Image>().color = Color.gray;
                makeButton.onClick.RemoveAllListeners();
            }
        }
        makeButton.onClick.RemoveAllListeners();
        switch (isMake)
        {
            case true:
                makeButton.onClick.GuardSubscribeAsync(async (o) => 
                {
                    await MakeButtonOnClick(items);
                }).AddTo(mSubscriptions);
                break;
            case false:
                makeButton.onClick.GuardSubscribeAsync(async (_) => await UIHomeButtleTeaData.Instance.brewTeaHint.ShowHint());
                break;
        }
        makeInformation.SetActive(true);
        neededItemPar.gameObject.SetActive(true);
    }

    async UniTask MakeButtonOnClick(Dictionary<int, int> items)
    {
        if (isMake)
        {
            await UIHomeButtleTeaData.Instance.teaMap.SetCharacteranimatorStatus("Layer.Standing");
            ////扣除道具
            //str = "";
            //foreach (var item in items)
            //{
            //    var request = new Takasho.Schema.Score.PlayerApi.ScoreDebugConsumeContentV1.Types.Request();
            //    request.Items.Add(new Takasho.Schema.Score.PlayerApi.ScoreDebugConsumeContentV1.Types.Request.Types.Item()
            //    {
            //        ContentMasterId = item.Key,
            //        Count = item.Value,
            //    });
            //    var op = ApiEndpoints.DebugCostItem.Instance.CreateOperation(request);
            //    await TakashoHandler.Instance.ExecuteOperationAsync(op);
            //    DataManager.Instance.Player.UpdateCommon(op.Response.Common, op.RespondTimestamp);

            //    str += $"{item.Key}:{item.Value} - ";
            //}
            //Debug.Log($"{GetType()}   扣除道具     {str}");

            openClick.Invoke("干得漂亮");
        }
    }
}
