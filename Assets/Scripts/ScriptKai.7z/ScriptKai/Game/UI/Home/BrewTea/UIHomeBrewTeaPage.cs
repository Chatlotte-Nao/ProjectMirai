using Cysharp.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using Pheonix.Core;
using System;
using DG.Tweening;

public class UIHomeBrewTeaPage : UIPageBase
{
    private GameObject mainCharacter = null;
    private UIDialogBase nowOpenDialog = null;
    private UIHomeBubbleTeaMap teaMap = null;
    private UIHomeBubbleTeaAssistMaterialDialog uiHameButtleTeaAssistMaterialDialog = null;
    private UIHomeBrewTeaDialog uIHomeBrewTeaDialog = null;
    private UIHomeBubbleTeaBlenderDialog uIHomeBubbleTeaBlenderDialog = null;
    private UIHomeBubbleTeaDialog uiHomeBubbleTeaDialog = null;
    private UIHomeBubbleTeaFinishPopup uIHomeBubbleTeaFinishPopup = null;
    private UIHomeBubbleTeaPourWaterDialog uIHomeBubbleTeaPourWaterDialog = null;

    private UIHomeButtleTeaTaMuDialog uIHomeButtleTeaTaMuDialog = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        await UI.ScreenEffect.Fade(1);
        await MapSceneManager.Instance.LoadOtherSceneAsync("Drink");
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        teaMap = (await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("UI/Home/BrewTea/UIHomeBubbleTeaMap")).GetComponent<UIHomeBubbleTeaMap>();
        UIHomeButtleTeaData.Instance.teaMap = teaMap;
        await base.ShowAsync(showType);
        uIHomeButtleTeaTaMuDialog = (await UI.Dialog.CreateAsync("UI/Home/BrewTea/UIHomeButtleTeaTaMuDialog", CanvasType.App0)).GetComponent<UIHomeButtleTeaTaMuDialog>();
        uiHomeBubbleTeaDialog = (await UI.Dialog.CreateAsync("UI/Home/BrewTea/UIHomeBubbleTeaDialog", CanvasType.App0)).GetComponent<UIHomeBubbleTeaDialog>();
        uIHomeBubbleTeaPourWaterDialog = (await UI.Dialog.CreateAsync("UI/Home/BrewTea/UIHomeBubbleTeaPourWaterDialog", CanvasType.App0)).GetComponent<UIHomeBubbleTeaPourWaterDialog>();
        uiHameButtleTeaAssistMaterialDialog = (await UI.Dialog.CreateAsync("UI/Home/BrewTea/UIHomeBubbleTeaAssistMaterialDialog", CanvasType.App0)).GetComponent<UIHomeBubbleTeaAssistMaterialDialog>();
        uIHomeBubbleTeaBlenderDialog = (await UI.Dialog.CreateAsync("UI/Home/BrewTea/UIHomeBubbleTeaBlenderDialog", CanvasType.App0)).GetComponent<UIHomeBubbleTeaBlenderDialog>();
        uIHomeBrewTeaDialog = (await UI.Dialog.CreateAsync("UI/Home/BrewTea/UIHomeBrewTeaDialog", CanvasType.App0)).GetComponent<UIHomeBrewTeaDialog>();
        uIHomeBubbleTeaFinishPopup = (await UI.Dialog.CreateAsync("UI/Home/BrewTea/UIHomeBubbleTeaFinishPopup", CanvasType.App0)).GetComponent<UIHomeBubbleTeaFinishPopup>();
        UIHomeButtleTeaData.Instance.brewTeaHint = uIHomeBrewTeaDialog;

        uiHomeBubbleTeaDialog.openClick.GuardSubscribeAsync(async (o)=> await UIHomeBubbleTeaDialogOpenClick());

        uIHomeBubbleTeaPourWaterDialog.openClick.GuardSubscribeAsync(async (s, l) => { await UIHomeBubbleTeaPourWaterDialogOpenClick(s, l); });

        uiHameButtleTeaAssistMaterialDialog.openClick.GuardSubscribeAsync(async (s) => { await UIHameButtleTeaAssistMaterialDialogOpenClick(s); });

        uIHomeBubbleTeaBlenderDialog.openClick.GuardSubscribeAsync(async (s) => { await UIHomeBubbleTeaBlenderDialogOpenClick (s); });
        await uIHomeBrewTeaDialog.SetUp(async () =>
        {
            if (nowOpenDialog != null)
            {
                await nowOpenDialog.HideAsync();
                await ShowInit();
                UIHomeButtleTeaData.Instance.teaMap.MoveCamera(new Vector3(-5.29f, 2.32f, 5), Quaternion.Euler(12.0f, 141.1f, 0), 30.0f);
            }
        });

        await ShowInit();
        await UI.ScreenEffect.Fade(0);
    }

    private async UniTask ShowInit()
    {
        List<int> ids = new List<int>();
        await teaMap.StopAllParticle();
        foreach (var item in DataManager.Instance.Master.PuzzleDrinkMakingMaster)
        {
            ids.Add(item.Key);
        }
        await uiHomeBubbleTeaDialog.SeriesSetUp(ids);
        await teaMap.SetUpShowAsync();
        nowOpenDialog = uiHomeBubbleTeaDialog;

        uIHomeBrewTeaDialog.openClick.RemoveAllListeners();
        uIHomeBrewTeaDialog.openClick.GuardSubscribeAsync(async () =>
        {
            await UI.ScreenEffect.Fade(1);
            await UI.Page.CloseCurrentPage(true);
            await changeSubPage("advBuilding[11]", "");
        });
    }

    async UniTask UIHomeBubbleTeaDialogOpenClick()
    {
        await DOTween.To(() => 2, value => { }, 0, 2).OnComplete(async () =>
        {
            await uIHomeBubbleTeaPourWaterDialog.ShowAsync();
            await uiHomeBubbleTeaDialog.HideAsync();
            await teaMap.SetCharacteranimatorStatus("Layer.TakeOut_01");
            UIHomeButtleTeaData.Instance.teaMap.MoveCamera(new Vector3(-4.95f, 2.88f, 6.45f), Quaternion.Euler(18.8f, 150.6f, 0), 15.0f);
            nowOpenDialog = uIHomeBubbleTeaPourWaterDialog;

            uIHomeBrewTeaDialog.openClick.RemoveAllListeners();
            uIHomeBrewTeaDialog.openClick.GuardSubscribeAsync(async () =>
            {
                await uIHomeBrewTeaDialog.OpenWindow();
            });
        });
    }

    async UniTask UIHomeBubbleTeaPourWaterDialogOpenClick(string s,List<int> l)
    {
        await DOTween.To(() => 2, value => { }, 0, 3).OnComplete(async () =>
        {
            await uIHomeButtleTeaTaMuDialog.SetShowAsync($"{s}", async () =>
            {
                await uIHomeBubbleTeaPourWaterDialog.HideAsync();
                await uiHameButtleTeaAssistMaterialDialog.SetUp(l);
                await uiHameButtleTeaAssistMaterialDialog.ShowAsync();
                await teaMap.SetCharacteranimatorStatus("Layer.TakeOut_02");
                nowOpenDialog = uiHameButtleTeaAssistMaterialDialog;
            });
        });
    }

    async UniTask UIHameButtleTeaAssistMaterialDialogOpenClick(string s)
    {
        await DOTween.To(() => 2, value => { }, 0, 3).OnComplete(async () =>
        {
            await uIHomeButtleTeaTaMuDialog.SetShowAsync($"{s}", async () =>
            {
                await uIHomeBubbleTeaBlenderDialog.ShowAsync();
                await uiHameButtleTeaAssistMaterialDialog.HideAsync();
                await teaMap.SetCharacteranimatorStatus("Layer.TakeOut_02 0");
                nowOpenDialog = uIHomeBubbleTeaBlenderDialog;
            });
        });
    }

    async UniTask UIHomeBubbleTeaBlenderDialogOpenClick(string s)
    {
        await DOTween.To(() => 2, value => { }, 0, 3).OnComplete(async () =>
        {
            await uIHomeButtleTeaTaMuDialog.SetShowAsync($"{s}", async () =>
            {
                await uIHomeBubbleTeaBlenderDialog.HideAsync();
                var t = await UIHomeButtleTeaData.Instance.GetAward();
                await teaMap.SetCharacteranimatorStatus("Layer.Show_01");
                await uIHomeBubbleTeaFinishPopup.SetUp(t.playerItems, async () =>
                {
                    //await ShowInit();
                    await UI.ScreenEffect.Fade(1);
                    await UI.Page.CloseCurrentPage(true);
                    await changeSubPage("advBuilding[11]", "");
                }, t.grad);
                await UIHomeButtleTeaData.Instance.Server();
            });
        });
    }

    private async UniTask changeSubPage(string map, string room)
    {
        //await UI.ScreenEffect.Fade(1);
        await MapSceneManager.Instance.UnloadOtherSceneAsync("Drink");
        var mapData = DataManager.Instance.Master.Location[map];
        await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null , MapSceneManager.SceneType.Home, "2F_route (26)");


        if (DataManager.Instance.Local.UserInfo.playerPosition != Vector3.zero)
        {
            MapSceneManager.Instance.CurrentScene.player.SetPosition(DataManager.Instance.Local.UserInfo
                .playerPosition);
            DataManager.Instance.Local.UserInfo.playerPosition = Vector3.zero;
        }
        DataManager.Instance.Local.UserInfo.currentHomeMap = map;
        DataManager.Instance.Local.UserInfo.currentHomeRoom = room;


        await UI.ScreenEffect.Fade(0);
    }

    public override void Dispose()
    {
        if (uIHomeButtleTeaTaMuDialog != null)
        {
            uIHomeButtleTeaTaMuDialog.Dispose();
            uIHomeButtleTeaTaMuDialog = null;
        }
        if (uiHomeBubbleTeaDialog != null)
        {
            uiHomeBubbleTeaDialog.Dispose();
            uiHomeBubbleTeaDialog = null;
        }
        if (uIHomeBubbleTeaPourWaterDialog != null)
        {
            uIHomeBubbleTeaPourWaterDialog.Dispose();
            uIHomeBubbleTeaPourWaterDialog = null;
        }
        if (uiHameButtleTeaAssistMaterialDialog != null)
        {
            uiHameButtleTeaAssistMaterialDialog.Dispose();
            uiHameButtleTeaAssistMaterialDialog = null;
        }
        if (uIHomeBubbleTeaFinishPopup != null)
        {
            uIHomeBubbleTeaFinishPopup.Dispose();
            uIHomeBubbleTeaFinishPopup = null;
        }
        if (teaMap != null)
        {
            GameObject.Destroy(teaMap.gameObject);
            teaMap = null;
        }
        if (uIHomeBubbleTeaBlenderDialog != null)
        {
            uIHomeBubbleTeaBlenderDialog.Dispose();
            uIHomeBubbleTeaBlenderDialog = null;
        }

        if (uIHomeBrewTeaDialog != null)
        {
            uIHomeBrewTeaDialog.Dispose();
            uIHomeBrewTeaDialog = null;
        }
        if (mainCharacter != null)
        {
            GameObject.Destroy(mainCharacter);
        }
    }
}
