using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Mission.V1;
using TMPro;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIMissionRewardItem: MonoBehaviour
{
    [SerializeField] private UIButton button;
    [SerializeField] private UIText requirePoint;
    [SerializeField] Image logo;
    [SerializeField] Sprite[] images;
    [SerializeField] Image lockImg;
    [SerializeField] Animation received;
    [SerializeField] private GameObject fx;
    private CnMissionPointRewardMaster mMaster;

    public ClickEvent OnClick => button.onClick;

    public void Setup(CnMissionPointRewardMaster master)
    {
        mMaster = master;
        fx.SetActive(false);
        if (DataManager.Instance.Player.MissionPoint.HasReceived(master))
        {
            requirePoint.SetLabel(LocalizeManager.DATA_TYPE.MISSION_EVENT_NAME, "MISSION_REWARDS_RECEIVED");
            received.Stop();
            logo.overrideSprite = images[2];
            lockImg.gameObject.SetActive(false);
        }
        else if (DataManager.Instance.Player.MissionPoint.CanReceive(master))
        {
            requirePoint.SetFormat(LocalizeManager.DATA_TYPE.MISSION_EVENT_NAME, "MISSION_REWARDS_CAN_RECEIVE");
            logo.color = Color.white;
            lockImg.gameObject.SetActive(false);
            received.Play();
            fx.SetActive(true);
            logo.overrideSprite = images[1];
        }
        else
        {
            requirePoint.SetFormat(LocalizeManager.DATA_TYPE.MISSION_EVENT_NAME, "MISSION_REWARDS_REQUIRE", new object[]{master.targetPoint});
            logo.overrideSprite = images[0];
            received.Stop();
            logo.color = Color.gray;
            lockImg.gameObject.SetActive(true);
        }
    }
    
    public class OnReceiveEvent : UnityEvent<CnMissionPointRewardMaster>
    {
    }
}