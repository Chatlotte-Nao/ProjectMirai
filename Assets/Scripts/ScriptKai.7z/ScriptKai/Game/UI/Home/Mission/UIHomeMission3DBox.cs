using Cysharp.Threading.Tasks;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Pheonix.Core;

public class UIHomeMission3DBox : MonoBehaviour
{
    [SerializeField] UnityEvent openClick;

    public async UniTask SetUpOpenClick(Func<UniTask> openClick)
    {
        this.openClick.RemoveAllListeners();
        this.openClick.GuardSubscribeAsync(openClick);
    }

    public void OpenBox()
    {

    }
    public void CloseBox()
    {

    }

    private void OnMouseUpAsButton()
    {
        openClick.Invoke();
    }
}
