using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Mission.V1;
using TMPro;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIMissionListItem: MonoBehaviour, IDisposable
{
    [SerializeField] private RectTransform progressBar;
    [SerializeField] private RectTransform progressContainer;
    [SerializeField] private TextMeshProUGUI progressText;
    [SerializeField] private UIText detailText;
    [SerializeField] private UIText rewardPointText;
    [SerializeField] private BaseItem itemPrefab;
    [SerializeField] private RectTransform itemsContainer;
    [SerializeField] private UIButton buttonReceive;
    [SerializeField] private UIButton buttonGoto;
    [SerializeField] private UIButton buttonDone;
    [SerializeField] private GameObject progressObj;
    [SerializeField] private Image receiveImage;
    [SerializeField] private Image buttonImage;
    public ClickEvent OnClickMissionAction = new ClickEvent();
    
    private List<BaseItem> mItems = new List<BaseItem>();
    public PlayerMission mMission;
    protected CompositeDisposable mSubscriptions = CompositeDisposable.Create();
    CnMissionMaster master;
    public void Setup(PlayerMission mission)
    {
        buttonReceive.onClick.Subscribe(OnClickMissionAction).AddTo(mSubscriptions);
        buttonGoto.onClick.Subscribe(OnClickMissionAction).AddTo(mSubscriptions);
        mMission = mission;
        master = DataManager.Instance.Master.Mission[mMission.MissionMasterId];
        UpdateData(mission);
        SetDetails(master);
    }

    public void UpdateData(PlayerMission mission)
    {
        mMission = mission;
        master = DataManager.Instance.Master.Mission[mMission.MissionMasterId];
        SetProgress(master);        
    }

    private void SetDetails(CnMissionMaster master)
    {
        foreach (var entry in mItems)
        {
            //entry.transform.parent = null;
            Destroy(entry.gameObject);
        }
        mItems.Clear();
        foreach (var item in master.GetRewards())
        {
            var ss = item.Split(':');
            var id = long.Parse(ss[0]);
            var obj = Instantiate(itemPrefab, itemsContainer);
            if (ss.Length > 1)
            {
                obj.Setup(id, ss[1]);
            }
            else
            {
                Log.ErrorFormat("MissionMaster Rewards Error");
            }

            obj.gameObject.SetActive(true);
            mItems.Add(obj);
        }
    }
    
    private void SetProgress(CnMissionMaster master)
    {
        detailText.SetRawText(master.GetLocalizedText());
        rewardPointText.SetRawText($"+{master.getPoint}");
        //rewardPointText.gameObject.SetActive(master.getPoint > 0);
        progressObj.SetActive(master.isShowProgress);
        var total = master.requiredTotalIndex;
        var current = Math.Min(mMission.Progress, total);
        var totalWidth = progressContainer.rect.width;
        progressText.text = $"{current}/{total}";
        var currentWidth = ((float) current / (float) total) * totalWidth;

        buttonDone.gameObject.SetActive(false);
        buttonGoto.gameObject.SetActive(false);
        buttonReceive.gameObject.SetActive(false);
        receiveImage.color = Color.white;
        buttonImage.color = master.goToPanel != string.Empty ? Color.white : Color.black;
        if (!mMission.CanReceive && current >= total)
        {
            buttonDone.gameObject.SetActive(true);
            //progressContainer.gameObject.SetActive(false);
            progressText.text = $"{total}/{total}";
        }
        else
        {
            if (mMission.CanReceive)
            {
                buttonReceive.gameObject.SetActive(true);
                currentWidth = totalWidth;
                progressText.text = $"{total}/{total}";
            }
            else
            {
                buttonGoto.gameObject.SetActive(master.goToPanel != string.Empty);
                // if (master.goToPanel == string.Empty)
                // {
                //     buttonReceive.gameObject.SetActive(true);
                //     receiveImage.color = Color.black;
                // }
            }
        }
        progressBar.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, currentWidth);
    }
    
    public void Dispose()
    {
        if (mSubscriptions != null)
        {
            mSubscriptions.Dispose();
            mSubscriptions = null;
        }
        Destroy(gameObject);
    }

    public class OnActionEvent : UnityEvent<PlayerMission>
    {
    }
}
