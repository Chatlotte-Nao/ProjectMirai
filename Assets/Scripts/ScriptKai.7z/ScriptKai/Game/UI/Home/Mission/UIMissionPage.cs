using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Mission.V1;
using Cysharp.Threading.Tasks;

public class UIMissionPage: UIPageBase
{
    UIHomeHeaderParam headerParam = new UIHomeHeaderParam();
    private CnMissionMaster.MissionCategory mCurrentCategory = CnMissionMaster.MissionCategory.NewbieTask;
    private UIMissionMainWindow mMainWindow = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        if(param!= null)
            mCurrentCategory = (CnMissionMaster.MissionCategory)param;
        else
            mCurrentCategory = CnMissionMaster.MissionCategory.NewbieTask;
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeMissionMainWindow, CanvasType.App0) as UIMissionMainWindow;

        if (mCurrentCategory == CnMissionMaster.MissionCategory.NewbieTask && MissionUtil.IsMissionNewReceive())
        {
            mCurrentCategory = CnMissionMaster.MissionCategory.DAILY;
        }

        mMainWindow.SetUp(mCurrentCategory);
        mMainWindow.OnClickMissionAction.GuardSubscribeAsync(OnClickMissionAction).AddTo(mSubscriptions);
        mMainWindow.OnReceiveMissionPointRewardsAction.GuardSubscribeAsync(OnClickReceiveMissionPointRewards).AddTo(mSubscriptions);
        mMainWindow.OnClickReceiveAll.GuardSubscribeAsync(OnClickReceiveAll).AddTo(mSubscriptions);
        mMainWindow.OnCloseClick.GuardSubscribeAsync(onClose).AddTo(mSubscriptions);
        
        headerParam.visibleMenu = false;
        headerParam.visibleRightRank = false;
        headerParam.visibleBack = true;
        headerParam.visibleNavigation = true;
        headerParam.visibleHome = true;
        
        headerParam.showResType.Add(UIHeaderResType.Coin);
        headerParam.showResType.Add(UIHeaderResType.GemFree);
        headerParam.showResType.Add(UIHeaderResType.GemPaid);
        headerParam.showResType.Add(UIHeaderResType.Stamina);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);
        await base.ShowAsync(showType);
        if(showType == UIPageShowType.Back){
            await MissionService.RequestMissionData();
        }
        // else if (mCurrentCategory == CnMissionMaster.MissionCategory.DAILY)
        // {
        //     var reward =DataManager.Instance.Player.Mission.GetList()
        //         .OrderBy(m => DataManager.Instance.Master.Mission[m.MissionMasterId].missionCategory).FirstOrDefault(m=>m.CanReceive && m.ReceiveRewardsAt <= 0);
        //     if (reward != null)
        //     {
        //         mCurrentCategory = (CnMissionMaster.MissionCategory) DataManager.Instance.Master.Mission[reward.MissionMasterId].missionCategory;
        //         mMainWindow.SetUp(mCurrentCategory);
        //     }
        // } 
        mMainWindow.UpdateContent();
        await mMainWindow.ShowAsync(showType);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await mMainWindow.HideAsync(showType);

    }

    async UniTask onClose(GameObject o)
    {
        await UI.Page.CloseCurrentPage();
    }

    async UniTask OnClickMissionAction(PlayerMission mission)
    {
        var master = DataManager.Instance.Master.Mission[mission.MissionMasterId];
        if (mission.CanReceive)   //判断是不是可以被领取
        {
            await MissionService.FinishMission(mission.MissionMasterId);
            await MissionService.RequestMissionData();
            mMainWindow.UpdateContent();
            if (master.GetRewards().Count > 0)
            {
                await UI.Popup.ShowItemGetPopupAsync(master.GetRewards());
            }
        }
        else // 未完成
        {
            if (master.goToPanel == string.Empty)
            {
                return;
            }

            if (master.requireCondition > 0)
            {
                if (DataManager.Instance.Master.FunctionUnlock[master.requireCondition].requirePlayerLevel >
                    DataManager.Instance.Player.Player.GetLevel())
                {
                    var msg = string.Format(
                        LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Level_Format"),
                        DataManager.Instance.Master.FunctionUnlock[master.requireCondition].requirePlayerLevel);
                    UI.Popup.ShowPopMessage(msg);
                    return;
                }

                var stageId = DataManager.Instance.Master.FunctionUnlock[master.requireCondition].requireStageId;
                if (stageId > 0 && !StoryUtil.IsClear(stageId))
                {
                    var chapterName =
                        LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{stageId}_name");
                    int chapterNum = DataManager.Instance.Master.Chapter[stageId].chapter;
                    var msg = string.Format(
                        LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Stage_Format"),
                        chapterNum, chapterName);
                    UI.Popup.ShowPopMessage(msg);
                    return;
                }
            }
            await CommonUtil.JumpToTargetPage(master.goToPanel);
            Log.Debug(master.id);
        }
    }

    async UniTask OnClickReceiveMissionPointRewards(CnMissionPointRewardMaster master)
    {
        if (!DataManager.Instance.Player.MissionPoint.CanReceive(master))
        {
            await UI.Popup.ShowItemRewardsPopupAsync(master.rewards);
            return;
        }
        if (DataManager.Instance.Player.MissionPoint.HasReceived(master))
        { 
            var str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MISSION_EVENT_NAME, "MISSION_REWARDS_RECEIVED2");
            await UI.Popup.ShowItemRewardsPopupAsync(master.rewards,str);
            // await UI.Popup.ShowPopupMessageAsync(str);
            return;
        }
        var isLevel = await MissionService.ReceiveMissionPointRewards(master.id);
        mMainWindow.UpdateContent(); 
        await UI.Popup.ShowItemGetPopupAsync(master.rewards);
        if (isLevel)
        {
            await UI.Popup.ShowCommonLevelUpAsync();
        }
    }


    async UniTask OnClickReceiveAll(CnMissionMaster.MissionCategory category)
    {
        // var availableMissions = new List<PlayerMission>(DataManager.Instance.Player.Mission.GetList())
        //     .Where(m => DataManager.Instance.Master.Mission[m.MissionMasterId].missionCategory == (int)category)
        //     .Where(m => m.CanReceive && m.ReceiveRewardsAt<0);
        
        var rewards = await MissionService.ReceiveAllMissionRewardsV1((int)category);
        // List<string> rewards = new List<string>();
        // foreach (var mission in availableMissions)
        // {
        //     foreach (var reward in DataManager.Instance.Master.Mission[mission.MissionMasterId].rewards)
        //     {
        //         rewards.Add(reward);
        //     }
        //     //var popup =  await UI.Popup.ShowItemGetPopupAsync(rewards);
        //     //await UniTask.WaitUntil(() => popup == null);
        // }
        if (rewards != null && rewards.Count > 0)
        {
            await UI.Popup.ShowItemGetPopupAsync(rewards);
        }
        await MissionService.RequestMissionData();
        mMainWindow.UpdateContent();
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
    }
}