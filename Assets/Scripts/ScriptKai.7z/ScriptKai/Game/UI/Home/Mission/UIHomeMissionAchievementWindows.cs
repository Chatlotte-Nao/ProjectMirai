
using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using TMPro;

public class UIHomeMissionAchievementWindows : UIDialogBase
{
    [SerializeField] RectTransform main;
    [SerializeField] RectTransform background;
    [SerializeField] UIText text;

    
    [SerializeField] float duration;
    [SerializeField] float stopTime;

    [SerializeField] UIText achievementType;

    float startPosY;
    float endPosY;
    float screenHeight;

    int index = 0;
    List<string> achievements = new List<string>();
    List<int> type = new List<int>();
    bool isLoop = false;
    private async UniTask Init()
    {
        //screenHeight = transform.parent ? transform.parent.gameObject.GetComponent<RectTransform>().sizeDelta.y : 0;
        //startPosY = -(screenHeight/2 + background.rect.width/2);
        //endPosY = -(screenHeight/2 - background.rect.width/2 - background.rect.width / 2);
        //main.localPosition = new Vector3(0, startPosY, 0);
    }

    public async UniTask ActionShow(Dictionary<string,int> achievements)
    {
        gameObject.SetActive(false);
        if (isLoop)
        {
            foreach (var item in achievements)
            {
                this.achievements.Add(item.Key);
                this.type.Add(item.Value);
            }
            if (index == 0 && isLoop)
            {
                //Debug.Log($"{GetType()}  û���������еĵ���   ִ�г�ʼ��   Show   {achievements.Count}");
                await Init();
                await Show(this.achievements, this.type);
            }
        }
        else
        {
            //Debug.Log($"{GetType()}  ��ǰΪ��һ�λ�ȡ����  ��ʼ��  ������");
        }
        isLoop = true;
    }
    private async UniTask Show(List<string> achievements,List<int> type)
    {
        if (index >= achievements.Count)
        {
            this.index = 0;
            this.achievements.Clear();
            this.type.Clear();
            return;
        }
        //Debug.Log($"{GetType()}  index: {index}  type: {type[0]}  achievements: {achievements[0]}");
        while (type[index] == 1 || type[index] == 6)
        {
            index++;
            if (index >= achievements.Count)
            {
                this.index = 0;
                this.achievements.Clear();
                this.type.Clear();
                return;
            }
        }
        if (achievements.Count == 0)
            return;

        achievementType.SetRawText(LocalizeManager.Instance.GetCommonText($"Common_Mission_Type_{type[index]}"));

        gameObject.SetActive(true);
        Debug.Log($"{GetType()}  {achievements.Count}   {index + 1} ");
        text.SetRawText(achievements[index]);
        this.index++;
        //main.sizeDelta = new Vector2(0, startPosY);
        //await main.DOLocalMoveY(endPosY, duration, false).OnComplete(() => { 
        //    main.DOLocalMoveY(main.localPosition.y, stopTime, false).OnComplete(() => { 
        //        main.DOLocalMoveY(startPosY, duration, false).OnComplete(() => { 
        //            gameObject.SetActive(false); AsyncManager.Instance.StartAsync(async () => { await Show(achievements, type);
        //            }); 
        //        }); }); });
        mAnimation.Play(showAnimation.name);
        var time = showAnimation.length + stopTime;
        await DOTween.To(() => 2, value => { }, 0, time)
            .OnComplete(() =>
            {
                mAnimation.Play(hideAnimation.name);
                time = hideAnimation.length;
                DOTween.To(() => 2, value => { }, 0, time)
                    .OnComplete(() =>
                    {
                        gameObject.SetActive(false); 
                        AsyncManager.Instance.StartAsync(async () => await Show(achievements, type));
                        });
            });
    }
}
