using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using Takasho.Schema.Score.ResourceCn.Mission.V1;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using System;

public class UIHomeMissionNewbieTaskItem : UIDialogBase
{
    [SerializeField] GameObject isAccomplish;
    [SerializeField] UIText missionInformation;
    [SerializeField] Image itemIcom;
    [SerializeField] UIText itemNumber;
    [SerializeField] GameObject getedImage;
    [SerializeField] GameObject getedImage2;
    [SerializeField] UIButton canReceiveButton;
    [SerializeField] Image acticleFrame;
    [SerializeField] Material garyMaterial;

    public EventMissionPlayer accomplishButtonClick = new EventMissionPlayer();

    PlayerMission playerMission = null;

    Dictionary<long, int> rewardsDic = new Dictionary<long, int>();

    int index = 0;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        canReceiveButton.onClick.RemoveAllListeners();
        canReceiveButton.onClick.GuardSubscribeAsync<GameObject>(async (o) => { accomplishButtonClick.Invoke(playerMission); }).AddTo(mSubscriptions);
    }

    public async UniTask SetUp(PlayerMission mission,int index, Func<UniTask> downClick)
    {
        rewardsDic.Clear();
        this.index = index;
        getedImage2.SetActive(false);
        foreach (var item in DataManager.Instance.Master.Mission[mission.MissionMasterId].previousMissionIds)
            if (!DataManager.Instance.Player.Mission.TryGet(item).CanReceive)
                return;
        gameObject.SetActive(true);
        //添加按钮事件
        accomplishButtonClick.RemoveAllListeners();
        accomplishButtonClick.GuardSubscribeAsync<PlayerMission>(async (item) =>
        {
            await ButtonClick(item);
            await MissionService.RequestMissionData();
            await downClick.Invoke();
        });

        if (mission.CanReceive)
        {
            //255,255,255  acticleFrame  itemIcom  itemNumber  missionInformation
            await SetColor(true);
        }
        else
        {
            //129.129.128
            await SetColor(false);
        }


        playerMission = mission;
        //mission.MissionMasterId = test_MissionId;

        var missionStr = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MISSION_DETAILS, $"MISSION_TYPE_{mission.MissionMasterId}");

        missionInformation.SetRawText(DataManager.Instance.Master.Mission[mission.MissionMasterId].GetLocalizedText());

        string[] strs = new string[2];
        string itemName = "";
        string itemNumber = "";
        List<string> itemIcon = new List<string>();
        //道具
        foreach (var item in DataManager.Instance.Master.Mission[mission.MissionMasterId].rewards)
        {
            strs = item.Split(':');
            rewardsDic.Add(long.Parse(strs[0]), int.Parse(strs[1]));
            itemIcon.Add(strs[0]);
        }
        itemName = "";
        foreach (var item in rewardsDic)
        {
            itemName += LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ITEM, $"{item.Key}_name") + " ";
            itemNumber += item.Value + " ";
        }
        this.itemNumber.SetRawText(itemNumber);


        foreach (var item in itemIcon)
        {
            long l = 2;
            itemIcom.sprite = (await ResourceManager.Instance.LoadSpriteAsync($"ItemIcon", item));

            if (DataManager.Instance.Master.Item.ContainsKey(long.Parse(item)))
            {
                l = DataManager.Instance.Master.Item[long.Parse(item)].rarity;
            }
            acticleFrame.sprite = await ResourceManager.Instance.LoadSpriteAsync("FrameBg", $"frame_item_{l}");
        }

        if (mission.ReceiveRewardsAt > 0)
        {
            acticleFrame.gameObject.SetActive(false);
            getedImage.SetActive(true);
            return;
        }
    }

    public async UniTask ButtonClick(PlayerMission mission)
    {
        var master = DataManager.Instance.Master.Mission[mission.MissionMasterId];
        if (mission.CanReceive)  //是否可以领取
        {
            getedImage.SetActive(mission.CanReceive);
            if (index == 1)
            {
                getedImage2?.SetActive(true);
            }
            acticleFrame.gameObject.SetActive(!mission.CanReceive);
            await MissionService.FinishMission(mission.MissionMasterId);//向服务器发出请求
            if (master.GetRewards().Count > 0)
            {
                Debug.Log($"Cs:{name}  id:{mission.MissionMasterId}  可获得报酬  {master.GetRewards().Count}");
                await UI.Popup.ShowItemGetPopupAsync(master.GetRewards());
            }
        }
        else // 未完成
        {
            if (master.requireCondition > 0)
            {
                var stageId = DataManager.Instance.Master.FunctionUnlock[master.requireCondition].requireStageId;
                if (stageId > 0 && !StoryUtil.IsClear(stageId))
                {

                    var chapterName =
                        LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{stageId}_name");
                    int chapterNum = DataManager.Instance.Master.Chapter[stageId].chapter;
                    var msg = string.Format(
                        LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Stage_Format"),
                        chapterNum, chapterName);
                    UI.Popup.ShowPopMessage(msg);
                    return;
                }
            }
            if (master.goToPanel == string.Empty)
            {
                return;
            }
            //自动移动-------------------------------------------------------
            await CommonUtil.JumpToTargetPage(master.goToPanel);
        }
    }

    async UniTask SetColor(bool isActive)
    {
        //acticleFrame  itemIcom  itemNumber  missionInformation
        Color color = new Color();
        if (isActive)
        {
            color = (new Color(1, 1, 1));
            itemNumber.SetColor(new Color(1, 1, 1));
            missionInformation.SetColor(new Color(1, 1, 1));
            acticleFrame.material = null;
            itemIcom.material = null;
        }
        else
        {
            itemNumber.SetColor(new Color(129.0f / 255.0f, 129.0f / 255.0f, 128.0f / 255.0f));
            if (index == 0)
            {
                missionInformation.SetColor(new Color(104 / 255.0f, 104 / 255.0f, 104 / 255.0f));
            }
            else
            {
                missionInformation.SetColor(new Color(129.0f / 255.0f, 129.0f / 255.0f, 128.0f / 255.0f));
            }
            color = new Color(0, 0, 0);
            acticleFrame.material = garyMaterial;
            itemIcom.material = garyMaterial;
        }
        itemIcom.color = color;
        acticleFrame.color = color;
    }
}
public class EventMissionPlayer : UnityEvent<PlayerMission> { }