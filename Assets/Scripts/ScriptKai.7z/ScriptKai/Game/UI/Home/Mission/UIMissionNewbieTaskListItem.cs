using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Mission.V1;
using System.Linq;
using System;
using UnityEngine.Events;
using UnityEngine.UI;


public class UIMissionNewbieTaskListItem : UIDialogBase
{
    [SerializeField] GameObject tenthMssiion;
    [SerializeField] UIButton tenthButton;
    [SerializeField] Animator boxAnimator;

    [SerializeField] List<UIHomeMissionNewbieTaskItem> missionActicles = new List<UIHomeMissionNewbieTaskItem>(10);
    public UnityEvent<GameObject> getClick = new UnityEvent<GameObject>();
    public UnityEvent newClick = new UnityEvent();

    private readonly List<CnMissionMaster.MissionCategory> mAllCategoriesList = new List<CnMissionMaster.MissionCategory>()
    {
        CnMissionMaster.MissionCategory.NewbieTask,
    };

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }

    public async UniTask SetContins()
    {
        var playerMissions = new List<PlayerMission>(DataManager.Instance.Player.Mission.GetList());
        //Debug.Log($"{GetType()}    <color=#FF0000> SetContins    </color>");

        //判断列表，拿出新手任务
        //排序
        List<PlayerMission> tempList = new List<PlayerMission>(new PlayerMission[10]);
        foreach (var item in playerMissions)
        {
            if (mAllCategoriesList.Contains((CnMissionMaster.MissionCategory)DataManager.Instance.Master.Mission[item.MissionMasterId].missionCategory)) 
            {
                tempList[int.Parse(item.MissionMasterId.ToString()) % 100 - 1] = item;
                //Debug.Log($"playermission   id:   {item.MissionMasterId.ToString()}");
            } 
        }
        playerMissions = new List<PlayerMission>(tempList);

        tenthButton.onClick.RemoveAllListeners();
        int containsIndex = 0;
        for (int i = 0;i < playerMissions.Count;i++)
        {
            if (playerMissions[i] == null) return;
            //tenthMssiion.SetActive(true);
           
            if (containsIndex == 9)
            {
                var missionm = DataManager.Instance.Player.Mission.TryGet(playerMissions[containsIndex].MissionMasterId);
                if (missionm!=null)
                {
                    var data = DataManager.Instance.Player.Mission.TryGet(playerMissions[i].MissionMasterId);
                    if (data.CanReceive)
                    {
                        if (data.ReceiveRewardsAt < 0)
                        {
                            var i1 = i;
                            tenthButton.onClick.GuardSubscribeAsync(async (o) =>
                            {
                                boxAnimator.Play("Base Layer.Open");
                                await UniTask.DelayFrame(15);
                                await MissionService.FinishMission(playerMissions[i1].MissionMasterId);
                                getClick.Invoke(o);
                            });
                        }
                        else
                        {
                            boxAnimator.Play("Base Layer.HasOpen");
                        }
                    }
                    else
                    {
                        boxAnimator.Play("Base Layer.HasOpen");
                    }
                }
            }
            else
            {
                var contains = missionActicles[i];
                var containsCs = contains.GetComponent<UIHomeMissionNewbieTaskItem>();
                await containsCs.InitializeAsync();
                await containsCs.SetUp(playerMissions[i], i, async () =>
                {
                    await SetContins();
                    newClick.Invoke();
                }) ;
            }
            containsIndex++;

        }
    }
}
