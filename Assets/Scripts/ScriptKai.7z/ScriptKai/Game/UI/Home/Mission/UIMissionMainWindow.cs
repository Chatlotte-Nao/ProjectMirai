using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Mission.V1;
using Takasho.Schema.Score.ResourceCn.System.V1;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;
using TMPro;
using UnityEngine.Assertions.Must;
using Score.Takasho.Storage;
using System.Threading.Tasks;
using DG.Tweening;

public class UIMissionMainWindow : UIDialogBase
{
    [SerializeField] private UIMissionListItem missionItemPrefab;
    [SerializeField] private RectTransform missionItemListContainer;
    [SerializeField] private List<UIButton> categoryButtons;
    [SerializeField] private List<TextMeshProUGUI> categoryTexts;
    [SerializeField] private List<Image> selectImg;
    [SerializeField] private UIButton oneClickReceiveAll;
    [SerializeField] private UIMissionRewardItem rewardItemPrefab;
    [SerializeField] private RectTransform rewardsContainer;

    [SerializeField] private ScrollRect missionItemScroller;

    [SerializeField] private UIText categoryPointLabel;
    [SerializeField] UIMissionNewbieTaskListItem newbieTask;
    [SerializeField] GameObject missionList;

    [SerializeField] GameObject newbieTaskList;

    [SerializeField] private Slider rewardSlider;
    [SerializeField] private BaseItem categoriesItem;
    [SerializeField] private UIButton closeBtn;

    private readonly List<CnMissionMaster.MissionCategory> mAllCategories = new List<CnMissionMaster.MissionCategory>()
    {
        CnMissionMaster.MissionCategory.DAILY,
        CnMissionMaster.MissionCategory.WEEKLY,
        CnMissionMaster.MissionCategory.ACHIEVEMENT,
        CnMissionMaster.MissionCategory.NewbieTask
    };

    private CnMissionMaster.MissionCategory mCurrentCategory = CnMissionMaster.MissionCategory.NewbieTask;
    private Dictionary<long, UIMissionRewardItem> mMissionPointRewards = new Dictionary<long, UIMissionRewardItem>();
    private Dictionary<long, UIMissionListItem> mMissions = new Dictionary<long, UIMissionListItem>();

    public UIMissionListItem.OnActionEvent OnClickMissionAction = new UIMissionListItem.OnActionEvent();

    public OneClickReceiveAllEvent OnClickReceiveAll = new OneClickReceiveAllEvent();

    public UIMissionRewardItem.OnReceiveEvent OnReceiveMissionPointRewardsAction =
        new UIMissionRewardItem.OnReceiveEvent();

    public ClickEvent OnCloseClick => closeBtn.onClick;


    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        if (!MissionUtil.IsMissionNewReceive())
        {
            await newbieTask.SetContins();
        }
        categoryButtons[3].gameObject.SetActive(!MissionUtil.IsMissionNewReceive());
        await base.ShowAsync(showType);
    }

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        oneClickReceiveAll.onClick.Subscribe(async _ =>
        {
            OnClickReceiveAll.Invoke(mCurrentCategory);
        }).AddTo(mSubscriptions);
        for (int i = 0; i < categoryButtons.Count; i++)
        {
            var index = i;
            categoryButtons[i].onClick.Subscribe(_ =>
            {
                {
                    selectToggleMission(mAllCategories[index]);
                    PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01");
                }
            }).AddTo(mSubscriptions);
        }

        newbieTask.getClick.GuardSubscribeAsync(async (_) => { await TenthMissionGetClick(); }).AddTo(mSubscriptions);
        newbieTask.newClick.Subscribe(UpdateContent).AddTo(mSubscriptions);
    }

    public void SetUp(CnMissionMaster.MissionCategory category)
    {
        this.mCurrentCategory = category;
        setButtonState(this.mCurrentCategory);
    }

    public void UpdateContent()
    {
        if (mCurrentCategory == CnMissionMaster.MissionCategory.NewbieTask)
        {
            NeebieTaskTab();
        }
        else
        {
            updateMissionsContent();
            toggleMissionCategory(mCurrentCategory, true);
        }
       
        SetRedActive();
    }

    private void updateMissionsContent()
    {
        var missionList = new List<PlayerMission>(DataManager.Instance.Player.Mission.GetList())
           .Where(a => (CnMissionMaster.MissionCategory)DataManager.Instance.Master.Mission[a.MissionMasterId].missionCategory == CnMissionMaster.MissionCategory.DAILY ||
                       (CnMissionMaster.MissionCategory)DataManager.Instance.Master.Mission[a.MissionMasterId].missionCategory == CnMissionMaster.MissionCategory.ACHIEVEMENT)
           .OrderBy(m => !m.CanReceive && m.Progress >= DataManager.Instance.Master.Mission[m.MissionMasterId].requiredTotalIndex)
           .ThenBy(m => !m.CanReceive)
           .ThenBy(a => DataManager.Instance.Master.Mission[a.MissionMasterId].missionTypeId)
           .ThenBy(a => a.MissionMasterId);
        int index = 1;
        bool isScroller = false;
        foreach (var mission in missionList)
        {
            if (!mMissions.ContainsKey(mission.MissionMasterId))
            { 
                if (mission.CanReceive && !DataManager.Instance.Player.Mission.alreadyExisted.ContainsKey(mission.MissionMasterId))
                {   
                    DataManager.Instance.Player.Mission.alreadyExisted.Add(mission.MissionMasterId, 1);
                }
                var missionObj = Instantiate(missionItemPrefab, missionItemListContainer);
                missionObj.Setup(mission);
                missionObj.OnClickMissionAction.Subscribe(o => OnClickMissionAction.Invoke(mission))
                    .AddTo(mSubscriptions);
                mMissions[mission.MissionMasterId] = missionObj;
                mMissions[mission.MissionMasterId].gameObject.transform.SetSiblingIndex(index);
                isScroller = true;
            }
            else
            {
                if (mMissions[mission.MissionMasterId].mMission.CanReceive != mission.CanReceive ||
                    mMissions[mission.MissionMasterId].mMission.ReceiveRewardsAt != mission.ReceiveRewardsAt)
                {
                    isScroller = true;
                }

                mMissions[mission.MissionMasterId].UpdateData(mission);
                mMissions[mission.MissionMasterId].OnClickMissionAction.RemoveAllListeners();
                mMissions[mission.MissionMasterId].OnClickMissionAction
                    .Subscribe(o => OnClickMissionAction.Invoke(mission)).AddTo(mSubscriptions);
                mMissions[mission.MissionMasterId].gameObject.transform.SetSiblingIndex(index);
            }

            index++;
        }
        

        foreach (var reward in DataManager.Instance.Master.MissionPointReward)
        {
            if (!mMissionPointRewards.ContainsKey(reward.Value.id))
            {
                var rewardObj = Instantiate(rewardItemPrefab, rewardsContainer);
                rewardObj.Setup(reward.Value);
                var master = reward.Value;
                rewardObj.OnClick.Subscribe(o => OnReceiveMissionPointRewardsAction.Invoke(master))
                    .AddTo((mSubscriptions));
                mMissionPointRewards[reward.Value.id] = rewardObj;
                SerRewardPostion(reward.Value, rewardObj);
            }
            else
            {
                mMissionPointRewards[reward.Value.id].Setup(reward.Value);
            }
        }
    }

    void SetRedActive()
    {
        var isAllRewards = new List<PlayerMission>(DataManager.Instance.Player.Mission.GetList())
            .Where(m => m.CanReceive ).ToArray();
        bool[] isReceived = new bool[4];
        bool isReceive = false;
        for (int i = 0; i < 4; i++)
        {
            isReceive = false;
            foreach (var reward in DataManager.Instance.Master.MissionPointReward)
            {
                if ((CnMissionMaster.MissionCategory)DataManager.Instance.Master.MissionPointReward[reward.Key].missionCategory == mAllCategories[i])
                {
                    if (DataManager.Instance.Player.MissionPoint.HasReceived(reward.Value))
                    {
                        isReceive = false;
                    }
                    else if (DataManager.Instance.Player.MissionPoint.CanReceive(reward.Value))
                    {
                        isReceive = true;
                        break;
                    }
                }
            }
            isReceived[i] = isReceive;
        }

        bool isReward = false;
        for (int i = 0; i < 4; i++)
        {
            isReward = false;
            foreach (var item in isAllRewards)
            {
                if ((CnMissionMaster.MissionCategory)DataManager.Instance.Master.Mission[item.MissionMasterId].missionCategory == mAllCategories[i])
                {
                    isReward = true;
                    break;
                }
            }
            Debug.Log(isReceived[i].ToString()+isReward.ToString()+123.ToString());
            categoryButtons[i].transform.GetChild(3).gameObject.SetActive(isReceived[i] || isReward);
        }
    }

    void SerRewardPostion(CnMissionPointRewardMaster master, UIMissionRewardItem rewardItem)
    {
        var allRewardNum = DataManager.Instance.Master.MissionPointReward.Values
            .Where(a => a.missionCategory == master.missionCategory).Max(a => a.targetPoint);
        rewardItem.gameObject.transform.localPosition = new Vector3(702.0f * master.targetPoint / allRewardNum,
            rewardItem.transform.localPosition.y, 0);
    }

    async UniTask NeebieTaskTab()
    {
        newbieTaskList.SetActive(true);
        missionList.SetActive(false);
        oneClickReceiveAll.gameObject.SetActive(false);
        await Task.Delay(TimeSpan.Zero);
    }

    private void setButtonState(CnMissionMaster.MissionCategory category)
    {
        var categoryIndex = mAllCategories.IndexOf(category);
        categoryButtons[categoryIndex].GetComponent<UnityEngine.UI.Toggle>().isOn = true;
        for (int i = 0; i < categoryButtons.Count; i++)
        {
            if (i == categoryIndex)
            {
                categoryTexts[categoryIndex].color = new Color(255.0f / 255, 255.0f / 255, 233.0f / 255);
                selectImg[categoryIndex].gameObject.SetActive(true);
            }
            else
            {
                categoryTexts[i].color = new Color(48.0f / 255, 48.0f / 255, 42.0f / 255);
                if (selectImg[i] != null)
                    selectImg[i].gameObject.SetActive(false);
            }
        }
        mCurrentCategory = category;
    }

    public void selectToggleMission(CnMissionMaster.MissionCategory category)
    {
        setButtonState(category);
        UpdateContent();
    }

    private void toggleMissionCategory(CnMissionMaster.MissionCategory category, bool isScroller = true)
    {
        oneClickReceiveAll.gameObject.SetActive(true);
        newbieTaskList.SetActive(false);
        missionList.SetActive(true);
      

        var isAllRewards = new List<PlayerMission>(DataManager.Instance.Player.Mission.GetList())
            .Where(m => DataManager.Instance.Master.Mission[m.MissionMasterId].missionCategory == (int) category &&
                        m.CanReceive && m.ReceiveRewardsAt <= 0).ToArray();
        oneClickReceiveAll.gameObject.SetActive(isAllRewards.Length > 0);
        foreach (var entry in mMissions)
        {
            var master = DataManager.Instance.Master.Mission[entry.Key];
            entry.Value.gameObject.SetActive(master.missionCategory == (int) category);
        }

        foreach (var entry in mMissionPointRewards)
        {
            var master = DataManager.Instance.Master.MissionPointReward[entry.Key];
            entry.Value.gameObject.SetActive(master.missionCategory == (int) category);
            var sliderMax = DataManager.Instance.Master.MissionPointReward.Values
                .Where(m => m.missionCategory == (int) category).Max(a => a.targetPoint);
            rewardSlider.maxValue = sliderMax;
            rewardSlider.value = DataManager.Instance.Player.MissionPoint.GetPointByCategory(category);
        }

        categoryPointLabel.SetFormat(LocalizeManager.DATA_TYPE.MISSION_EVENT_NAME, "MISSION_POINT",
            new object[] {DataManager.Instance.Player.MissionPoint.GetPointByCategory(category)});
        // switch (category)
        // {
        //    case CnMissionMaster.MissionCategory.DAILY:
        //        categoryPointTitleLabel.SetLabel(LocalizeManager.DATA_TYPE.MISSION_EVENT_NAME, "MISSION_POINT_DAILY");
        //        break;
        //    case CnMissionMaster.MissionCategory.WEEKLY:
        //        categoryPointTitleLabel.SetLabel(LocalizeManager.DATA_TYPE.MISSION_EVENT_NAME, "MISSION_POINT_WEEKLY");
        //        break;
        //    case CnMissionMaster.MissionCategory.ACHIEVEMENT:
        //        categoryPointTitleLabel.SetLabel(LocalizeManager.DATA_TYPE.MISSION_EVENT_NAME, "MISSION_POINT_ACHIEVEMENT");
        //        break;
        // }
        mCurrentCategory = category;
        var itemid = mCurrentCategory == CnMissionMaster.MissionCategory.DAILY ? 124000001 : 125000002;
        categoriesItem.Setup(itemid, DataManager.Instance.Player.MissionPoint.GetPointByCategory(category).ToString());
        if (isScroller)
            missionItemScroller.normalizedPosition = new Vector2(0, 1);
    }

    private async UniTask TenthMissionGetClick()
    {
        /*
         * 1.关闭新手任务按钮
         * 2.隐藏任务界面
         */
        Debug.Log($"{GetType()}   完成并领取全部任务任务   新手任务界面消失 ");
        var master = DataManager.Instance.Master.Mission[600010];
        if (master.GetRewards().Count > 0)
        {
            //await MissionService.FinishMission(600010);
            //Debug.Log($"Cs:{name}   可获得报酬  {master.GetRewards().Count}");
            await UI.Popup.ShowItemGetPopupAsync(master.GetRewards());
        }
        //newbieTaskList.SetActive(false);
        //newbieButton.gameObject.SetActive(false);
        await DOTween.To(() => 2, value => { }, 0, 2).OnComplete(() =>
              {
                  categoryButtons[3].gameObject.SetActive(false);
                  selectToggleMission(CnMissionMaster.MissionCategory.DAILY);
                  //UpdateContent();
              });
    }

    private void moveCategoryIndex(int offset)
    {
        int n = mAllCategories.Count;
        int currentIndex = mAllCategories.IndexOf(mCurrentCategory);
        currentIndex += offset;
        if (currentIndex < 0)
        {
            currentIndex += n;
        }

        currentIndex %= n;
        toggleMissionCategory(mAllCategories[currentIndex]);
    }

    public class OneClickReceiveAllEvent : UnityEvent<CnMissionMaster.MissionCategory>
    {}
}