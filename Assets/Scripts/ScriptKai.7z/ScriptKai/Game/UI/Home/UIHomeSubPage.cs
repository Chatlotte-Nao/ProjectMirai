﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIHomeSubPage : UIPageBase
{
    //private UIAdvConfigDialog mConfig = null;


    private bool isInit = true;


    private UIAdvConfigDialog mConfig = null;

    UIExploreEventListDialog mEventListDialog = null;

    private UIExchangeDialog mExchange = null;
    UIHomeSubMainWindow mMainWindow = null;

    UIWorldMapDialog mMapDialog = null;
    //private 


    private UIHomeNavigationWindow mNavigationWindow = null;
    UIMapOperationDialog mOperationDialog = null;
    UIPadController mPad = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);

        mNavigationWindow =  await UI.Dialog.CreateAsync(UIPrefabId.UIHomeNavigationWindow, CanvasType.App0) as UIHomeNavigationWindow;
        mOperationDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMapOperationDialog, CanvasType.BG) as UIMapOperationDialog;
        mPad = await UI.Dialog.CreateAsync(UIPrefabId.UIPadController, CanvasType.BG) as UIPadController;
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeSubMainWindow, CanvasType.App0) as UIHomeSubMainWindow;
 
        mMapDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIWorldMapDialog, CanvasType.App2) as UIWorldMapDialog;
        mEventListDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIExploreEventListDialog, CanvasType.App1) as UIExploreEventListDialog;

        mMainWindow.OnClickMap.SubscribeAsync(onClickMap).AddTo(mSubscriptions);
        mMainWindow.OnClickEventList.GuardSubscribeAsync(onClickEventList).AddTo(mSubscriptions);
        mMapDialog.OnSelectTarget.GuardSubscribeAsync(onSelectMapTarget).AddTo(mSubscriptions);
        mMapDialog.OnMapHide.GuardSubscribeAsync(onMapHide).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe<long>(UIEventId.ExploreEventListShow, OnClickInvite).AddTo(mSubscriptions);

        mNavigationWindow.OnNavigationGroup.GuardSubscribeAsync(OnNavigationGroup).AddTo(mSubscriptions);

        SignalBus.GlobalSignal.Subscribe<UIExploreCommandParam>(UIEventId.ExploreShowCharacter, OnClickCharacter).AddTo(mSubscriptions);
        mNavigationWindow.OnGotoRoom.GuardSubscribeAsync(onClickBgLocation).AddTo(mSubscriptions);
        mMainWindow.OnSelectTarget.GuardSubscribeAsync(onClickBgLocation).AddTo(mSubscriptions);
        TutorialManager.Instance.CheckTriggerStart(TutorialManager.FunctionTutorialTriggerType.BackToTop);
    }


    private void OnClickCharacter(UIExploreCommandParam param)
    {
        AsyncManager.Instance.StartGuardAsync(showCommandPage(param));
    }

    private async UniTask showCommandPage(UIExploreCommandParam param)
    {
        await UI.Page.OpenPage<UIExploreCommandPage>(param);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await mNavigationWindow.ShowAsync(showType);
        MapSceneManager.Instance.ShowCurrent();

        await mOperationDialog.ShowAsync(showType);
        await mPad.ShowAsync(showType);
        await mMainWindow.ShowAsync(showType);
        await base.ShowAsync(showType);

        ClientEvent clientEvent = ClientEventUtil.ClientHallInto();
        LCXHandler.Instance.ReportEvent(clientEvent.event_id, clientEvent.payload);
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHeaderHide);
        // if (isInit)
        // {
        //     TutorialManager.Instance.CheckTriggerStart(TutorialManager.FunctionTutorialTriggerType.BackToTop);
        //     isInit = false;
        // }
        if (DataManager.Instance.Player.Character.isUpdateMapCharacter)
        {
            DataManager.Instance.Player.Character.isUpdateMapCharacter = false;
            await ExploreService.RequestExploreData();
            await UI.ScreenEffect.Fade(1);
            var label = DataManager.Instance.Player.Player.GetData().Location;
            DataManager.Instance.Local.UserInfo.playerPosition =
                MapSceneManager.Instance.CurrentScene.player.gameObject.transform.position;
            await changeSubPage(label,null);
            if (DataManager.Instance.Local.UserInfo.playerPosition != Vector3.zero)
            {
                MapSceneManager.Instance.CurrentScene.player.SetPosition(DataManager.Instance.Local.UserInfo
                    .playerPosition);
                DataManager.Instance.Local.UserInfo.playerPosition = Vector3.zero;
            }
            await UI.ScreenEffect.Fade(0);
        }

        TutorialManager.Instance.SetGoalActive(true);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await mMainWindow.HideAsync();
        await mOperationDialog.HideAsync();
        await mPad.HideAsync();
        await mNavigationWindow.HideAsync();
        await base.HideAsync(showType);
        if (showType == UIPageShowType.Front)
        {
            //MapSceneManager.Instance.HideCurrent();
        }
        TutorialManager.Instance.SetGoalActive(false);
    }

    public override void Dispose()
    {
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
        if (mMapDialog != null)
        {
            mMapDialog.Dispose();
            mMapDialog = null;
        }
        if (mPad != null)
        {
            mPad.Dispose();
            mPad = null;
        }
        if (mEventListDialog != null)
        {
            mEventListDialog.Dispose();
            mEventListDialog = null;
        }
        if (mOperationDialog != null)
        {
            mOperationDialog.Dispose();
            mOperationDialog = null;
        }

       if (mNavigationWindow != null)
       {
           mNavigationWindow.Dispose();
           mNavigationWindow = null;
       }
       
       if (mExchange != null)
       {
           mExchange.Dispose();
           mExchange = null;
       }
       base.Dispose();
    }

    private async UniTask onClickBgLocation(UIWorldMapDialog.SelectTarget target)
    {
        await gotoMapTarget(target.mapName, target.roomName);
    }

    private async UniTask onSelectMapTarget(UIWorldMapDialog.SelectTarget target)
    {
        await changeSubPage(target.mapName, target.roomName);
    }


    private async UniTask changeSubPage(string map, string room)
    {
        //await UI.ScreenEffect.Fade(1);

        if (MapSceneManager.Instance.CurrentScene.player.currentActionObject != null)
        {
            MapSceneManager.Instance.CurrentScene.player.currentActionObject.EndAction();
        }

        await mMapDialog.HideAsync();

        var mapData = DataManager.Instance.Master.Location[map];
        if (string.IsNullOrEmpty(room))
        {
            await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home, mapData.startPos);
        }
        else
        {
            await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home, map);
        }


        DataManager.Instance.Local.UserInfo.currentHomeMap = map;
        DataManager.Instance.Local.UserInfo.currentHomeRoom = room;


        //await UI.ScreenEffect.Fade(0);
    }

    private async UniTask gotoMapTarget(string room,string name)
    {
        //await UI.ScreenEffect.Fade(1);
        var advMapMaster = DataManager.Instance.Master.AdvMap[room];
        var mapData = DataManager.Instance.Master.Location[advMapMaster.map_label];

        if (MapSceneManager.Instance.mCurrentSceneName != mapData.scene)
        {
           // await UI.ScreenEffect.Fade(1);
            if (string.IsNullOrEmpty(advMapMaster.startPos))
            {
                await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home,
                    mapData.startPos);
            }
            else
            {
                await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home,
                    advMapMaster.startPos);
            }
            //await UI.ScreenEffect.Fade(0);
        }

        DataManager.Instance.Local.UserInfo.currentHomeMap = advMapMaster.map_label;
        
        MapSceneManager.Instance.CurrentScene.MovePlayerToRoomPoint(room,advMapMaster.openUi);
        DataManager.Instance.Local.UserInfo.currentHomeRoom = room;
    }

    private async UniTask OnExploreGacha()
    {
        var param = await GachaService.GetGachaList();
        await UI.Page.ChangePage<UIGachaMainPage>(param);
        return;
        
        
        
        
        
        //探索Gacha
        // var model = await GachaService.GetExplpreGachaModel();
        // if (DataManager.Instance.Player.Item.GetCount(model.master.gachaContentId) <= 0)
        // {
        //     await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.GACHA,"Gacha_Explore_Item_Not"));
        //     return;
        // }
        // if(model!=null)
        //     await UI.Page.OpenPage<UIExploreGachaPage>(model);
        

    }

    private async UniTask OnConfige(GameObject o)
    {
        // if (mConfig == null)
        // {
        //     mConfig = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvConfigDialog, CanvasType.App2) as UIAdvConfigDialog;
        // }
        // await mConfig.ShowAsync();
    }

    private async UniTask OnOpenNavigationGroup(GameObject o)
    {
        mPad.gameObject.SetActive(false);
        mOperationDialog.gameObject.SetActive(false);
    }

    private async UniTask OnHideNavigationGroup(GameObject o)
    {
        mPad.gameObject.SetActive(true);
        mOperationDialog.gameObject.SetActive(true);
    }

    private async UniTask OnNavigationGroup(bool isActive)
    {
        await mPad.HideAsync();
        mPad.gameObject.SetActive(!isActive);
        mOperationDialog.gameObject.SetActive(!isActive);
        mMainWindow.gameObject.SetActive(!isActive);
        
    }

    private async UniTask OnExchange(GameObject o)
    {
        //TODO 弹出兑换框（兑换框会额外出需求）
        if (mExchange == null)
        {
            mExchange = await UI.Dialog.CreateAsync(UIPrefabId.UIExchange, CanvasType.App2) as UIExchangeDialog;
        }
        await mExchange.ShowAsync();
    }

    private async UniTask OnAccount(GameObject o)
    {
        //TODO 点击【账号】，弹出原 账号悬浮框的内容界面
        
    }


    private async UniTask onClickMap()
    {
        mMainWindow.GetComponent<CanvasGroup>().alpha = 0;
        mNavigationWindow.GetComponent<CanvasGroup>().alpha = 0;
        mPad.GetComponent<CanvasGroup>().alpha = 0;
        await mMapDialog.SetUp();
        await mMapDialog.ShowAsync();
    }

    private async UniTask onMapHide()
    {
        mMainWindow.GetComponent<CanvasGroup>().alpha = 1;
        mNavigationWindow.GetComponent<CanvasGroup>().alpha = 1;
        mPad.GetComponent<CanvasGroup>().alpha = 1;
    }

    private async UniTask onClickEventList()
    {
        mEventListDialog.RefreshList();
        await mEventListDialog.ShowAsync();
    }

    public void OnClickInvite(long characterId)
    {
        mEventListDialog.RefreshList(characterId);
        AsyncManager.Instance.StartGuardAsync(mEventListDialog.ShowAsync());
    }
}
