﻿using Base.Sound;
using Base.Ui;
using Base.Util;
using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;


namespace Game.Ui
{
	[RequireComponent(typeof(Animator))]
	[RequireComponent(typeof(CanvasGroup))]
	[RequireComponent(typeof(Button))]
	[RequireComponent(typeof(RectTransform))]
	[AddComponentMenu("Takt/AnimationButton")]

	public class AnimationButton : MonoBehaviour, IPointerClickHandler, IPointerDownHandler
	{
		[SerializeField] bool	enabledTransitionAnimation	= false;
		[SerializeField] string clickSeName;
		[SerializeField] bool	isSkipAnimation;

		static readonly string	ANIMATION_CLIP_IN		= "In";
		static readonly string	ANIMATION_CLIP_OUT		= "Out";
		static readonly string	ANIMATION_CLIP_PRESSED	= "Pressed";
		static readonly string	ANIMATION_CLIP_NORMAL	= "Normal";
		static readonly string	ANIMATION_CLIP_INIT		= "Init";

		Button		button;
		Animator	animator;
		float		inactiveTime;
		int			clickSeId;
		UiLocker	uiLocker;
		UiLocker	clickLocker;
		bool		interactable;
		Sprite		normalSprite;

#if ENABLED_CANCEL_SE
		string[]	cancelSeName	= new string[] { "cancel", "return", "no", "back", "close" };	// クリック時にキャンセルボタンを鳴らすオブジェクト名(小文字)
#endif


#if UNITY_EDITOR
		void Reset()
		{
			var	path	= "Assets/Application Assets/System/Animations/Button.controller";
			GetComponent<Animator>().runtimeAnimatorController	= UnityEditor.AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>(path);
		}
#endif


		void Awake()
		{
			button	= GetComponent<Button>();
			if (button != null)
			{
				button.enabled	= false;
				SetColor();
			}

			animator	= GetComponent<Animator>();
			inactiveTime	= GetInactiveTime();

			clickSeId = SoundConstants.SE_BUTTON;

#if ENABLED_CANCEL_SE
			string objectLowerName = gameObject.name.ToLower();
			for(int i = 0; i < cancelSeName.Length; i++)
			{
				if(objectLowerName.Contains(cancelSeName[i]))
				{
					clickSeId = SoundConstants.SE_BUTTON_CANCEL;
					break;
				}
			}
#endif
		}


		void OnEnable()
		{
			SetColor();
			animator.Play(enabledTransitionAnimation ? ANIMATION_CLIP_INIT : ANIMATION_CLIP_NORMAL, 0, 0);
		}


		void OnDisable()
		{
			if (uiLocker != null)		uiLocker.Dispose();
			if (clickLocker != null)	clickLocker.Dispose();

			uiLocker	= null;
			clickLocker	= null;
		}


		void Update()
		{
			if (button == null)	return;
			if (interactable == button.interactable)	return;
			SetColor();
		}


		void SetColor()
		{
			if (button == null)	return;
			var	color	= button.interactable ? button.colors.normalColor : button.colors.disabledColor;
			button.targetGraphic.CrossFadeColor(color, 0, false, true);
			interactable	= button.interactable;
		}


		public void SetEnabledTransitionAnimation(bool b)
		{
			enabledTransitionAnimation	= b;
		}


		public float GetInactiveTime()
		{
			return AnimationUtil.GetAnimationLength(animator.runtimeAnimatorController, ANIMATION_CLIP_OUT);
		}


		public IEnumerator Active()
		{
			if (uiLocker != null)	yield break;

			using (uiLocker = new UiLocker(gameObject))
			{
				yield return null;
				if (!enabledTransitionAnimation || !gameObject.activeInHierarchy || !isActiveAndEnabled)
				{
					uiLocker	= null;
					yield break;
				}

				animator.Play(ANIMATION_CLIP_IN, 0, 0);
				var	waitTime	= AnimationUtil.GetAnimationLength(animator.runtimeAnimatorController, ANIMATION_CLIP_IN);
				yield return AnimationUtil.Wait(animator, waitTime);

				uiLocker	= null;
			}
		}


		public IEnumerator Inactive()
		{
			if (uiLocker != null)	yield break;

			using (uiLocker = new UiLocker(gameObject))
			{
				if (!enabledTransitionAnimation || !gameObject.activeInHierarchy || !isActiveAndEnabled)
				{
					uiLocker	= null;
					yield break;
				}

				animator.Play(ANIMATION_CLIP_OUT, 0, 0);
				yield return AnimationUtil.Wait(animator, inactiveTime);

				uiLocker	= null;
			}
		}


		public void OnPointerClick(PointerEventData eventData)
		{
			if (button == null)	return;
			if (!button.IsInteractable())	return;
			StartCoroutine(ClickRoutine());

			if (!string.IsNullOrEmpty(clickSeName))
			{
				Game.Sound.SoundPlayer.PlaySe(clickSeName);
			}
			else
			{
				Game.Sound.SoundPlayer.PlaySe(clickSeId);
			}
		}


		IEnumerator ClickRoutine()
		{
			if (clickLocker != null)	yield break;

			using (clickLocker = new UiLocker())
			{
				animator.Play(ANIMATION_CLIP_PRESSED, 0, 0);

				if (!isSkipAnimation) 
				{
					var	waitTime	= AnimationUtil.GetAnimationLength(animator.runtimeAnimatorController, ANIMATION_CLIP_PRESSED);
					yield return AnimationUtil.Wait(animator, waitTime);
				}

				SetPressdSprite(false);
				button.onClick.Invoke();
				clickLocker	= null;
			}
		}


		public void OnPointerDown(PointerEventData eventData)
		{
			SetPressdSprite(true);
		}


		void SetPressdSprite(bool b)
		{
			if (button.transition != Selectable.Transition.SpriteSwap)	return;
			if (button.spriteState.pressedSprite == null)	return;

			if (b)
			{
				normalSprite	= button.image.sprite;
				button.image.sprite	= button.spriteState.pressedSprite;
			}
			else if (normalSprite != null)
			{
				button.image.sprite	= normalSprite;
			}
		}
	}
}
