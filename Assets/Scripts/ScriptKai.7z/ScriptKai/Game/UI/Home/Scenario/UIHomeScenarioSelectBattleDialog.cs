﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIHomeScenarioSelectBattleDialog : UIDialogBase
{
    [SerializeField] UIButton backButton;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }

    public async UniTask SetupAsync(int chapter)
    {
        
    }
}
