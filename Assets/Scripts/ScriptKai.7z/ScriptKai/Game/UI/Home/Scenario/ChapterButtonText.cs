﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using Pheonix.Core;
using System.Linq;

namespace ScenarioSelect
{
	/// <summary>
	/// シナリオ章選択に出ている文字周り表示(第〇楽章や推奨戦力など)処理をまとめた物
	/// </summary>
	public class ChapterButtonText : MonoBehaviour
	{
		readonly string BASE_BG_COLOR = "#000000";
		readonly string SELECT_BG_COLOR = "#00c7ff";
		readonly string TOTAL_POWER_FRW_COLOR = "#ff5151";

		[SerializeField] UIText text;
		[SerializeField] GameObject rewardGroup;
		[SerializeField] UIText rewardNumText;
		[SerializeField] Animator animator;

		[SerializeField] GameObject newIcon;
		[SerializeField] GameObject clearIcon;
		[SerializeField] GameObject completeIcon;
		[SerializeField] Image bgImage;
		[SerializeField] Pheonix.Core.FontStyle textbaseMaterial;
		[SerializeField] Pheonix.Core.FontStyle textSelectMaterial;
		[SerializeField] GameObject baseBadge;
		[SerializeField] bool isTextOnly;

		bool isSelect = false;
		string lastSetAnimName = string.Empty;

		static Dictionary<int, string> numDict = new Dictionary<int, string>() { { 1, "一" }, { 2, "二" }, { 3, "三" }, { 4, "四" }, { 5, "五" }, { 6, "六" }, { 7, "七" } };

		private void OnEnable()
		{
			if (string.IsNullOrEmpty(lastSetAnimName))
				return;
			animator.Play(lastSetAnimName);
		}


		public void Initialize(ChapterStatusViewModel viewModel,bool isChangeTile = false)
		{
			gameObject.SetActive(true);
			if (isChangeTile)
				text.SetFormat(Pheonix.Core.LocalizeManager.DATA_TYPE.COMMON, "STORY_CHAPTERTITLE_BIG", numDict[viewModel.chapter]);
			else
				text.SetFormat(Pheonix.Core.LocalizeManager.DATA_TYPE.COMMON, "STORY_CHAPTERTITLE", numDict[viewModel.chapter]);
			ResetIcon();

			if (isTextOnly)
				return;

			rewardNumText.SetRawText(string.Format("{0}/{1}", viewModel.currentRewardNum, viewModel.totalRewardNum));
		}

		public void SetTitleColor(Color color)
		{
			text.SetColor(color);
		}

		/// <param name="isForced">true:必ず変更を行う false:表示ステータスが一緒の時は一部処理は処理しない</param>
		public void SetSelectDisplay(bool isSelect, bool isForced)
		{
			//BGの色替え
			var color = Color.black;
			var colorStr = (isSelect) ? SELECT_BG_COLOR : BASE_BG_COLOR;
			ColorUtility.TryParseHtmlString(colorStr, out color);
			bgImage.color = color;
			//フォントの設定変更
			text.SetStyle(isSelect?textSelectMaterial:textbaseMaterial);

			if (this.isSelect != isSelect || isForced)
			{
				lastSetAnimName = (isSelect) ? "ChapterTitleOn" : "ChapterTitle";
				//強制の時は最初からアニメ終了時状態にする
				if (isForced)
					animator.Play(lastSetAnimName, -1, 1.0f);
				else
					animator.Play(lastSetAnimName);
			}
			this.isSelect = isSelect;
		}

		/// <summary>
		/// 話数選択のタイトル用表示に切り替える
		/// </summary>
		public void ChangeSectionTitleDisplay()
		{
			lastSetAnimName = "ChapterTitleSection";
			animator.Play(lastSetAnimName);
			//freeBattleButton.gameObject.SetActive(true);
		}

		public void ResetIcon()
		{
			if (newIcon != null)
				newIcon.SetActive(false);
			if (clearIcon != null)
				clearIcon.SetActive(false);
			if (completeIcon != null)
				completeIcon.SetActive(false);
		}
		
		public void SetNewIcon()
		{
			if (newIcon != null)
				newIcon.SetActive(true);
			baseBadge.SetActive(true);
		}
		public void SetClearIcon()
		{
			if (clearIcon != null)
				clearIcon.SetActive(true);
			baseBadge.SetActive(true);
		}
		public void SetCompleteIcon()
		{
			if (completeIcon != null)
				completeIcon.SetActive(true);
			baseBadge.SetActive(true);
		}
	}
}
