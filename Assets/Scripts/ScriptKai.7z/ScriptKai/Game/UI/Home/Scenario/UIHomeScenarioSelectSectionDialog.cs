﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using ScenarioSelect;
using System.Linq;
using UnityEngine.Events;


public class UIHomeScenarioSelectSectionDialog : UIDialogBase
{
	const float SECTION_TOP_Y = 102;
	const float SECTION_ALPHA_TOP_Y = -292.0f;
	[SerializeField] UITexture chapterImage;
	[SerializeField] UIButton backButton;
	[SerializeField] ChapterButtonText sectionTitleChapterButtonText;
	[SerializeField] SectionButton sectionButtonPrefab;
	[SerializeField] SectionButton favoriteSectionButtonPrefab;
	[SerializeField] Transform sectionButtonParent;
	[SerializeField] GameObject sectionDisplayObject;
	[SerializeField] UIButton sectionUpButton;
	[SerializeField] UIButton sectionDownButton;
	[SerializeField] PanelScrollRect sectionScrollRect = null;
	[SerializeField] RoundScrollController sectionRoundScrollController;
	[SerializeField] private GameObject titleObj;

	private int lastScrollSection = 0;
	public AsyncEvent OnBattleWarning = new AsyncEvent();


	List<SectionButton> sectionButtonList = new List<SectionButton>();

	public UnityEvent OnClickBack => backButton.OnTouchUpInside;

	void LateUpdate ()
	{
		//sectionbutton不进行位置横移调整
		return;
		sectionRoundScrollController.SetPosition(false, true);
		var parentRect = sectionRoundScrollController.GetGridLayoutGroupRect();
		//セクション横スクロール時の各ボタン横位置調整
		foreach (var panel in sectionScrollRect.Panels)
		{
			if (panel == null)
				continue;

			var sectionButton = panel.GetComponent<SectionButton>();
			if (sectionButton == null)
				continue;
			var canvasGroup = sectionButton.GetCanvasGroup();
			if (canvasGroup != null)
				canvasGroup.alpha = GetScrollObjectAhpha(parentRect.anchoredPosition.y + panel.GetComponent<RectTransform>().anchoredPosition.y);
		}
	}


	public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        //titleObj.SetActive(!TutorialManager.Instance.GetIsLockHome());
		sectionScrollRect.OnSelectionChanged.Subscribe(selectedIndex =>
		{
			lastScrollSection = selectedIndex;
			for (int i = 0; i < sectionButtonList.Count; i++)
			{
				var section = sectionButtonList[i];
				section.SetSelectLineActive(i == lastScrollSection);
			}
		}).AddTo(mSubscriptions);
		sectionUpButton.OnTouchUpInside.Subscribe(() =>
		{
			var currentPanelIndex = sectionScrollRect.FindPanelIndex(lastScrollSection);
			var nextPanelIndex = currentPanelIndex + 1;
			if (nextPanelIndex >= sectionScrollRect.Panels.Count) { return; }
			var slotId = sectionScrollRect.Panels[nextPanelIndex].SlotId;
			sectionScrollRect.SelectPanel(sectionScrollRect.FindPanelIndex(slotId));
		}).AddTo(mSubscriptions);
		sectionDownButton.OnTouchUpInside.Subscribe(() =>
		{
			var currentPanelIndex = sectionScrollRect.FindPanelIndex(lastScrollSection);
			var nextPanelIndex = currentPanelIndex - 1;
			if (0 > nextPanelIndex) { return; }
			var slotId = sectionScrollRect.Panels[nextPanelIndex].SlotId;
			sectionScrollRect.SelectPanel(sectionScrollRect.FindPanelIndex(slotId));
		}).AddTo(mSubscriptions);
    }


	public async UniTask SetupAsync(ChapterStatusViewModel viewModel)
    {
		await chapterImage.LoadAsync("Scenario/ChapterBG", $"zx_chapterbj_0{viewModel.chapter}");

		sectionScrollRect.ClearPanels();

		int idx = 0;

		sectionButtonList.Clear();

		foreach (var kv in viewModel.sectionStatus)
		{
			if (kv.Value.isLocked && !kv.Value.isNew) continue;
			var sectionButton = await MakeSectionButton(idx, kv.Value, sectionButtonPrefab, sectionButtonParent);
			sectionButton.name = kv.Value.section.ToString();
			sectionScrollRect.AddPanel(sectionButton.gameObject);
			sectionButtonList.Add(sectionButton);
			idx++;
		}
		sectionScrollRect.SetupAfterAddPanels();
		//親アンカーが画面比率で可変/画面比率自体が違う/最初からアクティブをすべて満たす時に内部UpdateContentSizeにてサイズが正常に取得出来ていなかったので、LateUpdateでもう一度設定するようにする
		sectionScrollRect.SetLateUpdateContentSizeRequest();
		sectionRoundScrollController.Init(sectionButtonList.Count, true);

		//セクションタイトル部分に使用されているチャプター情報更新
		sectionTitleChapterButtonText.Initialize(viewModel,true);
		sectionTitleChapterButtonText.ChangeSectionTitleDisplay();

		
		sectionScrollRect.SelectPanel(sectionButtonList.Count - 1);
		lastScrollSection = sectionButtonList.Count-1;

		var parentRect = sectionRoundScrollController.GetGridLayoutGroupRect();
		parentRect.anchoredPosition = new Vector2(0,sectionRoundScrollController.CELL_SIZE_Y*(sectionButtonList.Count-1));
		sectionRoundScrollController.SetPosition();

		//LateUpdate();
		
    }


	public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {

		mIsShowing = true;
		gameObject.SetActive(true);
		if (mAnimation != null && showAnimation != null && showType == UIPageShowType.Front)
		{
			await UIAnimationPlayer.PlayAsync(mAnimation, showAnimation);
		}
            
		// int idx = Mathf.Max(sectionButtonList.Count - 3, 0);
		//
		//  for (int i = idx; i < sectionButtonList.Count; i++)
		//  {
		//  	sectionButtonList[i].SetBaseObjectX(1200);
		//  }
		//
		// UI.Loading.Hide();
		// await UI.ScreenEffect.Fade(0);
		//
		// for (int i = idx; i < sectionButtonList.Count; i++)
		// {
		// 	
		// 	//sectionScrollRect.SelectPanel(i);
		// 	if (DataManager.Instance.Master.Chapter[sectionButtonList[i].Model.masterId].enableWarning == 1 && sectionButtonList[i].Model.isNew)
		// 	{
		// 		await OnBattleWarning.InvokeAsync();
		// 	}
		// 	sectionButtonList[i].Show();
		// 	await UniTask.Delay(100);
		// }
		//
		// await UniTask.Delay(300);
		List<UniTask> taskList = new List<UniTask>();
		foreach (var sectionButton in sectionButtonList)
		{
			sectionButton.gameObject.SetActive(true);
			taskList.Add(sectionButton.Show());
		}
		await UniTask.WhenAll(taskList);
		sectionButtonList[lastScrollSection].SetSelectLineActive(true);

		
        OnShow();

    }


	async UniTask<SectionButton> MakeSectionButton(int idx, SectionStatusViewModel model, SectionButton buttonPrefab, Transform parent)
	{
		var master = DataManager.Instance.Master.Chapter[model.masterId];
		var button = Instantiate(buttonPrefab);
		button.transform.SetParent(parent, false);
		await button.Initialize(model);
		button.OnClick.Subscribe((o)=>
		{
			if (lastScrollSection != idx)
			{
				var slotId = sectionScrollRect.Panels[idx].SlotId;
				sectionScrollRect.SelectPanel(sectionScrollRect.FindPanelIndex(slotId));
			}
			else
			{
				OnClickSection(model);
			}
			
		}).AddTo(mSubscriptions);
		// button.OnRewardClick.Subscribe((o) =>
		// {
		// 	OnShowRewardDialog(model);
		// }).AddTo(mSubscriptions);
		//button.gameObject.SetActive(true);

		return button;
	}

	void OnShowRewardDialog(SectionStatusViewModel model)
	{
		var items = DataManager.Instance.Master.Chapter[model.masterId].showRewards;
		if (items.Count > 0)
		{
			UI.Popup.ShowItemRewardsPopup(items);
		}
	}

	void OnClickSection(SectionStatusViewModel model)
	{
		// // //TODO 临时拦截
		// if (model.masterId == 8 || model.masterId == 11 || model.masterId == 17)
		// {
		// 	//var msg = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ADV, "Charpter_Not_Open");
		// 	UI.Popup.ShowPopMessage("装修中，敬请期待");
		// 	return;
		// }

		if (DataManager.Instance.Master.Chapter[model.masterId].requirePlayerLevel > DataManager.Instance.Player.Player.GetLevel())
		{
			var msg = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ADV, "Error_PlayerLevelFormat"), DataManager.Instance.Master.Chapter[model.masterId].requirePlayerLevel);
			UI.Popup.ShowPopMessage(msg);
			return;
		}
		if (DataManager.Instance.Local.Scenarios.OngoingChapterId != 0 && DataManager.Instance.Local.Scenarios.OngoingChapterId != model.masterId)
		{
			var ongoingMaster = DataManager.Instance.Master.Chapter[DataManager.Instance.Local.Scenarios.OngoingChapterId];
			var text = string.Format(LocalizeManager.Instance.GetCommonText("STORY_RESET_DESC"), ongoingMaster.chapter, LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{ongoingMaster.id}_name"));
			UI.Popup.ShowConfirm("", text, CanvasType.App2, (r)=>
			{
				if (r == UIPopupDialog.Result.OK)
				{
					startSection(model);
				}
			});
		}
		else
		{
			startSection(model);
		}
		
	}

	void startSection(SectionStatusViewModel model)
	{
		var master = DataManager.Instance.Master.Chapter[model.masterId];
		if (!model.isClear || (AdvChapterType)master.sectionType == AdvChapterType.Battle|| (AdvChapterType)master.sectionType == AdvChapterType.BattleZone )
		{
			AsyncManager.Instance.StartGuardAsync(AdvManager.Instance.StartScenarioAsync(master.id));
		}
		else
		{
			var text = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{model.masterId}_desc");
			UI.Popup.ShowConfirm(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{model.masterId}_name"), text, CanvasType.App2, (r)=>
			{
				if (r == UIPopupDialog.Result.OK)
				{
					AsyncManager.Instance.StartGuardAsync(AdvManager.Instance.StartScenarioAsync(master.id));
				}
			});
		}
	}

	float GetScrollObjectAhpha(float y)
	{
		if (y > SECTION_ALPHA_TOP_Y)
		{
			var alpha = 1.0f - ((y - SECTION_ALPHA_TOP_Y) / (SECTION_TOP_Y - SECTION_ALPHA_TOP_Y));
			alpha = Mathf.Clamp(alpha, 0.0f, 1.0f);
			return alpha;
		}
		return 1.0f;
	}

	public override void Dispose()
	{
		base.Dispose();
		Hide();
		Destroy(this.gameObject);
	}
}
