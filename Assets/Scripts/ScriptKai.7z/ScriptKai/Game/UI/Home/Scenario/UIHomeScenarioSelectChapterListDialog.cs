﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using ScenarioSelect;
using System.Linq;
using UnityEngine.UI;

public class UIHomeScenarioSelectChapterListDialog : UIDialogBase
{

    [SerializeField] UIButton backButton;
    [SerializeField] ChapterButton chapterButtonPrefab;
    [SerializeField] Transform chapterButtonParent;
	[SerializeField] private ScrollRect scrollrect;
	[SerializeField] private GameObject titleObj;
	List<GameObject> chapterButtonList = new List<GameObject>();
	[SerializeField] UIButton gotoUndergroundButton;

	public UIIntEvent SelectChapter = new UIIntEvent();

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
		backButton.onClick.SubscribeAsync(OnClickBackAsync).AddTo(mSubscriptions);
		// titleObj.SetActive(!TutorialManager.Instance.GetIsLockHome());
		gotoUndergroundButton.onClick.SubscribeAsync(OnClickUnderground).AddTo(mSubscriptions);
    }
    
	private async UniTask OnClickBackAsync(GameObject o)
	{
		await UI.Page.CloseCurrentPage();
		// await UI.Page.ChangePage<UIHomeMainPage>();
	}
	private async UniTask OnClickUnderground(GameObject o)
	{
		await UI.Page.ChangePage<UIUndergroundPage>();
	}

	private int selectChapter_;
	public async UniTask SetupAsync(Dictionary<int, ChapterStatusViewModel> modelList, int selectChapter)
	{
		foreach (var button in chapterButtonList)
		{
			Destroy(button.gameObject);
		}
		chapterButtonList.Clear();
		var chapterList = DataManager.Instance.Master.Chapter.Values.Select(m => m.chapter).Distinct().ToList();
		foreach (var chapter in chapterList)
		{
			if (chapter == 0)
				continue;

			var chapterModel = modelList[chapter];
			var master = DataManager.Instance.Master.ChapterUnlockMaster[chapter];
			bool undergroundComplete = DataManager.Instance.Player.underground.IsOpenedEvent(master.undergroundEventId);
			bool isOpen = !chapterModel.isLocked && undergroundComplete; //&& DataManager.Instance.Player.Chapter.IsOpenCharpter(chapter);
			
			var button = Instantiate(chapterButtonPrefab, chapterButtonParent, false);
			//button.name = chapter.ToString();
			await  button.InitializeAsync(chapterModel);
			button.OnClick.Subscribe(_ =>
			{
				if (isOpen)
				{
					SelectChapter.Invoke(chapter);
				}
				else
				{
					if (!undergroundComplete)
					{
						//提示解锁地下城
						var str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.UNDERGROUND,
								$"Event_Content_{master.undergroundEventId}");
						var msg = string.Format(
							LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.UNDERGROUND,
								"Underground_Chapter_UnLock"),str);
						UI.Popup.ShowPopMessage(msg);
					}
					else if (chapterModel.isLocked)
					{
						if (chapterModel.requireLevel > DataManager.Instance.Player.Player.GetLevel())
						{
							var msg = string.Format(
								LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ADV,
									"Error_PlayerLevelFormat"), chapterModel.requireLevel);
							UI.Popup.ShowPopMessage(msg);
						}
						else
						{
							UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ADV,
								"Error_ChapterNotComplete"));
						}
					}
					// else if (!memoryQuestComplete)
					// {
					// 	var msg = string.Format(
					// 		LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ADV,
					// 			"Error_MemoryQuestNotCompleteFormat"), chapter - 1);
					// 	UI.Popup.ShowPopMessage(msg);
					// }
					// else if ( !DataManager.Instance.Player.Chapter.IsOpenCharpter(chapter) )
					// {
					// 	UnlockClick(button,chapter);
					// }
					
				}
			});
			button.gameObject.SetActive(true);
			SetChapterButtonIcon(button.ChapterText, chapterModel, button);
			chapterButtonList.Add(button.gameObject);
			//await UniTask.DelayFrame(5);
		}

		selectChapter_ = selectChapter;
	}
	//解锁
	private void UnlockClick(ChapterButton button,int chapterId)
	{
		var master = DataManager.Instance.Master.ChapterUnlockMaster[chapterId];
		var s = master.item[0].Split(':');
		var itemName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ITEM, $"{s[0]}_name");

		if (!StoryUtil.IsHaveReward(chapterId))
		{
			//如果配了多个道具这里需要改
			var needNum = long.Parse(s[1])-DataManager.Instance.Player.Item.GetCount(long.Parse(s[0]));
			UI.Popup.ShowPopMessage(string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "Chapter_Unlock_NeedNum"), needNum, itemName));
			return;
		}
	
		
		
		var str =string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "Chapter_Unlock_Context"),s[1],itemName);
		UI.Popup.ShowConfirm(string.Empty, str, CanvasType.App2, (r)=>
		{
			if (r == UIPopupDialog.Result.OK)
			{
				AsyncManager.Instance.StartAsync(UnLockAsync(button,chapterId));
			}
		});
	}

	private async UniTask UnLockAsync(ChapterButton button,int chapterId)
	{
		await StoryService.UnlockChapter(chapterId);
		SignalBus.GlobalSignal.Dispatch(UIEventId.UIHeaderInfoUpdate);
		button.OnClick.RemoveAllListeners();
		button.OnClick.Subscribe(_ =>
		{
			SelectChapter.Invoke(chapterId);
		});
		button.PlayAnimation();
		
	}
	
	void SetChapterButtonIcon(ChapterButtonText buttonText, ChapterStatusViewModel model, ChapterButton button)
	{
		buttonText.ResetIcon();
		var master = DataManager.Instance.Master.ChapterUnlockMaster[model.chapter];
		bool undergroundComplete = DataManager.Instance.Player.underground.IsOpenedEvent(master.undergroundEventId);

		if (model.isLocked || !undergroundComplete)
			return;

		var sectionList = DataManager.Instance.Master.Chapter.Values.Where(x=>x.chapter ==model.chapter);

		bool isNew = model.isNew;
		bool isComp = model.isComplete;

		if (isNew)
		{
			buttonText.SetNewIcon();
		}else if (isComp)
		{
			buttonText.SetCompleteIcon();
		}
		else if (model.isClear)
		{
			buttonText.SetClearIcon();
		}

	}
	public async UniTask ShowAsync()
	{
		
		await base.ShowAsync();
		if(selectChapter_>1)
			scrollrect.horizontalNormalizedPosition = selectChapter_*1.0f/(chapterButtonList.Count-1); 
	}


}
