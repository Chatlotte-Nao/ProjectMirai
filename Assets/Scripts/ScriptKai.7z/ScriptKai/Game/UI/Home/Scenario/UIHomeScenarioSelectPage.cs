﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Linq;

public class UIHomeScenarioSelectPage : UIPageBase
{
    private UIHomeHeaderParam headerParam = null;
    private UIHomeBattleWarningDialog mBattleWarning = null;

    private UIHomeScenarioSelectChapterListDialog mChapterListDialog = null;
    private PageParam mParam = null;
    private UIHomeScenarioSelectSectionDialog mSectionDialog = null;

    private Dictionary<int, ChapterStatusViewModel> mViewModelList = new Dictionary<int, ChapterStatusViewModel>();

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);

        mChapterListDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeScenarioSelectChapterListDialog, CanvasType.App0) as UIHomeScenarioSelectChapterListDialog;
        mSectionDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeScenarioSelectSectionDialog, CanvasType.App0) as UIHomeScenarioSelectSectionDialog;
        mBattleWarning = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeBattleWarningDialog, CanvasType.App1) as UIHomeBattleWarningDialog;

        mParam = param as UIHomeScenarioSelectPage.PageParam;

        headerParam = new UIHomeHeaderParam()
        {
            visibleBack = false,
            visibleIcon = false,
            visiblePlayerStatus = false,
            visibleRightRank = false,
            visibleItem = true,
            visibleNavigation = true,
            visibleHome = true,
            
            
            showResType = new List<UIHeaderResType>()
            {
                 UIHeaderResType.Stamina,
            },
            //conuitemIds = new List<long>(){103002047}
        };
        mChapterListDialog.SelectChapter.GuardSubscribeAsync(ShowSectionAsync).AddTo(mSubscriptions);

        var chapterList = DataManager.Instance.Master.Chapter.Values.Select(m => m.chapter).Distinct().ToList();
		foreach (var chapter in chapterList)
		{
			if (chapter == 0)
				continue;

			var chapterModel = StoryUtil.BuildChapterViewModel(chapter);
            mViewModelList.Add(chapter, chapterModel);
		}

        
        mSectionDialog.OnClickBack.GuardSubscribeAsync(ShowChapterListAsync).AddTo(mSubscriptions);
        mSectionDialog.OnBattleWarning.SubscribeAsync(ShowBattleWarningAsync).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        // if (TutorialManager.Instance.GetIsLockHome())
        // {
        //     headerParam.visibleBack = false;
        //     headerParam.visibleNavigation = false;
        //     headerParam.visibleHome = false;
        // }

        SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);
       
        await base.ShowAsync(showType);
        
        switch (mParam.showType)
        {
            case UIHomeScenarioSelectPage.PageParam.ShowType.Chapter:
                await mChapterListDialog.SetupAsync(mViewModelList, mParam.selectChapter);
                await mChapterListDialog.ShowAsync();
                break;
            case UIHomeScenarioSelectPage.PageParam.ShowType.Section:
                await mChapterListDialog.SetupAsync(mViewModelList, mParam.selectChapter);
                await ShowSectionAsync(mParam.selectChapter);
                break;
            default:
                break;
        }
       
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await mChapterListDialog.HideAsync();
        await mSectionDialog.HideAsync();
    }

    private async UniTask ShowSectionAsync(int chapter)
    {
        
        await mSectionDialog.SetupAsync(mViewModelList[chapter]);
        mChapterListDialog.Hide();
        await mSectionDialog.ShowAsync();
    }


    private async UniTask ShowChapterListAsync()
    {
        mSectionDialog.Hide();
        await mChapterListDialog.ShowAsync();
    }

    private async UniTask ShowBattleWarningAsync()
    {
        await mBattleWarning.ShowAsync();
        await mBattleWarning.HideAsync();
        //Log.Debug("warning end");
    }

    public override void Dispose()
    {
        base.Dispose();

        if (mChapterListDialog != null)
        {
            mChapterListDialog.Dispose();
            mChapterListDialog = null;
        }
        if (mSectionDialog != null)
        {
            mSectionDialog.Dispose();
            mSectionDialog = null;
        }
        if (mBattleWarning != null)
        {
            mBattleWarning.Dispose();
            mBattleWarning = null;
        }
    }

    public class PageParam
    {
        public enum ShowType
        {
            Chapter, 
            Section,
            Battle
        }

        public int clearSectionMasterId = 0;
        public bool firstClear = false;

        public int selectChapter = 0;
        public int selectSection = 0;
        public ShowType showType = ShowType.Chapter;
    }
}