﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

namespace ScenarioSelect
{
	public class ChapterButton : MonoBehaviour
	{
		[SerializeField] UIButton button;
		[SerializeField] Image iconImage;
		[SerializeField] GameObject desableSelectObject;
		[SerializeField] Animation unlockAnimation;
		//[SerializeField] private UIText unLockText;
		bool IsSelect = false;
		[SerializeField] public ChapterButtonText ChapterText;
		public ClickEvent OnClick => button.onClick;
		
		private void OnDestroy()
		{
			if (button != null)
			{
				button.onClick.RemoveAllListeners();
				button = null;
			}
		}

		public async UniTask InitializeAsync(ChapterStatusViewModel model)
		{
			gameObject.SetActive(true);
			ChapterText.Initialize(model);
			iconImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("Scenario/ChapterBG", $"zx_chapterbj_0{model.chapter}");
			var master = DataManager.Instance.Master.ChapterUnlockMaster[model.chapter];
			bool undergroundComplete = DataManager.Instance.Player.underground.IsOpenedEvent(master.undergroundEventId);
			desableSelectObject.SetActive(model.isLocked || !undergroundComplete);//!DataManager.Instance.Player.Chapter.IsOpenCharpter(model.chapter));
			// var item = DataManager.Instance.Master.ChapterUnlockMaster[model.chapter].item;
			// var s = item[0].Split(':');
			// unLockText.SetRawText(s[1]);
			
			if ( !DataManager.Instance.Local.Scenarios.UnlockScenarioChapterIds.Contains(model.chapter) && !model.isLocked &&undergroundComplete )
			{
				desableSelectObject.SetActive(true);
				DataManager.Instance.Local.Scenarios.UnlockScenarioChapterIds.Add(model.chapter);
				DataManager.Instance.Local.Save();
				PlayAnimation();
			}
		}

		public void PlayAnimation()
		{
			unlockAnimation.Play();
			AsyncManager.Instance.StartAsync(SetDesableActive);
		}

		private async UniTask SetDesableActive()
		{
			var time = unlockAnimation.clip.length;
			await UniTask.Delay((int)(time * 1000));
			if(desableSelectObject.activeSelf)
				desableSelectObject.SetActive(false);
		}

		/// <summary>
		/// 選択中ライン表示
		/// </summary>
		/// <param name="isForced">true:必ず変更を行う false:ライン表示ステータスが一緒の時は処理しない</param>
		public void SetSelectLineActive(bool isActive,bool isForced)
		{
			if (!isForced &&
				IsSelect == isActive)
				return;

			IsSelect = isActive;

			if (ChapterText != null)
			{
				ChapterText.SetSelectDisplay(isActive, isForced);
			}
		}

		/// <summary>
		/// 選択できない状態にする　（鍵はかかっていないけど選択できない）
		/// </summary>
		public void SetDisableSelect(bool isActive)
		{
			desableSelectObject.SetActive(isActive);
		}
		public bool IsDisableSelect()
		{
			if (desableSelectObject == null)
				return false;
			return desableSelectObject.activeSelf;
		}
		
	}
}
