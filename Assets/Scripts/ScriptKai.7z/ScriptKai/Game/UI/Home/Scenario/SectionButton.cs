﻿
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using DG.Tweening;

namespace ScenarioSelect
{
	public class SectionButton : MonoBehaviour
	{
		/// <summary>
		/// ロック状態を押した時の処理
		/// </summary>
		public System.Action PushLockAction = null;
		/// <summary>
		/// 選択できない状態を押した時の処理
		/// </summary>
		public System.Action PushDisableSelectAction = null;
		/// <summary>
		/// 報酬ボタンを押した時の処理
		/// </summary>
		public System.Action PushRewardAction = null;

		public enum DataType
		{
			STORY,
			EVENT_STORY,
		}

		[SerializeField] Image bgImage;

		[SerializeField] UIButton button;
		[SerializeField] GameObject baseObject;
		[SerializeField] UIText titleText;
		[SerializeField] GameObject selectFlame;
		[SerializeField] Button favoriteButton;
		[SerializeField] UIButton rewardButton;
		[SerializeField] GameObject rewardCover;

		[SerializeField] GameObject mapIcon;
		[SerializeField] GameObject advIcon;
		[SerializeField] GameObject battleIcon;

		[SerializeField] GameObject newIcon;
		[SerializeField] GameObject clearIcon;
		[SerializeField] GameObject completeIcon;

		[SerializeField] GameObject rewardGroup;
		[SerializeField] UIText rewardNumText;
		[SerializeField] GameObject starRewardGroup;
		[SerializeField] UIText starRewardNumText;



		[SerializeField] GameObject lockObject;
		[SerializeField] GameObject desableSelectObject;
		[SerializeField] GameObject selectLine;
		[SerializeField] private Animation animation;
		[SerializeField] private AnimationClip showAnimation;
		CanvasGroup canvasGroup;

		SectionStatusViewModel mModel = null;

		public SectionStatusViewModel Model => mModel;

		public ClickEvent OnClick => button.onClick;

		public ClickEvent OnRewardClick => rewardButton.onClick;
		void Awake()
		{
			canvasGroup = GetComponent<CanvasGroup>();
		}


		public async UniTask Initialize(SectionStatusViewModel model)
		{
			mModel = model;
			var master = DataManager.Instance.Master.Chapter[model.masterId];
			titleText.SetLabel(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{model.masterId}_name");

			bgImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("Scenario/SectionBG", master.scePartBg);

			advIcon.SetActive(false);
			mapIcon.SetActive(false);
			battleIcon.SetActive(false);

			switch (master.sectionType)
			{
				case 1:
					mapIcon.SetActive(true);
					break;
				case 2:
				case 3:
					battleIcon.SetActive(true);
					break;
				case 4:
					advIcon.SetActive(true);
					break;
				default:
					break;
			}

			if (model.totalRewardNum > 0)
			{
				rewardNumText.SetRawText(string.Format("{0}/{1}", model.currentRewardNum, model.totalRewardNum));
			}
			else
			{
				rewardGroup.SetActive(false);
			}
			if (model.totalStarRewardNum > 0)
			{
				starRewardNumText.SetRawText(string.Format("{0}/{1}", model.currentStarRewardNum, model.totalStarRewardNum));
			}
			else
			{
				starRewardGroup.SetActive(false);
			}

			newIcon.SetActive(false);
			clearIcon.SetActive(false);
			completeIcon.SetActive(false);
			lockObject.SetActive(false);

			
			if (model.isLocked) lockObject.SetActive(true);
			else if (model.isNew) newIcon.SetActive(true);
			else if (model.isComplete) completeIcon.SetActive(true);
			else if (model.isClear) clearIcon.SetActive(true);

			
			
		}


		public void SetActiveSelectFlame(bool isActive)
		{
			selectFlame.SetActive(isActive);
		}


		public bool IsLock()
		{
			if (lockObject == null)
				return false;
			return lockObject.activeSelf;
		}
		public void SetSelectLineActive(bool isActive)
		{
			if (selectLine == null)
				return;
			selectLine.SetActive(isActive);
		}

		public void SetBaseObjectX(float x)
		{
			baseObject.transform.localPosition = new Vector3(x, baseObject.transform.localPosition.y, baseObject.transform.localPosition.z);
		}

		public async UniTask Show()
		{
			// baseObject.transform.DOKill();
			// baseObject.transform.localPosition = new Vector3(1200, baseObject.transform.localPosition.y, baseObject.transform.localPosition.z);
			// baseObject.transform.DOLocalMoveX(0, 0.4f).SetEase(Ease.InOutQuart);
			await UIAnimationPlayer.PlayAsync(animation, showAnimation);
		}


		public CanvasGroup GetCanvasGroup()
		{
			return canvasGroup;
		}
	}
}
