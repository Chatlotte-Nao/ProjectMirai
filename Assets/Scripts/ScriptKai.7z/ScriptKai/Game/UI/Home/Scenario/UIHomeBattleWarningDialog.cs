﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIHomeBattleWarningDialog : UIDialogBase
{
    [SerializeField] Animator animator;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        var index = Game.Sound.SoundPlayer.PlaySe("SE_Warning");
        await base.ShowAsync(showType);
        await UniTask.WaitUntil(()=>animator.GetCurrentAnimatorStateInfo(0).normalizedTime >= 1f);
        Game.Sound.SoundPlayer.StopSe(index, 0.5f);
    }
}
