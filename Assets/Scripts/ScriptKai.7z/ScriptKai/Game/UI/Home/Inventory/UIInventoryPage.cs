﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIInventoryPage : UIPageBase
{
    UIInventoryMainWindow mMainWindow = null;
    //UIDialogBase mBg = null;
    UIInventoryUseSimpleDialog mUseSimple = null;
    UIInventoryUseSelectDialog mUseSelect = null;
    UIInventorySellDialog mSell = null;
    private UIHomeHeaderParam headerParam;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        //mBg = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeInventoryBg, CanvasType.BG);
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeInventoryMainWindow, CanvasType.App0) as UIInventoryMainWindow;
        mMainWindow.OnCloseClick.GuardSubscribeAsync(ShowMainMenu).AddTo(mSubscriptions);
        headerParam = new UIHomeHeaderParam();
        headerParam.showResType.Add(UIHeaderResType.Coin);
        headerParam.visibleBack = true;
        headerParam.visibleNavigation = true;
        headerParam.visibleHome = true;


        mMainWindow.OnClickUse.GuardSubscribeAsync(onClickUseAsync).AddTo(mSubscriptions);
        mMainWindow.OnClickSell.GuardSubscribeAsync(onClickSellAsync).AddTo(mSubscriptions);
        
    }
    private async UniTask ShowMainMenu(GameObject o)
    {
        await UI.Page.CloseCurrentPage();
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);
        await base.ShowAsync(showType);
        //await mBg.ShowAsync(showType);
        await mMainWindow.UpdateContent();
        await mMainWindow.ShowAsync(showType);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await mMainWindow.HideAsync(showType);
        //await mBg.HideAsync(showType);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
        // if (mBg != null)
        // {
        //     mBg.Dispose();
        //     mBg = null;
        // }
        if (mUseSimple != null)
        {
            mUseSimple.Dispose();
            mUseSimple = null;
        }
        if (mUseSelect != null)
        {
            mUseSelect.Dispose();
            mUseSelect = null;
        }
        if (mSell != null)
        {
            mSell.Dispose();
            mSell = null;
        }
    }

    private async UniTask onClickUseAsync(GameObject o)
    {
        if (DataManager.Instance.Master.Item[mMainWindow.CurrentId].contentType == 105)
        {
            if (mUseSelect == null)
            {
                mUseSelect = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeInventoryUseSelectDialog, CanvasType.App1) as UIInventoryUseSelectDialog;
                mUseSelect.OnProcess.GuardSubscribeAsync(onProcessUseSelectAsync).AddTo(mSubscriptions);
            }
            await mUseSelect.SetupAsync(mMainWindow.CurrentId);
            await mUseSelect.ShowAsync();
        }
        else
        {
            if (DataManager.Instance.Master.Content[mMainWindow.CurrentId].contentTypeMasterId == 123)
            {
                //体力道具
                var addValue = DataManager.Instance.Master.Item[mMainWindow.CurrentId].exp;
                if (DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.StaminaMaxValue].data <=
                    DataManager.Instance.Player.Player.GetCurrentStaimina())
                {
                    var  str= LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.INVENTORY, "INVENTORY_STAMINAMAX");
                    await UI.Popup.ShowPopupMessageAsync(str);
                    return;
                }
            }
            if (mUseSimple == null)
            {
                mUseSimple = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeInventoryUseSimpleDialog, CanvasType.App1) as UIInventoryUseSimpleDialog;
                mUseSimple.OnProcess.GuardSubscribeAsync(onProcessUseSimpleAsync).AddTo(mSubscriptions);
            }
            await mUseSimple.SetupAsync(mMainWindow.CurrentId);
            if (DataManager.Instance.Player.Item.GetCount(mMainWindow.CurrentId) == 1)
            {
                await onProcessUseSimpleAsync();
            }else{
               
                await mUseSimple.ShowAsync();
            }
        }
    }

    private async UniTask onClickSellAsync(GameObject o)
    {
        if (mSell == null)
        {
            mSell = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeInventorySellDialog, CanvasType.App1) as UIInventorySellDialog;
            mSell.OnProcess.GuardSubscribeAsync(onProcessSellAsync).AddTo(mSubscriptions);
        }
        await mSell.SetupAsync(mMainWindow.CurrentId);
        await mSell.ShowAsync();
    }


    private async UniTask onProcessSellAsync()
    {
        await ItemService.SellItem(mSell.Id, mSell.Num);

        await mSell.HideAsync();

        await mMainWindow.UpdateContent();
        List<string> result = new List<string>();
        var sellPrice = DataManager.Instance.Master.Item[mSell.Id].sellPrice;
        result.Add($"106000001:{sellPrice*mSell.Num}");
        await UI.Popup.ShowItemGetPopupAsync(result);

    }

    private async UniTask onProcessUseSimpleAsync()
    {
        var result = await ItemService.UseItem(mUseSimple.Id, mUseSimple.Num);

        await mUseSimple.HideAsync();

        if (mUseSimple.Id == 123000001)
        {
            List<string> results = new List<string>();
            var sellPrice = DataManager.Instance.Master.Item[mUseSimple.Id].exp;
            results.Add($"110000001:{sellPrice*mUseSimple.Num}");
            await UI.Popup.ShowItemGetPopupAsync(results);
        }
        else if (result != null && result.Count > 0)
        {
            await UI.Popup.ShowItemGetPopupAsync(result);
        }

        await mMainWindow.UpdateContent();
    }

    private async UniTask onProcessUseSelectAsync()
    {
        if (mUseSelect.SelectedIndex.Count == 0)
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.INVENTORY, "INVENTORY_SELECT"));
            return;
        }

        var result = await ItemService.UseItem(mUseSelect.Id, mUseSelect.Num, mUseSelect.SelectedIndex);

        await mUseSelect.HideAsync();

        if (result != null && result.Count > 0)
        {
            await UI.Popup.ShowItemGetPopupAsync(result);
        }

        await mMainWindow.UpdateContent();
    }
}
