﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;

public class UIInventoryUseSimpleDialog : UIDialogBase
{
    [SerializeField] BaseItem item;
    [SerializeField] UIText nameText;
    [SerializeField] UIText possessionCountText;

    [SerializeField] UIButton sliderAddButton;
    [SerializeField] UIButton sliderMinusButton;
    [SerializeField] Slider numSlider;
    [SerializeField] UIText useNumText;
    [SerializeField] UIButton okButton;
    [SerializeField] private UIButton cancelButton;
    [SerializeField] private UIButton closeButton2;

    public long Id => mCurrentId;
    public int Num => (int)numSlider.value;
    public UnityEvent OnProcess => okButton.OnTouchUpInside;


    private long mCurrentId = 0;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        numSlider.onValueChanged.Subscribe(onSliderValueChange).AddTo(mSubscriptions);
        sliderAddButton.OnTouchDown.Subscribe(onSliderAdd).AddTo(mSubscriptions);
        sliderAddButton.OnLongTouch.Subscribe(onSliderAdd).AddTo(mSubscriptions);
        sliderMinusButton.OnTouchDown.Subscribe(onSliderMinus).AddTo(mSubscriptions);
        sliderMinusButton.OnLongTouch.Subscribe(onSliderMinus).AddTo(mSubscriptions);
        cancelButton.onClick.Subscribe((o) =>
        {
            onClickClose(o);
        }).AddTo(mSubscriptions);
        closeButton2.onClick.Subscribe((o) =>
        {
            onClickClose(o);
        }).AddTo(mSubscriptions);
    }

    public async UniTask SetupAsync(long id)
    {
        mCurrentId = id;

        nameText.SetLabel(LocalizeManager.DATA_TYPE.ITEM, $"{id}_name");

        if (DataManager.Instance.Master.Content[id].contentTypeMasterId == 123)
        {
            //体力道具
            var addValue = DataManager.Instance.Master.Item[id].exp;
            numSlider.maxValue = Mathf.Min(DataManager.Instance.Player.Item.GetCount(id), (DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.StaminaMaxValue].data-DataManager.Instance.Player.Player.GetCurrentStaimina()+addValue-1)/addValue);
        }
        else
        {
            numSlider.maxValue = DataManager.Instance.Player.Item.GetCount(id);
        }

        numSlider.maxValue = Mathf.Min(numSlider.maxValue, 500);
        numSlider.minValue = 1;
        numSlider.value = 1;

        okButton.enabled = (numSlider.maxValue > 0);

        await item.SetupAsync(id, string.Empty);

        possessionCountText.SetFormat(LocalizeManager.DATA_TYPE.INVENTORY, "INVENTORY_POSSESSNUM_FORMAT", DataManager.Instance.Player.Item.GetCount(id));
    }

    private void onSliderAdd()
    {
        numSlider.value += 1;
    }

    private void onSliderMinus()
    {
        numSlider.value -= 1;
    }

    private void onSliderValueChange(float value)
    {
        useNumText.SetFormat(LocalizeManager.DATA_TYPE.INVENTORY, "INVENTORY_USENUM_FORMAT", (int)value);
    }

}
