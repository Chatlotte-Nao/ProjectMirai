﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
public class UIInventoryMainWindow : UIDialogBase
{
    [SerializeField] SelectableItem itemPrefab;
    [SerializeField] RectTransform itemTransformParent;

    [SerializeField] TabToggle[] showTab;

    [SerializeField] GameObject detailGroup;

    [SerializeField] Image detailImage;
    [SerializeField] Image detailFrameImage;
    [SerializeField] UIText detailNameText;
    [SerializeField] UIText possessionCountText;
    [SerializeField] UIText descText;
    [SerializeField] UIButton sellButton;
    [SerializeField] UIButton useButton;

    [SerializeField] ItemObtainWay[] itemObtainWays;
    [SerializeField] UIButton closeBtn;
    [SerializeField] private RectTransform scrollContent;
    [SerializeField] private GameObject notObj;
    [SerializeField] private ScrollRect scrollrect;
    [SerializeField] private UIToggleGroupController tollgeGroup;
    public long CurrentId => mCurrentId;

    public ClickEvent OnClickUse => useButton.onClick;
    public ClickEvent OnClickSell => sellButton.onClick;
    public ClickEvent OnCloseClick => closeBtn.onClick;

    private Dictionary<long, SelectableItem> mItems = new Dictionary<long, SelectableItem>();
    private long mCurrentId = 0;
    private int mPage = 0;
    private long mItemId = 0;

    public async override UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        
        for (int i = 0; i < itemObtainWays.Length; i++)
        {
            var idx = i;
            itemObtainWays[i].OnClickGoto.GuardSubscribeAsync(async ()=>
            {
                await OnClickGoto(idx);
            }).AddTo(mSubscriptions);
        }
        foreach (var item in DataManager.Instance.Player.Item.GetList())
        {
            if (item.Count == 0) continue;
            var master = DataManager.Instance.Master.Item[item.ItemMasterId];
            if(master.isInventory !=1 ) continue;
            var newItemObj = GameObject.Instantiate(itemPrefab.gameObject);
            newItemObj.transform.parent = itemTransformParent;
            newItemObj.transform.localScale = Vector3.one;
            newItemObj.transform.localRotation = Quaternion.identity;
            newItemObj.transform.localPosition = Vector3.zero;
            newItemObj.SetActive(true);

            var sel = newItemObj.GetComponent<SelectableItem>();
            await sel.SetupAsync(item.ItemMasterId, item.Count.ToString());
            if(item.Count>9999)
                await sel.SetupAsync(item.ItemMasterId, "9999+");
            sel.OnClick.Subscribe(()=>
            {
                OnSelectItem(sel);
            }).AddTo(mSubscriptions);

            mItems.Add(item.ItemMasterId, sel);
        }

        for (int i = 0; i < showTab.Length; i++)
        {
            int page = i;
            showTab[i].onValueChanged.Subscribe((v)=>
            {
                if(v)
                    PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01");
                scrollContent.localPosition = new Vector3(scrollContent.localPosition.x, 0, 0);
                RefreshList(page);
            }).AddTo(mSubscriptions);
        }

        
    }
    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        if (showType == UIPageShowType.Front)
        {
            scrollrect.verticalNormalizedPosition = 1;
            tollgeGroup.reFresh(0);
            if (CurrentId > 0)
            {
                mItems[CurrentId].Select(false);
            }
            mCurrentId = -1;
            RefreshList(0);
        }

        await base.ShowAsync(showType);
        // mRTCamera.gameObject.SetActive(true);
    }
    public async UniTask UpdateContent()
    {
        foreach (var item in DataManager.Instance.Player.Item.GetList())
        {
            if (!mItems.ContainsKey(item.ItemMasterId))
            {
                if (item.Count == 0) continue;
                var master = DataManager.Instance.Master.Item[item.ItemMasterId];
                if(master.isInventory !=1 ) continue;
                var newItemObj = GameObject.Instantiate(itemPrefab.gameObject);
                newItemObj.transform.parent = itemTransformParent;
                newItemObj.transform.localScale = Vector3.one;
                newItemObj.transform.localRotation = Quaternion.identity;
                newItemObj.transform.localPosition = Vector3.zero;
                newItemObj.SetActive(true);

                var sel = newItemObj.GetComponent<SelectableItem>();
                sel.Setup(item.ItemMasterId, item.Count.ToString());
                if(item.Count>9999)
                    sel.Setup(item.ItemMasterId, "9999+");
                sel.OnClick.Subscribe(()=>
                {
                    OnSelectItem(sel);
                }).AddTo(mSubscriptions);

                mItems.Add(item.ItemMasterId, sel);
            }
            else
            {
                var sel = mItems[item.ItemMasterId].GetComponent<SelectableItem>();
                if (item.Count == 0)
                {
                    Destroy(sel.gameObject);
                    mItems.Remove(item.ItemMasterId);
                    if (mCurrentId == item.ItemMasterId)
                    {
                        mCurrentId = 0;
                    }
                }
                else
                {
                    sel.Setup(item.ItemMasterId, DataManager.Instance.Player.Item.GetCount(sel.ItemId).ToString());
                    if(item.Count>9999)
                        sel.Setup(item.ItemMasterId, "9999+");
                }
                
            }
        }

        RefreshList(mPage);
    }

    private void OnSelectItem(SelectableItem item)
    {
        if (CurrentId > 0)
        {
            mItems[CurrentId].Select(false);
        }
        item.Select(true);
        ShowDetail(item.ItemId);
    }

    private void ShowDetail(long id)
    {
        mItemId = id;
        detailGroup.SetActive(true);
        mCurrentId = id;
        detailNameText.SetLabel(LocalizeManager.DATA_TYPE.ITEM, $"{id}_name");

        //new
        var master = DataManager.Instance.Master.Item[id];
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(id, master); });
        //detailImage.sprite = ResourceManager.Instance.LoadSprite("ItemIcon", id.ToString());

      
        descText.SetLabel(LocalizeManager.DATA_TYPE.ITEM, $"{id}_desc");
        
        possessionCountText.SetFormat(LocalizeManager.DATA_TYPE.INVENTORY, "INVENTORY_POSSESSNUM_FORMAT", DataManager.Instance.Player.Item.GetCount(id));

        //var master = DataManager.Instance.Master.Item[id];
        //detailFrameImage.sprite = ResourceManager.Instance.LoadSpriteSmall("FrameBg", $"frame_item_{master.rarity}");
        useButton.gameObject.SetActive(master.displayType == 1);
        sellButton.gameObject.SetActive(master.sellPrice >0);
        for (int i = 0; i < 3; i++)
        {
            if (master.ObtainWay.Count > i)
            {
                itemObtainWays[i].gameObject.SetActive(true);
                //itemObtainWays[i].Setup(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.INVENTORY, master.ObtainWay[i]), true);
                if (master.getJumpUiId.Count > i)
                {
                    if (master.getJumpUiId[i] != null)
                    {
                        itemObtainWays[i].Setup(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.INVENTORY, master.ObtainWay[i]), true);
                    }
                }
                else
                    itemObtainWays[i].Setup(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.INVENTORY, master.ObtainWay[i]), false);
            }
            else
            {
                itemObtainWays[i].gameObject.SetActive(false);
            }
        }
        
    }

    private void RefreshList(int page)
    {
        mPage = page;
        bool first = true;
        if (mCurrentId > 0 && mItems.ContainsKey(mCurrentId))
        {
            if (shouldShow(mCurrentId, page))
            {
                first = false;
                OnSelectItem(mItems[mCurrentId]);
            }
        }
        var itemList = new List<long>(mItems.Keys);
        itemList.Sort();
        var itemNums = itemList.Count;
        for (int i = 0; i < itemList.Count; i++)
        {
            var show = shouldShow(itemList[i], page);
            if (!show) itemNums=(itemNums-1)<0?0:itemNums-1;
            var item = mItems[itemList[i]];
            item.gameObject.SetActive(show);
            item.transform.SetSiblingIndex(i);
            if (show && first)
            {
                OnSelectItem(item);
                first = false;
            }
        }
        notObj.SetActive(itemNums==0);
        if (first)
        {
            if (CurrentId > 0)
            {
                mItems[CurrentId].Select(false);
                mCurrentId = 0;
            }
            detailGroup.SetActive(false);
        }
    }

    private bool shouldShow(long id, int page)
    {
        if (page == 0) return true;
        return DataManager.Instance.Master.Item[id].displayType == page;
    }

    private async UniTask LoadSpriteAsync(long id,ItemMaster master)
    {
        detailImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("ItemIcon", id.ToString());
        detailFrameImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("FrameBg", $"frame_item_{master.rarity}");

    }

    private async UniTask OnClickGoto(int idx)
    {
        var master = DataManager.Instance.Master.Item.Values.FirstOrDefault(a => a.id == mItemId);
        if (master == null)
        {
           // obtainWayGroup.SetActive(false);
            return;
        }
        var jumpContent = master.getJumpUiId[idx];
        await CommonUtil.JumpToTargetPage(jumpContent);
        //await HideAsync();
       
    }
    void LateUpdate()
    {
        //roundScrollController.SetPosition();
    }
}
