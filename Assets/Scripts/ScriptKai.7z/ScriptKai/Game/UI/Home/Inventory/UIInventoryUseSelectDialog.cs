﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;

public class UIInventoryUseSelectDialog : UIDialogBase
{
    [SerializeField] SelectableItem itemPrefab;
    [SerializeField] RectTransform itemTransformParent;

    [SerializeField] UIButton sliderAddButton;
    [SerializeField] UIButton sliderMinusButton;
    [SerializeField] Slider numSlider;
    [SerializeField] UIText useNumText;
    [SerializeField] UIButton okButton;
    [SerializeField] private UIButton cancelButton;
    [SerializeField] private UIButton closeButton2;

    public long Id => mCurrentId;
    public int Num => (int)numSlider.value;
    public List<int> SelectedIndex => selectedIndex;
    public UnityEvent OnProcess => okButton.OnTouchUpInside;


    private long mCurrentId = 0;
    private int maxSelect = 1;
    List<SelectableItem> selectItems = new List<SelectableItem>();
    List<int> selectedIndex = new List<int>();

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        numSlider.onValueChanged.Subscribe(onSliderValueChange).AddTo(mSubscriptions);
        sliderAddButton.OnTouchDown.Subscribe(onSliderAdd).AddTo(mSubscriptions);
        sliderAddButton.OnLongTouch.Subscribe(onSliderAdd).AddTo(mSubscriptions);
        sliderMinusButton.OnTouchDown.Subscribe(onSliderMinus).AddTo(mSubscriptions);
        sliderMinusButton.OnLongTouch.Subscribe(onSliderMinus).AddTo(mSubscriptions);
        cancelButton.onClick.Subscribe((o) =>
        {
            onClickClose(o);
        }).AddTo(mSubscriptions);
        closeButton2.onClick.Subscribe((o) =>
        {
            onClickClose(o);
        }).AddTo(mSubscriptions);

    }

    public override async UniTask HideAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.HideAsync(showType);

        
        foreach (var item in selectItems)
        {
            Destroy(item.gameObject);
        }

        selectItems.Clear();
    }

    public async UniTask SetupAsync(long id)
    {
        mCurrentId = id;

        selectedIndex.Clear();

        
        numSlider.maxValue = DataManager.Instance.Player.Item.GetCount(id);
        numSlider.maxValue = Mathf.Min(numSlider.maxValue, 500);
        numSlider.minValue = 1;
        numSlider.value = 1;

        var dropMaster = DataManager.Instance.Master.Drop[DataManager.Instance.Master.Item[id].dropMasterId];
        maxSelect = dropMaster.pickNum;

        var dropList = dropMaster.fixedDrop;
        int i = 0;
        foreach (var item in dropList)
        {
            var s = item.Split(':');
            var itemId = long.Parse(s[0]);
            var itemNum = int.Parse(s[1]);
            var newItemObj = GameObject.Instantiate(itemPrefab.gameObject);
            newItemObj.transform.parent = itemTransformParent;
            newItemObj.transform.localScale = Vector3.one;
            newItemObj.transform.localRotation = Quaternion.identity;
            newItemObj.transform.localPosition = Vector3.zero;
            newItemObj.SetActive(true);

            var sel = newItemObj.GetComponent<SelectableItem>();
            await sel.SetupAsync(itemId, itemNum.ToString());

            selectItems.Add(sel);
            var idx = i;

            sel.OnClick.Subscribe(()=>
            {
                onSelectItem(idx);
            }).AddTo(mSubscriptions);
            sel.SetUpLongClick();
            i++;
        }

        //okButton.enabled = (selectedIndex.Count == maxSelect);

    }
    private void onSelectItem(int idx)
    {
        var item = selectItems[idx];
        if (item.IsSelected)
        {
            item.Select(false);
            selectedIndex.Remove(idx);
        }
        else
        {
            if (selectedIndex.Count >= maxSelect)
            {
                if (maxSelect == 1)
                {
                    selectItems[selectedIndex[0]].Select(false);
                    selectedIndex.Clear();
                }
                else
                {
                    //do nothing
                    return;
                }
            }
            
            item.Select(true);
            selectedIndex.Add(idx);
        }
        
        //okButton.enabled = (selectedIndex.Count == maxSelect);
    }

    private void onSliderAdd()
    {
        numSlider.value += 1;
        updateItemNumber();
    }

    private void onSliderMinus()
    {
        numSlider.value -= 1;
        updateItemNumber();
    }

    private void updateItemNumber()
    {
        if (selectItems.Count > 0)
        {
            var dropMaster =
                DataManager.Instance.Master.Drop[DataManager.Instance.Master.Item[mCurrentId].dropMasterId];
            maxSelect = dropMaster.pickNum;
            var dropList = dropMaster.fixedDrop;
            int i = 0;
            foreach (var item in dropList)
            {
                var s = item.Split(':');
                var itemId = long.Parse(s[0]);
                var itemNum = int.Parse(s[1]) * numSlider.value;
                selectItems[i].Setup(itemId, itemNum.ToString());
                i++;
            }
        }
    }

    private void onSliderValueChange(float value)
    {
        useNumText.SetFormat(LocalizeManager.DATA_TYPE.INVENTORY, "INVENTORY_USENUM_FORMAT", (int)value);
        updateItemNumber();
    }

}
