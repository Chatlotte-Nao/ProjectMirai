﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.Events;

public class UIInventorySellDialog : UIDialogBase
{
    [SerializeField] BaseItem item;
    [SerializeField] UIText nameText;
    [SerializeField] UIText possessionCountText;
    [SerializeField] UIText singlePriceText;
    [SerializeField] UIText totalPriceText;

    [SerializeField] UIButton sliderAddButton;
    [SerializeField] UIButton sliderMinusButton;

    [SerializeField] Slider numSlider;
    [SerializeField] UIText useNumText;
    [SerializeField] UIButton okButton;

    [SerializeField] private UIButton cancelButton;
    [SerializeField] private UIButton closeButton2;
    

    public long Id => mCurrentId;
    public int Num => (int)numSlider.value;
    public UnityEvent OnProcess => okButton.OnTouchUpInside;


    private long mCurrentId = 0;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        numSlider.onValueChanged.Subscribe(onSliderValueChange).AddTo(mSubscriptions);

        sliderAddButton.OnTouchDown.Subscribe(onSliderAdd).AddTo(mSubscriptions);
        sliderAddButton.OnLongTouch.Subscribe(onSliderAdd).AddTo(mSubscriptions);
        sliderMinusButton.OnTouchDown.Subscribe(onSliderMinus).AddTo(mSubscriptions);
        sliderMinusButton.OnLongTouch.Subscribe(onSliderMinus).AddTo(mSubscriptions);
        cancelButton.onClick.Subscribe((o) =>
        {
            onClickClose(o);
        }).AddTo(mSubscriptions);
        closeButton2.onClick.Subscribe((o) =>
        {
            onClickClose(o);
        }).AddTo(mSubscriptions);
    }

    public async UniTask SetupAsync(long id)
    {
        mCurrentId = id;

        nameText.SetLabel(LocalizeManager.DATA_TYPE.ITEM, $"{id}_name");
        
        numSlider.maxValue = DataManager.Instance.Player.Item.GetCount(id);
        numSlider.minValue = 1;
        numSlider.value = 1;

        await item.SetupAsync(id, string.Empty);

        possessionCountText.SetFormat(LocalizeManager.DATA_TYPE.INVENTORY, "INVENTORY_POSSESSNUM_FORMAT", DataManager.Instance.Player.Item.GetCount(id));
    }

    private void onSliderAdd()
    {
        numSlider.value += 1;
    }

    private void onSliderMinus()
    {
        numSlider.value -= 1;
    }

    private void onSliderValueChange(float value)
    {
        int count = (int)value;
        useNumText.SetFormat(LocalizeManager.DATA_TYPE.INVENTORY, "INVENTORY_SELLNUM_FORMAT", count);

        var price = DataManager.Instance.Master.Item[mCurrentId].sellPrice;
        
        singlePriceText.SetRawText(price.ToString());
        totalPriceText.SetRawText((price*count).ToString());
    }

}
