﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Game.Ui
{
	/// <summary>
	/// スクロールのアクティブを制御する
	/// 表示物がスクロール範囲内に納まっているときはスクロールしない
	/// コンポーネントに追加しておくと全自動で動く
	/// </summary>
	public class ScrollActiveManager : MonoBehaviour
	{
		/// <summary>
		/// 基準となる表示範囲
		/// </summary>
		[SerializeField]
		RectTransform BaseDisplayRect;
		/// <summary>
		/// スクロールする物(ボタンなどを親子付けする親。ContentSizeFitterで可変になっている部分)
		/// </summary>
		[SerializeField]
		RectTransform ScrollObjectRect;
		[SerializeField]
		ScrollRect ActiveScrollRect;
		[SerializeField]
		GameObject ScrollBar;

		private void OnDestroy()
		{
			BaseDisplayRect = null;
			ScrollObjectRect = null;
			ActiveScrollRect = null;
			ScrollBar = null;
		}

		private void OnEnable()
		{
		}

		private void OnDisable()
		{
			ScrollBar.SetActive(false);
		}

		private void Update()
		{
			ChangeActiveScrollFunction();
		}

		void ChangeActiveScrollFunction()
		{
			if ((ActiveScrollRect.horizontal && ScrollObjectRect.rect.width > BaseDisplayRect.rect.width) ||
				(ActiveScrollRect.vertical && ScrollObjectRect.rect.height > BaseDisplayRect.rect.height))
			{
				ActiveScrollRect.enabled = true;
				ScrollBar.SetActive(true);
			}
			else
			{
				if (ActiveScrollRect.horizontal)
					ActiveScrollRect.horizontalNormalizedPosition = 1.0f;
				if (ActiveScrollRect.vertical)
					ActiveScrollRect.verticalNormalizedPosition = 1.0f;
				ActiveScrollRect.enabled = false;
				ScrollBar.SetActive(false);
			}
		}
	}
}
