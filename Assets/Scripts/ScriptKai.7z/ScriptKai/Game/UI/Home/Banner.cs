﻿using AssetManage;
using Base.Ui;
using Base.Util;

//using Mission;
using System.Collections.Generic;
//using Tutorial;
using UnityEngine;
using UnityEngine.UI;


namespace Home
{
	public class Banner : MonoBehaviour
	{
		[SerializeField] ScrollRect	scrollRect;
		[SerializeField] GameObject	prefab;
		[SerializeField] ScrollRect	indicators;
		[SerializeField] GameObject	indicatorPrefab;

		[SerializeField] Sprite dummyImage;

		static readonly float	MOVE_WAIT_TIME	= 5f;
		//static readonly int		BANNER_NUM		= 4;

		ScrollSnap	scrollSnap;
		float	lastChangeTime;
		GameObject	centerBanner;
		BaseGameScene scene;
		List<GameObject> instanceList = new List<GameObject>();
		//List<HomeBannerMaster> master;

		int setCounter = 0;

		void Awake()
		{
			scrollSnap	= scrollRect.GetComponent<ScrollSnap>();
			//			indicators.transform.parent.gameObject.SetActive(true);

			setCounter = 0;
		}


		void Update()
		{
			AutoMove();
		}


		void OnEnable()
		{
			if (scrollSnap == null)	return;
			scrollSnap.onCenter.AddListener(OnCenter);
			scrollSnap.onSnaped.AddListener(OnSnaped);
		}


		void OnDisable()
		{
			if (scrollSnap == null)	return;
			scrollSnap.onCenter.RemoveListener(OnCenter);
			scrollSnap.onSnaped.RemoveListener(OnSnaped);
		}


		private void OnDestroy()
		{
			scrollSnap = null;
			centerBanner = null;
			scene = null;

			if (instanceList == null || 0 >= instanceList.Count) return;
			foreach (var go in instanceList)
			{
				GameObject.DestroyImmediate(go);
			}
			instanceList.Clear();

			dummyImage = null;
		}


		void OnCenter(GameObject center)
		{
			if (center != centerBanner)
			{
				centerBanner	= center;
				UpdateIndicator();
			}
		}


		void OnSnaped()
		{
			lastChangeTime	= Time.timeSinceLevelLoad;
		}


		//void SetupBanner(List<HomeBannerMaster> master, AssetLoader assetLoader)
		//{
		//	var i = 0;
		//	foreach (var record in master)
		//	{
		//		var go = Utility.CreateGameObject(prefab, scrollRect.content);
		//		go.SetActive(true);
		//		go.name = prefab.name + i;
		//		var bannerItem = go.GetComponent<BannerItem>();
		//		var image = assetLoader.GetSprite(record.image, AssetManage.AssetBundleLabelNames.Home);
		//		bannerItem.Initialize(i, image);
		//		bannerItem.onClick.AddListener(OnClickBanner);

		//		if (centerBanner == null) centerBanner = go;
		//		instanceList.Add(go);

		//		go = Utility.CreateGameObject(indicatorPrefab, indicatorPrefab.transform.parent);
		//		go.SetActive(true);
		//		go.GetComponent<Image>().color = Color.grey;
		//		instanceList.Add(go);
		//		i++;
		//	}

		//	gameObject.SetActive(master.Count > 0);
		//}


		//public void Initialize(BaseGameScene scene, List<HomeBannerMaster> master, AssetLoader assetLoader)
		//{
		//	this.scene = scene;
		//	this.master = master;
		//	SetupBanner(master, assetLoader);
		//	UpdateIndicator();
		//}

		public void InitializeStoryEventBanner(BaseGameScene scene, GameObject value)
		{
			this.scene = scene;

			value.transform.SetParent(scrollRect.content);
			var localpos = value.transform.localPosition;
			localpos.z = 0;
			value.transform.localPosition = localpos;
			value.SetActive(true);
			value.name = prefab.name + setCounter;
			value.layer = prefab.layer;//UI

			var bannerItem = value.GetComponent<Image>();
			if (bannerItem?.sprite == null)
			{
				bannerItem.sprite = dummyImage;
				value.GetComponent<RectTransform>().sizeDelta = prefab.GetComponent<RectTransform>().sizeDelta;
			}

			if (centerBanner == null) centerBanner = value;
			instanceList.Add(value);

			var go = Utility.CreateGameObject(indicatorPrefab, indicatorPrefab.transform.parent);
			go.SetActive(true);
			go.GetComponent<Image>().color = Color.grey;
			instanceList.Add(go);

			setCounter++;
		}

		public void ResetCounter()
		{
			setCounter = 0;
		}

		public void CallStoryEventBannerUpdateIndicator()
		{
			if (setCounter >= 2) { UpdateIndicator(); }
		}

		public void OnClickMove(int dir)
		{
			Move(dir);
		}


		void OnClickBanner(int id)
		{
			//var record = master[id];
			//ChangeScene(record.transitionPoint);
		}


		void Move(int dir)
		{
			scrollSnap.Move(dir < 0 ? Vector2.left : Vector2.right);
			lastChangeTime	= Time.timeSinceLevelLoad;
		}


		void AutoMove()
		{
			float	now	= Time.timeSinceLevelLoad;
			if (lastChangeTime == 0f)	lastChangeTime	= now;
			if (now - lastChangeTime < MOVE_WAIT_TIME)	return;

			Move(-1);
		}


		void UpdateIndicator()
		{
			var	index	= StringUtil.ToInt(centerBanner.name.Substring(centerBanner.name.Length - 1));

			foreach (RectTransform rect in indicators.content)
			{
				var	image	= rect.GetComponent<Image>();
				image.color	= rect.GetSiblingIndex() == index + 1 ? Color.white : Color.grey;

				var showObject	= image.gameObject.transform.Find("Select").gameObject;
				showObject.SetActive(rect.GetSiblingIndex() == index + 1 ? true : false);
			}
		}

		void ChangeScene(int transitionPointId)
		{
			//挑戦ボタン押下時に対象の各シーンへ遷移
			//switch (transitionPointId)
			//{
			//	case (int)MissionSceneConstants.TransitionType.Dungeon:
			//		scene.Change<DungeonSelectScene>();
			//		break;
			//	case (int)MissionSceneConstants.TransitionType.Pvp:
					//scene.Change<PvpTopScene>();
				//	break;
				//case (int)MissionSceneConstants.TransitionType.MilitaryOperation:
					//scene.Change<MilitaryOperationScene>();
					//break;
				//case (int)MissionSceneConstants.TransitionType.InvestigationMission:
					//scene.Change<InvestigationMissionScene>();
					//break;
			//	case (int)MissionSceneConstants.TransitionType.Equipment:
					//EquipmentSceneContext.CreateInstance();
					//var equipmentSceneContext = EquipmentSceneContext.Instance;
					//equipmentSceneContext.ExecuteMode = ExecuteMode.Normal;
					//equipmentSceneContext.BehaviourMode = EquipmentScreenCatalog.BehaviourMode.Enhancement;
		//			var playerData = UserData.GetPlayerData();
		//			var ids = playerData.TutorialReadIds;
//					if (ids.Contains((int)TutorialController.SerialId.Home_FunctionRelease_1))
		//			{
			//			scene.Change<EquipmentScene>();
		//			}
		//			break;
			//	case (int)MissionSceneConstants.TransitionType.InvestigationBattle:
				//	InvestigationMissionScene.SetStartTab(InvestigationMission.TabChangeButton.TAB_TYPE.BATTLE);
				//	scene.Change<InvestigationMissionScene>();
				//	break;
				//case (int)MissionSceneConstants.TransitionType.Training:
					//scene.Change<TrainingRoomScene>();
					//break;
				//case (int)MissionSceneConstants.TransitionType.Character:
				//	scene.Change<CharacterMainScene>();
				//	break;
				//case (int)MissionSceneConstants.TransitionType.MusicalEffectPowerUp:
					//scene.Change<MusicalEffectPowerUpScene>();
					//break;
				//case (int)MissionSceneConstants.TransitionType.Home:
					//var sceneName = LocationMaster.Get("advBuilding[2]").scene;
					//if (detailsMaster.id == (int)MissionSceneConstants.MissionDetails.BankLevel ||
					//	detailsMaster.id == (int)MissionSceneConstants.MissionDetails.CollectCoinForBank)
					//{
					//	//シンフォニカの銀行に移動
					//	Map.MapContext.GetInstance().SetOutsideStartSetting(sceneName, "routeBank");
					//}
					//if (detailsMaster.id == (int)MissionSceneConstants.MissionDetails.FoodProductionLevel ||
					//	detailsMaster.id == (int)MissionSceneConstants.MissionDetails.CollectFoodForProduction)
					//{
					//	//シンフォニカの食料保管庫に移動
					//	Map.MapContext.GetInstance().SetOutsideStartSetting(sceneName, "route (4)");
					//}
					//scene.Change<HomeMainScene>();
					//break;
			//	case (int)MissionSceneConstants.TransitionType.Shop:
					//scene.Change<ShopScene>();
				//	break;
			//	case (int)MissionSceneConstants.TransitionType.Chapter:
					//var scenarioSelectContext = ScenarioSelectContext.GetInstance();
					//var partSettingMaster = FindTransitionPartSettingMaster(detailsMaster.id);
					//scenarioSelectContext.StartOpenFreeBattleQuestId = partSettingMaster == null ? -1 : partSettingMaster.questId;
					//var routeType = GetRouteType(detailsMaster.id);
					//scenarioSelectContext.StartOpenType = detailsMaster.speciesType == 0 ? ScenarioSelectContext.START_OPEN_TYPE.TOP : ScenarioSelectContext.START_OPEN_TYPE.FREE_BATTLE;
					//scenarioSelectContext.StartOpenFreeBattleRoute = routeType;
			//		scene.Change<ScenarioSelectScene>();
			//		break;
			//	case (int)MissionSceneConstants.TransitionType.NormalGacha:
					//var normalGachaMaster = MasterData.GetInstance().gachaMaster.Values
					//	.Where(master => master.gachaType == (int)GachaConstants.GachaType.NormalGacha)
					//	.FirstOrDefault();
					//GachaSceneContext.CreateInstance().SelectedGachaMasterId = normalGachaMaster.id;
				//	scene.Change<GachaScene>();
				//	break;
			//}
		}
	}
}
