﻿
using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using TMPro;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeEquipmentGradeUpDialog : UIHomeEquipmentMainPagePanelBaseDialog
{
    [SerializeField] UIText textLevel;
    [SerializeField] UIText textMaxLevel;

    [Space]
    [SerializeField] GameObject groupCostGold;

    [SerializeField] BaseResource costMoney;
    [SerializeField] UIButton btnGradeUp;

    [Space]
    [SerializeField] Transform costItemsContent;

    [Space]
    [SerializeField] BaseItem costItemPrefab;

    [SerializeField] private BaseAttributeUp prefab;
    [SerializeField] private RectTransform attributeTransform;
    private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();

    private List<BaseItem> m_ListCostItems = new List<BaseItem>();

    private long masterId;
    public UILongEvent OnGradeUpClicked = new UILongEvent();

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        btnGradeUp.OnTouchUpInside.Subscribe(() =>
        {
            if (costMoney.IsNeed())
            {
                OnGradeUpClicked.Invoke(masterId);
            }
            else
            {
                UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "CHARACTER_ITEMS_NOT"));
            }
        }).AddTo(mSubscriptions);
    }

    public void Setup()
    {
        RefreshData();
    }

    public override void RefreshData()
    {
        //groupCostGold.SetActive(false);
        long _keyInGradeUpTable = EquipmentUtil.FindKeyInGradeUpTable(m_EquipmentViewModel.id, m_EquipmentViewModel.grade + 1);
        if (_keyInGradeUpTable != 0)
        {
            //next grade attribute
            //string levelFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_MaxLevel") + ": {0}<color=\"red\">→{1}";
            // string hpFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Hp") + ": {0}<color=\"red\">→{1}";
            // string atkFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Patk") + ": {0}<color=\"red\">→{1}";

            EquipmentViewModel fakeNextGardeEVM = EquipmentUtil.BuildFakeEquipmentViewModelByPointGrade(m_EquipmentViewModel, m_EquipmentViewModel.grade + 1);
            textMaxLevel.SetRawText(fakeNextGardeEVM.maxLevel.ToString());
            textLevel.SetRawText(m_EquipmentViewModel.level.ToString());
            foreach (var attribute in attributeList)
            {
                attribute.gameObject.SetActive(false);
            }

            int index = 1;
            for (int i = 1; i < (int)CharacterAttribute.Max; i++)
            {
                CharacterAttribute eAtt = (CharacterAttribute)i;
                var oldValue = m_EquipmentViewModel.attributeDict[eAtt];
                var newValue = fakeNextGardeEVM.attributeDict[eAtt];
                if (newValue > oldValue )
                {
                    if (index < attributeList.Count)
                    {
                        attributeList[index].LoadAttributeData(eAtt,eAtt.GetAttributePercent(oldValue),eAtt.GetAttributePercent(newValue));
                        attributeList[index].gameObject.SetActive(true);
                    }
                    else
                    {
                        var attribute = Instantiate(prefab, this.attributeTransform, false);
                        attribute.LoadAttributeData(eAtt,eAtt.GetAttributePercent(oldValue),eAtt.GetAttributePercent(newValue));
                        attribute.gameObject.SetActive(true);
                        attributeList.Add(attribute);
                    }
                    index++;
                }
            }
            
            //cost item
            int costItemIndex = 0;
            EquipmentGradeUpMaster rankUpStaticData = DataManager.Instance.Master.EquipmentGradeUpMaster[_keyInGradeUpTable];
            masterId = rankUpStaticData.id;
            foreach (var item in rankUpStaticData.requireContents)
            {
                var s = item.Split(':');
                var id = long.Parse(s[0]);

                BaseItem costItem = null;
                if (costItemIndex >= m_ListCostItems.Count)
                {
                    costItem = GameObject.Instantiate(costItemPrefab);
                    costItem.transform.parent = costItemsContent;

                    costItem.transform.localScale = Vector3.one;
                    costItem.transform.localPosition = Vector3.zero;
                    m_ListCostItems.Add(costItem);
                }
                else
                    costItem = m_ListCostItems[costItemIndex];

                costItem.gameObject.SetActive(true);
                costItem.SetupNeed(id, long.Parse(s[1]));
                costItemIndex++;
            }

            for (int i = costItemIndex; i < m_ListCostItems.Count; i++)
            {
                m_ListCostItems[i].gameObject.SetActive(false);
            }

            //cost money
            int goldCost = DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.EquipmentGradeUpCost].data;
            int totalGoldCost = Mathf.CeilToInt(goldCost * (m_EquipmentViewModel.grade + 1));
            costMoney.SetupMoneyNeed(totalGoldCost);
        }
        else
        {
            //max grade
        }

        if (!costMoney.IsNeed() || ! EquipmentUtil.IsGradeUp(masterId))
        {
            btnGradeUp.GetComponent<Image>().color = Color.black;
        }
        else
        {
            btnGradeUp.GetComponent<Image>().color = Color.white;
        }
    }
}
