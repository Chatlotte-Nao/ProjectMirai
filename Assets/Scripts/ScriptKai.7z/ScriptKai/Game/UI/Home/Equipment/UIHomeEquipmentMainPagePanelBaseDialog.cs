﻿using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using Takasho.Schema.Score.ResourceCn.Equipment.V1;
using UnityEngine;

public class UIHomeEquipmentMainPagePanelBaseDialog : UIDialogBase
{
    protected PlayerEquipment m_EquipmentServerData = null;
    protected EquipmentMaster m_EquipmentStaticData = null;
    protected EquipmentViewModel m_EquipmentViewModel = null;

    public virtual void RefreshData()
    { }

    public void SetData(EquipmentViewModel equipmentViewModel, PlayerEquipment equipmentServerData = null, EquipmentMaster equipmentStaticData = null)
    {
        m_EquipmentServerData = equipmentServerData;
        m_EquipmentStaticData = equipmentStaticData;
        m_EquipmentViewModel = equipmentViewModel;
    }
}
