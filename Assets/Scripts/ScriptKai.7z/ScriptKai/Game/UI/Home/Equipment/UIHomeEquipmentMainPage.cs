﻿using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Takasho.Schema.Score.ResourceCn.Equipment.V1;

public class UIHomeEquipmentMainPage : UIPageBase
{
    private UIHomeEquipmentDetailDialog DetailPanel = null;

    EquipmentParam equipmentParam = null;

    private UIHomeEquipmentFullScreenDialog fullScreen = null;
    private UIHomeEquipmentGradeUpDialog GardeUpPanel = null;
    private UIHomeEquipmentGradeUpSuccessDialog gradeUpSuccessDialog = null;
    UIHomeHeaderParam headerParam = new UIHomeHeaderParam();
    private UIHomeEquipmentLevelUpDialog LevelUpPanel = null;

    private UIHomeEquipmentLevelUpSuccessDialog levelUpSuccessDialog = null;

    private UIHomeEquipmentMainPagePanelBaseDialog m_CurrentActivePanel;
    private int m_CurrentTab = 0;
    private UIHomeEquipmentMainDialog m_EquipmentMainPageDialog = null;
    private EquipmentViewModel m_EquipmentViewModel = null;
    private List<EquipmentViewModel> m_ListAllEquipmentVMs = new List<EquipmentViewModel>();
    private UIHomeEquipmentRankUpDialog RankUpPanel = null;
    private UIHomeEquipmentRankUpSuccessDialog rankUpSuccessDialog = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync();

        equipmentParam = (EquipmentParam) param;
        //init data
        m_EquipmentViewModel = equipmentParam.model;

        _updateAllEquipmentViewModelsList();

        m_EquipmentMainPageDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeEquipmentMainDialog, CanvasType.App0) as UIHomeEquipmentMainDialog;

        //notify to update head bar
       
        headerParam.showResType.Add(UIHeaderResType.Coin);
        
        headerParam.visibleRightRank = false;
        headerParam.visibleBack = true;
        headerParam.visibleNavigation = true;
        headerParam.visibleHome = true;
      

        //bind tab click event
        m_EquipmentMainPageDialog.OnSelectTab.GuardSubscribeAsync(OnClickTab).AddTo(mSubscriptions);
        m_EquipmentMainPageDialog.DisplayCard.OnClickLock.GuardSubscribeAsync(OnLockValueChange).AddTo(mSubscriptions);
        m_EquipmentMainPageDialog.OnCloseClick.GuardSubscribeAsync(OnCloseClick).AddTo(mSubscriptions);
        m_EquipmentMainPageDialog.OnFullScreenClick.GuardSubscribeAsync(OnShowFullScreen).AddTo(mSubscriptions);
        // m_EquipmentMainPageDialog.LevelUpPanel.OnLevelUpPageLevelUpClicked.GuardSubscribeAsync(OnLevelUpPageLevelUpClicked).AddTo(mSubscriptions);
        // m_EquipmentMainPageDialog.GardeUpPanel.OnGradeUpClicked.GuardSubscribeAsync(OnGradeUpPageGradeUpClicked).AddTo(mSubscriptions);
        // m_EquipmentMainPageDialog.RankUpPanel.OnRankUpClicked.GuardSubscribeAsync(OnRankUpPageRankUpClicked).AddTo(mSubscriptions);
        
        //DetailPanel = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeEquipmentDetailDialog, CanvasType.App0) as UIHomeEquipmentDetailDialog;
        LevelUpPanel = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeEquipmentLevelUpDialog, CanvasType.App0) as UIHomeEquipmentLevelUpDialog;
        GardeUpPanel = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeEquipmentGradeUpDialog, CanvasType.App0) as UIHomeEquipmentGradeUpDialog;
        RankUpPanel = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeEquipmentRankUpDialog, CanvasType.App0) as UIHomeEquipmentRankUpDialog;
        
        fullScreen =  await UI.Dialog.CreateAsync(UIPrefabId.UIHomeEquipmentFullScreenDialog, CanvasType.App2) as UIHomeEquipmentFullScreenDialog;
        
        LevelUpPanel.OnLevelUpPageLevelUpClicked.GuardSubscribeAsync(OnLevelUpPageLevelUpClicked).AddTo(mSubscriptions);
        GardeUpPanel.OnGradeUpClicked.GuardSubscribeAsync(OnGradeUpPageGradeUpClicked).AddTo(mSubscriptions);
        RankUpPanel.OnRankUpClicked.GuardSubscribeAsync(OnRankUpPageRankUpClicked).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);
        Debug.Log("show uihomeequippage");
        await base.ShowAsync(showType);
        m_CurrentTab = 2;
        m_EquipmentMainPageDialog.SetData(m_EquipmentViewModel);
        m_EquipmentMainPageDialog.ActivePanel(equipmentParam.type);
        await m_EquipmentMainPageDialog.ShowAsync(showType);
        await ChangeTabAsync(m_CurrentTab, true);
        


        //if (m_CurrentActivePanel != null)
        //{

        //    await m_CurrentActivePanel.ShowAsync(showType);
        //}
        //else if(equipmentParam.type == EquipmentMainPagePanelType.Detail)
        //{
        //    m_CurrentActivePanel = DetailPanel;
        //    DetailPanel.SetData(m_EquipmentViewModel);
        //    DetailPanel.SetUp();
        //    await m_CurrentActivePanel.ShowAsync(showType);
        //}
        //else
        //{
        //await ChangeTabAsync(m_CurrentTab, true);
        //}
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        if (m_CurrentActivePanel != null)
        {
            await m_CurrentActivePanel.HideAsync(showType);
        }
        await m_EquipmentMainPageDialog.HideAsync(showType);

    }

    private async UniTask OnCloseClick(GameObject o)
    {
        await UI.Page.CloseCurrentPage();
    }

    private async UniTask OnShowFullScreen(long id)
    {
         await fullScreen.SetUp(id);
         await fullScreen.ShowAsync();
    }

    public override void Dispose()
    {
        base.Dispose();

        if (m_EquipmentMainPageDialog != null)
            m_EquipmentMainPageDialog.Dispose();
        if (levelUpSuccessDialog != null)
            levelUpSuccessDialog.Dispose();
        if (gradeUpSuccessDialog != null)
            gradeUpSuccessDialog.Dispose();
        if (rankUpSuccessDialog != null)
            rankUpSuccessDialog.Dispose();
        //if (DetailPanel != null)
        //{
        //    DetailPanel.Dispose();
        //    DetailPanel = null;
        //}
        if (LevelUpPanel != null)
        {
            LevelUpPanel.Dispose();
            LevelUpPanel = null;
        }
        if (GardeUpPanel != null)
        {
            GardeUpPanel.Dispose();
            GardeUpPanel = null;
        }
        if (RankUpPanel != null)
        {
            RankUpPanel.Dispose();
            RankUpPanel = null;
        }

        if (fullScreen != null)
        {
            fullScreen.Dispose();
            fullScreen = null;
        }

        m_EquipmentMainPageDialog = null;
        levelUpSuccessDialog = null;
        gradeUpSuccessDialog = null;
        rankUpSuccessDialog = null;
    }

    #region public functions

    private async UniTask ChangeTabAsync(int tab, bool isForceRefresh)
    {
        
        if (m_CurrentTab == tab && isForceRefresh == false)
            return;

        var oldPanel = m_CurrentActivePanel;
        m_CurrentTab = tab;
        m_EquipmentMainPageDialog.SetData(m_EquipmentViewModel);
        await m_EquipmentMainPageDialog.ShowAsync();
        //DetailPanel.SetData(m_EquipmentViewModel);
        LevelUpPanel.SetData(m_EquipmentViewModel);
        GardeUpPanel.SetData(m_EquipmentViewModel);
        RankUpPanel.SetData(m_EquipmentViewModel);
        string titleStr = "";
        switch (tab)
        {
            case 1:
                //m_CurrentActivePanel = DetailPanel;
                //DetailPanel.SetUp();
                //titleStr = "UI_Equip_Title_Detail";
                break;
            case 2:
                if (m_EquipmentViewModel.isMaxLevelAndGrade)
                {
                    _updateAllEquipmentViewModelsList();
                    LevelUpPanel.SetLevelUpExtraData(m_ListAllEquipmentVMs);
                    m_CurrentActivePanel = LevelUpPanel;
                    titleStr = "UI_Equip_Title_LevelUp";
                }
                else
                {
                    if (m_EquipmentViewModel.isMaxLevel)
                    {
                        m_CurrentActivePanel = GardeUpPanel;
                        GardeUpPanel.Setup();
                        titleStr = "UI_Equip_Title_GardUp";
                    }
                    else
                    {
                        
                        _updateAllEquipmentViewModelsList();
                        LevelUpPanel.SetLevelUpExtraData(m_ListAllEquipmentVMs);
                        m_CurrentActivePanel = LevelUpPanel;
                        titleStr = "UI_Equip_Title_LevelUp";
                    }
                }
                break;
            case 3:
                RankUpPanel.SetRankUpExtraData(m_ListAllEquipmentVMs);
                m_CurrentActivePanel = RankUpPanel;
                titleStr = "UI_Equip_Title_RankUp";
                break;
        }
        titleStr = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, titleStr);
        m_EquipmentMainPageDialog.SetTitle(titleStr);
        if (oldPanel != null)
        {
            await oldPanel.HideAsync();
        }
        await m_CurrentActivePanel.ShowAsync();

    }

    #endregion

    public void SetAllEquipmentVMs(List<EquipmentViewModel> evms)
    {
        m_ListAllEquipmentVMs = evms;
    }

    #region button events

    public async UniTask OnClickTab(int tab)
    {
        await ChangeTabAsync(tab, false);
    }

    private async UniTask OnLockValueChange(bool v)
    {
        if (m_EquipmentViewModel.locked != v)
        {
            await EquipmentService.SetEquipmentLock(m_EquipmentViewModel.uniqueId, v);
            m_EquipmentViewModel.locked = v;
        }
    }

    private async UniTask OnLevelUpPageLevelUpClicked(List<EquipmentItemData> selectedEquipments)
    {
        if (selectedEquipments.Count <= 0)
        {
            UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Select_Item"));
            return;
        }

        //double confirm dialog
        bool _isEquiped = false;
        bool _isEnhanced = false;
        bool _isRare = false;
        string _hintText = null;
        var equipmentList = new List<string>();
        var itemsList = new Dictionary<long, int>();
        //var allGradeUpExp = EquipmentUtil.GetGradeUpAllExp(m_EquipmentViewModel);
        //long totalAddExp = 0;
        foreach (var data in selectedEquipments)
        {
            if (data.type == EquipmentType.PlayerItem)
            {
                itemsList.Add(data.item.ItemMasterId,data.selectCount);
                //totalAddExp += DataManager.Instance.Master.Item[long.Parse(data.itemId)].exp;
            }else if (data.type == EquipmentType.Equipment)
            {
                EquipmentViewModel evm = _findEquipmentVMbyGUID(data.itemId);
                var master = DataManager.Instance.Master.Equipment[evm.id];
                if (evm.equippedCharacter != 0)
                    _isEquiped = true;
                else if (master.rarity > (int) EquipmentRarity.R)
                    _isRare = true;
                else if (evm.totalExp != 0 || evm.rank != master.initialRank || evm.grade != master.initialGrade)
                    _isEnhanced = true;
                equipmentList.Add(data.itemId);
                //totalAddExp += (evm.totalExp + evm.baseSupplyExp);
            }
            
        }

        if (_isEquiped)
            _hintText = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "Confirm_Enhance_Equiped");
        else if (_isEnhanced && _isRare)
            _hintText = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "Confirm_Enhance_EnhancedRare");
        else if (_isRare)
            _hintText = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "Confirm_Enhance_Rare");
        else if (_isEnhanced)
            _hintText = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "Confirm_Enhance_Enhanced");
        // else if(totalAddExp > allGradeUpExp)
        //     _hintText = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "Confirm_Enhance_Grade");
        if (_hintText != null)
            UI.Popup.ShowConfirm(string.Empty, _hintText, CanvasType.App0, async (r) => { if (r == UIPopupDialog.Result.OK) await _processToLevelUp(equipmentList,itemsList); });
        else
            await _processToLevelUp(equipmentList,itemsList);
    }

    private async UniTask OnGradeUpPageGradeUpClicked(long id)
    {
        if (! EquipmentUtil.IsGradeUp(id))
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "CHARACTER_ITEMS_NOT"));
            return;
        }
        int legacyGrade = m_EquipmentViewModel.grade;

        await EquipmentService.GradeUpEquipment(m_EquipmentViewModel.uniqueId);

        _updateEquipmentVM();
        //if rank up success
        if (m_EquipmentViewModel.grade != legacyGrade)
        {
            _updateAllEquipmentViewModelsList();
            await ChangeTabAsync(m_CurrentTab, true);
            if (gradeUpSuccessDialog == null)
                gradeUpSuccessDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeEquipmentGradeUpSuccessDialog, CanvasType.App2) as UIHomeEquipmentGradeUpSuccessDialog;
            gradeUpSuccessDialog.SetData(m_EquipmentViewModel);
            await gradeUpSuccessDialog.ShowAsync();

            //refresh current tab -> auto switch to level up panel
        
        }
    }

    private async UniTask OnRankUpPageRankUpClicked(string guid)
    {
        int legacyRank = m_EquipmentViewModel.rank;

        List<string> usedEquipments = new List<string>();
        usedEquipments.Add(guid);

        await EquipmentService.RankUpEquipment(m_EquipmentViewModel.uniqueId, usedEquipments);

        PxSoundManager.Instance.PlaySe("feedbackSE_mequ_star01");

        _updateEquipmentVM();

        if (m_EquipmentViewModel.rank != legacyRank)
        {
            _updateAllEquipmentViewModelsList();
            if (rankUpSuccessDialog == null)
                rankUpSuccessDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeEquipmentRankUpSuccessDialog, CanvasType.App1) as UIHomeEquipmentRankUpSuccessDialog;
            rankUpSuccessDialog.SetData(legacyRank,m_EquipmentViewModel);
            await rankUpSuccessDialog.ShowAsync();
            await ChangeTabAsync(m_CurrentTab, true);
        }
    }

    #endregion

    #region tool functions

    private void _updateAllEquipmentViewModelsList()
    {
        m_ListAllEquipmentVMs.Clear();
        foreach (PlayerEquipment pe in DataManager.Instance.Player.Equipment.GetList())
        {
            m_ListAllEquipmentVMs.Add(EquipmentUtil.BuildEquipmentViewModel(pe));
        }
    }

    private void _updateEquipmentVM()
    {
        m_EquipmentViewModel = EquipmentUtil.BuildEquipmentViewModel(DataManager.Instance.Player.Equipment.Get(m_EquipmentViewModel.uniqueId));
    }

    private EquipmentViewModel _findEquipmentVMbyGUID(string guid)
    {
        foreach (EquipmentViewModel evm in m_ListAllEquipmentVMs)
        {
            if (string.Equals(guid, evm.uniqueId))
                return evm;
        }
        return null;
    }

    private async UniTask _processToLevelUp(List<string> selectedEquipments,Dictionary<long ,int> items)
    {
        int legacyLevel = m_EquipmentViewModel.level;

        await EquipmentService.LevelUpEquipment(m_EquipmentViewModel.uniqueId, selectedEquipments,items);

        _updateEquipmentVM();
        _updateAllEquipmentViewModelsList();

        await ChangeTabAsync(m_CurrentTab, true);
        //push success popup
        if (legacyLevel != m_EquipmentViewModel.level)
        {
            if (levelUpSuccessDialog == null)
                levelUpSuccessDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeEquipmentLevelUpSuccessDialog, CanvasType.App2) as UIHomeEquipmentLevelUpSuccessDialog;
            levelUpSuccessDialog.SetData(m_EquipmentViewModel,legacyLevel);
            await levelUpSuccessDialog.ShowAsync();
            PxSoundManager.Instance.PlaySe("feedbackSE_mequ_level01");
        }
       
        //refresh current tab
       
    }

    #endregion
}

public class EquipmentParam
{
    public EquipmentViewModel model;
    public EquipmentMainPagePanelType type = EquipmentMainPagePanelType.LevelUp;
}
public enum EquipmentMainPagePanelType
{
    None,
    Detail,
    LevelUp,
    StarUp
}
