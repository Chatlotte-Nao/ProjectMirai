﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

using Takasho.Schema.Score.ResourceCn.Equipment.V1;

public class UIHomeEquipmentListPage : UIPageBase
{
    IReadOnlyList<PlayerEquipment> ownedEquipmentList = DataManager.Instance.Player.Equipment.GetList();
    private UIHomeEquipmentListDialog m_EquipmentList = null;
    private int mCurrentTab = 0; //default select the frist one.
    private int m_SelectedIndex = 0;
    private Dictionary<long, EquipmentMaster> cache_equipments_dictionary = DataManager.Instance.Master.Equipment;
    private List<PlayerEquipment> currentTabEquipmentList = new List<PlayerEquipment>();
    private List<EquipmentMaster> currentTabEquipmentStaticDataList = new List<EquipmentMaster>();
    private List<EquipmentViewModel> currentTabEquipmentViewModels = new List<EquipmentViewModel>();
    private List<EquipmentViewModel> allEquipmentViewModels = new List<EquipmentViewModel>();

    private EquipmentSortType sortType = EquipmentSortType.Rare;
    private EquipmentSortOrder sortOrder = EquipmentSortOrder.Increasing;
    UIHomeHeaderParam headerParam = new UIHomeHeaderParam();


    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync();

        m_EquipmentList = await Pheonix.Core.UI.Dialog.CreateAsync(UIPrefabId.UIHomeEquipmentListDialog, CanvasType.App0) as UIHomeEquipmentListDialog;
        m_EquipmentList.OnCloseClick.GuardSubscribeAsync(OnCloseClick).AddTo(mSubscriptions);
        headerParam.showResType.Add(UIHeaderResType.Coin);
        headerParam.visibleRightRank = false;
        headerParam.visibleBack = false;
        headerParam.visibleBack = true;
        headerParam.visibleNavigation = true;
        headerParam.visibleHome = true;

        //bind tab click event
        m_EquipmentList.OnSelectTab.GuardSubscribeAsync(ChangeTabAsync).AddTo(mSubscriptions);

        //bind equipment icon click event
        m_EquipmentList.OnEquipmentIconClicked.GuardSubscribeAsync(OnClickEquipmentIcon).AddTo(mSubscriptions);
        m_EquipmentList.OnSortTypeChanged.GuardSubscribeAsync(OnClickSortType).AddTo(mSubscriptions);
        m_EquipmentList.OnSortOrderChanged.GuardSubscribeAsync(OnClickSortOrder).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        if (showType == UIPageShowType.Front)
        {
            sortType = EquipmentSortType.Rare;
            sortOrder = EquipmentSortOrder.Increasing;
        }
        SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);

        _upadteAllEquipmentViewModels();
        InitInventoryTab();
        await base.ShowAsync(showType);
        await m_EquipmentList.ShowAsync(showType);

        //build EquipmentViewModel data
       
    }
    private async UniTask OnCloseClick(GameObject o)
    {
        await UI.Page.CloseCurrentPage();
    }
    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);

        await m_EquipmentList.HideAsync(showType);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (m_EquipmentList != null)
        {
            m_EquipmentList.Dispose();
            m_EquipmentList = null;
        }
    }

    public EquipmentViewModel GetSelectedEquipment()
    {
        return currentTabEquipmentViewModels[m_SelectedIndex];
    }

    public List<EquipmentViewModel> GetAllEquipmentViewModels()
    {
        return allEquipmentViewModels;
    }

    private async UniTask OnClickEquipmentIcon(int index)
    {
        //push equipment main page
        m_SelectedIndex = index;
        EquipmentParam param = new EquipmentParam();
        param.model = GetSelectedEquipment();
        await UI.Page.OpenPage<UIHomeEquipmentMainPage>(param);
    }

    private async UniTask OnClickSortType(int index)
    {
        if (index == (int)sortType)
            return;

        sortType = (EquipmentSortType)index;
        List<EquipmentViewModel> _resultEVMs = new List<EquipmentViewModel>();

        //Sort
        EquipmentUtil.SortEquipments(sortType, sortOrder, ref currentTabEquipmentViewModels, out _resultEVMs);
        currentTabEquipmentViewModels = _resultEVMs;

        //notify
        m_EquipmentList.UpdateEquipmentViewList(currentTabEquipmentViewModels);
    }

    private async UniTask OnClickSortOrder(int index)
    {
        List<EquipmentViewModel> _resultEVMs = new List<EquipmentViewModel>();
        sortOrder = sortOrder == EquipmentSortOrder.Decreasing ? EquipmentSortOrder.Increasing : EquipmentSortOrder.Decreasing;

        //Sort
        EquipmentUtil.SortEquipments(sortType, sortOrder, ref currentTabEquipmentViewModels, out _resultEVMs);
        currentTabEquipmentViewModels = _resultEVMs;

        //notify
        m_EquipmentList.SortOrderChange(sortOrder);
        m_EquipmentList.UpdateEquipmentViewList(currentTabEquipmentViewModels);
    }

    private async UniTask ChangeTabAsync(int tab)
    {
        if (mCurrentTab == tab)
            return;

        mCurrentTab = tab;

        switch (tab)
        {
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
        }

        InitInventoryTab();
    }

    private void InitInventoryTab()
    {
        int _tab = mCurrentTab;

        currentTabEquipmentList = new List<PlayerEquipment>();
        currentTabEquipmentStaticDataList = new List<EquipmentMaster>();
        currentTabEquipmentViewModels = new List<EquipmentViewModel>();
        List<EquipmentViewModel> _resultEVMs = new List<EquipmentViewModel>();

        //filter
        foreach (PlayerEquipment e in ownedEquipmentList)
        {
            EquipmentMaster equipStaticData = cache_equipments_dictionary[e.EquipmentMasterId];

            if (equipStaticData.position == _tab || _tab == 0)
            {
                currentTabEquipmentList.Add(e);

                EquipmentViewModel env = allEquipmentViewModels.Find((x) => string.Equals(x.uniqueId, e.PlayerEquipmentId));
                currentTabEquipmentViewModels.Add(env);
            }
        }

        //Sort
        EquipmentUtil.SortEquipments(sortType, sortOrder, ref currentTabEquipmentViewModels, out _resultEVMs);
        currentTabEquipmentViewModels = _resultEVMs;

        //notify
        m_EquipmentList.UpdateEquipmentViewList(currentTabEquipmentViewModels);
    }


    #region tool functions
    private void _upadteAllEquipmentViewModels()
    {
        allEquipmentViewModels.Clear();
        ownedEquipmentList = DataManager.Instance.Player.Equipment.GetList();

        foreach (PlayerEquipment pe in ownedEquipmentList)
        {
            allEquipmentViewModels.Add(EquipmentUtil.BuildEquipmentViewModel(pe));
        }
    }
    #endregion

}
