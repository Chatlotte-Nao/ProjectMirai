﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;
using System;
using System.Text;
using UnityEngine.Events;
using Pheonix.Core;
using UnityEngine.UI;

public class UIHomeEquipmentRankUpSuccessDialog : UIDialogBase
{
    //[Space]
    //[SerializeField] UIButton btnClose;

    [Space]
    [SerializeField] RarityIcon rarityIconBefore;
    [SerializeField] private BaseSkillInfo beforeSkillInfo;

    [Space]
    [SerializeField] RarityIcon rarityIconAfter;
    [SerializeField] private BaseSkillInfo afterSkillInfo;


    [Space]
    public UIHomeEquipmentMainPageCardDialog DisplayCard;

    [SerializeField] private BaseAttributeUp prefab;
    [SerializeField] private RectTransform attributeTransform;
    
    private EquipmentViewModel m_EquipmentViewModel = null;

    private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();
    private int _oldRank;
    public void SetData(int oldRank,EquipmentViewModel evm)
    {
        _oldRank = oldRank;
        m_EquipmentViewModel = evm;
        foreach (var attribute in attributeList)
        {
            attribute.gameObject.SetActive(false);
        }
        beforeSkillInfo.gameObject.SetActive(false);
        afterSkillInfo.gameObject.SetActive(false);
        rarityIconBefore.SetRarity(_oldRank, RarityIcon.RarityType.EQUIPMENT);
        rarityIconAfter.SetRarity(m_EquipmentViewModel.rank, RarityIcon.RarityType.EQUIPMENT);
        
        EquipmentViewModel oldRankFakeVM = EquipmentUtil.BuildFakeEquipmentViewModelByPointRank(m_EquipmentViewModel, _oldRank);
        
        EquipmentRankUpMaster previousRankStaticData = EquipmentUtil.GetRankUpStaticConfig(m_EquipmentViewModel.id, _oldRank);
        if (previousRankStaticData.skillId > 0 )
        {
            beforeSkillInfo.SetUpData(previousRankStaticData.skillId);
            beforeSkillInfo.gameObject.SetActive(true);
        }
        if (m_EquipmentViewModel.skillId > 0 )
        {
            afterSkillInfo.SetUpData(m_EquipmentViewModel.skillId);
            afterSkillInfo.gameObject.SetActive(true);
        }
        
        int index = 1;
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            var oldValue = oldRankFakeVM.attributeDict[eAtt];
            var newValue = m_EquipmentViewModel.attributeDict[eAtt];
            if (newValue > oldValue)
            {
                if (index < attributeList.Count)
                {
                    attributeList[index].LoadAttributeData(eAtt, eAtt.GetAttributePercent(oldValue), eAtt.GetAttributePercent(newValue));
                    attributeList[index].gameObject.SetActive(true);
                }
                else
                {
                    var attribute = Instantiate(prefab, this.attributeTransform, false);
                    attribute.LoadAttributeData(eAtt, eAtt.GetAttributePercent(oldValue), eAtt.GetAttributePercent(newValue));
                    attribute.gameObject.SetActive(true);
                    attributeList.Add(attribute);
                }
                index++;
            } 
        }
        DisplayCard.SetData(m_EquipmentViewModel);
        DisplayCard.OnShow();
    }
}
