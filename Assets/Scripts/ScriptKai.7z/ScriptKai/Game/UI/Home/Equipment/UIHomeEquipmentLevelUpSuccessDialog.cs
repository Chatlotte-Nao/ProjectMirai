﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;
using System;
using System.Text;
using UnityEngine.Events;
using Pheonix.Core;
using UnityEngine.UI;

public class UIHomeEquipmentLevelUpSuccessDialog : UIDialogBase
{
    //[SerializeField] Button btnClose;
    [SerializeField] UIText attributeText;
    [SerializeField] GameObject levelBar;
    [SerializeField] GameObject content;
    [SerializeField] GameObject attributePrefab;
    [SerializeField] List<GameObject> contentList = new List<GameObject>();
    [SerializeField] private UITexture titleTexture;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        titleTexture.Load("Font", "ty_font_sjcg_01", true);
    }

    public void SetData(EquipmentViewModel evm,int oldLevel)
    {
        EquipmentViewModel fakePreviousGardeEVM = EquipmentUtil.BuildFakeEquipmentViewModelByPointLevel(evm, oldLevel);
        //StringBuilder sb = new StringBuilder();
        int index = 1;
        //content.GetComponent<RectTransform>().sizeDelta = new Vector2(1543, 132);
        foreach (var item in contentList)
        {
            item.gameObject.SetActive(false);
        }
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            var oldValue = fakePreviousGardeEVM.attributeDict[eAtt];
            var newValue = evm.attributeDict[eAtt] ;
            if (newValue > oldValue )
            {
               // sb.AppendFormat(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, $"Attribute_{eAtt}_Format_Change"), eAtt.GetAttributePercent(oldValue), eAtt.GetAttributePercent(newValue));
                //sb.AppendLine();
                
              
                if (index - 1 < contentList.Count)
                {
                    contentList[index - 1].SetActive(true);
                    var textLst = contentList[index - 1].GetComponentsInChildren<UIText>();
                    textLst[0].SetRawText(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, $"Attribute_{eAtt}"));

                    textLst[1].SetRawText(eAtt.GetAttributePercent(oldValue).ToString());
                    textLst[2].SetRawText(eAtt.GetAttributePercent(newValue));

                   
                }
                else
                {
                    GameObject go = Instantiate(attributePrefab, content.transform);
                    contentList.Add(go);
                    go.SetActive(true);
                    var goTextlst = go.GetComponentsInChildren<UIText>();
                    goTextlst[0].SetRawText(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, $"Attribute_{eAtt}"));
                    goTextlst[1].SetRawText(eAtt.GetAttributePercent(oldValue).ToString());
                    goTextlst[2].SetRawText(eAtt.GetAttributePercent(newValue));
                
                }
                index++;

            }
        }
        //Debug.Log(index-1);
        // if (index - 1 < 4)
        // {
        //     content.GetComponent<RectTransform>().sizeDelta -= new Vector2(500, 0);
        // }
        //attributeText.SetRawText(sb.ToString());
        var levelTextlst = levelBar.GetComponentsInChildren<UIText>();
        levelTextlst[0].SetRawText(string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, $"UI_Unit_LevelUp_Number"), oldLevel));
        levelTextlst[1].SetRawText(string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, $"UI_Unit_LevelUp_Number"), evm.level));
    }
}
