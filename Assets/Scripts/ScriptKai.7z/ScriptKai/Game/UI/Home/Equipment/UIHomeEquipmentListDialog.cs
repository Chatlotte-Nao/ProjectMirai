﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using Takasho.Schema.Score.ResourceCn.Equipment.V1;

public class UIHomeEquipmentListDialog : UIDialogBase
{
    [Space] 
    [SerializeField] private UIToggleGroupController group;
    [SerializeField] TabToggle tabGroupOne;
    [SerializeField] TabToggle tabGroupTwo;
    [SerializeField] TabToggle tabGroupThree;
    [SerializeField] TabToggle tabGroupFour;
    [SerializeField] TabToggle tabGroupAll;
    public UIIntEvent OnSelectTab = new UIIntEvent();
    public UIIntEvent OnEquipmentIconClicked = new UIIntEvent();
    public UIIntEvent OnSortTypeChanged = new UIIntEvent();
    public UIIntEvent OnSortOrderChanged = new UIIntEvent();

    [Space]
    [SerializeField] BaseEquipment equipmentIconPrefab;

    [Space]
    [SerializeField] Transform equipmentScrollContent;
    [SerializeField] GameObject equipmentScrollView;

    [Space]
    [SerializeField] TMPro.TMP_Dropdown dropdownsortType;
    [SerializeField] UIButton btnSortOrder;

    [SerializeField] private UIButton backButton;
    [SerializeField] private GameObject notObj;
    public ClickEvent OnCloseClick => backButton.onClick;
    private List<BaseEquipment> equipmentIconList = new List<BaseEquipment>();
    private List<EquipmentViewModel> equipmentViewModelList = new List<EquipmentViewModel>();
    //private List<PlayerEquipment> equipments = new List<PlayerEquipment>();
    //private List<EquipmentMaster> equipmentsStaticData = new List<EquipmentMaster>();

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        //characterScrollManager.OnSelectCharacter.GuardSubscribeAsync(onSelectCharacter).AddTo(mSubscriptions);
        //backButton.onClick.GuardSubscribeAsync(OnClickBackAsync).AddTo(mSubscriptions);

        //add toggle/tab panel click listener
        tabGroupOne.onValueChanged.Subscribe((isOn) => { if (isOn) {  OnSelectTab.Invoke(1); PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01"); equipmentScrollView.GetComponent<ScrollRect>().StopMovement(); equipmentScrollContent.localPosition = new Vector3(equipmentScrollContent.localPosition.x, 0, equipmentScrollContent.localPosition.z);  } }).AddTo(mSubscriptions);
        tabGroupTwo.onValueChanged.Subscribe((isOn) => { if (isOn) { OnSelectTab.Invoke(2); PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01"); equipmentScrollView.GetComponent<ScrollRect>().StopMovement(); equipmentScrollContent.localPosition = new Vector3(equipmentScrollContent.localPosition.x, 0, equipmentScrollContent.localPosition.z); } }).AddTo(mSubscriptions);
        tabGroupThree.onValueChanged.Subscribe((isOn) => { if (isOn) { OnSelectTab.Invoke(3); PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01"); equipmentScrollView.GetComponent<ScrollRect>().StopMovement(); equipmentScrollContent.localPosition = new Vector3(equipmentScrollContent.localPosition.x, 0, equipmentScrollContent.localPosition.z);  } }).AddTo(mSubscriptions);
        tabGroupFour.onValueChanged.Subscribe((isOn) => { if (isOn) { OnSelectTab.Invoke(4); PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01"); equipmentScrollView.GetComponent<ScrollRect>().StopMovement(); equipmentScrollContent.localPosition = new Vector3(equipmentScrollContent.localPosition.x, 0, equipmentScrollContent.localPosition.z); } }).AddTo(mSubscriptions);
        tabGroupAll.onValueChanged.Subscribe((isOn) => { if (isOn) { OnSelectTab.Invoke(0); PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01"); equipmentScrollView.GetComponent<ScrollRect>().StopMovement(); equipmentScrollContent.localPosition = new Vector3(equipmentScrollContent.localPosition.x, 0, equipmentScrollContent.localPosition.z); } }).AddTo(mSubscriptions);
        SetupSortDropdown();
        btnSortOrder.onClick.Subscribe((go) => OnSortOrderChanged.Invoke(0)).AddTo(mSubscriptions);
    }

    private async UniTask OnClickBackAsync(GameObject o)
    {
        await Pheonix.Core.UI.Page.CloseCurrentPage();
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        if (showType == UIPageShowType.Front)
        {
            SetupSortDropdown();
            group.reFresh(0);
            OnSelectTab.Invoke(0);
        }

        await base.ShowAsync(showType);
        // mRTCamera.gameObject.SetActive(true);
    }

    private void SetupSortDropdown()
    {
        dropdownsortType.ClearOptions();

        List<string> sortDropdownList = new List<string>();
        sortDropdownList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Rarity"));
        sortDropdownList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Level"));
        sortDropdownList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Rank"));
        dropdownsortType.AddOptions(sortDropdownList);

        dropdownsortType.onValueChanged.Subscribe((select) => OnSortTypeChanged.Invoke(select)).AddTo(mSubscriptions);
    }

    private void OnClickEquipment(EquipmentViewModel equipmentVM, BaseEquipment icon)
    {
        // notice to manager
        int index = equipmentIconList.IndexOf(icon);
        OnEquipmentIconClicked.Invoke(index);
    }


    #region public functions
    public void UpdateEquipmentViewList(List<EquipmentViewModel> equipmentVMs)
    {
        equipmentViewModelList = equipmentVMs;
        notObj.SetActive(equipmentViewModelList.Count==0);
        for (int i = 0; i < equipmentVMs.Count; i++)
        {
            EquipmentViewModel equipmentVM = equipmentVMs[i];
            BaseEquipment equipmentIcon = null;

            if (i >= equipmentIconList.Count)
            {
                equipmentIcon = GameObject.Instantiate(equipmentIconPrefab);
                equipmentIcon.transform.SetParent(equipmentScrollContent);
                equipmentIcon.OnClick.AddListener(() =>
                {
                    OnClickEquipment(equipmentVM, equipmentIcon);
                });
                equipmentIconList.Add(equipmentIcon);
            }
            else
                equipmentIcon = equipmentIconList[i];

            equipmentIcon.SetupEquipmentData(equipmentVM); //update equipment icon display
        }

        //hide no need equipment view
        for (int i = equipmentVMs.Count; i < equipmentIconList.Count; i++)
        {
            BaseEquipment icon = equipmentIconList[i];
            icon.gameObject.SetActive(false);
        }
    }

    public void SortOrderChange(EquipmentSortOrder order)
    {
        switch (order)
        {
            case EquipmentSortOrder.Decreasing:
                btnSortOrder.transform.localScale = Vector3.one;
                break;
            case EquipmentSortOrder.Increasing:
                btnSortOrder.transform.localScale = new Vector3(-1, 1, 1);
                break;
            default:
                break;
        }
    }
    #endregion

    private void OnDestroy()
    {
        equipmentIconList.Clear();
        equipmentViewModelList.Clear();
    }
}
