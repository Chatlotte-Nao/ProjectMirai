﻿
using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeEquipmentDetailDialog : UIHomeEquipmentMainPagePanelBaseDialog
{
    [SerializeField] UIText lvText;
   
    [SerializeField] private BaseSkillInfo beforeSkillInfo;
    [SerializeField] private BaseAttributeUp prefab;
    [SerializeField] private RectTransform attributeTransform;
    private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();
    public void SetUp()
    {
        RefreshData();
    }

    public override void RefreshData()
    {
        foreach (var attribute in attributeList)
        {
            attribute.gameObject.SetActive(false);
        }
        string levelFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Level") + ": <color=#30302A>{0}</color>/{1}";
        string hpFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Hp") + ": {0}";
        string atkFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Patk") + ": {0}";

        lvText.SetRawText(string.Format(levelFormat, m_EquipmentViewModel.level, m_EquipmentViewModel.maxLevel));
        
        int index = 1;
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            var value = m_EquipmentViewModel.attributeDict[eAtt] ;
            if (value > 0 )
            {
                if (index < attributeList.Count)
                {
                    attributeList[index].SetupText(eAtt, eAtt.GetAttributePercent(value));
                    attributeList[index].gameObject.SetActive(true);
                }
                else
                {
                    var attribute = Instantiate(prefab, this.attributeTransform, false);
                    attribute.SetupText(eAtt, eAtt.GetAttributePercent(value));
                    attribute.gameObject.SetActive(true);
                    attributeList.Add(attribute);
                }
                index++;
            }
        }
        beforeSkillInfo.gameObject.SetActive(m_EquipmentViewModel.skillId>0);
        if(m_EquipmentViewModel.skillId>0)
            beforeSkillInfo.SetUpData(m_EquipmentViewModel.skillId);
      
    }
}
