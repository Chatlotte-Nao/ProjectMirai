﻿using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using Takasho.Schema.Score.ResourceCn.Equipment.V1;

public class UIHomeEquipmentMainDialog : UIDialogBase
{
     [SerializeField] UIText titleText;
    [Space] [Header("Function Toggles")] 
    [SerializeField] UIToggleGroupController toggles;
    [SerializeField] TabToggle tabGroupDetail;
    [SerializeField] TabToggle tabGroupLevelUp;
    [SerializeField] TabToggle tabGroupStarUp;
    public UIIntEvent OnSelectTab = new UIIntEvent();
    [SerializeField] UIText tabGroupLevelText;
    [SerializeField] UIText tabGroupLevelText2;
    [Space]
    public UIHomeEquipmentMainPageCardDialog DisplayCard;

    [SerializeField] private UIButton backButton;
    public ClickEvent OnCloseClick => backButton.onClick;
    [Space]
    [Header("Function Panels")]
    // public UIHomeEquipmentMainPagePanelBaseDialog DetailPanel;
    // public UIHomeEquipmentLevelUpDialog LevelUpPanel;
    // public UIHomeEquipmentGradeUpDialog GardeUpPanel;
    // public UIHomeEquipmentRankUpDialog RankUpPanel;
    [SerializeField] Image CardIllustBgImage;
    private UIHomeEquipmentMainPagePanelBaseDialog m_CurrentActivePanel = null;
    private PlayerEquipment m_EquipmentServerData = null;
    private EquipmentMaster m_EquipmentStaticData = null;
    private EquipmentViewModel m_EquipmentViewModel = null;

    public UILongEvent OnFullScreenClick = new UILongEvent();

    private long equipmentId;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        tabGroupDetail.onValueChanged.Subscribe((isOn) => { if (isOn) { OnSelectTab.Invoke(1); PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01"); } }).AddTo(mSubscriptions);
        tabGroupLevelUp.onValueChanged.Subscribe((isOn) => { if (isOn) {OnSelectTab.Invoke(2); PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01"); } }).AddTo(mSubscriptions);
        tabGroupStarUp.onValueChanged.Subscribe((isOn) => { if (isOn){ OnSelectTab.Invoke(3); PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01"); } }).AddTo(mSubscriptions);
        DisplayCard.OnClick.Subscribe((_) => {OnFullScreenClick.Invoke(equipmentId); }).AddTo(mSubscriptions);
    }
    
    public override void OnShow()
    {
        base.OnShow();
        
        DisplayCard?.OnShow();
        //ActivePanel(EquipmentMainPagePanelType.Detail);
    }
    public void SetData(EquipmentViewModel equipmentViewModel, PlayerEquipment equipmentServerData = null, EquipmentMaster equipmentStaticData = null)
    {
        m_EquipmentServerData = equipmentServerData;
        m_EquipmentStaticData = equipmentStaticData;
        m_EquipmentViewModel = equipmentViewModel;
        var master = DataManager.Instance.Master.Equipment[equipmentViewModel.id];
        equipmentId = master.id;
        if (!string.IsNullOrEmpty(master.iconId))
        {
            //new 
            AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(master); });
            //CardIllustBgImage.sprite = ResourceManager.Instance.LoadSprite("Equipment/CardIllustBgs", master.iconId);
        }
        
        DisplayCard.SetData(m_EquipmentViewModel);
        if (m_EquipmentViewModel.isMaxLevelAndGrade)
        {
            tabGroupLevelText.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT,"UI_Equip_LevelUp");
            tabGroupLevelText2.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT,"UI_Equip_LevelUp");
        }
        else
        {
            if (m_EquipmentViewModel.isMaxLevel)
            {

                tabGroupLevelText.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT,"UI_Equip_GardUp");
                tabGroupLevelText2.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT,"UI_Equip_GardUp");
            }
            else
            {
                tabGroupLevelText.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT,"UI_Equip_LevelUp");
                tabGroupLevelText2.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT,"UI_Equip_LevelUp");
            }
        }
    }

     public void ActivePanel(EquipmentMainPagePanelType type)
     {
        toggles.reFresh((int)type - 1);
     }
     public void SetTitle(string title)
     {
         titleText.SetRawText(title);
     }

    private async UniTask LoadSpriteAsync(EquipmentMaster master)
    {
        CardIllustBgImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("Equipment/CardIllustBgs", master.iconId);
    }
}
