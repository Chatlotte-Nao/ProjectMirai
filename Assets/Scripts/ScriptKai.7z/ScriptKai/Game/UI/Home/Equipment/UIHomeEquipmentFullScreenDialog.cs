using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using Base.Util;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIHomeEquipmentFullScreenDialog : UIDialogBase
{
    [SerializeField] private Image bgImage;
    [SerializeField] private UIButton button;
    //���´򿪰�ť
    [SerializeField] private UIButton storyOpenButton;
    //���¹رհ�ť
    [SerializeField] private UIButton storyCloseButton;
    //�����ɰ�
    [SerializeField] private GameObject storyMask;
    //��������
    [SerializeField] private UIText story;

    private List<long> equipmentIds = new List<long>();
    //װ��ID
    private long singleEquipmentIds;
    private int index = 0;
    private bool isEquipmentDialog = false;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        button.OnTouchUpInside.GuardSubscribeAsync(OnClickScreen).AddTo(mSubscriptions);
        storyOpenButton.OnTouchUpInside.GuardSubscribeAsync(OnClickStroyOpenButton).AddTo(mSubscriptions);
        storyCloseButton.OnTouchUpInside.GuardSubscribeAsync(OnClickStroyCloseButton).AddTo(mSubscriptions);
    }

    public async UniTask SetUp(long equipmentId)
    {
        bgImage.gameObject.SetActive(false);
        singleEquipmentIds = equipmentId;
        Debug.Log("equipmentId: " + equipmentId);
        isEquipmentDialog = true;
        await SetupEquipment(equipmentId);
    }

    public void SetUp(List<long> content)
   {
      isEquipmentDialog = false;
      equipmentIds = content;
      index = 0;
      AsyncManager.Instance.StartGuardAsync(SetupEquipment(equipmentIds[index]));
   }
   private async UniTask OnClickScreen()
   {
      index++;
      if (index >= equipmentIds.Count)
      {
         if (isEquipmentDialog)
         {
            await this.HideAsync();
         }
         else
         {
            this.Dispose();
         }
      }
      else
      {
         AsyncManager.Instance.StartGuardAsync(SetupEquipment(equipmentIds[index]));
         equipmentIds.Remove(equipmentIds[index]);
      }
   }

    private async UniTask SetupEquipment(long equipmentId)
    {
        var master = DataManager.Instance.Master.Equipment[equipmentId];
        var sprite = await ResourceManager.Instance.LoadSpriteAsync("Equipment/FullScreenBgs", master.iconId);
        bgImage.sprite = sprite;
        bgImage.gameObject.SetActive(true);
        story.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT_NAME, $"{singleEquipmentIds}_story");
        if (story.GetComponent<TextMeshProUGUI>().text == $"{singleEquipmentIds}_story")
        {
            Debug.Log("meigushi");
            storyOpenButton.gameObject.SetActive(false);
        }
    }

    private async UniTask OnClickStroyOpenButton()
    {
        storyMask.SetActive(true);
        storyOpenButton.gameObject.SetActive(false);
        storyCloseButton.gameObject.SetActive(true);
        //story.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT_NAME, $"{singleEquipmentIds}_story");
        Debug.Log("Open Stroy Button");
    }

    private async UniTask OnClickStroyCloseButton()
    {
        storyMask.SetActive(false);
        storyOpenButton.gameObject.SetActive(true);
        storyCloseButton.gameObject.SetActive(false);
        Debug.Log("Close Stroy Button");
    }
}
