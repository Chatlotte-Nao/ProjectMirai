﻿using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeEquipmentMainPageCardDialog : UIDialogBase
{
    public UIBoolEvent OnClickLock = new UIBoolEvent();

    [SerializeField] UIText levelText;
    [SerializeField] RarityIcon rarityIcon;
    [SerializeField] UITexture iconImage;
    [SerializeField] Image frameImage = null;
    [SerializeField] UIText slotText;
    [SerializeField] Image slotIcon;
    [SerializeField] UIText eqipmentName;
    [SerializeField] UIText illustratorName;
    [SerializeField] TabToggle lockToggle;
    [SerializeField] Image rarityImage;
    [SerializeField] private Image rarityBgImage;
    [SerializeField] EquipmentJob equipmentJob;
    [SerializeField] private UIButton button;
    private EquipmentViewModel m_EquipmentViewModel = null;

    public ClickEvent OnClick => button.onClick;
    
    protected override void Awake()
    {
        base.Awake();
        lockToggle.onValueChanged.Subscribe((isOn) => { OnClickLock.Invoke(isOn); }).AddTo(mSubscriptions);
    }

    public void SetData(EquipmentViewModel equipmentViewModel)
    {
        m_EquipmentViewModel = equipmentViewModel;
        Refresh(m_EquipmentViewModel);
    }

    public override void Dispose()
    {
        base.Dispose();
        lockToggle.onValueChanged.RemoveAllListeners();
    }

    public void Refresh(EquipmentViewModel equipmentViewModel)
    {
        m_EquipmentViewModel = equipmentViewModel;
        var master = DataManager.Instance.Master.Equipment[equipmentViewModel.id];

        levelText.SetRawText(equipmentViewModel.level.ToString());
        //rarityIcon.SetRarity(equipmentViewModel.rarity, RarityIcon.RarityType.EQUIPMENT);
        rarityIcon.SetRarity(equipmentViewModel.rank, RarityIcon.RarityType.EQUIPMENT);
        slotText.SetRawText(master.position.ToString());
        eqipmentName.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT_NAME, master.id.ToString());
        var tmp=eqipmentName.GetComponent<TextMeshProUGUI>();
        var str=tmp.text;
        tmp.text= "【"+str + "】";
        illustratorName.SetRawText(master.illustratorName);
        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(master); });
        //slotIcon.sprite = ResourceManager.Instance.LoadSpriteSmall("RarityIcon", $"slot{master.position}");
        //slotIcon.SetNativeSize();

        //rarityImage.sprite = ResourceManager.Instance.LoadSpriteSmall("RarityIcon", $"Rarity_{master.rarity}");
        //rarityBgImage.sprite = ResourceManager.Instance.LoadSpriteSmall("EquipmentNew", $"yuezhuang_frame_part{master.rarity}");
        lockToggle.isOn = equipmentViewModel.locked;
        lockToggle.RefreshGroup();

        iconImage.Load("Equipment/CardIllusts", master.iconId);
        //frameImage.sprite =  ResourceManager.Instance.LoadSpriteSmall("FrameBg", $"frame_equipment_big_{master.rarity}");
        if(equipmentJob!=null)
            equipmentJob.SetUp(master.equipableJobs);
    }

    private async UniTask LoadSpriteAsync(EquipmentMaster master)
    {
        slotIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("RarityIcon", $"slot{master.position}");
        rarityImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("RarityIcon", $"Rarity_{master.rarity}");
        rarityBgImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("EquipmentNew", $"yuezhuang_frame_part{master.rarity}");
        frameImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("FrameBg", $"frame_equipment_big_{master.rarity}");
    }
}
