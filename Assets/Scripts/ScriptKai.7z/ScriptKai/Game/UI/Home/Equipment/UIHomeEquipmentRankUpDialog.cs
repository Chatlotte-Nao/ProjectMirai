﻿using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeEquipmentRankUpDialog : UIHomeEquipmentMainPagePanelBaseDialog
{
    [Space]
    [SerializeField] UIButton beforeSkillBtn;

    [SerializeField] UIText beforeSkillText;
    [SerializeField] private BaseSkillInfo beforeSkillInfo;
    [SerializeField] GameObject skillObj;

    [Space]
    [SerializeField] RarityIcon rarityIconBefore;

    [SerializeField] RarityIcon rarityIconAfter;
    [SerializeField] RarityIcon rarityIconMax;


    [Space]
    [SerializeField] BaseResource costGold;

    [SerializeField] UIButton btnRankUp;
    [SerializeField] Transform costEquipmentAnchor;
    [SerializeField] UIButton btnEmpty;
    [SerializeField] UIButton btnSelectPanelClose;

    [Space]
    [SerializeField] GameObject GroupMax;

    [SerializeField] GameObject GroupNotMax;
    [SerializeField] GameObject GroupSelectEquipmentPanel;
    [SerializeField] GameObject GroupSelectEquipmentPanelShowDetail;

    [Header("Select Panel")]
    [SerializeField] UIButton selectPanel_btnSortOrder;

    [SerializeField] TMPro.TMP_Dropdown selectPanel_sortDropdown;
    [SerializeField] UIButton selectPanel_btnClose;
    [SerializeField] Transform selectPanel_equipmentIconContent;
    [SerializeField] GameObject selectPanel_sortOrder;
    [SerializeField] UIEquipmentPanel selectPanel_detail_equipmentPanel;
    [SerializeField] UIButton selectPanel_detail_btnClose;

    [Space]
    [SerializeField] SelectableEquipment equipmentPrefab;

    [SerializeField] private BaseAttributeUp prefab;
    [SerializeField] private RectTransform attributeTransform;

    [SerializeField] RectTransform equipmentIcon1Position;
    private SkillMaster afterSkillData = null;

    private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();
    private SkillMaster beforeSkillData = null;

    private BaseEquipment costEquipment = null;

    private EquipmentViewModel equipmentPanelShowDetail;

    private bool isAfter = true ;
    private bool isMaxRank = false;
    private List<EquipmentViewModel> m_ListAllEquipmentVMs = new List<EquipmentViewModel>();
    private List<EquipmentViewModel> m_ListDisplay = new List<EquipmentViewModel>();
    private List<SelectableEquipment> m_ListEquipmentIcons = new List<SelectableEquipment>();

    private List<EquipmentViewModel> m_ListSatisfy = new List<EquipmentViewModel>();
    public UIStrEvent OnRankUpClicked = new UIStrEvent();
    private SelectableEquipment selectedEquipment = null;
    private EquipmentViewModel selectedEquipmentVM = null;
    private EquipmentSortOrder sortOrder = EquipmentSortOrder.Decreasing;
    private EquipmentSortType sortType = EquipmentSortType.Rare;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        btnRankUp.OnTouchUpInside.Subscribe(OnClickRankUp).AddTo(mSubscriptions);
        btnEmpty.OnTouchUpInside.Subscribe(OnEmptyClicked).AddTo(mSubscriptions);

        beforeSkillBtn.OnTouchUpInside.Subscribe(OnChangeSkillTab).AddTo(mSubscriptions);

        selectPanel_sortDropdown.onValueChanged.Subscribe(OnSortTypeChanged).AddTo(mSubscriptions);
        selectPanel_btnSortOrder.onClick.Subscribe(OnSortOrderChanged).AddTo(mSubscriptions);
        selectPanel_btnClose.onClick.Subscribe(OnClickPanelClose).AddTo(mSubscriptions);
        selectPanel_detail_btnClose.onClick.Subscribe(OnClickSelectPanelDetailClose).AddTo(mSubscriptions);

        SetupSortDropdown();
    }


    public void LoadData()
    {
        GroupMax.SetActive(false);
        GroupNotMax.SetActive(false);
        GroupSelectEquipmentPanel.SetActive(false);

        sortOrder = EquipmentSortOrder.Decreasing;
        selectPanel_btnSortOrder.transform.localScale = Vector3.one;

        if (costEquipment != null)
        {
            Destroy(costEquipment.gameObject);
            costEquipment = null;
            selectedEquipment = null;
            selectedEquipmentVM = null;
        }

        // string hpFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Hp") + ": {0}<color=\"red\">→{1}";
        // string atkFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Patk") + ": {0}<color=\"red\">→{1}";
        // string hpFormatMax = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Hp") + ": {0}";
        // string atkFormatMax = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Patk") + ": {0}";
        costGold.gameObject.SetActive(false);
        isAfter = true;
        if (!isMaxRank)
        {
            GroupNotMax.SetActive(true);

            EquipmentViewModel nextRankFakeVM = EquipmentUtil.BuildFakeEquipmentViewModelByPointRank(m_EquipmentViewModel, m_EquipmentViewModel.rank + 1);
            // textHp.SetRawText(string.Format(hpFormat, m_EquipmentViewModel.attributeDict[CharacterAttribute.Hp], nextRankFakeVM.attributeDict[CharacterAttribute.Hp]));
            // textAtk.SetRawText(string.Format(atkFormat, m_EquipmentViewModel.attributeDict[CharacterAttribute.PAtk], nextRankFakeVM.attributeDict[CharacterAttribute.PAtk]));
            setAttributeText(false, m_EquipmentViewModel, nextRankFakeVM);
            rarityIconBefore.SetRarity(m_EquipmentViewModel.rank, RarityIcon.RarityType.EQUIPMENT);
            rarityIconAfter.SetRarity(m_EquipmentViewModel.rank + 1, RarityIcon.RarityType.EQUIPMENT);

            OnChangeSkillTab();
        }
        else
        {
            GroupMax.SetActive(true);

            // textHp.SetRawText(string.Format(hpFormatMax, m_EquipmentViewModel.attributeDict[CharacterAttribute.Hp]));
            // textAtk.SetRawText(string.Format(atkFormatMax, m_EquipmentViewModel.attributeDict[CharacterAttribute.PAtk]));
            setAttributeText(true, m_EquipmentViewModel);
            rarityIconMax.SetRarity(m_EquipmentViewModel.rank, RarityIcon.RarityType.EQUIPMENT);

            OnChangeSkillTab();
        }
    }

    public void setAttributeText(bool isMaxRank ,EquipmentViewModel old ,EquipmentViewModel newModel = null)
    {
        string format = "";
        if(!isMaxRank)
            format = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Hp") + ": {0}<color=\"red\">→{1}";
        else
            format = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Hp") + ": {0}";
        

        foreach (var attribute in attributeList)
        {
            attribute.gameObject.SetActive(false);
        }
        int index = 1;
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            var oldValue = old.attributeDict[eAtt];
            var newValue =isMaxRank ?0: newModel.attributeDict[eAtt];
            if (newValue > oldValue)
            {
                if (index < attributeList.Count)
                {
                    attributeList[index].LoadAttributeData(eAtt, eAtt.GetAttributePercent(oldValue), eAtt.GetAttributePercent(newValue));
                    attributeList[index].gameObject.SetActive(true);
                }
                else
                {
                    var attribute = Instantiate(prefab, this.attributeTransform, false);
                    attribute.LoadAttributeData(eAtt, eAtt.GetAttributePercent(oldValue), eAtt.GetAttributePercent(newValue));
                    attribute.gameObject.SetActive(true);
                    attributeList.Add(attribute);
                }
                index++;
            } 
        }

    }

    public override void OnHide()
    {
        base.OnHide();

        if (costEquipment != null)
        {
            costGold.gameObject.SetActive(false);
            Destroy(costEquipment.gameObject);
            costEquipment = null;
        }

        if (selectedEquipment != null)
        {
            selectedEquipment = null;
            selectedEquipmentVM = null;
        }
    }

    public void SetRankUpExtraData(List<EquipmentViewModel> listAllEquipmentVMs)
    {
        m_ListAllEquipmentVMs = listAllEquipmentVMs;
        var res =SetupSatisfiedRankUpEquipmentVMs();
        if (res[0] > 0)
            beforeSkillData = DataManager.Instance.Master.Skill[res[0]];
        if (res[1] > 0)
            afterSkillData = DataManager.Instance.Master.Skill[res[1]];
        LoadData();
    }

    private void RefreshList()
    {
        /*
        if (costEquipment == null)
        {
            m_ListDisplay = m_ListSatisfy;
        }
        else
        */
        {
            m_ListDisplay = new List<EquipmentViewModel>();
            List<EquipmentViewModel> exceptList = new List<EquipmentViewModel>();
            exceptList.Add(m_EquipmentViewModel);

            EquipmentUtil.FilterEquipments(ref m_ListSatisfy, ref exceptList, out m_ListDisplay, EquipmentFilterType.ExcepRankList, false, true,false,true);
        }

        //sort
        List<EquipmentViewModel> temp = new List<EquipmentViewModel>();
        EquipmentUtil.SortEquipments(sortType, sortOrder, ref m_ListDisplay, out temp);
        m_ListDisplay = temp;
        m_ListDisplay = m_ListDisplay.OrderBy(a => a.locked).ToList();
        for (int i = 0; i < m_ListDisplay.Count; i++)
        {
            EquipmentViewModel evm = m_ListDisplay[i];
            SelectableEquipment be = null;

            if (i >= m_ListEquipmentIcons.Count)
            {
                be = GameObject.Instantiate(equipmentPrefab);
                be.transform.parent = selectPanel_equipmentIconContent;
                be.transform.localScale = Vector3.one;
                //be.transform.localPosition = Vector3.zero;
                m_ListEquipmentIcons.Add(be);
            }
            else
            {
                be = m_ListEquipmentIcons[i];
                be.Button.OnTouchUpInside.RemoveAllListeners();
                be.Button.OnLongTouch.RemoveAllListeners();
            }

            be.Button.OnTouchUpInside.Subscribe(() => { OnChangeCostEquipment(be, evm); }).AddTo(mSubscriptions);
            be.Button.OnLongTouch.Subscribe(()=> { OnLongClickEquipment(be, evm); }).AddTo(mSubscriptions);
            be.SetupEquipmentData(evm);
            be.gameObject.SetActive(true);
            //set checked
            if (selectedEquipmentVM != null && string.Equals(selectedEquipmentVM.uniqueId, evm.uniqueId))
            {
                selectedEquipment = be;
                be.Select(true);
            }
        }

        for (int i = m_ListDisplay.Count; i < m_ListEquipmentIcons.Count; i++)
        {
            BaseEquipment icon = m_ListEquipmentIcons[i];
            icon.gameObject.SetActive(false);
        }
    }

    private void OnChangeCostEquipment(SelectableEquipment be, EquipmentViewModel evm)
    {
        if (evm.locked)
        {
            UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_RankUp_Lock"));
            return;
        }

        //GroupSelectEquipmentPanel.SetActive(false);
        if (selectedEquipment != null)
            selectedEquipment.Select(false);

        selectedEquipment = be;
        selectedEquipmentVM = evm;
        selectedEquipment.Select(true);
        PxSoundManager.Instance.PlaySe("feedbackSE_date_select01");

        if (costEquipment == null)
        {
            costEquipment = GameObject.Instantiate(equipmentPrefab);
            costEquipment.transform.SetParent(costEquipmentAnchor);
            
            //costEquipment.transform.localScale = Vector3.one;
            //costEquipment.transform.localPosition = Vector3.zero;
            //costEquipment.GetComponent<RectTransform>().anchoredPosition = Vector3.zero;

            costEquipment.OnClick.AddListener(OnEquipmentClicked);
        }
        // costEquipment.gameObject.SetActive(false);
        costEquipment.SetupEquipmentData(evm);
        costEquipment.transform.localScale = Vector3.one * 1.84f;
        costEquipment.transform.position = equipmentIcon1Position.position;
        // costEquipment.GetComponent<RectTransform>().sizeDelta=Vector2.zero;
        // costEquipment.GetComponent<RectTransform>().anchoredPosition=Vector2.zero;
        SetGlodCost(evm);
    }

    private void SetGlodCost(EquipmentViewModel evm)
    {
        int addRank = evm.rank;
        int totalGoldCost = 0;
        for (int i = 0; i <  evm.rank; i++)
        {
            var rank = m_EquipmentViewModel.rank + i;
            if (rank < 5)
            {
                int goldCost = DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.EquipmentRankUpCost]
                    .data;
                totalGoldCost += Mathf.CeilToInt(goldCost * rank);
            }
        }
        var maxrank = m_EquipmentViewModel.rank + addRank >5? 5: m_EquipmentViewModel.rank + addRank;
        rarityIconAfter.SetRarity(maxrank, RarityIcon.RarityType.EQUIPMENT);
        costGold.SetupMoneyNeed(totalGoldCost);
        costGold.gameObject.SetActive(true);
        EquipmentViewModel nextRankFakeVM = EquipmentUtil.BuildFakeEquipmentViewModelByPointRank(m_EquipmentViewModel, maxrank);
        // textHp.SetRawText(string.Format(hpFormat, m_EquipmentViewModel.attributeDict[CharacterAttribute.Hp], nextRankFakeVM.attributeDict[CharacterAttribute.Hp]));
        // textAtk.SetRawText(string.Format(atkFormat, m_EquipmentViewModel.attributeDict[CharacterAttribute.PAtk], nextRankFakeVM.attributeDict[CharacterAttribute.PAtk]));
        setAttributeText(false, m_EquipmentViewModel, nextRankFakeVM);
    }

    private void OnEmptyClicked()
    {
        GroupSelectEquipmentPanel.SetActive(true);
        GroupSelectEquipmentPanelShowDetail.SetActive(false);

        RefreshList();
    }

    private void OnEquipmentClicked()
    {
        GroupSelectEquipmentPanel.SetActive(true);
        GroupSelectEquipmentPanelShowDetail.SetActive(false);

        RefreshList();
    }

    private void OnChangeSkillTab()
    {
        if(isAfter)
            beforeSkillText.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_After_RankUp");
        else
            beforeSkillText.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Before_RankUp");
        SkillMaster skillStaticData = isAfter ?  afterSkillData : beforeSkillData;
        skillObj.gameObject.SetActive(skillStaticData != null);
        if (skillStaticData != null)
            beforeSkillInfo.SetUpData(skillStaticData.id);
        isAfter = !isAfter;
    }

    private void OnClickRankUp()
    {
        if (selectedEquipment != null)
        {
            if (costGold.IsNeed())
            {
                OnRankUpClicked.Invoke(selectedEquipmentVM.uniqueId);
            }
            else
            {
                UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "CHARACTER_ITEMS_NOT"));
            }
        }
        else
        {
            UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Select_Item"));
        }
    }

    private void OnSortTypeChanged(int i)
    {
        sortType = (EquipmentSortType)i;

        RefreshList();
    }

    private void OnSortOrderChanged(GameObject go)
    {
        sortOrder = sortOrder == EquipmentSortOrder.Decreasing ? EquipmentSortOrder.Increasing : EquipmentSortOrder.Decreasing;

        // switch (sortOrder)
        // {
        //     case EquipmentSortOrder.Decreasing:
        //         //selectPanel_sortOrder.transform.localScale = Vector3.one;
        //         break;
        //     case EquipmentSortOrder.Increasing:
        //         selectPanel_btnSortOrder.transform.localScale = new Vector3(-1, 1, 1);
        //         break;
        //     default:
        //         break;
        // }

        RefreshList();
    }

    private void OnClickPanelClose(GameObject go)
    {
        GroupSelectEquipmentPanel.SetActive(false);
    }

    private void OnLongClickEquipment(BaseEquipment be, EquipmentViewModel evm)
    {
        if (!GroupSelectEquipmentPanelShowDetail.activeSelf)
        {
            GroupSelectEquipmentPanelShowDetail.SetActive(true);
            selectPanel_detail_equipmentPanel.Setup(evm);
            equipmentPanelShowDetail = evm;
        }
    }

    private void OnClickSelectPanelDetailClose(GameObject go)
    {
        GroupSelectEquipmentPanelShowDetail.SetActive(false);
        var data = m_ListEquipmentIcons.First(a => a.itemId == equipmentPanelShowDetail.uniqueId);
        if (equipmentPanelShowDetail.locked)
        {
            if (selectedEquipment != null)
                selectedEquipment.Select(false);
            if (costEquipment != null)
            {
                Destroy(costEquipment.gameObject);
                costEquipment = null;
                selectedEquipment = null;
                selectedEquipmentVM = null;
            }
        }

        if (!data.IsSelected)
        {
            costGold.gameObject.SetActive(false);
            data.SetupEquipmentData(equipmentPanelShowDetail);
        }
    }

    private long[] SetupSatisfiedRankUpEquipmentVMs()
    {
        long[] res = new long[2];

        m_ListSatisfy = new List<EquipmentViewModel>();

        EquipmentRankUpMaster currentRankStaticData = EquipmentUtil.GetRankUpStaticConfig(m_EquipmentViewModel.id, m_EquipmentViewModel.rank);
        EquipmentRankUpMaster nextRankStaticData = EquipmentUtil.GetRankUpStaticConfig(m_EquipmentViewModel.id, m_EquipmentViewModel.rank + 1);

        isMaxRank = nextRankStaticData == null;
        res[0] = currentRankStaticData.skillId;
        res[1] = isMaxRank ? currentRankStaticData.skillId : nextRankStaticData.skillId;

        if (isMaxRank == false)
        {
            //update satisfied list
            List<long> needEquipments = new List<long>();
            foreach (string item in nextRankStaticData.requireContents)
            {
                var s = item.Split(':');
                long id = long.Parse(s[0]);
                needEquipments.Add(id);
            }

            foreach (EquipmentViewModel evm in m_ListAllEquipmentVMs)
            {
                foreach (long id in needEquipments)
                {
                    if (evm.id == id)
                        m_ListSatisfy.Add(evm);
                }
            }
        }

       return res;
    }

    private void SetupSortDropdown()
    {
        selectPanel_sortDropdown.ClearOptions();

        List<string> sortDropdownList = new List<string>();
        sortDropdownList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Rarity"));
        sortDropdownList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Level"));
        sortDropdownList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Rank"));
        selectPanel_sortDropdown.AddOptions(sortDropdownList);

        selectPanel_sortDropdown.onValueChanged.Subscribe(OnSortTypeChanged).AddTo(mSubscriptions);
    }
}
