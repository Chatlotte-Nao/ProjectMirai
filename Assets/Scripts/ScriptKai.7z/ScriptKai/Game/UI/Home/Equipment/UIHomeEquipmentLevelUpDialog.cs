﻿
using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using Takasho.Schema.Score.ResourceCn.Item.V1;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIHomeEquipmentLevelUpDialog : UIHomeEquipmentMainPagePanelBaseDialog
{
    [Space]
    [SerializeField] GameObject groupMax;
    [SerializeField] GameObject groupNotMax;

    [Space]
    [SerializeField] UIText lvText;
    [SerializeField] UIText expText;
    // [SerializeField] UIText[] attributeText;
    // [SerializeField] UIText[] attributeAddText;
    [SerializeField] Slider imageExpBar;
    [SerializeField] Slider imageAddpBar;
    [SerializeField] UIText levelAddText;
    [SerializeField] UIText expAddText;
    [SerializeField] BaseResource costMoney;

    [Space]
    [SerializeField] UIButton btnSortOrder;
    [SerializeField] TMPro.TMP_Dropdown sortDropdown;
    [SerializeField] UIButton btnLevelUp;
    [SerializeField] UIButton btnSelectAll;

    [Space]
    [SerializeField] Transform equipmentIconContent;

    [Space]
    [SerializeField] BaseEquipment equipmentIconPrefab;
    [SerializeField] GameObject GroupSelectEquipmentPanelShowDetail;
    [SerializeField] UIEquipmentPanel selectPanel_detail_equipmentPanel;
    //public UICommonItemInfoDialog commonItemInfoDialog;
    [SerializeField] UIButton selectPanel_detail_btnClose;
    
    [SerializeField] private BaseAttributeUp prefab; 
    [SerializeField] private RectTransform attributeTransform;
    private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();
    public EquipmentItemDataEvent OnLevelUpPageLevelUpClicked = new EquipmentItemDataEvent();

    private List<EquipmentViewModel> m_ListAllEquipmentVMs = new List<EquipmentViewModel>();
    private List<EquipmentViewModel> m_ListAllExceptCurrentEquipment = new List<EquipmentViewModel>();
    //private List<SelectableEquipment> m_ListEquipmentIcons = new List<SelectableEquipment>();
    private Dictionary<string,SelectableEquipment> m_ListEquipmentIcons = new Dictionary<string,SelectableEquipment>();
    //private Dictionary<string,int> m_ListSelectedItems = new Dictionary<string,int>();

    private EquipmentSortOrder sortOrder = EquipmentSortOrder.Decreasing;
    private int sortType = 0;

    private List<EquipmentItemData> _itemDatas = new List<EquipmentItemData>();
    private Dictionary<string,EquipmentItemData> _itemSelectDatas = new Dictionary<string,EquipmentItemData>();
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        btnSortOrder.OnTouchUpInside.Subscribe(OnSortOrderChanged).AddTo(mSubscriptions);
        btnLevelUp.OnTouchUpInside.Subscribe(() =>
        {
            if (costMoney.IsNeed())
            {
                OnLevelUpPageLevelUpClicked.Invoke(_itemSelectDatas.Values.ToList());
            }
            else
            {
                UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "CHARACTER_ITEMS_NOT"));
            }
        }).AddTo(mSubscriptions);
        btnSelectAll.OnTouchUpInside.Subscribe(OnSelectAllClicked).AddTo(mSubscriptions);
        selectPanel_detail_btnClose.onClick.Subscribe(OnClickSelectPanelDetailClose).AddTo(mSubscriptions);
        SetupSortDropdown();
    }


    public void SetLevelUpExtraData(List<EquipmentViewModel> allEquipmentVMs)
    {
        m_ListAllEquipmentVMs = allEquipmentVMs;

        _removeCurrentEquipmentVM();
        LoadData();
        isAllClick = false;
    }

    public void LoadData()
    {
        _itemSelectDatas.Clear();
        RefreshData();
        RefreshList();
        isMaxExp = false;
    }

    public override void OnHide()
    {
        base.OnHide();

        totalAddExp = 0;
        foreach (var item in m_ListEquipmentIcons.Values)
        {
            item.Select(false);
        }
    }

    private EquipmentViewModel equipmentPanelShowDetail;
    private bool isItemInfo = false;
    private bool iscommon = false;
    private async UniTask OnLongClickEquipment(BaseEquipment be, EquipmentItemData data)
    {
        if (!GroupSelectEquipmentPanelShowDetail.activeSelf)
        {
            if (data.type == EquipmentType.Equipment)
            {
                isItemInfo = false;
                //commonItemInfoDialog.gameObject.SetActive(false);
                GroupSelectEquipmentPanelShowDetail.SetActive(true);
                selectPanel_detail_equipmentPanel.gameObject.SetActive(true);
                selectPanel_detail_equipmentPanel.Setup(data.model);
                equipmentPanelShowDetail = data.model;
            }
            else
            {
                isItemInfo = true;
                //commonItemInfoDialog.gameObject.SetActive(true);
                //selectPanel_detail_equipmentPanel.gameObject.SetActive(false);
                //GroupSelectEquipmentPanelShowDetail.SetActive(true);
                if (!iscommon)
                {
                    iscommon = true;
                    var commonItemInfoDialog = await UI.Popup.ShowItemInfoPopupAsync(data.item.ItemMasterId, true);
                    await UniTask.WaitUntil(()=>(commonItemInfoDialog == null));
                    iscommon = false;
                }
            }
        }
    }
    
    private async UniTask showCommonItem(long itemid)
    {
        var commonItemInfoDialog = await UI.Popup.ShowItemInfoPopupAsync(itemid, true);
        await UniTask.WaitUntil(()=>(commonItemInfoDialog == null));
        iscommon = false;
    }


    private void OnClickSelectPanelDetailClose(GameObject go)
    {
        GroupSelectEquipmentPanelShowDetail.SetActive(false);
        if (!isItemInfo && equipmentPanelShowDetail.locked )
        {
            var data = m_ListEquipmentIcons.Values.First(a => a.itemId == equipmentPanelShowDetail.uniqueId);
            data.gameObject.SetActive(false);
            if (_itemSelectDatas.ContainsKey(data.itemId))
            {
                _itemSelectDatas.Remove(data.itemId);
                RefreshSelectd(_itemSelectDatas);
            }
        }
    }
    public override void RefreshData()
    {
        string levelFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Level") + ": <color=#30302A>{0}</color>/{1}";
        //string expFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Exp") + ": {0}/{1}";
        string hpFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Hp") + ": {0}";
        string atkFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Patk") + ": {0}";

        lvText.SetRawText(string.Format(levelFormat, m_EquipmentViewModel.level, m_EquipmentViewModel.maxLevel));
        expText.SetRawText(string.Format(" {0}/{1}", m_EquipmentViewModel.curExp, m_EquipmentViewModel.levelUpExp));
        foreach (var attribute in attributeList)
        {
            attribute.gameObject.SetActive(false);
        }
        int index = 1;
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            var value = m_EquipmentViewModel.attributeDict[eAtt];
            if (value > 0 )
            {
                if (index < attributeList.Count)
                {
                    attributeList[index].SetupText(eAtt,eAtt.GetAttributePercent(value));
                    attributeList[index].gameObject.SetActive(true);
                }
                else
                {
                    var attribute = Instantiate(prefab, this.attributeTransform, false);
                    attribute.SetupText(eAtt,eAtt.GetAttributePercent(value));
                    attribute.gameObject.SetActive(true);
                    attributeList.Add(attribute);
                }
                index++;
            }
        }
        imageExpBar.value = (float)m_EquipmentViewModel.curExp / (float)m_EquipmentViewModel.levelUpExp;
        imageAddpBar.value = 0;
        groupMax.SetActive(false);
        groupNotMax.SetActive(false);
        if (m_EquipmentViewModel.isMaxLevelAndGrade)
        {
            groupMax.SetActive(true);
            imageExpBar.value = 1;
            expText.gameObject.SetActive(false);
        }
        else
        {
            groupNotMax.SetActive(true);
            expText.gameObject.SetActive(true);
        }

        levelAddText.gameObject.SetActive(false);
        expAddText.gameObject.SetActive(false);

        costMoney.SetupMoneyNeed(0);
    }

    public void RefreshList()
    {
        isAllClick = false;
         for (int i = 0; i < _itemDatas.Count; i++)
        {
            SelectableEquipment equipmentIcon = null;
            var data = _itemDatas[i];
            if (m_ListEquipmentIcons.ContainsKey(data.itemId))
            {
                equipmentIcon = m_ListEquipmentIcons[data.itemId];
                if (data.type == EquipmentType.Equipment)
                {
                    equipmentIcon.SetupEquipmentData(data.model); //update equipment icon display
                }
                else
                {
                    equipmentIcon.SetUpItemData(data.item); //update equipment icon display
                }
            }
            else
            {
                equipmentIcon = GameObject.Instantiate(equipmentIconPrefab) as SelectableEquipment;
                equipmentIcon.transform.SetParent(equipmentIconContent);
                m_ListEquipmentIcons.Add(data.itemId,equipmentIcon);
                if (data.type == EquipmentType.Equipment)
                {
                    equipmentIcon.SetupEquipmentData(data.model); //update equipment icon display
                    equipmentIcon.OnClick.Subscribe(() => { OnClickEquipment(data, equipmentIcon); }).AddTo(mSubscriptions);
                    equipmentIcon.Button.onLongClick.SubscribeAsync(async(_) => { await OnLongClickEquipment(equipmentIcon, data); })
                        .AddTo(mSubscriptions);
                }
                else
                {
                    equipmentIcon.SetUpItemData(data.item); //update equipment icon display
                    equipmentIcon.OnClick.Subscribe(() => { OnItemSelectedAdd(data,equipmentIcon); }).AddTo(mSubscriptions);
                    equipmentIcon.OnRemoveClick.Subscribe(() => { OnItemSelectedRemove(data, equipmentIcon); }).AddTo(mSubscriptions);
                    equipmentIcon.Button.onLongClick.SubscribeAsync(async(_) => { await OnLongClickEquipment(equipmentIcon, data); })
                        .AddTo(mSubscriptions);
                }
            }
            equipmentIcon.transform.SetAsLastSibling();
            // if (i >= m_ListEquipmentIcons.Count)
            // {
            //     equipmentIcon = GameObject.Instantiate(equipmentIconPrefab) as SelectableEquipment;
            //     m_ListEquipmentIcons.Add(equipmentIcon);
            // }
            // else
            // {
            //     equipmentIcon = m_ListEquipmentIcons[i];
            //     equipmentIcon.OnClick.RemoveAllListeners();
            //     equipmentIcon.OnRemoveClick.RemoveAllListeners();
            //     equipmentIcon.Button.OnLongTouch.RemoveAllListeners();
            // }
            //
            // equipmentIcon.transform.SetParent(equipmentIconContent);
            // if (data.type == EquipmentType.Equipment)
            // {
            //     equipmentIcon.SetupEquipmentData(data.model); //update equipment icon display
            //     equipmentIcon.OnClick.Subscribe(() => { OnClickEquipment(data, equipmentIcon); }).AddTo(mSubscriptions);
            //     equipmentIcon.Button.OnLongTouch.Subscribe(() => { OnLongClickEquipment(equipmentIcon, data); })
            //         .AddTo(mSubscriptions);
            // }
            // else
            // {
            //     equipmentIcon.transform.SetParent(equipmentIconContent);
            //     equipmentIcon.SetUpItemData(data.item); //update equipment icon display
            //     equipmentIcon.OnClick.Subscribe(() => { OnItemSelectedAdd(data,equipmentIcon); }).AddTo(mSubscriptions);
            //     equipmentIcon.OnRemoveClick.Subscribe(() => { OnItemSelectedRemove(data, equipmentIcon); }).AddTo(mSubscriptions);
            //     equipmentIcon.Button.OnLongTouch.Subscribe(() => { OnLongClickEquipment(equipmentIcon, data); })
            //         .AddTo(mSubscriptions);
            // }
        }

         foreach (var icon in m_ListEquipmentIcons)
         {
             var item = _itemDatas.FirstOrDefault(a => a.itemId == icon.Key);
             if (item == null)
             {
                 icon.Value.gameObject.SetActive(false);
             }
         }
    }

    private long totalAddExp;
    public void RefreshSelectd(Dictionary<string,EquipmentItemData> selectedEquipments)
    {
        totalAddExp = 0;
        long allLevelUpExp = EquipmentUtil.GetGradeUpAllExp(m_EquipmentViewModel);
        foreach (var data in selectedEquipments)
        {
            if (data.Value.type == EquipmentType.PlayerItem)
            {
                totalAddExp += DataManager.Instance.Master.Item[long.Parse(data.Key)].exp * data.Value.selectCount;
            }
            else
            {
                EquipmentViewModel evm = m_ListAllExceptCurrentEquipment.Find((EquipmentViewModel e) => string.Equals(e.uniqueId, data.Key));
                totalAddExp += (evm.totalExp + evm.baseSupplyExp);
            }
        }
        isMaxExp = (totalAddExp >= allLevelUpExp);
        //calculate level and exp
        if (totalAddExp > 0)
        {
            long[] res = EquipmentUtil.CalculateLevelByExp(m_EquipmentViewModel, totalAddExp, false);
            int newlevel = (int) res[0];
            long levelUpExp = res[1];
            long curExp = res[2];

            //exp
            expAddText.gameObject.SetActive(true);
            expAddText.SetRawText("+" + totalAddExp);
            if (totalAddExp >= EquipmentUtil.CalculateLevelMaxExp(m_EquipmentViewModel))
            {
                expAddText.SetRawText("+" + EquipmentUtil.CalculateLevelMaxExp(m_EquipmentViewModel));
            }

            //imageExpBar.value = (float) (m_EquipmentViewModel.curExp + totalAddExp) /  (float) m_EquipmentViewModel.levelUpExp;
            imageAddpBar.value = (float) (m_EquipmentViewModel.curExp + totalAddExp) /  (float) m_EquipmentViewModel.levelUpExp;
            //level
            levelAddText.gameObject.SetActive(false);
            if (newlevel != m_EquipmentViewModel.level)
            {
                levelAddText.gameObject.SetActive(true);
                levelAddText.SetRawText( "+" +(newlevel - m_EquipmentViewModel.level).ToString());
            }

            //money
            int goldCost = DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.EquipmentLevelUpCost]
                .data;
            int totalGoldCost = Mathf.CeilToInt(goldCost * totalAddExp / 100);
            costMoney.SetupMoneyNeed(totalGoldCost);

            if (newlevel != m_EquipmentViewModel.level)
            {
             
                foreach (var attribute in attributeList)
                {
                    attribute.gameObject.SetActive(false);
                }
                EquipmentViewModel EVM = EquipmentUtil.BuildFakeEquipmentViewModelByPointLevel(m_EquipmentViewModel, newlevel);
                int index = 1;
                for (int i = 1; i < (int)CharacterAttribute.Max; i++)
                {
                    CharacterAttribute eAtt = (CharacterAttribute)i;
                    var oldValue = m_EquipmentViewModel.attributeDict[eAtt];
                    var newValue = EVM.attributeDict[eAtt];
                    if (oldValue > 0 )
                    {
                        if (index < attributeList.Count)
                        {
                            if(newValue == oldValue)
                                attributeList[index].SetupText(eAtt,eAtt.GetAttributePercent(oldValue));
                            else
                                attributeList[index].LoadAttributeData(eAtt, eAtt.GetAttributePercent(oldValue), eAtt.GetAttributePercent(newValue));
                            attributeList[index].gameObject.SetActive(true);
                        }
                        else
                        {
                            var attribute = Instantiate(prefab, this.attributeTransform, false);
                            if(newValue == oldValue)
                                attribute.SetupText(eAtt,eAtt.GetAttributePercent(oldValue));
                            else
                                attribute.LoadAttributeData(eAtt, eAtt.GetAttributePercent(oldValue), eAtt.GetAttributePercent(newValue));
                            attribute.gameObject.SetActive(true);
                            attributeList.Add(attribute);
                        }
                        index++;
                    }
                }
            }
        }
        else
        {
            levelAddText.gameObject.SetActive(false);
            expAddText.gameObject.SetActive(false);
            costMoney.SetupMoneyNeed(0);
            imageExpBar.value = (float)m_EquipmentViewModel.curExp / (float)m_EquipmentViewModel.levelUpExp;
            imageAddpBar.value = 0;
            RefreshData();
        }
    }

    private bool isMaxExp = false;
    private void OnItemSelected(EquipmentItemData data,SelectableEquipment icon)
    {
        isAllClick = false;
        if (_itemSelectDatas.ContainsKey(data.itemId))
        {
            _itemSelectDatas.Remove(data.itemId);
            _setEquipmentVMSelected(icon, false,0);
            RefreshSelectd(_itemSelectDatas);
            PxSoundManager.Instance.PlaySe("feedbackSE_date_cancel01");
        }
        else
        {
            var allGradeUpExp = EquipmentUtil.GetGradeUpAllExp(m_EquipmentViewModel);
            EquipmentViewModel evm = m_ListAllExceptCurrentEquipment.Find((e) => string.Equals(e.uniqueId, data.model.uniqueId));
            var totalExp = totalAddExp + (evm.totalExp + evm.baseSupplyExp);
            if (allGradeUpExp < totalExp )
            {
                if (isMaxExp)
                {
                    UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Exp_Max"));
                    return;
                }

                var _hintText = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "Confirm_Enhance_Grade");
                UI.Popup.ShowConfirm(string.Empty, _hintText, CanvasType.App0, async (r) => {
                    if (r == UIPopupDialog.Result.OK)
                    {
                        _itemSelectDatas.Add(data.itemId,data);
                        _setEquipmentVMSelected(icon, true,0);
                        RefreshSelectd(_itemSelectDatas);
                        isMaxExp = true;
                    }
                });
            }
            else
            {
                _itemSelectDatas.Add(data.itemId,data);
                _setEquipmentVMSelected(icon, true,0);
                RefreshSelectd(_itemSelectDatas);
                PxSoundManager.Instance.PlaySe("feedbackSE_date_select01");
            }
        }

    }
    private void OnItemSelectedRemove(EquipmentItemData data,SelectableEquipment icon)
    {
        if (_itemSelectDatas.ContainsKey(data.itemId))
        {
            isAllClick = false;
            if ( _itemSelectDatas[data.itemId].selectCount <= 1)
            {
                _setEquipmentVMSelected(icon, false, 0);
                _itemSelectDatas[data.itemId].selectCount = 0;
                _itemSelectDatas.Remove(data.itemId);
                RefreshSelectd(_itemSelectDatas);

            }
            else
            {
                _itemSelectDatas[data.itemId].selectCount = _itemSelectDatas[data.itemId].selectCount - 1;
                _setEquipmentVMSelected(icon, true ,  _itemSelectDatas[data.itemId].selectCount);
                RefreshSelectd(_itemSelectDatas);

            }
            PxSoundManager.Instance.PlaySe("feedbackSE_date_cancel01");
        }
    }
    
    private void OnItemSelectedAdd(EquipmentItemData data,SelectableEquipment icon)
    {
        isAllClick = false;
        var allGradeUpExp = EquipmentUtil.GetGradeUpAllExp(m_EquipmentViewModel);
        var totalExp = totalAddExp + DataManager.Instance.Master.Item[long.Parse(data.itemId)].exp ;
        if (allGradeUpExp < totalExp)
        {
            if (isMaxExp)
            {
                UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT,
                    "UI_Exp_Max"));
                return;
            }

            var _hintText = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "Confirm_Enhance_Grade");
            UI.Popup.ShowConfirm(string.Empty, _hintText, CanvasType.App0, async (r) =>
            {
                if (r == UIPopupDialog.Result.OK )
                {
                    OnSelectAddItem(data, icon);
                    isMaxExp = true;
                }
            });
        }
        else
        {
            OnSelectAddItem(data, icon);
            PxSoundManager.Instance.PlaySe("feedbackSE_date_select01");
        }
    }

    private void OnSelectAddItem(EquipmentItemData data,SelectableEquipment icon)
    {
        if (_itemSelectDatas.ContainsKey(data.itemId) )
        {
            if (_itemSelectDatas[data.itemId].selectCount < _itemSelectDatas[data.itemId].item.Count)
            {
                _itemSelectDatas[data.itemId].selectCount = _itemSelectDatas[data.itemId].selectCount + 1;
                _setEquipmentVMSelected(icon, true, _itemSelectDatas[data.itemId].selectCount);
                RefreshSelectd(_itemSelectDatas);
            }
        }
        else
        {
            _itemSelectDatas.Add(data.itemId, data);
            _itemSelectDatas[data.itemId].selectCount = 1;
            _setEquipmentVMSelected(icon, true, 1);
            RefreshSelectd(_itemSelectDatas);
        }
    }

    private bool isAllClick = false;
    private void OnSelectAllClicked()
    {
        if (isAllClick)
            return;
        isAllClick = true;
        sortOrder = EquipmentSortOrder.Increasing;
        OnSortOrderChanged();
        _itemSelectDatas.Clear();
        totalAddExp = 0;
        var allGradeUpExp = EquipmentUtil.GetGradeUpAllExp(m_EquipmentViewModel);
        var listEquipmentIcons = m_ListEquipmentIcons.Values.Where(a => a.gameObject.activeSelf == true).ToArray();
        foreach (var item in listEquipmentIcons )
        {
            
            var data = _itemDatas.First(a => a.itemId == item.itemId);
            if (data.type == EquipmentType.PlayerItem)
            {
                for (int i = 0; i < data.item.Count; i++)
                {
                    totalAddExp += DataManager.Instance.Master.Item[long.Parse(data.itemId)].exp;
                    data.selectCount = i + 1;
                    if (allGradeUpExp < totalAddExp)
                    {
                        break;
                    }
                }
                 
            }
            else
            {
                if(data.model.rarity >  (int) EquipmentRarity.R ||data.model.grade>1|| data.model.rank>1 )
                    continue;
                EquipmentViewModel evm = m_ListAllExceptCurrentEquipment.Find((e) => string.Equals(e.uniqueId, item.itemId));
                totalAddExp += (evm.totalExp + evm.baseSupplyExp);
            }

            _itemSelectDatas.Add(item.itemId, data);
            _setEquipmentVMSelected(item, true,data.selectCount);

            if (allGradeUpExp < totalAddExp)
                break;
        }
        RefreshSelectd(_itemSelectDatas);
    }

    private void OnClickEquipment(EquipmentItemData itemDate,SelectableEquipment icon)
    {
        // notice to manager
        OnItemSelected(itemDate,icon);
    }

    private void OnSortOrderChanged()
    {
        sortOrder = sortOrder == EquipmentSortOrder.Decreasing ? EquipmentSortOrder.Increasing : EquipmentSortOrder.Decreasing;

        _removeCurrentEquipmentVM();
        RefreshList();
        RefreshData();
        totalAddExp = 0;
        isMaxExp = false;
        SortOrderChange(sortOrder);
    }

    private void OnSortTypeChanged(int i)
    {
        sortType = i;

        _removeCurrentEquipmentVM();
        RefreshData();
        totalAddExp = 0;
        RefreshList();
    }

    public void SortOrderChange(EquipmentSortOrder order)
    {
        switch (order)
        {
            case EquipmentSortOrder.Decreasing:
                btnSortOrder.transform.localScale = Vector3.one;
                break;
            case EquipmentSortOrder.Increasing:
                btnSortOrder.transform.localScale = new Vector3(-1, 1, 1);
                break;
            default:
                break;
        }
    }

    private void SetupSortDropdown()
    {
        sortDropdown.ClearOptions();

        List<string> sortDropdownList = new List<string>();
        sortDropdownList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Level"));
        sortDropdownList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Rank"));
        sortDropdownList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Rarity"));

        sortDropdown.AddOptions(sortDropdownList);
        sortDropdown.onValueChanged.Subscribe((select) => OnSortTypeChanged(select)).AddTo(mSubscriptions);
    }
    
    private void _setEquipmentVMSelected(SelectableEquipment item, bool b,long num)
    {
        if (num > 0)
            item.Select(b,num);
        else
            item.Select(b);
    }

    private void _removeCurrentEquipmentVM()
    {
        //filter
        List<EquipmentViewModel> exceptEuipments = new List<EquipmentViewModel>();
        exceptEuipments.Add(m_EquipmentViewModel);
        m_ListAllExceptCurrentEquipment = new List<EquipmentViewModel>();
        EquipmentUtil.FilterEquipments(ref m_ListAllEquipmentVMs, ref exceptEuipments, out m_ListAllExceptCurrentEquipment, EquipmentFilterType.ExceptLevelList, true, true,true,true);

        //sort
        //List<EquipmentViewModel> res = new List<EquipmentViewModel>();
        //EquipmentUtil.SortEquipments(sortType, sortOrder, ref m_ListAllExceptCurrentEquipment, out res);
        //m_ListAllExceptCurrentEquipment = res;
        m_ListAllExceptCurrentEquipment = SortSelectList(m_ListAllExceptCurrentEquipment);
        _itemSelectDatas.Clear();
        _itemDatas.Clear();
        var equipmentItems = DataManager.Instance.Player.Item.GetList()
            .Where(a => DataManager.Instance.Master.Item[a.ItemMasterId].contentType == 117 && a.Count>0).ToArray();
        foreach (var item in equipmentItems)
        {
            var data = new EquipmentItemData();
            data.itemId = item.ItemMasterId.ToString();
            data.selectCount = 0;
            data.type = EquipmentType.PlayerItem;
            data.item = item;
            _itemDatas.Add(data);
        }
        foreach (var model in m_ListAllExceptCurrentEquipment)
        {
            var data = new EquipmentItemData();
            data.itemId = model.uniqueId;
            data.selectCount = 0;
            data.type = EquipmentType.Equipment;
            data.model = model;
            _itemDatas.Add(data);
        }
    }
    private List<EquipmentViewModel> SortSelectList( List<EquipmentViewModel> models)
    {
        var objList = models;

        switch (sortType)
        { 
            case 0:
                objList = objList.OrderBy(a => a.level).ThenBy(a => a.rank)
                    .ThenBy(a => DataManager.Instance.Master.Equipment[a.id].rarity).ThenBy(a => a.sortId).ToList();
                break;
            case 1:
                objList = objList.OrderBy(a => a.rank).ThenBy(a => a.level).ThenBy(a => DataManager.Instance.Master.Equipment[a.id].rarity)
                    .ThenBy(a => a.sortId).ToList();
                break;
            case 2:
                objList = objList.OrderBy(a => DataManager.Instance.Master.Equipment[a.id].rarity)
                    .ThenBy(a => a.level).ThenBy(a => a.rank).ThenBy(a => a.sortId).ToList();
                break;
        }
        if (sortOrder == EquipmentSortOrder.Increasing) objList.Reverse();
        return objList;
    }
}

public class EquipmentItemDataEvent : UnityEvent<List<EquipmentItemData>>
{
}
public class EquipmentItemData
{
    public string itemId;
    public int selectCount;
    public EquipmentType type;
    public EquipmentViewModel model;
    public PlayerItem item;
}
public enum EquipmentType
{
    Equipment = 1,
    PlayerItem = 2,
}
