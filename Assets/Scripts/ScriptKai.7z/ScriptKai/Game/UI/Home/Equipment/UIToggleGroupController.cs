﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class UIToggleGroupController : MonoBehaviour {

    [SerializeField] Toggle[] toggles_;
    
    public void reFresh(int index) {
        if (index < 0 || index > toggles_.Length)
        {
            return;
        } 
        else {
            for (int i = 0, n = toggles_.Length; i < n; i++) {
                if (i == index) {
                    if(! toggles_[i].isOn){
                        toggles_[i].isOn = true;
                    }               
                } else {
                    if(toggles_[i].isOn){
                        toggles_[i].isOn = false;
                    }                
                }
            }              
        }
    }
	
}