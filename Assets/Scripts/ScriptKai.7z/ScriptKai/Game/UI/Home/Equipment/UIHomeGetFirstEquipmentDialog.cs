using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using Base.Util;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIHomeGetFirstEquipmentDialog : UIDialogBase
{
    [SerializeField] UIText eqipmentName;
    [SerializeField] Image positionIcon;
    [SerializeField] Image rarityImage;
    [SerializeField] Image positionBgImage;
    [SerializeField] Image frameImage;
    [SerializeField] UITexture cardImage;
    [SerializeField] UIButton screenButton;
    [SerializeField] UIButton fullScreenButton;
    [SerializeField] UITexture titleTexture;
    [SerializeField] EquipmentJob equipmentJob;

    public ClickEvent Close = new ClickEvent();
    private long currentEquipmentId;

    private List<long> equipmentIds = new List<long>();

    private UIHomeEquipmentFullScreenDialog fullScreen = null;
    private int index = 0;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        titleTexture.Load("Font", "ty_font_hdyz_01", true);
        fullScreen = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeEquipmentFullScreenDialog, CanvasType.App2) as UIHomeEquipmentFullScreenDialog;
        screenButton.OnTouchUpInside.GuardSubscribeAsync(OnClickScreen).AddTo(mSubscriptions);
        fullScreenButton.OnTouchUpInside.GuardSubscribeAsync(OnShowFullScreen).AddTo(mSubscriptions);
        cardImage.gameObject.SetActive(false);
    }

    public async UniTask SetUp(List<long> content)
    {
        equipmentIds = content;
        index = 0;
        await SetupEquipment(equipmentIds[index]);
    }

    private async UniTask SetupEquipment(long equipmentId)
    {
        currentEquipmentId = equipmentId;
        var master = DataManager.Instance.Master.Equipment[equipmentId];
        eqipmentName.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT_NAME, master.id.ToString());
        positionIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("RarityIcon", $"slot{master.position}");
        rarityImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("RarityIcon", $"Rarity_{master.rarity}");
        positionBgImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("EquipmentNew", $"yuezhuang_frame_part{master.rarity}");
        frameImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("FrameBg", $"frame_equipment_big_{master.rarity}");
        cardImage.Load("Equipment/CardIllusts", master.iconId);
        if (equipmentJob != null)
        {
            equipmentJob.SetUp(master.equipableJobs);
        }
        cardImage.gameObject.SetActive(true);
    }

    private async UniTask OnClickScreen()
    {
        index++;
        if (index >= equipmentIds.Count)
        {
            DataManager.Instance.Player.Equipment.firstEquipmentIds.Clear();
            fullScreen.Dispose();
            Dispose();
            Close?.Invoke(null);
        }
        else
        {
            AsyncManager.Instance.StartGuardAsync(SetupEquipment(equipmentIds[index]));
            equipmentIds.Remove(equipmentIds[index]);
        }
    }

    private async UniTask OnShowFullScreen()
    {
        Debug.Log("OnShowFullScreen");
        await fullScreen.SetUp(currentEquipmentId);
        await fullScreen.ShowAsync();
    }
}
