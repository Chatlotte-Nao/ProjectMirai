﻿using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeEquipmentGradeUpSuccessDialog : UIDialogBase
{
    [Space]
    //[SerializeField] UIText textMaxLevel;
    //[SerializeField] UIText textHp;
    //[SerializeField] UIText textAtk;
    [SerializeField] GameObject attributeBarPrefab;
    [SerializeField] Transform content;
    [SerializeField] List<GameObject> contentList = new List<GameObject>();
    [SerializeField] GameObject levelBar;
    [SerializeField] UIButton btnClose;
    [SerializeField] private UITexture titleTexture;
    [SerializeField] protected Animation mAnimation;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        base.SetAnimation(mAnimation);
        titleTexture.Load("Font", "ty_font_jjcg_01", true);
        btnClose.onClick.GuardSubscribeAsync(onClickClose).AddTo(mSubscriptions);
    }

    public void SetData(EquipmentViewModel evm)
    {
        string levelFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_MaxLevel");
        string hpFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Hp") + ": {0}<color=\"red\">→{1}";
        string atkFormat = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Patk") + ": {0}<color=\"red\">→{1}";

        EquipmentViewModel fakePreviousGardeEVM = EquipmentUtil.BuildFakeEquipmentViewModelByPointGrade(evm, evm.grade - 1);
        var levelTextlst = levelBar.GetComponentsInChildren<UIText>();

        levelTextlst[0].SetRawText(levelFormat);
        levelTextlst[1].SetRawText(fakePreviousGardeEVM.maxLevel.ToString());
        levelTextlst[2].SetRawText(evm.maxLevel.ToString());
        //levelText.GetComponentInChildren<UIText>().SetRawText(string.Format(levelFormat, fakePreviousGardeEVM.maxLevel, evm.maxLevel));
        //textMaxLevel.SetRawText(string.Format(levelFormat, fakePreviousGardeEVM.maxLevel, evm.maxLevel));
        //textHp.SetRawText(string.Format(hpFormat, fakePreviousGardeEVM.attributeDict[CharacterAttribute.Hp], evm.attributeDict[CharacterAttribute.Hp]));
        //textAtk.SetRawText(string.Format(atkFormat, fakePreviousGardeEVM.attributeDict[CharacterAttribute.PAtk], evm.attributeDict[CharacterAttribute.PAtk]));
        StringBuilder sb = new StringBuilder();
        sb.Clear();
        //StringBuilder sb2 = new StringBuilder();
        int index = 1;
        foreach (var item in contentList)
        {
            item.gameObject.SetActive(false);
        }
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            var oldValue = fakePreviousGardeEVM.attributeDict[eAtt];
            var newValue = evm.attributeDict[eAtt] ;
            if (newValue > oldValue )
            {
                sb.AppendFormat(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, $"Attribute_{eAtt}"));
                //sb.AppendLine();
               
                if(index - 1 < contentList.Count)
                {
                    contentList[index - 1].SetActive(true);
                    var textLst = contentList[index - 1].GetComponentsInChildren<UIText>();
                    textLst[0].SetRawText(sb.ToString());
                    textLst[1].SetRawText(eAtt.GetAttributePercent(oldValue));
                    textLst[2].SetRawText(eAtt.GetAttributePercent(newValue));
                
                        
                    sb.Clear();

                }
                else
                {
                    GameObject go = Instantiate(attributeBarPrefab, content);
                    go.SetActive(true);
                    contentList.Add(go);
                    var list = go.GetComponentsInChildren<UIText>();

                    list[0].SetRawText(sb.ToString());
                    list[1].SetRawText(eAtt.GetAttributePercent(oldValue));
                    list[2].SetRawText(eAtt.GetAttributePercent(newValue));
                   
                       
                    sb.Clear();

                }
                index++;
            }
        }

       // textHp.SetRawText(sb.ToString());
    }
}
