using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Underground.V1;
using UnityEngine;

public class UIUndergroundRewardDialog : UIDialogBase
{

    [SerializeField] private UIUndergroundRewardCell cellPrefab;
    [SerializeField] private RectTransform cellContent;

    private List<UIUndergroundRewardCell> cellList = new List<UIUndergroundRewardCell>();
    
    public UIIntEvent OnReceive = new UIIntEvent();
    private long _sectionId;
    private async UniTask Receive(int eventId)
    {
        var player = DataManager.Instance.Player.underground.TryEventGet(eventId);
        if (player == null || player.Status == EventStatus.InvalidEventStatus)
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.UNDERGROUND,"Event_No_CanReceive"));
            return;
        }
        var reward = await UndergroundService.UndergroundClaimEvent(eventId);
        await UI.Popup.ShowItemGetPopupAsync(reward);
        await SetUpAsync(_sectionId);
    }

    public async UniTask SetUpAsync(long SectionId)
    {
        _sectionId = SectionId;
        var masters = DataManager.Instance.Master.UndergroundEventMaster
            .Where(a => a.Value.undergroundSectionMasterId == SectionId && a.Value.show);
        foreach (var cell in cellList)
        {
            cell.gameObject.SetActive(false);
            cell.OnReceive.RemoveAllListeners();
        }

        int index = 0;
        foreach (var master in masters)
        {
            if (index < cellList.Count)
            {
                await cellList[index].SetUpAsync(master.Value);
                cellList[index].OnReceive.SubscribeAsync(async (_) => {await Receive(master.Key); }).AddTo(mSubscriptions);
                cellList[index].gameObject.SetActive(true);
            }
            else
            {
                var cell = Instantiate(cellPrefab, cellContent);
                await cell.SetUpAsync(master.Value);
                cell.OnReceive.SubscribeAsync(async (_) => { await Receive(master.Key); }).AddTo(mSubscriptions);
                cellList.Add(cell);
                cell.gameObject.SetActive(true);
            }

            index++;
        }
    }
}

