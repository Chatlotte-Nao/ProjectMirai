using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Underground.V1;
using UnityEngine;
using UnityEngine.UI;

public class UIUndergroundMainCell : MonoBehaviour
{
    public enum LockState
    {
        Lock,
        unLock,
        complete,
    }

    [SerializeField] private UIText nameTxt;
    [SerializeField] private GameObject redObj;

    [SerializeField] private GameObject dataObj;
    [SerializeField] private Slider completeSlider;

    [SerializeField] private UIText sliderTxt;
    //[SerializeField] private UIButton openBtn;

    [SerializeField] private GameObject lockObj;
    [SerializeField] private UIText lockConditionTxt;
    [SerializeField] private UIButton button;

    [SerializeField] private GameObject unLockObj;

    // public ClickEvent OnOpen => openBtn.onClick;
    // public ClickEvent OnUnLock => unLockBtn.onClick;
    private LockState _lockState;
    private UndergroundChapterMaster _master;

    private PlayerUndergroundChapter _playerUndergroundChapter;

    //[SerializeField] private UIButton unLockBtn;
    // //TODO 临时加的已通关
    // [SerializeField] private GameObject clearObj;
    public ClickEvent OnClick => button.onClick;

    public async UniTask SetUpAsync(UndergroundChapterMaster master)
    {
        _master = master;
        nameTxt.SetLabel(LocalizeManager.DATA_TYPE.UNDERGROUND,$"Chapter_Title_{master.id}");
        _playerUndergroundChapter = DataManager.Instance.Player.underground.TryGet(master.id);
        if (_playerUndergroundChapter != null)
        {
            switch (_playerUndergroundChapter.Status)
            {
                case ChapterStatus.InvalidChapterStatus:
                    _lockState = LockState.Lock;
                    await loadLockData();
                    break;
                case ChapterStatus.ChapterUnlocked:
                    _lockState = LockState.unLock;
                    await loadUnlock();
                    break;
                case ChapterStatus.ChapterStarted:
                    _lockState = LockState.complete;
                    await loadCompleteData();
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
        else
        {
            _lockState = LockState.Lock;
            await loadLockData();
        }
        SetObjectAvtive(_lockState);
    }

    private async UniTask loadCompleteData()
    {
        var progress =
            DataManager.Instance.Player.underground.TryChapterProgresGet(_playerUndergroundChapter
                .UndergroundChapterMasterId);
        nameTxt.SetColor(Color.white);
        completeSlider.value = progress*0.01f;
        sliderTxt.SetFormat(LocalizeManager.DATA_TYPE.UNDERGROUND,"Slider_Text",progress);
    }

    private  async UniTask loadLockData()
    {
        nameTxt.SetColor(Color.white);
        UndergroundUtil.IsLock(_master.unlockCondition,out var Str);
        lockConditionTxt.SetRawText(Str);
    }

    private async UniTask loadUnlock()
    {
        nameTxt.SetColor(Color.black);
    }

    private void SetObjectAvtive(LockState state)
    {
        dataObj.SetActive(state == LockState.complete);
        lockObj.SetActive(state == LockState.Lock);
        unLockObj.SetActive(state == LockState.unLock);
    }
}
