using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;

public class UIUndergroundMainDialog : UIDialogBase
{

    [SerializeField] private UIUndergroundMainCell cellPrefab;
    [SerializeField] private RectTransform cellContent;
    
    [SerializeField] private UIText selectText;
    [SerializeField] private UIText rejectText;

    [SerializeField] private UIButtonWithNew selectButton;
    [SerializeField] private UIButton scenarioButton;
    
    public ClickEvent OnClickScenario => scenarioButton.onClick;
    public ClickEvent OnClickSelect => selectButton.onClick;
    private List<UIUndergroundMainCell> cellList = new List<UIUndergroundMainCell>();

    private UndergroundLevelType _undergroundLevelType;

    public UILongEvent OnClick = new UILongEvent();
    // public UILongEvent OnUnClickLock = new UILongEvent();
    // public UILongEvent OnOpenDetails = new UILongEvent();
    private string normal = "FREEBATTLE_NORMAL";
    private string hard = "FREEBATTLE_HARD";
    public async UniTask SetUpAsync(UndergroundLevelType type)
    {
        _undergroundLevelType = type;
        selectButton.SetNewFlag(type == UndergroundLevelType.Normal? UINewType.UnderGroundHard:UINewType.UnderGroundNomal);
        selectText.SetLabel(LocalizeManager.DATA_TYPE.COMMON,type == UndergroundLevelType.Normal?normal:hard);
        rejectText.SetLabel(LocalizeManager.DATA_TYPE.COMMON,type == UndergroundLevelType.Hard?normal:hard);
        await loadCells();
    }

    public async UniTask loadCells()
    {
        var masters = DataManager.Instance.Master.UndergroundChapterMaster
            .Where(a => a.Value.undergroundLevelMasterId == (int) _undergroundLevelType);
        foreach (var cell in cellList)
        {
            cell.gameObject.SetActive(false);
            // cell.OnUnLock.RemoveAllListeners();
            // cell.OnOpen.RemoveAllListeners();
            cell.OnClick.RemoveAllListeners();
        }
        int index = 0;
        foreach (var master in masters)
        {
            if (index < cellList.Count)
            {
                cellList[index].GetComponent<RectTransform>().anchoredPosition = master.Value.getPostion();
                await cellList[index].SetUpAsync(master.Value);
                cellList[index].OnClick.SubscribeAsync(async (_) => { OnClick.Invoke(master.Key); })
                    .AddTo(mSubscriptions);
                // cellList[index].OnOpen.SubscribeAsync(async (_) => { OnOpenDetails.Invoke(master.Key); })
                //     .AddTo(mSubscriptions);
                cellList[index].gameObject.SetActive(true);
            }
            else
            {
                var cell = Instantiate(cellPrefab, cellContent);
                cell.GetComponent<RectTransform>().anchoredPosition = master.Value.getPostion();
                cell.OnClick.SubscribeAsync(async (_) => { OnClick.Invoke(master.Key); }).AddTo(mSubscriptions);
                // cell.OnOpen.SubscribeAsync(async (_) => { OnOpenDetails.Invoke(master.Key); }).AddTo(mSubscriptions);
                await cell.SetUpAsync(master.Value);
                cellList.Add(cell);
                cell.gameObject.SetActive(true);
            }
            index++;
        }
    }
}
