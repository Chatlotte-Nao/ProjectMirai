using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using Takasho.Schema.Score.PlayerApi;
using UnityEngine;
using UnityEngine.UI;


public class UIUndergroundDetailsCell : MonoBehaviour
{
    [SerializeField] private UIText nameTxt;

    [SerializeField] private Slider completeSlider;
    [SerializeField] private UIText sliderTxt;
    [SerializeField] private UIButton openRewardBtn;

    [SerializeField] private UIButton gotoBtn;

    //TODO 临时加的已通关
    [SerializeField] private GameObject clearObj;
    public ClickEvent OnOpenReward => openRewardBtn.onClick;
    public ClickEvent OnClickUnderground => gotoBtn.onClick;

    public async UniTask SetUpAsync(UndergroundGetChapterV1.Types.Response.Types.Section section)
    {
        var master = DataManager.Instance.Master.UndergroundSectionMaster[section.UndergroundSectionMasterId];
        nameTxt.SetLabel(LocalizeManager.DATA_TYPE.UNDERGROUND,$"Section_Title_{master.id}");
        completeSlider.value = section.Progress * 0.01f;
        sliderTxt.SetFormat(LocalizeManager.DATA_TYPE.UNDERGROUND,"Slider_Text",section.Progress);
        var eventMaster = DataManager.Instance.Master.UndergroundEventMaster.FirstOrDefault(
            a => a.Value.undergroundSectionMasterId == section.UndergroundSectionMasterId &&
                 !a.Value.show);
        clearObj.SetActive(DataManager.Instance.Player.underground.IsOpenedEvent(eventMaster.Key));
    }
}
