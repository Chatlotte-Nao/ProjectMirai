using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Underground.V1;
using UnityEngine;
using UnityEngine.UI;


public class UIUndergroundRewardCell : MonoBehaviour
{
    [SerializeField] private UIText nameTxt;
    [SerializeField] private UIButton receiveBtn;
    [SerializeField] private UITexture receive;
    [SerializeField] private BaseItem baseItem;
     [SerializeField] private UIText receiveTxt;
    public ClickEvent OnReceive => receiveBtn.onClick;

    public async UniTask SetUpAsync(UndergroundEventMaster master)
    {
        nameTxt.SetLabel(LocalizeManager.DATA_TYPE.UNDERGROUND,$"Event_Content_{master.id}");
        var reward = master.rewards[0].Split(":");
        await baseItem.SetupAsync(long.Parse(reward[0]),reward[1]);
        await receive.LoadAsync("Font","rw_btn_a1_04",true);
        receiveTxt.SetColor(new Color(254.0f/255,244.0f/255,182.0f/255));
        var player = DataManager.Instance.Player.underground.TryEventGet(master.id);
        if (player != null)
        {
            switch (player.Status)
            {
                case EventStatus.InvalidEventStatus:
                    receiveBtn.gameObject.SetActive(true);
                    receiveTxt.SetColor(Color.gray);
                    receive.gameObject.SetActive(false);
                    break;
                case EventStatus.EventFinished:
                    receiveBtn.gameObject.SetActive(true);
                    receive.gameObject.SetActive(false);
                    break;
                case EventStatus.EventClaimed:
                    receiveBtn.gameObject.SetActive(false);
                    receive.gameObject.SetActive(true);
                    break;
            }
        }
        else
        {
            receiveBtn.gameObject.SetActive(true);
            receiveTxt.SetColor(Color.gray);
            receive.gameObject.SetActive(false);
        }
    }
    
 
}
