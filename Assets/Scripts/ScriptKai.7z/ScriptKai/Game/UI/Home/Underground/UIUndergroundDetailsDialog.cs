using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Adventure.Util;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;

public class UIUndergroundDetailsDialog : UIDialogBase
{

    [SerializeField] private UIUndergroundDetailsCell cellPrefab;
    [SerializeField] private RectTransform cellContent;
    [SerializeField] private UIText nameTxt;
    
    private List<UIUndergroundDetailsCell> cellList = new List<UIUndergroundDetailsCell>();
    
    public UILongEvent OnGotoCLick = new UILongEvent();
    public UILongEvent OnOpenReward = new UILongEvent();
    public async UniTask SetUpAsync(long chapterId)
    {
        var sections = await UndergroundService.UndergroundGetChapter(chapterId);
        nameTxt.SetLabel(LocalizeManager.DATA_TYPE.UNDERGROUND,$"Chapter_Title_{chapterId}");
        // var masters = DataManager.Instance.Master.UndergroundSectionMaster
        //     .Where(a => a.Value.UndergounrdChapterMasterId ==  chapterId);
        foreach (var cell in cellList)
        {
            cell.gameObject.SetActive(false);
            cell.OnClickUnderground.RemoveAllListeners();
            cell.OnOpenReward.RemoveAllListeners();
        }
        int index = 0;
        foreach (var section in sections)
        {
            if (!section.Unlocked)
            {
                continue;
            }
            if (index < cellList.Count)
            {
                await cellList[index].SetUpAsync(section);
                cellList[index].OnOpenReward.SubscribeAsync(async (_) => { OnOpenReward.Invoke(section.UndergroundSectionMasterId); }).AddTo(mSubscriptions);
                cellList[index].OnClickUnderground.SubscribeAsync(async (_) => { OnGotoCLick.Invoke(section.UndergroundSectionMasterId); }).AddTo(mSubscriptions);
                cellList[index].gameObject.SetActive(true);
            }
            else
            {
                var cell = Instantiate(cellPrefab, cellContent);
                cell.OnOpenReward.SubscribeAsync(async (_) => { OnOpenReward.Invoke(section.UndergroundSectionMasterId); }).AddTo(mSubscriptions);
                cell.OnClickUnderground.SubscribeAsync(async (_) => { OnGotoCLick.Invoke(section.UndergroundSectionMasterId); }).AddTo(mSubscriptions);
                await cell.SetUpAsync(section);
                cellList.Add(cell);
                cell.gameObject.SetActive(true);
            }
            index++;
        }
    }
}

