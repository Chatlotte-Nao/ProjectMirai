using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using EnhancedScrollerDemos.Chat;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Underground.V1;
using UnityEngine;

public class UIUndergroundPage : UIPageBase
{
    private UIUndergroundMainDialog _undergroundMainDialog = null;
    private UIUndergroundDetailsDialog _undergroundDetails = null;
    private UIUndergroundRewardDialog _undergroundReward = null;
    private UndergroundLevelType _undergroundLevel;
    private long level = 0;
    private bool isInit = true;
    private List<long> chapterIds = new List<long>();
    private List<long> sectionIds = new List<long>();
    private UIHomeHeaderParam headerParam = new UIHomeHeaderParam();
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        if (param != null)
            _undergroundLevel = (UndergroundLevelType) param;
        else
            _undergroundLevel = UndergroundLevelType.Normal;
        //await UndergroundService.UndergroundGetProfile((int)_undergroundLevel);
        _undergroundMainDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIUndergroundMainDialog, CanvasType.App0) as UIUndergroundMainDialog;
        _undergroundDetails = await UI.Dialog.CreateAsync(UIPrefabId.UIUndergroundDetailsDialog, CanvasType.App1) as UIUndergroundDetailsDialog;
        _undergroundReward = await UI.Dialog.CreateAsync(UIPrefabId.UIUndergroundRewardDialog, CanvasType.App2) as UIUndergroundRewardDialog;

        _undergroundMainDialog.OnClickSelect.GuardSubscribeAsync(OnClickSelect).AddTo(mSubscriptions);
        _undergroundMainDialog.OnClick.GuardSubscribeAsync(OnClick).AddTo(mSubscriptions);
        //_undergroundMainDialog.OnOpenDetails.GuardSubscribeAsync(OnClickOpenDetails).AddTo(mSubscriptions);
        _undergroundMainDialog.OnClickScenario.GuardSubscribeAsync(OnClickScenario).AddTo(mSubscriptions);
        
        _undergroundDetails.OnOpenReward.GuardSubscribeAsync(OnOpenReward).AddTo(mSubscriptions);
        _undergroundDetails.OnGotoCLick.GuardSubscribeAsync(OnGoToClick).AddTo(mSubscriptions);
        
        
        headerParam = new UIHomeHeaderParam()
        {
            visibleBack = true,
            visibleIcon = false,
            visiblePlayerStatus = false,
            visibleRightRank = false,
            visibleNavigation = true,
            visibleHome = true,
            showResType = new List<UIHeaderResType>()
            {
                UIHeaderResType.Stamina,
            },
            //conuitemIds = new List<long>(){103002047}
        };
        await LoadServerData();
    }

    private async UniTask LoadServerData()
    {
        await UndergroundService.UndergroundGetProfile(1);
        await UndergroundService.UndergroundGetProfile(2);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);
        if (!isInit)
        {
            await UndergroundService.UndergroundGetProfile((int) _undergroundLevel);
            level = 1;
        }
        chapterIds.Clear();
        sectionIds.Clear();
        isInit = false;
        await base.ShowAsync(showType);
        await _undergroundMainDialog.SetUpAsync(_undergroundLevel);
        await _undergroundMainDialog.ShowAsync();
    }
    
    private async UniTask OnClickSelect(GameObject o)
    {
        _undergroundLevel = _undergroundLevel == UndergroundLevelType.Normal
            ? UndergroundLevelType.Hard
            : UndergroundLevelType.Normal;
        // if (level < 2)
        // {
        //     await UndergroundService.UndergroundGetProfile((int) _undergroundLevel);
        //     level++;
        // }

        await _undergroundMainDialog.SetUpAsync(_undergroundLevel);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await _undergroundMainDialog.HideAsync();
        await _undergroundDetails.HideAsync();
        await _undergroundReward.HideAsync();
    }

    private async UniTask OnClickScenario(GameObject o)
    {
        UIHomeScenarioSelectPage.PageParam p = new UIHomeScenarioSelectPage.PageParam();
        p.showType = UIHomeScenarioSelectPage.PageParam.ShowType.Chapter;
        await UI.Page.ChangePage<UIHomeScenarioSelectPage>(p);
    }

    private async UniTask OnClick(long chapterId)
    {
        var playerUndergroundChapter = DataManager.Instance.Player.underground.TryGet(chapterId);
        if (playerUndergroundChapter != null)
        {
            switch (playerUndergroundChapter.Status)
            {
                case ChapterStatus.InvalidChapterStatus:
                    await loadLockData(chapterId);
                    break;
                case ChapterStatus.ChapterUnlocked:
                    await OnClickLock(chapterId);
                    break;
                case ChapterStatus.ChapterStarted:
                    await OnClickOpenDetails(chapterId);
                    break;
            }
        }
        else
        {
            await loadLockData(chapterId);
        }
    }
    private async UniTask loadLockData(long chapterId)
    {
        var _master = DataManager.Instance.Master.UndergroundChapterMaster[chapterId];
        UndergroundUtil.IsLock(_master.unlockCondition,out var Str);
        await UI.Popup.ShowPopupMessageAsync(Str);
    }
    /// <summary>
    /// 解锁
    /// </summary>
    /// <param name="o"></param>
    private async UniTask OnClickLock(long chapterId)
    {
        var master = DataManager.Instance.Master.UndergroundChapterMaster[chapterId];
        var s = master.startCostContents[0].Split(':');
        var itemName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ITEM, $"{s[0]}_name");
        var str =string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "Chapter_Unlock_Context"),s[1],itemName);
        UI.Popup.ShowConfirm(string.Empty, str, CanvasType.App2, (r)=>
        {
            if (r == UIPopupDialog.Result.OK)
            {
                AsyncManager.Instance.StartAsync(UnlockAsync(chapterId));
            }
        });
    }

    private async UniTask UnlockAsync(long chapterid)
    {
        await UndergroundService.UndergroundStartChapter(chapterid);
        await _undergroundMainDialog.SetUpAsync(_undergroundLevel);
    }

    /// <summary>
    /// 打开详情界面
    /// </summary>
    /// <param name="o"></param>
    private async UniTask OnClickOpenDetails(long chapterId)
    {
        if (!chapterIds.Contains(chapterId))
        {
            await _undergroundDetails.SetUpAsync(chapterId);
            chapterIds.Add(chapterId);
        }
        await _undergroundDetails.ShowAsync();
    }
    /// <summary>
    ///打开领取物品界面
    /// </summary>
    /// <param name="sectionId"></param>
    private async UniTask OnOpenReward(long sectionId)
    {

        return;
        if (!sectionIds.Contains(sectionId))
        {
            await UndergroundService.UndergroundGetSection(sectionId);
            sectionIds.Add(sectionId);
        }
        await _undergroundReward.SetUpAsync(sectionId);
        await _undergroundReward.ShowAsync();
    }
    /// <summary>
    /// 进地下城
    /// </summary>
    /// <param name="sectionId"></param>
    private async UniTask OnGoToClick(long sectionId)
    {
        //await UI.ScreenEffect.Fade(1);

        var section = DataManager.Instance.Master.UndergroundSectionMaster[sectionId];
        var battleZoneId = section.battleZoneId;
        var chapter = DataManager.Instance.Master.UndergroundChapterMaster[section.undergroundChapterMasterId];
        AdvManager.Instance.undergroundLevel = chapter.undergroundLevelMasterId;
        AdvSceneParam p = new AdvSceneParam();
        p.onFinish = onScenarioScriptFinish;
            
        await GameSceneManager.Instance.ChangeSceneAsync<AdvScene>("AdvScene", p,false);

        DataManager.Instance.Local.BattleZone.currentBattleZoneId = battleZoneId;

        var sceneName = DataManager.Instance.Master.Location[DataManager.Instance.Master.BattleZone[battleZoneId].mapName].scene;
        var levelName = DataManager.Instance.Master.Location[DataManager.Instance.Master.BattleZone[battleZoneId].mapName].level;
        DataManager.Instance.Local.BattleZone.currentSceneName = sceneName;
            
        await MapSceneManager.Instance.ShowAsync(sceneName, levelName, null, MapSceneManager.SceneType.Underground);
        
        //await UI.ScreenEffect.Fade(0);
        await UI.Loading.EndValue();
    }
 
    private void onScenarioScriptFinish(Game.ScriptEngine.ScriptResult scriptName)
    {
        AsyncManager.Instance.StartAsync(FinishScenarioSectionAsync());
    }

    public async UniTask FinishScenarioSectionAsync()
    {
        DataManager.Instance.Local.ClearStoryParam();
        Time.timeScale = 1f;
        await GameSceneManager.Instance.ChangeSceneAsync<HomeScene>("HomeScene", null);
    }

    
    public override void Dispose()
    {
        if (mSubscriptions != null)
        {
            mSubscriptions.Dispose();
            mSubscriptions = null;
        }
    }
}
