﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using UnityEngine.Events;
using UnityEngine.Rendering;

public class UIHomeSubMainWindow : UIDialogBase
{
    [Space(20), Header("常驻")]
    [SerializeField]
    UIButton navigationButton;

    [SerializeField] UIButton mapButton;
    [SerializeField] UIButton dungeonButton;
    [SerializeField] UIButton storyButton;
    [SerializeField] UIButton inventoryButton;
    [SerializeField] UIButton strengthenEquipmentButton;
    [SerializeField] UIButton characterButton;
    [SerializeField] UIButton foldButton;
    [SerializeField] UIButton gachaButton;
    [SerializeField] RectTransform foldObj;

    [Space(20), Header("导航面板")]
    [SerializeField] GameObject navigationGroup;
    [SerializeField] GameObject normalGroup;
    [SerializeField] UIText nameText;
    [SerializeField] UserIcon userIcon;
    [SerializeField] UIText rankText;

    [SerializeField] UIButton closeNavigationButton;
    [SerializeField] UIButton profileButton;
    [SerializeField] UIButton exchangeButton;
    [SerializeField] UIButton accountButton;
    [SerializeField] UIButton configButton;
    [SerializeField] UIButton signoffButton;


    [SerializeField] UIButton characterButton2;
    [SerializeField] UIButton strengthenEquipmentButton2;
    [SerializeField] UIButton storyButton2;
    [SerializeField] UIButton dungeonButton2;
    [SerializeField] UIButton gachaButton2;
    [SerializeField] UIButton dailyQuestButton;
    [SerializeField] UIButton missionButton;
    [SerializeField] UIButton shopButton;
    [SerializeField] UIButton inventoryButton2;
    [SerializeField] UIButton mailButton;
    [SerializeField] UIButton announceButton;


    public UnityEvent OnClickMap;

    public ClickEvent OnExchange = new ClickEvent();
    public ClickEvent OnAccount = new ClickEvent();
    public ClickEvent OnConfige = new ClickEvent();
    public ClickEvent OnOpenNavigationGroup = new ClickEvent();
    public ClickEvent OnHideNavigationGroup = new ClickEvent();

    [SerializeField] UIText placenameText;

    [SerializeField] UIButton eventListButton;

    [SerializeField] private UIHomeHeaderExplore explpreResource;

    public UnityEvent OnClickEventList => eventListButton.OnTouchUpInside;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        //navigationButton.OnTouchUpInside.GuardSubscribeAsync(onClickNavigation).AddTo(mSubscriptions);
        mapButton.OnTouchUpInside.GuardSubscribeAsync(onClickMap).AddTo(mSubscriptions);
        dungeonButton.OnTouchUpInside.GuardSubscribeAsync(onClickDungeon).AddTo(mSubscriptions);
        storyButton.OnTouchUpInside.GuardSubscribeAsync(onClickStory).AddTo(mSubscriptions);
        //inventoryButton.OnTouchUpInside.GuardSubscribeAsync(onClickInventory).AddTo(mSubscriptions);
        //strengthenEquipmentButton.OnTouchUpInside.GuardSubscribeAsync(onClickEquipment).AddTo(mSubscriptions);
        //characterButton.OnTouchUpInside.GuardSubscribeAsync(onClickCharacter).AddTo(mSubscriptions);
        //foldButton.OnTouchUpInside.GuardSubscribeAsync(onClickFolder).AddTo(mSubscriptions);
        gachaButton.OnTouchUpInside.GuardSubscribeAsync(onClickGacha).AddTo(mSubscriptions);

        //closeNavigationButton.OnTouchUpInside.GuardSubscribeAsync(onClickCloseNavigation).AddTo(mSubscriptions);
        // profileButton.OnTouchUpInside.GuardSubscribeAsync(onClickProfile).AddTo(mSubscriptions);
        // exchangeButton.OnTouchUpInside.GuardSubscribeAsync(onClickExchange).AddTo(mSubscriptions);
        // accountButton.OnTouchUpInside.GuardSubscribeAsync(onClickAccount).AddTo(mSubscriptions);
        // configButton.OnTouchUpInside.GuardSubscribeAsync(onClickconfig).AddTo(mSubscriptions);
        // signoffButton.OnTouchUpInside.GuardSubscribeAsync(onClickSignOff).AddTo(mSubscriptions);
        // characterButton2.OnTouchUpInside.GuardSubscribeAsync(onClickCharacter).AddTo(mSubscriptions);
        // strengthenEquipmentButton2.OnTouchUpInside.GuardSubscribeAsync(onClickEquipment).AddTo(mSubscriptions);
        // storyButton2.OnTouchUpInside.GuardSubscribeAsync(onClickStory).AddTo(mSubscriptions);
        // dungeonButton2.OnTouchUpInside.GuardSubscribeAsync(onClickDungeon).AddTo(mSubscriptions);
        // gachaButton2.OnTouchUpInside.GuardSubscribeAsync(onClickGacha).AddTo(mSubscriptions);
        // dailyQuestButton.OnTouchUpInside.GuardSubscribeAsync(onClickDailyQuest).AddTo(mSubscriptions);
        // missionButton.OnTouchUpInside.GuardSubscribeAsync(onClickMission).AddTo(mSubscriptions);
        // shopButton.OnTouchUpInside.GuardSubscribeAsync(onClickShop).AddTo(mSubscriptions);
        // inventoryButton2.OnTouchUpInside.GuardSubscribeAsync(onClickInventory).AddTo(mSubscriptions);
        // mailButton.OnTouchUpInside.GuardSubscribeAsync(onClickMail).AddTo(mSubscriptions);
        // announceButton.OnTouchUpInside.GuardSubscribeAsync(onClickAnnounce).AddTo(mSubscriptions);


        SignalBus.GlobalSignal.Subscribe(UIEventId.MapSceneChanged, OnMapChanged).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe(UIEventId.UIHeaderExploreInfoUpdate, OnExplpreCoinChanged)
            .AddTo(mSubscriptions);
        OnMapChanged();
        OnExplpreCoinChanged();
    }

    // private void OnEnable()
    // {
    //     if (isNavigation)
    //     {
    //         OnOpenNavigationGroup.Invoke(gameObject);
    //     }
    //
    //     UpdateIcon();
    //     UpdateRank();
    //     nameText.SetRawText(DataManager.Instance.Player.Player.GetData().Name);
    // }
    public override void OnShow()
    {
        base.OnShow();

        if (!DataManager.Instance.Local.UserInfo.showNotice
            && !TutorialManager.Instance.IsRunningFunctionTutorial
            && DataManager.Instance.Player.Chapter.TryGet(2) != null
            && DataManager.Instance.Local.ConfigStorage.isPopAnnouncement)
        {
            DataManager.Instance.Local.UserInfo.showNotice = true;
            AsyncManager.Instance.StartAsync(onClickAnnounce());
        }
    }
    void UpdateIcon()
    {
        var iconId = DataManager.Instance.Player.Player.GetData().ProfileIconId;
        userIcon.Setup(DataManager.Instance.Player.Player.GetData().ProfileIconFrame, iconId);
        var master = DataManager.Instance.Master
            .CharacterResource[DataManager.Instance.Master.BattleCharacter[iconId].characterResourceId];
    }

    void UpdateRank()
    {
        rankText.SetLabel(LocalizeManager.DATA_TYPE.COMMON, DataManager.Instance.Player.Player.GetLevel().ToString());
    }

    private async UniTask onClickAnnounce()
    {
#if !UNITY_EDITOR
        var _webViewDialog =
 (UIWebViewDialog) await UI.Dialog.CreateAsync(UIPrefabId.UIWebAnnouncementDialog, CanvasType.System);
        
        _webViewDialog.OnBack.Subscribe(_=>{
            _webViewDialog.Dispose();
            _webViewDialog = null;
        });

        var platform = "";
#if UNITY_ANDROID
        platform = "android";
#elif UNITY_IOS
        platform = "ios";
#endif
        var affcode = LCXHandler.Instance.AffCode;
        var realmid = DataManager.Instance.Local.UserInfo.currentServer.id;

        var url =
 DataManager.Instance.Local.UserInfo.announcementUrl+$"?platform={platform}&affcode={affcode}&realmid={realmid}";

        await _webViewDialog.SetupAsync(url);
        await _webViewDialog.ShowAsync();
#endif
    }

    private async UniTask onClickProfile()
    {
        await UI.Page.OpenPage<UIHomeProfilePage>();
    }

    private async UniTask onClickMail()
    {
        await MailService.GetMailsAsync();
        await UI.Page.OpenPage<UIHomeMailPage>();
    }

    bool isFolding = false;

    private async UniTask onClickFolder()
    {
        isFolding = !isFolding;
        var xValue = isFolding ? 620 : 360;
        // var zValue = isFolding ? 180 : 0;
        DOTween.To(() => foldObj.anchoredPosition, x => foldObj.anchoredPosition = x, new Vector2(xValue, -39), 0.3f);
        // rightButton.transform.localRotation = new Quaternion(0, 0, zValue, 0);
    }

    private async UniTask onClickMap()
    {
        OnClickMap.Invoke();
    } 
    public class RoomSelectEvent : UnityEvent<UIWorldMapDialog.SelectTarget>
    {
    }

    private void gotoRoom(string room, string name = "")
    {
        UIWorldMapDialog.SelectTarget t = new UIWorldMapDialog.SelectTarget();
        t.mapName = room;
        t.roomName = name;
        OnSelectTarget.Invoke(t);
    }
    public RoomSelectEvent OnSelectTarget = new RoomSelectEvent();
    private async UniTask onClickInventory()
    {
        await UI.Page.OpenPage<UIInventoryPage>();
        // gotoRoom("advRoom[51]");
    }

    private async UniTask onClickShop()
    {
        // gotoRoom("advRoom[52]");
        // await ExploreService.RequestExploreData();
        // await UI.Page.OpenPage<UIShopPage>();
    }

    private async UniTask onClickMission()
    {
        await MissionService.RequestMissionData();
        await UI.Page.OpenPage<UIMissionPage>();
    }

    private async UniTask onClickDungeon()
    {
        //TODO 跳转地牢
        //UI.Popup.ShowPopMessage( LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "Common_Home_NotOpen"));
        //await UI.Page.ChangePage<UIUndergroundPage>();
        gotoRoom("advRoom[131]","dungeon");
    }

    private async UniTask onClickExchange()
    {
        //TODO 兑换码界面
        OnExchange.Invoke(exchangeButton.gameObject);
    }

    private async UniTask onClickAccount()
    {
        //TODO 账号界面
        OnAccount.Invoke(accountButton.gameObject);
    }

    private async UniTask onClickconfig()
    {
        OnConfige.Invoke(configButton.gameObject);
    }

    private async UniTask onClickDailyQuest()
    {
        await DailyQuestService.GetAvailable();
        await DailyQuestService.GetToday();
        await UI.Page.OpenPage<UIHomeDailyQuestMainPage>();
    }

    private async UniTask onClickStory()
    {
        gotoRoom("advRoom[58]","OrganMachine");
        // UIHomeScenarioSelectPage.PageParam p = new UIHomeScenarioSelectPage.PageParam();
        // p.showType = UIHomeScenarioSelectPage.PageParam.ShowType.Chapter;
        // await UI.Page.OpenPage<UIHomeScenarioSelectPage>(p);
    }


    private bool isNavigation;

    private async UniTask onClickNavigation()
    {
        isNavigation = true;
        navigationGroup.SetActive(true);
        normalGroup.SetActive(false);
        OnOpenNavigationGroup.Invoke(gameObject);
    }

    private async UniTask onClickCloseNavigation()
    {
        navigationGroup.SetActive(false);
        normalGroup.SetActive(true);
        OnHideNavigationGroup.Invoke(gameObject);
        isNavigation = false;
    }

    private async UniTask onClickSignOff()
    {
        LCXHandler.Instance.SignOff();
    }

    private async UniTask onClickCharacter()
    {
        await UI.Page.OpenPage<UIHomeCharacterMainPage>();
    }

    private async UniTask onClickEquipment()
    {
        await UI.Page.OpenPage<UIHomeEquipmentListPage>();
    }

    private async UniTask onClickGacha()
    { 
        gotoRoom("advRoom[128]");
    }

    private void OnExplpreCoinChanged()
    {
        var itemCouny = DataManager.Instance.Player.Item.GetCount(121000001);
        explpreResource?.SetText(itemCouny.ToString());
    }

    private void OnMapChanged()
    {
        if (MapSceneManager.Instance.CurrentScene != null && !string.IsNullOrEmpty(MapSceneManager.Instance.CurrentScene.GetNowMapLabel()))
            placenameText.SetLabel(LocalizeManager.DATA_TYPE.LOCATION_NAME,
                DataManager.Instance.Master.Location[MapSceneManager.Instance.CurrentScene.GetNowMapLabel()]
                    .displayName);
    }
}
