﻿using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;


namespace Home
{
	public class HomeButton : MonoBehaviour
	{
		[SerializeField]
		GameObject selectedObject = null;

		[SerializeField]
		RawImage icon = null;

		[SerializeField]
		TextMeshProUGUI text = null;

		[SerializeField]
		Color normalColor = default;

		[SerializeField]
		Color selectedColor = default;

		[SerializeField]
		RawImage deactivateFilter = null;

		[SerializeField]
		Button button = null;

		[SerializeField]
		RawImage nameBase = null;

		public bool isButtonActionSkip = false;

		public bool isDeactivate = false;

		public void SetSelectState(bool isSelected)
		{
			text.color = icon.color = isSelected ? selectedColor : normalColor;
			selectedObject.SetActive(isSelected);

			if (nameBase != null)
			{
				if (isSelected) { nameBase.color = selectedColor; }
				else			{ nameBase.color = new Color32(17, 18, 21, 255); }
			}
		}

		public void SetDeactivate(bool value)
		{
			isDeactivate = value;
			CallUpdate();
		}

		void CallUpdate()
		{
			if (!isDeactivate)
			{
				if (button != null && !isButtonActionSkip) { button.interactable = true; }
				if( selectedObject == null )
				{
					icon.color = new Color32(255, 255, 255, 255);
					text.color = new Color32(255, 255, 255, 255);
				}
				else
				{
					text.color = icon.color = normalColor;
				}
				
				if (deactivateFilter != null) { deactivateFilter.gameObject.SetActive(false); }
			}
			else
			{
				if (button != null && !isButtonActionSkip) { button.interactable = false; }
				icon.color = new Color32(96, 96, 96, 255);
				text.color = new Color32(255, 255, 255, 96);
				if (deactivateFilter != null) { deactivateFilter.gameObject.SetActive(true); }
			}
		}

#if UNITY_EDITOR
		bool localfalg = false;
		void Start()
		{
			localfalg = isDeactivate;
		}

		void Update()
		{
			if (localfalg != isDeactivate)
			{
				localfalg = isDeactivate;
				CallUpdate();
			}
		}
#endif

	}
}
