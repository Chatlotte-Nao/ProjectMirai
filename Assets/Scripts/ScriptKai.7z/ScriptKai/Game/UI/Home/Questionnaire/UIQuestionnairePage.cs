﻿using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using Takasho.Schema.Score.PlayerApi;
using Takasho.Schema.Score.ResourceCn.Questionnaire.V1;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class UIQuestionnairePage : UIPageBase
{
    private UIWebViewDialog _webViewDialog = null;
    private GlobalQuestionnaireWithUrl _mParam;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        _mParam = param as GlobalQuestionnaireWithUrl;
        _webViewDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIWebViewDialog, CanvasType.App1) as UIWebViewDialog;
        await _webViewDialog.SetupAsync(_mParam.FullUrl,_mParam.GlobalQuestionnaire.QuestionnaireTitle);
        
        _webViewDialog.OnBack.GuardSubscribeAsync(ShowHonme).AddTo(mSubscriptions);
    }
    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
        await _webViewDialog.ShowAsync(showType);
    }
    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await _webViewDialog.HideAsync();
    }
    private async UniTask ShowHonme(GameObject o)
    {
        await QuestionnaireService.QuitQuestionnaireAsync(_mParam.GlobalQuestionnaire.QuestionnaireId);
        await UI.Page.CloseCurrentPage(true);
        // await UI.Page.ChangePage<UIHomeMainPage>();
    }

    public override void Dispose()
    {
        if (_webViewDialog != null)
        {
            _webViewDialog.Dispose();
            _webViewDialog = null;
        }
    }
}
