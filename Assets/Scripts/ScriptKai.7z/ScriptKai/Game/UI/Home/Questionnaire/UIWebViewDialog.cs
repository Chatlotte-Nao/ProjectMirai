﻿using System;
using System.Collections;
using System.Collections.Generic;
using Game.Ui;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

public class UIWebViewDialog : UIDialogBase
{
    [SerializeField] UIButton backButton;
    [SerializeField] WebView webView;
    [SerializeField] private UIText titleText;
    [SerializeField] private Toggle _toggle;
    public ClickEvent OnBack => backButton.onClick;
    private string url_;
    private int _screenWidth, _screenHeight;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        // SaveResolution();
        // QualityLevelController.Instance.ResumeResolution();
        webView.Initialize();
        webView.OnUnityMessage.Subscribe(onUnityMessage).AddTo(mSubscriptions);
        if (_toggle != null)
        {
            _toggle.isOn = DataManager.Instance.Local.ConfigStorage.notAnnouncement;
            _toggle.onValueChanged.Subscribe(onDay).AddTo(mSubscriptions);
        }

    }
    
    // public void SaveResolution()
    // {
    //     _screenWidth = Screen.currentResolution.width;
    //     _screenHeight = Screen.currentResolution.height;
    // }

    public async UniTask SetupAsync(string url, string title = null)
    {
        url_ = url;
        if (!string.IsNullOrEmpty(title))
        {
            titleText.SetRawText(title);
        }
        
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        await LoadUrl(url_);
    }

    void onUnityMessage(string msg)
    {
        if (msg == "//close") {
            Dispose();
        }
        else if (msg.StartsWith("//jump/"))
        {
            AsyncManager.Instance.StartGuardAsync(CommonUtil.JumpToTargetPage(msg.Substring(7)));
            Dispose();
        }
        else if (msg.StartsWith("//webEvent/"))
        {
            AsyncManager.Instance.StartGuardAsync(OpenWeChatShareDialog(msg.Substring(11)));
            Dispose();
        }
        
    }

    public async UniTask LoadUrl(string url)
    {
        if (!gameObject.activeSelf)
        {
            return;
        }
        
        await webView.LoadUrl(url);
    }

    public override void Dispose()
    {
        base.Dispose();
        // QualityLevelController.Instance.SetResolution(_screenWidth, _screenHeight);
        if(webView != null)
            Destroy(webView);
    }

    public async UniTask OpenWeChatShareDialog(string eventHead)
    {
        var weChatShareDialog = (UIWeChatShareDialog) await UI.Dialog.CreateAndShowAsync(UIPrefabId.UIWeChatShareDialog, CanvasType.App2);
        await weChatShareDialog.SetUp(eventHead);
    }

    private void onDay(bool isToggle)
    {
        DataManager.Instance.Local.ConfigStorage.notAnnouncement = isToggle;
        DataManager.Instance.Local.SaveConfig();
    }






}
