﻿using System;
using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using LocalizeManager = Pheonix.Core.LocalizeManager;

public class UIWeChatShareDialog : UIDialogBase
{
    
    [SerializeField]
    UIButton copyButton;
    [SerializeField]
    UIButton closeArea;
    
    
    
    
    
    
    
    [SerializeField]
    UIText serialNumberText;
    [SerializeField]
    UIText countDownText;
    
    
    [SerializeField]
    DateTime _expire_at;

    private string _eventHead;
    private string _account;
    private string _dynamicCode;
    private string _serialNumber = "";
    
    
    
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        copyButton.onClick.GuardSubscribeAsync(OnClickCopy).AddTo(mSubscriptions);
        if (closeArea != null)
            closeArea.onClick.GuardSubscribeAsync(OnClickCancel).AddTo(mSubscriptions);
        if (closeButton != null)
            closeButton.onClick.GuardSubscribeAsync(OnClickCancel).AddTo(mSubscriptions);
    }

    public async UniTask SetUp(string eventHead)
    {
        
        SetEventHead(eventHead);
        await RefreshSn();
        AsyncManager.Instance.StartAsync(StartCountdown());
    }

    void SetEventHead(string eventHead)
    {
        _eventHead=eventHead;
    }


    
    private async UniTask RefreshSn()
    {
        
        var data=await OutgameService.WeChatShare();
        _expire_at = GlobalTime.GetDateTime(data.Item1);
        _account=data.Item2;
        _dynamicCode=data.Item3;
        _serialNumber = _eventHead + "#" + _account  + _dynamicCode;
        serialNumberText.SetLabel(LocalizeManager.DATA_TYPE.COMMON,_serialNumber);
    }


    async UniTask StartCountdown()
    {
        while (gameObject!=null)
        {
            await  UniTask.Delay(1000);
            var countDown =(int)(_expire_at - DateTime.Now).TotalSeconds;
            if (countDown <= 0)
            {
                await RefreshSn();
            }
            countDownText.SetFormat(LocalizeManager.DATA_TYPE.COMMON,"ANNOUNCE_WeChatShare_CountDownLeft",countDown.ToString());
        }
    }

     private async UniTask OnClickCopy(GameObject o)
    {
        UnityEngine.GUIUtility.systemCopyBuffer = _serialNumber;
        var t = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "ANNOUNCE_WeChatShare_CopySNSucceed");
        await UI.Popup.ShowPopupMessageAsync(t);
    }
    
    
    private async UniTask OnClickCancel(GameObject o)
    {
        await HideAsync();
        Dispose();
    }
    
    
}
