using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using System.Threading.Tasks;

public class UINoneItemPopup : UIDialogBase
{
    [SerializeField] UIText text;

    public ClickEvent OnClick => closeButton.onClick;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        OnClick.GuardSubscribeAsync(onBackClcik).AddTo(mSubscriptions);
        Debug.Log($"UINoneItemPopup Initialization");
    }
    private async UniTask onBackClcik(GameObject o)
    {
        Debug.Log($"UINoneItemPopup Down Button");
        //await HideAsync(showType: UIPageShowType.Front);
        gameObject.SetActive(false);
    }
    public async UniTask loadData(string str)
    {
        text.SetRawText(LocalizeManager.Instance.GetCommonText(str));
        await Task.Delay(System.TimeSpan.Zero);
    }
    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        Debug.Log($"UINoneItemPopup Show");
        gameObject.SetActive(true);
    }
}
