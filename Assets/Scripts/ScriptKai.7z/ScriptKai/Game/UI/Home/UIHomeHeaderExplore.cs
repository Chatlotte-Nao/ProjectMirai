using System;
using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using UnityEngine;

public class UIHomeHeaderExplore : MonoBehaviour
{
    [SerializeField] UIText exploreCoinText;
    [SerializeField] UIText exploreCoinLimitText;
    [SerializeField] private UIText limitContentText;
    [SerializeField] private UIButton limitButton;
    [SerializeField] private UIButton closeButton;
    [SerializeField] private UIButton closeButton2;
    [SerializeField] private UIButton closeButton3;
    [SerializeField] private GameObject limitObj;  
    [SerializeField] private GameObject limitMaxObj;
    [SerializeField] private BaseItem item;
    private void Start()
    {
        limitButton.onClick.AddListener((_) => { OnLimitClick(true);});
        closeButton.onClick.AddListener((_) => { OnLimitClick(false);});
        closeButton2.onClick.AddListener((_) => { OnLimitClick(false);});
        closeButton3.onClick.AddListener((_) => { OnLimitClick(false);});
    }

    public void SetText(string count)
    {
        exploreCoinText.SetRawText(count);
        var exploreCoinLimit = DataManager.Instance.Player.Player.GetData().ExploreCoinLimit;
        var receivedCost = DataManager.Instance.Player.Player.GetData().ExploreCoinReceived;
        exploreCoinLimitText.SetFormat(LocalizeManager.DATA_TYPE.EXPLORE,"Explore_Limit",$"{receivedCost}/{exploreCoinLimit}");
        //limitMaxObj.SetActive(receivedCost >= exploreCoinLimit);
        var limit = DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.ExploreCoinDailyCost].data;
        var max = DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.ExploreCoinDailyLimitMax].data;
        limitContentText.SetFormat(LocalizeManager.DATA_TYPE.EXPLORE,"Explore_Limit_Content", limit,max);
        item.Setup(121000001,"");
    }

    void OnLimitClick(bool isActive)
    {
        limitObj.SetActive(isActive);
        // var limit = DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.ExploreCoinDailyCost].data;
        // var max = DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.ExploreCoinDailyLimitMax].data;
        // var text = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE,"Explore_Limit_Content"), limit,max);
        // var title = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON,"MAP_SUB_QUEST_WINDOW_HINT");
        //
        // UI.Popup.ShowPopup(title,text, CanvasType.App2);
    }

    private void OnDestroy()
    {
        limitButton.onClick.RemoveAllListeners();
        closeButton.onClick.RemoveAllListeners();
    }
}
