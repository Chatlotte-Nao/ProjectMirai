﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using Base.Util;

using Home;
using TMPro;
using Game.Ui;

namespace Map
{
    public class VariousNotification : MonoBehaviour
    {
        public SupportMissionNotification SupportMissionNotification { get { return supportMissionNotification; } }

        [SerializeField] RectTransform investigationBattleRoot;
        [SerializeField] GameObject investigationBattle;
		[SerializeField] TextMeshProUGUI investigationBattleName;
		[SerializeField] TextMeshProUGUI investigationBattleTime;
        [SerializeField] Image rareEenemyIcon;
		[SerializeField] SupportMissionNotification supportMissionNotification;

        [SerializeField] NotificationImage notificationImage;


		List<NotificationImage> notifications = new List<NotificationImage>();
        bool isBattle;
        bool isStart;
        int lastNum;
        DateTime investigationLimitTime;
        
        public enum CONTENT_NAME
        {
            GUILD,
            INVESTIGATION,
            PRODUCTION,
            NOTICE,
            FRIEND,
            MAILBOX,
            SHOP,
            WAREHOUSE,
            CONFIG,
            TAKT_ROOM,
            QUEST,
            PVP,
            DUNGEON,
        }
        CONTENT_NAME contentName;

        readonly string[] LABELDATA =
        {
            "NOTIFICATION_GUILD",
            "NOTIFICATION_INVESTIGATION",
            "NOTIFICATION_PRODUCTION",
            "NOTIFICATION_BANK",
            "NOTIFICATION_NOTICE",
            "NOTIFICATION_MAILBOX",
            "NOTIFICATION_FRIEND",
            "NOTIFICATION_SHOP",
            "NOTIFICATION_WAREHOUSE",
            "NOTIFICATION_CONFIG",
            "NOTIFICATION_TAKT_ROOM",
            "NOTIFICATION_QUEST",
            "NOTIFICATION_PVP",
            "NOTIFICATION_DUNGEON",
        };

        public void Init()
        {
            isBattle = false;
            isStart = false;
            bool isActive = false;
            lastNum = 0;
     //       var playerData = UserData.GetPlayerData();
     //       if (playerData.InvestigationBattleId > 0)
     //       {
     //           isBattle = true;
     //           if (playerData.InvestigationMissionBattle != 0)
     //           {
					//investigationBattleName.text = "";
					//var masterData = MasterData.GetInstance().investigationBattleMaster;
					//foreach ( var record in masterData)
					//{
					//	if (record.Key == playerData.InvestigationBattleId)
					//	{
					//		investigationBattleName.text = LocalizeManager.GetText(LocalizeManager.DATA_TYPE.INVESTIGATION_BATTLE_NAME, record.Value.name);
     //                       rareEenemyIcon.gameObject.SetActive(record.Value.isRareButtle > 0);
					//		break;
					//	}
					//}

					//investigationLimitTime = TimeUtil.GetDateTime(playerData.InvestigationMissionBattle);
					//investigationBattle.SetActive(true);
     //           }
     //       }

            supportMissionNotification.Init();

            var isInvestigationRootActivation = false;
            foreach (RectTransform child in investigationBattleRoot)
            {
                if (child.gameObject.activeSelf)
                {
                    isInvestigationRootActivation = true;
                    isActive = true;
                    break;
                }
            }
            investigationBattleRoot.gameObject.SetActive(isInvestigationRootActivation);

            for (int i = 0; i < Enum.GetNames(typeof(CONTENT_NAME)).Length; i++)
            {
                var image = Utility.CreateGameObject<NotificationImage>(notificationImage.gameObject, notificationImage.transform.parent);
                image.Create((CONTENT_NAME)i);
                image.gameObject.SetActive(false);
                notifications.Add(image);
            }

            //int num = InvestigationMission.InvestigationShare.GetFinishNum();
            //if (num > 0)
            //{
            //    var index = (int)CONTENT_NAME.INVESTIGATION;
            //    notifications[index].gameObject.SetActive(true);
            //    notifications[index].SetText(string.Format("{0}({1})", LocalizeManager.GetCommonText(LABELDATA[index]), num));
            //    isActive = true;
            //}
            SetActive(isActive);
           // InvestigationMission.InvestigationShare.SetTime();
            isStart = true;
        }

        public void UpdateContent()
        {
            if (!isStart) return;
			//var	num	= InvestigationMission.InvestigationShare.GetFinishNum();
   //         if (num > lastNum)
   //         {
   //             int index = (int)CONTENT_NAME.INVESTIGATION;
   //             if (!notifications[index].gameObject.activeSelf)
   //                 notifications[index].gameObject.SetActive(true);
   //             if (!this.gameObject.activeSelf)
   //                 SetActive(true);

   //             notifications[index].SetText(string.Format("{0}({1})", LocalizeManager.GetCommonText(LABELDATA[index]), num));
   //         }

            supportMissionNotification.Refresh();

            if (!isBattle) return;
            //if (!InvestigationMission.InvestigationShare.IsRemainBattleTimeLimit(investigationLimitTime, null, investigationBattleTime))
            //{
            //    isBattle = false;
            //    investigationBattle.SetActive(false);
            //}
        }

        public void SetActive(bool isActive)
        {
            this.gameObject.SetActive(isActive);
        }
    }
}