﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Battle;
using UnityEngine.UIElements;
using UnityEngine.UI;
using TMPro;

public class UIHomeCharacterUnitSkillDialog : UIDialogBase
{
    [SerializeField] UIHomeCharacterUnitSkillCellUI[] cells;
    [SerializeField] UIText skillDescText;
    [SerializeField] UIButton equipBtn;
    [SerializeField] UIButton unequipBtn;
    [SerializeField] List<TextMeshProUGUI> conductorEnergy = new List<TextMeshProUGUI>();

    [SerializeField] UnityEngine.UI.Image selectedSkillIcon;
    [SerializeField] private UIButton ProtectBG;
    
    [SerializeField] private UISkillCommandDetailPanel skillCommandDetailPanel;
    [SerializeField] UIText energy;
    public UILongEvent OnEquip = new UILongEvent();
    public UILongEvent OnUnequip = new UILongEvent();

    public long SelectSkill = 0;
    
    

    private CharacterViewModel _viewModel;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        equipBtn.OnTouchUpInside.Subscribe(OnClickEquip).AddTo(mSubscriptions);
        unequipBtn.OnTouchUpInside.Subscribe(OnClickUnEquip).AddTo(mSubscriptions);
        ProtectBG.onClick.Subscribe((o) =>
        {
            if (_viewModel.selectedSkills.Count >= 2)
            {
                OnClose.Invoke();
            }
            else
            {
                var str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "CHARACTER_SKILL_SHORT"), 2);
                UI.Popup.ShowPopMessage(str);
            }
        }).AddTo(mSubscriptions);
    }

    public async UniTask SetupAsync(CharacterViewModel model)
    {
        
        _viewModel = model;
        
        var characterMaster = DataManager.Instance.Master.BattleCharacter[model.id];

        for (int i = 0; i < cells.Length; i++)
        {
            var cell = cells[i];
            cell.SelectToggle.onValueChanged.RemoveAllListeners();
            if (i >= model.learnedSkills.Count)
            {
                cell.gameObject.SetActive(false);
            }
            else
            {
                cell.Id = model.learnedSkills[i];
                await cell.SetupAsync( model.learnedSkills[i]);
                if (model.passiveSkills.Contains(cell.Id))
                {
                    
                    cell.IsPassive = true;
                    cell.IsEquipped = false;
                    cell.statusText.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Unit_Skill_Passive");
                    cell.gameObject.SetActive(false);
                }
                else
                {
                    cell.gameObject.SetActive(true);
                    cell.IsPassive = false;
                    if (model.selectedSkills.Contains(cell.Id))
                    {
                        cell.IsEquipped = true;
                        cell.statusText.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Unit_Skill_Equipped");
                        //cell.equippedHintIcon.gameObject.SetActive(cell.IsEquipped&&!cell.IsPassive);
                    }
                    else
                    {
                        cell.IsEquipped = false;
                        cell.statusText.SetRawText(string.Empty);
                        //cell.equippedHintIcon.gameObject.SetActive(false);
                    }
                }
            }
            
            if (cell.Id == SelectSkill && cell.IsEquipped)
            // if (cell.IsEquipped)
            {
                cell.SelectToggle.isOn = true;
                selectedSkillIcon.sprite = cell.iconImage.sprite;
            }
            else
            {
                cell.SelectToggle.isOn = false;
            }
            cell.SelectToggle.onValueChanged.Subscribe((v)=>
            {
                if (v)
                {
                    var c = cell;
                    OnSelectSkill(c);
                }
            }).AddTo(mSubscriptions);
            
            if (cell.SelectToggle.isOn)
            {
                OnSelectSkill(cell);
            }
        }


    }
    
    private void OnSelectSkill(UIHomeCharacterUnitSkillCellUI cell)
    {
        PxSoundManager.Instance.PlaySe("feedbackSE_date_select01");
        SelectSkill = cell.Id;

        setArticle(SelectSkill);

        // skillNameText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{mSelectSkill}_name");
        skillDescText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{SelectSkill}_desc");
        

        if (cell.IsPassive)
        {
            equipBtn.gameObject.SetActive(false);
            unequipBtn.gameObject.SetActive(false);
        }
        else
        {
            equipBtn.gameObject.SetActive(!cell.IsEquipped);
            unequipBtn.gameObject.SetActive(cell.IsEquipped);
        }

        var skillMaster = DataManager.Instance.Master.Skill[SelectSkill]; //

        skillCommandDetailPanel.Refresh((int)_viewModel.id,skillMaster.id,true);

        selectedSkillIcon.sprite = cell.iconImage.sprite;
    }

    private void OnClickEquip()
    {
        OnEquip.Invoke(SelectSkill);
        if (_viewModel.selectedSkills.Count >= 2)
        {
            ProtectBG.gameObject.SetActive(false);
        }
    }

    private void OnClickUnEquip()
    {
        OnUnequip.Invoke(SelectSkill);
        if (_viewModel.selectedSkills.Count < 2)
        {
            ProtectBG.gameObject.SetActive(true);
        }
    }


    private void setArticle(long skillId)
    {

        var skillMaster = DataManager.Instance.Master.Skill[skillId];
        bool isMusicEffect = (CommandType)skillMaster.skillType == CommandType.MusicEffect;
        //skillMaster.ene
        List<int> energyNumber = isMusicEffect ? skillMaster.energyDecrease : skillMaster.energyIncrease;
        energy.SetRawText($"<color=#FF0000>{energyNumber[2]}</color>/<color=#00FF2C>{energyNumber[1]}</color>/<color=#0067FF>{energyNumber[0]}</color>" + LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.BATTLE, "Text_Energy"));

        conductorEnergy[0].text = $"<color=#0067FF>{energyNumber[0].ToString()}</color>";
        conductorEnergy[1].text = $"<color=#00FF2C>{energyNumber[1].ToString()}</color>";
        conductorEnergy[2].text = $"<color=#FF0000>{energyNumber[2].ToString()}</color>"; 


        //var tempConductor = BattleMain.Instance.battleAdmin.conductor;
        //conductorEnergy[0].text = $"{tempConductor.curEnergy[0]}/{tempConductor.EachEnergyMax[0]}";
        //conductorEnergy[1].text = $"{tempConductor.curEnergy[1]}/{tempConductor.EachEnergyMax[1]}";
        //conductorEnergy[2].text = $"{tempConductor.curEnergy[2]}/{tempConductor.EachEnergyMax[2]}";
    }
}
