﻿using System.Collections;
using System.Collections.Generic;
using Base.Sound;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIHomeCharacterMainPage : UIPageBase
{
    UIHomeHeaderParam headerParam = new UIHomeHeaderParam();

    private bool isMapAdv = false;

    private UIHomeCharacterSelectMainWindow mMainWindow = null;

    // private bool isInit = true;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        if (param != null)
            isMapAdv = true;
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterMainWindow, CanvasType.App0) as UIHomeCharacterSelectMainWindow;
        mMainWindow.OnBackClick.GuardSubscribeAsync(OnBackClcik).AddTo(mSubscriptions);
        mMainWindow.OnGachaClick.GuardSubscribeAsync(onClickGacha).AddTo(mSubscriptions);
        headerParam.showResType.Add(UIHeaderResType.Coin);
        headerParam.visibleRightRank = false;
        headerParam.visibleBack = true;
        headerParam.visibleNavigation = true;
        headerParam.visibleHome = true;
        
        // SignalBus.GlobalSignal.Subscribe(UIEventId.UIHeaderHomeButton,OnHomeButton).AddTo(mSubscriptions);
        //SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        
        // if(isInit)
            SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);
        await base.ShowAsync(showType);
        // isInit = false;
        await mMainWindow.ShowAsync(showType);
    }

    private async UniTask OnBackClcik(GameObject o)
    {
        SoundManager.StopVoice();
        await UI.Page.CloseCurrentPage();
    }

    private async UniTask onClickGacha(GameObject o)
    {
        if (!CommonUtil.IsFunctionUnlock(5,true))
        {
            return;
        }

        if (true)
        {
            var param = await GachaService.GetGachaList();
            
            // await UI.Page.CloseCurrentPage();
            await UI.Page.OpenPage<UIGachaMainPage>(param);
            return;
        }
        await ExploreService.RequestExploreData();
        var room = "advRoom[128]";
        var advMapMaster = DataManager.Instance.Master.AdvMap[room];
        var mapData = DataManager.Instance.Master.Location[advMapMaster.map_label];

        if (string.IsNullOrEmpty(advMapMaster.startPos))
        {
            await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home, mapData.startPos);
        }
        else
        {
            await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home, advMapMaster.startPos);
        }

        DataManager.Instance.Local.UserInfo.currentHomeMap = advMapMaster.map_label;
        
        MapSceneManager.Instance.CurrentScene.MovePlayerToRoom(room);
        DataManager.Instance.Local.UserInfo.currentHomeRoom = room;
        await UI.Page.ChangePage<UIHomeSubPage>();
        MapSceneManager.Instance.CurrentScene.GetCameraController().SetFollowMode(true);
        MapSceneManager.Instance.CurrentScene.GetCameraController().SetEnabledDraggableCamera(false);
      
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);

        await mMainWindow.HideAsync(showType);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
    }
}
