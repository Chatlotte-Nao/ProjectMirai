﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UIHomeCharacterUnitMenu : UIDialogBase
{
    [SerializeField] UIToggleGroupController toggles;
    [SerializeField] TabToggle tabStatus;
    [SerializeField] TabToggle tabEquipment;
    [SerializeField] TabToggle tabSphere;
    [SerializeField] TabToggle tabSkin;
    [SerializeField] TabToggle fetterSkin;
    [SerializeField] TabToggle tabGamut;
    
    [SerializeField] UIButton tabStatusBtn;
    [SerializeField] UIButton tabEquipmentBtn;
    [SerializeField] UIButton tabSphereBtn;
    [SerializeField] UIButton tabGamuBtnt;
    [SerializeField] UIButton fetterBtn;
    [SerializeField] UIButton tabGamutBtn;

    public UIIntEvent OnSelectTab = new UIIntEvent();


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        tabStatus.onValueChanged.Subscribe((isOn)=>{if (isOn) OnSelectTab.Invoke(1);}).AddTo(mSubscriptions);
        tabEquipment.onValueChanged.Subscribe((isOn)=>{if (isOn) OnSelectTab.Invoke(2);}).AddTo(mSubscriptions);
        tabSphere.onValueChanged.Subscribe((isOn)=>{if (isOn) OnSelectTab.Invoke(3);}).AddTo(mSubscriptions);
        tabSkin.onValueChanged.Subscribe((isOn)=>{if (isOn) OnSelectTab.Invoke(4);}).AddTo(mSubscriptions);
        fetterSkin.onValueChanged.Subscribe((isOn)=>{if (isOn) OnSelectTab.Invoke(5);}).AddTo(mSubscriptions);
        tabGamut.onValueChanged.Subscribe(ison => { if (ison) OnSelectTab.Invoke(6); }).AddTo(mSubscriptions);

        
        tabStatusBtn.OnTouchUpInside.Subscribe(()=>{tabStatus.isOn = true;}).AddTo(mSubscriptions);
        tabEquipmentBtn.OnTouchUpInside.Subscribe(()=>{tabEquipment.isOn = true;}).AddTo(mSubscriptions);
        tabSphereBtn.OnTouchUpInside.Subscribe(()=>{tabSphere.isOn = true;}).AddTo(mSubscriptions);
        tabGamuBtnt.OnTouchUpInside.Subscribe(() => { tabSkin.isOn = true; }).AddTo(mSubscriptions);
        fetterBtn.OnTouchUpInside.Subscribe(()=>{fetterSkin.isOn = true;}).AddTo(mSubscriptions);
        tabGamutBtn.OnTouchUpInside.Subscribe(() => tabGamut.isOn = true).AddTo(mSubscriptions);
    }
    public void TogglesActive(int tab)
    {
        toggles.reFresh((int)tab - 1);
        PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01");
    }
}
