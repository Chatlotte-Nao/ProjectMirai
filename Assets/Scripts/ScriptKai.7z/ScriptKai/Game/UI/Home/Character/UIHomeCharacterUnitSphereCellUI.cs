﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UIHomeCharacterUnitSphereCellUI : MonoBehaviour
{
    public Toggle SelectToggle;
    public GameObject ActiveObject;
    public long Id;
    public bool IsActivated => ActiveObject.activeSelf;
    public bool IsCenterCell => UnlockObject != null;
    public GameObject UnlockObject;
    
}
