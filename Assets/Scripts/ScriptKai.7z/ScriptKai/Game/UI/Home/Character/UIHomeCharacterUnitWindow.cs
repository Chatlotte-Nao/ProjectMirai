﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;
using System.Linq;
using Spine.Unity;
using TMPro;

public class UIHomeCharacterUnitWindow : UIDialogBase
{
    [SerializeField] UIText titleText;
    [SerializeField] UIText nameText;
    [SerializeField] UIText cvText;
    [SerializeField] RawImage standImage;
    [SerializeField] Image bgImage;
    [SerializeField] Image rarityImage;

    [SerializeField] BaseItem rankUpItem;
    [SerializeField] UIButton rankUpBtn;

    [SerializeField] UIButton prevBtn;
    [SerializeField] UIButton nextBtn;

    [SerializeField] UIButton backBtn;
    [SerializeField] UIText bondText;
    [SerializeField] UIButton signContractBtn;
    [SerializeField] GameObject signContractActive;
    [SerializeField] private GameObject rankObject;
    [SerializeField] private UIText yuanDingBondText;
    [SerializeField] private UITexture bondImage;
    [SerializeField] GameObject BondsGroup;
    [SerializeField] int lockId;
    private long modelId = 0;
    UIRTCamera mRTCamera = null;
    public ClickEvent OnBackClick => backBtn.onClick;
    public UnityEvent OnClickRankUp => rankUpBtn.OnTouchUpInside;
    public ClickEvent OnClickPrev => prevBtn.onClick;
    public ClickEvent OnClickNext => nextBtn.onClick;
    public RawImage stand => standImage;
    public UnityEvent OnClickSign => signContractBtn.OnTouchUpInside;

    public void SetTitle(string title)
    {
        titleText.SetRawText(title);
    }

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        var rtc = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/RTCamera");
        mRTCamera = rtc.GetComponent<UIRTCamera>();
    }

    public async UniTask SetupAsync(CharacterViewModel model)
    {
        signContractBtn.gameObject.SetActive(false);
        //signContractActive.SetActive(true);
        FunctionUnlockMaster fum = DataManager.Instance.Master.FunctionUnlock[lockId];
        //bool isOn = DataManager.Instance.Player.Player.GetLevel() > fum.requirePlayerLevel && StoryUtil.IsClear(fum.requireStageId) ? true : false;
        nameText.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER_NAME,  model.id.ToString());

        var nameTextMeshPro = nameText.GetComponent<TextMeshProUGUI>();
        string firstWord = nameTextMeshPro.text.ToString()[0].ToString();
        string nameLast1 = nameTextMeshPro.text.ToString().Substring(1);
        
        string nameFirst="<size=40>"+firstWord+"</size>";
        string nameLast2 = "<color=#672972>"+nameLast1+"</color>";
        nameTextMeshPro.text = nameFirst+ nameLast2;
        
        
        
        var resourceMaster = DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[model.id].characterResourceId];

        //temp
        GameObject loadCharacter = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/chara/" + resourceMaster.advModelId);
        SkeletonAnimation skeletonAnimation = loadCharacter.GetComponent<SkeletonAnimation>();
        skeletonAnimation.Initialize(false);
        skeletonAnimation.Update(0.0f);
        skeletonAnimation.LateUpdate();

        mRTCamera.Setup(loadCharacter);
        standImage.texture = mRTCamera.GetRenderTexture();
        bgImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("CharacterMain/BgCutin", resourceMaster.bgCutinName);

        var characterRankMaster = DataManager.Instance.Master.CharacterRankUp.Values.FirstOrDefault((r)=>(r.battleCharacterMasterId==model.id&&r.rank==model.rank+1));
        if (characterRankMaster != null)
        {
            //rankObject.SetActive(true);
            rankUpItem.gameObject.SetActive(true);
            var item = characterRankMaster.requireContents[0].Split(':');
            rankUpItem.SetupNeed(long.Parse(item[0]), long.Parse(item[1]));
        }
        else
        {
            //rankObject.SetActive(false);
            rankUpItem.gameObject.SetActive(false);
        }

        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(model); });
        //rarityImage.sprite = ResourceManager.Instance.LoadSpriteSmall("RarityIcon", $"Rarity_{DataManager.Instance.Master.BattleCharacter[model.id].rarity}");
        bondText.SetFormat(LocalizeManager.DATA_TYPE.BOND, DataManager.Instance.Player.Bond.GetLevel(model.id).ToString());
        var bondTextMeshPro = bondText.GetComponent<TextMeshProUGUI>();
        firstWord = bondTextMeshPro.text.ToString()[0].ToString();
        nameLast1 = bondTextMeshPro.text.ToString().Substring(1);
        nameFirst = "<size=28>" + firstWord + "</size>";
        bondTextMeshPro.text = nameFirst + nameLast1;
        modelId = DataManager.Instance.Player.Bond.GetLevel(model.id);
        //signContractBtn.gameObject.SetActive(!model.contract);
        if (DataManager.Instance.Player.Bond.GetLevel(model.id) >= 4)
        {
            signContractActive.SetActive(true);
            //signContractBtn.gameObject.SetActive(true);
        }
        else
        {
            signContractActive.SetActive(false);
            //signContractBtn.gameObject.SetActive(false);
        }

        yuanDingBondText.SetLabel(LocalizeManager.DATA_TYPE.BOND, $"{DataManager.Instance.Player.Bond.GetLevel(model.id)}");
        bondImage.Load("Bond", DataManager.Instance.Player.Bond.GetLevel(model.id).ToString(), false);
    }

    public async UniTask SetBondsGroup(bool isSow)
    {
        BondsGroup.SetActive(isSow);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mRTCamera != null)
        {
            mRTCamera.Dispose();
            mRTCamera = null;
        }
    }

    private async UniTask LoadSpriteAsync(CharacterViewModel model)
    {
        rarityImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("RarityIcon", $"Rarity_{DataManager.Instance.Master.BattleCharacter[model.id].rarity}");
    }
}
