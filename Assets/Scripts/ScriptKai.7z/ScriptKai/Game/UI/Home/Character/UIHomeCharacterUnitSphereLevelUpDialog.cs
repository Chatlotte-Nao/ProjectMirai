﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
public class UIHomeCharacterUnitSphereLevelUpDialog : UIDialogBase
{

    [SerializeField] GameObject skillObj;
    [SerializeField] Image skillIcon;
    [SerializeField] UIText voiceTxt;

    [SerializeField] UIText stageText;
    [SerializeField] GameObject TextBar;
    [SerializeField] UIButton skillBtn;
    [SerializeField] private GameObject skillGroup;
    [SerializeField] UIButton closeDetailButton;
    [SerializeField] private UISkillCommandDetailPanel commandDetailPanel;
    [SerializeField] private BaseAttributeUp prefab; 
    [SerializeField] private RectTransform attributeTransform;
    private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();
    CharacterViewModel _model;
    CharacterPanelMaster panel;
    [SerializeField] private UITexture titleTexture;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        titleTexture.Load("Font", "ty_font_hxyl_01", true);
        closeDetailButton.OnTouchUpInside.Subscribe(() => commandDetailPanel.Hide()).AddTo(mSubscriptions);
        skillBtn.OnTouchDown.Subscribe(OnClickSkill).AddTo(mSubscriptions);
    }

    public async UniTask SetupAsync(CharacterViewModel oldModel, CharacterViewModel newModel,CharacterPanelMaster panelMaster)
    {
        commandDetailPanel.gameObject.SetActive(false);
        _model = newModel;
        panel = panelMaster;
        foreach (var attribute in attributeList)
        {
            attribute.gameObject.SetActive(false);
        }
        int index = 1;
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            var oldValue = oldModel.attributeDict[eAtt];
            var newValue = newModel.attributeDict[eAtt];
            if (newValue > oldValue)
            {
                if (index < attributeList.Count)
                {
                    attributeList[index].LoadAttributeData(eAtt, eAtt.GetAttributePercent(oldValue), eAtt.GetAttributePercent(newValue));
                    attributeList[index].gameObject.SetActive(true);
                }
                else
                {
                    var attribute = Instantiate(prefab, this.attributeTransform, false);
                    attribute.LoadAttributeData(eAtt, eAtt.GetAttributePercent(oldValue), eAtt.GetAttributePercent(newValue));
                    attribute.gameObject.SetActive(true);
                    attributeList.Add(attribute);
                }
                index++;
            } 
        }

        if (panelMaster.getSkillId > 0)
        {
            skillObj.SetActive(true);
            SkillMaster master = DataManager.Instance.Master.Skill[panelMaster.getSkillId];
            string skillIconPath = master.iconPath;
            if (skillIcon != null)
            {
                skillIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", skillIconPath);
                skillGroup.SetActive(true);
            }
            else
            {
                skillGroup.SetActive(false);
            }
            
        }
        else
        {
            skillObj.SetActive(false);
        }

        if (panelMaster.getVoiceId != string.Empty)
        {
            voiceTxt.gameObject.SetActive(true);
            voiceTxt.SetRawText(panelMaster.getVoiceId );
        }
        else
        {
             voiceTxt.gameObject.SetActive(false);
        }
        stageText.SetRawText(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, $"UI_Unit_Sphere_Page{newModel.grade - 1}"));
        if(oldModel.grade == newModel.grade)
        {
            skillGroup.SetActive(false);
        }
        else
        {
            skillGroup.SetActive(true);
        }


    }
    void OnClickSkill()
    {
        commandDetailPanel.Show();
        commandDetailPanel.Refresh((int)_model.id, panel.getSkillId, true);
    }

    private void OnDisable()
    {
        skillGroup.SetActive(false);
    }
}
