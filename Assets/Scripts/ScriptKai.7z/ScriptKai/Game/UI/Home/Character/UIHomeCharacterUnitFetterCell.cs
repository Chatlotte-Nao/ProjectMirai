using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeCharacterUnitFetterCell : MonoBehaviour
{
    [SerializeField] private RectTransform selRectTransform;
    [SerializeField] private UIText titleTxt;
    [SerializeField] private UIButton titleBtn;
    [Space]
    [SerializeField] private UIButton unLockBtn;
    [SerializeField] private List<BaseItem> rewards1;
    [SerializeField] private UIText[] condiTionTxt;
    [Space]
    [SerializeField] private UIButton allRewardBtn;
    [SerializeField] private List<BaseItem> rewards2;

    [SerializeField] private GameObject contentObj;
    [SerializeField] private GameObject condiTionObj;
    [SerializeField] private GameObject reward1Obj;
    [SerializeField] private GameObject reward2Obj;
    [SerializeField] private GameObject textObj;
    [SerializeField] private UIText unlockText;
    [SerializeField] private Image[] lockImages;
    [SerializeField] private GameObject lockObject;
    [SerializeField] private GameObject titleBg2;
    public ClickEvent OnClick => unLockBtn.onClick;

    
    //public ClickEvent OnClick => allRewardBtn.onClick;
    private BondsInfoMaster _master;
    private bool isSizeMax;
    private void Start()
    {
        titleBtn.onClick.Subscribe((_)=>
        {
            OnTitleClick();
        });
        allRewardBtn.onClick.Subscribe((_)=>
        {
            OnClick.Invoke(_);
        });
    }

    public async UniTask SetUp(BondsInfoMaster master)
    {
        _master = master;
        isSizeMax = false;
        condiTionObj.SetActive(false);
        reward1Obj.SetActive(false);
        reward2Obj.SetActive(false);
        textObj.SetActive(false);
        titleTxt.SetLabel(LocalizeManager.DATA_TYPE.BOND,$"Bonds_Title_{master.id}");
        titleTxt.SetColor(Color.black);
        unlockText.SetLabel(LocalizeManager.DATA_TYPE.BOND,$"Bonds_UnLock_Content_{master.id}");
        
        OnTitleClick();
        foreach (var item in condiTionTxt)
        {
            item.gameObject.SetActive(false);
        }

        bool isUnlock = true;
        for (int i = 0; i < master.missionMasterId.Count; i++)
        {
            if (i < condiTionTxt.Length)
            {
                var missionMater = DataManager.Instance.Master.Mission[master.missionMasterId[i]];
                condiTionTxt[i].SetFormat(LocalizeManager.DATA_TYPE.BOND, $"Mission_Title_{i + 1}",
                    missionMater.GetLocalizedText());
                condiTionTxt[i].gameObject.SetActive(true);
                if (MissionUtil.IsMissionCompelte(master.missionMasterId[i]))
                {
                    condiTionTxt[i].SetColor(Color.green);
                }
                else
                {
                    condiTionTxt[i].SetColor(Color.white);
                    isUnlock = false;
                }

                if (missionMater.missionTypeId == 40006)
                {
                    condiTionObj.SetActive(false);
                    reward1Obj.SetActive(false);
                    reward2Obj.SetActive(true);
                }
                else
                {
                    condiTionObj.SetActive(true);
                    reward1Obj.SetActive(true);
                    reward2Obj.SetActive(false);
                }
            }
        }
        unLockBtn.gameObject.SetActive(isUnlock);
        allRewardBtn.gameObject.SetActive(isUnlock);
        foreach (var lockImage in lockImages)
        {
            if ( DataManager.Instance.Player.Bond.IsUnLockId(master.id))
            {
                lockImage.color =  Color.white;
                titleBg2.SetActive(false);
                unLockBtn.gameObject.SetActive(false);
                allRewardBtn.gameObject.SetActive(false);
                textObj.SetActive(true);
                condiTionObj.SetActive(false);
                reward1Obj.SetActive(false);
                reward2Obj.SetActive(false);
                //titleTxt.SetColor( new Color(1,1,217.0f/255));
                titleTxt.SetColor(Color.black);
                lockObject.SetActive(false);
            }
            else
            {
                lockImage.color =   Color.black;
                titleBg2.SetActive(true);
                unLockBtn.gameObject.SetActive(isUnlock);
                allRewardBtn.gameObject.SetActive(isUnlock);
                lockObject.SetActive(true);
            }
        }
        for (int i = 0; i < rewards1.Count; i++)
        {
            if (master.rewardContents.Count > i)
            {
                var s = master.rewardContents[i].Split(':');
                var itemId = long.Parse(s[0]);
                var itemNum = s[1];
                rewards1[i].gameObject.SetActive(true);
                rewards2[i].gameObject.SetActive(true);
                await rewards1[i].SetupAsync(itemId,itemNum);
                await rewards2[i].SetupAsync(itemId,itemNum);
            }
            else
            {
                rewards1[i].gameObject.SetActive(false);
                rewards2[i].gameObject.SetActive(false);
            }
        }

      
    }

    void OnTitleClick()
    {
        this.gameObject.SetActive(false);
        contentObj.SetActive(isSizeMax);
        selRectTransform.sizeDelta = new Vector2(465,isSizeMax?335:95);
        isSizeMax = !isSizeMax;
        this.gameObject.SetActive(true);
    }
}
