﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIHomeCharacterSubPage : UIPageBase
{
    private UIHomeCharacterSelectSubWindow mMainWindow = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync();
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterSubWindow, CanvasType.App0) as UIHomeCharacterSelectSubWindow;
        await mMainWindow.RefreshAsync((int)param);

    }
    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);

        await mMainWindow.ShowAsync(showType);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);

        await mMainWindow.HideAsync(showType);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
    }


}
