using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;
using System.Linq;

public class UIHomeCharacterUnitGamutRankUpDialog : UIDialogBase
{

    public UIIntEvent OnGamut = new UIIntEvent();

    [SerializeField] Image[] starts;
    [SerializeField] Image[] startsNext;
    [SerializeField] UIText newMeNameText;
    [SerializeField] UIText newMeLev;

    [SerializeField] private Image newSkillImage;

    [SerializeField] private BaseAttributeUp prefab;
    [SerializeField] private RectTransform attributeTransform;

    private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();


    public async UniTask SetupAsync(CharacterViewModel oldModel, CharacterViewModel newModel)
    {
        for (int i = 0; i < starts.Length; i++)
        {
            starts[i].gameObject.SetActive(false);
            startsNext[i].gameObject.SetActive(false);
        }
        for (int i = 0; i < oldModel.rank; i++)
        {
            starts[i].gameObject.SetActive(true);
        }


        for (int i = 0; i < attributeTransform.childCount; i++)
        {
            attributeTransform.GetChild(i).gameObject.SetActive(false);
        }

        for (int i = 0; i < newModel.rank; i++)
        {
            startsNext[i].gameObject.SetActive(true);
        }

        int index = 1;
        for (int i = 1; i < (int)CharacterAttribute.Crt; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            var oldValue = oldModel.attributeDict[eAtt] + oldModel.equipAttributeDict[eAtt];
            var newValue = newModel.attributeDict[eAtt] + newModel.equipAttributeDict[eAtt];

            var attribute = Instantiate(prefab, this.attributeTransform, false);
            if (newValue > oldValue)
                attribute.LoadAttributeData(eAtt, eAtt.GetAttributePercent(oldValue),
                    eAtt.GetAttributePercent(newValue));
            //else
            //    attribute.SetupText(eAtt, eAtt.GetAttributePercent(oldValue));
            else
                attribute.LoadAttributeData(eAtt, eAtt.GetAttributePercent(oldValue),
                    eAtt.GetAttributePercent(oldValue));
            attribute.gameObject.SetActive(true);
            attributeList.Add(attribute);
            index++;
        }


        newMeNameText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{newModel.meId}_name");

        //newMeLev.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "UNION_LEVEL_Gamut", newModel.rank.ToString());
        string str = string.Format(LocalizeManager.Instance.GetCommonText("Level_GetTo"), newModel.rank);
        newMeLev.SetRawText(str);
        Debug.Log($"{oldModel.meId}   {oldModel.meId + 1}   {newModel.meId}   {newModel.meId + 1}");

        SkillMaster master = DataManager.Instance.Master.Skill[oldModel.meId];

        SkillMaster master2 = DataManager.Instance.Master.Skill[newModel.meId];
        newSkillImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", master2.iconPath);

    }


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }
    public void Setup(string message)
    {
        //DataManager.Instance.Master.PuzzleExplore[1].
    }
}
