﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Linq;
using System.Net.Mime;
using UnityEngine.UI;

public class UIHomeCharacterUnitEquipmentDialog : UIDialogBase
{
    [SerializeField] UIButton[] slots;
    [SerializeField] Image[] slotsSelects;
    [SerializeField] GameObject itemPrefab;
    [SerializeField] RectTransform itemTransformParent;
    [SerializeField] private GameObject notObj;

    [SerializeField] UIEquipmentPanel oldPanel;
    [SerializeField] UIEquipmentPanel newPanel;
    [SerializeField] UIText newPanelEquipText;

    [SerializeField] UIButton bgObject;
    [SerializeField] UIButton selectBgObject;
    [SerializeField] UIButton listBgObject;
    [SerializeField] GameObject selectPanel;
    [SerializeField] TMPro.TMP_Dropdown sortDropdown;
    [SerializeField] UIButton sortOrderButton;
    [SerializeField] UIButton eqpCloseArea;
    
    public ClickEvent OnUpdateModel = new ClickEvent();
    private CharacterViewModel mCurrentCharacter = null;
    private Dictionary<string, SelectableEquipment> mListEquipmentObjects = new Dictionary<string, SelectableEquipment>();
    private Dictionary<int, BaseEquipment> mSlotEquipmentObjects = new Dictionary<int, BaseEquipment>();
    private EquipmentViewModel mListSelectEquipment = null;
    private int mSlot = -1;
    private bool mAscending = false;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        for (int i = 0; i < slots.Length; i++)
        {
            var s = i+1;
            slots[i].OnTouchUpInside.Subscribe(()=>{OnSelectEquipSlot(s);}).AddTo(mSubscriptions);
        }
        
        newPanel.OnClickEquip.Subscribe(OnClickEquip).AddTo(mSubscriptions);
        oldPanel.OnClickUnEquip.GuardSubscribeAsync(ProcessUnEquipAsync).AddTo(mSubscriptions);
        oldPanel.OnClickEnhance.GuardSubscribeAsync(OnClickEnhanceEquipped).AddTo(mSubscriptions);
        newPanel.OnClickEnhance.GuardSubscribeAsync(OnClickEnhanceSelected).AddTo(mSubscriptions);
        oldPanel.OnClickChange.GuardSubscribeAsync(OnClickChange).AddTo(mSubscriptions);
        bgObject.OnTouchUpInside.Subscribe(OnClickBg).AddTo(mSubscriptions);
        selectBgObject.OnTouchUpInside.Subscribe(OnClickBg).AddTo(mSubscriptions);
        listBgObject.OnTouchUpInside.Subscribe(OnClickBg).AddTo(mSubscriptions);
        eqpCloseArea.OnTouchUpInside.Subscribe(closeEqp).AddTo(mSubscriptions);


        var actList = new List<string>();
        actList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Rarity"));
        actList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Level"));
        actList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Sort_Rank"));
       

        sortDropdown.AddOptions(actList);

        sortDropdown.onValueChanged.Subscribe(SortSelectList).AddTo(mSubscriptions);
        sortOrderButton.OnTouchUpInside.Subscribe(OnClickOrderButton).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        if (showType == UIPageShowType.Back)
        {
            oldPanel.gameObject.SetActive(false);
            newPanel.gameObject.SetActive(false);
            if (mListSelectEquipment != null)
            {
                mListEquipmentObjects[mListSelectEquipment.uniqueId].Select(false);
                mListSelectEquipment = null;
            }
            if (mSlotEquipmentObjects.ContainsKey(mSlot) && selectPanel.activeSelf)
                ShowEquipList(mCurrentCharacter.id, mSlot, mSlotEquipmentObjects[mSlot].Model);
            else
            {
                selectPanel.SetActive(false);
            }
        }
    }

    public override async UniTask HideAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.HideAsync(showType);
        if (showType == UIPageShowType.Front)
        {
            selectPanel.SetActive(false);
            OnClickBg();
        }
    }

    public async UniTask SetupAsync(CharacterViewModel model)
    {
        mCurrentCharacter = model;

        foreach (var item in mSlotEquipmentObjects)
        {
            Destroy(item.Value.gameObject);
        }
        mSlotEquipmentObjects.Clear();

        foreach (var item in model.equipments)
        {
            await SetupEquipmentAsync(item.Key, item.Value);
        }
        transform.SetSiblingIndex(transform.parent.childCount - 1);
    }

    private async UniTask SetupEquipmentAsync(int slot, EquipmentViewModel model)
    {
        var o = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync(UIPrefabId.BaseEquipment, slots[slot-1].transform);

        var equip = o.GetComponent<BaseEquipment>();
        mSlotEquipmentObjects[slot] = equip;
        equip.Setup(model);
        equip.SetInteractable(false);
        selectPanel.SetActive(false);
    }


    void closeEqp()
    {
        oldPanel.gameObject.SetActive(false);
        oldPanel.ChangeBtnSetAvtive(false);
        //oldPanel.UnequipBtnSetAvtive(false);
        newPanel.gameObject.SetActive(false);
        eqpCloseArea.gameObject.SetActive(false);
    }

    private EquipmentViewModel seleteEquipment;
    private void OnSelectEquipSlot(int slot)
    {
        for (int i = 0; i < slotsSelects.Length; i++)
        {
            slotsSelects[i].gameObject.SetActive(i == slot-1);
        }
        EquipmentViewModel currentEquipment = null;
        mCurrentCharacter.equipments.TryGetValue(slot, out currentEquipment);
        seleteEquipment = currentEquipment;
        mSlot = slot;

        if (currentEquipment != null)
        {
            oldPanel.Setup(currentEquipment);
            oldPanel.gameObject.SetActive(true);
            oldPanel.ChangeBtnSetAvtive(true);
            oldPanel.UnequipBtnSetAvtive(true);
            eqpCloseArea.gameObject.SetActive(true);
            if (selectPanel.activeSelf)
            {
                oldPanel.ChangeBtnSetAvtive(false);
                ShowEquipList(mCurrentCharacter.id, slot, currentEquipment);
            }
            //selectPanel.SetActive(false);
            // bgObject.GetComponent<GraphicCast>().raycastTarget = true;
            
        }
        else
        {
            oldPanel.gameObject.SetActive(false);
            newPanel.gameObject.SetActive(false);
            mListSelectEquipment = null;
            ShowEquipList(mCurrentCharacter.id, slot, currentEquipment);
        }

        //ShowEquipList(mCurrentCharacter.id, slot, currentEquipment);

    }

    private async UniTask OnClickChange()
    {
        oldPanel.gameObject.SetActive(false);
        eqpCloseArea.gameObject.SetActive(false);
        ShowEquipList(mCurrentCharacter.id, mSlot, seleteEquipment);
    }
    private void ShowEquipList(long characterId, int slot, EquipmentViewModel currentEquipment)
    {
        selectPanel.SetActive(true);
        // bgObject.GetComponent<GraphicCast>().raycastTarget = true;

        foreach (var kv in mListEquipmentObjects)
        {
            kv.Value.gameObject.SetActive(false);
        }
        
        var totalList = DataManager.Instance.Player.Equipment.GetList().ToList();

        var charaMaster = DataManager.Instance.Master.BattleCharacter[characterId];
        
        foreach (var data in totalList)
        {
            var equipMaster = DataManager.Instance.Master.Equipment[data.EquipmentMasterId];
            if (equipMaster.position != slot) continue;
            if (!equipMaster.equipableJobs.Contains(charaMaster.job)) continue;

            if (mListEquipmentObjects.ContainsKey(data.PlayerEquipmentId))
            {
                //check changed
                if (mListEquipmentObjects[data.PlayerEquipmentId].Model.updateTime != data.UpdatedAt)
                {
                    var model = EquipmentUtil.BuildEquipmentViewModel(data);
                    mListEquipmentObjects[data.PlayerEquipmentId].Setup(model);
                    mListEquipmentObjects[data.PlayerEquipmentId].OnClick.RemoveAllListeners();
                    mListEquipmentObjects[data.PlayerEquipmentId].OnClick.Subscribe(()=>{ OnSelectListEquipment(model); }).AddTo(mSubscriptions);
                }
                else
                {
                    //mListEquipmentObjects[data.PlayerEquipmentId].OnClick.Subscribe(()=>{ OnSelectListEquipment(EquipmentUtil.BuildEquipmentViewModel(data)); }).AddTo(mSubscriptions);
                    mListEquipmentObjects[data.PlayerEquipmentId].Select(false);
                }

                mListEquipmentObjects[data.PlayerEquipmentId].gameObject.SetActive(true);
                
            }
            else
            {
                var newItemObj = GameObject.Instantiate(itemPrefab.gameObject);
                newItemObj.transform.parent = itemTransformParent;
                newItemObj.transform.localScale = Vector3.one;
                newItemObj.transform.localRotation = Quaternion.identity;
                newItemObj.transform.localPosition = Vector3.zero;
                newItemObj.SetActive(true);

                var sel = newItemObj.GetComponent<SelectableEquipment>();
                var model = EquipmentUtil.BuildEquipmentViewModel(data);
                sel.Setup(model);
                sel.OnClick.Subscribe(()=>{ OnSelectListEquipment(model); }).AddTo(mSubscriptions);

                mListEquipmentObjects.Add(model.uniqueId, sel);
            }
            
            //check current
            
            if (currentEquipment != null && currentEquipment.uniqueId == data.PlayerEquipmentId)
            {
                mListEquipmentObjects[data.PlayerEquipmentId].SetSelectableStatus(true, LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Unit_Equip_SelectList_Equiping"));
            }
            else
            {
                mListEquipmentObjects[data.PlayerEquipmentId].SetSelectableStatus(true);
            }
        }

        SortSelectList(sortDropdown.value);
    }

    private void SortSelectList(int select)
    {
        var objList = new List<SelectableEquipment>(mListEquipmentObjects.Values.Where(x=>x.gameObject.activeSelf));

        switch (select)
        { 
            case 0:
               objList = objList.OrderBy(a => DataManager.Instance.Master.Equipment[a.Model.id].rarity)
                    .ThenBy(a => a.Model.level).ThenBy(a => a.Model.rank).ThenBy(a => a.Model.sortId).ToList();
                break;
            case 1:
                objList = objList.OrderBy(a => a.Model.level).ThenBy(a => DataManager.Instance.Master.Equipment[a.Model.id].rarity)
                   .ThenBy(a => a.Model.rank).ThenBy(a => a.Model.sortId).ToList();
                break;
            case 2:
                objList = objList.OrderBy(a => a.Model.rank).ThenBy(a => DataManager.Instance.Master.Equipment[a.Model.id].rarity)
                    .ThenBy(a => a.Model.level).ThenBy(a => a.Model.sortId).ToList();
                break;
           
        }
        
        if (!mAscending) objList.Reverse();

        for (int i = 0; i < objList.Count; i++)
        {
            objList[i].transform.SetSiblingIndex(i);
        }
        notObj.SetActive(objList.Count==0||objList==null);
    }

    private void OnClickOrderButton()
    {
        mAscending = !mAscending;

        SortSelectList(sortDropdown.value);
    }




    private void OnSelectListEquipment(EquipmentViewModel model)
    {
        if (model.equippedCharacter > 0 && (seleteEquipment !=null && model.equippedCharacter == seleteEquipment.equippedCharacter))
        {
            oldPanel.gameObject.SetActive(true);
            oldPanel.ChangeBtnSetAvtive(false);
            eqpCloseArea.gameObject.SetActive(true);
            mListSelectEquipment = model;
            return;
        }

        if (mListSelectEquipment != null)
        {
            if (mListSelectEquipment == model && (model.equippedCharacter>0 && model.equippedCharacter == mListSelectEquipment.equippedCharacter))
            {
                oldPanel.Setup(model);
                oldPanel.gameObject.SetActive(true);
                oldPanel.ChangeBtnSetAvtive(false);
                eqpCloseArea.gameObject.SetActive(true);
                return;
            }
            else
            {
                mListEquipmentObjects[mListSelectEquipment.uniqueId].Select(false);
            }
        }
        mListSelectEquipment = model;
        mListEquipmentObjects[mListSelectEquipment.uniqueId].Select(true);
        newPanel.Setup(model);
        if (mCurrentCharacter.equipments.ContainsKey(mSlot))
        {
            newPanelEquipText.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Btn_Change");
        }
        else
        {
            newPanelEquipText.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT, "UI_Equip_Btn_Equip");
        }
        newPanel.gameObject.SetActive(true);
        eqpCloseArea.gameObject.SetActive(true);
        EquipmentViewModel currentEquipment = null;
        mCurrentCharacter.equipments.TryGetValue(mSlot, out currentEquipment);
        
        if (currentEquipment != null)
        {
            oldPanel.Setup(currentEquipment);
            oldPanel.gameObject.SetActive(true);
            oldPanel.ChangeBtnSetAvtive(false);
            // oldPanel.UnequipBtnSetAvtive(false);
            // bgObject.GetComponent<GraphicCast>().raycastTarget = true;
        }
        else
        {
            oldPanel.gameObject.SetActive(false);
        }
    }

    private void OnClickEquip()
    {
        if (mListSelectEquipment.equippedCharacter > 0)
        {
            UI.Popup.ShowConfirm(string.Empty, string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EQUIPMENT, "Confirm_EquipChange"), LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER_NAME, $"{mListSelectEquipment.equippedCharacter}")), CanvasType.App2, (r)=>
            {
                if (r == UIPopupDialog.Result.OK)
                {
                    AsyncManager.Instance.StartGuardAsync(ProcessEquipAsync());
                }
            });
        }
        else
        {
            AsyncManager.Instance.StartGuardAsync(ProcessEquipAsync());
        }
    }

    private async UniTask OnClickEnhanceEquipped()
    {
        EquipmentParam param = new EquipmentParam();
        param.model = mCurrentCharacter.equipments[mSlot];
        param.type = EquipmentMainPagePanelType.LevelUp;
        await UI.Page.OpenPage<UIHomeEquipmentMainPage>(param);
    }

    private async UniTask OnClickEnhanceSelected()
    {
        EquipmentParam param = new EquipmentParam();
        param.model = mListSelectEquipment;
        param.type = EquipmentMainPagePanelType.LevelUp;
        await UI.Page.OpenPage<UIHomeEquipmentMainPage>(param);
    }

    private async UniTask ProcessEquipAsync()
    {
        await CharacterService.SetEquipment(mCurrentCharacter.id, mListSelectEquipment.uniqueId, true);
        PxSoundManager.Instance.PlaySe("feedbackSE_mequ_equip01");
        mListSelectEquipment.equippedCharacter = mCurrentCharacter.id;

        if (mCurrentCharacter.equipments.ContainsKey(mSlot))
        {
            mListEquipmentObjects[mCurrentCharacter.equipments[mSlot].uniqueId].Model.equippedCharacter = 0;
            mListEquipmentObjects[mCurrentCharacter.equipments[mSlot].uniqueId].Setup(mListEquipmentObjects[mCurrentCharacter.equipments[mSlot].uniqueId].Model);
            mListEquipmentObjects[mCurrentCharacter.equipments[mSlot].uniqueId].SetSelectableStatus(true);
        }

        mCurrentCharacter.equipments[mSlot] = mListSelectEquipment;
        if (mSlotEquipmentObjects.ContainsKey(mSlot))
            Destroy(mSlotEquipmentObjects[mSlot].gameObject);
        await SetupEquipmentAsync(mSlot, mListSelectEquipment);

        mListEquipmentObjects[mCurrentCharacter.equipments[mSlot].uniqueId].Setup(mListSelectEquipment);

        mListEquipmentObjects[mCurrentCharacter.equipments[mSlot].uniqueId].SetSelectableStatus(false, LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Unit_Equip_SelectList_Equiping"));
        OnUpdateModel.Invoke(this.gameObject);
        oldPanel.gameObject.SetActive(false);
        newPanel.gameObject.SetActive(false);
        eqpCloseArea.gameObject.SetActive(false);
    }

    private async UniTask ProcessUnEquipAsync()
    {
        await CharacterService.SetEquipment(mCurrentCharacter.id, mCurrentCharacter.equipments[mSlot].uniqueId, false);
        PxSoundManager.Instance.PlaySe("feedbackSE_mequ_remove01");
        if (mListSelectEquipment !=null )
            mListSelectEquipment.equippedCharacter = 0;
        if (mListEquipmentObjects.ContainsKey(mCurrentCharacter.equipments[mSlot].uniqueId))
        {
            mListEquipmentObjects[mCurrentCharacter.equipments[mSlot].uniqueId].Model.equippedCharacter = 0;
            mListEquipmentObjects[mCurrentCharacter.equipments[mSlot].uniqueId].SetSelectableStatus(true);
        }

        mCurrentCharacter.equipments.Remove(mSlot);

        Destroy(mSlotEquipmentObjects[mSlot].gameObject);
        
        mSlotEquipmentObjects.Remove(mSlot);
        OnUpdateModel.Invoke(this.gameObject);
        oldPanel.gameObject.SetActive(false);
        newPanel.gameObject.SetActive(false);
        eqpCloseArea.gameObject.SetActive(false);
        selectPanel.SetActive(false);
    }

    private void OnClickBg()
    {
        if (oldPanel.gameObject.activeSelf || newPanel.gameObject.activeSelf)
        {
            oldPanel.gameObject.SetActive(false);
            newPanel.gameObject.SetActive(false);
        }
        else
        {
            selectPanel.SetActive(false);
        }

        if (mListSelectEquipment != null)
        {
            mListEquipmentObjects[mListSelectEquipment.uniqueId].Select(false);
            mListSelectEquipment = null;
        }

        foreach (var select in slotsSelects)
        {
            select.gameObject.SetActive(false);
        }
        // bgObject.GetComponent<GraphicCast>().raycastTarget = false;
    }


}
