﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UIHomeCharacterUnitSkillCellUI : MonoBehaviour
{
    public Toggle SelectToggle;
    public UIText statusText;
    public Image iconImage;
    public Image equippedHintIcon;

    public long Id;
    public bool IsEquipped;
    public bool IsPassive;

    public async UniTask SetupAsync(long skillId)
    {
        var master = DataManager.Instance.Master.Skill[skillId];
        string skillIconPath = master.iconPath;
        iconImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", skillIconPath);
    }

}
