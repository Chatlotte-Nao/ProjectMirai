﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using CharacterMain.UI;
using CharacterMain;

using TMPro;
using CharacterMain.Util;

public class UIHomeCharacterSelectSubWindow : UIDialogBase
{
    [SerializeField] UIButton backButton;
	[SerializeField] Image roleIcon = null;
	[SerializeField] Image attributeIcon = null;
	[SerializeField] UIText selectCharaNameText = null;
	[SerializeField] UIText selectCharaRarityText = null;
	[SerializeField] RarityIcon selectCharaRarityIcon = null;
	//[SerializeField] RoleIconData roleIconData = null;
	//[SerializeField] StatusIconData statusIconData = null;
	[SerializeField] RareLinePanel rareLineSwitcher = null;
    [SerializeField] UIText bondsPointText = null;

	[SerializeField] GameObject uiRoot = null;
	[SerializeField] GameObject selectChara = null;
	[SerializeField] CustomScrollRect charaPageCharaScrollRect = null;
	[SerializeField] float charaPageChangeCharacterScrollLength = 30;
	[SerializeField] GameObject subUIRoot = null;
	[SerializeField] UIText pageTitleText = null;
	[SerializeField] GameObject namePanelBase = null;
	[SerializeField] GameObject namePanelFooter = null;
    [SerializeField] TextMeshProUGUI selectCharaBgName = null;
    [SerializeField] Button charaPageLeftButton = null;
	[SerializeField] Button charaPageRightButton = null;
	[SerializeField] Button changeLeftButton = null;
	[SerializeField] Button changeRightButton = null;
	[SerializeField] Button filterButton = null;
	[SerializeField] Button sortButton = null;
	[SerializeField] Button sortOrderButton = null;
	[SerializeField] Button playerSelectFilterButton = null;
	[SerializeField] Button playerSelectSortButton = null;
	[SerializeField] Button playerSelectSortOrderButton = null;
	[SerializeField] UIText sortOrderButtonText = null;
	[SerializeField] CharacterPanelScrollRect charaPanelScrollRect = null;


    BattleCharacterDataEnumerator battleCharacterEnumerator;
	BattleCharacterDataEnumerator playerSelectEnumerator;


    private int currentClothesId = 0;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        var battleCharacterSortFilterSetting = new BattleCharacterDataEnumerator.SortFilterSetting
		{
			SortType = BattleCharacterDataEnumerator.SortType.Level,
			IsAscending = false
		};

		var playerSelectSortFilterSetting = new BattleCharacterDataEnumerator.SortFilterSetting
		{
			SortType = BattleCharacterDataEnumerator.SortType.Level,
			IsAscending = false
		};

		battleCharacterEnumerator = new BattleCharacterDataEnumerator(battleCharacterSortFilterSetting);
		playerSelectEnumerator = new BattleCharacterDataEnumerator(playerSelectSortFilterSetting);

		backButton.onClick.GuardSubscribeAsync(OnClickBackAsync).AddTo(mSubscriptions);
		charaPanelScrollRect.OnClickItem.GuardSubscribeAsync(onClickItem).AddTo(mSubscriptions);
    }

	private async UniTask OnClickBackAsync(GameObject o)
	{
		await UI.Page.CloseCurrentPage();
	}


    public async UniTask RefreshAsync(int characterId)
    {
        //var charalist = UserData.GetPlayerData().battleCharacterList;
		//BattleCharacterData chara = null;
		//foreach (var selectChara in charalist)
		//{
			//if (selectChara.master.characterId == characterId)
			//{
			//	chara = selectChara;
			//	break;
			//}
	//	}
	
		// var characterMaster = CharacterMaster.Get(characterId);
		//var clothesMaster = CharacterClothesMaster.Get(characterId, currentClothesId);

        //selectCharaBgName.text = characterMaster.name_English;

       // selectChara.GetComponent<Image>().sprite = await ResourceManager.Instance.LoadSpriteAsync("CharacterMain/Stand", clothesMaster.standImageName);
        selectChara.SetActive(true);

		//selectCharaNameText.SetRawText(characterMaster.name);


		//bondsPointText.SetRawText(chara.GetCharacterData().bondsData.bonds.ToString());

		//レアリティ設定
		//todo:突破行為があった場合更新の必要あり
		var rarityText = "";
		//switch (chara.rarity)
		//{
		//	case 2: rarityText = "★2"; break;
		//	case 3: rarityText = "★3"; break;
		//	case 4: rarityText = "★4"; break;
		//	case 5: rarityText = "★5"; break;
		//	case 6: rarityText = "★5+1"; break;
		//	case 7: rarityText = "★5+2"; break;
		//	case 8: rarityText = "★5+3"; break;
		//}

		selectCharaRarityText.SetRawText(rarityText);
		//selectCharaRarityIcon.SetRarity(chara.rarity, RarityIcon.RarityType.CHARACTER);
		//roleIcon.sprite = roleIconData.GetSprite(chara.master.role);
		//attributeIcon.sprite = statusIconData.GetAttributeIcon(chara.master.attributeId);
		//rareLineSwitcher.SetRareLineActive(chara.master.rarity);


        charaPanelScrollRect.ClearItems();

				if (battleCharacterEnumerator != null)
				{
					var filterSetting = battleCharacterEnumerator.Setting.FilterSetting;
					filterSetting.IsEnableCharacterFilter = true;
					filterSetting.FilterCharacterIdList.Clear();
					filterSetting.FilterCharacterIdList.Add(characterId);
					//battleCharacterEnumerator.SetSource(charalist);

					//charaPanelScrollRect.SetupItems(battleCharacterEnumerator.Enumerate(), charalist, battleCharacterEnumerator.Setting.SortType);
					charaPanelScrollRect.SelectItem(charaPanelScrollRect.FindCharaPanelIndex(0), 0.0f);
				}
    }

	private async UniTask onClickItem(int slotId)
	{
		var param = new UIHomeCharacterUnitPage.PageParam();
		param.characterId = slotId;
		await UI.Page.OpenPage<UIHomeCharacterUnitPage>(param);
	}
}
