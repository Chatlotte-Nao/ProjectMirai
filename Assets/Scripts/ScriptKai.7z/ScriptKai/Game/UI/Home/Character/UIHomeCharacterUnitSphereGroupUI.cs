﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIHomeCharacterUnitSphereGroupUI : MonoBehaviour
{
    public UIHomeCharacterUnitSphereCellUI[] cells;
    
}
