﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIHomeCharacterUnitSkinDialog : UIDialogBase
{
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }

    public async UniTask SetupAsync(CharacterViewModel model)
    {
    }
}
