﻿using Pheonix.Core;
using Spine.Unity;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;
using Base.Sound;
using UnityEngine.Events;

public class UIHomeCharacterUnitSignContract : UIDialogBase
{
    [SerializeField] RawImage standImage;
    [SerializeField] private GameObject lockObj;
    [SerializeField] private GameObject levelUpObj;
    [SerializeField] UIText beforeDesc;
    [SerializeField] UIText afterDesc;
    [SerializeField] UIText beforeApDesc;
    [SerializeField] UIText afterApDesc;
    [SerializeField] UITexture beforeImage;

    [SerializeField] UITexture afterImage;

    //
    [SerializeField] UIText textPro2;
    [SerializeField] UIText textPro1;
    UnityEvent<Func<GameObject, UniTask>> clos = new UnityEvent<Func<GameObject, UniTask>>();

    public ClickEvent hide = new ClickEvent();
    private bool isLevelUp;
    UIRTCamera mRTCamera = null;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        var rtc = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/RTCamera");
        mRTCamera = rtc.GetComponent<UIRTCamera>();
        lockObj.gameObject.SetActive(false);
        levelUpObj.gameObject.SetActive(false);
        closeButton.onClick.GuardSubscribeAsync(CloseButtonClick).AddTo(mSubscriptions);
        PxSoundManager.Instance.PlaySe("feedbackSE_character_yoke01");
    }

    public async UniTask SetupAsync(CharacterViewModel model)
    {
        isLevelUp = false;
        lockObj.gameObject.SetActive(true);
        SoundManager.StopBgm();
        beforeApDesc.SetRawText(DataManager.Instance.Master.BattleCharacter[model.id].initialAp.ToString());
        afterApDesc.SetRawText(model.ap.ToString());
        await LoadTextAsync(model.id);
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
    }

    public async UniTask LoadTextAsync(long characterId)
    {
        var resourceMaster = DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[characterId].characterResourceId];

        //temp
        GameObject loadCharacter = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/chara/" + resourceMaster.advModelId);
        SkeletonAnimation skeletonAnimation = loadCharacter.GetComponent<SkeletonAnimation>();
        skeletonAnimation.Initialize(false);
        skeletonAnimation.Update(0.0f);
        skeletonAnimation.LateUpdate();
        mRTCamera.Setup(loadCharacter);
        standImage.texture = mRTCamera.GetRenderTexture();
        //meDesc.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{model.meId}_desc");
    }

    public async UniTask SetUpLevelUpAsync(long characterId,int beforeLevel,int afterLevel)
    {
        isLevelUp = true;
        levelUpObj.gameObject.SetActive(true);
        await LoadTextAsync(characterId);
        await beforeImage.LoadAsync("Bond",beforeLevel.ToString(),false);
        await afterImage.LoadAsync("Bond",afterLevel.ToString(),false);
        beforeDesc.SetFormat(LocalizeManager.DATA_TYPE.BOND, "LvFormat",beforeLevel.ToString());
        afterDesc.SetFormat(LocalizeManager.DATA_TYPE.BOND, "LvFormat",afterLevel.ToString());

        textPro2.SetFormat(LocalizeManager.DATA_TYPE.BOND, beforeLevel.ToString());
        textPro1.SetFormat(LocalizeManager.DATA_TYPE.BOND, afterLevel.ToString());
    }

    public override void OnHide()
    {
        
        mRTCamera?.Dispose();
        Destroy(mRTCamera.gameObject);
        mRTCamera = null;
        base.OnHide();
        base.Dispose();
    }

    async UniTask CloseButtonClick(GameObject obj)
    {
        clos.Invoke(async (o) => { });
    }

    public async UniTask AddEndClick(Func<UniTask> func)
    {
        clos.RemoveAllListeners();
        clos.AddListener(async(o)=> { await func.Invoke(); });
    }
}
