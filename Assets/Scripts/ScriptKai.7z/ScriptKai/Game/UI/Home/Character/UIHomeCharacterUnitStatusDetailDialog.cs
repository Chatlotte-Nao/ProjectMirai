﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIHomeCharacterUnitStatusDetailDialog : UIDialogBase
{
    [SerializeField] UIText[] attributeText;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }

    public async UniTask SetupAsync(CharacterViewModel model)
    {
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;

            var str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, $"Attribute_{eAtt}_Format_WithEquip"), eAtt.GetAttributePercent(model.attributeDict[eAtt]), eAtt.GetAttributePercent(model.equipAttributeDict[eAtt]));
            attributeText[i-1].SetRawText($"{model.GetAttributeRateStr(eAtt)} {str}");
            //attributeText[i-1].SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, $"Attribute_{eAtt}_Format_WithEquip", model.attributeDict[eAtt], model.equipAttributeDict[eAtt])};
        }
    }
}
