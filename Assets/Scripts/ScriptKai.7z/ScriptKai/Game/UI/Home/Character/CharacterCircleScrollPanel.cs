﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class CharacterCircleScrollPanel : UIBehaviourComponent, ICircleScrollItem
{
    [SerializeField] RectTransform childRect;
    [SerializeField] UITexture charaTexture;
    [SerializeField] GameObject selectObject;


    public async UniTask SetupAsync(long characterId)
    {
        await charaTexture.LoadAsync("CharacterMain/CircleScrollPanel", characterId.ToString());
    }


    public void OnSelect()
    {
        childRect.anchoredPosition = new Vector2(-70, 0);
        selectObject.SetActive(true);
    }

    public void OnDeselect()
    {
        childRect.anchoredPosition = Vector2.zero;
        selectObject.SetActive(false);
    }
}
