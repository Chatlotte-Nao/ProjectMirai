﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Battle.Unity.BattleUI;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;
using Battle;
using Battle.Unity;

public class UIHomeCharacterUnitStatusDialog : UIDialogBase
{
    [SerializeField] UIText campText;
    [SerializeField] Image campIcon;
    [SerializeField] UIText jobText;
    [SerializeField] Image[] starts;
    [SerializeField] private Image jobIcon;
    [SerializeField] private Image jobattIcon;
    [SerializeField] UIText levelName;

    [SerializeField] UIText levelText;

    // [SerializeField] UIText expText;
    [SerializeField] Slider expSlider;
    [SerializeField] UIButton levelUpBtn;
    [SerializeField] RectTransform jobIconsPar;


    [SerializeField] private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();


    [SerializeField] UIText meDescText;
    [SerializeField] UIText meNameText;
    [SerializeField] Image skillIcon;
    [SerializeField] UIText skillText;
    [SerializeField] UIButton skillChangeBtn;
    [SerializeField] UIButton skillChangeBtn1;
    [SerializeField] UIButton skillChangeBtn2;
    [SerializeField] private UIButton skillChangeBigBtn2;
    [SerializeField] private Image[] skillImage;
    [SerializeField] private UISkillCommandDetailPanel commandDetailPanel;
    [SerializeField] private List<UIButton> skillButtons;
    [SerializeField] UIButton closeDetailButton;
    [SerializeField] private GameObject expGroup;
    [SerializeField] private GameObject levelMax;
    [SerializeField] private UIText[] skillLockText;
    [SerializeField] UIText apNameText;
    [SerializeField] GameObject adddIcon;

    [SerializeField] UIButton arributeDetails;
    [SerializeField] private List<Image> tagImages;

    CharacterViewModel _model;
    // public UILongEvent SendClickSkillID=new UILongEvent();

    // public ClickEvent OnShowDetail => detailBtn.onClick;
    public UILongEvent OnSkillChange = new UILongEvent();

    List<GameObject> professionIcons = new List<GameObject>();
    List<GameObject> usingProfessionIcons = new List<GameObject>();
    public ClickEvent OnLevelUp => levelUpBtn.onClick;
    public UnityEvent arriButeBtnClick => arributeDetails.OnTouchDown;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        closeDetailButton.OnTouchUpInside.Subscribe(()=> commandDetailPanel.Hide()).AddTo(mSubscriptions);
        skillChangeBtn1.OnTouchUpInside.Subscribe(() =>
        {
            OnSkillChange.Invoke(_model.selectedSkills[1]);
        }).AddTo(mSubscriptions);
        skillChangeBtn.OnTouchUpInside.Subscribe(() =>
        {
            OnSkillChange.Invoke(_model.selectedSkills[0]);
        }).AddTo(mSubscriptions);
        skillChangeBtn2.OnTouchUpInside.Subscribe(() =>
        {
            //if (_model.skillSlotStatus[2] > 0)
            {
                OnSkillChange.Invoke(_model.selectedSkills.Count > 2 ? _model.selectedSkills[2]:0);
            }
        }).AddTo(mSubscriptions);
        skillChangeBigBtn2.OnTouchUpInside.Subscribe(() =>
        {
            //if (_model.skillSlotStatus[2] > 0)
            {
                OnSkillChange.Invoke(_model.selectedSkills.Count > 2 ? _model.selectedSkills[2]:0);
            }
        }).AddTo(mSubscriptions);

    }

    public async UniTask SetupAsync(CharacterViewModel model)
    {
        //await SetProfession(model.id);
        commandDetailPanel.gameObject.SetActive(false);
        _model = model;
        var characterMaster = DataManager.Instance.Master.BattleCharacter[model.id];
        var attrMaster =DataManager.Instance.Master.Attribute[characterMaster.attribute];
        apNameText.SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Unit_Ap_Number",model.ap);
        //rarityIcon.SetRarity(model.rank, RarityIcon.RarityType.CHARACTER);
        //for (int i = 0; i < tagImages.Count;i++)
        //{
        //    if (characterMaster.characterTags.Count <= i)
        //    {
        //        tagImages[i].sprite = await ResourceManager.Instance.LoadSpriteAsync("Camp", characterMaster.characterTags[i].ToString());
        //        tagImages[i].gameObject.SetActive(true);
        //    }
        //    else
        //    {
        //        tagImages[i].gameObject.SetActive(false);
        //    }
        //}
        foreach (var parameter in tagImages)
        {
            parameter.gameObject.SetActive(false);
        }
        for (int i = 0; i < characterMaster.characterTags.Count; i++)
        {
            //var iconName = "";
            //if (characterMaster.characterTags[i] < 10)
            //{
            //    iconName = $"icon_zya_0{characterMaster.characterTags[i]}";
            //}
            //else
            //{
            //    iconName = $"icon_zya_{characterMaster.characterTags[i]}";
            //}
            //tagImages[i].sprite = await ResourceManager.Instance.LoadSpriteAsync("Camp", iconName);
            tagImages[i].sprite = await ResourceManager.Instance.LoadSpriteAsync("Camp", AssetPath.CharacterTagIcons[characterMaster.characterTags[i]]);
            tagImages[i].gameObject.SetActive(true);
        }

        for (int i = 0; i < starts.Length; i++)
        {
            starts[i].gameObject.SetActive(false);
        }
        for (int i = 0;i<model.rank;i++)
        {
            starts[i].gameObject.SetActive(true);
        }
        jobText.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, string.Format("Job_{0}", ((CharacterRole)characterMaster.job).ToString()));


        var jobMaster = DataManager.Instance.Master.Job[characterMaster.job];
        //new
        jobIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("Job", jobMaster.IconPath);
        jobattIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("Attribute", attrMaster.IconPath);
        levelName.SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, "CHARACTER_SORT_LV");
        levelText.SetRawText(string.Format("{0}<color=#969593>/{1}</color>", model.level, model.maxLevel));
        // expText.SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Status_Exp_Format", model.curExp, model.maxExp);
        if (model.level == DataManager.Instance.Master.CharacterGradeUp[model.grade].levelCap)
        {
            // expText.SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Status_Exp_Format", model.maxExp, model.maxExp);
            expGroup.SetActive(false);
            levelMax.SetActive(true);
        }
        else
        {
            expGroup.SetActive(true);
            levelMax.SetActive(false);
        }
        
        expSlider.value = model.maxExp == 0 ? 0 : (float)model.curExp / model.maxExp;
        
        for (int i = 1; i < (int)CharacterAttribute.Crt; i++)
        {
            CharacterAttribute en = (CharacterAttribute) i;
            attributeList[i-1].SetupText(en,en.GetAttributePercent(model.attributeDict[en]+model.equipAttributeDict[en]));
        }
        
        meNameText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{model.meId}_name");
        meDescText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{model.meId}_desc");
        SkillMaster master = DataManager.Instance.Master.Skill[model.meId];
        //skillIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", master.iconPath);
        skillIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", "icon_jineng_tianfu_dazhao_w");
        skillText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "UNION_LEVEL_FORMAT", model.rank.ToString());
        
        //selectedSkills
        var selectedSkillLength = 3;
        for (int i = 0; i < skillImage.Length; i++)
        {
            switch (i)
            {
                case 0:
                case 1:
                    await setSkillImage(skillImage[i], model.selectedSkills[i], skillButtons[i]);
                    break;
                 case 2:
                //     SetPassiveLock(skillButtons[i], model.skillSlotStatus[i] == 0);
                //     skillLockText[i].gameObject.SetActive(model.skillSlotStatus[i] == 0);
                //     skillChangeBtn2.gameObject.SetActive(model.selectedSkills.Count > i);
                //     skillChangeBigBtn2.gameObject.SetActive(model.selectedSkills.Count <= i);
                //     skillLockText[i].SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, "Skill_Contract_Lock");
                     skillChangeBigBtn2.gameObject.SetActive(model.selectedSkills.Count <= i);
                     await setSkillImage(skillImage[i], model.selectedSkills.Count > i ? model.selectedSkills[i] : 0, skillButtons[i]);
                    if (model.selectedSkills.Count > i)
                    {
                        adddIcon.SetActive(false);
                    }
                    else
                    {
                        adddIcon.SetActive(true);
                    }
                    break;
                case 3:
                case 4:
                    if (i - selectedSkillLength < model.passiveSkills.Count)
                    {
                        SetPassiveLock(skillButtons[i], false);
                        skillLockText[i - selectedSkillLength].gameObject.SetActive(false);
                        await setSkillImage(skillImage[i], model.passiveSkills[i - selectedSkillLength],
                            skillButtons[i]);
                    }
                    else
                    {
                        SetPassiveLock(skillButtons[i], true);
                        var characterMasters = DataManager.Instance.Master.CharacterPanel.Values.Where(a =>
                            a.battleCharacterMasterId == model.id && a.getSkillId > 0);
                        var skills = characterMasters
                            .Where(a => DataManager.Instance.Master.Skill[a.getSkillId].skillType == 3).ToArray();
                        skillLockText[i - selectedSkillLength].gameObject.SetActive(true);
                        var isSkill = skills.Length > i - selectedSkillLength;
                        if (isSkill)
                        {
                            skillLockText[i - selectedSkillLength].SetFormat(LocalizeManager.DATA_TYPE.CHARACTER,
                                $"CHARACTER_SKILL_Lock", skills[i - selectedSkillLength].getBattleCharacterGrade);
                        }

                        await setSkillImage(skillImage[i], isSkill?skills[i - selectedSkillLength].getSkillId:0, skillButtons[i]);
                    }
                    break;
            }
        }
    }

    public async UniTask SetProfession(long id)
    {
        Debug.Log($"Profession   {id}    {DataManager.Instance.Master.BattleCharacter[id].job}");
        foreach (var item in DataManager.Instance.Master.Job)
        {
            Debug.Log($"{item.Key}    {item.Value}   {item.Value.IconPath}    {item.Value.id}");
        }
        foreach (var item in usingProfessionIcons)
        {
            professionIcons.Add(item);
        }
        usingProfessionIcons.Clear();

        var sprite = await ResourceManager.Instance.LoadSpriteAsync("Job", DataManager.Instance.Master.Job[DataManager.Instance.Master.BattleCharacter[id].job].IconPath);
        GameObject icon = null;
        if (professionIcons.Count != 0)
        {
            icon = professionIcons[0];
            professionIcons.Remove(icon);
        }
        else
        {
            icon = new GameObject("Job Icon");
            icon.AddComponent<Image>();
            icon.AddComponent<RectTransform>();
            icon.GetComponent<RectTransform>().SetParent(jobIconsPar);
            icon.GetComponent<RectTransform>().SetPositionAndRotation(new Vector3(0, 0, 0), Quaternion.Euler(0, 0, 0));
            icon.GetComponent<RectTransform>().sizeDelta = new Vector2(sprite.rect.width, sprite.rect.width);
            icon.GetComponent<RectTransform>().localPosition = new Vector3(0, 0, 0);
        }
        icon.GetComponent<Image>().sprite = sprite;
        usingProfessionIcons.Add(icon);
    }

    private void SetPassiveLock(UIButton passiveLock,bool isLock)
    {
        passiveLock.transform.GetChild(0).gameObject.SetActive(isLock);
    }

    private async UniTask setSkillImage(Image image,long skillId,UIButton skillButtonp = null)
    {
        if (skillId > 0)
        {
            image.enabled = true;
            SkillMaster master = DataManager.Instance.Master.Skill[skillId];
            string skillIconPath = master.iconPath;
            image.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", skillIconPath);
            if (skillButtonp != null)
            {
                skillButtonp.OnTouchUpInside.RemoveAllListeners();
                skillButtonp.OnTouchUpInside.Subscribe(() => SkillData(skillId)).AddTo(mSubscriptions);
            }
        }
        else
        {
            //image.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", "zz_jinengbj2");
            image.enabled = false;
        }

    }

    public void SkillData(long skillId)
    {
        commandDetailPanel.Show();
        commandDetailPanel.Refresh((int)_model.id,skillId,true);
    }
}
