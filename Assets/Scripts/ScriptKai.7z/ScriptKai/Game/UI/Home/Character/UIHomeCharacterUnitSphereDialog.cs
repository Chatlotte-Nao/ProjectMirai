﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using System.Linq;
using System.Text;

public class UIHomeCharacterUnitSphereDialog : UIDialogBase
{
    [SerializeField] UIHomeCharacterUnitSphereGroupUI[] panels;

    
    [SerializeField] GameObject skillGroup;
    [SerializeField] Image skillIconImage;
    [SerializeField] private UISkillCommandDetailPanel commandDetailPanel;
    [SerializeField] UIButton skillIconButton;
    
    [SerializeField] UIText skillText;
    [SerializeField] GameObject attributeGroup;
    [SerializeField] BaseAttributeUp[] attributeText;
    [SerializeField] UIText infoGetText;
    [SerializeField] GameObject processGroup;
    [SerializeField] BaseItem[] useItems;
    [SerializeField] BaseResource useMoneyText;
    [SerializeField] UIButton processBtn;
    [SerializeField] UIText requireLevelText;
    

    [SerializeField] GameObject activatedGroup;


    [SerializeField] UIButton showListBtn;
    [SerializeField] GameObject listPanelObject;
    [SerializeField] RectTransform UpPreviewContent;

    // [SerializeField] private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();
    
    [SerializeField] BaseAttributeUp statusHpText;
    [SerializeField] BaseAttributeUp statusAtkText;
    [SerializeField] BaseAttributeUp statusDefText;
    [SerializeField] BaseAttributeUp statusMAtkText;
    [SerializeField] BaseAttributeUp statusMDefText;
    [SerializeField] BaseAttributeUp statusSpdText;
    
    
    [SerializeField] UIButton closeListPanelBtn;
    [SerializeField] UIText attritubeText;
    [SerializeField] private UIHomeCharacterUpPreview[] upPreviews;
    public UILongEvent OnProcess = new UILongEvent();

    [SerializeField] private BaseAttributeUp prefab;
    [SerializeField] private RectTransform attributeTransform;
    private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();
    private long mSelectPanel = 0;
    private int currentLevel = 0;
    private Image greadImage;
    private UIHomeCharacterUnitSphereCellUI sphereCell = null;
    CharacterViewModel _model;
    private UIHomeCharacterUnitSphereGroupUI panel;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        greadImage = processBtn.GetComponent<Image>();
        // foreach (var p in panels)
        // {
        //     foreach (var cell in p.cells)
        //     {
        //         var c = cell;
        //         c.SelectToggle.onValueChanged.Subscribe((v)=>
        //         {
        //             if (v)
        //             {
        //                 OnSelectPanel(c);
        //             }
        //         }).AddTo(mSubscriptions);   
        //     }
        // }
        

        processBtn.OnTouchUpInside.Subscribe(OnClickProcess).AddTo(mSubscriptions);
        showListBtn.OnTouchUpInside.Subscribe(OnClickShowList).AddTo(mSubscriptions);
        closeListPanelBtn.OnTouchUpInside.Subscribe(OnClickHideList).AddTo(mSubscriptions);
    }

    public async UniTask SetupAsync(CharacterViewModel model)
    {
        listPanelObject.SetActive(false);

        _model = model;

        for (int i = 0; i < upPreviews.Length; i++)
        {
            await upPreviews[i].SetUpAsync(i,model);
        }
        
        var garde = model.grade;
        for (int i = 0; i < panels.Length; i++)
        {
            panels[i].gameObject.SetActive(false);
            if (i == 0)
            {
                panel = panels[i];
                panels[i].gameObject.SetActive(true);
            }
            if ((i + 1) == model.grade/2)
            {
                panel = panels[i];
                panel.gameObject.SetActive(true);
            }
            //panels[i].gameObject.SetActive((i+1) == model.grade);
   
            
        }

        // if (model.grade == 13)
        // {
        //     panels[model.grade - 2].gameObject.SetActive(true);
        //     garde = panels.Length;
        // }
        

        currentLevel = model.level;
       
        var panelList = DataManager.Instance.Master.CharacterPanel.Values.Where(x => (x.battleCharacterMasterId == model.id && x.pageId == garde)).OrderBy(x => x.id).ToList();
        if(panelList.Count<=0)
            panelList = DataManager.Instance.Master.CharacterPanel.Values.Where(x => (x.battleCharacterMasterId == model.id && x.pageId == garde-1)).OrderBy(x => x.id).ToList();
        bool unlockCenter = true;
        sphereCell = null;
        var cells = panel.cells;
        for (int i = 0; i < panelList.Count; i++)
        {
            cells[i].Id = panelList[i].id;
            var c = cells[i];
            c.SelectToggle.onValueChanged.RemoveAllListeners();
            c.SelectToggle.onValueChanged.Subscribe((v)=>
            {
                if (v)
                {
                    OnSelectPanel(c);
                }
            }).AddTo(mSubscriptions);   
            if (model.unlockedPanels.Contains(cells[i].Id))
            {
                cells[i].ActiveObject?.SetActive(true);
            }
            else
            {
                cells[i].ActiveObject?.SetActive(false);
                if (cells[i].IsCenterCell)
                {
                    cells[i].UnlockObject.SetActive(unlockCenter);
                    cells[i].SelectToggle.interactable = unlockCenter;
                    if (unlockCenter)
                        cells[i].SelectToggle.isOn = true;
                }
                else
                {
                    if (unlockCenter)
                    {
                        unlockCenter = false;
                        cells[i].SelectToggle.isOn = true;
                        OnSelectPanel(cells[i]);
                    }
                }
            }

        }
        
        
         statusHpText.SetupText(CharacterAttribute.Hp,model.sphereAttributeDict[CharacterAttribute.Hp].ToString());
         statusAtkText.SetupText(CharacterAttribute.PAtk,model.sphereAttributeDict[CharacterAttribute.PAtk].ToString());
         statusDefText.SetupText(CharacterAttribute.PDef,model.sphereAttributeDict[CharacterAttribute.PDef].ToString());
         statusMAtkText.SetupText(CharacterAttribute.MAtk,model.sphereAttributeDict[CharacterAttribute.MAtk].ToString());
         statusMDefText.SetupText(CharacterAttribute.MDef,model.sphereAttributeDict[CharacterAttribute.MDef].ToString());
         statusSpdText.SetupText(CharacterAttribute.Spd,model.sphereAttributeDict[CharacterAttribute.Spd].ToString());
       
        if (sphereCell != null)
        {
            OnSelectPanel(sphereCell);
        }
        else
        {
            OnSelectPanel(cells[4]);
            cells[4].SelectToggle.isOn = true;
        }
    }


    private void OnSelectPanel(UIHomeCharacterUnitSphereCellUI cell)
    {
        if (cell.Id == 0)
            return;
        sphereCell = cell;    
        mSelectPanel = cell.Id;
        var data = DataManager.Instance.Master.CharacterPanel[mSelectPanel];
    
        if (data.getSkillId > 0)
        {
            SkillMaster master = DataManager.Instance.Master.Skill[data.getSkillId];
            string skillIconPath = master.iconPath;
            if (skillIconImage != null)
            {
                //new
                AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(skillIconPath); });
                //skillIconImage.sprite = ResourceManager.Instance.LoadSprite("SkillIcon", skillIconPath);
                skillIconButton.onClick.RemoveAllListeners();
                skillIconButton.onClick.AddListener((o) =>
                {
                    
                    commandDetailPanel.Show();
                    commandDetailPanel.Refresh((int)_model.id,data.getSkillId,true);
                });
            }
            skillText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{data.getSkillId}_name");
            skillGroup.SetActive(true);
            infoGetText.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, $"UI_Unit_Sphere_SkillGet");


        }
        else
        {
            skillGroup.SetActive(false);
            infoGetText.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, $"UI_Unit_Sphere_AttributeGet");
        }

        if (data.getAttributes.Count > 0 && data.getSkillId <= 0)
        {
             attributeGroup.SetActive(true);
             foreach (var attribute in attributeList)
            {
                attribute.gameObject.SetActive(false);
            }
        
            int  index = 0;
            var attrDict = data.GetAttribute();
            foreach (var attr in attrDict)
            {
                CharacterAttribute eAtt = attr.Key;
                var value = attr.Value;
                if (value > 0 )
                {
                    if (index < attributeList.Count)
                    {
                        attributeList[index].SetupText(eAtt, eAtt.GetAttributePercent(value));
                        attributeList[index].gameObject.SetActive(true);
                    }
                    else
                    { 
                        var attribute = Instantiate(prefab, this.attributeTransform, false);
                        attribute.SetupText(eAtt,eAtt.GetAttributePercent(value));
                        attribute.gameObject.SetActive(true);
                        attributeList.Add(attribute);
                    }
                    index++;
                }
            }

        }
        else
        {
            attributeGroup.SetActive(false);
        }
        
        if (data.getVoiceId != string.Empty)
        {
        }
        
        if (cell.IsActivated)
        {
            processGroup.SetActive(false);
            activatedGroup.SetActive(true);
        }
        else
        {
            processGroup.SetActive(true);
            activatedGroup.SetActive(false);
            greadImage.color = CharacterUtil.IsGradeUp(mSelectPanel) ? Color.white : Color.black;
            foreach (var useItem in useItems)
            {
                useItem.gameObject.SetActive(false);
            }
            int idx = 0;

            foreach (var item in data.requireContents)
            {
                var s = item.Split(':');
                var id = long.Parse(s[0]);

                if (DataManager.Instance.Master.Content[id].contentTypeMasterId == 106)
                {
                    useMoneyText.SetupNeed(id, long.Parse(s[1]));
                }
                else
                {
                    useItems[idx].gameObject.SetActive(true);
                    useItems[idx++].SetupNeed(id, long.Parse(s[1]));
                }
            }

            if (data.requireBattleCharacterLv > currentLevel)
            {
                //processBtn.gameObject.SetActive(false);
                requireLevelText.gameObject.SetActive(true);
                greadImage.color = Color.black;
                requireLevelText.SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Unit_Sphere_RequireLevel_Format", data.requireBattleCharacterLv);
            }
            else
            {
                requireLevelText.gameObject.SetActive(false);
            }
        }
    }


    private void OnClickProcess()
    {
        OnProcess.Invoke(mSelectPanel);
    }

    private void OnClickShowList()
    {
        listPanelObject.SetActive(true);
        UpPreviewContent.anchoredPosition = Vector2.zero;

    }
    private void OnClickHideList()
    {
        listPanelObject.SetActive(false);
    }

    private async UniTask LoadSpriteAsync(string skillIconPath)
    {
        skillIconImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", skillIconPath); 
    }
}
