﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Linq;
using Base.Sound;
using UnityEngine.UI;
using TMPro;

public class UIHomeCharacterSelectMainWindow : UIDialogBase
{

    //[SerializeField] CircleScroll characterScrollManager;
	[SerializeField] UIButton backButton;
	// [SerializeField] RawImage characterImage;
	[SerializeField] UIButton detailButton;
	// [SerializeField] UIButton homeButton;
	// [SerializeField] UIButton navigationButton;
	[SerializeField] UIButton gachaButton;
	[SerializeField] UIHomeCharacterSelectObject characterObject;
	[SerializeField] RectTransform characterObjectRT;
	[SerializeField] Transform content;
	[SerializeField] VerticalLayoutGroup contentVLG;
	[SerializeField] RectTransform contentRT;
	[SerializeField] UIText nameText;
	//[SerializeField] Image[] starts;
	[SerializeField] Image bgImage;
	[SerializeField] private CharacterTouchHandler touchChara;
	// UIRTCamera mRTCamera = null;

	[SerializeField] private ScrollRect scrollrect;
	public ClickEvent OnBackClick => backButton.onClick;
	List<long> mSlots = new List<long>();
	private float mLastChangeTime = -1f;
	private int mCurrentDisplaySlot = -1;
	List<UIHomeCharacterSelectObject> mObjects = new List<UIHomeCharacterSelectObject>();
	private long currentCharacterId = -1;
	public ClickEvent OnGachaClick => gachaButton.onClick;
	private bool init = true;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        init = true;
		detailButton.OnTouchUpInside.GuardSubscribeAsync(onClickDetail).AddTo(mSubscriptions);
		// homeButton.OnTouchUpInside.GuardSubscribeAsync(onClickHome).AddTo(mSubscriptions);

		
		await touchChara.Init(true,-1f,0,0f);
		

    }



    private UIPageShowType _showType;
async UniTask onClickHome()
    {
	    UI.Popup.ShowConfirm(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "MEPOWERUP_START_CONFIRM_TITLE"), LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "ShowConfirm_Back2Home"), CanvasType.App2, (r)=>
	    {
		    if (r == UIPopupDialog.Result.OK)
		    {
			    AsyncManager.Instance.StartGuardAsync(async()=>
			    {

				    HomeSceneParam p = new HomeSceneParam();
				    var t=MapSceneManager.Instance.CurrentType;
				    switch (t)
				    {
					    case MapSceneManager.SceneType.Home:
						    OnBackClick.Invoke(gameObject);
						    return;
					    
					    case MapSceneManager.SceneType.None:
						    p.enterType = HomeSceneParam.EnterType.DoNothing;
						    break;
					    case MapSceneManager.SceneType.Adv:
						    p.enterType = HomeSceneParam.EnterType.FromStory;
						    break;
					    case MapSceneManager.SceneType.Dungeon:
						    p.enterType = HomeSceneParam.EnterType.FromStory;
						    break;
					    case MapSceneManager.SceneType.BattleZone:
						    p.enterType = HomeSceneParam.EnterType.FromBattle;
						    break;
					    case MapSceneManager.SceneType.Tutorial:
						    p.enterType = HomeSceneParam.EnterType.Turotial;
						    break;
						    
				    }
                    
				    await GameSceneManager.Instance.ChangeSceneAsync<HomeScene>("HomeScene", p);
			    });
		    }
	    });
    }
    async UniTask onClickNavigation()
    {
	    var dialog= await UI.Dialog.CreateAsync(UIPrefabId.UIHomeNavigationWindow, CanvasType.App1) as UIHomeNavigationWindow;
	    await dialog.SetUpOutSide();
	    await dialog.ShowAsync(UIPageShowType.Front);
	    await dialog.OpenNavigationGroupOutSide();
    }	
    public override async UniTask ShowAsync(UIPageShowType showType)
	{
		_showType = showType;
	    await OnInitCharacterViewList();
		await base.ShowAsync(showType);
	    // mRTCamera.gameObject.SetActive(true);
    }
	
	public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);

        // mRTCamera.gameObject.SetActive(false);
    }

	public override void Dispose()
	{
		base.Dispose();
		touchChara?.Dispose();
		// mRTCamera.Dispose();
	}



	private async UniTask UpdateDisplayCharacter()
	{
        //if (characterScrollManager.currentSlotId == mCurrentDisplaySlot) return;

        //var charaId = mSlots[characterScrollManager.currentSlotId];

        if (DataManager.Instance.Player.Character.TryGet(currentCharacterId) == null)
        {
            detailButton.gameObject.SetActive(false);
        }
        else
        {
            detailButton.gameObject.SetActive(true);
        }

        var resourceMaster = DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[currentCharacterId].characterResourceId];

        // mRTCamera.Setup("Adventure/Objects/chara/" + resourceMaster.advModelId, "99_");

        var t = currentCharacterId;

        touchChara.guardTime = 0f;
        await touchChara.RefreshChara((int)currentCharacterId);
        touchChara.PlayOpenning("99_");
        touchChara.guardTime = 1f;
        
		//var mCharacterViewModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.GetList()[(int)currentCharacterId], DataManager.Instance.Player.Equipment.GetList());
		nameText.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER_NAME, currentCharacterId.ToString());

		var nameTextMeshPro = nameText.GetComponent<TextMeshProUGUI>();
		string firstWord = nameTextMeshPro.text.ToString()[0].ToString();
		string nameLast1 = nameTextMeshPro.text.ToString().Substring(1);

		string nameFirst = "<size=54>" + firstWord + "</size>";
		string nameLast2 = "<color=#672972>" + nameLast1 + "</color>";
		nameTextMeshPro.text = nameFirst + nameLast2;
		bgImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("CharacterMain/BgCutin", resourceMaster.bgCutinName);
		CharacterViewModel mCharacterViewModel = new CharacterViewModel();
		int idx = 0;
		foreach (var ch in DataManager.Instance.Player.Character.GetList())
		{
			
			if (ch.BattleCharacterMasterId == currentCharacterId)
			{
				mCharacterViewModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.GetList()[idx], DataManager.Instance.Player.Equipment.GetList());
				break;
			}
			idx++;
		}

		//for (int i = 0; i < starts.Length; i++)
		//{
		//	starts[i].gameObject.SetActive(false);
		//}
		//for (int i = 0; i < mCharacterViewModel.rank; i++)
		//{
		//	starts[i].gameObject.SetActive(true);
		//}
		//var characterRankMaster = DataManager.Instance.Master.CharacterRankUp.Values.FirstOrDefault((r) => (r.battleCharacterMasterId == model.id && r.rank == model.rank + 1));
		//if (characterRankMaster != null)
		//{
		//	rankUpItem.gameObject.SetActive(true);
		//	var item = characterRankMaster.requireContents[0].Split(':');
		//	rankUpItem.SetupNeed(long.Parse(item[0]), long.Parse(item[1]));
		//}
		//else
		//{
		//	rankUpItem.gameObject.SetActive(false);
		//}

		//mLastChangeTime = -1f;
		//mCurrentDisplaySlot = characterScrollManager.currentSlotId;
	}



	private async UniTask OnClickBackAsync(GameObject o)
	{
		await UI.Page.CloseCurrentPage();
	}

	async UniTask OnUpdateCharacterViewList()
	{
		foreach (var mObject in mObjects)
		{
			await mObject.SetupAsync(mObject.currentMasterId);
			if (mObject.currentMasterId != currentCharacterId)
			{
				mObject.OnDeselect();
			}
			else
			{
				mObject.OnSelect();
			}
		}
	}

	async UniTask OnInitCharacterViewList()
	{
		var characterMasters = DataManager.Instance.Master.BattleCharacter.Values.Where(master => (master.characterTypeId == 1)).OrderBy(master => master.sortId);
		int index = 0;
		foreach(var characterMaster in characterMasters)
		{
			if (DataManager.Instance.Player.Character.TryGet(characterMaster.id) == null) continue;
			if ( index < mObjects.Count())
			{
				mObjects[index].OnDeselect();
				await mObjects[index].SetupAsync(characterMaster.id);
			}
			else
			{
				GameObject go = Instantiate(characterObject.gameObject, content);
				var cell = go.GetComponent<UIHomeCharacterSelectObject>();
				await cell.SetupAsync(characterMaster.id);
				cell.OnClick.Subscribe(onSelectCharacter).AddTo(mSubscriptions);
				//mItems.Add(item.Key, cell);
				mObjects.Add(cell);
				go.SetActive(true);
			}
			//var t = characterScrollManager.AddSlot();
			//await t.GetComponent<CharacterCircleScrollPanel>().SetupAsync(characterMaster.id);
			//mSlots.Add(characterMaster.id);
			index++;
		}
		contentRT.sizeDelta = new Vector2(contentRT.sizeDelta.x, (characterObjectRT.sizeDelta.y + contentVLG.spacing) * mObjects.Count);
		if (_showType == UIPageShowType.Front)
		{
			currentCharacterId = mObjects.ElementAt(0).currentMasterId;
			mObjects.ElementAt(0).OnSelect();
			scrollrect.verticalNormalizedPosition = 1;
		}
		else
		{
			//mObjects[currentCharacterId].OnSelect();
			var cell = mObjects.First(a => a.currentMasterId == currentCharacterId);
			cell.OnSelect();
		}

		//onSelectCharacter(mObjects.ElementAt(0).Value.gameObject.GetComponentInChildren<UIButton>().gameObject);
		await UpdateDisplayCharacter();

	}


	private void onSelectCharacter(GameObject o)
	{
		//show character
		//mLastChangeTime = Time.realtimeSinceStartup;
		
		var cell = o.GetComponentInParent<UIHomeCharacterSelectObject>();
		if(cell.currentMasterId != currentCharacterId && currentCharacterId > 0)
        {
	        var oldEll = mObjects.First(a => a.currentMasterId == currentCharacterId);
	        oldEll.OnDeselect();
        }
		currentCharacterId = cell.currentMasterId;
		cell.OnSelect();
		SoundManager.StopVoice();
		AsyncManager.Instance.StartAsync(UpdateDisplayCharacter());
		

	}


	private async UniTask onClickDetail()
	{
		var param = new UIHomeCharacterUnitPage.PageParam();
		param.characterId = currentCharacterId;
		await UI.Page.OpenPage<UIHomeCharacterUnitPage>(param);
	}
	
}
