﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Takasho.Schema.Score.PlayerApi;

public class UIHomeCharacterUnitPage : UIPageBase
{
    private PageParam.ShowType _showType = PageParam.ShowType.Status;
    private UICommonCharacterArributeDetailsDialog arributeDetails;
    UIHomeHeaderParam headerParam = new UIHomeHeaderParam();

    private CharacterViewModel mCharacterViewModel = null;
    private int mCurrentCharacterIndex = 0;


    private UIDialogBase mCurrentDialog = null;
    private int mCurrentTab = 1;
    private UIHomeCharacterUnitEquipmentDialog mEquipmentDialog = null;
    private UIHomeCharacterUnitFetterDialog mFetterDialog = null;
    private UIHomeCharacterUnitGamutDialog mGamutDialog = null;
    private UIHomeCharacterUnitGamutRankUpDialog mGamutRankUp = null;

    private UIHomeCharacterUnitLevelUpDialog mLevelUp = null;
    private UIHomeCharacterUnitWindow mMainWindow = null;
    private int mMaxNum = 0;
    private UIHomeCharacterUnitMenu mMenu = null;
    private UIHomeCharacterUnitRankUpDialog mRankUp = null;
    private UIHomeCharacterUnitSignContract mSignContract = null;
    private UIHomeCharacterUnitSkillDialog mSkillDetail = null;
    private UIHomeCharacterUnitSkinDialog mSkinDialog = null;
    private UIHomeCharacterUnitSphereDialog mSphereDialog = null;
    private UIHomeCharacterUnitSphereLevelUpDialog mSphereUp = null;

    private UIHomeCharacterUnitStatusDetailDialog mStatusDetail = null;
    private UIHomeCharacterUnitStatusDialog mStatusDialog = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync();
        var pParam = param as PageParam;
        mCurrentCharacterIndex = 0;
        int idx = -1;
        foreach (var ch in DataManager.Instance.Player.Character.GetList())
        {
            idx++;
            if (ch.BattleCharacterMasterId == pParam.characterId)
            {
                mCurrentCharacterIndex = idx;
                break;
            }
        }

        _showType = pParam.showType;
        mMaxNum = DataManager.Instance.Player.Character.GetList().Count;
        
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterUnitWindow, CanvasType.App0) as UIHomeCharacterUnitWindow;

        mStatusDialog = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterUnitStatusDialog, CanvasType.App0) as UIHomeCharacterUnitStatusDialog;
        mEquipmentDialog = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterUnitEquipmentDialog, CanvasType.App0) as UIHomeCharacterUnitEquipmentDialog;
        mSphereDialog = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterUnitSphereDialog, CanvasType.App0) as UIHomeCharacterUnitSphereDialog;
        mSkinDialog = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterUnitSkinDialog, CanvasType.App0) as UIHomeCharacterUnitSkinDialog;
        mMenu = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterUnitMenu, CanvasType.App0) as UIHomeCharacterUnitMenu;
        mFetterDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeCharacterUnitFetterDialog, CanvasType.App0) as UIHomeCharacterUnitFetterDialog;
        mGamutDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeCharacterUnitGamutDialog, CanvasType.App0) as UIHomeCharacterUnitGamutDialog;
        arributeDetails = await UI.Dialog.CreateAsync(UIPrefabId.UIArributeDetails, CanvasType.App1) as UICommonCharacterArributeDetailsDialog; ;

        mMenu.OnSelectTab.GuardSubscribeAsync(ChangeTabAsync).AddTo(mSubscriptions);


        // mStatusDialog.OnShowDetail.GuardSubscribeAsync(ShowStatusDetail).AddTo(mSubscriptions);
        mStatusDialog.OnLevelUp.GuardSubscribeAsync(ShowLevelUp).AddTo(mSubscriptions);
        mStatusDialog.OnSkillChange.GuardSubscribeAsync(ShowSkillChange).AddTo(mSubscriptions);

        mSphereDialog.OnProcess.GuardSubscribeAsync(OnProcessUnlockSphere).AddTo(mSubscriptions);

        mMainWindow.OnClickRankUp.GuardSubscribeAsync(OnProcessRankUp).AddTo(mSubscriptions);
        mGamutDialog.OnClickRankUp.GuardSubscribeAsync(OnGamutRankUp).AddTo(mSubscriptions);
        mMainWindow.OnClickPrev.GuardSubscribeAsync(ChangeCharacterPrev).AddTo(mSubscriptions);
        mMainWindow.OnClickNext.GuardSubscribeAsync(ChangeCharacterNext).AddTo(mSubscriptions);
        mMainWindow.OnBackClick.GuardSubscribeAsync(OnBackClcik).AddTo(mSubscriptions);
        mMainWindow.OnClickSign.GuardSubscribeAsync(OnClickSignContract).AddTo(mSubscriptions);
        mEquipmentDialog.OnUpdateModel.GuardSubscribeAsync(UpdateChararcterModel).AddTo(mSubscriptions);
        mFetterDialog.OnUnLock.GuardSubscribeAsync(OnUnlockFetter).AddTo(mSubscriptions);
        mGamutDialog.OnGamut.GuardSubscribeAsync(OnGamut).AddTo(mSubscriptions);
        mStatusDialog.arriButeBtnClick.GuardSubscribeAsync(async () => { await arributeDetails.ShowAsync(); await arributeDetails.SetUp(mCharacterViewModel); }).AddTo(mSubscriptions);
        headerParam.showResType.Add(UIHeaderResType.Coin);
        headerParam.visibleRightRank = false;
        headerParam.visibleBack = false;
        headerParam.visibleNavigation = true;
        headerParam.visibleHome = true;
    }

    private async UniTask OnBackClcik(GameObject o)
    {
        await UI.Page.CloseCurrentPage();
    }


    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
        //header

        SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);
        mCharacterViewModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.GetList()[mCurrentCharacterIndex], DataManager.Instance.Player.Equipment.GetList());
        await mMainWindow.SetupAsync(mCharacterViewModel);
        await mMainWindow.ShowAsync(showType);
        await mMenu.ShowAsync(showType);
        if (mCurrentDialog == null)
        {
            await ChangeTabAsync((int) _showType +1);
            //mCurrentDialog = mStatusDialog;
        }

      
        await UpdateCharacter();
        
        

        await mCurrentDialog.ShowAsync(showType);
        
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);

        var taskList = new List<UniTask>();

        taskList.Add(mMenu.HideAsync(showType));

        if (mCurrentDialog != null)
        {
            taskList.Add(mCurrentDialog.HideAsync(showType));
        }
        await UniTask.WhenAll(taskList);

        await mMainWindow.HideAsync(showType);
    }


    public override void Dispose()
    {
        base.Dispose();
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
        if (mMenu != null)
        {
            mMenu.Dispose();
            mMenu = null;
        }

        if (mStatusDialog != null)
        {
            mStatusDialog.Dispose();
            mStatusDialog = null;
        }

        if (mEquipmentDialog != null)
        {
            mEquipmentDialog.Dispose();
            mEquipmentDialog = null;
        }

        if (mSphereDialog != null)
        {
            mSphereDialog.Dispose();
            mSphereDialog = null;
        }

        if (mSkinDialog != null)
        {
            mSkinDialog.Dispose();
            mSkinDialog = null;
        }

        if (mStatusDetail != null)
        {
            mStatusDetail.Dispose();
            mStatusDetail = null;
        }
        if (mLevelUp != null)
        {
            mLevelUp.Dispose();
            mLevelUp = null;
        }
        if (mRankUp != null)
        {
            mRankUp.Dispose();
            mRankUp = null;
        }
        if (mSphereUp != null)
        {
            mSphereUp.Dispose();
            mSphereUp = null;
        }

        if (mSkillDetail != null)
        {
            mSkillDetail.Dispose();
            mSkillDetail = null;
        }

        if (mFetterDialog != null)
        {
            mFetterDialog.Dispose();
            mFetterDialog = null;
        }

        if (mGamutDialog != null)
        {
            mGamutDialog.Dispose();
            mGamutDialog = null;
        }

        mCurrentDialog = null;
    }

    private async UniTask ChangeTabAsync(int tab)
    {
        if (mCurrentDialog != null)
        {
            await mCurrentDialog.HideAsync();
        }

        mCurrentTab = tab;
        string titleStr = "";
        switch (tab)
        {
            case 1:
                mCurrentDialog = mStatusDialog;
                await mStatusDialog.SetupAsync(mCharacterViewModel);
                await mMainWindow.SetBondsGroup(true);
                titleStr = "UI_Unit_Title_Status";
                break;
            case 2:
                mCurrentDialog = mEquipmentDialog;
                await mEquipmentDialog.SetupAsync(mCharacterViewModel);
                titleStr = "UI_Unit_Title_Equip";
                await mMainWindow.SetBondsGroup(false);
                break;
            case 3:
                mCurrentDialog = mSphereDialog;
                await mSphereDialog.SetupAsync(mCharacterViewModel);
                titleStr = "UI_Unit_Title_Sphere";
                await mMainWindow.SetBondsGroup(false);
                break;
            case 4:
                mCurrentDialog = mSkinDialog;
                await mSkinDialog.SetupAsync(mCharacterViewModel);
                await mMainWindow.SetBondsGroup(false);
                break;
            case 5:
                mCurrentDialog = mFetterDialog;
                titleStr = "UI_Unit_Title_Fetter";
                await mFetterDialog.SetupAsync(mCharacterViewModel);
                await mMainWindow.SetBondsGroup(true);
                break;
            case 6:
                mCurrentDialog = mGamutDialog;
                var rank = mCharacterViewModel.rank < 5 ? mCharacterViewModel.rank + 1 : mCharacterViewModel.rank;
                var temp = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.GetList()[mCurrentCharacterIndex], DataManager.Instance.Player.Equipment.GetList(),characterRank: rank);
                await mGamutDialog.SetupAsync(mCharacterViewModel, temp);
                await mMainWindow.SetBondsGroup(false);
                titleStr = "UI_Unit_Title_Gamut2";
                break;
        }

        mMenu.TogglesActive(tab);
        titleStr = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, titleStr);
        mMainWindow.SetTitle(titleStr);
        await mCurrentDialog.ShowAsync();
     
    }

    private async UniTask ChangeCharacterPrev(GameObject o)
    {
        mCurrentCharacterIndex--;
        mCurrentCharacterIndex = (mCurrentCharacterIndex+mMaxNum) % mMaxNum;
        mCharacterViewModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.GetList()[mCurrentCharacterIndex], DataManager.Instance.Player.Equipment.GetList());

        await UpdateCharacter();
        await mCurrentDialog.ShowAsync();
    }

    private async UniTask ChangeCharacterNext(GameObject o)
    {
        mCurrentCharacterIndex++;
        mCurrentCharacterIndex = mCurrentCharacterIndex % mMaxNum;
        mCharacterViewModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.GetList()[mCurrentCharacterIndex], DataManager.Instance.Player.Equipment.GetList());

        await UpdateCharacter();
        await mCurrentDialog.ShowAsync();
    }

    private async UniTask ShowLevelUp(GameObject o)
    {   
        if (mLevelUp == null)
        {
            mLevelUp = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterUnitLevelupDialog, CanvasType.App1) as UIHomeCharacterUnitLevelUpDialog;
            mLevelUp.OnProcessLevelUp.GuardSubscribeAsync(OnProcessLevelUp).AddTo(mSubscriptions);
        }
            
        await mLevelUp.SetupAsync(mCharacterViewModel);
        await mLevelUp.ShowAsync();
    }

    private async UniTask OnProcessLevelUp()
    {
        await CharacterService.RequestLevelUp(mCharacterViewModel.id, mLevelUp.UseItems);

        mCharacterViewModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get(mCharacterViewModel.id), DataManager.Instance.Player.Equipment.GetList());
        await UpdateCharacter();
        
        await mLevelUp.SetupAsync(mCharacterViewModel);
        await mLevelUp.ProcessEnd();
    }

    private async UniTask OnProcessRankUp()
    {
        var characterRankMaster = DataManager.Instance.Master.CharacterRankUp.Values.FirstOrDefault((r)=>(r.battleCharacterMasterId==mCharacterViewModel.id&&r.rank==mCharacterViewModel.rank+1));
        if (characterRankMaster == null) return;
        var item = characterRankMaster.requireContents[0].Split(':');
        long cur = DataManager.Instance.Player.Item.GetCount(long.Parse(item[0]));
        if (cur < long.Parse(item[1]))
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Unite_RankUp_Item_Number"));
            return;
        }

        await CharacterService.RequestRankUp(mCharacterViewModel.id);

        var newModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get(mCharacterViewModel.id), DataManager.Instance.Player.Equipment.GetList());
        await ShowRankUp(mCharacterViewModel, newModel);

        mCharacterViewModel = newModel;
        await UpdateCharacter();
    }

    private async UniTask OnGamutRankUp()
    {
        var characterRankMaster = DataManager.Instance.Master.CharacterRankUp.Values.FirstOrDefault((r) => (r.battleCharacterMasterId == mCharacterViewModel.id && r.rank == mCharacterViewModel.rank + 1));
        if (characterRankMaster == null) return;
        var item = characterRankMaster.requireContents[0].Split(':');
        long cur = DataManager.Instance.Player.Item.GetCount(long.Parse(item[0]));
        if (cur < long.Parse(item[1]))
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "CHARACTER_ITEMS_NOT"));
            return;
        }

        await CharacterService.RequestRankUp(mCharacterViewModel.id);

        var newModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get(mCharacterViewModel.id), DataManager.Instance.Player.Equipment.GetList());
        await ShowGamutRankUp(mCharacterViewModel, newModel);

        mCharacterViewModel = newModel;
        await UpdateCharacter();
    }

    private async UniTask ShowStatusDetail(GameObject o)
    {
        if (mStatusDetail == null)
        {
            mStatusDetail = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterUnitStatusDetailDialog, CanvasType.App1) as UIHomeCharacterUnitStatusDetailDialog;
        }

        await mStatusDetail.SetupAsync(mCharacterViewModel);
        await mStatusDetail.ShowAsync();
    }

    private async UniTask ShowSkillChange(long id)
    {
        if (mSkillDetail == null)
        {
            mSkillDetail = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterUnitSkillDialog, CanvasType.App1) as UIHomeCharacterUnitSkillDialog;
            mSkillDetail.OnEquip.GuardSubscribeAsync(OnEquipSkill).AddTo(mSubscriptions);
            mSkillDetail.OnUnequip.GuardSubscribeAsync(OnUnEquipSkill).AddTo(mSubscriptions);
            mSkillDetail.OnClose.GuardSubscribeAsync(HideSkillChange).AddTo(mSubscriptions);
        }
        mSkillDetail.SelectSkill = id;
        await mStatusDialog.HideAsync(UIPageShowType.Back);
        await mSkillDetail.SetupAsync(mCharacterViewModel);
        await mSkillDetail.ShowAsync();

        mCurrentDialog = mSkillDetail;
    }


    private async UniTask HideSkillChange()
    {
        await mSkillDetail.HideAsync();
        mCurrentDialog = mStatusDialog;
        await mStatusDialog.ShowAsync();
    }

    private async UniTask OnEquipSkill(long id)
    {
        //var maxSkillCount = mCharacterViewModel.skillSlotStatus.Where(a => a > 0).ToArray().Length;
        if (mCharacterViewModel.selectedSkills.Count >= 3)
        {
            var str = string.Format(
                LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "CHARACTER_SKILL_MAX"), 3);
            await UI.Popup.ShowPopupMessageAsync(str);
            return; 
        }

        mCharacterViewModel.selectedSkills.Add(id);
        
        await CharacterService.ChangeSkill(mCharacterViewModel.id, mCharacterViewModel.selectedSkills);

        var newModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get(mCharacterViewModel.id), DataManager.Instance.Player.Equipment.GetList());

        mCharacterViewModel = newModel;
        await UpdateCharacter();

        await mSkillDetail.SetupAsync(newModel);
    }

    private async UniTask OnUnEquipSkill(long id)
    {
        if (mCharacterViewModel.selectedSkills.Count <= 1) return;
        mCharacterViewModel.selectedSkills.Remove(id);
        if (mCharacterViewModel.selectedSkills.Count >= 2)
        {
            await CharacterService.ChangeSkill(mCharacterViewModel.id, mCharacterViewModel.selectedSkills);

            var newModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get(mCharacterViewModel.id), DataManager.Instance.Player.Equipment.GetList());

            mCharacterViewModel = newModel;
            await UpdateCharacter();
        }
        await mSkillDetail.SetupAsync(mCharacterViewModel);
    }

    private async UniTask OnProcessUnlockSphere(long id)
    {
        if (!CharacterUtil.IsGradeUp(id))
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "CHARACTER_ITEMS_NOT"));
            return;
        }

        var data = DataManager.Instance.Master.CharacterPanel[id];
        if (data.requireBattleCharacterLv > mCharacterViewModel.level)
        {
            await UI.Popup.ShowPopupMessageAsync(string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Unit_Sphere_RequireLevel_Format"),data.requireBattleCharacterLv));
            return;
        }

        await CharacterService.UnlockSphere(mCharacterViewModel.id, id);

        var newModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get(mCharacterViewModel.id), DataManager.Instance.Player.Equipment.GetList());
        var panel = DataManager.Instance.Master.CharacterPanel[id];
        //if (panel.requireCharacterPanelMasterIds.Count > 0)
        {
            if (mSphereUp == null)
            {
                mSphereUp = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterUnitSphereLevelUpDialog, CanvasType.App1) as UIHomeCharacterUnitSphereLevelUpDialog;
            }
            PxSoundManager.Instance.PlaySe("feedbackSE_character_stage01");
            await mSphereUp.SetupAsync(mCharacterViewModel, newModel,panel);
            await mSphereUp.ShowAsync();
        }


        mCharacterViewModel = newModel;
        await UpdateCharacter();
    }

    private async UniTask ShowRankUp(CharacterViewModel oldModel, CharacterViewModel newModel)
    {
        if (mRankUp == null)
        {
            mRankUp = await UI.Dialog.CreateAsync(UIPrefabId.UICharacterUnitRankUpDialog, CanvasType.App1) as UIHomeCharacterUnitRankUpDialog;
        }

        await mRankUp.SetupAsync(oldModel, newModel);
        await mRankUp.ShowAsync();
    }

    private async UniTask ShowGamutRankUp(CharacterViewModel oldModel, CharacterViewModel newModel)
    {
        Debug.Log($"Gamut {mGamutRankUp != null}");
        if (mGamutRankUp == null)
        {
            Debug.Log($"Gamut {UIPrefabId.GamutBankUpDialog}");
            mGamutRankUp = await UI.Dialog.CreateAsync(UIPrefabId.GamutBankUpDialog, CanvasType.App1) as UIHomeCharacterUnitGamutRankUpDialog;
        }
        Debug.Log($"Gamut {mGamutRankUp != null}");
        await mGamutRankUp.SetupAsync(oldModel, newModel);
        await mGamutRankUp.ShowAsync();
    }

    private async UniTask UpdateChararcterModel(GameObject o)
    {
        mCharacterViewModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get(mCharacterViewModel.id), DataManager.Instance.Player.Equipment.GetList());
    }

    private async UniTask UpdateCharacter()
    {
        await mMainWindow.SetupAsync(mCharacterViewModel);
      
        switch (mCurrentTab)
        {
            case 1:
                await mStatusDialog.SetupAsync(mCharacterViewModel);
                break;
            case 2:
                await mEquipmentDialog.SetupAsync(mCharacterViewModel);
                break;
            case 3:
                await mSphereDialog.SetupAsync(mCharacterViewModel);
                break;
            case 4:
                await mSkinDialog.SetupAsync(mCharacterViewModel);
                break;
            case 5:
                await mFetterDialog.SetupAsync(mCharacterViewModel);
                break;
            case 6:
                var rank = mCharacterViewModel.rank < 5 ? mCharacterViewModel.rank + 1 : mCharacterViewModel.rank;
                Debug.Log($"{mCharacterViewModel.rank}   {mCharacterViewModel.maxLevel}");
                var newModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.GetList()[mCurrentCharacterIndex], DataManager.Instance.Player.Equipment.GetList(), characterRank: rank);
                await mGamutDialog.SetupAsync(mCharacterViewModel, newModel);
                break;
        }

       
    }

    async UniTask OnClickSignContract()
    {
        return;
        if (DataManager.Instance.Player.Bond.GetLevel(mCharacterViewModel.id) < 4)
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Unit_Sign_LevelNotReach"));
            return;
        }
        if(mCharacterViewModel.contract)
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Unit_AlreadySign"));
            return;
        }
        
        var characterId = DataManager.Instance.Master.BattleCharacter[mCharacterViewModel.id].characterMasterId;
        var master = DataManager.Instance.Master.PrivateTalkCharacter[characterId];
        if (master != null && !string.IsNullOrEmpty(master.bondTalk))
        {
            SignalBus.GlobalSignal.Dispatch(UIEventId.UIHeaderHide);
            await UI.Page.OpenPage<UIAdvMainPage>();
            Game.ScriptEngine.ScenarioScript script = await ResourceManager.Instance.LoadLocalizeAssetAsync<Game.ScriptEngine.ScenarioScript>("Scenario/"+ master.bondTalk);

            Game.ScriptEngine.ScriptEngine.GetInstance().LoadScript(master.bondTalk, script);
            Game.ScriptEngine.ScriptEngine.GetInstance().SetStartScript(master.bondTalk, null, (r)=>
            {
                AsyncManager.Instance.StartGuardAsync(afterEngage);
            });
        }
        else
        {
            await afterEngage();
        }
    }

    async UniTask afterEngage()
    {
        UIHomeHeaderParam headerParam = new UIHomeHeaderParam();
        headerParam.showResType.Add(UIHeaderResType.Coin);
        
        headerParam.visibleRightRank = false;
        headerParam.visibleBack = true;
        headerParam.visibleNavigation = true;
        headerParam.visibleHome = true;
        
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHomeHeaderUpdate, headerParam);
        await CharacterService.SingContract(mCharacterViewModel.id);
        var newModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get(mCharacterViewModel.id), DataManager.Instance.Player.Equipment.GetList());
        await ShowEngaged(newModel);
        mCharacterViewModel = newModel;
        await UpdateCharacter();
    }

    private async UniTask ShowEngaged(CharacterViewModel model)
    {
        if(mSignContract == null)
             mSignContract = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeCharacterUnitSignContract, CanvasType.App1) as UIHomeCharacterUnitSignContract;
        await mSignContract.SetupAsync(model);
        await mSignContract.ShowAsync();
        //mMainWindow.stand.gameObject.SetActive(false);
    }

    private async UniTask OnUnlockFetter(int masterId)
    {
        var master = DataManager.Instance.Master.BondsInfo[masterId];
        await BondService.BondUnlockBond(masterId);
        await UI.Popup.ShowItemGetPopupAsync(master.rewardContents);
        await BondService.BondGetData();
        await UpdateCharacter();
    }


    private async UniTask OnGamut(int i)
    {
        await mGamutDialog.ShowAsync();
    }

    public class PageParam
    {
        public enum ShowType
        {
            Status, 
            Equipment,
            Sphere
        }

        public long characterId = 0;
        public ShowType showType = ShowType.Status;
    }
}
