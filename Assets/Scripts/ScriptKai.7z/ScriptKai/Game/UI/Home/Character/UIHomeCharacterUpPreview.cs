﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.PlayerLoop;
using UnityEngine.UI;
public class UIHomeCharacterUpPreview : MonoBehaviour
{
   [SerializeField] UIText pageText;
   [SerializeField] UIText pageContentText;
   [SerializeField] UIText pageText2;
   [SerializeField] UIText pageContentText2;
   [SerializeField] Image skillIcon;
   [SerializeField] Image skillIcon2;


   [SerializeField] private UIButton lockBtn;
   [SerializeField] private UIButton unlockBtn;
   [SerializeField] private UISkillCommandDetailPanel commandDetailPanel;
   [SerializeField] UIButton closeDetailButton;

   // [SerializeField] private ContentSizeFitter _offContentSizeFitter;
   // [SerializeField] private ContentSizeFitter _onContentSizeFitter;

   [SerializeField] private List<Image> lines;
   RectTransform _rectTransform;
   private RectTransform _child0Rect;
   private RectTransform _child1Rect;
   bool isOn;

   private CharacterViewModel model;
   private void Update()
   {
       _rectTransform.sizeDelta = isOn ? _child0Rect.sizeDelta : _child1Rect.sizeDelta;
   }

   public async UniTask SetUpAsync(int index,CharacterViewModel model)
   {
       
       this.model = model;
       
       foreach (var item in lines)
       {
           item.gameObject.SetActive(true);
       }
       closeDetailButton.OnTouchUpInside.AddListener(()=> commandDetailPanel.Hide());
       pageText.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, $"UI_Unit_Sphere_Page{index}");
       pageText2.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, $"UI_Unit_Sphere_Page{index}");
       var data = DataManager.Instance.Master.CharacterPanel.Values.FirstOrDefault(a => a.battleCharacterMasterId == model.id && a.pageId == index &&a.getBattleCharacterGrade == index+1 );
       //var data = datas.Length>0 ? datas[0]:null;
       pageContentText.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, $"UI_Unit_TotalAttribute");
       pageContentText2.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, $"UI_Unit_TotalAttribute");
       if (data != null && data.getVoiceId != "")
       {
           
           pageContentText.SetRawText(data.getVoiceId);
           pageContentText2.SetRawText(data.getVoiceId);
       }
       if (data != null && data.getSkillId > 0)
       {
           skillIcon.transform.parent.gameObject.SetActive(true);
           skillIcon2.transform.parent.gameObject.SetActive(true);
           pageContentText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{data.getSkillId}_name");
           pageContentText2.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{data.getSkillId}_name");
           SkillMaster master = DataManager.Instance.Master.Skill[data.getSkillId];
           string skillIconPath = master.iconPath;
           if (skillIcon != null)
               skillIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", skillIconPath);
           if (skillIcon2 != null)
               skillIcon2.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", skillIconPath);
           foreach (var item in lines)
           {
               item.gameObject.SetActive(false);
           }
       }
       else
       {
           //skillIcon.gameObject.SetActive(false);
           skillIcon.transform.parent.gameObject.SetActive(false);
           skillIcon2.transform.parent.gameObject.SetActive(false);
           
       }
       if (model.grade >= 1 && index < model.grade)
       {
           isOn = true;
           // pageText.SetColor(Color.cyan);
           // pageContentText.SetColor(Color.cyan);
       }
       else
       {
           isOn = false;
           // pageText.SetColor(Color.black);
           // pageContentText.SetColor(Color.black);
       }
       
       
       transform.GetChild(0).gameObject.SetActive(isOn);
       transform.GetChild(1).gameObject.SetActive(!isOn);
       
           
       
       gameObject.SetActive(false);
       LayoutRebuilder.ForceRebuildLayoutImmediate(this.GetComponent<RectTransform>());
       gameObject.SetActive(true);
       

       
       LayoutRebuilder.ForceRebuildLayoutImmediate(this.GetComponent<RectTransform>());

       if (lockBtn != null)
       {
           lockBtn.onClick.RemoveAllListeners();
           lockBtn.onClick.Subscribe((o) =>
           {
               SkillData(data.getSkillId);
           });
       }

       if (unlockBtn != null)
       {
           unlockBtn.onClick.RemoveAllListeners();
           unlockBtn.onClick.AddListener((o) =>
           {
               SkillData(data.getSkillId);
           });
       }


       _child1Rect = transform.GetChild(1).GetComponent<RectTransform>();
       _child0Rect = transform.GetChild(0).GetComponent<RectTransform>();
       _rectTransform =GetComponent<RectTransform>();


   }
   private void OnDestroy()
   {
        if (unlockBtn != null)
            unlockBtn.onClick.RemoveAllListeners();
        if(lockBtn!=null)
            lockBtn.onClick.RemoveAllListeners();
   }


   public void SkillData(long skillId)
   {

       if (skillId > 0)
       {
           commandDetailPanel.Show();
           commandDetailPanel.Refresh((int) model.id, skillId, true);
       }
   }
   
   
}

