﻿using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UIHomeCharacterUnitRankUpDialog : UIDialogBase
{


    [SerializeField] Image standImage;
    [SerializeField] Image bgImage;
    [SerializeField] Image[] starts;

    [SerializeField] UIText oldMeNameText;
    [SerializeField] UIText newMeNameText;
    [SerializeField] UIText oldMeDesc;
    [SerializeField] UIText newMeDesc;
    [SerializeField] UIText oldMeLev;
    [SerializeField] UIText newMeLev;
    
    [SerializeField] private Image oldSkillImage;
    [SerializeField] private Image newSkillImage;

    [SerializeField] private BaseAttributeUp prefab;
    [SerializeField] private RectTransform attributeTransform;
    
    private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();
    public async UniTask SetupAsync(CharacterViewModel oldModel, CharacterViewModel newModel)
    {
        var resourceMaster = DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[newModel.id].characterResourceId];
        standImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("CharacterMain/BgProfile", resourceMaster.bgProfileName);
        bgImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("CharacterMain/BgCutin", resourceMaster.bgCutinName);
        
        for (int i = 0; i < starts.Length; i++)
        {
            starts[i].gameObject.SetActive(false);
        }
        for (int i = 0; i < newModel.rank; i++)
        {
            starts[i].gameObject.SetActive(true);
        }

        for (int i = 0; i < attributeTransform.childCount; i++)
        {
            attributeTransform.GetChild(i).gameObject.SetActive(false);
        }
        
        int  index = 1;
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            var oldValue =  oldModel.attributeDict[eAtt] + oldModel.equipAttributeDict[eAtt];
            var newValue = newModel.attributeDict[eAtt] + newModel.equipAttributeDict[eAtt];

            var attribute = Instantiate(prefab, this.attributeTransform, false);
            if (newValue > oldValue)
                attribute.LoadAttributeData(eAtt, eAtt.GetAttributePercent(oldValue),
                    eAtt.GetAttributePercent(newValue));
            else
                attribute.SetupText(eAtt, eAtt.GetAttributePercent(oldValue));
            attribute.gameObject.SetActive(true);
            attributeList.Add(attribute);
            index++;
            
        }

        oldMeNameText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{oldModel.meId}_name");
        newMeNameText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{newModel.meId}_name");
        oldMeDesc.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{oldModel.meId}_desc");
        newMeDesc.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{newModel.meId}_desc");
        oldMeLev.SetFormat(LocalizeManager.DATA_TYPE.COMMON,"UNION_LEVEL_FORMAT", oldModel.rank.ToString());
        newMeLev.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "UNION_LEVEL_FORMAT",newModel.rank.ToString());
        
        
        SkillMaster master = DataManager.Instance.Master.Skill[oldModel.meId];
        oldSkillImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", master.iconPath);
        
        SkillMaster master2 = DataManager.Instance.Master.Skill[newModel.meId];
        newSkillImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", master2.iconPath);
        
    }
}
