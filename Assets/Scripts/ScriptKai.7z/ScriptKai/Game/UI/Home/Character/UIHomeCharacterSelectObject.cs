using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Linq;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;

public class UIHomeCharacterSelectObject : MonoBehaviour,IBeginDragHandler, IEndDragHandler
{
    [SerializeField] UIButton clickBtn;
    [SerializeField] UITexture charaTexture;
    [SerializeField] GameObject selectObject;
    [SerializeField] Image[] starts;
    [SerializeField] UIText levelName;
    [SerializeField] UIText levelText;
    [SerializeField] GameObject mask;
    public ClickEvent OnClick => clickBtn.onClick;

    public long currentMasterId;
    public async UniTask SetupAsync(long characterId)
    {
        await charaTexture.LoadAsync("CharacterMain/CircleScrollPanel", characterId.ToString());
        currentMasterId = characterId;
        var mCharacterViewModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get(characterId), DataManager.Instance.Player.Equipment.GetList());
        for (int i = 0; i < starts.Length; i++)
        {
            starts[i].gameObject.SetActive(false);
        }
        for (int i = 0; i < mCharacterViewModel.rank; i++)
        {
            starts[i].gameObject.SetActive(true);
        }
        levelName.SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, "CHARACTER_SORT_LV");
        levelText.SetRawText(mCharacterViewModel.level.ToString());
    }


    public void OnSelect()
    {
        //childRect.anchoredPosition = new Vector2(-70, 0);
        selectObject.SetActive(true);
    }

    public void OnDeselect()
    {
        //childRect.anchoredPosition = Vector2.zero;
        selectObject.SetActive(false);
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        mask.SetActive(true);

    }

    public void OnEndDrag(PointerEventData eventData)
    {
        mask.SetActive(false);
    }
}
