﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIHomeCharacterUnitLevelUpDialog : UIDialogBase
{
    [SerializeField] UIText levelText;
    [SerializeField] UIText expText;
    // [SerializeField] Image expBarImage;
    [SerializeField] Slider expBarSlider;
    [SerializeField] UIButton CloseBtn;

    [SerializeField] BaseItem[] itemButton;
    [SerializeField] UIText[] itemRemainText;

    [SerializeField] private UIText levelTextTitle;

    [SerializeField] private GameObject levelFxObject;
    public UnityEvent OnProcessLevelUp = new UnityEvent();
    private CharacterViewModel model_;
    public Dictionary<long, long> UseItems {get; private set;}


    private long curExp = 0;
    private long maxExp = 0;
    private int curLevel = 0;
    private int maxLevel = 0;
    private long newTotleExp = 0;

    readonly int[] ItemId = {114000001, 114000002, 114000003};


    private float mLastTouchAddTime = 0f;
    private float mAddInterval = 1f;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        UseItems = new Dictionary<long, long>();

        for (int i = 0; i < 3; i++)
        {
            int idx = i;
            var button = itemButton[i];
            button.Button.OnLongTouch.Subscribe(()=>{OnLongTouchItem(idx);}).AddTo(mSubscriptions);
            button.Button.OnTouchUpInside.Subscribe(OnLongTouchEnd).AddTo(mSubscriptions);
            button.Button.OnTouchDown.Subscribe(()=>{OnTouchDown(idx);}).AddTo(mSubscriptions);
            await button.SetupAsync(ItemId[i], $"{DataManager.Instance.Player.Item.GetCount(ItemId[i])}");
        }
        CloseBtn.onClick.GuardSubscribeAsync(onClickClose).AddTo(mSubscriptions);
    }

    public async UniTask SetupAsync(CharacterViewModel model)
    {
        model_ = model;
        curExp = model.curExp;
        curLevel = model.level;
        maxLevel = model.maxLevel;
        maxExp = model.maxExp;
            // <#00ff00>Green text</color>
      
        levelText.SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Status_Level_Format", "<size=16>"+curLevel+"</size>", "<size=16><#969593>"+maxLevel+"</color></size>");
        expText.SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Status_Exp_Format", "<size=16>"+curExp+"</size>", "<size=16><#969593>"+maxExp+"</color></size>");
        if (curLevel == maxLevel && curExp >= maxExp)
        {
            expText.SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Status_Exp_Format", "<#969593>"+maxExp+"</color>", "<#969593>"+maxExp+"</color>");
        }
        
        
        // expBarImage.fillAmount = maxExp == 0?0:(float)curExp/maxExp;
        expBarSlider.value=maxExp == 0?0:(float)curExp/maxExp;

        for (int i = 0; i < 3; i++)
        {
            UseItems[ItemId[i]] = 0;

            itemRemainText[i].SetRawText($"{DataManager.Instance.Player.Item.GetCount(ItemId[i])}");
        }
        
        // Debug.Log(curExp);
    }

    public async UniTask ProcessEnd()
    {
        for (int i = 0; i < 3; i++)
        {
            UseItems[ItemId[i]] = 0;

            itemRemainText[i].SetRawText($"{DataManager.Instance.Player.Item.GetCount(ItemId[i])}");
        }
        
    }

    private void OnTouchDown(int idx)
    {
        mLastTouchAddTime = Time.realtimeSinceStartup;
        mAddInterval = 1f;
        if (levelTextTitle.gameObject.activeSelf)
        {
            levelTextTitle.gameObject.SetActive(false);
        }
        if (UseItems[ItemId[idx]] >= DataManager.Instance.Player.Item.GetCount(ItemId[idx]))
            return;

        tryAddExp(idx);
    }

    private void OnLongTouchItem(int idx)
    {
        
        if (UseItems[ItemId[idx]] >= DataManager.Instance.Player.Item.GetCount(ItemId[idx]))
            return;
            

        if (Time.realtimeSinceStartup-mLastTouchAddTime >= mAddInterval)
        {
            mLastTouchAddTime = Time.realtimeSinceStartup;
            mAddInterval *= 0.8f;
        }
        else
        {
            return;
        }
        tryAddExp(idx);
    }
    bool isOverflow = true;
    private void OnLongTouchEnd()
    {
        bool process = false;
        foreach (var kv in UseItems)
        {
            if (kv.Value > 0)
            {
                process = true;
                break;
            }
        }
        if (process && isOverflow)
            OnProcessLevelUp.Invoke();
        newTotleExp = 0;
    }

    private void tryAddExp(int idx)
    {
        if (curLevel >= maxLevel && curExp >= maxExp || !isOverflow) return;
        if (DataManager.Instance.Master.CharacterGradeUp[model_.grade].levelCap == curLevel) return;
        if (CharacterUtil.GetExpOverflow(model_,ItemId[idx],newTotleExp))
        {
            isOverflow = false;
            var str  = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER, "UI_LevelUp_Exp_Max");
            UI.Popup.ShowConfirm(string.Empty, str, CanvasType.App2, (r) =>
            {
                if (r == UIPopupDialog.Result.OK)
                {
                    isOverflow = true;
                    loadAddExp(idx);
                    OnLongTouchEnd();
                }

                if (r == UIPopupDialog.Result.Cancel)
                {
                    isOverflow = true;
                    OnLongTouchEnd();
                }
            });
        }
        else
        {
            isOverflow = true;
            loadAddExp(idx);
        }
    }

    void loadAddExp(int idx)
    {
        var exp = DataManager.Instance.Master.Item[ItemId[idx]].exp;
        var oldlevel = curLevel;
        curExp += exp;
        newTotleExp += exp;
        while (curLevel < maxLevel)
        {
            maxExp = DataManager.Instance.Master.CharacterLevelUp[curLevel+1].exp;
            if (curExp >= maxExp)
            {
                levelFxObject.SetActive(false);
                curLevel++;
                PxSoundManager.Instance.PlaySe("feedbackSE_character_level01");
                levelFxObject.SetActive(true);
                curExp -= maxExp;
            }
            else
            {
                break;
            }
        }
        
        levelText.SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Status_Level_Format", curLevel, maxLevel);
        expText.SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Status_Exp_Format", curExp, maxExp);
        if (oldlevel < curLevel)
        {
            levelTextTitle.gameObject.SetActive(true);
        }

        if (curLevel == maxLevel && curExp >= maxExp)
        {
            expText.SetFormat(LocalizeManager.DATA_TYPE.CHARACTER, "UI_Status_Exp_Format", maxExp, maxExp);
        }
        // expBarImage.fillAmount = maxExp == 0?0:(float)curExp/maxExp;
        expBarSlider.value=maxExp == 0?0:(float)curExp/maxExp;

        UseItems[ItemId[idx]]++;

        itemRemainText[idx].SetRawText($"{DataManager.Instance.Player.Item.GetCount(ItemId[idx])-UseItems[ItemId[idx]]}");
    }
}
