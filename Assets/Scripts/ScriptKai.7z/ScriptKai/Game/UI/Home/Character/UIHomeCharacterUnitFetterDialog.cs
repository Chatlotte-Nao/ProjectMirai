using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeCharacterUnitFetterDialog : UIDialogBase
{
    [SerializeField] private UIHomeCharacterUnitFetterCell cellPrefab;
    [SerializeField] private RectTransform contentTransform;
    [SerializeField] private UIText bondText;
    [SerializeField] private UIText bondNumberText;
    [SerializeField] private UITexture bondImage;
    private List<UIHomeCharacterUnitFetterCell> cellList = new List<UIHomeCharacterUnitFetterCell>();
    public UIIntEvent OnUnLock = new UIIntEvent();
    private bool isInit = true;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }

    public async UniTask SetupAsync(CharacterViewModel model)
    {
        if (isInit)
        {
            await BondService.BondGetData();
            await MissionService.RequestMissionData(new long[]{5});
        }

        isInit = false;
        var masters = DataManager.Instance.Master.BondsInfo.Where(a => a.Value.battleCharacterMasterId == model.id);
        var level = DataManager.Instance.Player.Bond.GetLevel(model.id);
        bondText.SetLabel(LocalizeManager.DATA_TYPE.BOND,$"{level}");
        bondNumberText.SetRawText(level.ToString());
        bondImage.Load("Bond",level.ToString(),false);
        foreach (var cell in cellList)
        {
            cell.gameObject.SetActive(false);
            cell.OnClick.RemoveAllListeners();
        }
        int index = 0;
        foreach (var master in masters)
        {
            if (index < cellList.Count)
            {
                await cellList[index].SetUp(master.Value);
                cellList[index].gameObject.SetActive(true);
                cellList[index].OnClick.Subscribe(_ => OnUnLock.Invoke(master.Key)).AddTo(mSubscriptions);
                //cellList[index].OnClick2.Subscribe(_ => OnItemBuyClick.Invoke(master.id)).AddTo(mSubscriptions);
            }
            else
            {
                var cell = Instantiate(cellPrefab, contentTransform);
                await cell.SetUp(master.Value);
                cell.OnClick.Subscribe(_ => OnUnLock.Invoke(master.Key)).AddTo(mSubscriptions);
                //cell.OnClick.Subscribe(_ => OnItemBuyClick.Invoke(master.id)).AddTo(mSubscriptions);
                //cell.OnClick2.Subscribe(_ => OnItemBuyClick.Invoke(master.id)).AddTo(mSubscriptions);
                cellList.Add(cell);
                cell.gameObject.SetActive(true);
            }

            index++;
            
        }
    }
    
}
