using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using System.Linq;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIHomeCharacterUnitGamutDialog : UIDialogBase
{
    [SerializeField] Image[] starts;
    [SerializeField] Image[] startsNext;
    [SerializeField] UIText oldMeNameText;
    [SerializeField] UIText newMeNameText;
    [SerializeField] UIText oldMeDesc;
    [SerializeField] UIText newMeDesc;
    [SerializeField] UIText oldMeLev;
    [SerializeField] UIText newMeLev;

    [SerializeField] private Image oldSkillImage;
    [SerializeField] private Image newSkillImage;

    [SerializeField] private BaseAttributeUp prefab;
    [SerializeField] private RectTransform attributeTransform;

    [SerializeField] List<GameObject> rankMaxHide = new List<GameObject>();

    [SerializeField] BaseItem rankUpItem;
    [SerializeField] UIButton rankUpBtn;
    [SerializeField] private GameObject rankObject;

    private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();
    public UIIntEvent OnGamut = new UIIntEvent();
    public UnityEvent OnClickRankUp => rankUpBtn.OnTouchUpInside;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }

    public async UniTask SetupAsync(CharacterViewModel oldModel, CharacterViewModel newModel)
    {
        foreach (var attribute in attributeList)
        {
            attribute.gameObject.SetActive(false);
        }
        var characterRankMaster = DataManager.Instance.Master.CharacterRankUp.Values.FirstOrDefault((r) => (r.battleCharacterMasterId == oldModel.id && r.rank == oldModel.rank + 1));
        if (characterRankMaster != null)
        {
            rankObject.SetActive(true);
            rankUpItem.gameObject.SetActive(true);
            var item = characterRankMaster.requireContents[0].Split(':');
            rankUpItem.SetupNeed(long.Parse(item[0]), long.Parse(item[1]));
            long cur = DataManager.Instance.Player.Item.GetCount(long.Parse(item[0]));
            if (cur < long.Parse(item[1]))
            {
                rankUpBtn.GetComponent<Image>().color = Color.black;
            }
            else
            {
                rankUpBtn.GetComponent<Image>().color = Color.white;
            }
        }
        else
        {
            rankObject.SetActive(false);
            rankUpItem.gameObject.SetActive(false);
        }




        for (int i = 0; i < starts.Length; i++)
        {
            starts[i].gameObject.SetActive(false);
            startsNext[i].gameObject.SetActive(false);
        }
        for (int i = 0; i < oldModel.rank; i++)
        {
            starts[i].gameObject.SetActive(true);
        }
        if (oldModel.rank < 5)
        {
            for (int i = 0; i < rankMaxHide.Count; i++)
            {
                rankMaxHide[i].SetActive(true);
            }
            for (int i = 0; i < newModel.rank; i++)
            {
                startsNext[i].gameObject.SetActive(true);
            }
        }
        else
        {
            for (int i = 0; i < rankMaxHide.Count; i++)
            {
                rankMaxHide[i].SetActive(false);
            }
        }

        for (int i = 0; i < attributeTransform.childCount; i++)
        {
            attributeTransform.GetChild(i).gameObject.SetActive(false);
        }

       
        int index = 0;
        for (int i = 1; i < (int)CharacterAttribute.Crt; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            var oldValue = oldModel.attributeDict[eAtt] + oldModel.equipAttributeDict[eAtt];
            var newValue = newModel.attributeDict[eAtt] + newModel.equipAttributeDict[eAtt];
            BaseAttributeUp attribute;
            if (newValue <= oldValue && oldModel.rank < 5)
                continue;
            if (index < attributeList.Count)
            {
                attribute = attributeList[index];
            }
            else
            {
                attribute = Instantiate(prefab, this.attributeTransform, false);
                attributeList.Add(attribute);
            }
            if (oldModel.rank < 5)
                attribute.LoadAttributeData(eAtt, eAtt.GetAttributePercent(oldValue),
                    eAtt.GetAttributePercent(newValue));
             else
                 attribute.SetupText(eAtt, eAtt.GetAttributePercent(oldValue));
            attribute.gameObject.SetActive(true);
           
            index++;
        }

        oldMeNameText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{oldModel.meId}_name");
        newMeNameText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{newModel.meId}_name");
        oldMeDesc.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{oldModel.meId}_desc");
        newMeDesc.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{newModel.meId}_desc");
        oldMeLev.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "UNION_LEVEL_FORMAT", oldModel.rank.ToString());
        newMeLev.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "UNION_LEVEL_FORMAT", newModel.rank.ToString());
        //Debug.Log($"{oldModel.meId}   {oldModel.meId + 1}   {newModel.meId}   {newModel.meId + 1}");

        SkillMaster master = DataManager.Instance.Master.Skill[oldModel.meId];
        //oldSkillImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", master.iconPath);

        SkillMaster master2 = DataManager.Instance.Master.Skill[newModel.meId];
        //newSkillImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", master2.iconPath);

        oldSkillImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", "icon_jineng_tianfu_dazhao_w");
        newSkillImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", "icon_jineng_tianfu_dazhao_w");
    }


    public void Setup(string message)
    {

    }


    //[SerializeField] UIText sphereLevel;
    //[SerializeField] UIText propertyPreview;
    //[SerializeField] UIText skillParticulars;

    //[SerializeField] private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();

    //[SerializeField] private List<BaseAttributeUp> attributeList2 = new List<BaseAttributeUp>();

    //CharacterViewModel mCharacterViewModel;
    //private int mCurrentCharacterIndex = 0;
    //private int mMaxNum = 0;


    //public async UniTask SetupAsync(CharacterViewModel model)
    //{
    //    Debug.Log("23123132131");
    //    gameObject.SetActive(true);
    //    OnGamut.Invoke(1);
    //22
    //for (int i = 1; i < (int)CharacterAttribute.Max; i++)
    //{
    //    CharacterAttribute en = (CharacterAttribute)i;
    //    attributeList[i - 1].SetupText(en, en.GetAttributePercent(model.attributeDict[en] + model.equipAttributeDict[en]));
    //}

    ////
    //Debug.Log($"{DataManager.Instance.Player.Player.GetOldLevel()}   {DataManager.Instance.Player.Player.GetLevel()}   {(DataManager.Instance.Player.Character.GetList()[0]) == (DataManager.Instance.Player.Character.GetList()[1])}");
    //mCharacterViewModel = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.GetList()[0], DataManager.Instance.Player.Equipment.GetList());
    //for (int i = 1; i < (int)CharacterAttribute.Max; i++)
    //{
    //    CharacterAttribute en = (CharacterAttribute)i;
    //    attributeList2[i - 1].SetupText(en, (en).GetAttributePercent(mCharacterViewModel.attributeDict[en] + mCharacterViewModel.equipAttributeDict[en]));
    //}
    //Debug.Log($"{DataManager.Instance.Player.Player.GetOldLevel()}   {DataManager.Instance.Player.Player.GetLevel()}");

    //string str = "";

    //str += nameof(model.id) + " : " + model.id + "\n";

    //str += nameof(model.curExp) + " : " + model.curExp + "\n";

    //str += nameof(model.maxExp) + " : " + model.maxExp + "\n";

    //str += nameof(model.level) + " : " + model.level + "\n";

    //str += nameof(model.maxLevel) + " : " + model.maxLevel + "\n";

    //str += nameof(model.grade) + " : " + model.grade + "\n";

    //str += nameof(model.rank) + " : " + model.rank + "\n";

    //str += nameof(model.equipments) + " : " + model.equipments + "\n";

    //str += nameof(model.meId) + " : " + model.meId + "\n";

    //str += nameof(model.learnedSkills) + " : " + model.learnedSkills + "\n";

    //str += nameof(model.selectedSkills) + " : " + model.selectedSkills + "\n";

    //str += nameof(model.passiveSkills) + " : " + model.passiveSkills + "\n";

    //str += nameof(model.skillSlotStatus) + " : " + model.skillSlotStatus + "\n";

    //str += nameof(model.attributeDict) + " : " + model.attributeDict + "\n";

    //str += nameof(model.equipAttributeDict) + " : " + model.equipAttributeDict + "\n";

    //str += nameof(model.sphereAttributeDict) + " : " + model.sphereAttributeDict + "\n";

    //str += nameof(model.unlockedPanels) + " : " + model.unlockedPanels + "\n";

    //str += nameof(model.contract) + " : " + model.contract + "\n";

    //str += nameof(model.ap) + " : " + model.ap + "\n";

    //Debug.Log(str);
    //}
}
