using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIHomeNavigationWindow : UIDialogBase
{
    [SerializeField] UIButtonWithNew navigationButton;
    [SerializeField] private GameObject navigationBorder;

    [Space(20), Header("导航面板")] [SerializeField]
    GameObject navigationGroup;

    [SerializeField] GameObject normalGroup;
    [SerializeField] UIText nameText;
    [SerializeField] UserIcon userIcon;
    [SerializeField] UIText rankText;
    [SerializeField] RectTransform scrollContent;

    [SerializeField] UIButton closeNavigationButton;
    [SerializeField] UIButton profileButton;
    [SerializeField] UIButton exchangeButton;
    [SerializeField] UIButton accountButton;
    [SerializeField] UIButton configButton;
    [SerializeField] UIButton signoffButton;

    [SerializeField] UIButton characterButton2;
    [SerializeField] UIButton strengthenEquipmentButton2;
    [SerializeField] UIButton storyButton2;
    [SerializeField] UIButton dungeonButton2;
    [SerializeField] UIButton gachaButton2;
    [SerializeField] UIButton dailyQuestButton;
    [SerializeField] UIButtonWithNew missionButton;
    [SerializeField] UIButton shopButton;
    [SerializeField] UIButton inventoryButton2;
    [SerializeField] UIButtonWithNew mailButton;
    [SerializeField] UIButton announceButton;

    [SerializeField] UIButtonWithNew QuestionnaireButton;

    [SerializeField] private GameObject mutaObj;
    [SerializeField] private RectTransform mutaImage;

    [SerializeField] Vector2 offset;
    [SerializeField] private float mutaAnimationDuration;

    private bool _outSideOpenFlag = false;

    bool isFolding = false;

    private UIAdvConfigDialog mConfig = null;

    private UIExchangeDialog mExchange = null;
    public RoomSelectEvent OnGotoRoom = new RoomSelectEvent();

    public UIBoolEvent OnNavigationGroup = new UIBoolEvent();


    public override async UniTask InitializeAsync()
    {
        navigationButton.OnTouchUpInside.GuardSubscribeAsync(onClickNavigation).AddTo(mSubscriptions);
        closeNavigationButton.OnTouchUpInside.GuardSubscribeAsync(onClickCloseNavigation).AddTo(mSubscriptions);

        profileButton.OnTouchUpInside.GuardSubscribeAsync(onClickProfile).AddTo(mSubscriptions);
        exchangeButton.OnTouchUpInside.GuardSubscribeAsync(onClickExchange).AddTo(mSubscriptions);
        accountButton.OnTouchUpInside.GuardSubscribeAsync(onClickAccount).AddTo(mSubscriptions);
        configButton.OnTouchUpInside.GuardSubscribeAsync(onClickconfig).AddTo(mSubscriptions);
        signoffButton.OnTouchUpInside.GuardSubscribeAsync(onClickSignOff).AddTo(mSubscriptions);
        characterButton2.OnTouchUpInside.GuardSubscribeAsync(onClickCharacter).AddTo(mSubscriptions);
        strengthenEquipmentButton2.OnTouchUpInside.GuardSubscribeAsync(onClickEquipment).AddTo(mSubscriptions);
        storyButton2.OnTouchUpInside.GuardSubscribeAsync(onClickStory).AddTo(mSubscriptions);
        dungeonButton2.OnTouchUpInside.GuardSubscribeAsync(onClickDungeon).AddTo(mSubscriptions);
        gachaButton2.OnTouchUpInside.GuardSubscribeAsync(onClickGacha).AddTo(mSubscriptions);
        dailyQuestButton.OnTouchUpInside.GuardSubscribeAsync(onClickDailyQuest).AddTo(mSubscriptions);
        missionButton.OnTouchUpInside.GuardSubscribeAsync(onClickMission).AddTo(mSubscriptions);
        shopButton.OnTouchUpInside.GuardSubscribeAsync(onClickShop).AddTo(mSubscriptions);
        inventoryButton2.OnTouchUpInside.GuardSubscribeAsync(onClickInventory).AddTo(mSubscriptions);
        mailButton.OnTouchUpInside.GuardSubscribeAsync(onClickMail).AddTo(mSubscriptions);
        announceButton.OnTouchUpInside.GuardSubscribeAsync(onClickAnnounce).AddTo(mSubscriptions);
        QuestionnaireButton.OnTouchUpInside.GuardSubscribeAsync(OnClickQuestionnaire).AddTo(mSubscriptions);
    }

    public void SetupAdvNavigation()
    {
        navigationButton.GetComponent<RectTransform>().localScale = new Vector3(0.5f, 0.5f, 1);
        navigationBorder.SetActive(true);
    }


    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        SetScrollZero();
        UpdateIcon();
        UpdateRank();
        nameText.SetRawText(DataManager.Instance.Player.Player.GetData().Name);
        SetNavigationActive(false);
        await base.ShowAsync(showType);
    }

    async UniTask MutaAnimation(bool isOn)
    {
        if (isOn)
        {
            //TODO 暂时注释
            // //刷新姆塔位置
            // mutaObj.gameObject.SetActive(true);
            // var playerScreenLeftWolrdPos = MapSceneManager.Instance.CurrentScene.GetPlayerScreenLeftWorldPos(offset);
            // mutaObj.transform.position = playerScreenLeftWolrdPos+new Vector3(0,offset.y,0);
            // //朝相机移动
            // await UniTask.Delay(1000);
            // var camPos = MapSceneManager.Instance.CurrentScene.GetCameraController().GetCamera().transform.position;
            // mutaObj.transform.LookAt(camPos);
            // Tween tween = DOTween.To(() => mutaObj.transform.position, x => mutaObj.transform.position = x, camPos, mutaAnimationDuration);
            //  var tweenDone=false;
            //
            //  tween.onComplete += () => { tweenDone = true; mutaObj.gameObject.SetActive(false); };
            // await UniTask.WaitWhile(()=>tweenDone==false);


            //rawImage移入
            // var end = new Vector2(111, 226.5f);
            // Tween tween2 = DOTween.To(() => mutaImage.anchoredPosition, x => mutaImage.anchoredPosition = x, end, 1);
        }
        else
        {
            // var end = new Vector2(111-mutaImage.sizeDelta.x, 226.5f);
            // Tween tween2 = DOTween.To(() => mutaImage.anchoredPosition, x => mutaImage.anchoredPosition = x, end, 1);
        }
    }


    private void SetScrollZero()
    {
        scrollContent.localPosition = Vector3.zero;
    }

    public async UniTask SetUpOutSide()
    {
        _outSideOpenFlag = true;
        normalGroup.SetActive(false);
        navigationButton.gameObject.SetActive(false);
    }

    public async UniTask OpenNavigationGroupOutSide()
    {
        await onClickNavigation();
    }

    public override async UniTask LoadRedInfoAsync()
    {
        await LoadMailRed();
        navigationButton.SetNewFlag(new[] {UINewType.Mission, UINewType.MissionPoint, UINewType.Mail});
        await loadQuestionnaire();
    }

    private async UniTask loadQuestionnaire()
    {
        await QuestionnaireService.GetQuestionnairesAsync();
        if (DataManager.Instance.Player.Questionnaire.IsHaveQuestionnaire())
        {
            QuestionnaireButton.SetNewFlag();
            QuestionnaireButton.gameObject.SetActive(true);
        }
        else
        {
            QuestionnaireButton.gameObject.SetActive(false);
        }
    }

    //TODO 临时获取邮件红点
    private async UniTask LoadMailRed()
    {
        await MailService.GetMailsAsync();
        mailButton.SetNewFlag(UINewType.Mail);
    }

    private async UniTask OnClickQuestionnaire()
    {
        var url = DataManager.Instance.Player.Questionnaire.TryGetFirst();
        if (url != null) 
            await UI.Page.OpenPage<UIQuestionnairePage>(url);
        else
        {
            QuestionnaireButton.gameObject.SetActive(false);
        }
    }

    void UpdateIcon()
    {
        var iconId = DataManager.Instance.Player.Player.GetData().ProfileIconId;
        userIcon.Setup(DataManager.Instance.Player.Player.GetData().ProfileIconFrame, iconId);
        var master = DataManager.Instance.Master
            .CharacterResource[DataManager.Instance.Master.BattleCharacter[iconId].characterResourceId];
    }

    void UpdateRank()
    {
        rankText.SetLabel(LocalizeManager.DATA_TYPE.COMMON, DataManager.Instance.Player.Player.GetLevel().ToString());
    }

    private async UniTask onClickAnnounce()
    {
#if !UNITY_EDITOR
        var _webViewDialog =
 (UIWebViewDialog) await UI.Dialog.CreateAsync(UIPrefabId.UIWebAnnouncementDialog, CanvasType.System);
        
        _webViewDialog.OnBack.Subscribe(_=>{
            _webViewDialog.Dispose();
            _webViewDialog = null;
        });

        var platform = "";
#if UNITY_ANDROID
        platform = "android";
#elif UNITY_IOS
        platform = "ios";
#endif
        var affcode = LCXHandler.Instance.AffCode;
        var realmid = DataManager.Instance.Local.UserInfo.currentServer.id;

        var url =
 DataManager.Instance.Local.UserInfo.announcementUrl+$"?platform={platform}&affcode={affcode}&realmid={realmid}";

        await _webViewDialog.SetupAsync(url);
        await _webViewDialog.ShowAsync();
#endif
    }

    private async UniTask onClickProfile()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
        }

        await UI.Page.OpenPage<UIHomeProfilePage>();
    }

    private async UniTask onClickMail()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
        }

        await MailService.GetMailsAsync();
        await UI.Page.OpenPage<UIHomeMailPage>();
    }

    private async UniTask onClickInventory()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
        }

        await UI.Page.OpenPage<UIInventoryPage>();
        // gotoRoom("advRoom[51]");
    }

    private async UniTask onClickShop()
    {
        // gotoRoom("advRoom[52]");
        if (_outSideOpenFlag)
        {
            await HideAsync();
        }

        if (MapSceneManager.Instance.CurrentType == MapSceneManager.SceneType.Home)
        {
            await gotoRoom("advRoom[52]", "shop");
        }
        else
            // await ExploreService.RequestExploreData();
            await UI.Page.OpenPage<UIShopPage>();
    }

    private async UniTask onClickMission()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
        }

        if (MapSceneManager.Instance.CurrentType == MapSceneManager.SceneType.Home)
        {
            await gotoRoom("advRoom[39]", "mission");
        }
        else
        {
            await MissionService.RequestMissionData();
            await UI.Page.OpenPage<UIMissionPage>();
        }
    }

    private async UniTask onClickDungeon()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
        }

        //TODO 跳转地牢
        //UI.Popup.ShowPopMessage( LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "Common_Home_NotOpen"));
        if (MapSceneManager.Instance.CurrentType == MapSceneManager.SceneType.Home)
        {
            gotoRoom("advRoom[131]", "dungeon");
        }
        else
        {
            // //TODO XZF 临时注释
            // await UI.Popup.ShowPopupMessageAsync("功能正在研发中...");
            // return;
            await UI.Page.ChangePage<UIUndergroundPage>();
        }
    }

    private async UniTask onClickExchange()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
        }

        //TODO 兑换码界面
        if (mExchange == null)
        {
            mExchange = await UI.Dialog.CreateAsync(UIPrefabId.UIExchange, CanvasType.App2) as UIExchangeDialog;
        }

        await mExchange.ShowAsync();
    }

    private async UniTask onClickAccount()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
        }
#if BUILD_DEBUG
        if (TakashoHandler.Instance.MockLoginMode)
        {
            UI.Popup.ShowPopMessage("Mock 模式不能使用");
            return;
        }
#endif

        //TODO 账号界面
        await LCXHandler.Instance.ShowUserCenter();
        //UI.Popup.ShowPopMessage( LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "Common_Home_NotOpen"));
    }

    private async UniTask onClickconfig()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
        }

        if (mConfig == null)
        {
            mConfig = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvConfigDialog, CanvasType.App2) as UIAdvConfigDialog;
        }

        await mConfig.ShowAsync();
    }

    private async UniTask onClickDailyQuest()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
        }

        if (MapSceneManager.Instance.CurrentType == MapSceneManager.SceneType.Home)
        {
            await gotoRoom("advRoom[41]", "dailyquest");
        }
        else
        {
            await DailyQuestService.GetAvailable();
            await DailyQuestService.GetToday();
            await UI.Page.OpenPage<UIHomeDailyQuestMainPage>();
        }
    }

    private async UniTask onClickStory()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
        }

        if (MapSceneManager.Instance.CurrentType == MapSceneManager.SceneType.Home)
        {
            await gotoRoom("advRoom[58]", "OrganMachine");
        }
        else
        {
            UIHomeScenarioSelectPage.PageParam p = new UIHomeScenarioSelectPage.PageParam();
            p.showType = UIHomeScenarioSelectPage.PageParam.ShowType.Chapter;
            await UI.Page.OpenPage<UIHomeScenarioSelectPage>(p);
        }
    }


    private async UniTask onClickNavigation()
    {
        if (!_outSideOpenFlag)
        {
            await MutaAnimation(true);
            // transform.TransformDirection();
        }

        SetNavigationActive(true);
        UpdateIcon();
        UpdateRank();
        nameText.SetRawText(DataManager.Instance.Player.Player.GetData().Name);
        missionButton.SetNewFlag(new[] {UINewType.Mission, UINewType.MissionPoint});
        await loadQuestionnaire();
        await LoadMailRed();
    }

    private async UniTask onClickCloseNavigation()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
            return;
        }

        if (!_outSideOpenFlag)
        {
            await MutaAnimation(false);
            // transform.TransformDirection();
        }

        SetNavigationActive(false);
    }


    private void SetNavigationActive(bool isShow)
    {
        navigationGroup.SetActive(isShow);
        if (!_outSideOpenFlag)
        {
            if (CommonUtil.IsFunctionUnlock(38))
                normalGroup.SetActive(!isShow);
            else
                normalGroup.SetActive(false);
        }

        OnNavigationGroup.Invoke(isShow);
    }

    private async UniTask onClickSignOff()
    {
#if BUILD_DEBUG
        if (TakashoHandler.Instance.MockLoginMode)
        {
            UI.Popup.ShowPopMessage("Mock 模式不能使用");
            return;
        }
#endif

        LCXHandler.Instance.SignOff();
    }

    private async UniTask onClickCharacter()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
        }

        await UI.Page.OpenPage<UIHomeCharacterMainPage>();
    }

    private async UniTask onClickEquipment()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
        }

        await UI.Page.OpenPage<UIHomeEquipmentListPage>();
    }

    private async UniTask onClickGacha()
    {
        if (_outSideOpenFlag)
        {
            await HideAsync();
            Dispose();
        }

        if (MapSceneManager.Instance.CurrentType == MapSceneManager.SceneType.Home)
        {
            await gotoRoom("advRoom[128]");
        }
        else
        {
            var param = await GachaService.GetGachaList();
            await UI.Page.ChangePage<UIGachaMainPage>(param);
        }
    }

    public override void OnHide()
    {
        base.OnHide();

        if (!_outSideOpenFlag)
        {
            AsyncManager.Instance.StartAsync(MutaAnimation(false));
            // transform.TransformDirection();
        }
    }

    private async UniTask gotoRoom(string room, string name = "")
    {
        // UIWorldMapDialog.SelectTarget t = new UIWorldMapDialog.SelectTarget();
        // t.mapName = room;
        // t.roomName = name;
        SetNavigationActive(false);
        await UI.Page.OpenPage<UIHomeSubPage>();
        //OnGotoRoom.Invoke(t);
        await gotoMapTarget(room, name);
    }

    private async UniTask gotoMapTarget(string room, string name)
    {
        var advMapMaster = DataManager.Instance.Master.AdvMap[room];
        var mapData = DataManager.Instance.Master.Location[advMapMaster.map_label];

        if (MapSceneManager.Instance.mCurrentSceneName != mapData.scene)
        {
            //await UI.ScreenEffect.Fade(1);
            if (string.IsNullOrEmpty(advMapMaster.startPos))
            {
                await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home,
                    mapData.startPos);
            }
            else
            {
                await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home,
                    advMapMaster.startPos);
            }
            //await UI.ScreenEffect.Fade(0);
        }

        MapSceneManager.Instance.CurrentScene.GetCameraController().GetVirtualCameraManager().ZoomPlayer(false, 0.6f);

        DataManager.Instance.Local.UserInfo.currentHomeMap = advMapMaster.map_label;

        MapSceneManager.Instance.CurrentScene.MovePlayerToRoomPoint(room, advMapMaster.openUi);
        DataManager.Instance.Local.UserInfo.currentHomeRoom = room;
    }

    public class RoomSelectEvent : UnityEvent<UIWorldMapDialog.SelectTarget>
    {
    }
}