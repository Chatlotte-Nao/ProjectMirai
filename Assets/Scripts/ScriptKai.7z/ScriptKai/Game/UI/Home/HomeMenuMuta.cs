﻿using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.Rendering.Universal;
using UnityEngine.UI;


public class HomeMenuMuta : MonoBehaviour, IDisposable
{

    [SerializeField] Animator _animator;
    [SerializeField] private Camera _camera;
    [SerializeField] private RawImage _rawImage;
    public TabToggleWithAnimation _tabToggle;

    private RenderTexture mRenderTexture = null;
    [SerializeField] private int animationInterval;

    private int lastTimeRamdom = -1;



    [SerializeField] int lockID = -1;

    void Start()
    {
        if (lockID != -1)
        {

            // var stageId = DataManager.Instance.Master.FunctionUnlock[lockID].requireStageId;
            // Debug.Log(stageId);
            Log.Info(StoryUtil.IsClear(lockID));
            var isLock = !StoryUtil.IsClear(lockID);
            gameObject.SetActive(!isLock);

            // if (stageId > 0 && !StoryUtil.IsClear(stageId))
            // {
            //     var isLock = true;
            // }

        }



        _rawImage = GetComponent<RawImage>();
        // var myUniversalAdditionalCameraData = _camera.GetUniversalAdditionalCameraData();
        var rt = new RenderTexture(512, 1024, 1);
        _camera.targetTexture = rt;
        _rawImage.texture = rt;

        InvokeRepeating("RandomIdle", animationInterval, animationInterval);
    }


    public void Open()
    {
        PxSoundManager.Instance.PlaySe("feedbackSE_interface_open01");
        _animator.SetTrigger("open");
    }
    public void Close()
    {
        PxSoundManager.Instance.PlaySe("feedbackSE_interface_close01");
        _animator.SetTrigger("close");
    }
    async UniTask RandomIdle()
    {
        var randomInt = UnityEngine.Random.Range(1, 4);
        if (randomInt == lastTimeRamdom)
        {
            randomInt = (randomInt + 1) % 3;
        }
        lastTimeRamdom = randomInt;
        if (_animator != null)
            _animator.SetInteger("nextIdle", randomInt);
        await UniTask.Delay(300);
        if (_animator != null)
            _animator.SetInteger("nextIdle", -1);
    }

    public void Dispose()
    {
        CancelInvoke("RandomIdle");
        mRenderTexture?.Release();
        mRenderTexture = null;
        _camera = null;
        Destroy(gameObject);
    }
}
