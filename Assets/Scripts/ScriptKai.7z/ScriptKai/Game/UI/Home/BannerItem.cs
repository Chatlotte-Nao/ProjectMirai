﻿using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;


namespace Home
{
	public class BannerItem : MonoBehaviour
	{
		public BannerClickEvent onClick { get; private set; } = new BannerClickEvent();

		public void Initialize(int id, Sprite sprite)
		{
			this.id = id;
			this.image.sprite = sprite;
			button.onClick.AddListener(() =>
			{
				onClick.Invoke(id);
			});
		}

		[SerializeField]
		Image image = null;

		[SerializeField]
		Button button = null;

		int id;

		void OnDestroy()
		{
			image = null;
			button.onClick.RemoveAllListeners();
			button = null;
			onClick.RemoveAllListeners();
			onClick = null;
		}
	}

	public class BannerClickEvent : UnityEvent<int>
	{
	}
}
