﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;



public class UIHomeDailyQuestMainPage : UIPageBase
{
    private DailyQuestUtil.OpenDailyQuestParam _param;

    private int _typeId ;
    private UIDailyQuestAchievementsDialog achievementsDialog = null;
    private UIHomeDailyQuestSectionSelectDialog chapterSelector = null;

    private UIHomeHeaderParam headerParam = new UIHomeHeaderParam(){
        
        visibleBack = false,
        visibleIcon = false,
        visiblePlayerStatus = true,
        visibleRightRank = false,
        visibleNavigation = true,
        visibleHome = true,
        showResType = new List<UIHeaderResType>()
        {
            UIHeaderResType.Coin, UIHeaderResType.Stamina, UIHeaderResType.GemFree, UIHeaderResType.GemPaid
        },
    };

    private UIHomeDailyQuestSectionDetailDialog sectionDetail = null;
    private int sectionsId = 0;
    private UIHomeDailyQuestSkipSettlementDialog skipDialog = null;

    private UIHomeDailyQuestTypeSelectDialog typeSelector = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        if (param is DailyQuestUtil.OpenDailyQuestParam)
        {
            _param = param as DailyQuestUtil.OpenDailyQuestParam;
        }
        
        typeSelector = await UI.Dialog.CreateAsync(UIPrefabId.UIDailyQuestTypeSelectDialog, CanvasType.App0) as UIHomeDailyQuestTypeSelectDialog;
        chapterSelector = await UI.Dialog.CreateAsync(UIPrefabId.UIDailyQuestSectionSelectDialog, CanvasType.App0) as UIHomeDailyQuestSectionSelectDialog;
        sectionDetail = await UI.Dialog.CreateAsync(UIPrefabId.UIDailyQuestSectionDetailDialog, CanvasType.App0) as UIHomeDailyQuestSectionDetailDialog;
        achievementsDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIDailyQuestAchievementsDialog, CanvasType.App1) as UIDailyQuestAchievementsDialog;

        typeSelector.OnClickBackButton.GuardSubscribeAsync(ShowMainMenu).AddTo(mSubscriptions);
        typeSelector.typeActive.GuardSubscribeAsync(ShowChapterWithTypeIdAsync).AddTo(mSubscriptions);
        chapterSelector.backToType.GuardSubscribeAsync(ShowTypeAsync).AddTo(mSubscriptions);
        chapterSelector.sectionActive.GuardSubscribeAsync(ShowDetailAsync).AddTo(mSubscriptions);
        chapterSelector.princesActive.GuardSubscribeAsync(ShowPrincesDetailAsync).AddTo(mSubscriptions);
        chapterSelector.chapterActive.GuardSubscribeAsync(ShowChapterActiveDetailAsync).AddTo(mSubscriptions);
        sectionDetail.backToChapter.GuardSubscribeAsync(HideDetailAsync).AddTo(mSubscriptions);
        sectionDetail.SkipStart.GuardSubscribeAsync(ShowSkipDialog).AddTo(mSubscriptions);
        sectionDetail.BattleStart.GuardSubscribeAsync(StartBattle).AddTo(mSubscriptions);
        sectionDetail.Achievement.GuardSubscribeAsync(ShowAchievement).AddTo(mSubscriptions);
        
        skipDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIDailyQuestSkipSettlementDialog, CanvasType.App1) as UIHomeDailyQuestSkipSettlementDialog;
        skipDialog.ClickAgain.GuardSubscribeAsync(ShowSkipDialog).AddTo(mSubscriptions);
        
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHomeHeaderUpdate, headerParam);
        await base.ShowAsync(showType);
        sectionDetail.ClearList();
        if (_param != null)
        {
            switch (_param.T)
            {
                case DailyQuestUtil.OpenDailyQuestParam.OpenPageType.ShowChapters:
                    await ShowChapterWithChapterIdAsync(_param.ID);
                    break;
                case DailyQuestUtil.OpenDailyQuestParam.OpenPageType.ShowDetail:
                    await ShowChapterWithChapterIdAsync( DataManager.Instance.Master.DailyQuestsSection[_param.ID].chapterMasterId);
                    await ShowDetailAsync(_param.ID);
                    break;
                default:
                    await ShowTypeAsync();
                    break;
            }
        }
        else
        {
            await ShowTypeAsync();
        }
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await typeSelector.HideAsync();
        await chapterSelector.HideAsync();
        await sectionDetail.HideAsync();
    }

    private async UniTask ShowAchievement(int battleId)
    {
        await achievementsDialog.SetUpAsync(battleId);
        await achievementsDialog.ShowAsync();
    }

    private async UniTask ShowChapterWithTypeIdAsync(int typeId)
    {
        var master = DataManager.Instance.Master.DailyQuestsType[typeId];
        if (master.requirePlayerLevel > DataManager.Instance.Player.Player.GetLevel())
        {
            var msg = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Level_Format"), master.requirePlayerLevel );
            UI.Popup.ShowPopMessage(msg);
            return;
        }
        
        var stageId = master.requireStageId;
        if (stageId > 0 && !StoryUtil.IsClear(stageId))
        {
            var chapterName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{stageId}_name");
            int chapterNum = DataManager.Instance.Master.Chapter[stageId].chapter;
            var msg = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Stage_Format"), chapterNum, chapterName);
            UI.Popup.ShowPopMessage(msg);
            return;
        }
        var active = DataManager.Instance.Player.DailyQuest.TodayDailyQuestTypes.Contains(typeId);
        if (!active)
        {
            var requirePlayerLevel = DataManager.Instance.Master.DailyQuestsSection.Values.Where(m=>m.chapterMasterId == typeId).Min( m=> m.requirePlayerLevel);
            await UI.Popup.ShowPopupMessageAsync(string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_open_level"), new object[] { requirePlayerLevel}));
            return;
        }

        _typeId = typeId;
        sectionsId = 0;
        await chapterSelector.SetUpAsync(typeId, 0);
        await typeSelector.HideAsync();
        //await sectionDetail.HideAsync();
        await chapterSelector.ShowAsync();
    }

    private async UniTask ShowChapterWithChapterIdAsync(int id)
    {
        _typeId = 0;
        
        
        var level = 0;
        var stage = 0;
        switch (_param.T)
        {
            case DailyQuestUtil.OpenDailyQuestParam.OpenPageType.ShowChapters:
                var master = DataManager.Instance.Master.DailyQuestsType[id];
                level = master.requirePlayerLevel;
                stage = master.requireStageId;
                break;
            case DailyQuestUtil.OpenDailyQuestParam.OpenPageType.ShowDetail:
                var chapte = DataManager.Instance.Master.DailyQuestsChapter[id];
                var masters = DataManager.Instance.Master.DailyQuestsType[chapte.dailyQuestTypeMasterId];
                level = masters.requirePlayerLevel;
                stage = masters.requireStageId;
                break;
        }
        if (level > DataManager.Instance.Player.Player.GetLevel())
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_not_open"));
            await ShowTypeAsync();
            return;
        }
        
        var stageId = stage;
        if (stageId > 0 && !StoryUtil.IsClear(stageId))
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_not_open"));
            await ShowTypeAsync();
            return;
        }
        if (!DataManager.Instance.Player.DailyQuest.TodayDailyQuestChapters.Contains(id))
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_not_open"));
        }
        switch (_param.T)
        {
            case DailyQuestUtil.OpenDailyQuestParam.OpenPageType.ShowChapters:
                await chapterSelector.SetUpAsync(id, 0);
                break;
            case DailyQuestUtil.OpenDailyQuestParam.OpenPageType.ShowDetail:
                await chapterSelector.SetUpAsync(0, id);
                break;
        }
       
        await sectionDetail.HideAsync();
        await chapterSelector.ShowAsync();
    }

    private async UniTask HideDetailAsync(int id)
    {
        await sectionDetail.HideAsync();

    }


    private async UniTask ShowTypeAsync()
    {
        await chapterSelector.HideAsync();
        await typeSelector.ShowAsync();
        await typeSelector.SetUpAsync();
    }

    private async UniTask ShowDetailAsync(int id)
    {
        var master = DataManager.Instance.Master.DailyQuestsSection[id];
        var levelSatisfied = DataManager.Instance.Player.Player.GetLevel() >= master.requirePlayerLevel;
        if (!levelSatisfied)
        {
            await UI.Popup.ShowPopupMessageAsync(string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_open_level"), new object[] {  master.requirePlayerLevel}));
            return;
        }

        var masterId = DataManager.Instance.Player.DailyQuest.TryGet(master.preDailyQuestMasterId);
        if (master.preDailyQuestMasterId !=0 && masterId == null)
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_open_forward"));
            return;
        }
        
        await sectionDetail.SetUpAsync(id);
        //await chapterSelector.HideAsync();
        await sectionDetail.ShowAsync();
    }

    private async UniTask ShowPrincesDetailAsync(int id)
    {
        if (!DataManager.Instance.Player.DailyQuest.TodayDailyQuestChapters.Contains(id))
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_not_open"));
            return;
        }
        var sectionMasters = DataManager.Instance.Master.DailyQuestsSection.Values.
            Where(x => x.chapterMasterId == id).
            OrderBy(x => x.id).ToArray();
        //var master = DataManager.Instance.Master.DailyQuestsSection[sectionMasters[0].id];
        
        await sectionDetail.SetUpAsync(sectionMasters[0].id);
        //await chapterSelector.HideAsync();
        await sectionDetail.ShowAsync();
    }

    private async UniTask ShowChapterActiveDetailAsync(int id)
    {
        if (sectionsId == id)
        {
            return;
        }
        var master = DataManager.Instance.Master.DailyQuestsChapter[id];
        if (!DataManager.Instance.Player.DailyQuest.TodayDailyQuestChapters.Contains(master.id))
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_not_open"));
            return;
        }
        if (master.requirePlayerLevel > DataManager.Instance.Player.Player.GetLevel())
        {
            var msg = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Level_Format"), master.requirePlayerLevel );
            UI.Popup.ShowPopMessage(msg);
            return;
        }
        
        var stageId = master.requireStageId;
        if (stageId > 0 && !StoryUtil.IsClear(stageId))
        {
            var chapterName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{stageId}_name");
            int chapterNum = DataManager.Instance.Master.Chapter[stageId].chapter;
            var msg = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Stage_Format"), chapterNum, chapterName);
            UI.Popup.ShowPopMessage(msg);
            return;
        }
        PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01");
        sectionsId = id;
        await chapterSelector.ChangeSections(id);
        await sectionDetail.HideAsync();
        await chapterSelector.ShowAsync();
    }

    private async UniTask ShowSkipDialog(DailyQuestMaster master)
    {
        if (DataManager.Instance.Player.DailyQuest.SkipTimes <= 0)
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_skill_times"));
            return;
        }
        if (master.useStamina > DataManager.Instance.Player.Player.GetCurrentStaimina())
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_OPEN_PAID_NO"));
            //TODO xzf TT版本不要这个
            //await UI.Dialog.CreateAndShowAsync(UIPrefabId.StaminaRecover, CanvasType.App2);
            return;
        }
        if (DataManager.Instance.Player.DailyQuest.TryGet(master.id) == null)
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_clearance"));
            return;
        }
        
        await skipDialog.SetUpAsync(master);
        await skipDialog.ShowAsync();
        await sectionDetail.UpdateInformation();

    }

    private async UniTask StartBattle(DailyQuestMaster master)
    {
        await DailyQuestService.GetAvailable();
        await DailyQuestService.GetToday();
        if (!DataManager.Instance.Player.DailyQuest.TodayDailyQuestChapters.Contains(master.chapterMasterId))
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_not_open"));
            await ShowChapterWithTypeIdAsync(_typeId);
            return;
        }
        var masterId = DataManager.Instance.Player.DailyQuest.TryGet(master.preDailyQuestMasterId);
        if (master.preDailyQuestMasterId !=0 && masterId == null)
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_open_forward"));
            return;
        }
        if (master.useStamina > DataManager.Instance.Player.Player.GetCurrentStaimina())
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_OPEN_PAID_NO"));
            //TODO xzf TT版本不要这个
            //await UI.Dialog.CreateAndShowAsync(UIPrefabId.StaminaRecover, CanvasType.App2);
            return;
        }
        if (DailyQuestUtil.SectionCanActive(master))
        {
            var param = new BattleSceneParam();
            param.battleID = master.battleMasterId;
            param.stageID = master.id;
            GameSceneManager.Instance.ChangeScene<BattleScene>("BattleScene", param);
        }
    }

    private async UniTask ShowMainMenu(GameObject o)
    {
        await UI.Page.CloseCurrentPage();
        // await UI.Page.ChangePage<UIHomeMainPage>();
    }


    public override void Dispose()
    {
        base.Dispose();
        if (typeSelector != null)
        {
            typeSelector.Dispose();
            typeSelector = null;
        }

        if (chapterSelector != null)
        {
            chapterSelector.Dispose();
            chapterSelector = null;
        }

        if (sectionDetail != null)
        {
            sectionDetail.Dispose();
            sectionDetail = null;
        }

        if (skipDialog != null)
        {
            skipDialog.Dispose();
            skipDialog = null;
        }
    }
}
