using System;
using System.Collections.Generic;
using System.Linq;
using Battle.Utils;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIHomeDailyQuestSectionDetailDialog: UIDialogBase
{
    [SerializeField] private Image btnBg;
    [SerializeField] private UIText descText;
    [SerializeField] private UIButton backBtn;
    [SerializeField] private UIText recommendLevel;
    [SerializeField] private RectTransform rewardsLayout;
    [SerializeField] private BaseItem reward;
    [SerializeField] private UIText stamina;
    [SerializeField] private UIButton battleStart;
    [SerializeField] private UIButton skipStart;
    [SerializeField] private UIText title;
    [SerializeField] private Image sectionBg;
    [SerializeField] private UIText showLablTitle;
    [SerializeField] private UIText remainSkipTimes;
    [SerializeField] private UIText remainMultiTimes;
    [SerializeField] private UIButton closeBtn;
    [SerializeField] private GameObject listObj;
    [SerializeField] private GameObject dropObj;
    [Space] 
    [SerializeField] private RectTransform tableParent;
    [SerializeField] private UIDailyQuestSectionDetailTab tabPrefab;
    [Space] 
    [SerializeField] private UIButton achievementButton;
    [SerializeField] private UIText achievementText;

    List<UIDailyQuestSectionDetailTab> _tabs = new List<UIDailyQuestSectionDetailTab>();
    public UIIntEvent backToChapter = new UIIntEvent();
    private DailyQuestMaster _master;
    private DailyQuestTypeMaster _typeMaster;
    private List<DailyQuestMaster> _sections = new List<DailyQuestMaster>();
    private List<BaseItem> _rewards = new List<BaseItem>();
    private int _index;
    public UIDailyQuestMasterEvent SkipStart = new UIDailyQuestMasterEvent();
    public UIDailyQuestMasterEvent BattleStart = new UIDailyQuestMasterEvent();
    public UIIntEvent Achievement = new UIIntEvent();
    public override async UniTask InitializeAsync()
    { 
        await base.InitializeAsync();
        backBtn.onClick.Subscribe((_) =>
        {
            backToChapter.Invoke(_master.chapterMasterId);
        }).AddTo(mSubscriptions);
        closeBtn.onClick.Subscribe((_) =>
        {
            backToChapter.Invoke(_master.chapterMasterId);
        }).AddTo(mSubscriptions);
        battleStart.onClick.Subscribe((_) =>
        {
            BattleStart.Invoke(_master);
        }).AddTo(mSubscriptions);
        skipStart.onClick.SubscribeAsync(async (_) =>
        {
            SkipStart.Invoke(_master);
        }).AddTo(mSubscriptions);
        achievementButton.onClick.SubscribeAsync(async (_) =>
        {
            Achievement.Invoke(_master.battleMasterId);
        }).AddTo(mSubscriptions);
    }

    public void ClearList()
    {
        battleIds.Clear();
    }

    public async UniTask SetUpAsync(int sectionId)
    {
        FillSections(sectionId);
        await UpdateInformation();
    }
     
    private void FillSections(int sectionId)
    {
        _sections.Clear();
        descText.SetLabel(LocalizeManager.DATA_TYPE.DAILY_QUEST, $"{sectionId}_desc");
        var master = DataManager.Instance.Master.DailyQuestsSection.
            Where(x => x.Key == sectionId).First().Value;
        _master = master;
        _sections = DataManager.Instance.Master.DailyQuestsSection.Values
            .Where(x => x.chapterMasterId == _master.chapterMasterId)
            .OrderBy(x => x.id).ToList();
        _index = _sections.IndexOf(_master);
        title.SetLabel(LocalizeManager.DATA_TYPE.DAILY_QUEST, $"chapter_title_{master.chapterMasterId}");
        _typeMaster = master.FindDailyQuestTypeMaster();
        if (_typeMaster.showDetailType == 2)
        {
            //new
            AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(master); });
            //sectionBg.sprite = ResourceManager.Instance.LoadSpriteSmall("DailyQuest", $"section_bg_big_{master.chapterMasterId}");
        }
        closeBtn.gameObject.SetActive(_typeMaster.showDetailType == 1);
        listObj.SetActive(_typeMaster.showDetailType == 2);
    }

    private List<long> battleIds = new List<long>();
    public async UniTask UpdateInformation()
    {
        if (!battleIds.Contains(_master.battleMasterId))
        {
            await BattleAchievementService.BattleAchievementGet(new List<long> {_master.battleMasterId});
            battleIds.Add(_master.battleMasterId);
        }

        await SetSectionBgAndTitle();
        await SetRewardItemsButton();
        await SetInformation();
        if (_typeMaster.showDetailType == 2)
        {
            await SetTabInfo();
        }
        if (!DailyQuestUtil.SectionCanActive(_master))
        {
            //battleStart.enabled = false;
            battleStart.GetComponent<Image>().color = Color.black;
        }
        else
        {
            battleStart.GetComponent<Image>().color = Color.white;
        }

        if (!DailyQuestUtil.SectionCanSkip(_master))
        {
            //skipStart.enabled = false;
            skipStart.GetComponent<Image>().color = Color.black;
        }
        else
        {
            skipStart.GetComponent<Image>().color = Color.white;
        }

        LoadAchievement();
    }

    private void LoadAchievement()
    {
        var battleID = _master.battleMasterId;
        var achievedAchievementIds = BattleAchievementUtil.GetAchievedBattleAchievements(battleID);
        BattleStageMaster battleStageMaster = DataManager.Instance.Master.BattleStageMaster[battleID];
        if (battleStageMaster.relatedAchievements.Count < 1)
        {
            achievementButton.gameObject.SetActive(false);
        }
        else{
            achievementButton.gameObject.SetActive(true);
            achievementText.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST,"Achievement",achievedAchievementIds.Count,battleStageMaster.relatedAchievements.Count);
        }

  }

    public async UniTask SetTabInfo()
    {
        foreach (var tab in _tabs)
        {
            tab.gameObject.SetActive(false);
            tab.onClick.RemoveAllListeners();
        }
        
        for (int i = 0; i < _sections.Count; i++)
        {
            if (i < _tabs.Count)
            {
                await _tabs[i].SetUpAsync( _sections[i]);
                var i1 = i;
                if (DailyQuestUtil.SectionActive(_sections[i]))
                {
                    _tabs[i].onClick.Subscribe((_) =>
                    {
                        _master = _sections[i1];
                        PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01");
                        AsyncManager.Instance.StartAsync(UpdateInformation());
                    });
                }
                else
                {
                    _tabs[i].onClick.Subscribe((_) =>
                    {
                        _master = _sections[i1];
                        PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01");
                        AsyncManager.Instance.StartAsync(ShowPopup());
                    });
                }

                _tabs[i].gameObject.SetActive(true);
            }
            else
            {
                var tabBtn = Instantiate(tabPrefab, tableParent, false);
                await tabBtn.SetUpAsync( _sections[i]);
                var i1 = i;
                if (DailyQuestUtil.SectionActive(_sections[i]))
                {
                    tabBtn.onClick.Subscribe((_) =>
                    {
                        _master = _sections[i1];
                        PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01");
                        AsyncManager.Instance.StartAsync(UpdateInformation());
                    });
                } 
                else
                {
                    tabBtn.onClick.Subscribe((_) =>
                    {
                        _master = _sections[i1];
                        PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01");
                        AsyncManager.Instance.StartAsync(ShowPopup());
                      
                    });
                }
                tabBtn.gameObject.SetActive(true);
                _tabs.Add(tabBtn);
            }
        }
        foreach (var tab in _tabs)
        {
            tab.SetSelectActive(_master.id);
        }
    }

    private async UniTask ShowPopup()
    {
        var master = _master;
        var levelSatisfied = DataManager.Instance.Player.Player.GetLevel() >= master.requirePlayerLevel;
        if (!levelSatisfied)
        {
            await UI.Popup.ShowPopupMessageAsync(string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_open_level"), new object[] {  master.requirePlayerLevel}));
            return;
        }

        var masterId = DataManager.Instance.Player.DailyQuest.TryGet(master.preDailyQuestMasterId);
        if (master.preDailyQuestMasterId !=0 && masterId == null)
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_open_forward"));
            return;
        }
    }

    private async UniTask SetSectionBgAndTitle()
    {
        sectionBg.color = Color.white;
    }
    
    private async UniTask SetRewardItemsButton()
    {
        foreach (var gObj in _rewards)
        {
             gObj.gameObject.SetActive(false);
        }
        var displayElements = _master.displayDropRewardContents;
        if (displayElements.Count > 3)
        {
            displayElements = displayElements.GetRange(0, 3);
        }

        int index = 0;
        foreach (var contentId in displayElements)
        {
            //var key = DailyQuestUtil.GetRewardContentIconKey(contentId, out var id);
            if (index < _rewards.Count)
            {
                await _rewards[index].SetupAsync(contentId, "");
                _rewards[index].gameObject.SetActive(true);
            }
            else
            {
                var button = Instantiate(reward, rewardsLayout, false);
                button.transform.localScale = new Vector3(0.8f, 0.8f, 1f);
                await button.SetupAsync(contentId, "");
                button.gameObject.SetActive(true);
                _rewards.Add(button);
            }
            index++;

        }
    }

    private async UniTask SetInformation()
    {
        recommendLevel.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, "section_detail_recommend_level", _master.recommendPlayerLevel);
        stamina.SetRawText(_master.useStamina.ToString());
        var number = DataManager.Instance.Player.DailyQuest.GetMultiTimes(DataManager.Instance.Master.DailyQuestsChapter[_master.chapterMasterId].dailyQuestTypeMasterId);
        if (number > 0)
        {
            dropObj.SetActive(true);
            remainMultiTimes.gameObject.SetActive(true);
            remainMultiTimes.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, "remain_multi_times", number);
        }
        else
        {
            dropObj.SetActive(false);
            remainMultiTimes.gameObject.SetActive(false);
        }

        remainSkipTimes.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, "remain_skip_times", DataManager.Instance.Player.DailyQuest.SkipTimes);
    }

    private async UniTask LoadSpriteAsync(DailyQuestMaster master)
    {
        sectionBg.sprite = await ResourceManager.Instance.LoadSpriteAsync("DailyQuest", $"section_bg_big_{master.chapterMasterId}");
    }
}

public class UIDailyQuestMasterEvent: UnityEvent<DailyQuestMaster>
{
}
