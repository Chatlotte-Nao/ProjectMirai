using System;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using TMPro;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIHomeDailyQuestSectionSelectDialog: UIDialogBase
{
    [SerializeField] private UIButton backButton;
    [SerializeField] private UIText titleBar;
    [Space]
    [SerializeField] private RectTransform sectionButtonParent;
    [SerializeField] private UIHomeDailyQuestSectionSelectButton sectionPrefab;
    [Space]
    [SerializeField] private RectTransform chapterButtonParent;
    [SerializeField] private UIHomeDailyQuestChapterButton chapterPrefab;
    // [SerializeField] private UIText remainSkipTimes;
    // [SerializeField] private UIText remainMultiTimes;
    [Space]
    [SerializeField] private RectTransform chapterPrincesParent;
    [SerializeField] private UIDailyQuestChapterPrincesButton chapterPrincesPrefab;
    [Space]
    [SerializeField] private GameObject content1Obj;
    [SerializeField] private GameObject content2Obj;
    private List<UIHomeDailyQuestSectionSelectButton> sections = new List<UIHomeDailyQuestSectionSelectButton>();
    private List<UIHomeDailyQuestChapterButton> chapters = new List<UIHomeDailyQuestChapterButton>();
    
    private List<UIDailyQuestChapterPrincesButton> chapterPrinces = new List<UIDailyQuestChapterPrincesButton>();
    private float srcollAverage;
    public UnityEvent backToType = new UnityEvent();
    public UIIntEvent chapterActive = new UIIntEvent();
    public UIIntEvent sectionActive = new UIIntEvent();
    public UIIntEvent princesActive = new UIIntEvent();
    DailyQuestTypeMaster _dailyQuestTypeMaster;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        backButton.onClick.Subscribe((_) =>
        {
            backToType.Invoke();
        }).AddTo(mSubscriptions);
    }

    private int typeId_;
    public async UniTask SetUpAsync(int typeId, long chapterId)
    {
        if (typeId == 0)
        {
            typeId = DataManager.Instance.Master.DailyQuestsChapter.Where(x => x.Key == chapterId).First().Value
                .dailyQuestTypeMasterId;
        }
        typeId_ = typeId;
        titleBar.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, $"type_title_{typeId}");
        // remainMultiTimes.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, "remain_multi_times",
        //     DataManager.Instance.Player.DailyQuest.GetMultiTimes(typeId));
        // remainSkipTimes.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, "remain_skip_times",
        //     DataManager.Instance.Player.DailyQuest.SkipTimes);
        _dailyQuestTypeMaster = DataManager.Instance.Master.DailyQuestsType[typeId];
        if (_dailyQuestTypeMaster.showDetailType != 2)
        {
            content1Obj.SetActive(true);
            content2Obj.SetActive(false);
            await LoadChaptersInfo(typeId, chapterId);
        }
        else
        {
            content1Obj.SetActive(false);
            content2Obj.SetActive(true);
            await LoadSection2();
        }
        
    }

    public async UniTask LoadChaptersInfo(int typeId, long chapterId)
    {
        foreach (var chapter in chapters)
        {
            chapter.onClick.RemoveAllListeners();
            chapter.gameObject.SetActive(false);
        }

        var chapterMasters = DataManager.Instance.Master.DailyQuestsChapter.Values
            .Where(x => x.dailyQuestTypeMasterId == typeId).ToArray();
        var chapterIndex = 0;
        if (chapterMasters.Length > 1)
        {
            for (int i = 0; i < chapterMasters.Length; i++)
            {
                var master = chapterMasters[i];
                if (i < chapters.Count)
                {
                    await chapters[i].InitializeAsync(chapterIndex, master);
                    chapters[i].onClick.Subscribe(_ => chapterActive.Invoke(master.id));
                    chapters[i].gameObject.SetActive(true);
                }
                else
                {
                    var chapter = Instantiate(chapterPrefab, chapterButtonParent, false);
                    await chapter.InitializeAsync(chapterIndex, master);
                    chapter.onClick.Subscribe(_ => chapterActive.Invoke(master.id));
                    chapter.gameObject.SetActive(true);
                    chapters.Add(chapter);
                }
                chapterIndex++;
            }
        }
        if (chapterId == 0 || !DataManager.Instance.Player.DailyQuest.TodayDailyQuestChapters.Contains(chapterId))
        {
            chapterId =  DailyQuestUtil.GetFirstAbleChapterId(typeId);
        }
        await ChangeSections(Convert.ToInt32(chapterId));
    }

    public async UniTask ChangeSections(int chapterId)
    {
        foreach (var chapter in chapters)
        {
            chapter.SetActiveLine(chapterId);
        }
        if (_dailyQuestTypeMaster.showDetailType != 2)
            await LoadSection1(chapterId);
        else 
            await LoadSection2();
        
    }

    public async UniTask LoadSection1(int chapterId)
    {
        foreach (var section in sections)
        {
            section.onClick.RemoveAllListeners();
            section.gameObject.SetActive(false);
            //Destroy(section.gameObject);
        }
        var sectionMasters = DataManager.Instance.Master.DailyQuestsSection.Values.
            Where(x => x.chapterMasterId == chapterId).
            OrderBy(x => x.id).ToArray();
        var sectionIndex = 0;
        if (sectionMasters.Length > 0)
        {
            for (int i = 0; i < sectionMasters.Length; i++)
            {
                var master = sectionMasters[i];
                if (i < sections.Count)
                {
                    await sections[i].InitializeAsync(sectionIndex, master);
                    sections[i].onClick.Subscribe(_ => sectionActive.Invoke(master.id));
                    sections[i].gameObject.SetActive(true);
                }
                else
                {
                    var section = Instantiate(sectionPrefab, sectionButtonParent, false);
                    await section.InitializeAsync(sectionIndex, master);
                    section.onClick.Subscribe(_ =>  sectionActive.Invoke(master.id));
                    section.gameObject.SetActive(true);
                    sections.Add(section);
                }
                //await UniTask.DelayFrame(5);
                sectionIndex++;
            }
        }
    }
    public async UniTask LoadSection2()
    {
        foreach (var chapter in chapterPrinces)
        {
            chapter.onClick.RemoveAllListeners();
            chapter.gameObject.SetActive(false);
        }
     
        var chapterMasters = DataManager.Instance.Master.DailyQuestsChapter.Values.
            Where(x => x.dailyQuestTypeMasterId == typeId_).ToArray();
        var chapterIndex = 0;
        if (chapterMasters.Length > 1)
        {
            for (int i = 0; i < chapterMasters.Length; i++)
            {
                var master = chapterMasters[i];
                if (i < chapterPrinces.Count)
                {
                    await chapterPrinces[i].InitializeAsync( master);
                    chapterPrinces[i].onClick.Subscribe(_ => princesActive.Invoke(master.id));
                    chapterPrinces[i].gameObject.SetActive(true);
                }
                else
                {
                    var chapter = Instantiate(chapterPrincesPrefab, chapterPrincesParent, false);
                    await chapter.InitializeAsync( master);
                    chapter.onClick.Subscribe(_ => princesActive.Invoke(master.id));
                    chapter.gameObject.SetActive(true);
                    chapterPrinces.Add(chapter);
                }
                //await UniTask.DelayFrame(5);
                chapterIndex++;
            }
        }
    }
}