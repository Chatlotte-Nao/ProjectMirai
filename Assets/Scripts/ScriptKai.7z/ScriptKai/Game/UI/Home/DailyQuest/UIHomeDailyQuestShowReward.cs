
using UnityEngine;
using UnityEngine.UI;
using Pheonix.Core;

public class UIHomeDailyQuestShowReward : MonoBehaviour
{
    [SerializeField] private Image icon;
    [SerializeField] private Image frame;
    [SerializeField] private UIButton button;
}