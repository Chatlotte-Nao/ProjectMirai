﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using Pheonix.Core;
using Cysharp.Threading.Tasks;


public class UIHomeDailyQuestTypeSelectDialog : UIDialogBase
{
    [SerializeField] UIHomeDailyQuestTypeSelectButton dailyQuestTypePrefab;
    [SerializeField] RectTransform buttonParent;
    [SerializeField] RectTransform layoutParent;
    [SerializeField] ScrollRect typeScrollRect;
    [SerializeField] UIButton backButton;

    private List<UIHomeDailyQuestTypeSelectButton> chapterTypes = new List<UIHomeDailyQuestTypeSelectButton>();
    public UIIntEvent  typeActive = new UIIntEvent();
    public ClickEvent OnClickBackButton => backButton.onClick;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        typeScrollRect.vertical = false;
        typeScrollRect.content = layoutParent;
    }
    
    
    public async UniTask SetUpAsync()
    {
        foreach (var button in chapterTypes)
        {
            //Destroy(button.gameObject);
            button.onClick.RemoveAllListeners();
            button.gameObject.SetActive(false);
        }
        
        var dailyQuestTypes = DataManager.Instance.Master.DailyQuestsType.Values.ToArray();
        for (int i = 0; i < dailyQuestTypes.Length; i++)
        {
            var dailyQuestType = dailyQuestTypes[i];
            if (i < chapterTypes.Count)
            {
                await chapterTypes[i].UpdataDataAsync(dailyQuestType);
                chapterTypes[i].onClick.Subscribe(_ => typeActive.Invoke(dailyQuestType.id)).AddTo(mSubscriptions);
                chapterTypes[i].gameObject.SetActive(true);
            }
            else
            {
                var button = Instantiate(dailyQuestTypePrefab, this.buttonParent, false);
                await  button.InitializeAsync(dailyQuestType);
                button.onClick.Subscribe(_ => typeActive.Invoke(dailyQuestType.id)).AddTo(mSubscriptions);
                chapterTypes.Add(button);
            }

            await UniTask.DelayFrame(5);
        }        
    }

}
