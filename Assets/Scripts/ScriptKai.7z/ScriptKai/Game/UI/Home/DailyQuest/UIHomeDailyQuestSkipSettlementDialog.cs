using System;
using System.Collections.Generic;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class UIHomeDailyQuestSkipSettlementDialog: UIDialogBase
{
    [SerializeField] private UIText exp;
    [SerializeField] private UIText golden;
    [SerializeField] private UIButton again;
    [SerializeField] private BaseItem itemPrefab;
    [SerializeField] private RectTransform itemParent;
    [SerializeField] private UIButton self;
    [SerializeField] private UIText buttonText;
    [SerializeField] private UITexture titleTexture;
    [SerializeField] protected Animation mAnimation;

    private List<BaseItem> _rewards = new List<BaseItem>();
    public UIDailyQuestMasterEvent ClickAgain = new UIDailyQuestMasterEvent();
    private DailyQuestMaster _master;
    List<string> contents = new List<string>();
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        base.SetAnimation(mAnimation);
        titleTexture.Load("Font", "ty_font_sdwc_01", true);
        again.onClick.SubscribeAsync(async  (_) =>
            {
                await HideAsync();
                ClickAgain.Invoke(_master);
            }).AddTo(mSubscriptions);
        self.onClick.SubscribeAsync(async (_) =>
        {
            await HideAsync();
        }).AddTo(mSubscriptions);
    }

    private bool isLevelup = false;
    public async UniTask SetUpAsync(DailyQuestMaster master)
    {
        _master = master;
        isLevelup = false;
        again.gameObject.SetActive(false);
        var reward = await DailyQuestService.Finish(master.id, true, true, null);
        foreach (var item in _rewards)
        {
            item.gameObject.SetActive(false);
        }
  
        exp.SetFormat(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_PLAYER_EXP", reward.Exp);
        golden.SetRawText(Convert.ToString(reward.Golden));
        
        if (DataManager.Instance.Player.DailyQuest.SkipTimes == 0)
        {
            //buttonText.SetRawText("确定");
            again.onClick.RemoveAllListeners();
            again.onClick.Subscribe((_) =>
            {
                UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_skill_times"));
                Dispose();
            }).AddTo(mSubscriptions);
        }

        isLevelup = reward.isLevelUp;

        if (DataManager.Instance.Player.Equipment.firstEquipmentIds.Count > 0)
        {
            UI.Popup.ShowEquipmentFullScreen(DataManager.Instance.Player.Equipment.firstEquipmentIds);
        }
        contents.Clear();
        foreach (var item in reward.Rewards)
        {
            contents.Add($"{item.Id}:{item.Count}");
        }
        await Setup(contents);
        
    }

    public override void OnShow()
    {
        if (isLevelup)
        {
            this.gameObject.SetActive(false);
            UI.Popup.ShowCommonLevelUp();
        }
        again.gameObject.SetActive(true);
    }

    public async UniTask Setup(List<string> content)
    {
        CommonUtil.SortDictionary(content);
        int i = 0;
        foreach (var item in content)
        {
            var s = item.Split(':');
            long itemId = 0;
            string itemNum = string.Empty;
            if (s.Length > 1)
            {
                itemId = long.Parse(s[0]);
                itemNum = s[1];
            }
            else
            {
                itemId =  long.Parse(item);
            }


            if (i < _rewards.Count)
            {
                await _rewards[i].SetupAsync(itemId, itemNum);
                _rewards[i].gameObject.SetActive(true);
            }
            else
            {
                var btn = Instantiate(itemPrefab, itemParent, false);
                btn.transform.localScale = new Vector3(0.8f, 0.8f, 1f);
                await btn.SetupAsync(itemId, itemNum);
                btn.gameObject.SetActive(true);
                _rewards.Add(btn);
            }

            i++;
        }
    }

}