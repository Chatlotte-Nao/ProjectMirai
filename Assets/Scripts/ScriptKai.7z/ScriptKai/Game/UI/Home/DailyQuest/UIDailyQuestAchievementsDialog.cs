using System.Collections;
using System.Collections.Generic;
using Battle.Unity.BattleUI;
using Battle.Utils;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;

public class UIDailyQuestAchievementsDialog : UIDialogBase
{
    [SerializeField] private BattleAchievementItem achievementCell;
    [SerializeField] private RectTransform cellParent;
    List<BattleAchievementItem> rewardItems = new List<BattleAchievementItem>();
    
    public async UniTask SetUpAsync(int battleID)
    {
        var achievedAchievementIds = BattleAchievementUtil.GetAchievedBattleAchievements(battleID);
        BattleStageMaster battleStageMaster = DataManager.Instance.Master.BattleStageMaster[battleID];
        List<int> tempAchvIds = battleStageMaster.relatedAchievements;
        string[] rewardStr;
        foreach (var rewardItem in rewardItems)
        {
            rewardItem.gameObject.SetActive(false);
        }    
        for(int i = 0;i< tempAchvIds.Count;i++)
        {
            BattleAchievementMaster achvMaster =DataManager.Instance.Master.BattleAchievementMaster[tempAchvIds[i]];
            rewardStr = achvMaster.rewards[0].Split(':');
            if (i < rewardItems.Count)
            {
                rewardItems[i].InitAchievement(achvMaster.title, achvMaster.describe, long.Parse(rewardStr[0]), rewardStr[1], achievedAchievementIds.Contains(achvMaster.id));
                rewardItems[i].gameObject.SetActive(true);
            }
            else
            {
                var cell = Instantiate(achievementCell, cellParent);
                cell.InitAchievement(achvMaster.title, achvMaster.describe, long.Parse(rewardStr[0]), rewardStr[1], achievedAchievementIds.Contains(achvMaster.id));
                rewardItems.Add(cell);
                cell.gameObject.SetActive(true);
            }
        }
    }
}
