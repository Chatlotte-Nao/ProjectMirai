
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;

public class UIHomeDailyQuestSectionSelectButton : MonoBehaviour
{
    [SerializeField] private UIText title;
    [SerializeField] private UIButton self;
    [SerializeField] private GameObject activeLine;
    [SerializeField] private GameObject badgeNew;
    [SerializeField] private GameObject badgeClear;
    [SerializeField] private BaseItem rewards;
    [SerializeField] private Image btnBg;
    [SerializeField] private RectTransform rewardsLayout;
    [SerializeField] private VerticalLayoutGroup vertical;
    [SerializeField] private UIText lockText;
    private DailyQuestMaster _master;
    private List<GameObject> _elements = new List<GameObject>();
    private List<BaseItem> _rewards = new List<BaseItem>();
    private int _index;
    
    public ClickEvent onClick => self.onClick;
    public async UniTask InitializeAsync(int index, DailyQuestMaster master)
    {
        await UpdataDataAsync(index, master);
        await SetRewardItemsButton();
    }

    public async UniTask UpdataDataAsync(int index, DailyQuestMaster master)
    {
        _master = master;
        _index = index;
        var active = DailyQuestUtil.SectionCanActive(_master);
        activeLine.SetActive(!active);
        if (!active)
        {
            var masterId = DataManager.Instance.Player.DailyQuest.TryGet(master.preDailyQuestMasterId);
            if (master.preDailyQuestMasterId != 0 && masterId == null)
            {
                lockText.SetLabel(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_open_forward");
            }
            else
            {
                var levelSatisfied = DataManager.Instance.Player.Player.GetLevel() >= master.requirePlayerLevel;
                if (!levelSatisfied)
                {
                    var str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST,
                            "daily_quest_open_level"), new object[] {master.requirePlayerLevel});
                    lockText.SetRawText(str);
                }
                else
                {
                    if (master.useStamina > DataManager.Instance.Player.Player.GetCurrentStaimina())
                    {
                        activeLine.SetActive(false);
                    }
                    lockText.gameObject.SetActive(false);
                }
            }
        }

        //btnBg.color = active ? Color.white : Color.black;
        var clear = DailyQuestUtil.SectionCanClear(_master);
        badgeClear.gameObject.SetActive(clear);
        var isActive = DailyQuestUtil.SectionActive(_master);
        badgeNew.SetActive(isActive && !clear);
    }
    
    private async UniTask SetRewardItemsButton()
    {
        title.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, $"section_title_{_master.id}");
        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(_master); });
        //btnBg.sprite = ResourceManager.Instance.LoadSpriteSmall("DailyQuest", $"section_bg_{_master.chapterMasterId}");
        vertical.padding.bottom = _index % 2 == 0 ? 0 : 90;
        foreach (var reward in _rewards)
        {
            reward.gameObject.SetActive(false);
        }

        var displayElements = _master.displayDropRewardContents;
        if (displayElements.Count > 3)
        {
            displayElements = displayElements.GetRange(0, 3);
        }

        for (int i = 0; i < displayElements.Count; i++)
        {
            //var key = DailyQuestUtil.GetRewardContentIconKey(displayElements[i], out var id);
            if (i < _rewards.Count)
            {
                await _rewards[i].SetupAsync(displayElements[i],"" );
                _rewards[i].gameObject.SetActive(true);
            }
            else
            {
                var button = Instantiate(rewards, rewardsLayout, false);
                await button.SetupAsync(displayElements[i], "");
                button.gameObject.SetActive(true);
                _rewards.Add(button);
            }
        }
    }

    private async UniTask LoadSpriteAsync(DailyQuestMaster _master)
    {
        btnBg.sprite = await ResourceManager.Instance.LoadSpriteAsync("DailyQuest", $"section_bg_{_master.chapterMasterId}");
    }
}
