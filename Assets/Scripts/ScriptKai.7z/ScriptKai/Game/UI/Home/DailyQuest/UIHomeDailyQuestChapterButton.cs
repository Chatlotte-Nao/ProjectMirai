using System;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using Image = UnityEngine.UI.Image;

public class UIHomeDailyQuestChapterButton: MonoBehaviour
{
    [SerializeField] private Image activeLine;
    [SerializeField] private UIText title;
    [SerializeField] private UIText desc;
    [SerializeField] private UIButton self;
    [SerializeField] Image bgImage;
    [SerializeField] private Image iconImage;
    [SerializeField] private RectTransform content;
    [SerializeField] GameObject lockObj;
    private DailyQuestChapterMaster _master;
    //private int _index;
    //private bool active;
    // private Color originColor;
    public ClickEvent onClick => self.onClick;
    public async UniTask InitializeAsync(int index, DailyQuestChapterMaster master)
    {
        _master = master;
        //_index = index;
        activeLine.gameObject.SetActive(false);
        title.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, $"chapter_title_{_master.id}");
        desc.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, $"chapter_desc_{_master.id}");
        //originColor = activeLine.color;
        // self.onClick.Subscribe((_) =>
        // {
        //     action.Invoke(_master.id);
        // });
        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(_master); });
        //iconImage.sprite = ResourceManager.Instance.LoadSpriteSmall("DailyQuest", $"section_btn_{_master.id}");
        lockObj.gameObject.SetActive(false);
        if (!DataManager.Instance.Player.DailyQuest.TodayDailyQuestChapters.Contains(_master.id))
        {
            //activeLine.gameObject.SetActive(true);
            bgImage.color = Color.white;;
            lockObj.SetActive(true);
            return;
        }
        if (master.requirePlayerLevel > DataManager.Instance.Player.Player.GetLevel())
        {
            bgImage.color = Color.black;;
            lockObj.SetActive(true);
        }
        
        var stageId = master.requireStageId;
        if (stageId > 0 && !StoryUtil.IsClear(stageId))
        {
            bgImage.color = Color.black;;
            lockObj.SetActive(true);
        }
    }

    public void SetActiveLine(int id)
    {
        activeLine.gameObject.SetActive(id ==_master.id );
        content.localPosition = id == _master.id ? new Vector3(0, 35, 0) : new Vector3(0, 0, 0);
        bgImage.gameObject.SetActive(id !=_master.id );
    }

    private async UniTask LoadSpriteAsync(DailyQuestChapterMaster _master)
    {
        iconImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("DailyQuest", $"section_btn_{_master.id}");
    }
}
