﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using UnityEngine.UI;
using Cysharp.Threading.Tasks;
public class UIDailyQuestChapterPrincesButton : MonoBehaviour
{
    [SerializeField] UIText title;
    [SerializeField] UIText desciTxt;
    [SerializeField] UIButton button;
    [SerializeField] Image textBg;
    [SerializeField] BaseItem rewardElement;
    [SerializeField] RectTransform rewardParent;
    [SerializeField] private GameObject badgeClear;
    [SerializeField] private GameObject lockImage;
    [SerializeField] private Animation lockAnimation;

    private List<BaseItem> items = new List<BaseItem>();
    private DailyQuestChapterMaster _master;
    public ClickEvent onClick => button.onClick;
    public async UniTask InitializeAsync(DailyQuestChapterMaster master)
    {
        await UpdataDataAsync(master);
        await SetRewardItemsButton();
        
    }
    public async UniTask UpdataDataAsync(DailyQuestChapterMaster master)
    {
        _master = master;
       
        badgeClear.SetActive(DailyQuestUtil.chapterAllClear(master));
        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(_master); });
        //textBg.sprite = ResourceManager.Instance.LoadSpriteSmall("DailyQuest", $"section_bg_{_master.id}");
        //var allClear = DailyQuestUtil.SectionAllClear(master);
        //badgeClear.gameObject.SetActive(allClear);
        title.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, $"chapter_title_{_master.id}");
        desciTxt.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, $"chapter_desc_{_master.id}");
        var active = DataManager.Instance.Player.DailyQuest.TodayDailyQuestChapters.Contains(_master.id);
        lockImage.SetActive(!active);
        if (!active)
        {
            return;
        }

        if (master.requirePlayerLevel > DataManager.Instance.Player.Player.GetLevel())
        {
            lockImage.SetActive(true);
            return;
        }
        
        var stageId = master.requireStageId;
        if (stageId > 0 && !StoryUtil.IsClear(stageId))
        {
            lockImage.SetActive(true);
            return;
        }
        if (!DataManager.Instance.Local.Scenarios.UnlockDailyQuestChapterIds.Contains(master.id))
        {
            lockImage.SetActive(true);
            DataManager.Instance.Local.Scenarios.UnlockDailyQuestChapterIds.Add(master.id);
            DataManager.Instance.Local.Save();
            PlayAnimation();
        }


    }
    void PlayAnimation()
    {
        AsyncManager.Instance.StartAsync(PlayAnimationAsync);
    }
    private async UniTask PlayAnimationAsync()
    {
        lockAnimation.Play();
        var time = lockAnimation.clip.length;
        await UniTask.Delay((int)(time * 1000));
        lockImage.SetActive(false);
    }
    

    private async UniTask SetRewardItemsButton()
    {
        foreach (var item in items)
        {
            item.gameObject.SetActive(false);
        }


        var displayElements = _master.displayDropRewardContents;
        if (displayElements.Count > 3)
        {
            displayElements = displayElements.GetRange(0, 3);
        }

        int index = 0;
        foreach (var contentId in displayElements)
        {
            if (index < items.Count)
            {
                await items[index].SetupAsync(contentId, "");
                items[index].gameObject.SetActive(true);
            }
            else
            {
                var button = Instantiate(rewardElement, rewardParent, false);
                //button.transform.localScale = new Vector3(0.5f, 0.5f, 1f);
                await button.SetupAsync(contentId, "");
                button.gameObject.SetActive(true);
                items.Add(button);
            }

            index++;


        }
    }

    private async UniTask LoadSpriteAsync(DailyQuestChapterMaster _master)
    {
        textBg.sprite = await ResourceManager .Instance.LoadSpriteAsync("DailyQuest", $"section_bg_{_master.id}");
    }
}
