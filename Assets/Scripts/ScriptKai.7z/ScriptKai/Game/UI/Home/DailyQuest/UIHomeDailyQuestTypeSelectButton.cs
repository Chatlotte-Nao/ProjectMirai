using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using UnityEngine.UI;
using Cysharp.Threading.Tasks;

public class UIHomeDailyQuestTypeSelectButton : MonoBehaviour
{
    private const long MAX_INDEX = 3;
    
    [SerializeField] UIText title;
    [SerializeField] UIText desciTxt;
    [SerializeField] UIButton button;
    [SerializeField] GameObject selectLine;
    [SerializeField] Image btnBg;
    [SerializeField] Image textBg;
    [SerializeField] BaseItem rewardElement;
    [SerializeField] RectTransform rewardParent;
    [SerializeField] private GameObject badgeClear;
    [SerializeField] private UIText remainMultiTimes;

    [SerializeField] private GameObject disableObject;
    [SerializeField] private UIText lockText;
    [SerializeField] private Animation lockAnimation;
    
    private List<BaseItem> items = new List<BaseItem>();
    private DailyQuestTypeMaster _master;
    public ClickEvent onClick => button.onClick;


    public async UniTask InitializeAsync(DailyQuestTypeMaster master)
    {
        await UpdataDataAsync(master);
        await SetRewardItemsButton();
        
    }

    public async UniTask UpdataDataAsync(DailyQuestTypeMaster master)
    {
        _master = master;
        var active = DataManager.Instance.Player.DailyQuest.TodayDailyQuestTypes.Contains(_master.id);
        // if (active)
        // {
        //     selectLine.SetActive(true);
        // }
        
        btnBg.color = active ? Color.white : Color.black;

        var allClear = DailyQuestUtil.SectionAllClear(master);
        badgeClear.gameObject.SetActive(allClear);
        remainMultiTimes.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, "remain_multi_times", DataManager.Instance.Player.DailyQuest.GetMultiTimes(_master.id));
        await SetButtonBgAndTitle(_master.id);

        if (master.requirePlayerLevel > DataManager.Instance.Player.Player.GetLevel())
        {
            lockText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "UILock_Level_Format",master.requirePlayerLevel);
            disableObject.SetActive(true);
            return;
        }
        var stageId = master.requireStageId;
        if (stageId > 0 && !StoryUtil.IsClear(stageId))
        {
            var chapterName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{stageId}_name");
            int chapterNum = DataManager.Instance.Master.Chapter[stageId].chapter;
            lockText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "UILock_Stage_Format", chapterNum, chapterName);
            disableObject.SetActive(true);
            return;
        }

        if (!DataManager.Instance.Local.Scenarios.UnlockDailyQuestIds.Contains(master.id))
        {
            disableObject.SetActive(true);
            DataManager.Instance.Local.Scenarios.UnlockDailyQuestIds.Add(master.id);
            DataManager.Instance.Local.Save();
            lockAnimation.Play();
            PlayAnimation();
        }

    }

    void PlayAnimation()
    {
        AsyncManager.Instance.StartAsync(PlayAnimationAsync);
    }

    private async UniTask PlayAnimationAsync()
    {
        var time = lockAnimation.clip.length;
        await UniTask.Delay((int)(time * 1000));
        disableObject.SetActive(false);
    }
    private async UniTask SetButtonBgAndTitle(long id)
    {
        title.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, $"type_title_{id}");
        desciTxt.SetFormat(LocalizeManager.DATA_TYPE.DAILY_QUEST, $"type_desc_{id}");
        //new 
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(id); });
        //btnBg.sprite = ResourceManager.Instance.LoadSpriteSmall("DailyQuest", $"chapter_bg_{id}");
    }

    private async UniTask SetRewardItemsButton()
    {
        foreach (var item in items)
        {
            item.gameObject.SetActive(false);
        }
      

        var displayElements = _master.displayDropRewardContents;
        if (displayElements.Count > 3)
        {
            displayElements = displayElements.GetRange(0, 3);
        }
        int index = 0;
        foreach (var contentId in displayElements)
        {
            //var key = DailyQuestUtil.GetRewardContentIconKey(contentId, out var id);
            if (index < items.Count)
            {
                await items[index].SetupAsync(contentId, "");
                items[index].gameObject.SetActive(true);
            }
            else
            {
                var button = Instantiate(rewardElement, rewardParent, false);
                //button.transform.localScale = new Vector3(0.5f, 0.5f, 1f);
                await button.SetupAsync(contentId, "");
                button.gameObject.SetActive(true);
                items.Add(button);
            }

            index++;

           
        }
    }

    private async UniTask LoadSpriteAsync(long id)
    {
        btnBg.sprite = await ResourceManager.Instance.LoadSpriteAsync("DailyQuest", $"chapter_bg_{id}");
    }
}