﻿using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;
using Cysharp.Threading.Tasks;

public class UIDailyQuestSectionDetailTab : MonoBehaviour
{
    [SerializeField] private GameObject lockObj;
    [SerializeField] private Image selectImage;
    [SerializeField] private GameObject badgeNew;
    [SerializeField] private GameObject badgeClear;
    [SerializeField] private UIText title;
    [SerializeField] private UIButton button;
    public ClickEvent onClick => button.onClick;
    private DailyQuestMaster _master;
    private Color select = new Color(255.0f / 255, 255.0f / 255, 217.0f / 255);
    private Color noSelect = new Color(68.0f / 255, 67.0f / 255, 66.0f / 255);
    public async UniTask SetUpAsync(DailyQuestMaster master)
    {
        _master = master;
       
        var active = DailyQuestUtil.SectionActive(_master);
        lockObj.SetActive(!active);
        var clear = DailyQuestUtil.SectionCanClear(_master);
        badgeClear.gameObject.SetActive(clear);
        badgeNew.SetActive(active && !clear);
        if (!active)
        {
            var masterId = DataManager.Instance.Player.DailyQuest.TryGet(master.preDailyQuestMasterId);
            if (master.preDailyQuestMasterId !=0 && masterId == null)
            {
                title.SetLabel(LocalizeManager.DATA_TYPE.DAILY_QUEST, "daily_quest_open_forward");
            }
            else
            {
                var levelSatisfied = DataManager.Instance.Player.Player.GetLevel() >= master.requirePlayerLevel;
                if (!levelSatisfied)
                {
                    var str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.DAILY_QUEST,
                        "daily_quest_open_level"), new object[] {master.requirePlayerLevel});
                    title.SetRawText(str);
                }
            }

        }
        else
        {
            title.SetLabel(LocalizeManager.DATA_TYPE.DAILY_QUEST, $"section_title_{master.id}");
        }

    }

    public void SetSelectActive(int masterId)
    {
        selectImage.gameObject.SetActive(_master.id == masterId );
        if(_master.id == masterId)
            title.SetColor(select);
        else
            title.SetColor(noSelect);
    }

}
