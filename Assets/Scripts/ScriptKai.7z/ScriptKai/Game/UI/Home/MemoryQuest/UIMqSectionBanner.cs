//using Home;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

public class UIMqSectionBanner: MonoBehaviour
{
    [SerializeField] Image bigImage;
    [SerializeField] Image smallImage;
    [SerializeField] Image lockImage;
    [SerializeField] Image lockIconImage;
    [SerializeField] private UIText MemoryQuestStage;

    [SerializeField] private Image MissionStarOff1;
    [SerializeField] private Image MissionStarOn1;
    [SerializeField] private Image MissionStarOff2;
    [SerializeField] private Image MissionStarOn2;
    [SerializeField] private Image MissionStarOff3;
    [SerializeField] private Image MissionStarOn3;
    
    [SerializeField] private GameObject badgeNew;
    [SerializeField] private GameObject badgeClear;
    [SerializeField] private GameObject perfectClear;
    
    [SerializeField] private UIButton enterMemoryQuestStage;
    [SerializeField] private GameObject starObj;
    [SerializeField] private Image selectBigCover;
    [SerializeField] private Image selectSmallCover;
    [SerializeField] private VerticalLayoutGroup vertical;
    public  MqMemoryQuestStatusViewModel.MqType mqType = MqMemoryQuestStatusViewModel.MqType.Normal;
    private MqMemoryQuestStatusViewModel.SoreType soreType = MqMemoryQuestStatusViewModel.SoreType.Small;
    public bool IsLocked = false;
    public ClickEvent EnterMq => enterMemoryQuestStage.onClick;
    private int masterId;
    public void SetUp(MqMemoryQuestStatusViewModel model)
    {
        vertical.padding.top = model.vertical;
        this.mqType = model.MemoryQuestType;
        this.soreType = model.soreType;
        this.IsLocked = model.IsLocked();
        this.masterId = model.MasterId;
        starObj.SetActive(model.soreType == MqMemoryQuestStatusViewModel.SoreType.Big);
        this.MissionStarOff1.gameObject.SetActive(true);
        this.MissionStarOff2.gameObject.SetActive(true);
        this.MissionStarOff3.gameObject.SetActive(true);
        
        this.MissionStarOn1.gameObject.SetActive(false);
        this.MissionStarOn2.gameObject.SetActive(false);
        this.MissionStarOn3.gameObject.SetActive(false);
        
        this.badgeNew.gameObject.SetActive(false);
        this.badgeClear.gameObject.SetActive(false);
        this.perfectClear.gameObject.SetActive(false);
        bigImage.gameObject.SetActive(model.soreType == MqMemoryQuestStatusViewModel.SoreType.Big);
        smallImage.gameObject.SetActive(model.soreType != MqMemoryQuestStatusViewModel.SoreType.Big);
        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(1); });
        //bigImage.sprite = ResourceManager.Instance.LoadSpriteSmall("MemoryQuest", "zljy_frame_b1_01");
        //smallImage.sprite = ResourceManager.Instance.LoadSpriteSmall("MemoryQuest", "zljy_frame_b1_02");
   
        this.MemoryQuestStage.SetLabel(LocalizeManager.DATA_TYPE.MEMORY_QUEST, $"{model.MasterId}_name");
        if (!model.IsLocked() && model.isWin)
        {
            this.lockImage.gameObject.SetActive(false);
            lockIconImage.gameObject.SetActive(true);
            if (model.StarNumGot == 0)
            {
                this.badgeNew.gameObject.SetActive(true);
            }
  
            if (model.StarNumGot == 1)
            {
                this.MissionStarOn1.gameObject.SetActive(true);
                this.badgeClear.gameObject.SetActive(true);
            } 
            else if (model.StarNumGot == 2)
            {
                this.MissionStarOn1.gameObject.SetActive(true);
                this.MissionStarOn2.gameObject.SetActive(true);
                this.badgeClear.gameObject.SetActive(true);
            } 
            else if (model.StarNumGot == 3)
            {
                this.MissionStarOn1.gameObject.SetActive(true);
                this.MissionStarOn2.gameObject.SetActive(true);
                this.MissionStarOn3.gameObject.SetActive(true);
                this.perfectClear.gameObject.SetActive(true);
                //MqSectionBanner.sprite = ResourceManager.Instance.LoadSpriteSmall("MemoryQuest", "zljy_frame_b1_01");
            }
            if (model.soreType == MqMemoryQuestStatusViewModel.SoreType.Small)
            {
                this.perfectClear.gameObject.SetActive(false);
                this.badgeClear.gameObject.SetActive(model.IsSmallPass());
            }
        }
        else
        {
            starObj.SetActive(false);
            lockImage.gameObject.SetActive(true);
            lockIconImage.gameObject.SetActive(false);
            //new 
            AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(2); });
            //bigImage.sprite = ResourceManager.Instance.LoadSpriteSmall("MemoryQuest", "zljy_frame_b1_03");
            //smallImage.sprite = ResourceManager.Instance.LoadSpriteSmall("MemoryQuest", "zljy_frame_b1_03");
        }

        
    }

    public void SetSelectActive(int selectMasterId)
    {
        this.selectBigCover.gameObject.SetActive(masterId == selectMasterId && soreType == MqMemoryQuestStatusViewModel.SoreType.Big);
        this.selectSmallCover.gameObject.SetActive(masterId == selectMasterId && soreType == MqMemoryQuestStatusViewModel.SoreType.Small);
    }

    private async UniTask LoadSpriteAsync(int index)
    {
        switch (index)
        {
            case 1:
                bigImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("MemoryQuest", "zljy_frame_b1_01");
                smallImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("MemoryQuest", "zljy_frame_b1_02");
                break;
            case 2:
                bigImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("MemoryQuest", "zljy_frame_b1_03");
                smallImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("MemoryQuest", "zljy_frame_b1_03");
                break;
            default:
                break;
        }
        
    }
}