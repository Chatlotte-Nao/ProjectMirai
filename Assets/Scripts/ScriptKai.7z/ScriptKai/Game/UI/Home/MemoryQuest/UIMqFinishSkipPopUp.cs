using System;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class UIMqFinishSkipPopUp : MonoBehaviour
{
    [SerializeField] private UIText title;
    [SerializeField] private GameObject playerExpInfo;
    [SerializeField] private UIText playerExpReceived;
    [SerializeField] private GameObject gameMoneyInfo;
    [SerializeField] private UIText gameMoneyReceived;

    [SerializeField] private RectTransform itemsContainer;
    [SerializeField] private BaseItem itemPrefab;

    [SerializeField] private UIText errorInfo;
    
    [SerializeField] private UIButton skipAgainButton;
    [SerializeField] private UIButton hideButton;

    // public MqMemoryQuestStatueViewModelEvent SkipAgain = new MqMemoryQuestStatueViewModelEvent();

    public UIMqMemoryQuestStatusViewModelEvent SkipAgain = new UIMqMemoryQuestStatusViewModelEvent();

    public ClickEvent HideDialog => hideButton.onClick;
    // public ClickEvent SkipAgain;
    private List<BaseItem> mItem = new List<BaseItem>();
    private Dictionary<long, string> itemInfos = new Dictionary<long, string>();
    public async UniTask SetUpAsync(int id)
    {
        var model = MemoryQuestUtil.BuildMqMemoryQuestStatusViewModel(id);
        skipAgainButton.onClick.RemoveAllListeners();
        skipAgainButton.onClick.AddListener( _=>SkipAgain.Invoke(model));
        foreach (var item in mItem)
        {
            item.gameObject.SetActive(false);
        }
        itemInfos.Clear();
        if (model.DailyCountLeft > 0)
        {
            var infos = await MemoryQuestService.FinishSkipMemoryQuestAsync(model.MasterId);
            model.DailyCountLeft--;
            
            var master = DataManager.Instance.Master.MemoryQuest.Values.First(_ => _.id == model.MasterId);

            foreach (var dropContent in infos.rewards)
            {
                if (DataManager.Instance.Master.Content[dropContent.id].contentTypeMasterId == 113)
                    this.playerExpReceived.SetFormat(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_PLAYER_EXP", new object[]{ dropContent.count});
                else if(DataManager.Instance.Master.Content[dropContent.id].contentTypeMasterId == 106)
                    this.gameMoneyReceived.SetRawText(dropContent.count.ToString());
                else
                    itemInfos.Add(dropContent.id,dropContent.count.ToString());
            }
            var keys = itemInfos.Keys.ToList();
            if (keys.Count > 0)
            {
                for (int i = 0; i < keys.Count; i++)
                {
                    if (i < mItem.Count)
                    {
                        await mItem[i].SetupAsync(keys[i], itemInfos[keys[i]]);
                        mItem[i].gameObject.SetActive(true);
                    }
                    else
                    {
                        var item = Instantiate(itemPrefab, itemsContainer);
                        await item.SetupAsync(keys[i], itemInfos[keys[i]]);
                        item.gameObject.SetActive(true);
                        mItem.Add(item);
                    }
                }
            }
            
            

            // 不显示错误信息
            this.errorInfo.gameObject.SetActive(false);
            // this.playerExpReceived.SetFormat(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_PLAYER_EXP", new object[]{ master.expPlayer});
            // //playerExpReceived.SetRawText("玩家经验：" + master.expPlayer);
            // this.gameMoneyReceived.SetRawText(master.gameMoney.ToString());
            this.title.SetLabel(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_SWEEP_COMPLETE");
            this.playerExpInfo.SetActive(true);
            this.gameMoneyInfo.SetActive(true);
            this.skipAgainButton.gameObject.SetActive(true);
            if (infos.playerLevelUp)
            {
                await UI.Popup.ShowCommonLevelUpAsync();
            }
        }
        else
        {
            // 隐藏各种按钮
            //this.title.SetRawText("错误");
            this.playerExpInfo.SetActive(false);
            this.gameMoneyInfo.SetActive(false);
            this.skipAgainButton.gameObject.SetActive(false);
            // 显示错误信息
            this.errorInfo.gameObject.SetActive(true);
        }
        if(DataManager.Instance.Player.Equipment.firstEquipmentIds.Count > 0)
            UI.Popup.ShowEquipmentFullScreen(DataManager.Instance.Player.Equipment.firstEquipmentIds);
    }
    
    
}