using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;

public class UIMqScenarioSelectSectionDialog : UIDialogBase
{
    [SerializeField] private UIText titleText;
    [SerializeField] private Image bg;
    [SerializeField] private UIMqSectionBanner bannerPrefab;
    [SerializeField] private RectTransform uiMqSectionBannerContainer;
    [SerializeField] private UIButton backButton;
    [SerializeField] private UIMqScenarioToggle[] showTab;
    [SerializeField] private UIText missionStarAllNormal;
    [SerializeField] private UIText missionStarAllHard;
    [SerializeField] private UIText starRewards1Normal;
    [SerializeField] private UIText starRewards1Hard;
    [SerializeField] private UIText starRewards2Normal;
    [SerializeField] private UIText starRewards2Hard;
    [SerializeField] private UIText starRewards3Normal;
    [SerializeField] private UIText starRewards3Hard;

    [SerializeField] private UIMqRewardsBox rewardsBox1;
    [SerializeField] private UIMqRewardsBox rewardsBox2;
    [SerializeField] private UIMqRewardsBox rewardsBox3;

    [SerializeField] private UIMqStagePanel stagePanel;
    [SerializeField] private UIMqFinishSkipPopUp mqFinishSkipPopUp;
    [SerializeField] private Slider rewardsNormalSlider;
    [SerializeField] private Slider rewardsHardSlider;
    [SerializeField] private UIButton closeStage;
    [SerializeField] private ScrollRect scrollrect;
    private int _mStageSelected = 1;
    private int _mMemoryQuestType = 1;

    private List<UIMqSectionBanner> mBanners = new List<UIMqSectionBanner>();

    public UIMqRewardsBoxEvent ClickRewardsBox = new UIMqRewardsBoxEvent();

    public ClickEvent ClickBack = new ClickEvent();
    public UIMqMemoryQuestStatusViewModelEvent ClickBanner = new UIMqMemoryQuestStatusViewModelEvent();
    public UIMqMemoryQuestStatusViewModelEvent OnClickSkip = new UIMqMemoryQuestStatusViewModelEvent();
    public ClickEvent OnClickBattle = new ClickEvent();
    public ClickEvent ClickHideFinishPopUp = new ClickEvent();
    private MqChapterStatusViewModel mqChapterStatusViewModel;

    public UIIntEvent ClickTab = new UIIntEvent();
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        
        backButton.onClick.Subscribe(ClickBack).AddTo(mSubscriptions);
        closeStage.onClick.Subscribe(_=>CloseStage()).AddTo(mSubscriptions);

        this.rewardsBox1.RewardBoxOnClick.Subscribe(_ => ClickRewardsBox.Invoke(this.rewardsBox1));
        this.rewardsBox2.RewardBoxOnClick.Subscribe(_ => ClickRewardsBox.Invoke(this.rewardsBox2));
        this.rewardsBox3.RewardBoxOnClick.Subscribe(_ => ClickRewardsBox.Invoke(this.rewardsBox3));

        stagePanel.gameObject.SetActive(false);
        stagePanel.OnClickSkip.Subscribe(OnClickSkip).AddTo(mSubscriptions);
        stagePanel.OnClickBattle.Subscribe(OnClickBattle).AddTo(mSubscriptions);
        mqFinishSkipPopUp.gameObject.SetActive(false);
        mqFinishSkipPopUp.SkipAgain.Subscribe(OnClickSkip).AddTo(mSubscriptions);
        mqFinishSkipPopUp.HideDialog.Subscribe(ClickHideFinishPopUp).AddTo(mSubscriptions);
        
        // Set as Normal by default
       
    }

    public async UniTask SetUpAsync(int selectedChapter)
    {
        this.bg.sprite = await ResourceManager.Instance.LoadSpriteAsync("MemoryQuest/BG", getBgName(selectedChapter));
        
        foreach (var banner in mBanners)
        {
            banner.EnterMq.RemoveAllListeners();
            banner.gameObject.SetActive(false);
        }
        //mBanners.Clear();
        var viewmodel = MemoryQuestUtil.BuildMqChapterStatusViewModel(selectedChapter);
        mqChapterStatusViewModel = viewmodel;
        var models = viewmodel.MqSectionStatus.Values.ToArray();
        for (int i = 0; i < models.Length; i++)
        {
            var model = models[i];
            if (i < mBanners.Count)
            {
                mBanners[i].EnterMq.Subscribe(_ => ClickBanner.Invoke(model));
                mBanners[i].SetUp(model);
                mBanners[i].gameObject.SetActive(true);
            }
            else
            {
                var banner = Instantiate(bannerPrefab, uiMqSectionBannerContainer);
                var statusModel = model;
                // if (!statusModel.IsLocked)
                // {
                banner.EnterMq.Subscribe(_ => ClickBanner.Invoke(statusModel));
                //}
                banner.SetUp(statusModel);
                mBanners.Add(banner);
            }
        }
        for (var i = 0; i < showTab.Length; i++)
        {
            var memoryQuestType = i==0 ? MqMemoryQuestStatusViewModel.MqType.Normal: MqMemoryQuestStatusViewModel.MqType.Hard;
            await showTab[i].SetUpAsync(mqChapterStatusViewModel,memoryQuestType);
            showTab[i].OnClick.Subscribe((_) =>
            {
                ClickTab.Invoke((int)memoryQuestType);
                //RefreshList(memoryQuestType);
            }).AddTo(mSubscriptions);
        }
        // Setting Up Rewards Related Values
       
        this.starRewards1Hard.SetRawText(viewmodel.StarRewards1Hard.ToString());
        this.starRewards2Hard.SetRawText(viewmodel.StarRewards2Hard.ToString());
        this.starRewards3Hard.SetRawText(viewmodel.StarRewards3Hard.ToString());
        this.starRewards1Normal.SetRawText(viewmodel.StarRewards1Normal.ToString());
        this.starRewards2Normal.SetRawText(viewmodel.StarRewards2Normal.ToString());
        this.starRewards3Normal.SetRawText(viewmodel.StarRewards3Normal.ToString());
        
        this.missionStarAllNormal.SetRawText(viewmodel.StarNumNormalGot + "/" + viewmodel.StarNumNormalTotal);
        this.rewardsNormalSlider.maxValue = viewmodel.StarNumNormalTotal;
        this.rewardsNormalSlider.value = viewmodel.StarNumNormalGot;
       
        this.missionStarAllHard.SetRawText(viewmodel.StarNumHardGot + "/" + viewmodel.StarNumHardTotal);
        this.rewardsHardSlider.maxValue = viewmodel.StarNumHardTotal;
        this.rewardsHardSlider.value = viewmodel.StarNumHardGot;
        
        this.rewardsBox1.canReceiveNormal = viewmodel.StarRewards1NormalCanReceive;
        this.rewardsBox2.canReceiveNormal = viewmodel.StarRewards2NormalCanReceive;
        this.rewardsBox3.canReceiveNormal = viewmodel.StarRewards3NormalCanReceive;
        this.rewardsBox1.canReceiveHard = viewmodel.StarRewards1HardCanReceive;
        this.rewardsBox2.canReceiveHard = viewmodel.StarRewards2HardCanReceive;
        this.rewardsBox3.canReceiveHard = viewmodel.StarRewards3HardCanReceive;

        this.rewardsBox1.receivedNormal = viewmodel.StarRewards1NormalReceived;
        this.rewardsBox3.receivedNormal = viewmodel.StarRewards3NormalReceived;
        this.rewardsBox2.receivedNormal = viewmodel.StarRewards2NormalReceived;
        this.rewardsBox1.receivedHard = viewmodel.StarRewards1HardReceived;   
        this.rewardsBox2.receivedHard = viewmodel.StarRewards2HardReceived;
        this.rewardsBox3.receivedHard = viewmodel.StarRewards3HardReceived;
        
        // Setting rewards box default as normal type
        RefreshList(MqMemoryQuestStatusViewModel.MqType.Normal);
        
        this.rewardsBox1.chapter = selectedChapter;
        this.rewardsBox1.position = 1;
        this.rewardsBox2.chapter = selectedChapter;
        this.rewardsBox2.position = 2;
        this.rewardsBox3.chapter = selectedChapter;
        this.rewardsBox3.position = 3;

        this.rewardsBox1.onNormalToggle = _mMemoryQuestType == 1;
        this.rewardsBox2.onNormalToggle = _mMemoryQuestType == 1;
        this.rewardsBox3.onNormalToggle = _mMemoryQuestType == 1;
        stagePanel.gameObject.SetActive(false);
    }

    public void RefreshList(MqMemoryQuestStatusViewModel.MqType memoryQuestType)
    {
        foreach (var tab in showTab)
        {
            tab.SetToggleActive(memoryQuestType);
        }
        _mMemoryQuestType = memoryQuestType == MqMemoryQuestStatusViewModel.MqType.Normal ? 1 : 2;
        this.rewardsBox1.onNormalToggle = _mMemoryQuestType == 1;
        this.rewardsBox2.onNormalToggle = _mMemoryQuestType == 1;
        this.rewardsBox3.onNormalToggle = _mMemoryQuestType == 1;

        foreach (var model in mBanners)
        {
            model.gameObject.SetActive(model.mqType == memoryQuestType);
        }

        var showNormal = memoryQuestType == MqMemoryQuestStatusViewModel.MqType.Normal;

        this.missionStarAllNormal.gameObject.SetActive(showNormal);
        this.starRewards1Normal.gameObject.SetActive(showNormal);
        this.starRewards2Normal.gameObject.SetActive(showNormal);
        this.starRewards3Normal.gameObject.SetActive(showNormal);
        this.rewardsNormalSlider.gameObject.SetActive(showNormal);
        
        this.missionStarAllHard.gameObject.SetActive(!showNormal);
        this.starRewards1Hard.gameObject.SetActive(!showNormal);
        this.starRewards2Hard.gameObject.SetActive(!showNormal);
        this.starRewards3Hard.gameObject.SetActive(!showNormal);
        this.rewardsHardSlider.gameObject.SetActive(!showNormal);
        // Rewards box open or close state
        FlushRewardsBox(memoryQuestType);
        stagePanel.gameObject.SetActive(false);
        AsyncManager.Instance.StartGuardAsync(updataPostion(memoryQuestType));
    }
    public async UniTask updataPostion(MqMemoryQuestStatusViewModel.MqType memoryQuestType)
    {
        var value = mqChapterStatusViewModel.GetHorizontalNormalized(memoryQuestType);
        await UniTask.Delay(10);
        scrollrect.horizontalNormalizedPosition = value;
    }

    void CloseStage()
    {
        stagePanel.gameObject.SetActive(false);
    }
    private void FlushRewardsBox(MqMemoryQuestStatusViewModel.MqType memoryQuestType)
    {
        this.rewardsBox1.OnShow(memoryQuestType);
        this.rewardsBox2.OnShow(memoryQuestType);
        this.rewardsBox3.OnShow(memoryQuestType);
    }
    
    public async UniTask ShowPanel(int id)
    {
        stagePanel.gameObject.SetActive(false);
        await stagePanel.SetUpAsync(id);
        stagePanel.gameObject.SetActive(true);
        foreach (var banner in mBanners)
        {
            banner.SetSelectActive(id);
        }
    }

    public async UniTask FinishSkip(int id)
    {
        mqFinishSkipPopUp.gameObject.SetActive(false);
        await mqFinishSkipPopUp.SetUpAsync(id);
        mqFinishSkipPopUp.gameObject.SetActive(true);
        await stagePanel.SetUpAsync(id);
    }

    public async UniTask HideFinishPopUp()
    {
        mqFinishSkipPopUp.gameObject.SetActive(false);
    }

    private string getBgName(int chapter)
    {
        return "MemoryQuest_bg" + ((chapter - 1)%3 +1 );
    }
}

public class UIMqRewardsBoxEvent : UnityEvent<UIMqRewardsBox>
{
}
public class UIMqMemoryQuestStatusViewModelEvent : UnityEvent<MqMemoryQuestStatusViewModel>
{
}