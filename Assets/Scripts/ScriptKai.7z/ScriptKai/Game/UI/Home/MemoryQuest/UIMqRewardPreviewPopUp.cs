using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIMqRewardPreviewPopUp : UIDialogBase
{
    [SerializeField] private BaseItem itemPrefab;
    [SerializeField] private RectTransform itemContainer;
    [SerializeField] private UIText title;
    [SerializeField] UIButton btnClose;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        btnClose.onClick.GuardSubscribeAsync(onClickClose).AddTo(mSubscriptions);
    }
    List<BaseItem> _baseItems = new List<BaseItem>();
    public async UniTask SetUpAsync(UIMqRewardsBox box)
    {
        var type = box.onNormalToggle ? 1 : 2;
        
        // 限定chapter和type之后是唯一的
        var chapterMaster = DataManager.Instance.Master.MemoryQuestChapter.Values.First(_ => _.chapter == box.chapter && _.memoryQuestType == type);
        
        var chapterRewardContents = box.position == 1? chapterMaster.starRewardContents1 : 
            box.position == 2? chapterMaster.starRewardContents2 :chapterMaster.starRewardContents3;
        foreach (var bastItem in _baseItems)
        {
            bastItem.gameObject.SetActive(false);
        }
        if(chapterRewardContents.Count>0){
            for (int i = 0; i < chapterRewardContents.Count; i++)
            {
                var s = chapterRewardContents[i].Split(':');
                var itemId = long.Parse(s[0]);
                if (i < _baseItems.Count)
                {
                    await _baseItems[i].SetupAsync(itemId, s[1]);
                    _baseItems[i].gameObject.SetActive(true);
                }
                else
                {
                    var item = Instantiate(itemPrefab, itemContainer);
                    await item.SetupAsync(itemId, s[1]);
                    item.gameObject.SetActive(true);
                    _baseItems.Add(item);
                }
            }
        }
        

        //title.SetRawText("奖励预览");
        title.SetLabel(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_REWARD_PREVIEW");
        if ((box.onNormalToggle && box.receivedNormal) || (!box.onNormalToggle && box.receivedHard))
        {
            //title.SetRawText("已领取奖励");
            title.SetLabel(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_REWARD_RECEIVE");
        } else if ((box.onNormalToggle && box.canReceiveNormal) || (!box.onNormalToggle && box.canReceiveHard))
        {
            await MemoryQuestService.ReceiveChapterRewardsAsync(chapterMaster.id, box.position);
            await UI.Popup.ShowItemGetPopupAsync(chapterRewardContents);
            if (type == 1)
            {
                box.receivedNormal = true;
                box.canReceiveNormal = false;
            }
            else
            {
                box.receivedHard = true;
                box.canReceiveHard = false;
            }
            //title.SetRawText("已领取奖励"); 
            title.SetLabel(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_REWARD_RECEIVE");
        }
    }
}