
using System;
using Pheonix.Core;
using ScenarioSelect;
using TMPro;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIMqChapterButton : MonoBehaviour
{
    [SerializeField] private UIText chapterName;
    
    [SerializeField] private Image innerImage;
    [SerializeField] private UIButton button;

    [SerializeField] private Image starNormal;
    [SerializeField] private UIText awardCountNormal;
    [SerializeField] private Image starHard;
    [SerializeField] private UIText awardCountHard;
    
    [SerializeField] private Image missonStarNormalImage;
    [SerializeField] private Image missonStarHardImage;
    [SerializeField] private Image missonBgTitleImage;
    
    [SerializeField] private GameObject badgeNew;
    [SerializeField] private GameObject badgeClear;
    [SerializeField] private GameObject perfectClear;
    [SerializeField] private GameObject lockObj;
    public int currentChapter = 0;
    
    public ClickEvent ChapterButtonOnClick => button.onClick;
    
    public async void Setup(MqChapterStatusViewModel model)
    {
        this.currentChapter = model.Chapter;
        innerImage.color = model.IsLocked ? Color.black : Color.white;
        //missonStarNormalImage.color = model.IsLocked ? Color.black : Color.white;
        //missonStarHardImage.color = model.IsLocked ? Color.black : Color.white;
        lockObj.SetActive( model.IsLocked);
        //this.starNormal.color = (model.StarNumNormalGot == model.StarNumNormalTotal) ? Color.yellow : Color.white;
        this.starNormal.gameObject.SetActive(true);

        //this.starHard.color = (model.StarNumHardGot == model.StarNumHardTotal) ? Color.yellow : Color.white;
        this.starHard.gameObject.SetActive(true);
        
        this.awardCountNormal.SetRawText(model.StarNumNormalGot.ToString() + "/" + model.StarNumNormalTotal.ToString());
        this.awardCountNormal.gameObject.SetActive(true);
        this.awardCountHard.SetRawText(model.StarNumHardGot.ToString() + "/" + model.StarNumHardTotal.ToString());
        this.awardCountHard.gameObject.SetActive(true);
        // TODO: Localize!!!!
        // this.chapterName.SetLabel(LocalizeManager.DATA_TYPE, "第" + model.chapter.ToString() + "章");
        this.chapterName.SetFormat(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_NAME", new object[]{ model.Chapter});
        this.chapterName.gameObject.SetActive(true);

        this.innerImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("MemoryQuest/ChapterButtonBG", getBgId(model.Chapter));
        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(model); });
        //missonBgTitleImage.sprite = ResourceManager.Instance.LoadSpriteSmall("MemoryQuest", getBgTitleId(model.Chapter));
        badgeNew.SetActive( !model.IsLocked && model.IsChapterStatusNew());
        bool isPerfect = model.StarNumNormalGot + model.StarNumHardGot >= model.StarNumNormalTotal + model.StarNumHardTotal;
        badgeClear.SetActive(!isPerfect &&model.IsChapterStatusClear());
        perfectClear.SetActive(isPerfect);
    }

    private string getBgId(int chapter)
    {
        return "mq_bg" + ((chapter - 1)%3 +1 );
    }
    private string getBgTitleId(int chapter)
    {
        return "zljy_frame_a1_0" + ((chapter - 1)%2 + 1);
    }

    private async UniTask LoadSpriteAsync(MqChapterStatusViewModel model)
    {
        missonBgTitleImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("MemoryQuest", getBgTitleId(model.Chapter));
    }
}