using System.Collections.Generic;
using System.Linq;
using MapUi;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
public class UIMqScenarioSelectChapterListDialog : UIDialogBase
{
    [SerializeField] private UIButton backButton;
    [SerializeField] private UIMqChapterButton chapterButtonPrefab;
    [SerializeField] private RectTransform chapterButtonContainer;
    [SerializeField] private UIText titleText;

    public UIIntEvent OnClickChapterButton = new UIIntEvent();
    public ClickEvent OnClickBackButton => backButton.onClick;
    private List<GameObject> cells = new List<GameObject>();
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
       
        var chapterNumList = DataManager.Instance.Master.MemoryQuest.Values.Select(m => m.chapter).Distinct().ToList();
        foreach (var chapter in chapterNumList)
        {
            var chapterButton = Instantiate(chapterButtonPrefab, chapterButtonContainer); 
            var index = chapter;
            var model = MemoryQuestUtil.BuildMqChapterStatusViewModel(index);
            chapterButton.Setup(model);
            chapterButton.ChapterButtonOnClick.Subscribe(_ => OnClickChapterButton.Invoke(index));
            cells.Add(chapterButton.gameObject);
        
        }
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        foreach (var cell in cells)
        {
            cell.gameObject.SetActive(false);
        }
        foreach (var cell in cells)
        {
            await UniTask.DelayFrame(5);
            cell.gameObject.SetActive(true);
        }
    }
}