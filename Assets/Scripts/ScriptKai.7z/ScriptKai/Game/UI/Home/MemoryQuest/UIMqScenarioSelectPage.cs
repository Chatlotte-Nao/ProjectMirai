using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Battle;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;

public class UIMqScenarioSelectPage : UIPageBase
{
    private UIMqScenarioSelectPageParam _mParam;
    
    private UIMqScenarioSelectChapterListDialog _mMqChapterListDialog;
    private UIMqScenarioSelectSectionDialog _mMqSectionDialog;
    private UIMqRewardPreviewPopUp _mMqRewardPreviewPopUp;
    private int _mStageSelected = 1;
    
    private Dictionary<int, MqChapterStatusViewModel> _mMqViewModelList = new Dictionary<int, MqChapterStatusViewModel>();

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        _mMqChapterListDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMqScenarioSelectChapterListDialog, CanvasType.App0) as UIMqScenarioSelectChapterListDialog;
        _mMqSectionDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMqScenarioSelectSectionDialog, CanvasType.App0) as UIMqScenarioSelectSectionDialog;
        _mParam = param as UIMqScenarioSelectPageParam;
        
        var headerParam = new UIHomeHeaderParam()
        {
            visibleBack = false,
            visibleIcon = false,
            visiblePlayerStatus = true,
            visibleRightRank = false,
            showResType = new List<UIHeaderResType>()
            {
                UIHeaderResType.Coin, UIHeaderResType.Stamina, UIHeaderResType.GemFree, UIHeaderResType.GemPaid
            },
        };

        SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);

        _mMqChapterListDialog.OnClickChapterButton.GuardSubscribeAsync(ShowMemoryQuestOfChapter).AddTo(mSubscriptions);
        _mMqChapterListDialog.OnClickBackButton.GuardSubscribeAsync(ShowMainMenu).AddTo(mSubscriptions); 
        
        _mMqSectionDialog.ClickRewardsBox.GuardSubscribeAsync(ShowPreviewDialog).AddTo(mSubscriptions);
        _mMqSectionDialog.ClickBanner.GuardSubscribeAsync(ShowStagePanel).AddTo(mSubscriptions);
        _mMqSectionDialog.OnClickSkip.GuardSubscribeAsync(SkipMq).AddTo(mSubscriptions);
        _mMqSectionDialog.OnClickBattle.GuardSubscribeAsync(StartBattle).AddTo(mSubscriptions);
        _mMqSectionDialog.ClickHideFinishPopUp.GuardSubscribeAsync(HidePopUp).AddTo(mSubscriptions);
        _mMqSectionDialog.ClickBack.GuardSubscribeAsync(ShowChapterList).AddTo(mSubscriptions);
        _mMqSectionDialog.ClickTab.GuardSubscribeAsync(ShowTab).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    { 
        await base.ShowAsync(showType);
        
        switch (_mParam.showType)
        {
            case UIMqScenarioSelectPageParam.ShowType.Chapter:
                await _mMqChapterListDialog.ShowAsync();
                break;
            case UIMqScenarioSelectPageParam.ShowType.Section:
                _mMqChapterListDialog.gameObject.SetActive(true);
                await ShowMemoryQuestOfChapter(_mParam.SelectedChapter);
                //_mMqSectionDialog.RefreshList(MqMemoryQuestStatusViewModel.MqType.Normal);
                mqType = (MqMemoryQuestStatusViewModel.MqType) _mParam.mqType;
                if( _mParam.mqType == 2)
                    await ShowTab(_mParam.mqType);
                break;
            default:
                break;
        }
    }

    private MqMemoryQuestStatusViewModel.MqType mqType = MqMemoryQuestStatusViewModel.MqType.Normal;
    private MqChapterStatusViewModel mqChapterStatusViewModel;
    private async UniTask ShowTab(int index)
    {
        if (index == (int)MqMemoryQuestStatusViewModel.MqType.Hard && mqChapterStatusViewModel!=null)
        {
            var chapterModel = DataManager.Instance.Master.MemoryQuestChapter.Values.First(_ => _.chapter== mqChapterStatusViewModel.Chapter && _.memoryQuestType == 2);
            if (chapterModel.requireStarNum > mqChapterStatusViewModel.StarNumNormalGot)
            {
                var  str= string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_OPEN_STAR"),new object[] {chapterModel.requireStarNum});
                await UI.Popup.ShowPopupMessageAsync(str);
                mqType = MqMemoryQuestStatusViewModel.MqType.Normal;
                return;
            }
        }
        _mMqSectionDialog.RefreshList((MqMemoryQuestStatusViewModel.MqType) index);
        mqType = (MqMemoryQuestStatusViewModel.MqType) index;
    }
    private async UniTask ShowMainMenu(GameObject o)
    {
        await UI.Page.CloseCurrentPage();
        // await UI.Page.ChangePage<UIHomeMainPage>();
    }
    
    private async UniTask ShowChapterList(GameObject o)
    {
        await _mMqSectionDialog.HideAsync();
        _mMqChapterListDialog.gameObject.SetActive(true);
    }

    private async UniTask ShowMemoryQuestOfChapter(int chapter) 
    {
        var model = MemoryQuestUtil.BuildMqChapterStatusViewModel(chapter);
        var view = model.MqSectionStatus.Values.FirstOrDefault(m => m.RequireChapterMasterId > 0);
        if (view!=null && view.IsLocked())
        {
            await OpenShowPopupMessageStage(view,true);
            return;
        }
        mqChapterStatusViewModel = model;
        await _mMqSectionDialog.SetUpAsync(chapter);
        chapter_ = chapter;
        await _mMqChapterListDialog.HideAsync();
        await _mMqSectionDialog.ShowAsync();
        
    }

    private int chapter_;
    private async UniTask ShowPreviewDialog(UIMqRewardsBox box)
    {
        if ((box.onNormalToggle && box.canReceiveNormal && !box.receivedNormal) || (!box.onNormalToggle && box.canReceiveHard && !box.receivedHard))
        {
            await ShowItemGetPopupDialog(box);
            return;
        }
        if (_mMqRewardPreviewPopUp == null)
        {
            _mMqRewardPreviewPopUp =  await UI.Dialog.CreateAsync(UIPrefabId.UIMqRewardDialog, CanvasType.App1) as UIMqRewardPreviewPopUp;
        }

        await _mMqRewardPreviewPopUp.SetUpAsync(box);
        await _mMqRewardPreviewPopUp.ShowAsync();
    }

    private async UniTask ShowItemGetPopupDialog(UIMqRewardsBox box)
    {
        var type = box.onNormalToggle ? 1 : 2;
        var chapterMaster = DataManager.Instance.Master.MemoryQuestChapter.Values.First(_ => _.chapter == box.chapter && _.memoryQuestType == type);
        var chapterRewardContents = box.position == 1 ? chapterMaster.starRewardContents1 :
            box.position == 2 ? chapterMaster.starRewardContents2 : chapterMaster.starRewardContents3;
        await MemoryQuestService.ReceiveChapterRewardsAsync(chapterMaster.id, box.position);
        await UI.Popup.ShowItemGetPopupAsync(chapterRewardContents);
        if (type == 1)
        {
            box.receivedNormal = true;
            box.canReceiveNormal = false;
        }
        else
        {
            box.receivedHard = true;
            box.canReceiveHard = false;
        }
         _mMqSectionDialog.RefreshList(mqType);
    }
    private async UniTask ShowStagePanel(MqMemoryQuestStatusViewModel model)
    {
        //var model = MemoryQuestUtil.BuildMqChapterStatusViewModel(chapter_).MqSectionStatus[key];
        if (model.IsLocked())
        {
            await OpenShowPopupMessageStage(model);
            return;
        }

        if (model.IsSmallPass())
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST,"MEMORY_QUEST_PASS"));
            return;
        }

        var mqMasterId = model.MasterId;
        _mStageSelected = mqMasterId;
        await _mMqSectionDialog.ShowPanel(mqMasterId);
    }

    private async UniTask OpenShowPopupMessageStage(MqMemoryQuestStatusViewModel view, bool isChaper = false)
    {
        string str = "";
        switch (view.lockedType)
        {
            case MqMemoryQuestStatusViewModel.LockedType.Chapter:
                //var playerChapter = DataManager.Instance.Player.Chapter.TryGet(view.RequireChapterMasterId);
                var playerChapter = DataManager.Instance.Master.Chapter[view.RequireChapterMasterId];
                var name = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{view.RequireChapterMasterId}_name");
                str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_OPEN_CHATPER"),new object[] {playerChapter.chapter,name});
                break;
            case MqMemoryQuestStatusViewModel.LockedType.Master:
                var memoryQuest = DataManager.Instance.Master.MemoryQuest[view.PreMasterId];
                var questName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, $"{memoryQuest.id}_name");
                if (isChaper)
                {
                    str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_OPEN_STAGE"), new object[] { memoryQuest.chapter , questName});
                }
                else
                {
                    str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_OPEN_MESTER"),questName);
                }
                break;
            case MqMemoryQuestStatusViewModel.LockedType.StatNum:
                var memoryQuestChapter = DataManager.Instance.Master.MemoryQuestChapter.Values.First(_ => _.chapter == view.Chapter && _.memoryQuestType == 2);
                str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_OPEN_STAR"),new object[] {memoryQuestChapter.requireStarNum});
                break;
        }
        await UI.Popup.ShowPopupMessageAsync(str);
    }

    private async UniTask SkipMq(MqMemoryQuestStatusViewModel model)
    {
        var parid = DataManager.Instance.Player.Player.GetCurrentStaimina();
        var useStamina = DataManager.Instance.Master.MemoryQuest[_mStageSelected].useStamina;
        if (parid < useStamina)
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_OPEN_PAID_NO"));
            return;
        }

        if (model.StarNumGot < model.StarNumTotal )
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_SKILL_PASS"));
            return;
        }

        await _mMqSectionDialog.FinishSkip(_mStageSelected);
    }

    private async UniTask StartBattle(GameObject o)
    {
        var parid = DataManager.Instance.Player.Player.GetCurrentStaimina();
        var useStamina = DataManager.Instance.Master.MemoryQuest[_mStageSelected].useStamina;
        if (parid < useStamina)
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_OPEN_PAID_NO"));
            return;
        }
        var param = new BattleSceneParam();
        var master = DataManager.Instance.Master.MemoryQuest[_mStageSelected];
        param.stageID = master.id;
        param.battleID = master.battleMasterId;
        await GameSceneManager.Instance.ChangeSceneAsync<BattleScene>("BattleScene", param);
    }

    private async UniTask HidePopUp(GameObject o)
    {
        await _mMqSectionDialog.HideFinishPopUp();
        await _mMqSectionDialog.ShowPanel(_mStageSelected);
    }

    public override void Dispose()
    {
        base.Dispose();

        if (_mMqChapterListDialog != null)
        {
            _mMqChapterListDialog.Dispose();
            _mMqChapterListDialog = null;
        }

        if (_mMqSectionDialog != null)
        {
            _mMqSectionDialog.Dispose();
            _mMqSectionDialog = null;
        }

        if (_mMqRewardPreviewPopUp != null)
        {
            _mMqRewardPreviewPopUp.Dispose();
            _mMqRewardPreviewPopUp = null;
        }
    }
}

public class UIMqScenarioSelectPageParam
{
    public enum ShowType
    {
        Chapter,
        Section
    }
    
    public ShowType showType = ShowType.Chapter;
    public int SelectedChapter = 1;
    public int mqType;
}