using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIMqRewardsBox : MonoBehaviour
{
    [SerializeField] private UIButton button; 
    
    [SerializeField] private Image rewardNotReach;
    [SerializeField] private Image rewardCanReceive;
    [SerializeField] private Image rewardReceived;

    public bool canReceiveNormal;
    public bool receivedNormal;
    public bool canReceiveHard;
    public bool receivedHard;
    public int chapter;
    public bool onNormalToggle;
    // position be 1, 2 or 3, represent for chapterReward1, 2, and 3
    public int position;

    public ClickEvent RewardBoxOnClick => button.onClick;

    public void OnShow(MqMemoryQuestStatusViewModel.MqType type)
    {
        if (type == MqMemoryQuestStatusViewModel.MqType.Normal)
        {
            SetUp(canReceiveNormal, receivedNormal);
        }
        else
        {
            SetUp(canReceiveHard, receivedHard);
        }
    }
    
    private void SetUp(bool canReceive, bool received)
    {
        if (received)
        {
            SetAsReceived();
        } else if (canReceive)
        {
            SetAsCanReceive();
        }
        else
        {
            SetAsNotReach();
        }
    }
    
    private void SetAsNotReach()
    {
        this.rewardNotReach.gameObject.SetActive(true);
        this.rewardCanReceive.gameObject.SetActive(false);
        this.rewardReceived.gameObject.SetActive(false);
    }

    private void SetAsReceived()
    {
        this.rewardNotReach.gameObject.SetActive(false);
        this.rewardCanReceive.gameObject.SetActive(true);
        this.rewardReceived.gameObject.SetActive(false);
    }

    private void SetAsCanReceive()
    {
        this.rewardNotReach.gameObject.SetActive(false);
        this.rewardCanReceive.gameObject.SetActive(false);
        this.rewardReceived.gameObject.SetActive(true);
    }
}