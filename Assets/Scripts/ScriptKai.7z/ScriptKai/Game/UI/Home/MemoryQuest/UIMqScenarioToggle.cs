﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class UIMqScenarioToggle : MonoBehaviour
{
    [SerializeField] private UIButton _button;
    [SerializeField] private GameObject offObj;
    [SerializeField] private GameObject onObj;
    [SerializeField] private GameObject lockObj;

    private MqMemoryQuestStatusViewModel.MqType memoryQuestType_;
    public ClickEvent OnClick => _button.onClick;
    public async UniTask SetUpAsync(MqChapterStatusViewModel model,MqMemoryQuestStatusViewModel.MqType memoryQuestType)
    {
        memoryQuestType_ = memoryQuestType;
        lockObj.gameObject.SetActive(false);
        if (memoryQuestType == MqMemoryQuestStatusViewModel.MqType.Hard)
        {
            var chapterModel = DataManager.Instance.Master.MemoryQuestChapter.Values.First(_ => _.chapter == model.Chapter && _.memoryQuestType == 2);
            if (chapterModel.requireStarNum > model.StarNumNormalGot)
            {
                lockObj.gameObject.SetActive(true);
            }
        }
    }

    public void SetToggleActive(MqMemoryQuestStatusViewModel.MqType memoryQuestType)
    {
        offObj.SetActive(memoryQuestType != memoryQuestType_);
        onObj.SetActive(memoryQuestType == memoryQuestType_);
    }
}
