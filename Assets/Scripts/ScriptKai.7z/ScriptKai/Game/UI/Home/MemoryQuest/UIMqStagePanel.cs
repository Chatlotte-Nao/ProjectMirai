using System;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;
using UnityEngine.UI;

public class UIMqStagePanel : MonoBehaviour
{
    [SerializeField] private UIText recommendLevel;
    [SerializeField] private UIText starInfo1;
    [SerializeField] private UIText starInfo2;
    [SerializeField] private UIText starInfo3;
    [SerializeField] private BaseItem itemPrefab;
    [SerializeField] private RectTransform itemContainer;
    [SerializeField] private UIText leftCount;
    [SerializeField] private UIText staminaCost;
    [SerializeField] private UIButton toBattleButton;
    [SerializeField] private UIButton toSkipButton;
    [SerializeField] private Image toSkipImage;
    [SerializeField] private GameObject starObj;
    [SerializeField] private Image[] stars;
    [SerializeField] private UIText rewardText;
    [SerializeField] private GameObject descObj;
    private List<BaseItem> mItem = new List<BaseItem>();
    
    public UIMqMemoryQuestStatusViewModelEvent OnClickSkip = new UIMqMemoryQuestStatusViewModelEvent();
    public ClickEvent OnClickBattle => toBattleButton.onClick;
    
    public async UniTask SetUpAsync(int memoryQuestMasterId)
    {
        this.toSkipButton.gameObject.SetActive(true);
        this.toBattleButton.gameObject.SetActive(true);
        // Setting Recommend Level
        var model = MemoryQuestUtil.BuildMqMemoryQuestStatusViewModel(memoryQuestMasterId); 
        var master = DataManager.Instance.Master.MemoryQuest.Values.First(_ => _.id == model.MasterId);
        var lv = master.recommendPlayerLevel;
        recommendLevel.SetFormat(LocalizeManager.DATA_TYPE.MEMORY_QUEST,"MEMORY_QUEST_DEGREE_DIFFICULTY", lv);
        // Setting Star Info1
        
        starInfo1.SetLabel(LocalizeManager.DATA_TYPE.MEMORY_QUEST,"MEMORY_QUEST_BATTLE_WIN");
        var roundLimit = master.roundNum;
        
        starInfo2.SetFormat(LocalizeManager.DATA_TYPE.MEMORY_QUEST,"MEMORY_QUEST_ROUND_WIN", roundLimit);
        var deathNum = master.deathNum;
        
        if(deathNum == 0)
            starInfo3.SetFormat(LocalizeManager.DATA_TYPE.MEMORY_QUEST,"MEMORY_QUEST_DEATH_NUM2");
        else
            starInfo3.SetFormat(LocalizeManager.DATA_TYPE.MEMORY_QUEST,"MEMORY_QUEST_DEATH_NUM", deathNum);
        // Possible DropItems
        var data = DataManager.Instance.Player.MemoryQuest.TryGet(memoryQuestMasterId);
        stars[0].color = data != null && data.Star1 ? Color.white : Color.black;
        stars[1].color = data != null && data.Star2 ? Color.white : Color.black;
        stars[2].color = data != null && data.Star3 ? Color.white : Color.black;
        // for (int i = 0; i < stars.Length; i++)
        // {
        //     stars[i].color = model.StarNumGot > i ? Color.white : Color.black;
        // }
        foreach (var item in mItem)
        {
            item.gameObject.SetActive(false);
        }

        if (model.StarNumGot == 0 && master.firstClearRewardContents.Count > 0)
        {
            for (int i = 0; i < master.firstClearRewardContents.Count; i++)
            {
                var s =  master.firstClearRewardContents[i].Split(':');
                var itemId = long.Parse(s[0]);
                if (i < mItem.Count)
                {
                    await mItem[i].SetupAsync(itemId, s[1]);
                    mItem[i].gameObject.SetActive(true);
                }
                else
                {
                    var item = Instantiate(itemPrefab, itemContainer);
                    await item.SetupAsync(itemId, s[1]);
                    item.gameObject.SetActive(true);
                    mItem.Add(item);
                }
            }
            rewardText.SetFormat(LocalizeManager.DATA_TYPE.MEMORY_QUEST,"MEMORY_QUEST_FIRST_REWARD");
        }
        else if( !model.IsLocked()&& model.StarNumGot!=0 && master.displayDropRewardContents.Count>0 ){
            for (int i = 0; i < master.displayDropRewardContents.Count; i++)
            {
                var itemId = master.displayDropRewardContents[i];
                if (i < mItem.Count)
                {
                    await mItem[i].SetupAsync(itemId, string.Empty);
                    mItem[i].gameObject.SetActive(true);
                }
                else
                {
                    var item = Instantiate(itemPrefab, itemContainer);
                    await item.SetupAsync(itemId, string.Empty);
                    item.gameObject.SetActive(true);
                    mItem.Add(item);
                }
            }
            rewardText.SetFormat(LocalizeManager.DATA_TYPE.MEMORY_QUEST,"MEMORY_QUEST_DROP");
        }else
            rewardText.gameObject.SetActive(false);
        
        leftCount.SetFormat(LocalizeManager.DATA_TYPE.MEMORY_QUEST,"MEMORY_QUEST_REMAINING_TIMES", model.DailyCountLeft);
        staminaCost.SetFormat(LocalizeManager.DATA_TYPE.MEMORY_QUEST,"MEMORY_QUEST_CONSUME_AP", model.StaminaCost);
        toSkipButton.onClick.RemoveAllListeners();
        toSkipButton.onClick.AddListener( _=>OnClickSkip.Invoke(model));
        if (model.soreType == MqMemoryQuestStatusViewModel.SoreType.Big)
        {
            starObj.gameObject.SetActive(true);
            // 如果没有达到三星则不开放扫荡
            this.toSkipButton.gameObject.SetActive(model.DailyCountLeft > 0);
            // 如果剩余次数为0则不开放战斗
            this.toSkipImage.color = model.StarNumGot >= model.StarNumTotal ? Color.white : Color.black;
            this.toBattleButton.gameObject.SetActive(model.DailyCountLeft > 0);
            descObj.SetActive(model.DailyCountLeft <=0);
        }
        else
        {
            starObj.SetActive(false);
            this.toSkipButton.gameObject.SetActive(false);
            this.toBattleButton.gameObject.SetActive(model.DailyCountLeft <= 0 || !model.isWin);
            descObj.SetActive(false);
        }
    }
}