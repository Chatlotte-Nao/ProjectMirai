﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIHomeBg : UIDialogBase
{
    [SerializeField] UIButton hallButton;
    [SerializeField] UIButton entranceButton;
    [SerializeField] UIButton shopButton;
    [SerializeField] UIButton wingButton;
    [SerializeField] UIButton trainingButton;

    public UIStrEvent OnClickMap = new UIStrEvent();


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        hallButton.OnTouchUpInside.GuardSubscribeAsync(onClickHall).AddTo(mSubscriptions);
        entranceButton.OnTouchUpInside.GuardSubscribeAsync(onClickEntrance).AddTo(mSubscriptions);
        trainingButton.OnTouchUpInside.GuardSubscribeAsync(onClickTraining).AddTo(mSubscriptions);
        wingButton.OnTouchUpInside.GuardSubscribeAsync(onClickWing).AddTo(mSubscriptions);
        shopButton.OnTouchUpInside.GuardSubscribeAsync(onClickShop).AddTo(mSubscriptions);
    }

    private async UniTask onClickHall()
    {
        Hide();
        gotoMap("advBuilding[10]");
    }

    private async UniTask onClickEntrance()
    {
        Hide();
        gotoMap("advBuilding[7]");
    }

    private async UniTask onClickTraining()
    {
        Hide();
        gotoMap("advBuilding[9]");
    }

    private async UniTask onClickShop()
    {
        Hide();
        gotoMap("advBuilding[11]");
    }

    private async UniTask onClickWing()
    {
        Hide();
        gotoMap("advBuilding[8]");
    }

    private void gotoMap(string label)
    {
        OnClickMap.Invoke(label);
    }
}
