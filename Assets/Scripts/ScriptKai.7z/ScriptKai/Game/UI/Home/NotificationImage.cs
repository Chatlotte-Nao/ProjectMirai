﻿using UnityEngine;
using UnityEngine.UI;

namespace Map {
    public class NotificationImage : MonoBehaviour
    {
        [SerializeField] Image image;
        [SerializeField] Text text;

        public VariousNotification.CONTENT_NAME contentName { get; private set; }
        
        public void Create(VariousNotification.CONTENT_NAME contentName)
        {
            this.contentName = contentName;
        }

        public void SetText(string value)
        {
            text.text = value;
        }
    }
}