﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;

public class UIHomeMailWindow : UIDialogBase
{
    [SerializeField] private UIButton backBtn;
    [SerializeField] private UIText emailNumberTxt;
    [SerializeField] private UIText emailNotClaimedNumberTxt;
    [SerializeField] private UIButton oneKeyReceiveBtn;
    [SerializeField] private UIButton oneKeyDeleteBtn;
    
    [SerializeField] UIMailTabBtn tabBtnPrefab;
    [SerializeField] RectTransform tabBtnParent;
    
    [SerializeField] private UIButton receiveBtn;
    [SerializeField] private UIButton deleteBtn;

    [SerializeField] private UIHomeMailContent mailContent;
    
    [SerializeField] private GameObject mailObj;
    [SerializeField] private GameObject notMailObj;
    public ClickEvent OnShowHome => backBtn.onClick;
    public ClickEvent OnOneKeyReceiveClick => oneKeyReceiveBtn.onClick;
    public ClickEvent OnOneKeyDeleteClick => oneKeyDeleteBtn.onClick;
    public ClickEvent OnReceiveClick => receiveBtn.onClick;
    public ClickEvent OnDeleteClick => deleteBtn.onClick;
    
    public UIMailViewEvent OnSelectClick = new UIMailViewEvent();
    private List<UIMailTabBtn> emailTabBtns = new List<UIMailTabBtn>();
    
    public ClickEvent OnWebClick => mailContent.WebClick;
    public ClickEvent OnFunctionClick => mailContent.FunctionClick;
    public async UniTask SetUpAsunc(List<MailStatusViewModel> models)
    {
        foreach (var emailTabBtn in emailTabBtns)
        {
            emailTabBtn.gameObject.SetActive(false);
        }
        if (models != null && models.Count > 0)
        {
            notMailObj.SetActive(false);
            mailObj.SetActive(true);
            for (int i = 0; i < models.Count; i++)
            {
                var index = i;
                if (index < emailTabBtns.Count)
                {
                    await emailTabBtns[index].SetUpAsync(models[index]);
                    emailTabBtns[index].OnClick.RemoveAllListeners();
                    emailTabBtns[index].OnClick.Subscribe((_) =>
                    {
                        OnSelectClick.Invoke(models[index]);
                    }).AddTo(mSubscriptions);
                    emailTabBtns[index].gameObject.SetActive(true);
                }
                else
                {
                    var button = Instantiate(tabBtnPrefab, this.tabBtnParent, false);
                    await button.SetUpAsync(models[index]);
                    button.OnClick.Subscribe((_) =>
                    {
                        OnSelectClick.Invoke(models[index]);
                    }).AddTo(mSubscriptions);
                    emailTabBtns.Add(button);
                }
            }
        }
        else
        {
            notMailObj.SetActive(true);
            mailObj.SetActive(false);
        }
        emailNumberTxt.SetFormat(LocalizeManager.DATA_TYPE.MAIL, "Mail_Number", $"{models.Count}/{ DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.MailNumberCost].data}");
        var notClaimedMailCount= models.Count(item => item.openState== MailStatusViewModel.MailOpenState.Unread);
        emailNotClaimedNumberTxt.SetFormat(LocalizeManager.DATA_TYPE.MAIL, "Mail_NotClaimedMail", $"{notClaimedMailCount}");
    
    }

    public async UniTask UpdateUnread(List<MailStatusViewModel> models)
    {
        var notClaimedMailCount= models.Count(item => item.openState== MailStatusViewModel.MailOpenState.Unread);
        emailNotClaimedNumberTxt.SetFormat(LocalizeManager.DATA_TYPE.MAIL, "Mail_NotClaimedMail", $"{notClaimedMailCount}");
    }

    public async UniTask SelectTab(MailStatusViewModel model)
    {
        foreach (var emailTabBtn in emailTabBtns)
        {
            emailTabBtn.SetSelectActive(model);
        }
        receiveBtn.gameObject.SetActive(model.rewards.Count>0 && model.rewardState == MailStatusViewModel.MailRewardState.NotClaimed); 
        deleteBtn.gameObject.SetActive( model.rewards.Count <= 0 || model.rewardState == MailStatusViewModel.MailRewardState.Received);
        await mailContent.SetUpAsync(model);
        
    }
}
public class UIMailViewEvent: UnityEvent<MailStatusViewModel>
{
}

