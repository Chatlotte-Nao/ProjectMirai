﻿using UnityEngine;

namespace Script.Game.UI.Home.Mail
{
    public class UIMailBaseItem : BaseItem
    {
        [SerializeField] private GameObject receivedImage;
    
    
        public  void SetupActive(bool received)
        {
            receivedImage.SetActive(received);
        }
    }
}
