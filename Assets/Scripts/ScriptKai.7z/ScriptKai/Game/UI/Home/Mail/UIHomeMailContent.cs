﻿
using System;
using System.Collections.Generic;
using Base.Util;
using Script.Game.UI.Home.Mail;
// using Script.Game.UI.Home.Mail;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeMailContent : MonoBehaviour
{
    [SerializeField] private UIText titleTxt;
    [SerializeField] private UIText senderTxt;
    [SerializeField] private UIText termTxt;
    [SerializeField] private UIText sendTimeTxt;
    
    [SerializeField] private UIMailBaseItem baseItemPrefab;
    [SerializeField] private RectTransform itemsParent;

    [SerializeField] private UIText contentTxt;
    
    [SerializeField] private GameObject fuctionObj;
    [SerializeField] private UIButton fuctionBtn;
    [SerializeField] private UIText fuctionTxt;
    
    [SerializeField] private GameObject webObj;
    [SerializeField] private UIButton webBtn;
    [SerializeField] private UIText webTxt;
    
    [SerializeField] private GameObject imageObj;
    [SerializeField] private Image image;
    [SerializeField] private int firstLineIndentWidth = 0;
    
    private List<UIMailBaseItem> items = new List<UIMailBaseItem>();

    public ClickEvent WebClick => webBtn.onClick;
    public ClickEvent FunctionClick => fuctionBtn.onClick;
    public async UniTask SetUpAsync(MailStatusViewModel model)
    {
        titleTxt.SetLabel(LocalizeManager.DATA_TYPE.MAIL, model.title);
        senderTxt.SetFormat(LocalizeManager.DATA_TYPE.MAIL, "Maid_Send", LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MAIL, model.sender));
        endTime = GlobalTime.GetDateTime(model.lifeTimeEndAt);
        var timeindex = CommonUtil.GetCountDownTime( endTime,out var timeType);
        termTxt.SetFormat(LocalizeManager.DATA_TYPE.MAIL, $"Mail_Term_{timeType}", timeindex);
        isStartTime = false;
        if (timeType == 3 || timeType == 4)
        {
            timeIndex = (int)(endTime - GlobalTime.Now).TotalSeconds;
            isStartTime = true;
        }
        sendTimeTxt.SetFormat(LocalizeManager.DATA_TYPE.MAIL, "Mail_SendTime", GlobalTime.GetDateTime(model.createdTime).ToShortDateString());
        // var firstLineIndentStr="";
        // for (int i = 0; i < firstLineIndentWidth; i++)
        // {
        //     firstLineIndentStr += " ";
        // }
        contentTxt.SetLabel(LocalizeManager.DATA_TYPE.MAIL, model.textContent);
        fuctionObj.SetActive(false);
        webObj.SetActive(false);
        imageObj.SetActive(false);

        foreach (var item in items)
        {
            item.gameObject.SetActive(false);
        }

        for (int i = 0; i <  model.rewards.Count; i++)
        {
            var s = model.rewards[i].Split(':');
            var itemId = long.Parse(s[0]);
            if (i < items.Count)
            {
                items[i].transform.localScale = new Vector3(0.5f, 0.5f, 1f);
                await  items[i].SetupAsync(itemId,s[1]);
                items[i].SetupActive(model.rewardState== MailStatusViewModel.MailRewardState.Received);
                items[i].gameObject.SetActive(true);
            }
            else
            {
                var item = Instantiate(baseItemPrefab, this.itemsParent, false);
                item.transform.localScale = new Vector3(0.5f, 0.5f, 1f);
                await item.SetupAsync(itemId,s[1]);
                item.SetupActive(model.rewardState== MailStatusViewModel.MailRewardState.Received);
                item.gameObject.SetActive(true);
                items.Add(item);
            }
        }

        if (model.contentTypes.Count>0)
        {
            foreach (var contentType in model.contentTypes)
            {
                if (contentType == MailStatusViewModel.MailContentType.FunctionLink)
                {
                    fuctionObj.SetActive(true);
                    fuctionTxt.SetRawText(model.functionLink);
                }
                else if (contentType == MailStatusViewModel.MailContentType.WebLink)
                {
                    webObj.SetActive(true);
                    webTxt.SetRawText(model.webStr);
                }
                else if (contentType == MailStatusViewModel.MailContentType.Image)
                {
                    imageObj.SetActive(true);
                    image.sprite = await ResourceManager.Instance.LoadSpriteAsync("Mail",model.imagePath);
                }

            }
        }
    }
    
    private DateTime endTime;
    void UpdateTime()
    {
        var timeindex =  CommonUtil.GetCountDownTime( endTime,out var timeType);
        termTxt.SetFormat(LocalizeManager.DATA_TYPE.MAIL, $"Mail_Term_{timeType}", timeindex);
    }

    private int timeIndex;
    private float time = 0;
    bool isStartTime = false;
    private void Update()
    {
        if (isStartTime)
        {
            time += Time.fixedDeltaTime;
            if (time > 1)
            {
                timeIndex--;
                time = 0;
                UpdateTime();
                if (timeIndex <= 0)
                {
                    this.gameObject.SetActive(false);
                    isStartTime = false;
                }
            }
        }
    }
}
