using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using TMPro;

public class UIExchangeDialog : UIDialogBase
{
    [SerializeField] private GameObject frame = null;
    [SerializeField] private GameObject success = null;
    
    [SerializeField]
    private TMP_InputField InputText = null;
    [SerializeField]
    private UIButton cleanButton = null;
    [SerializeField]
    private UIButton cancelButton = null;
    [SerializeField]
    private UIButton exchangeButton = null;
    [SerializeField]
    private UIButton closeBtn= null;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
#if BUILD_DEBUG || UNITY_EDITOR
        
#endif
        closeBtn.OnTouchUpInside.Subscribe(OnClickClose).AddTo(mSubscriptions);
        exchangeButton.OnTouchUpInside.Subscribe(OnClickExchange).AddTo(mSubscriptions);
        cancelButton.OnTouchUpInside.Subscribe(OnClickCancel).AddTo(mSubscriptions);
        cleanButton.OnTouchUpInside.Subscribe(OnClickClean).AddTo(mSubscriptions);
        //InputText.onValueChanged.AddListener(InputOnChanged);
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        InputText.text = string.Empty;
        await base.ShowAsync(showType);
    }
    private void InputOnChanged(string id)
    {
        Debug.Log(LCXHandler.Instance.AffCode);
        Debug.Log(id);
    }
    
    private async void  OnClickExchange()
    {
        await ExchangeService.GetExchangesAsync(InputText.text);
        if (true)
        {
            frame.SetActive(false);
            success.SetActive(true);
            Invoke("OnClickCancel",2f);
        }
    }
    
    private void OnClickCancel()
    {
        //UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON,
        //    "Common_Setting_RebootHint"));
        // frame.SetActive(true);
        // success.SetActive(false);
        Hide();
        Destroy(gameObject);
    }
    
    private void OnClickClean()
    {
        //string str = GUIUtility.systemCopyBuffer;
        
        InputText.text = "";
    }

    private void OnClickClose()
    {
        // UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON,
        //     "Common_Setting_RebootHint"));
        Hide();
        Destroy(gameObject);
    }
}
