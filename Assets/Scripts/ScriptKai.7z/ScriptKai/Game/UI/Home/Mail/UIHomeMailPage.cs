﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Mail.V1;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class UIHomeMailPage : UIPageBase
{
    private UIHomeMailWindow _emaliWindow = null;
    private UIWebViewDialog _webViewDialog = null;
    private Dictionary<string ,MailStatusViewModel> _mailModels = new Dictionary<string,MailStatusViewModel>();
    private MailStatusViewModel _selectMail;
    UIHomeHeaderParam headerParam = new UIHomeHeaderParam();
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        headerParam.visibleBack = true;
        headerParam.visibleNavigation = true;
        headerParam.visibleHome = true;
        _emaliWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeMailWindow, CanvasType.App0) as UIHomeMailWindow;
       

        _emaliWindow.OnOneKeyReceiveClick.GuardSubscribeAsync(OneKeyReceive).AddTo(mSubscriptions);
        _emaliWindow.OnOneKeyDeleteClick.GuardSubscribeAsync(OneKeyDelete).AddTo(mSubscriptions);
        _emaliWindow.OnReceiveClick.GuardSubscribeAsync(OnReceive).AddTo(mSubscriptions);
        _emaliWindow.OnDeleteClick.GuardSubscribeAsync(OnDelete).AddTo(mSubscriptions);
        _emaliWindow.OnShowHome.GuardSubscribeAsync(ShowMainMenu).AddTo(mSubscriptions);
        _emaliWindow.OnSelectClick.GuardSubscribeAsync(OnSelectClick).AddTo(mSubscriptions);
        
        _emaliWindow.OnWebClick.GuardSubscribeAsync(OnGotoWebClick).AddTo(mSubscriptions);
        _emaliWindow.OnFunctionClick.GuardSubscribeAsync(OnGotoFunctionClick).AddTo(mSubscriptions);

    }
    
    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHomeHeaderUpdate,headerParam);
        await base.ShowAsync(showType);
        await _emaliWindow.ShowAsync(showType);
        _upadteAllMailViewModels();
        await _emaliWindow.SetUpAsunc(_mailModels.Values.ToList());
        if (_mailModels.Count > 0)
        {
            await OnSelectClick(_mailModels.Values.ToList()[0]);
        }
    }
    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await _emaliWindow.HideAsync();
    }
    private async UniTask OnReceive(GameObject o)
    {
        var newMail =  await MailService.ReceiveRewardsAsync(_selectMail.mailId);
        _mailModels[_selectMail.mailId] = MailUtil.BuildMailStatusViewModel(newMail);

        _selectMail = _mailModels[_selectMail.mailId];
        await _emaliWindow.SelectTab(_selectMail);
        await ShowRewardDialog(_selectMail.rewards);
        await _emaliWindow.SetUpAsunc(_mailModels.Values.ToList());

    }
    private async UniTask OnDelete(GameObject o)
    {
        await MailService.RemoveMailAsync(_selectMail.mailId);
        _mailModels.Remove(_selectMail.mailId);
        await _emaliWindow.SetUpAsunc(_mailModels.Values.ToList());
        if (_mailModels.Count > 0)
        {
            await OnSelectClick(_mailModels.Values.ToArray()[0]);
        }
    }

    private async UniTask ShowRewardDialog(List<string> rewards)
    {
        await UI.Popup.ShowItemGetPopupAsync(rewards);
    }
    private async UniTask OneKeyReceive(GameObject o)
    {
        var allRewards = MailUtil.GetAllRewards(_mailModels.Values.ToList());
        var unreads = _mailModels.Values.Where(a => a.openState == MailStatusViewModel.MailOpenState.Unread).ToArray();
        if (allRewards.Count > 0 || unreads.Length > 0 )
        {
            await MailService.ReceiveAllRewardsAsync();
            _upadteAllMailViewModels();
            if(allRewards.Count > 0)
                await ShowRewardDialog(allRewards);
            await _emaliWindow.SetUpAsunc(_mailModels.Values.ToList());
            if (_mailModels.Count > 0)
            {
                _selectMail = null;
                await OnSelectClick(_mailModels.Values.ToArray()[0]);
            }
        }
    }
    private async UniTask OneKeyDelete(GameObject o)
    {
        await MailService.RemoveReadAndReceivedMailsAsync();
        _upadteAllMailViewModels();
        await _emaliWindow.SetUpAsunc(_mailModels.Values.ToList());
        if (_mailModels.Count > 0)
        {
            await OnSelectClick(_mailModels.Values.ToArray()[0]);
        }
    }
    public async UniTask OnSelectClick(MailStatusViewModel model)
    {
        if (_selectMail !=null && _selectMail.mailId.Equals(model.mailId))
        {
            return;
        }
        if (model.openState != MailStatusViewModel.MailOpenState.Read)
        {
            var newMail = await MailService.OpenMailAsync(model.mailId);
            _mailModels[model.mailId].lifeTimeEndAt = newMail.LifeTimeEndAt;
        }
        _mailModels[model.mailId].openState = MailStatusViewModel.MailOpenState.Read;
        _selectMail = _mailModels[model.mailId];
        await _emaliWindow.UpdateUnread(_mailModels.Values.ToList());
        await _emaliWindow.SelectTab(_selectMail);
    }

    private async UniTask ShowMainMenu(GameObject o)
    {
        await UI.Page.CloseCurrentPage();
        // await UI.Page.ChangePage<UIHomeMainPage>();
    }
    
    private async UniTask OnGotoWebClick(GameObject o)
    {
        if (_webViewDialog == null)
        {
            _webViewDialog = (UIWebViewDialog) await UI.Dialog.CreateAsync(UIPrefabId.UIWebViewFullScreenDialog, CanvasType.App1);
            await _webViewDialog.SetupAsync(_selectMail.webLink,_selectMail.webStr);
            // _webViewDialog.OnBack.Subscribe(_=>{
            //      _webViewDialog.Dispose();
            //      _webViewDialog = null;
            // });
            await _webViewDialog.ShowAsync();
        }
    }
    private async UniTask OnGotoFunctionClick(GameObject o)
    {
        await CommonUtil.JumpToTargetPage(_selectMail.functionLink);
    }
    private void _upadteAllMailViewModels()
    {
        _mailModels.Clear();
        var mailList = DataManager.Instance.Player.Mail.GetList();
        //var list = mailList.OrderBy(a => a.CreatedAt);
        foreach (PlayerMail pe in mailList)
        {
            _mailModels.Add(pe.MailId,MailUtil.BuildMailStatusViewModel(pe));
        }
    }
    public override void Dispose()
    {
        base.Dispose();
        if (_emaliWindow != null)
        {
            _emaliWindow.Dispose();
            _emaliWindow = null;
        }
        if (_webViewDialog != null)
        {
            _webViewDialog.Dispose();
            _webViewDialog = null;
        }
    }
}
