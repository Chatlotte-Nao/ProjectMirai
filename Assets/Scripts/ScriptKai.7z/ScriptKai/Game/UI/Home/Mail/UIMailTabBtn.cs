﻿using System;
using System.Collections;
using System.Collections.Generic;
using Base.Util;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;  
using UnityEngine.UI;

public class UIMailTabBtn : MonoBehaviour
{
    [SerializeField] private Image iconImg;
    [SerializeField] private UIText receiveTxt;
    [SerializeField] private GameObject receiveRedObj;

    [SerializeField] private UIText titleTxt;
    [SerializeField] private UIText senderTxt;
    [SerializeField] private UIText termTxt;

    [SerializeField] private Image clickImg;
    [SerializeField] private UIButton clickBtn;
     [SerializeField] private GameObject selectObj;
    public ClickEvent OnClick => clickBtn.onClick;

    private MailStatusViewModel model_;
    public async UniTask SetUpAsync(MailStatusViewModel model)
    {
        model_ = model;
        titleTxt.SetLabel(LocalizeManager.DATA_TYPE.MAIL, model.title);
        //senderTxt.SetLabel(LocalizeManager.DATA_TYPE.MAIL, model.sender);
        senderTxt.SetRawText(GlobalTime.GetDateTime(model.createdTime).ToShortDateString());
        UpdataAllActive(model);
    }

    public void SetSelectActive(MailStatusViewModel selectModel)
    {
        selectObj.SetActive(  model_.mailId == selectModel.mailId);
        if( model_.mailId == selectModel.mailId)
            UpdataAllActive(selectModel);
    }

    void UpdataAllActive(MailStatusViewModel model)
    {
        receiveRedObj.SetActive( model.rewards.Count > 0 &&  model.rewardState == MailStatusViewModel.MailRewardState.NotClaimed);
        iconImg.color =model.openState == MailStatusViewModel.MailOpenState.Read ? Color.black : Color.white;
        clickImg.color = model.openState == MailStatusViewModel.MailOpenState.Read ? Color.black : Color.white;
        endTime = GlobalTime.GetDateTime(model.lifeTimeEndAt);
        var timeindex = CommonUtil.GetCountDownTime( endTime,out var timeType);
        termTxt.SetFormat(LocalizeManager.DATA_TYPE.MAIL, $"Mail_Term_{timeType}", timeindex);
        isStartTime = false;
        if (timeType == 0)
        {
            termTxt.SetLabel(LocalizeManager.DATA_TYPE.MAIL, $"Mail_Expiration");
        }
        else if (timeType == 3 || timeType == 4)
        {
            timeIndex = (int)(endTime - GlobalTime.Now).TotalSeconds;
            isStartTime = true;
        }
    }

    private DateTime endTime;
    void UpdateTime()
    {
        var timeindex =  CommonUtil.GetCountDownTime( endTime,out var timeType);
        termTxt.SetFormat(LocalizeManager.DATA_TYPE.MAIL, $"Mail_Term_{timeType}", timeindex);
    }

    private int timeIndex;
    private float time = 0;
    bool isStartTime = false;
    private void Update()
    {
        if (isStartTime)
        {
            time += Time.fixedDeltaTime;
            if (time > 1)
            {
                timeIndex--;
                time = 0;
                UpdateTime();
                if (timeIndex <= 0)
                {
                    this.gameObject.SetActive(false);
                    isStartTime = false;
                }
            }
        }
    }
}
