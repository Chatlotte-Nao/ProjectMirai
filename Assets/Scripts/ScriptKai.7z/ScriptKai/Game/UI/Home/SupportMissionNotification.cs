﻿using Base.Util;
//using Game.Core.Net;

using Game.Extensions;
using System;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Home
{
	public sealed class SupportMissionNotification : MonoBehaviour
	{
		//public UnionSupportMissionData DisplaySupportMissionData { get; set; }


#pragma warning disable IDE0044, 0649 // SerializeField で不要な警告の抑制
		[SerializeField] Text limitTimeText;
        [SerializeField] Image rareEnemyIcon;
#pragma warning restore IDE0044, 0649 // SerializeField で不要な警告の抑制


		public void Refresh()
		{
			CheckTimeLimit();

			// 表示支援任務データを取得。
			//if (DisplaySupportMissionData == null)
			//{
			//	var myUnionData = UserData.GetPlayerData().FindMyUnionData();
			//	if (myUnionData != null)
			//	{
   //                 var userId = myUnionData.FindMyMemberData()?.userId;
   //                 DisplaySupportMissionData = myUnionData.EnumerateSelectableSupportMissionData()
			//			.OrderBy(data => data.endUnixTime)
			//			.FirstOrDefault();

			//		if (DisplaySupportMissionData != null)
			//		{
			//			endDateTime = TimeUtil.GetDateTime(DisplaySupportMissionData.endUnixTime);
   //                     var investigationBattleMissionMaster = MasterData.GetInstance().investigationBattleMaster.ContainsKey(DisplaySupportMissionData.investigationBattleMasterId)
   //                         ? MasterData.GetInstance().investigationBattleMaster[DisplaySupportMissionData.investigationBattleMasterId] : null;
   //                     if (investigationBattleMissionMaster != null)
   //                     {
   //                         rareEnemyIcon.gameObject.SetActive(investigationBattleMissionMaster.isRareButtle > 0);
   //                     }
   //                     this.gameObject.SetActive(true);
			//		}
			//	}
			//}

			//gameObject.SetActiveOnlyChanged(DisplaySupportMissionData != null);
			//if (DisplaySupportMissionData == null) { return; }

			//var timeSpan = endDateTime - TimeUtil.GetDateTime(ServerDateTime.GetUnixTime());
			//limitTimeText.text = timeSpan.ToString("c");
		}

		#region 初期化
		public void Init()
		{
			Refresh();
		}

		void Awake()
		{
			InitializeEvents();
		}

		void InitializeEvents()
		{
		}
		#endregion

		void CheckTimeLimit()
		{
			//if (DisplaySupportMissionData == null) { return; }
			//if (!DisplaySupportMissionData.IsEnd()) { return; }

			//UserData.GetPlayerData().FindMyUnionData().supportMissionDataList.Remove(DisplaySupportMissionData);
			////SaveData.Save(true);

			//DisplaySupportMissionData = null;
            this.gameObject.SetActive(false);
		}

		void OnDestroy()
		{
			limitTimeText = null;
            rareEnemyIcon = null;
		}


		DateTime endDateTime;
	}
}
