﻿using System.Text;
using UnityEngine;
using UnityEngine.UI;

using TMPro;
using Game.Ui;

namespace Map
{
    public class ItemGetConfirm : MonoBehaviour
    {
        [SerializeField] Text itemName;
        [SerializeField] Text amountNum;
        [SerializeField] TextMeshProUGUI after;
        [SerializeField] TextMeshProUGUI afterNum;
        [SerializeField] TextMeshProUGUI beforeNum;
        [SerializeField] TextMeshProUGUI warning;

        string item;

        /// <summary>アイテムの所持数</summary>
        int myItem;

        /// <summary>
        /// アイテム獲得
        /// </summary>
        /// <param name="label">施設ID</param>
        /// <param name="getItem">獲得アイテム数</param>
        /// <param name="get">受け取れるアイテム数</param>
        public void Set(string label, int getItem, int get, int useMoney)
        {
            StringBuilder stringBuilder = new StringBuilder();
            if (label == FacilityIconController.staminaLabel)
            {
                item = LocalizeManager.GetCommonText("COMMON_ITEM_STAMINA");

                ///今の所持数を取得
                
                //myItem = UserData.GetPlayerData().stamina;
                ///最大所持数
               // int max = UserData.GetPlayerData().staminaMax;
                int result = myItem + get;
                //SetWarning(myItem, max, getItem);
                beforeNum.text = myItem.ToString();
                afterNum.text = result.ToString();
            }
            else if(label == FacilityIconController.coinLabel)
            {
                item = LocalizeManager.GetCommonText("COMMON_ITEM_MONEY");

                //myItem = UserData.GetPlayerData().coin;
                int limit = myItem - useMoney;
                //int max = UserData.GetPlayerData().coinMax;
                int result = limit + get;
                //SetWarning(limit, max, getItem);
                var colorTagText = limit < 0 ? "<color=#dc5555>" : "<color=#000000>";
                beforeNum.text = colorTagText + limit.ToString() + "</color>";
                afterNum.text = colorTagText + result.ToString() + "</color>";
            }

            amountNum.text = getItem.ToString();
            itemName.text = string.Format(LocalizeManager.GetCommonText("FACILITY_ITEMGET"), item);
            after.text = string.Format("{0}:", item);
            
        }


        void SetWarning(int myItem, int max, int getItem)
        {
            int result = myItem + getItem;
            if (max >= result)
            {
                warning.gameObject.SetActive(false);
            }
            else if (max < result)
            {
                warning.text = string.Format(LocalizeManager.GetCommonText("FACILITY_ITEMGET_OVERLIMIT"), max);
                warning.gameObject.SetActive(true);
            }
        }
        

        public void ResetText()
        {
            if (warning.gameObject.activeSelf)
            {
                warning.gameObject.SetActive(false);
            }
        }
    }
}