﻿using System.Text;
using UnityEngine;
using UnityEngine.UI;

using TMPro;
using Pheonix.Core;

namespace Map
{
    public class StrengthenFacility : UIDialogBase
    {
        [SerializeField] UIText facilityName;
        [SerializeField] UIText level;
        [SerializeField] UIText amountNum;
        [SerializeField] UIText limitNum;
        [SerializeField] UIText[] coins;
        [SerializeField] UIText time;
        [SerializeField] UIText conditions;
        [SerializeField] UIText achieved;

        [SerializeField] ItemGetConfirm getConfirm;
        [SerializeField] Image bg;

        [SerializeField] NotStrengthen notStrengthen;
        [SerializeField] Camera uiCamera;
        
        //FacilityData data;
        int userCoin;

        /// <summary>ユーザーレベル</summary>
        int conductorLv;

        /// <summary>強化開始の有無</summary>
        public bool isStart { get; private set; }

        public bool isPopUp { get; private set; }

        /// <summary>
        /// 強化確認ダイアログの表示設定
        /// </summary>
        public void SetDialog()
        {
            //userCoin = UserData.GetPlayerData().coin;
            //var master = FacilityData.GetNextLevel(data.lv);
            //if (master == null) return;
            isStart = false;

            //if (data.label == FacilityIconController.staminaLabel)
            //{
                //amountNum.SetRawText(GetText(data.get, master.stamina_get, true));
                //limitNum.SetRawText(GetText(data.limit, master.stamina_limit));
           // }
            //else if (data.label == FacilityIconController.coinLabel)
           // {
                //amountNum.SetRawText(GetText(data.get, master.coin_get, true));
                //limitNum.SetRawText(GetText(data.limit, master.coin_limit));
           // }
          //  facilityName.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "FACILITY_ENHANCE_LABEL", LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ROOM_NAME, data.name));
            //level.SetRawText(GetText(data.lv, master.lv));

            coins[0].SetRawText(userCoin.ToString());
           // int limitCoin = userCoin - master.money;
            //coins[1].SetRawText(limitCoin.ToString());

            TextSet();

            int hours = 60;
            //if (master.time < hours)
            //{
            //    time.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "COMMON_TIME_MIN", master.time);
            //}
            //else
            //{
            //    int useTime = master.time / hours;
            //    int minute = master.time % hours;
            //    if (minute <= 0)
            //        time.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "COMMON_TIME_HOUR", useTime);
            //    else
            //        time.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "COMMON_TIME_HOURMIN", useTime, minute);
            //}
        }

        /// <summary>
        /// 強化ができるか
        /// </summary>
        /// <param name="label">施設情報</param>
        /// <returns></returns>
        //public bool IsGoChange(FacilityData data, int coin)
        //{
        //    int nextLv = data.lv + 1;
        //    this.data = data;

            //if (FacilityData.GetNextLevel(data.lv) == null)
            //    return false;

        //    return IsChange(coin);
        //}

        /// <summary>
        /// OKボタンの設定(強化を開始できるか)
        /// </summary>
        /// <param name="nextLv">次のレベル</param>
        /// <returns></returns>
        bool IsChange(int coin)
        {
            ///強化不可原因のカウント
            int not = 0;
            //var master = FacilityData.GetNextLevel(data.lv);
           // conductorLv = UserData.GetPlayerData().level;
            ///コンダクターレベルが設定されているとき
            //if (master.conductorLv > 0)
            //{
            //    ///コンダクターレベルが不足
            //    if (conductorLv < master.conductorLv)
            //    {
            //        notStrengthen.Type(NotStrengthen.NOT_TYPE.LEVEL);
            //        notStrengthen.ConductorLvSet(master.conductorLv, false);
            //        not++;
            //    }
            //    else
            //    {
            //        notStrengthen.ConductorLvSet(master.conductorLv, true);
            //    }
            //}
            //else
            //{
            //    notStrengthen.Nothing();
            //}

            /////コインが不足
            //if (coin < master.money)
            //{
            //    notStrengthen.Type(NotStrengthen.NOT_TYPE.COIN);
            //    not++;
            //}

            if (not > 0)
            {
                if (not == (int)NotStrengthen.NOT_TYPE.BOTH)
                {
                    notStrengthen.Type(NotStrengthen.NOT_TYPE.BOTH);
                }
                return false;
            }

            return true;
        }

        /// <summary>
        /// テキスト設定
        /// </summary>
        void TextSet()
        {
            //var master = FacilityData.GetNextLevel(data.lv);
           
            //if (master.conductorLv > 0)
            //{
            //    conditions.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "FACILITY_ENHANCE_CONDITION", LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, FacilityIconController.CONDUCTOR_RANK), master.conductorLv);
            //    if (conductorLv >= master.conductorLv)
            //    {
            //        achieved.gameObject.SetActive(true);
            //    }
            //}
            //else
            //{
            //    achieved.gameObject.SetActive(false);
            //    conditions.SetLabel(LocalizeManager.DATA_TYPE.COMMON, "FACILITY_ENHANCE_NOCONDITION");
            //}
        }

        /// <summary>
        /// テキストのリセット
        /// </summary>
        void ResetText()
        {
            achieved.gameObject.SetActive(false);
            //getConfirm.ResetText();
        }

        string GetText(int first, int second, bool isTime = false)
        {
            if (isTime)
            {
                return string.Format( LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "FACILITY_ENHANCE_AMOUNTTIME"), first, second);
            }
            return string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "FACILITY_ENHANCE_AMOUNT"), first, second);
        }

        /// <summary>
        /// 施設強化ダイアログ表示
        /// </summary>
        /// <param name="data">施設情報</param>
        /// <param name="coin">所持資金</param>
        //public void OnClickOpen(FacilityData data, int coin)
        //{
        //    uiCamera.depth = 10;
           // conductorLv = UserData.GetPlayerData().level;
            //this.data = data;

            //if (IsChange(coin))
            //{
            //    isPopUp = true;
                //getConfirm.Set(data.label, getItem, get, FacilityData.GetNextLevel(data.lv).money);
        //        SetDialog();
        //        bg.gameObject.SetActive(true);
        //    }
        //    else
        //    {
        //        notStrengthen.Set(data, coin);
        //        notStrengthen.gameObject.SetActive(true);
        //    }
        //    this.gameObject.SetActive(true);
        //}

        public void OnClickDecision()
        {
            uiCamera.depth = 1;
            isPopUp = false;
            ResetText();
            bg.gameObject.SetActive(false);
            this.gameObject.SetActive(false);
            isStart = true;
        }
        
        public void ResetStart()
        {
            isStart = false;
        }


        public void OnClickClose()
        {
            uiCamera.depth = 1;
            isPopUp = false;
            ResetText();
            bg.gameObject.SetActive(false);
            this.gameObject.SetActive(false);
        }

        public void OnClickCloseNot()
        {
            uiCamera.depth = 1;
            notStrengthen.gameObject.SetActive(false);
            notStrengthen.ResetText();
            this.gameObject.SetActive(false);
        }
    }
}