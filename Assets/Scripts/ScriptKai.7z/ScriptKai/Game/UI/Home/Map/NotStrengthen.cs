﻿using System.Text;
using UnityEngine;
using UnityEngine.UI;

using TMPro;
using Game.Ui;

namespace Map
{
    public class NotStrengthen : MonoBehaviour
    {
        [SerializeField] TextMeshProUGUI cause;
        [SerializeField] TextMeshProUGUI level;
        [SerializeField] TextMeshProUGUI amountNum;
        [SerializeField] TextMeshProUGUI limitNum;
        [SerializeField] TextMeshProUGUI[] coins;
        [SerializeField] TextMeshProUGUI useTime;
        [SerializeField] TextMeshProUGUI conditions;
        [SerializeField] TextMeshProUGUI achieved;
        
        public enum NOT_TYPE
        {
            COIN,
            LEVEL,
            BOTH,
        }
        
        string content;

        public void Type(NOT_TYPE type)
        {
            var conductorRank = LocalizeManager.GetCommonText(FacilityIconController.CONDUCTOR_RANK);
            if (type == NOT_TYPE.COIN)
            {
                content = LocalizeManager.GetCommonText("FACILITY_ENHANCE_NOMONEY");
            }
            else if (type == NOT_TYPE.LEVEL)
            {
                content = string.Format(LocalizeManager.GetCommonText("FACILITY_ENHANCE_NOLEVEL"), conductorRank);
            }
            else if (type == NOT_TYPE.BOTH)
            {
                content = string.Format(LocalizeManager.GetCommonText("FACILITY_ENHANCE_NOBOTH"), conductorRank);
            }
        }

       // public void Set(FacilityData data, int coin)
       // {
            //var master = FacilityData.GetNextLevel(data.lv);
            
            //cause.text = string.Format(LocalizeManager.GetCommonText("FACILITY_ENHANCE_FAIL"), content);

            //if (data.label == FacilityIconController.staminaLabel)
            //{
               // amountNum.text = GetText(GetTimeText(data.get), GetTimeText(master.stamina_get));
               // limitNum.text = GetText(data.limit, master.stamina_limit);

            //}
            //else if (data.label == FacilityIconController.coinLabel)
            //{
               // amountNum.text = GetText(GetTimeText(data.get), GetTimeText(master.coin_get));
                //limitNum.text = GetText(data.limit, master.coin_limit);
          //  }
           //level.text = GetText(data.lv, master.lv);

           // coins[0].text = coin.ToString();
           // var limitCoin = coin - master.money;
          //  coins[1].text = limitCoin.ToString();

           // int hours = 60;
            //if (master.time < hours)
            //{
            //    useTime.text = string.Format(LocalizeManager.GetCommonText("COMMON_TIME_MIN"), master.time);
            //}
            //else
            //{
            //    int hour = master.time / hours;
            //    int minute = master.time % hours;
            //    if (minute <= 0)
            //        useTime.text = string.Format(LocalizeManager.GetCommonText("COMMON_TIME_HOUR"), hour);
            //    else
            //        useTime.text = string.Format(LocalizeManager.GetCommonText("COMMON_TIME_HOURMIN"), hour, minute);
            //}
       // }
        
        string GetTimeText(int num)
        {
            return string.Format(LocalizeManager.GetCommonText("FACILITY_ENHANCE_LABEL_SPEED"), num);
        }

        string GetText(int before, int after)
        {
            return GetText(before.ToString(), after.ToString());
        }

        string GetText(string before, string after)
        {
            return string.Format("{0}　→　<color=#00a0dc>{1}</color>", before, after);
        }

        public void ConductorLvSet(int nextLv, bool isExceed)
        {
            conditions.text = string.Format(LocalizeManager.GetCommonText("FACILITY_ENHANCE_CONDITION"), LocalizeManager.GetCommonText(FacilityIconController.CONDUCTOR_RANK), nextLv);
            if (isExceed)
            {
                achieved.text = LocalizeManager.GetCommonText("FACILITY_ENHANCE_CONDITIONEXCEED");
            }
            else
            {
                achieved.text = LocalizeManager.GetCommonText("FACILITY_ENHANCE_CONDITIONNOEXCEED");
            }
            achieved.gameObject.SetActive(true);
        }


        public void Nothing()
        {
            if (achieved.gameObject.activeSelf)
            {
                achieved.gameObject.SetActive(false);
            }
            conditions.text = LocalizeManager.GetCommonText("FACILITY_ENHANCE_NOCONDITION");
        }
        
        public void ResetText()
        {
            achieved.gameObject.SetActive(false);
        }
    }
}