﻿using System;
using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using Base.Util;

using Game.Ui;


namespace Map
{
    public class FacilityIcon : MonoBehaviour
    {
        [SerializeField] Camera uiCamera, mainCamera;
        [SerializeField] Image icon;
        [SerializeField] Image typeIcon;
        [SerializeField] TMPro.TextMeshProUGUI getText;
        [SerializeField] Image maxIcon;
        [SerializeField] Image limitOver;
        [SerializeField] Image goChange;
        [SerializeField] Image countDown;
        [SerializeField] Text count;
        [SerializeField] Text facilityLevel;
        [SerializeField] Image unionSkillEffect;
        [SerializeField] Text unionskillEffectContent;
        [SerializeField] Text collectNum;
        
        /// <summary>レベル上げの終了時間</summary>
        public DateTime levelUpTime { get; private set; }
        /// <summary>レベル上げの状態保持</summary>
        public enum STATE
        {
            /// <summary>レベル上げをしていない</summary>
            NORMAL,
            /// <summary>レベル上げ中</summary>
            LEVEL_UP,
            /// <summary>レベル上げ終了</summary>
            FINISH,
            /// <summary>レベルMax(上限達成)</summary>
            MAX_LEVEL,
        }
        public STATE state { get; private set; }

        bool isSame;
        bool isMove;
        bool isStart = false;
        float waitTime = 0.0f;
        float alpha = 1.0f;
        float colorA;
       
        Vector2 pos2D;
        Transform target;
        
        DateTime finishTime = new DateTime();
        TimeSpan progressTime;
        Vector3 pos;

        RectTransform rectTransform;
        //public FacilityData data { get; private set; }
        //UnionSkillData unionSkillData;
        //UnionSkillEffectMaster unionSkillEffectMaster;
        int unionSkillLevel;
        int nowCollect;
        bool isRestart = false;
        double totalSeconds;

        readonly float timeSplit = 60;

        //public void Init(Transform target, FacilityData data, Vector3 pos, Sprite sprite)
        //{
            //unionSkillData = Union.UnionSkillMoveInformation.GetUnionSkill(UnionConstants.UnionSkillCategory.Facility);
            //if (unionSkillData != null && unionSkillData.IsProgress() && data != null)
            //{
            //    unionSkillEffect.gameObject.SetActive(true);
            //    var unionSkillMaster = UnionSkillMaster.Get(unionSkillData.id);
            //    var masterList = MasterData.GetInstance().unionSkillEffectMaster;
            //    if (unionSkillMaster != null) {
            //        int skillId = data.name == "Room_Food production building" ? unionSkillMaster.skillEffectIdList[1] : unionSkillMaster.skillEffectIdList[0];
            //        unionSkillEffectMaster = masterList.ContainsKey(skillId) ? masterList[skillId] : null;
            //    }
            //    if (unionSkillEffectMaster != null) {
            //        var skillName = Game.Ui.LocalizeManager.GetText(Game.Ui.LocalizeManager.DATA_TYPE.UNION_SKILL_EFFECT, unionSkillEffectMaster.content);
            //        unionSkillLevel = unionSkillData.level - 1;
            //        if (unionSkillLevel < 0)
            //            unionSkillLevel = 0;
            //        else if (unionSkillLevel >= unionSkillEffectMaster.percents.Count)
            //            unionSkillLevel = unionSkillEffectMaster.percents.Count - 1;
            //        unionskillEffectContent.text = string.Format("{0} +{1}%", skillName, unionSkillEffectMaster.percents[unionSkillLevel]);
            //    }
            //}
        //    isSame = false;
        //    isMove = false;
        //    this.data = data;
        //    this.target = target;
        //    this.pos = pos;
        //    typeIcon.sprite = sprite;
        //    typeIcon.SetNativeSize();

        //    if (data.startTime < 0)
        //    {
        //        data.startTime = 0;
        //    }
        //    if (data.levelUpTime < 0)
        //    {
        //        data.levelUpTime = 0;
        //    }
        //    levelUpTime = TimeUtil.GetDateTime(data.levelUpTime);
        //    finishTime = TimeUtil.GetDateTime(data.startTime);
        //    totalSeconds = (DateTime.Now.AddHours(data.collectTime) - DateTime.Now).TotalSeconds;

        //    if (data.startTime == 0)
        //    {
        //        progressTime = TimeSpan.Zero;
        //        RestartCollect();
        //    }

        //    getText.gameObject.SetActive(false);
        //    maxIcon.gameObject.SetActive(false);
            
        //    ///レベルアップしていない時
        //    if (data.levelUpTime == 0)
        //    {
        //        state = STATE.NORMAL;
        //    }
        //    ///レベルアップしている or 終わっているとき
        //    else 
        //    {
        //        state = STATE.LEVEL_UP;
        //    }
        //    ///レベルがマックスの時
        //    if (data.lv >= data.lvMax)
        //    {
        //        state = STATE.MAX_LEVEL;
        //    }

        //    facilityLevel.text = string.Format(LocalizeManager.GetCommonText("FACILITY_LV"), data.lv);

        //    rectTransform = GetComponent<RectTransform>();

        //    isStart = true;
        //}

        // Update is called once per frame
        public void LateUpdatePosition()
        {
            if (isStart)
            {
                Vector3 point = mainCamera.WorldToViewportPoint(target.position);
                Vector3 uiPos = uiCamera.ViewportToWorldPoint(point);
                uiPos.z = 0;
                this.transform.position = uiPos + pos;
            }
        }

        /// <summary>
        /// 強化にかかる残り時間
        /// </summary>
        /// <returns>終了したか</returns>
        public bool CountDown()
        {
            if (state == STATE.LEVEL_UP)
            {
                TimeSpan timeSpan = levelUpTime - DateTime.Now;
                count.text = string.Format(LocalizeManager.GetCommonText("FACILITY_ENHANCE_COUNTDOWN"), timeSpan.Hours, timeSpan.Minutes, timeSpan.Seconds);
                if (!countDown.gameObject.activeSelf)
                {
                    countDown.gameObject.SetActive(true);
                }
            }
            return DateTime.Now >= levelUpTime;
        }
        
        /// <summary>
        /// コイン・スタミナの獲得経過時間加算
        /// </summary>
        public void Addition()
        {
            if (!isSame)
            {
                progressTime = finishTime - DateTime.Now;
            }
           // var getNum = GetItem();
            //if (getNum < data.limit && DateTime.Now < finishTime)
            //{
            //    if (nowCollect < (int)getNum || isRestart)
            //    {
            //        nowCollect = (int)getNum;
            //        collectNum.text = nowCollect.ToString();

            //        if (isRestart)
            //            isRestart = false;
            //    }
            //    if (getNum >= 1 && !icon.gameObject.activeSelf)
            //    {
            //        icon.gameObject.SetActive(true);
            //    }
            //    ///最大ではないのに表示されていた場合
            //    if (maxIcon.gameObject.activeSelf)
            //        maxIcon.gameObject.SetActive(false);
            //}
            //else
            //{
            //    if (isSame) return;
            //    progressTime = TimeSpan.Zero;
            //    nowCollect = (int)getNum;
            //    collectNum.text = nowCollect.ToString();

            //    ///獲得の吹き出しが出ていなかったら表示する
            //    if (!icon.gameObject.activeSelf)
            //        icon.gameObject.SetActive(true);

            //    maxIcon.gameObject.SetActive(true);
            //    isSame = true;
            //}
        }

        /// <summary>
        /// コイン・スタミナを取得したときの処理
        /// </summary>
        //public float GetItem()
        //{
            /**
             * 1時間の獲得量 / 60分(1時間) = 1分間の獲得量
             * 1分間の獲得量 / 60秒(1分) = 1秒間の獲得量
             * 1秒間の獲得量 * 経過時間(秒) = 獲得量
             * 渡す量(int) = 獲得量(float) + 前回の 余った量(float)
             * 獲得量(float) - 渡す量(int) = 余った量(float)
             */
             
           // float m = data.get / timeSplit;
          //  float s = m / timeSplit;
           // float get = s * (float)(totalSeconds - progressTime.TotalSeconds - data.stockpileTotalSeconds);
            //float give = get + data.rest + data.levelUpRest;
            //if (unionSkillData != null && unionSkillData.IsProgress())
            //{
            //    if (unionSkillEffectMaster != null)
            //    {
            //        give += give * (unionSkillEffectMaster.percents[unionSkillLevel] / 100f);
            //    }
            //}
            //if (give > data.limit)
            //    give = data.limit;
            //if (data.stockpileNum < give)
            //{
            //    data.stockpileNum = give;
            //}
            //return data.stockpileNum;
      //  }

        public void SetRest(float get, float give)
        {
            //data.rest = get - give;

            //if (data.levelUpRest > 0)
            //    data.levelUpRest = 0;
            //if (data.stockpileTotalSeconds > 0)
            //    data.stockpileTotalSeconds = 0;
        }

        /// <summary>
        /// アイテムを回収した後に再スタート
        /// </summary>
        public void RestartCollect()
        {
   //         finishTime = DateTime.Now.AddHours(data.collectTime);
            
   //         data.startTime = GetUnixTime(finishTime);

			//data.SetDirty();

            isSame = false;
            isRestart = true;
            icon.gameObject.SetActive(false);
        }

        /// <summary>
        /// コイン・スタミナを取得したときの取得数Textのアニメーション
        /// </summary>
        /// <param name="value">取得数</param>
        /// <returns></returns>
        public IEnumerator Animation(int value)
        {
            if (isMove) yield break;
            isMove = true;

            int moveY = 15;
            colorA = alpha;
            maxIcon.gameObject.SetActive(false);
            var pos = getText.transform.localPosition;
            getText.text = new StringBuilder().Append('+').Append(value).ToString();
            getText.gameObject.SetActive(true);

            var menuPos = getText.transform.localPosition;
            var target = new Vector3(menuPos.x, menuPos.y + moveY, menuPos.z);
            yield return new WaitUntil(() => IsMoved(target));

            isMove = false;
            getText.transform.localPosition = new Vector3(menuPos.x, menuPos.y);
            getText.gameObject.SetActive(false);
            getText.color = new Color(0, 0, 0, alpha);

            if (isSame)
                isSame = false;
        }

        bool IsMoved(Vector3 target)
        {
            float speed = 10.0f;
            float minusSpeed = 0.08f;
            colorA -= minusSpeed;
            if (colorA < 0)
            {
                colorA = 0;
            }
            getText.color = new Color(0, 0, 0, colorA);
            var pos = getText.transform.localPosition;
            getText.transform.localPosition = Vector2.MoveTowards(pos, target, speed * Time.deltaTime);
            
            return (int)Vector2.Distance(pos, target) <= 0;
        }

        /// <summary>
        /// レベルアップ開始処理
        /// </summary>
        public void StartLevelUp()
        {
            //levelUpTime = DateTime.Now.AddMinutes(FacilityData.GetNextLevel(data.lv).time);
          //  data.levelUpTime = GetUnixTime(levelUpTime);
            state = STATE.LEVEL_UP;
			//data.SetDirty();
            FacilityIconController.FacilitySave();
        }

        /// <summary>
        /// レベルアップ終了処理
        /// </summary>
        public void Finish()
        {
            state = STATE.FINISH;
            countDown.gameObject.SetActive(false);
            SetGoChange(true);
        }
        

        public void LevelUp()
        {
            if (state != STATE.FINISH) return;
            //var time = data.collectTime;
            //data = FacilityData.LevelUp(data);
            //facilityLevel.text = string.Format(Game.Ui.LocalizeManager.GetCommonText("COMMON_LVFORMAT"), data.lv);

            levelUpTime = new DateTime();
            //data.levelUpTime = 0;

            //var limit = data.limit - data.stockpileNum;
            //var m = data.get / timeSplit;
            //var s = m / timeSplit;
            //var total = limit / s;

            //finishTime = DateTime.Now.AddSeconds(total);
            //totalSeconds = (DateTime.Now.AddHours(data.collectTime) - DateTime.Now).TotalSeconds;
            //data.startTime = GetUnixTime(finishTime);

            /////レベルが上がるまでの通算時間と備蓄数を取得
            //data.stockpileTotalSeconds = totalSeconds - total;
            //data.levelUpRest = data.stockpileNum;
            
            //data.SetDirty();
            isSame = false;

            //if (data.label == FacilityIconController.staminaLabel)
            //    UserData.GetPlayerData().MissionData.SetCountByPlayerData(Mission.MissionSceneConstants.MissionDetails.FoodProductionLevel);
            //else if (data.label == FacilityIconController.coinLabel)
            //    UserData.GetPlayerData().MissionData.SetCountByPlayerData(Mission.MissionSceneConstants.MissionDetails.BankLevel);

            FacilityIconController.FacilitySave();
        }

        /// <summary>
        /// レベルアップ終了確認処理
        /// </summary>
        /// <param name="isActive"></param>
        public void ConfirmLevelUp(bool isActive)
        {
            //if (data.lv < data.lvMax)
            //{
            //    state = STATE.NORMAL;
            //    SetGoChange(isActive);
            //}
            //else
            //{
            //    state = STATE.MAX_LEVEL;
            //    goChange.gameObject.SetActive(false);
            //}
        }


        /// <summary>
        /// レベル上げ可能・レベル上げ終了の視認用アイコン表示
        /// </summary>
        /// <param name="isActive">表示するか</param>
        public void SetGoChange(bool isActive)
        {
            ///レベルアップ中とレベル最大値の時は施設確認アイコンを出さない
            if (state == STATE.LEVEL_UP || state == STATE.MAX_LEVEL)
            {
                goChange.gameObject.SetActive(false);
                return;
            }
            ///レベルアップが終わっていて確認していないときは必ず表示されるようにする
            else if(state == STATE.FINISH)
            {
                goChange.gameObject.SetActive(true);
                return;
            }
            goChange.gameObject.SetActive(isActive);
        }

        /// <summary>
        /// コイン・スタミナが取得できない時の処理
        /// </summary>
        /// <returns></returns>
        public IEnumerator Over()
        {
            float colorA = alpha;
            float goOut = 0.2f;
            float wait = 1.5f;
            limitOver.gameObject.SetActive(true);
            yield return new WaitForSeconds(wait);

            while (colorA > 0)
            {
                colorA -= goOut;
                limitOver.color = new Color(1, 1, 1, colorA);
                yield return new WaitForSeconds(waitTime);
            }

            limitOver.gameObject.SetActive(false);
            limitOver.color = new Color(1, 1, 1, alpha);
        }

        long GetUnixTime(DateTime dateTime)
        {
            return TimeUtil.GetUnixTime(dateTime);
        }
    }
}