﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Base.Util;
using Game.Sound;


namespace Map
{
    public class FacilityIconController : MonoBehaviour
    {
        [SerializeField] FacilityIcon facilityIcon;
        [SerializeField] StrengthenFacility strengthenFacility;
        [SerializeField] StrengthenDialog strengthenDialog;
        [SerializeField] Sprite[] typeSprite;
        
        int coinMax;
        int staminaMax;
        
        public const string staminaLabel = "advRoom[45]";
        public const string coinLabel = "advRoom[47]";

        public readonly static string CONDUCTOR_RANK = "COMMON_CONDUCTERRANK";


        public enum FACILITY_TYPE
        {
            STAMINA,
            COIN,
        }

        FacilityIcon lvUpFacility;
        List<FacilityIcon> facilities;
        Vector3[] iconPos = { new Vector3(23, 125), new Vector3(23, 100) };

        Player player;

        public void Init(Room[] rooms, GameObject player)
        {
            //coinMax = UserData.GetPlayerData().coinMax;
          //  staminaMax = UserData.GetPlayerData().staminaMax;

           // List<FacilityData> facilityDatas = UserData.GetPlayerData().facilities;
            facilities = new List<FacilityIcon>();

            foreach (Transform child in facilityIcon.transform.parent)
            {
                if (!child.gameObject.activeSelf) continue;
                Destroy(child.gameObject);
            }
            //int myCoin = UserData.GetPlayerData().coin;
            //foreach(var data in facilityDatas)
            //{
            //    if (!data.isOpen)
            //    {
            //        facilities.Add(null);
            //        continue;
            //    }
            //    var facility = Utility.CreateGameObject<FacilityIcon>(facilityIcon.gameObject, facilityIcon.transform.parent);
            //    facility.gameObject.SetActive(true);
            //    int id = data.id - 1;
            //    facility.Init(rooms[id].transform, data, iconPos[id], typeSprite[id]);

            //    //var isActive = strengthenFacility.IsGoChange(data, myCoin);
            //    //facility.SetGoChange(isActive);

            //    facilities.Add(facility);
            //}

            this.player = player.GetComponent<Player>();

            foreach (var icon in facilities)
            {
                if (icon == null) continue;
                icon.gameObject.SetActive(false);
            }
        }

        public void StartSavings()
        {
            //int myCoin = UserData.GetPlayerData().coin;
            for (int i = 0; i < facilities.Count; i++)
            {
                var icon = facilities[i];
                if (icon == null) continue;
                //var isActive = strengthenFacility.IsGoChange(icon.data, myCoin);
               // icon.SetGoChange(isActive);
            }
        }

        public void UpdateTime()
        {
            if (facilities == null) return;

            ///強化中の処理
            Strengthenining();
            MovePlayer();
            ///生産施設の強化中の残り時間カウントダウン
            for (int i = 0; i < facilities.Count; i++)
            {
                if (facilities[i] == null) continue;
                
                facilities[i].Addition();

                if (facilities[i].state == FacilityIcon.STATE.LEVEL_UP)
                {
                    if (!facilities[i].CountDown()) continue;

                    ///終わった瞬間に強化していた情報を削除
                    facilities[i].Finish();
                }
            }
        }

        public void LateUpdatePosition()
        {
            if (facilities == null) return;
            if (MapManager.GetNowPlayingConductType() != MapConstants.MAP_CONDUCT_TYPE.HOME) return;
            for (int i = 0; i < facilities.Count; i++)
            {
                if (facilities[i] == null) continue;
                facilities[i].LateUpdatePosition();
            }
        }

        /// <summary>
        /// タクトが歩いているときは吹き出しを消す
        /// </summary>
        void MovePlayer()
        {
            if (player.IsNowMove())
            {
                for (int i = 0; i < facilities.Count; i++)
                {
                    if (facilities[i] == null) continue;
                    facilities[i].gameObject.SetActive(false);
                }
            }
            else
            {
                for (int i = 0; i < facilities.Count; i++)
                {
                    if (facilities[i] == null) continue;
                    if (facilities[i].gameObject.activeSelf) continue;
                    facilities[i].gameObject.SetActive(true);
                }
            }

        }


        void Strengthenining()
        {
            if (strengthenFacility.isStart)
            {
                lvUpFacility.StartLevelUp();
                StartLevelUp();
                strengthenFacility.ResetStart();
            }
        }


        void StartLevelUp()
        {
           // int myCoin = UserData.GetPlayerData().coin;
            //int useMoney = FacilityData.GetNextLevel(lvUpFacility.data.lv).money;
            //myCoin -= useMoney;
            //UserData.GetPlayerData().coin = myCoin;

            for (int i = 0; i < facilities.Count; i++)
            {
                if (facilities[i] == null) continue;
                //var isActive = strengthenFacility.IsGoChange(facilities[i].data, myCoin);
                //facilities[i].SetGoChange(isActive);
            }
           // UserData.GetPlayerData().MissionData.AddCount(Mission.MissionSceneConstants.MissionDetails.CoinConsumption, useMoney);
        }
        

        /// <summary>
        /// 生産施設のアイテム入手の吹き出しをタップしたときの
        /// 該当アイテム所持数加算処理
        /// </summary>
        /// <param name="icon"></param>
        public void OnClickGet(FacilityIcon icon)
        {
           // if (!GetIsReadTutorial(icon.data.label)) return;
           // var playerData = UserData.GetPlayerData();
            //int myCoin = playerData.coin;
           // int myStamina = playerData.stamina;
            bool isOver = false;
            bool isNone = false;
            ///もらう数
          //  float get = icon.GetItem();
            ///反映される数
           // int give = (int)get;
            //if (facilities[(int)FACILITY_TYPE.STAMINA] != null && icon.data.label == facilities[(int)FACILITY_TYPE.STAMINA].data.label)
            //{
            //    //int result = myStamina + give;
                //if (result >= staminaMax)
                //{
                //    isOver = true;
                //    give = staminaMax - myStamina;
                //    if (give <= 0)
                //        isNone = true;
                //}
                //if (!isNone)
                //{
                //    SoundPlayer.PlaySe(SoundConstants.SE_EAT);
                //    icon.data.stockpileNum -= give;
                //    icon.RestartCollect();
                //    icon.SetRest(get, give);
                    ///スタミナ獲得
                   // myStamina += give;
                   // playerData.stamina = myStamina;
                    //playerData.MissionData.AddCount(Mission.MissionSceneConstants.MissionDetails.CollectFoodForProduction, 1);
            //    }
            //}
            //else if (facilities[(int)FACILITY_TYPE.COIN] != null && icon.data.label == facilities[(int)FACILITY_TYPE.COIN].data.label)
            //{
                //int result = myCoin + give;
                //if (result >= coinMax)
                //{
                //    isOver = true;
                //   // give = coinMax - myCoin;
                //    if (give <= 0)
                //        isNone = true;
                //}
               // if (!isNone)
                //{
                //    SoundPlayer.PlaySe(SoundConstants.SE_COIN);
                //    icon.data.stockpileNum -= give;
                //    icon.RestartCollect();
                //    icon.SetRest(get, give);
                    //myCoin += give;
                    //UserData.GetPlayerData().coin = myCoin;
                    //Game.Common.PlayerStatus.SetDirty();
                   // playerData.MissionData.AddCount(Mission.MissionSceneConstants.MissionDetails.CollectCoinForBank, 1);
            //    }
            //}
            if (!isOver)
            {
                //icon.data.stockpileNum = 0;
            }

            var scene = MapSceneManager.Instance.CurrentScene;
            if (isNone)
            {
                scene.StartCoroutine(icon.Over());
                return;
            }
           // var isActive = strengthenFacility.IsGoChange(icon.data, myCoin);
            //icon.SetGoChange(isActive);
            //scene.StartCoroutine(icon.Animation(give));
            FacilitySave();
        }

        public void OpenDialog(Room room)
        {
          //  var read = UserData.GetPlayerData().TutorialReadIds;
          //  if (!read.Contains((int)Tutorial.TutorialController.SerialId.Home_FunctionRelease_0)) return;

            //foreach (var data in UserData.GetPlayerData().facilities)
            //{
            //    if (data.isOpen) continue;
            //    if (data.label != room.label) continue;
            //    if (!GetIsReadTutorial(data.label)) return;
            //}

            //int myCoin = UserData.GetPlayerData().coin;
            //int myStamina = UserData.GetPlayerData().stamina;
            FacilityIcon icon = null;
            for (int i = 0; i < facilities.Count; i++)
            {
                if (facilities[i] == null) continue;
               // if (room.label != facilities[i].data.label) continue;
                icon = facilities[i];
            }
            if (icon == null) return;
            
            lvUpFacility = icon;
            ///強化されていない
            if (icon.state == FacilityIcon.STATE.NORMAL)
            {
                //strengthenFacility.OnClickOpen(icon.data, myCoin);
            }
            ///強化中
            else if(icon.state == FacilityIcon.STATE.LEVEL_UP)
            {
               // strengthenDialog.OnClickStrengthening(icon.data);
            }
            ///強化終了時
            else if (icon.state == FacilityIcon.STATE.FINISH)
            {
                SoundPlayer.PlaySe(SoundConstants.SE_RANKUP);
                strengthenDialog.endAction = () =>
                {
                    //int nowCoin = UserData.GetPlayerData().coin;
                    icon.LevelUp();
                    //var isActive = strengthenFacility.IsGoChange(icon.data, nowCoin);
                    //icon.ConfirmLevelUp(isActive);
                };
                //strengthenDialog.OnClickFinish(icon.data);
            }
            ///施設が最大レベル
            else if (icon.state == FacilityIcon.STATE.MAX_LEVEL)
            {
               // strengthenDialog.OnClickLevelMax(icon.data);
            }
        }

        int GetItem(int item, int myItem, int max, int useMoney = 0)
        {
            int get = 0;
            
            ///残りの持てる数
            int limit = max - (myItem - useMoney);
            if (limit < 0)
            {
                limit = 0;
            }
            ///獲得数より持てる数か多かったら
            if (limit >= item)
            {
                get = item;
            }
            ///持てる数より獲得数が多かったら
            else
            {
                get = limit;
            }
            return get;
        }

        bool GetIsReadTutorial(string label)
        {
            //var read = UserData.GetPlayerData().TutorialReadIds;
    //        if (label == staminaLabel &&
    //            !read.Contains((int)Tutorial.TutorialController.SerialId.Home_Reserved_0))
    //        {
				////var tutorialScene = (TutorialHomeScene)SceneController.GetBaseScene(BaseScene.GetSceneName<TutorialHomeScene>());
				////if (tutorialScene != null) { tutorialScene.SetViewPlayablePanel(false); }

				//var musicalHall = MapSceneManager.Instance.CurrentScene.transform.Find("Map/Map/Symphonica/Objects/MusicalHall").GetComponent<Room>();
				//musicalHall.IsClickOff = false;

				////MapSceneManager.Instance.CurrentScene.StartCoroutine(StartTutorial(label));
    //            return false;
    //        }
    //        else if(label == coinLabel &&
    //            !read.Contains((int)Tutorial.TutorialController.SerialId.Home_FunctionRelease_Bank))
    //        {
				////var tutorialScene = (TutorialHomeScene)SceneController.GetBaseScene(BaseScene.GetSceneName<TutorialHomeScene>());
				////if (tutorialScene != null) { tutorialScene.SetViewPlayablePanel(false); }

				////MapSceneManager.Instance.CurrentScene.StartCoroutine(StartTutorial(label));
    //            return false;
    //        }
            return true;
        }

   //     IEnumerator StartTutorial(string label)
   //     {
			//if (label == staminaLabel)
			//	yield return TutorialHomeScene.StartTutorial(Tutorial.TutorialController.SerialId.Home_Reserved_0);
			//else if (label == coinLabel)
			//	yield return TutorialHomeScene.StartTutorial(Tutorial.TutorialController.SerialId.Home_FunctionRelease_Bank);
   //     }

        public static void FacilitySave()
        {
            //MapSceneManager.Instance.CurrentScene.StartCoroutine(Game.Core.Io.PlayerStorageProvider.Save());
        }
    }
}