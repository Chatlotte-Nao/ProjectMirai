﻿using System.Text;
using UnityEngine;
using UnityEngine.UI;

using TMPro;
using Game.Ui;

namespace Map
{
    public class StrengthenDialog : MonoBehaviour
    {
        [SerializeField] TextMeshProUGUI[] title;
        [SerializeField] TextMeshProUGUI strengthenName;
        [SerializeField] TextMeshProUGUI finishName;
        [SerializeField] TextMeshProUGUI maxName;
        [SerializeField] TextMeshProUGUI level;
        [SerializeField] TextMeshProUGUI amountNum;
        [SerializeField] TextMeshProUGUI limitNum;
        [SerializeField] Button okButton;
        [SerializeField] Button cancelButton;

        [SerializeField] GameObject[] texts;
        [SerializeField] Camera uiCamera;

       // FacilityData data;

        readonly string staminaLabel = FacilityIconController.staminaLabel;
        readonly string coinLabel = FacilityIconController.coinLabel;

        public UnityEngine.Events.UnityAction endAction = null;

        void SetStrengthening()
        {
            title[0].gameObject.SetActive(true);
            texts[0].gameObject.SetActive(true);
            //var master = FacilityData.GetNextLevel(data.lv);
            //if (master == null) return;
            //strengthenName.text = string.Format(LocalizeManager.GetCommonText("FACILITY_ENHANCE_ONGOING_LABEL"), LocalizeManager.GetText(LocalizeManager.DATA_TYPE.ROOM_NAME, data.name));
            //level.text = GetText( data.lv, master.lv);

            //if (data.label == staminaLabel)
            //{
            //    amountNum.text = GetText(GetTimeText(data.get), GetTimeText(master.stamina_get));
            //    limitNum.text = GetText(data.limit, master.stamina_limit);

            //}
            //else if (data.label == coinLabel)
            //{
            //    amountNum.text = GetText(GetTimeText(data.get), GetTimeText(master.coin_get));
            //    limitNum.text = GetText(data.limit, master.coin_limit);
            //}
        }

        void SetFinish()
        {
            title[1].gameObject.SetActive(true);
            texts[1].gameObject.SetActive(true);
            //var master = FacilityMaster.Get(data.lv + 1);
            //if (master == null) return;
           // finishName.text = string.Format(LocalizeManager.GetCommonText("FACILITY_ENHANCE_FINISH_LABEL"), LocalizeManager.GetText(LocalizeManager.DATA_TYPE.ROOM_NAME, data.name));
            //level.text = GetText(data.lv, master.lv);

          //  if (data.label == staminaLabel)
           // {
               // amountNum.text = GetText(GetTimeText(data.get), GetTimeText(master.stamina_get));
               // limitNum.text = GetText(data.limit, master.stamina_limit);

           // }
           // else if (data.label == coinLabel)
           // {
               // amountNum.text = GetText(GetTimeText(data.get), GetTimeText(master.coin_get));
               // limitNum.text = GetText(data.limit, master.coin_limit);
           // }
        }
        
        void SetMax()
        {
            title[2].gameObject.SetActive(true);
            texts[2].gameObject.SetActive(true);
           // maxName.text = string.Format(LocalizeManager.GetCommonText("FACILITY_ENHANCE_MAX_LABEL"), LocalizeManager.GetText(LocalizeManager.DATA_TYPE.ROOM_NAME, data.name));

            //level.text = data.lv.ToString();
            //amountNum.text = GetTimeText(data.get);
            //limitNum.text = data.limit.ToString();
        }
        
        /// <summary>
        /// 強化中ダイアログ
        /// </summary>
        /// <param name="data"></param>
        //public void OnClickStrengthening(FacilityData data)
        //{
        //    uiCamera.depth = 10;
        //    this.data = data;
        //    SetStrengthening();
        //    SetDisplayButton();
        //    this.gameObject.SetActive(true);
        //}

        /// <summary>
        /// 強化終了ダイアログ
        /// </summary>
        /// <param name="data"></param>
        //public void OnClickFinish(FacilityData data)
        //{
        //    uiCamera.depth = 10;
        //    this.data = data;
        //    SetFinish();
        //    SetDisplayButton();
        //    this.gameObject.SetActive(true);
        //}

        /// <summary>
        /// 施設レベル最大ダイアログ
        /// </summary>
        /// <param name="data"></param>
        //public void OnClickLevelMax(FacilityData data)
        //{
        //    uiCamera.depth = 10;
        //    this.data = data;
        //    SetMax();
        //    SetDisplayButton();
        //    this.gameObject.SetActive(true);
        //}

        void SetDisplayButton(bool ok = true, bool cancel = false)
        {
            if (okButton.gameObject.activeSelf != ok)
                okButton.gameObject.SetActive(ok);
            if (cancelButton.gameObject.activeSelf != cancel)
                cancelButton.gameObject.SetActive(cancel);
        }

        string GetTimeText(int num)
        {
            return string.Format("{0}/h", num);
        }

        string GetText(int before, int after)
        {
            return GetText(before.ToString(), after.ToString());
        }

        string GetText(string before, string after)
        {
            return string.Format("{0}　→　<color=#00a0dc>{1}</color>", before, after);
        }

        public void OnClickClose()
        {
            if (endAction != null)
            {
                endAction.Invoke();
                endAction = null;
            }

            uiCamera.depth = 1;

            for(int i = 0; i < title.Length; i++)
            {
                title[i].gameObject.SetActive(false);
            }

            for(int i = 0; i < texts.Length; i++)
            {
                texts[i].gameObject.SetActive(false);
            }

            this.gameObject.SetActive(false);
        }
    }
}