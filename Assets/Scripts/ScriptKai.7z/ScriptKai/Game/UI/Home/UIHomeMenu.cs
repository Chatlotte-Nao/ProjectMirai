﻿
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using CriWare;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Takasho.Schema.Score.ResourceCn.Chapter.V1;
using UnityEngine.Events;
using DG.Tweening;
using Spine.Unity;
using UnityEngine.UI;
 
public class UIHomeMenu : UIDialogBase
{
    [SerializeField] UserIcon userIcon;
    [SerializeField] RankIcon leftRank;
    [SerializeField] UIText playerName;
    [SerializeField] UIButton profileButton;

    [SerializeField] UIButton storyButton;
    [SerializeField] UIButton freebattleButton;


    [SerializeField] UIButton characterButton;
    [SerializeField] UIButton equipmentButton;
    [SerializeField] UIButton shopButton;
    [SerializeField] UIButton gachaButton;
    [SerializeField] UIButton exploreButton;


    [SerializeField] UIButton informationButton;
    [SerializeField] UIButton presentboxButton;
    [SerializeField] UIButton missionButton;
    [SerializeField] UIButton inventoryButton;
    [SerializeField] UIButton dailyQuestButton;
    [SerializeField] UIButton MailButton;
    [SerializeField] UIButton QuestionnaireButton;

    [SerializeField] private UIText questionnaireText;


    //map
    [SerializeField] UIButton mapButton;
    [SerializeField] UIButton wingButton;
    [SerializeField] UIButton rightButton;
    [SerializeField] UIButton leftButton;
    
    [SerializeField]  HomeMenuMuta muta;
    [SerializeField] RectTransform rightObj;
    [SerializeField] RectTransform leftObj;
    [SerializeField] private CharacterTouchHandler touchCharacter;
    
    //red
    [SerializeField] private GameObject redMissionObject;
    public UnityEvent OnClickMap => mapButton.OnTouchUpInside;
    public UIStrEvent OnClickGotoMap = new UIStrEvent();
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        Log.Info("init home");
        profileButton.onClick.GuardSubscribeAsync(OnClickProfile).AddTo(mSubscriptions);
        storyButton.OnTouchUpInside.GuardSubscribeAsync(onClickStory).AddTo(mSubscriptions);
        freebattleButton.OnTouchUpInside.GuardSubscribeAsync(onClickBattle).AddTo(mSubscriptions);
        characterButton.OnTouchUpInside.GuardSubscribeAsync(onClickCharacter).AddTo(mSubscriptions);
        gachaButton.OnTouchUpInside.GuardSubscribeAsync(onClickGacha).AddTo(mSubscriptions);
        inventoryButton.OnTouchUpInside.GuardSubscribeAsync(onClickInventory).AddTo(mSubscriptions);
        equipmentButton.OnTouchUpInside.GuardSubscribeAsync(onClickEquipment).AddTo(mSubscriptions);
        exploreButton.OnTouchUpInside.GuardSubscribeAsync(onClickExplore).AddTo(mSubscriptions);
        dailyQuestButton.OnTouchUpInside.GuardSubscribeAsync(onClickDailyQuest).AddTo(mSubscriptions);

        MailButton.OnTouchUpInside.GuardSubscribeAsync(onClickMail).AddTo(mSubscriptions);
        missionButton.OnTouchUpInside.GuardSubscribeAsync(onClickMission).AddTo(mSubscriptions);

        informationButton.OnTouchUpInside.SubscribeAsync(OnClickInfomation).AddTo(mSubscriptions);

        QuestionnaireButton.OnTouchUpInside.GuardSubscribeAsync(OnClickQuestionnaire).AddTo(mSubscriptions);
        wingButton.OnTouchUpInside.GuardSubscribeAsync(onClickWing).AddTo(mSubscriptions);
        
        muta._tabToggle.onValueChanged.Subscribe(MutaToggle).AddTo(mSubscriptions);
        rightButton.OnTouchUpInside.GuardSubscribeAsync(OnClickRightButtom).AddTo(mSubscriptions);
        leftButton.OnTouchUpInside.GuardSubscribeAsync(OnClickLeft).AddTo(mSubscriptions);
        shopButton.OnTouchUpInside.GuardSubscribeAsync(OnClickShop).AddTo(mSubscriptions);
        
        SignalBus.GlobalSignal.Subscribe(UIEventId.UIHeaderInfoUpdate, RefreshInfo).AddTo(mSubscriptions);
        await touchCharacter.Init(false,3f,0);
        
        RefreshInfo();
        RefreshRedInfo();
    }
    private void RefreshInfo()
    {
        
        playerName.SetRawText(DataManager.Instance.Player.Player.GetData().Name);
        // playerName.SetRawText();

        long remainExp = DataManager.Instance.Player.Player.GetRemainExp();
        int lv = DataManager.Instance.Player.Player.GetLevel();

        var fill = 0f;
        if (DataManager.Instance.Master.PlayerLevel.ContainsKey(lv + 1))
        {
            fill = (float)remainExp / DataManager.Instance.Master.PlayerLevel[lv + 1].exp;
        }
    
        leftRank.Set(lv, fill);
        
        //userIcon.Setup(DataManager.Instance.Player.Player.GetData().ProfileIconFrame, DataManager.Instance.Player.Player.GetData().ProfileIconId);

    }

    //TODO 临时任务红点判断 后期做红点功能时可删
    private void RefreshRedInfo()
    {
        bool isLock = false;
        if (DataManager.Instance.Master.FunctionUnlock[8].requirePlayerLevel > DataManager.Instance.Player.Player.GetLevel())
        {
            isLock = true;
        }
        var stageId = DataManager.Instance.Master.FunctionUnlock[8].requireStageId;
        if (stageId > 0 && !StoryUtil.IsClear(stageId))
        {
            isLock = true;
        }
        redMissionObject.SetActive(!isLock);
    }

    private bool fristIn;
    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await touchCharacter.RefreshChara();
        await base.ShowAsync(showType);
        await SetUpQuestionnaireAsync();
    }
    

    public override void OnShow()
    {
        base.OnShow();
        //
        // if (!DataManager.Instance.Local.UserInfo.showNotice && !TutorialManager.Instance.IsRunningFunctionTutorial &&  DataManager.Instance.Player.Chapter.TryGet(2) != null)
        // {
        //     DataManager.Instance.Local.UserInfo.showNotice = true;
        //     AsyncManager.Instance.StartAsync(OnClickInfomation());
        // }
    }

    private async UniTask SetUpQuestionnaireAsync()
    {
        await QuestionnaireService.GetQuestionnairesAsync();
        if (DataManager.Instance.Player.Questionnaire.IsHaveQuestionnaire())
        {
            QuestionnaireButton.gameObject.SetActive(true);
            questionnaireText.SetRawText(DataManager.Instance.Player.Questionnaire.GetList().Count.ToString());
        }
        else
        {
            QuestionnaireButton.gameObject.SetActive(false);
        }
    }

    void MutaToggle(bool isOn)
    {
        if (isOn)
        {
            muta.Open();
        }
        else
        {
            muta.Close();
        }
    }
    

    private async UniTask onClickStory()
    {
        UIHomeScenarioSelectPage.PageParam p = new UIHomeScenarioSelectPage.PageParam();
        p.showType = UIHomeScenarioSelectPage.PageParam.ShowType.Chapter;
        await UI.Page.OpenPage<UIHomeScenarioSelectPage>(p);
    }

    private async UniTask onClickBattle()
    {
        var master = DataManager.Instance.Master.MemoryQuest.Values.First(m => m.chapter == 1 && m.requireChapterMasterId > 0);
        var playerChapter = DataManager.Instance.Player.Chapter.TryGet(master.requireChapterMasterId);
        if (playerChapter == null || playerChapter.Status != Status.Clear)
        {
            var chapter = DataManager.Instance.Master.Chapter[master.requireChapterMasterId];
            var name = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{master.requireChapterMasterId}_name");
            string str = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MEMORY_QUEST, "MEMORY_QUEST_OPEN"), new object[] { chapter.chapter, name });
            await UI.Popup.ShowPopupMessageAsync(str);
        }
        else
        {
            await MemoryQuestService.GetDataAsync();
            UIMqScenarioSelectPageParam p = new UIMqScenarioSelectPageParam();
            p.showType = UIMqScenarioSelectPageParam.ShowType.Chapter;
            await UI.Page.OpenPage<UIMqScenarioSelectPage>(p);
        }

    }
    private async UniTask onClickWing()
    {
        Hide();
        gotoMap("advBuilding[7]");
    }

    private void gotoMap(string label)
    {
        OnClickGotoMap.Invoke(label);
    }
    private async UniTask onClickInventory()
    {
        await UI.Page.OpenPage<UIInventoryPage>();
       // gotoRoom("advRoom[51]");
    }

    private async UniTask onClickCharacter()
    {
        await UI.Page.OpenPage<UIHomeCharacterMainPage>();
    }

    private async UniTask onClickGacha()
    {
        var param = await GachaService.GetGachaList();
        await UI.Page.OpenPage<UIGachaMainPage>(param);
    }

    private async UniTask onClickEquipment()
    {
        await UI.Page.OpenPage<UIHomeEquipmentListPage>();
    }

    private async UniTask onClickExplore()
    {
        await ExploreService.RequestExploreData();
        GameSceneManager.Instance.ChangeScene<ExploreScene>("ExploreScene");
    }

    // ReSharper disable Unity.PerformanceAnalysis
    private async UniTask onClickDailyQuest()
    {
        // await DailyQuestService.GetAvailable();
        // await DailyQuestService.GetToday();
        // await UI.Page.OpenPage<UIHomeDailyQuestMainPage>();
        gotoRoom("advRoom[41]");
    }

    private async UniTask onClickMail()
    {
        await MailService.GetMailsAsync();
        await UI.Page.OpenPage<UIHomeMailPage>();
    }

    private async UniTask OnClickQuestionnaire()
    {
        var url = DataManager.Instance.Player.Questionnaire.TryGetFirst();
        await UI.Page.OpenPage<UIQuestionnairePage>(url);
    }

    private async UniTask onClickMission()
    {
        gotoRoom("advRoom[39]");
        // await MissionService.RequestMissionData();
        // await UI.Page.OpenPage<UIMissionPage>();
    }

    private async UniTask OnClickShop()
    {
        gotoRoom("advRoom[52]");
        // await ExploreService.RequestExploreData();
        // await UI.Page.OpenPage<UIShopPage>();
    }

    private async UniTask OnClickInfomation()
    {
        
#if !UNITY_EDITOR
        var _webViewDialog = (UIWebViewDialog) await UI.Dialog.CreateAsync(UIPrefabId.UIWebAnnouncementDialog, CanvasType.System);
        
        _webViewDialog.OnBack.Subscribe(_=>{
            _webViewDialog.Dispose();
            _webViewDialog = null;
        });

        var platform = "";
#if UNITY_ANDROID
        platform = "android";
#elif UNITY_IOS
        platform = "ios";
#endif
        var affcode = LCXHandler.Instance.AffCode;
        var realmid = DataManager.Instance.Local.UserInfo.currentServer.id;

        var url = DataManager.Instance.Local.UserInfo.announcementUrl+$"?platform={platform}&affcode={affcode}&realmid={realmid}";

        await _webViewDialog.SetupAsync(url);
        await _webViewDialog.ShowAsync();
#endif
    }
    bool isSmallRight = false;

    private async UniTask OnClickRightButtom()
    {
        isSmallRight = !isSmallRight;
        var xValue = isSmallRight ? 350 : 0;
        var zValue = isSmallRight ? 180 : 0;
        DOTween.To(() => rightObj.anchoredPosition, x => rightObj.anchoredPosition = x, new Vector2(xValue, 0), 0.3f);
        rightButton.transform.localRotation = new Quaternion(0, 0, zValue, 0);
    }

    private bool isSmallLeft = false;

    private async UniTask OnClickLeft()
    {
        isSmallLeft = !isSmallLeft;
        var yValue = isSmallLeft ? 226 : 0;
        var zValue = isSmallLeft ? 180 : 0;
        DOTween.To(() => leftObj.anchoredPosition, y => leftObj.anchoredPosition = y, new Vector2(0, yValue), 0.3f);
        leftButton.transform.localRotation = new Quaternion(0, 0, zValue, 0);
    }

    private async UniTask OnClickProfile(GameObject o)
    {
        await UI.Page.OpenPage<UIHomeProfilePage>();
    }

    public override void Dispose()
    {
        touchCharacter?.Dispose();
        muta?.Dispose();
        base.Dispose();
    }
    private void gotoRoom(string room)
    {
        OnSelectTarget.Invoke(room);
    }
    public UIStrEvent OnSelectTarget = new UIStrEvent();
}
