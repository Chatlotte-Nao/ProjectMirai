﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Game.Ui
{
	/// <summary>
	/// 指定箇所のリソースを自動でローカライズ後の物に変更する
	/// </summary>
	public class AutoLocalizeResource : MonoBehaviour
	{
		[SerializeField] SpriteRenderer spriteRenderer;
		[SerializeField] Image image;

		bool isSet = false;
		string loadDataName = string.Empty;

		//Inspectorの歯車アイコンにSetFontDataNameという項目を追加、押すと下のメソッドが実行される
		[ContextMenu("SetFontDataName")]
		public void SetComponentLink()
		{
			if (spriteRenderer != null || image != null)
			{
				return;
			}

			if (spriteRenderer == null)
			{
				spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
			}
			if (spriteRenderer != null)
			{
				return;
			}

			if (image == null)
			{
				image = gameObject.GetComponent<Image>();
			}
			if (image != null)
			{
				return;
			}
			Debug.LogWarning("AutoLocalizeResource.csを付けたコンポーネントですが、切り替え対象となるリソースを扱っていません！　name:" + gameObject.name);
		}

		private void Reset()
		{
			SetComponentLink();
		}

		void Awake()
		{
			SetData();
		}

		private void OnEnable()
		{
			SetData();
		}

		/// <summary>
		/// 
		/// </summary>
		public void SetData()
		{
			if (isSet)
				return;

			isSet = true;
			loadDataName = GetLoadDataName();

			if (LocalizeManager.GetLanguageType().Equals("ja"))
				return;

			var sceneName = (gameObject.scene != null) ? gameObject.scene.name : string.Empty;
			if (spriteRenderer != null)
			{
				spriteRenderer.enabled = false;
				//読み込みを行い、読み込み終わったら設定
				LocalizeResourceManager.SetLocalizeResource<Sprite>(sceneName, loadDataName, sprite =>
				{
					//※読み込み中にこれが着いたオブジェクトが解放されるかもしれないので、その時用処理
					if (this == null)
						return;
					if (gameObject == null)
						return;

					spriteRenderer.enabled = true;
					if (sprite == null)
						return;
					spriteRenderer.sprite = sprite;
				});
			}
			else if (image != null)
			{
				image.enabled = false;
				//読み込みを行い、読み込み終わったら設定
				LocalizeResourceManager.SetLocalizeResource<Sprite>(sceneName, loadDataName, sprite =>
				{
					//※読み込み中にこれが着いたオブジェクトが解放されるかもしれないので、その時用処理
					if (this == null)
						return;
					if (gameObject == null)
						return;

					image.enabled = true;
					if (sprite == null)
						return;
					image.sprite = sprite;
				});
			}
		}

		/// <summary>
		/// 読み込むデータ名を取得
		/// </summary>
		/// <returns></returns>
		public string GetLoadDataName()
		{
			if (spriteRenderer != null)
			{
				return spriteRenderer.sprite?.name;
			}
			if (image != null)
			{
				return image.sprite?.name;
			}
			return string.Empty;
		}

		/// <summary>
		/// すでにデータ設定を行った状態かどうか
		/// </summary>
		public bool IsSet()
		{
			return isSet;
		}

		public LocalizeResourceManager.DataType GetDataType()
		{
			//ToDo:今のところSpriteのみ
			return LocalizeResourceManager.DataType.Sprite;
		}
	}
}
