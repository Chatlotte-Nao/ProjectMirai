﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIHomeMainPage : UIPageBase
{
    // UIHomeBg mHomeBg = null;
    UIHomeMenu mHomeMenu = null;
    // UIWorldMapDialog mMapDialog = null;



    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);

        // mHomeBg = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeBg, CanvasType.BG) as UIHomeBg;

        mHomeMenu = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeMenuWindow, CanvasType.App0) as UIHomeMenu;
        // mMapDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIWorldMapDialog, CanvasType.App2) as UIWorldMapDialog;

        // mHomeMenu.OnClickMap.GuardSubscribeAsync(onClickMap).AddTo(mSubscriptions);
        mHomeMenu.OnClickGotoMap.GuardSubscribeAsync(onClickBgLocation).AddTo(mSubscriptions);
        
        // mHomeBg.OnClickMap.GuardSubscribeAsync(onClickBgLocation).AddTo(mSubscriptions);
        mHomeMenu.OnSelectTarget.GuardSubscribeAsync(onSelectMapTarget).AddTo(mSubscriptions);
        
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);

        

        //check tutorial
        
        //check login bonus
        // await mHomeBg.ShowAsync(showType);
        await mHomeMenu.ShowAsync(showType);
        ClientEvent clientEvent = ClientEventUtil.ClientHallInto();
        LCXHandler.Instance.ReportEvent(clientEvent.event_id, clientEvent.payload);
        // SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, UIHomeHeaderParam.Default);
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHeaderHide);

        TutorialManager.Instance.CheckTriggerStart(TutorialManager.FunctionTutorialTriggerType.BackToTop);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        
        await mHomeMenu.HideAsync(showType);
        // MapSceneManager.Instance.HideCurrent();

    }

    public override void Dispose()
    {
        // if (mHomeBg != null)
        // {
        //     mHomeBg.Dispose();
        //     mHomeBg = null;
        // }
        if (mHomeMenu != null)
        {
            mHomeMenu.Dispose();
            mHomeMenu = null;
        }
        // if (mMapDialog != null)
        // {
        //     mMapDialog.Dispose();
        //     mMapDialog = null;
        // }

        base.Dispose();
    }

    private async UniTask onClickBgLocation(string label)
    {
        await ExploreService.RequestExploreData();
        await changeSubPage(label, null);
    }


    private async UniTask onSelectMapTarget(string roomName)
    {
        await ExploreService.RequestExploreData();
        await changeMapTarget(roomName);
    }

    private async UniTask changeSubPage(string map, string room)
    {
        // await UI.ScreenEffect.Fade(1);
        //UI.Loading.Show();
        // await UniTask.DelayFrame(2);
        // await UniTask.Delay(3000);
        await UI.Page.ChangePage<UIHomeSubPage>();
        var mapData = DataManager.Instance.Master.Location[map];
        
        if (string.IsNullOrEmpty(room))
        {
            await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home, mapData.startPos);
        }
        else
        {
            await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home, room);
        }

      

        DataManager.Instance.Local.UserInfo.currentHomeMap = map;
        DataManager.Instance.Local.UserInfo.currentHomeRoom = room;


        // await UI.ScreenEffect.Fade(0);
        // await UI.Loading.EndValue();
        // UI.Loading.Hide();

    }
    private async UniTask changeMapTarget(string room)
    {
        //await UI.ScreenEffect.Fade(1);
        var advMapMaster = DataManager.Instance.Master.AdvMap[room];
        var mapData = DataManager.Instance.Master.Location[advMapMaster.map_label];

        if (string.IsNullOrEmpty(advMapMaster.startPos))
        {
            await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home, mapData.startPos);
        }
        else
        {
            await MapSceneManager.Instance.ShowAsync(mapData.scene, null, null, MapSceneManager.SceneType.Home, advMapMaster.startPos);
        }

        DataManager.Instance.Local.UserInfo.currentHomeMap = advMapMaster.map_label;
        
        MapSceneManager.Instance.CurrentScene.MovePlayerToRoom(room);
        DataManager.Instance.Local.UserInfo.currentHomeRoom = room;
        await UI.Page.ChangePage<UIHomeSubPage>();
        MapSceneManager.Instance.CurrentScene.GetCameraController().SetFollowMode(true);
        MapSceneManager.Instance.CurrentScene.GetCameraController().SetEnabledDraggableCamera(false);

    }

}