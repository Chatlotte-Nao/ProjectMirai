using System;
using System.Collections;
using System.Collections.Generic;
using Adventure.Command;
using Adventure.Controller;
using Cysharp.Threading.Tasks;
using Game.ScriptEngine;
using Pheonix.Core;
using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.UI;


public class KanBanChara : MonoBehaviour
{
    [SerializeField] RawImage standImage;
    
    /// <summary>
    /// SpineアニメーションBody再生コマンド
    /// </summary>
    public CommandPlaySpineAnimationBody PlaySpineAnimationBody;
    
    /// <summary>
    /// SpineアニメーションFace再生コマンド
    /// </summary>
    public CommandPlaySpineAnimationFace PlaySpineAnimationFace;
    
    [SerializeField] UIButton charaInteractionButton;
    private SkeletonAnimation skeletonAnimation;
    private ScenarioScript s;
    UIRTCamera mRTCamera = null;
    GameObject rtCameraObj;

    private bool isInit = true;


    private List<string> faceCommandList = new List<string>(){"Destiny", "運命_真顔", "FALSE", "True"};
    private List<string> faceCommandList2 = new List<string>(){"Destiny", "運命_喜（小）", "FALSE", "True"};
    private List<string> bodyCommandList = new List<string>(){"Destiny", "運命_通常_両手上げ", "FALSE", "True"};
    async void Start()
    {
        PlaySpineAnimationBody ??= new CommandPlaySpineAnimationBody();
        PlaySpineAnimationFace ??= new CommandPlaySpineAnimationFace();
        
        charaInteractionButton.onClick.AddListener(Interaction);
        rtCameraObj = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/RTCamera");
        mRTCamera = rtCameraObj.GetComponent<UIRTCamera>();
        if (isInit)
        {
            await SetKanbanMusume();
        }
        isInit = false;
    }

    async void OnEnable()
    {
        if (!isInit)
        {
            await SetKanbanMusume();
        }
    }


    void Interaction(GameObject o)
    {
        Debug.Log("interaction");
        SetAnimation(skeletonAnimation, 1, "運命_通常_両手上げ", false, 1);
    }

    
    async UniTask SetKanbanMusume()
    {
        
        //TODO 获取看板娘id
        var charaID = DataManager.Instance.Player.Player.GetData().ProfileIconId;
        
        var resourceMaster = DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[charaID].characterResourceId];
        var loadCharacter = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/chara/" + resourceMaster.advModelId);
        skeletonAnimation = loadCharacter.GetComponent<SkeletonAnimation>();
        skeletonAnimation.Initialize(false);
        skeletonAnimation.Update(0.0f);
        skeletonAnimation.LateUpdate();
        mRTCamera.Setup(loadCharacter);
        standImage.texture = mRTCamera.GetRenderTexture();
    }

    
    protected TrackEntry SetAnimation(SkeletonAnimation skeletonAnimation, int trackIndex, string animationName, bool loop, float timeScale=1)
    {
        TrackEntry trackEntry = null;
        Spine.Animation animation = skeletonAnimation.skeleton.Data.FindAnimation(animationName);
        if (animation == null)
        {
            Debug.LogWarning("Animation not found: " + animationName);
        }
        else
        {
            trackEntry = skeletonAnimation.AnimationState.SetAnimation(trackIndex, animationName, loop);
            trackEntry.TimeScale = timeScale;
        }
        return trackEntry;
    }



    private void OnDestroy()
    {
        charaInteractionButton.onClick.RemoveAllListeners();
        if (mRTCamera != null)
        {
            mRTCamera.Dispose();
            mRTCamera = null;
        }
        Destroy(rtCameraObj);
        s = null;
        PlaySpineAnimationBody = null;
        PlaySpineAnimationFace = null;
    }
}
