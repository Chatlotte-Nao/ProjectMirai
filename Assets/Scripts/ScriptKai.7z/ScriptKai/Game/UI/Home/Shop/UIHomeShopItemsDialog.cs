﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class UIHomeShopItemsDialog : UIDialogBase
{
   
    [Space]
    //itemBig
    [SerializeField] private GameObject tableGameObject;
    [SerializeField] private RectTransform itemRectTransform;
    [SerializeField] private UIShopItem shopItemPrefab;
    [SerializeField] private RectTransform scrollView;
    [SerializeField] private RectTransform content;
    private List<UIShopItem> bigShopItems = new List<UIShopItem>();
    public UIIntEvent OnItemBuyClick = new UIIntEvent();
    public async UniTask SetUpAsync(int categoryId)
    {
        itemRectTransform.gameObject.SetActive(false);
       
        if (content)
        {
            content.localPosition = Vector3.zero;
        }   
        var categoryMaster = DataManager.Instance.Master.ShopCategoryMaster[categoryId];
        var categorys = DataManager.Instance.Master.ShopCategoryMaster
            .Where(a => a.Value.shopMasterId == categoryMaster.shopMasterId).ToArray();
        tableGameObject.SetActive(categorys.Length > 1);
        scrollView.sizeDelta = new Vector2(categorys.Length > 1?1235:1330,500);
        var shopProductMasters =  DataManager.Instance.Master.ShopProductMaster.Values.Where(a=>a.shopCategoryMasterId == categoryId && a.IsOpen).OrderByDescending(a=>a.sortId).ToArray();
        foreach (var info in bigShopItems)
        {
            info.OnClick.RemoveAllListeners();
            info.OnClick2.RemoveAllListeners();
        }
        int index = 0;
        foreach (var master in shopProductMasters)
        {
            if (!ShopUtil.isAccordFormer(master))
            {
                continue;
            }
            
            if (index < bigShopItems.Count)
            {
                 await bigShopItems[index].SetUpAsync(master);
                 bigShopItems[index].gameObject.SetActive(true);
                 bigShopItems[index].OnClick.Subscribe(_ => OnItemBuyClick.Invoke(master.id)).AddTo(mSubscriptions);
                 bigShopItems[index].OnClick2.Subscribe(_ => OnItemBuyClick.Invoke(master.id)).AddTo(mSubscriptions);
            }
            else
            {
                var cell = Instantiate(shopItemPrefab, itemRectTransform);
                await cell.SetUpAsync(master);
                cell.OnClick.Subscribe(_ => OnItemBuyClick.Invoke(master.id)).AddTo(mSubscriptions);
                cell.OnClick2.Subscribe(_ => OnItemBuyClick.Invoke(master.id)).AddTo(mSubscriptions);
                bigShopItems.Add(cell);
                cell.gameObject.SetActive(true);
            }
            index++;
        }

        if (index < bigShopItems.Count)
        {
            for (int i = index; i < bigShopItems.Count; i++)
            {
                bigShopItems[i].gameObject.SetActive(false);
            }
        }
        itemRectTransform.gameObject.SetActive(true);
    }
   

}
