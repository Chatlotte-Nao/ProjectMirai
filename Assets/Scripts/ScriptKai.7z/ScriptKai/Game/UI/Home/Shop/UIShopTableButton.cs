﻿using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;

public class UIShopTableButton : MonoBehaviour
{
    [SerializeField] private UIButton button;
    [SerializeField] private GameObject onObject;
    [SerializeField] private GameObject offObject;    
    [SerializeField] private UIText labelText;
    [SerializeField] private UIText label2Text;
    public ClickEvent OnClick => button.onClick;
    private int selectId_;
    public async UniTask SetUpAsync(ShopMaster shopMaster)
    {
        selectId_ = shopMaster.id;
        labelText.SetLabel( LocalizeManager.DATA_TYPE.SHOP,$"Shop_Title_{shopMaster.id}");
        label2Text.SetLabel( LocalizeManager.DATA_TYPE.SHOP,$"Shop_Title_{shopMaster.id}");
        onObject.SetActive(false);
        offObject.SetActive(true);
    }

    public async UniTask SetUpAsync(ShopCategoryMaster shopCategoryMaster)
    {
        selectId_ = shopCategoryMaster.id;
        labelText.SetLabel(LocalizeManager.DATA_TYPE.SHOP, $"Shop_Category_{shopCategoryMaster.id}");
        label2Text.SetLabel( LocalizeManager.DATA_TYPE.SHOP,$"Shop_Category_{shopCategoryMaster.id}");
        onObject.SetActive(false);
        offObject.SetActive(true);
    }

    public void SelectTableButton(int selectId)
    {
        onObject.SetActive(selectId_ == selectId);
        offObject.SetActive(selectId_ != selectId);
    }

}
