﻿using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class UIShopPage : UIPageBase
{

    private UIHomeShopMainDialog mHomeShopMainDialog = null;
    private UIHomeShopItemsDialog mUIHomeShopSmallDialog = null;
    private UIHomeShopItemsDialog mUIHomeShopBigDialog = null;
    private UIHomeShopBuyDialog mUIHomeShopBuyDialog = null;
    private UIHomeShopItemsDialog shopItemsDialog;
    private UIHomeHeaderParam headerParam;
    private int _initShopMasterId = 0;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        if (param != null)
            _initShopMasterId = (int) param;
        
        headerParam = new UIHomeHeaderParam()
        {
            visibleBack = true,
            visibleIcon = false,
            visiblePlayerStatus = false,
            visibleRightRank = false,
            visibleItem = true,
            visibleNavigation = true,
            visibleHome = true
        };
        mHomeShopMainDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeShopMainDialog, CanvasType.App0) as UIHomeShopMainDialog;
        mUIHomeShopSmallDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeShopSmallDialog, CanvasType.App0) as UIHomeShopItemsDialog;
        mUIHomeShopBigDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeShopBigDialog, CanvasType.App0) as UIHomeShopItemsDialog;
        mUIHomeShopBuyDialog =  await UI.Dialog.CreateAsync(UIPrefabId.UIHomeShopBuyDialog, CanvasType.App1) as UIHomeShopBuyDialog;
        
        mHomeShopMainDialog.OnSelectShopClick.GuardSubscribeAsync(SetSelectShopInfo).AddTo(mSubscriptions);
        mHomeShopMainDialog.OnShowShopItemClick.GuardSubscribeAsync(ShowShopItemDialog).AddTo(mSubscriptions);
        mHomeShopMainDialog.OnCloseClick.GuardSubscribeAsync(CloseClick).AddTo(mSubscriptions);
        
        mUIHomeShopBigDialog.OnItemBuyClick.GuardSubscribeAsync(ShowShopBuyDialog).AddTo(mSubscriptions);
        mUIHomeShopSmallDialog.OnItemBuyClick.GuardSubscribeAsync(ShowShopBuyDialog).AddTo(mSubscriptions);
        mUIHomeShopBuyDialog.OnBuyClcik.GuardSubscribeAsync(OnBuyClick).AddTo(mSubscriptions);
        
    }
    private List<int> shopMasterIds = new List<int>();
    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        _categotyId = -1;
        _shopMasterId = 0;
        shopMasterIds.Clear();
        var shopMasters = await ShopService.GetOpenShopShopMasters();
        if (shopMasters.Length <= 0)
        {
            return;
        }
        var masterId = _initShopMasterId;
        if (_initShopMasterId == 0)
        {
            masterId = shopMasters[0].id;
        }
        await ShopService.ShopGetShopProductsInfo(masterId);
        shopMasterIds.Add(masterId);
        await base.ShowAsync(showType);
        await mHomeShopMainDialog.SetUpAsync(shopMasters,_initShopMasterId);
        await mHomeShopMainDialog.ShowAsync(showType);
    }
    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await shopItemsDialog.HideAsync(showType);
        await mHomeShopMainDialog.HideAsync(showType);
    }
    public async UniTask CloseClick(GameObject o)
    {
        await UI.Page.CloseCurrentPage(true);
    }

    private int _shopMasterId = 0;
    private async UniTask SetSelectShopInfo(int shopMasterId)
    {
        if (_shopMasterId == shopMasterId)
            return;
        if (!shopMasterIds.Contains(shopMasterId))
        {
            await ShopService.ShopGetShopProductsInfo(shopMasterId);
            shopMasterIds.Add(shopMasterId);
            _categotyId = -1;
        }
        _shopMasterId = shopMasterId;
        await mHomeShopMainDialog.LoadTablesData(shopMasterId);
    }

    private int _categotyId;
    private async UniTask ShowShopItemDialog(int categotyId)
    {
        var consuneItemIds = ShopUtil.ConsuneItemIds(categotyId);
        headerParam.conuitemIds.Clear();
        headerParam.conuitemIds.AddRange(consuneItemIds);
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHomeHeaderUpdate, headerParam);
        if (_categotyId == categotyId)
            return;
        PxSoundManager.Instance.PlaySe("feedbackSE_interface_tab01");
        _categotyId = categotyId;
        mHomeShopMainDialog.SetSelectLable(categotyId);
        var categoryMastet = DataManager.Instance.Master.ShopCategoryMaster[categotyId];
        if (shopItemsDialog != null)
            await shopItemsDialog.HideAsync();
        switch (categoryMastet.UiType)
        {
            case 1:
                shopItemsDialog = mUIHomeShopBigDialog;
                break;
            case 2:
                shopItemsDialog = mUIHomeShopSmallDialog;
                break;
        }
        await shopItemsDialog.ShowAsync();
        await shopItemsDialog.SetUpAsync(categotyId);
        
    }

    private ShopProductMaster _productMaster;
    private async UniTask ShowShopBuyDialog(int productId)
    {
        var productMaster = DataManager.Instance.Master.ShopProductMaster[productId];
        await mUIHomeShopBuyDialog.SteUpAsync(productMaster);
        await mUIHomeShopBuyDialog.ShowAsync();
        _productMaster = productMaster;
    }

    private async UniTask OnBuyClick(int number)
    {
        if (ShopUtil.HaveItemCount(_productMaster.costId) < _productMaster.discountedPrice * number)
        {
            UI.Popup.ShowPopMessage( LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SHOP, "Shop_Product_Not_Enough"));
            return;
        }
        await mUIHomeShopBuyDialog.HideAsync();
        _categotyId = -1;
        await ShopService.ShopPurchase(_productMaster.id,number);
        await ShowShopItemDialog(_productMaster.shopCategoryMasterId);
        List<string> results = new List<string>();
        results.Add($"{_productMaster.contentId}:{_productMaster.contentAmount * number}");
        await UI.Popup.ShowItemGetPopupAsync(results);
       
        var categoryMaster = DataManager.Instance.Master.ShopCategoryMaster[_productMaster.shopCategoryMasterId];
        shopMasterIds.Remove(categoryMaster.shopMasterId);
        _shopMasterId = 0;
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHeaderInfoUpdate);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mHomeShopMainDialog != null)
        {
            mHomeShopMainDialog.Dispose();
            mHomeShopMainDialog = null;
        }

        if (mUIHomeShopBigDialog != null)
        {
            mUIHomeShopBigDialog.Dispose();
            mUIHomeShopBigDialog = null;
        }

        if (mUIHomeShopSmallDialog != null)
        {
            mUIHomeShopSmallDialog.Dispose();
            mUIHomeShopSmallDialog = null;
        }
        if (mUIHomeShopBuyDialog != null)
        {
            mUIHomeShopBuyDialog.Dispose();
            mUIHomeShopBuyDialog = null;
        }
    }
}
