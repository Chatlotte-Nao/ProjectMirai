﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;

public class UIHomeShopBuyDialog : UIDialogBase
{
    [SerializeField] BaseItem item;
    [SerializeField] UIText nameText;
    [SerializeField] private UIText numberText;
    [SerializeField] UIText itemDescText;

    [SerializeField] UIButton addButton;
    [SerializeField] UIButton removeButton;
    [SerializeField] UIButton minButton;
    [SerializeField] UIButton maxButton;
    [SerializeField] UIText buyNumText;

    [SerializeField] GameObject buyValueObject;
    [SerializeField] UIText conditionsText;
    [SerializeField] UIButton buyButton;
    [SerializeField] BaseItem consumeitem;
    [SerializeField] UIText originalPriceText;
    [SerializeField] UIText nowPriceText;
    [SerializeField] private GameObject discountObject;
    [SerializeField] private UIText discountText;
    [SerializeField] UIButton closeButton2;
    [SerializeField] private GameObject freeObject;
    ShopProductMaster _productMaster;

    public UIIntEvent OnBuyClcik = new UIIntEvent();
    private Color _color = new Color(252.0f / 255, 244.0f / 255, 182.0f / 255);
    private Color _redColor = new Color(243.0f / 255, 94.0f / 255, 101.0f / 255);
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        addButton.OnTouchUpInside.Subscribe(AddProduct).AddTo(mSubscriptions);
        removeButton.OnTouchUpInside.Subscribe(RemoveProduct).AddTo(mSubscriptions);
        minButton.OnTouchUpInside.Subscribe(MinProduct).AddTo(mSubscriptions);
        maxButton.OnTouchUpInside.Subscribe(MaxProduct).AddTo(mSubscriptions);
        closeButton2.onClick.Subscribe((o) => { onClickClose(o); }).AddTo(mSubscriptions);
        buyButton.onClick.Subscribe(_ => OnBuyClcik.Invoke(_selectNumber)).AddTo(mSubscriptions);
    }

    private int _selectNumber;
    private int _price;
    private int _maxValue;
    public async UniTask SteUpAsync(ShopProductMaster productMaster)
    {
        isStartTime = false;
        buyButton.gameObject.SetActive(false);
        _productMaster = productMaster;
        _selectNumber = 1;
        _price = _productMaster.discountedPrice;
        var purchaseLimit = _productMaster.purchaseLimit - DataManager.Instance.Player.Shop.GetPurchaseCount(productMaster.id);
        var haveValue = ShopUtil.HaveItemCount(_productMaster.costId);
        _maxValue = (int) Mathf.Min(haveValue,purchaseLimit * _productMaster.discountedPrice);
        if (productMaster.constrainType == 4)
        {
            _maxValue = (int)haveValue;
        }
        item.Setup(productMaster.contentId, "");
        nameText.SetLabel(LocalizeManager.DATA_TYPE.ITEM, $"{productMaster.contentId}_name");
        numberText.SetRawText($"x{productMaster.contentAmount}");
        numberText.gameObject.SetActive(productMaster.show);
        itemDescText.SetLabel(LocalizeManager.DATA_TYPE.ITEM, $"{productMaster.contentId}_desc");

        buyNumText.SetRawText(_selectNumber.ToString());
        consumeitem.Setup(productMaster.costId, "");
        // originalPriceText.gameObject.SetActive(productMaster.labeledPrice!=0 && productMaster.labeledPrice != productMaster.discountedPrice);
        originalPriceText.SetRawText(productMaster.labeledPrice.ToString());
        nowPriceText.SetRawText(productMaster.discountedPrice.ToString());
        nowPriceText.SetColor((ShopUtil.HaveItemCount(productMaster.costId) >= productMaster.discountedPrice) ? _color :_redColor);
        discountObject.SetActive(_productMaster.discount != string.Empty);
        discountText.SetFormat(LocalizeManager.DATA_TYPE.SHOP, "Shop_Discount", _productMaster.discount);
        
        freeObject.SetActive(productMaster.discountedPrice==0);
        consumeitem.gameObject.SetActive(productMaster.discountedPrice > 0);
        if (productMaster.discount == string.Empty || productMaster.labeledPrice == 0)
        {
            originalPriceText.SetRawText("");
        }
        nowPriceText.gameObject.SetActive(productMaster.discountedPrice > 0);
        if (ShopUtil.IsConstrain(productMaster.constrainType, productMaster.constrainValue, out var consterainStr))
        {
            conditionsText.gameObject.SetActive(true);
           
            buyButton.gameObject.SetActive(false);
            buyValueObject.SetActive(false);
            conditionsText.SetRawText(consterainStr);
        }
        else if (productMaster.constrainType!=4 && purchaseLimit <=0)
        {
            conditionsText.gameObject.SetActive(true);
            buyButton.gameObject.SetActive(false);
            buyValueObject.SetActive(false);
            conditionsText.SetLabel(LocalizeManager.DATA_TYPE.SHOP,"Shop_Buy_Not_Limit");
        }
        else
        {
            conditionsText.gameObject.SetActive(false);
            buyButton.gameObject.SetActive(true);
            buyValueObject.SetActive(productMaster.discountedPrice!=0);
        }
        if (productMaster.endTime != string.Empty)
        {
            var timeindex = ShopUtil.GetRemainingTime(DateTime.Parse(productMaster.endTime), out var timeType);
            if (timeType == 3)
            {
                timeIndex = (int)(DateTime.Parse(productMaster.endTime) - GlobalTime.Now).TotalSeconds;
                isStartTime = true;
            }
        }
          
        
    }

    private void AddProduct()
    {
        if ((_selectNumber+1) * _price > _maxValue || (_productMaster.constrainType !=4 &&_price ==0 && _selectNumber>= _productMaster.purchaseLimit))
        {
            var  str= LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SHOP, "Shop_Product_Max");
            UI.Popup.ShowPopMessage(str);
            return;
        }
        _selectNumber++;
        SetPriceData();
    }

    private void RemoveProduct()
    {
        _selectNumber--;
        if (_selectNumber < 1)
            _selectNumber = 1;
        SetPriceData();
    }

    private void MinProduct()
    {
        _selectNumber = 1;
        SetPriceData();
    }

    private void MaxProduct()
    {
        if ((_selectNumber+1) * _price > _maxValue || (_productMaster.constrainType !=4 &&_price ==0 && _selectNumber>= _productMaster.purchaseLimit))
        {
            var  str= LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SHOP, "Shop_Product_Max");
            UI.Popup.ShowPopMessage(str);
            return;
        }
        _selectNumber = _maxValue / _price;
        if (_price == 0)
        {
            _selectNumber = _productMaster.purchaseLimit;
        }

        if (_selectNumber < 1)
        {
            _selectNumber = 1;
        }

        SetPriceData();
    }

    private void SetPriceData()
    {
        buyNumText.SetRawText(_selectNumber.ToString());
        nowPriceText.SetColor(
            (ShopUtil.HaveItemCount(_productMaster.costId) >= _productMaster.discountedPrice * _selectNumber)
                ? _color : _redColor);
        originalPriceText.SetRawText((_productMaster.labeledPrice * _selectNumber).ToString());
        if (_productMaster.discount == string.Empty || _productMaster.labeledPrice == 0)
        {
            originalPriceText.SetRawText("");
        }
        nowPriceText.SetRawText((_productMaster.discountedPrice * _selectNumber).ToString());
    }
    
    private int timeIndex;
    private float time = 0;
    bool isStartTime = false;
    private void Update()
    {
        if (isStartTime)
        {
            time += Time.deltaTime;
            if (time > 1)
            {
                timeIndex--;
                time = 0;
                if (timeIndex <= 0)
                {
                    this.gameObject.SetActive(false);
                    isStartTime = false;
                }
            }
        }
    }
}