﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class UIHomeShopMainDialog : UIDialogBase
{
    [Space]
    [SerializeField] private UIButton backBtn;
    //title
    [SerializeField] private RectTransform titleRectTransform;
    [SerializeField] private UIShopTableButton titlePrefab;
    
    [Space]
    //table
    [SerializeField] private GameObject tableGameObject;
    [SerializeField] private RectTransform  tableRectTransform;
    [SerializeField] private UIShopTableButton tablePrefab;
    
    
    public ClickEvent OnCloseClick => backBtn.onClick;
    public UIIntEvent OnSelectShopClick = new UIIntEvent();

    public UIIntEvent OnShowShopItemClick = new UIIntEvent();
    
    private List<UIShopTableButton> titleButtons = new List<UIShopTableButton>();
    private List<UIShopTableButton> tableButtons = new List<UIShopTableButton>();

    public async UniTask SetUpAsync(ShopMaster[] shopMasters,int shopId = 0)
    {
        foreach (var info in titleButtons)
        {
            info.gameObject.SetActive(false);
            info.OnClick.RemoveAllListeners();
        }
        int index = 0;
        foreach (var shopMaster in shopMasters)
        {
            if (index < titleButtons.Count)
            {
                await titleButtons[index].SetUpAsync(shopMaster);
                titleButtons[index].gameObject.SetActive(true);
                titleButtons[index].OnClick.Subscribe(_ => OnSelectShopClick.Invoke(shopMaster.id)).AddTo(mSubscriptions);
            }
            else
            {
                var item = Instantiate(titlePrefab, titleRectTransform);
                await item.SetUpAsync(shopMaster);
                item.OnClick.Subscribe(_ => OnSelectShopClick.Invoke(shopMaster.id)).AddTo(mSubscriptions);
                titleButtons.Add(item);
                item.gameObject.SetActive(true);
            }
            index++;
        }

        var shopMasterId = shopId == 0 ? shopMasters[0].id : shopId;
        OnSelectShopClick.Invoke(shopMasterId);
    }

    
    public async UniTask LoadTablesData(int shopMasterId)
    {
        foreach (var titleButton in titleButtons)
        {
            titleButton.SelectTableButton(shopMasterId);
        }
        foreach (var info in tableButtons)
        {
            info.gameObject.SetActive(false);
            info.OnClick.RemoveAllListeners();
        }
        var shopMasters = DataManager.Instance.Master.ShopCategoryMaster.Values.Where(a=>a.shopMasterId == shopMasterId).ToArray();
        if (shopMasters.Length > 1)
        {
            tableGameObject.gameObject.SetActive(true);
           
            for (int i = 0; i < shopMasters.Length; i++)
            {
                int index = i;
                if (i < tableButtons.Count)
                {
                    await tableButtons[i].SetUpAsync(shopMasters[i]);
                    tableButtons[i].OnClick.Subscribe(_ => OnShowShopItemClick.Invoke(shopMasters[index].id)).AddTo(mSubscriptions);
                    tableButtons[i].gameObject.SetActive(true);
                }
                else
                {
                    var item = Instantiate(tablePrefab, tableRectTransform);
                    await item.SetUpAsync(shopMasters[i]);
                    item.OnClick.Subscribe(_ => OnShowShopItemClick.Invoke(shopMasters[index].id)).AddTo(mSubscriptions);
                    item.gameObject.SetActive(true);
                    tableButtons.Add(item);
                }
            }
            OnShowShopItemClick.Invoke(shopMasters[0].id);
        }
        else if(shopMasters.Length == 1)
        {
            tableGameObject.gameObject.SetActive(false);
            OnShowShopItemClick.Invoke(shopMasters[0].id);
        }
    }

    public void SetSelectLable(int categotyId)
    {
        foreach (var tableButton in tableButtons)
        {
            tableButton.SelectTableButton(categotyId);
        }
    }


}
