﻿using System;
using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class UIShopItem : MonoBehaviour
{
    [SerializeField] private BaseItem item;

    [SerializeField] private UIText numberText;
    [SerializeField] private UIText nameText;
    [SerializeField] private UIText remainingText;
    [SerializeField] private UIText conditionsText;

    [SerializeField] private GameObject timeObject;
    [SerializeField] private UIText timeText;
    [SerializeField] private GameObject discountObject;
    [SerializeField] private UIText discountText;

    [SerializeField] private UIButton buyButton;
    [SerializeField] private UIButton itemButton;
    [SerializeField] private BaseItem consumeitem;
    [SerializeField] private UIText originalPriceText;
    [SerializeField] private UIText nowPriceText;
    [SerializeField] private GameObject freeObject;

    ShopProductMaster _master;
    public ClickEvent OnClick => buyButton.onClick;
    public ClickEvent OnClick2 => itemButton.onClick;

    private Color _color = new Color(252.0f / 255, 244.0f / 255, 182.0f / 255);
    private Color _redColor = new Color(243.0f / 255, 94.0f / 255, 101.0f / 255);
    public async UniTask SetUpAsync(ShopProductMaster productMaster)
    {
        buyButton.gameObject.SetActive(false);
        _master = productMaster;
        await item.SetupAsync(_master.contentId, string.Empty);
        numberText.SetRawText($"x{_master.contentAmount}");
        numberText.gameObject.SetActive(_master.show);
        nameText.SetLabel(LocalizeManager.DATA_TYPE.ITEM, $"{_master.contentId}_name");
        var str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SHOP, $"Shop_PurchaseLimit_{_master.purchaseCountLimitType}");
        var purchaseCount = DataManager.Instance.Player.Shop.GetPurchaseCount(productMaster.id);
        remainingText.SetRawText($"{str}{_master.purchaseLimit-purchaseCount}/{_master.purchaseLimit}");

       
        discountObject.SetActive(_master.discount != string.Empty);
        discountText.SetFormat(LocalizeManager.DATA_TYPE.SHOP, "Shop_Discount", _master.discount);
        //originalPriceText.gameObject.SetActive(_master.labeledPrice!=0 && _master.labeledPrice != _master.discountedPrice);
        originalPriceText.SetRawText(_master.labeledPrice.ToString());
        nowPriceText.SetRawText(_master.discountedPrice.ToString());
        nowPriceText.SetColor((ShopUtil.HaveItemCount(_master.costId) >= _master.discountedPrice) ? _color : _redColor);
        consumeitem.Setup(_master.costId, "");
             
        freeObject.SetActive(_master.discountedPrice==0);
        consumeitem.gameObject.SetActive(_master.discountedPrice > 0);
        if (_master.discount == string.Empty || productMaster.labeledPrice == 0)
        {
            originalPriceText.SetRawText("");
        }
        nowPriceText.gameObject.SetActive(_master.discountedPrice > 0);
        timeObject.SetActive(productMaster.endTime != string.Empty);
        if (ShopUtil.IsConstrain(_master.constrainType, _master.constrainValue, out var consterainStr))
        {
            conditionsText.gameObject.SetActive(true);
            conditionsText.SetRawText(consterainStr);
            buyButton.gameObject.SetActive(false);
        }
        else if(_master.constrainType!=4 && _master.purchaseLimit-purchaseCount <=0)
        {
            remainingText.SetRawText($"{str}<color=red>0</color>/{_master.purchaseLimit}");
            conditionsText.gameObject.SetActive(true);
            conditionsText.SetLabel(LocalizeManager.DATA_TYPE.SHOP,"Shop_Buy_Not_Limit");
        }
        else
        {
            conditionsText.gameObject.SetActive(false);
            buyButton.gameObject.SetActive(true);
        }
        remainingText.gameObject.SetActive(_master.constrainType != 4);
        isStartTime = false;
        if (productMaster.endTime != string.Empty)
        {
            endTime = GlobalTime.GetDateTime(DateTime.Parse(productMaster.endTime));
            var timeindex = CommonUtil.GetCountDownTime(endTime, out var timeType);
            timeText.SetFormat(LocalizeManager.DATA_TYPE.SHOP, $"Shop_Time_Term_{timeType}", timeindex);
            if (timeType == 3)
            {
                timeIndex = (int)(endTime - GlobalTime.Now).TotalSeconds;
                isStartTime = true;
            }
        }
    }
    private DateTime endTime;
    void UpdateTime()
    {
        var timeindex =  CommonUtil.GetCountDownTime( endTime,out var timeType);
        timeText.SetFormat(LocalizeManager.DATA_TYPE.SHOP, $"Shop_Time_Term_{timeType}", timeindex);
    }
    private int timeIndex;
    private float time = 0;
    bool isStartTime = false;
    private void Update()
    {
        if (isStartTime)
        {
            time += Time.fixedDeltaTime;
            if (time > 1)
            {
                timeIndex--;
                time = 0;
                UpdateTime();
                if (timeIndex <= 0)
                {
                    this.gameObject.SetActive(false);
                    isStartTime = false;
                }
            }
        }
    }
}