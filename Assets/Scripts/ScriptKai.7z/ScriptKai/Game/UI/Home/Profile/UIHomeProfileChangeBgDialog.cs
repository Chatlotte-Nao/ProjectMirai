﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;

public class UIHomeProfileChangeBgDialog : UIDialogBase
{
    public UnityEvent OnSuccess = new UnityEvent();
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }
}
