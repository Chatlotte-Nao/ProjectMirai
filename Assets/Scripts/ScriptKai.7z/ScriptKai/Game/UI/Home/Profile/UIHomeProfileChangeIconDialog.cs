﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Script.Game.UI.Common;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Cysharp.Threading.Tasks.Triggers;
using UnityEngine.Events;

public class UIHomeProfileChangeIconDialog : UIDialogBase
{
   
    //
    // [SerializeField] long selectedFrameId=-1;
    long selectedIconId=-1;


    public UIButton okButton;
    [SerializeField] private SelectableCharacterHead HeadItemBase;
    [SerializeField] private RectTransform headRectTransform;
    public UnityEvent OnSuccess = new UnityEvent();
    //[SerializeField] private UIToggleGroupController FrameContent;
    // [SerializeField] private SelectableCharacterHead FrameItemBase;
    List<SelectableCharacterHead> _heads = new List<SelectableCharacterHead>();
    [SerializeField] UIButton closeButton2;
    
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        okButton.onClick.GuardSubscribeAsync(OnClickOk).AddTo(mSubscriptions);
        closeButton2.onClick.GuardSubscribeAsync(onClickClose);
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        await SetUp();
    }

    private async UniTask SetUp()
    {
        var characterMasters = DataManager.Instance.Master.BattleCharacter.Values.Where(master => (master.characterTypeId == 1)).OrderBy(master => master.sortId);
        var chapterIndex = 0;
        foreach (var head in _heads)
        {
            head.gameObject.SetActive(false);
            head.OnClick.RemoveAllListeners();
        }
        foreach(var characterMaster in characterMasters)
        {
            if (DataManager.Instance.Player.Character.TryGet(characterMaster.id) == null) continue;
            
            var master = characterMaster;
            if (chapterIndex < _heads.Count)
            {
                await _heads[chapterIndex].SetupAsync(characterMaster.id);
                _heads[chapterIndex].OnClick.Subscribe(() => { SelectIconId(characterMaster.id); }).AddTo(mSubscriptions);
                if (characterMaster.id == DataManager.Instance.Player.Player.GetData().ProfileIconId)
                    _heads[chapterIndex].Select(true);
                _heads[chapterIndex].gameObject.SetActive(true);
            }
            else
            {
                var icon = Instantiate(HeadItemBase, headRectTransform, false);
                await icon.SetupAsync(characterMaster.id);
                icon.OnClick.Subscribe(() => { SelectIconId(characterMaster.id); }).AddTo(mSubscriptions);
                if (characterMaster.id == DataManager.Instance.Player.Player.GetData().ProfileIconId)
                    icon.Select(true);
                icon.gameObject.SetActive(true);
                _heads.Add(icon);
            }
            
            chapterIndex++;
        }
    }

    private void SelectIconId(long characterId)
    {
        foreach (var head in _heads)
        {
            head.Select(characterId == head.CharacterId);
        }

        selectedIconId = characterId;
    }

    private  async UniTask OnClickOk(GameObject arg0)
    {
        // if(selectedFrameId==-1) return;
        // if(selectedIconId==-1) return;
        
        
        await ProfileService.SetUserIcon(selectedIconId);
        OnSuccess.Invoke();
        await base.HideAsync();
    }

    private void SetFrameContent()
    {
        // var t=DataManager.Instance.Player.Player.Get
        
    }

    private void SetIconContent()
    {
    }


    
}
