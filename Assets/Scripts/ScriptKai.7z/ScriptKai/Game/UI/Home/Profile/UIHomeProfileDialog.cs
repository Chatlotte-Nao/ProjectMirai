﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using TMPro;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;

public class UIHomeProfileDialog : UIDialogBase
{
    [SerializeField] UIText nameText;
    [SerializeField] UIText idText;
    [SerializeField] UIText introText;
    //[SerializeField] UIText totalPowerText = null;
    [SerializeField] UIText unionNameText = null;
    
    // [SerializeField] RankIcon rankIcon = null;
    
    [SerializeField] UIText rankText = null;
    
    
    
    [SerializeField] TabToggle editButton = null;
	[SerializeField] GameObject[] editButtonObjects = null;
    [SerializeField] UIButton copyIdButton = null;
    [SerializeField] UIButton editNameButton = null;
    [SerializeField] UIButton editDescButton = null;
    [SerializeField] UIButton editIconButton = null;
    [SerializeField] UIButton editBgButton = null;
    [SerializeField] UIButton editminiCharaButton = null;
    [SerializeField] UIMiniScene miniScene = null;

    [SerializeField] private UIButton closeBtn;

    [SerializeField] private UIButton configBtn;
    [SerializeField] private UIButton signoffBtn;
    
    [SerializeField] private UserIcon _userIcon;

    [SerializeField] private Image characterImage;
    [SerializeField] private Image characterBg;
    public ClickEvent OnCloseClick => closeBtn.onClick;

    public ClickEvent OnEditName => editNameButton.onClick;
    public ClickEvent OnEditIntro => editDescButton.onClick;
    public ClickEvent OnEditIcon => editIconButton.onClick;
    public ClickEvent OnEditBg => editBgButton.onClick;
    public UnityEvent OnEditMiniSceneCharacter => editminiCharaButton.OnTouchUpInside;

    public UIIntEvent OnClickMiniSceneEmptySlot => miniScene.OnClickEmptySlot;
    public UIIntEvent OnClickMiniSceneCharacter => miniScene.OnClickCharacter;

    public ClickEvent OnConfige => configBtn.onClick;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        editButton.onValueChanged.Subscribe(OnClickEdit).AddTo(mSubscriptions);
        copyIdButton.onClickUp.Subscribe((o) => { OnClickCopy();}).AddTo(mSubscriptions);
        signoffBtn.OnTouchUpInside.Subscribe(OnClickSignOff).AddTo(mSubscriptions);
        OnClickEdit(true);
    }

    public async UniTask SetupSelfAsync()
    {
        nameText.SetRawText(DataManager.Instance.Player.Player.GetData().Name);
        idText.SetRawText(DataManager.Instance.Player.Player.GetData().PlayerShortId);
        introText.SetRawText(DataManager.Instance.Player.Player.GetData().IntroText);
        long remainExp = DataManager.Instance.Player.Player.GetRemainExp();
        int lv = DataManager.Instance.Player.Player.GetLevel();

        var fill = 0f;
        if (DataManager.Instance.Master.PlayerLevel.ContainsKey(lv+1))
        {
            fill = (float)remainExp/DataManager.Instance.Master.PlayerLevel[lv+1].exp;
        }

        //rankIcon.Set(lv, fill);
        rankText.SetRawText(lv.ToString());
        UpdateIcon();
    }

    public void UpdateName()
    {
        nameText.SetRawText(DataManager.Instance.Player.Player.GetData().Name);
    }

    public void UpdateIntro()
    {
        introText.SetRawText(DataManager.Instance.Player.Player.GetData().IntroText);
    }

    public void UpdateMiniScene(UIMiniSceneViewModel model, bool editable)
    {
        miniScene.Setup(model, editable);
    }

    public void UpdateIcon()
    {
        var iconId = DataManager.Instance.Player.Player.GetData().ProfileIconId;
        _userIcon.Setup(DataManager.Instance.Player.Player.GetData().ProfileIconFrame,iconId );
        var master = DataManager.Instance.Master
            .CharacterResource[DataManager.Instance.Master.BattleCharacter[iconId].characterResourceId];

        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(master); });
        //characterImage.sprite =   ResourceManager.Instance.LoadSprite("CharacterMain/Stand", master.standImageName);
        //characterBg.sprite =   ResourceManager.Instance.LoadSprite("CharacterMain/BgCutin", master.bgCutinName);
    }

    private void OnClickEdit(bool v)
    {
        foreach (var btn in editButtonObjects)
        {
            btn.SetActive(v);
        }
    }
    private void OnClickCopy()
    {
        GUIUtility.systemCopyBuffer = DataManager.Instance.Player.Player.GetData().PlayerShortId;
        UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.PROFILE, "PROFILE_COPY"));
        
    }

    private void OnClickSignOff()
    {
        LCXHandler.Instance.SignOff();
    }

    private async UniTask LoadSpriteAsync(CharacterResourceMaster master)
    {
        characterImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("CharacterMain/Stand", master.standImageName);
        characterBg.sprite = await ResourceManager.Instance.LoadSpriteAsync("CharacterMain/BgCutin", master.bgCutinName);
    }
}
