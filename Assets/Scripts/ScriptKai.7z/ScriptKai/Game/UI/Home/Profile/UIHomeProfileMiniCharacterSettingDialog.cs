﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using TMPro;
using Spine.Unity;
using UnityEngine.Events;

public class UIHomeProfileMiniCharacterSettingDialog : UIDialogBase
{
    [SerializeField] TMP_Dropdown dropdownDirection;
    [SerializeField] TMP_Dropdown dropdownAction;
    [SerializeField] UIMiniCharacterHolder characterHolder;
    [SerializeField] UIButton changeCharaButton;
    [SerializeField] UIButton okButton;
    [SerializeField] UIButton unsetButton;
    [SerializeField] UIButton closeButton2;

    public int Direction => dropdownDirection.value;
    public int Action => dropdownAction.value;


    public UnityEvent OnSuccess = new UnityEvent();
    public UIIntEvent OnChangeCharacter = new UIIntEvent();
    public UnityEvent OnUnsetCharacter = new UnityEvent();


    private int mCurrentSlot = 0;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        var dirList = new List<string>();
        dirList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.PROFILE, "MINICHARA_DIR_LEFT"));
        dirList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.PROFILE, "MINICHARA_DIR_RIGHT"));

        dropdownDirection.AddOptions(dirList);
        closeButton2.onClick.AddListener((o) =>
        {
            onClickClose(o);
        });

        var actList = new List<string>();
        actList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.PROFILE, "MINICHARA_ACTION_IDLE"));
        actList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.PROFILE, "MINICHARA_ACTION_ATTACK"));
        //actList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.PROFILE, "MINICHARA_ACTION_STUN"));
        //actList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.PROFILE, "MINICHARA_ACTION_RUN"));
        //actList.Add(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.PROFILE, "MINICHARA_ACTION_DIE"));

        dropdownAction.AddOptions(actList);

        okButton.onClick.GuardSubscribeAsync(OnClickOKAsync).AddTo(mSubscriptions);
        unsetButton.onClick.AddListener((o) =>
        {
            onClickClose(o);
        });
        changeCharaButton.onClick.Subscribe(OnClickChangeCharacter).AddTo(mSubscriptions);

        dropdownAction.onValueChanged.Subscribe(OnActionChange).AddTo(mSubscriptions);
        dropdownDirection.onValueChanged.Subscribe(OnDirChange).AddTo(mSubscriptions);
    }

    public void Setup(int slot, long id, int dir, int action)
    {
        mCurrentSlot = slot;
        characterHolder.Setup(id, dir, action);
        dropdownDirection.SetValueWithoutNotify(dir);
        dropdownAction.SetValueWithoutNotify(action);
    }

    private void OnDirChange(int val)
    {
        characterHolder.SetDirection(val);
    }

    private void OnActionChange(int val)
    {
        characterHolder.SetAction(val);
    }


    private void OnClickChangeCharacter(GameObject o)
    {
        Hide();
        OnChangeCharacter.Invoke(mCurrentSlot);
    }


    private async UniTask OnClickOKAsync(GameObject o)
    {
        Hide();
        OnSuccess.Invoke();
    }

   //private void OnClickUnset(GameObject o)
   //{
   //    Hide();
   //    OnUnsetCharacter.Invoke();
   //}
}
