﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine.Events;

public class UIHomeProfileChangeIntroDialog : UIDialogBase
{
    [SerializeField] UIButton okButton;
    [SerializeField] TMP_InputField inputField;
    [SerializeField] UIText errorText;
    [SerializeField] UIButton cancelButton;


    public UnityEvent OnSuccess = new UnityEvent();



    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        okButton.onClick.GuardSubscribeAsync(OnClickOk).AddTo(mSubscriptions);

        inputField.text = DataManager.Instance.Player.Player.GetData().IntroText;
        cancelButton.onClick.GuardSubscribeAsync(onClickClose).AddTo(mSubscriptions);
    }
    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        inputField.text = DataManager.Instance.Player.Player.GetData().IntroText;
        errorText.gameObject.SetActive(false);
    }

    private async UniTask OnClickOk(GameObject o)
    {
        string intro = inputField.text;

        await ProfileService.SetUserIntro(intro);

        await HideAsync();

        OnSuccess.Invoke();
        
    }

}
