﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;

public class UIHomeProfileSelectMiniCharacterDialog : UIDialogBase
{
    [SerializeField] SelectableCharacter itemPrefab;
    [SerializeField] RectTransform itemTransformParent;
    [SerializeField] UIButton okButton;

    [SerializeField] private List<Sprite> borderList;


    public UnityEvent OnSelect = new UnityEvent();
    public Dictionary<int, long> Result = new Dictionary<int, long>();


    private const int maxSelectNum = 4;


    private Dictionary<long, SelectableCharacter> mItems = new Dictionary<long, SelectableCharacter>();
    private Dictionary<long, int> mCurrentDeck = null;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        okButton.onClick.GuardSubscribeAsync(OnClickOkAsync).AddTo(mSubscriptions);
    }


    public async UniTask SetupAsync(Dictionary<long, int> deck)
    {
        mCurrentDeck = deck;
        Result.Clear();

        foreach (var item in DataManager.Instance.Player.Character.GetList())
        {
            SelectableCharacter sel = null;

            if (!mItems.ContainsKey(item.BattleCharacterMasterId))
            {
                var newItemObj = GameObject.Instantiate(itemPrefab.gameObject);
                newItemObj.transform.parent = itemTransformParent;
                newItemObj.transform.localScale = Vector3.one;
                newItemObj.transform.localRotation = Quaternion.identity;
                newItemObj.transform.localPosition = Vector3.zero;
                newItemObj.SetActive(true);

                sel = newItemObj.GetComponent<SelectableCharacter>(); 
                var rarity = DataManager.Instance.Master.BattleCharacter[item.BattleCharacterMasterId].rarity;
                Sprite borderSprite;
                if (rarity>=0&&rarity<=borderList.Count)
                {
                    borderSprite = borderList[rarity-1];
                }
                else
                {
                    borderSprite= borderList[0];
                }
                sel.SetBoder(borderSprite);      
                
                await sel.SetupAsync(item.BattleCharacterMasterId);
                sel.OnClick.Subscribe(()=>
                {
                    OnSelectItem(sel);
                }).AddTo(mSubscriptions);

                mItems.Add(item.BattleCharacterMasterId, sel);
            }
            else
            {
                sel = mItems[item.BattleCharacterMasterId];
            }

            if (deck.ContainsKey(item.BattleCharacterMasterId))
            {
                sel.Select(true);
                sel.SetSelectText((deck[item.BattleCharacterMasterId]+1).ToString());
                Result.Add(deck[item.BattleCharacterMasterId], item.BattleCharacterMasterId);
            }
            else
            {
                sel.Select(false);
            }
        }

        for (int i = 0; i < maxSelectNum; i++)
        {
            if (!Result.ContainsKey(i))
            {
                Result.Add(i, 0);
            }
        }

    }

    private void OnSelectItem(SelectableCharacter selectableCharacter)
    {
        if (selectableCharacter.IsSelected)
        {
            //当前已经在deck里
            selectableCharacter.Select(false);
            PxSoundManager.Instance.PlaySe("feedbackSE_date_cancel01");
           var currentSlot = mCurrentDeck[selectableCharacter.CharacterId];
            mCurrentDeck.Remove(selectableCharacter.CharacterId);
            Result[currentSlot] = 0;
        }
        else
        {
            var validSlot = -1;
            for (int i = 0; i < maxSelectNum; i++)
            {
                if (Result[i] == 0)
                {
                    validSlot = i;
                    break;
                }
            }
            if (validSlot >= 0)
            {
                selectableCharacter.Select(true);
                selectableCharacter.SetSelectText((validSlot+1).ToString());
                mCurrentDeck.Add(selectableCharacter.CharacterId, validSlot);
                Result[validSlot] = selectableCharacter.CharacterId;
            }
            
        }
        
    }

    private async UniTask OnClickOkAsync(GameObject o)
    {
        await HideAsync();
        OnSelect.Invoke();
    }

}
