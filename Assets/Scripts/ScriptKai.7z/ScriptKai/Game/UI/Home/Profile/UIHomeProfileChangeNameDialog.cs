﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine.Events;

public class UIHomeProfileChangeNameDialog : UIDialogBase
{
    [SerializeField] UIButton okButton;
    [SerializeField] TMP_InputField inputField;
    [SerializeField] UIText errorText;
    [SerializeField] UIText costNumText;

    [SerializeField] private UIButton closeBtn;
    public UnityEvent OnSuccess = new UnityEvent();

    [SerializeField] UIButton closeButton2;
    [SerializeField] UIButton cancelButton;
    

    private int costNum = 0;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        okButton.onClick.GuardSubscribeAsync(OnClickOk).AddTo(mSubscriptions);
        costNum = DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.ChangeNameCost].data;

        costNumText.SetRawText(costNum.ToString());
        if (closeButton2 != null)
        {
            closeButton2.onClick.AddListener((o) =>
            {
                onClickClose(o);
            });
        }
        if (cancelButton != null)
        {
            cancelButton.onClick.AddListener((o) =>
            {
                onClickClose(o);
            });
        }
    }
    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        inputField.text = "";
        errorText.gameObject.SetActive(false);
    }

    private async UniTask OnClickOk(GameObject o)
    {
        string name = inputField.text;
        if (string.IsNullOrEmpty(name))
        {
            //errorText.gameObject.SetActive(true);
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "Change_Name_Null"));
            return;
        }
        
        if (DataManager.Instance.Player.Wallet.GetCount("FREE_STONE") < costNum)
        {
            // var changeVal = costNum-DataManager.Instance.Player.Wallet.GetCount("FREE_STONE");
            // string confirmText = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "FREEGEM_PURCHASE_CONFIRM"), changeVal, changeVal);
            // var popup = await UI.Popup.ShowPopupAsync(UIPrefabId.CommonConfirm, string.Empty, confirmText, CanvasType.System);
            // var result = await popup.WaitResult();
            // if (result != UIPopupDialog.Result.OK)
            // {
            //     return;
            // }

            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "FREEGEM_PURCHASE"));
            return;
        }

        await ProfileService.SetUserName(name);

        await HideAsync();

        OnSuccess.Invoke();
        
    }

}
