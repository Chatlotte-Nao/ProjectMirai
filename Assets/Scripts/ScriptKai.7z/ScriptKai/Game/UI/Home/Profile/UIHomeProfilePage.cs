﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Cysharp.Threading.Tasks.Triggers;

public class UIHomeProfilePage : UIPageBase
{
    //private UIDialogBase mBg = null;
    private UIHomeProfileDialog mProfileDialog = null;
    private UIHomeProfileChangeNameDialog mChangeName = null;
    private UIHomeProfileChangeIntroDialog mChangeIntro = null;
    private UIHomeProfileChangeIconDialog mChangeIcon = null;
    private UIHomeProfileChangeBgDialog mChangeBg = null;
    private UIHomeProfileMiniCharacterSettingDialog mMiniCharacterSetting = null;
    private UIHomeProfileSelectMiniCharacterDialog mSelectCharacter = null;
    private UIAdvConfigDialog mConfig = null;
    private int mCurrentEditSlot = 0;
    private UIMiniSceneViewModel mMiniSceneModel = null;
    UIHomeHeaderParam headerParam = new UIHomeHeaderParam();


    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        
        mMiniSceneModel = MiniSceneUtil.BuildViewModel(DataManager.Instance.Player.Player.GetData().ProfileDecks);

        //mBg = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeProfileBg, CanvasType.BG);
        mProfileDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeProfileDialog, CanvasType.App0) as UIHomeProfileDialog;
        await mProfileDialog.SetupSelfAsync();
        mProfileDialog.UpdateMiniScene(mMiniSceneModel, true);

        headerParam.visibleMenu = false;
        headerParam.visiblePlayerStatus = false;
        headerParam.visibleRightRank = false;
        headerParam.visibleBack = true;
        headerParam.visibleNavigation = true;
        headerParam.visibleHome = true;


        mProfileDialog.OnEditName.GuardSubscribeAsync(OnClickChangeName).AddTo(mSubscriptions);
        mProfileDialog.OnEditIntro.GuardSubscribeAsync(OnClickChangeIntro).AddTo(mSubscriptions);
        mProfileDialog.OnEditIcon.GuardSubscribeAsync(OnClickChangeIcon).AddTo(mSubscriptions);
        mProfileDialog.OnEditBg.GuardSubscribeAsync(OnClickChangeBg).AddTo(mSubscriptions);
        mProfileDialog.OnClickMiniSceneCharacter.GuardSubscribeAsync(OnClickMiniSceneCharacter).AddTo(mSubscriptions);
        mProfileDialog.OnClickMiniSceneEmptySlot.GuardSubscribeAsync(OnClickMiniSceneEmptySlot).AddTo(mSubscriptions);
        mProfileDialog.OnEditMiniSceneCharacter.GuardSubscribeAsync(OnClickChangeMiniSceneCharacter).AddTo(mSubscriptions);
        mProfileDialog.OnCloseClick.SubscribeAsync(onClose).AddTo(mSubscriptions);
        mProfileDialog.OnConfige.GuardSubscribeAsync(OnConfige).AddTo(mSubscriptions);
    }

    private async UniTask onClose(GameObject o)
    {
        await UI.Page.CloseCurrentPage();
    }
    public override async UniTask ShowAsync(UIPageShowType showType)
    {       
        SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);
        await base.ShowAsync(showType);
        //await mBg.ShowAsync(showType);
        await mProfileDialog.ShowAsync(showType);
    }
    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        //await mBg.HideAsync(showType);
        await mProfileDialog.HideAsync(showType);
    }

    public override void Dispose()
    {
        base.Dispose();
        // if (mBg != null)
        // {
        //     mBg.Dispose();
        //     mBg = null;
        // }
        headerParam = null;
        if (mProfileDialog != null)
        {
            mProfileDialog.Dispose();
            mProfileDialog = null;
        }
        if (mChangeName != null)
        {
            mChangeName.Dispose();
            mChangeName = null;
        }
        if (mChangeIcon != null)
        {
            mChangeIcon.Dispose();
            mChangeIcon = null;
        }
        if (mChangeBg != null)
        {
            mChangeBg.Dispose();
            mChangeBg = null;
        }
        if (mMiniCharacterSetting != null)
        {
            mMiniCharacterSetting.Dispose();
            mMiniCharacterSetting = null;
        }
        if (mSelectCharacter != null)
        {
            mSelectCharacter.Dispose();
            mSelectCharacter = null;
        }
        if (mChangeIntro != null)
        {
            mChangeIntro.Dispose();
            mChangeIntro = null;
        }

        if (mConfig != null)
        {
            mConfig.Dispose();
            mConfig = null;
        }
        
    }
    private async UniTask OnConfige(GameObject o)
    {
        if (mConfig == null)
        {
            mConfig = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvConfigDialog, CanvasType.App2) as UIAdvConfigDialog;
        }
        await mConfig.ShowAsync();
    }
    
    private async UniTask OnClickChangeName(GameObject o)
    {
        if (mChangeName == null)
        {
            mChangeName = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeProfileChangeNameDialog, CanvasType.App1) as UIHomeProfileChangeNameDialog;
            mChangeName.OnSuccess.Subscribe(OnNameUpdate).AddTo(mSubscriptions);
        }
        await mChangeName.ShowAsync();
    }

    private async UniTask OnClickChangeIntro(GameObject o)
    {
        if (mChangeIntro == null)
        {
            mChangeIntro = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeProfileChangeIntroDialog, CanvasType.App1) as UIHomeProfileChangeIntroDialog;
            mChangeIntro.OnSuccess.Subscribe(OnIntroUpdate).AddTo(mSubscriptions);
        }
        await mChangeIntro.ShowAsync();
    }

    private async UniTask OnClickChangeIcon(GameObject o)
    {
        if (mChangeIcon == null)
        {
            mChangeIcon = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeProfileChangeIconDialog, CanvasType.App1) as UIHomeProfileChangeIconDialog;
            mChangeIcon.OnSuccess.Subscribe(OnIconUpdate).AddTo(mSubscriptions);
        }
        await mChangeIcon.ShowAsync();
    }

    private async UniTask OnClickChangeBg(GameObject o)
    {
        if (mChangeBg == null)
        {
            mChangeBg = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeProfileChangeBgDialog, CanvasType.App1) as UIHomeProfileChangeBgDialog;
            mChangeBg.OnSuccess.Subscribe(OnBgUpdate).AddTo(mSubscriptions);
        }
        await mChangeBg.ShowAsync();
    }

    private async UniTask OnClickChangeMiniSceneCharacter()
    {
        await OnClickMiniSceneEmptySlot(0);
    }

    private async UniTask OnClickMiniSceneEmptySlot(int slot)
    {
        // mCurrentEditSlot = slot;
        if (mSelectCharacter == null)
        {
            mSelectCharacter = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeProfileSelectMiniCharacterDialog, CanvasType.App1) as UIHomeProfileSelectMiniCharacterDialog;
            mSelectCharacter.OnSelect.GuardSubscribeAsync(OnMiniCharacterSelectAsync).AddTo(mSubscriptions);
        }

        var deck = new Dictionary<long, int>();
        foreach (var item in mMiniSceneModel.characters)
        {
            deck.Add(item.Value.id, item.Key);
        }

        await mSelectCharacter.SetupAsync(deck);
        
        await mSelectCharacter.ShowAsync();
    }

    private async UniTask OnClickMiniSceneCharacter(int slot)
    {
        mCurrentEditSlot = slot;
        if (mMiniCharacterSetting == null)
        {
            mMiniCharacterSetting = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeProfileMiniCharacterSettingDialog, CanvasType.App1) as UIHomeProfileMiniCharacterSettingDialog;
            mMiniCharacterSetting.OnChangeCharacter.GuardSubscribeAsync(OnClickMiniSceneEmptySlot).AddTo(mSubscriptions);
            mMiniCharacterSetting.OnSuccess.GuardSubscribeAsync(OnMiniCharacterSettingChangedAsync).AddTo(mSubscriptions);
            mMiniCharacterSetting.OnUnsetCharacter.GuardSubscribeAsync(OnMiniSceneCharacterUnsetAsync).AddTo(mSubscriptions);
        }
        var data = DataManager.Instance.Player.Player.GetData().ProfileDecks[slot];
        mMiniCharacterSetting.Setup(slot, data.BattleCharacterMasterId, data.Direction, data.ActionId);
        await mMiniCharacterSetting.ShowAsync();
    }


    private void OnNameUpdate()
    {
        mProfileDialog.UpdateName();
    }

    private void OnIntroUpdate()
    {
        mProfileDialog.UpdateIntro();
    }

    private void OnIconUpdate()
    {
        mProfileDialog.UpdateIcon();
    }

    private void OnBgUpdate()
    {

    }

    private async UniTask OnMiniCharacterSelectAsync()
    {
        foreach (var kv in mSelectCharacter.Result)
        {
            if (kv.Value > 0)
            {
                MiniSceneUtil.ChangeCharacter(mMiniSceneModel, kv.Key, kv.Value);
            }
            else
            {
                mMiniSceneModel.characters.Remove(kv.Key);
            }
        }
        
        await ProfileService.SaveMiniScene(mMiniSceneModel);

        OnMiniSceneChanged();
    }

    private async UniTask OnMiniCharacterSettingChangedAsync()
    {
        mMiniSceneModel.characters[mCurrentEditSlot].dir = mMiniCharacterSetting.Direction;
        mMiniSceneModel.characters[mCurrentEditSlot].action = mMiniCharacterSetting.Action;
        await ProfileService.SaveMiniScene(mMiniSceneModel);

        OnMiniSceneChanged();
    }

    private async UniTask OnMiniSceneCharacterUnsetAsync()
    {
        mMiniSceneModel.characters.Remove(mCurrentEditSlot);
        await ProfileService.SaveMiniScene(mMiniSceneModel);

        OnMiniSceneChanged();
    }

    private void OnMiniSceneChanged()
    {
        mProfileDialog.UpdateMiniScene(mMiniSceneModel, true);
    }

}
