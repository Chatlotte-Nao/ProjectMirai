using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
public class UINoneItemPage : UIPageBase
{
    public UINoneItemPopup noneItemPopup = null;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        noneItemPopup = await UI.Dialog.CreateAsync(UIPrefabId.UINoneItemPopup, CanvasType.App1) as UINoneItemPopup;
        noneItemPopup.OnClick.GuardSubscribeAsync(onBackClcik).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
        await noneItemPopup.ShowAsync();

    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await noneItemPopup.HideAsync();

    }
    private async UniTask onBackClcik(GameObject o)
    {
        //await HideAsync(showType: UIPageShowType.Front);
        await UI.Page.CloseCurrentPage();
    }
    public override void Dispose()
    {
        if (noneItemPopup != null)
        {
            noneItemPopup.Dispose();
            noneItemPopup = null;
        }
        base.Dispose();
    }

}
