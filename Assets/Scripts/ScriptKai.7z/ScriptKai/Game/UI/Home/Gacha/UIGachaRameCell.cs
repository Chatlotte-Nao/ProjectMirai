﻿using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class UIGachaRameCell : MonoBehaviour
{
    [SerializeField] private SpriteRenderer sheetMusic;
    [SerializeField] private SpriteRenderer sheetMusicAnime;
    [SerializeField] private GameObject[] effects;
    
    public async UniTask SetupAsync(long id,GachaDrawItemType gachaDrawItemType)
    {
        int rarity = 0;
        if (gachaDrawItemType == GachaDrawItemType.Charater)
        {
            var characterMaster = DataManager.Instance.Master.BattleCharacter[id];
            rarity = characterMaster.initialRank+1;
        }
        else
        {
            var equipmentrMaster = DataManager.Instance.Master.Equipment[id];
            rarity = equipmentrMaster.rarity;
        }
       
        sheetMusic.sprite = await ResourceManager.Instance.LoadSpriteAsync("Gacha/Gachamusic", $"SheetMusic_Rare_{rarity}");
        sheetMusicAnime.sprite = await ResourceManager.Instance.LoadSpriteAsync("Gacha/Gachamusic", $"SheetMusic_Rare_{rarity}_anime");
        for (int i = 0; i < effects.Length; i++)
        {
            effects[i].gameObject.SetActive(i == rarity - 1);
        }
    }
}
