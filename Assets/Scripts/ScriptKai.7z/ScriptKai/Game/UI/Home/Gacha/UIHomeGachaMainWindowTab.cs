﻿using System;
using System.Collections;
using System.Collections.Generic;
using Base.Util;
using Battle.Unity.BattleUI;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
public class UIHomeGachaMainWindowTab : MonoBehaviour
{
   [SerializeField] Image selectBg;
   [SerializeField] Image unselectedBg;
   [SerializeField] UIText gachaName;
   [SerializeField] UIButton button;
   [SerializeField] UIText titleText;
   //[SerializeField] private List<UITexture> characterIcon;
   [SerializeField] UIText timeText;
   public ClickEvent OnClick => button.onClick;
   private long _gacheId;
   public async UniTask SetUpAsync(UIGachaViewModel model)
   {
      _gacheId = model.id;
      gachaName.SetLabel(LocalizeManager.DATA_TYPE.GACHA, $"Gacha_Name{model.id}");
        //new
      AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(model); });
      //unselectedBg.sprite =  ResourceManager.Instance.LoadSpriteSmall("Gacha/TabIcon", model.master.icon);
      titleText.SetLabel(LocalizeManager.DATA_TYPE.GACHA, $"Gacha_Type_{model.master.type}");
      
   }
   
   public void SetBtnAvtive(long gachaId)
   {
      selectBg.gameObject.SetActive(gachaId == _gacheId);
   }

    private async UniTask LoadSpriteAsync(UIGachaViewModel model)
    {
        unselectedBg.sprite = await ResourceManager.Instance.LoadSpriteAsync("Gacha/TabIcon", model.master.icon);
    }
}
