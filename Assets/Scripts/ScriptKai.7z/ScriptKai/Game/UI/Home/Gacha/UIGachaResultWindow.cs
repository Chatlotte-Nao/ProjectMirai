﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIGachaResultWindow : UIDialogBase
{
    [SerializeField] UIButton okButton;
    [SerializeField] UIButton againButton;
    [SerializeField] private RectTransform itemContent;
    [SerializeField] private UIHomeGachaResultCell resultCell;
    [SerializeField] UIText againText;
    [SerializeField] BaseItem consumeItem;

    [SerializeField] private GameObject tenObject;
    [SerializeField] private GameObject oneObject;
    
    [SerializeField] List<UIHomeGachaResultCell> tenCells;
    [SerializeField] UIHomeGachaResultCell oneCell;
    [SerializeField] private GameObject fragmentObj;
    public ClickEvent OnCloseClick => okButton.onClick;
    public ClickEvent OnAgainBtutton => againButton.onClick;

    public async UniTask Setup(UIGachaResultModel model,GachaDrawType gachaDrawType,GachaDrawItemType gachaDrawItemType,long gachaContentId)
    {
        foreach (var cell in tenCells)
        {
            cell.gameObject.SetActive(false);
        }
        if (model.itemList.Count > 0)
        {
            if (gachaDrawType == GachaDrawType.Ten)
            {
                tenObject.SetActive(true);
                oneObject.SetActive(false);
                fragmentObj.SetActive(true);
                for (int i = 0; i < model.itemList.Count; i++)
                {
                    var item = model.itemList[i];
                    if (i < tenCells.Count)
                    {
                        await tenCells[i].SetUpAsync(item, gachaDrawItemType);
                        tenCells[i].gameObject.SetActive(true);
                    }
                }
            }
            else
            {
                tenObject.SetActive(false);
                oneObject.SetActive(true);
                fragmentObj.SetActive(model.itemList[0].isConverted);
                await oneCell.SetUpAsync(model.itemList[0], gachaDrawItemType);
            }

        }
        againButton.gameObject.SetActive(gachaDrawType != GachaDrawType.DailyLimit );
        if (gachaDrawType != GachaDrawType.DailyLimit)
        {
            if (gachaDrawType == GachaDrawType.One)
            {
                consumeItem.Setup(gachaContentId, "x1");
                againText.SetLabel(LocalizeManager.DATA_TYPE.COMMON, "GACHA_BUTTON_CONTINUE");
            }
            else
            {
                consumeItem.Setup(gachaContentId, "x10");
                againText.SetLabel(LocalizeManager.DATA_TYPE.GACHA, "Gacha_Again_Ten");
            }
        }
    }


    private void OnEndGacha(GameObject o)
    {
        // if (TutorialManager.Instance.TryStartOpeningTutorial())
        // {
        //     return;
        // }
    }
}
