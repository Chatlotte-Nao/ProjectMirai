using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;

public class UIGachaCharacterInfo : MonoBehaviour
{
    [SerializeField] private Image jobBg;
    [SerializeField] private Image jobIcon;
    [SerializeField] private UIText jobText;
    
    [SerializeField] private UIText characterNameText;
    [SerializeField] private UIText characterName2Text;
    [SerializeField] private UIText characterTitleText;

    [SerializeField] private Image[] starImage;

    [SerializeField] private GameObject timeObj;
    [SerializeField] private UIText timeText;
    [SerializeField] private Image titleImage;
    public void SetUp(long characterId)
    {
        timeObj.gameObject.SetActive(false);
        var characterMaster = DataManager.Instance.Master.BattleCharacter[characterId];
        var attrMaster = DataManager.Instance.Master.Attribute[characterMaster.attribute];
       
        var jobMaster = DataManager.Instance.Master.Job[characterMaster.job];
        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(attrMaster,jobMaster); });

        jobText.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, string.Format("Job_{0}", ((CharacterRole)characterMaster.job).ToString()));
        var characterName =
            LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER_NAME, $"{characterId}");
        characterNameText.SetRawText(characterName);
        characterName2Text.SetRawText(characterName);
        characterTitleText.SetFormat(LocalizeManager.DATA_TYPE.GACHA,"Gacha_Character_Title3",characterName);
        for (int i = 0; i < starImage.Length; i++)
        {
            starImage[i].gameObject.SetActive(characterMaster.initialRank >= (i+1) );
        }
    }
    
    public void SetUpGachaInfo(long characterId,long closeAt,GachaMaster master)
    {
        SetUp(characterId);
        //timeText.SetFormat(LocalizeManager.DATA_TYPE.GACHA, "Gacha_EndTime", GlobalTime.GetDateTime(closeAt).ToShortDateString());
        timeObj.gameObject.SetActive(closeAt>0);
        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(master); });
        //titleImage.sprite =  ResourceManager.Instance.LoadSpriteSmall("Gacha/TitleIcon", master.icon);
    }

    private async UniTask LoadSpriteAsync(AttributeMaster attrMaster,JobMaster jobMaster)
    {
        jobIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("Job", jobMaster.IconPath);
        jobBg.sprite = await ResourceManager.Instance.LoadSpriteAsync("Attribute", attrMaster.IconPath);
    }
    private async UniTask LoadSpriteAsync(GachaMaster master)
    {
        titleImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("Gacha/TitleIcon", master.icon);
    }

}
