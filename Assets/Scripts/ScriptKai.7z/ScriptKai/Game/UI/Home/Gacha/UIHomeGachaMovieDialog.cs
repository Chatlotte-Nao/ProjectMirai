﻿using System;
using System.Collections;
using System.Collections.Generic;
using Base.Util;
using Battle.Unity.BattleUI;
using CriMana;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using UnityEngine.UI;

public class UIHomeGachaMovieDialog : UIDialogBase
{
   //[SerializeField] Image bg;
   [SerializeField] CriManaMovieControllerForUI controller;
   [SerializeField] private UIButton jumpButton;
   UIGachaViewModel _model;
   public const string Production = "Movies/Gacha/Character/";
   public const string Lottery = "Movies/Gacha/Lottery/";
   public const string ProductionLoop = "Movies/Gacha/CharacterLoop/";
   
   private string[] GachaLottery = {"GachaLottery_SC00-3","GachaLottery_SC00-2","GachaLottery_SC00-1"};
   private RectTransform canvasRectTransform = null;
   private RectTransform targetTransform = null;
   public ClickEvent OnJump => jumpButton.onClick;
   private bool isLoop_;
   private string loopPath;
   public async UniTask SetUpAsync(UIGachaViewModel model,bool isChatcter = true,int lotteryIndex = 0,bool isLoop = false)
   {
      isJump = false;
      _model = model;
      isLoop_ = isLoop;
      UpdataUpResource(0,isChatcter,lotteryIndex);
   }

   public void UpdataUpResource(int index,bool isChatcter = true,int lotteryIndex = 0)
   {
      if (_model.master.toggleUnClickImages.Count > 0)
      {
         if (isChatcter)
         {
            //controller.player.Loop(false);
            var characterMaster = DataManager.Instance.Master.BattleCharacter[_model.master.upIconIds[index]];
            var skillMaster = DataManager.Instance.Master.Skill[characterMaster.musicalEffectId];
            var path = string.Format("{0}{1}", Production,skillMaster.cutinPath);
            if(isLoop_)
               path = string.Format("{0}{1}", ProductionLoop,skillMaster.cutinPath);
            this.StartCoroutine(DrawReadyVideoRoutine(path,false));
            //isLoop = true;
            //loopPath =  string.Format("{0}{1}", ProductionLoop,skillMaster.cutinPath);
         }
         else
         {
            var path = string.Format("{0}{1}.usm", Lottery,GachaLottery[lotteryIndex]);
            Log.Debug("UIHomeGachaMovieDialog UpdataUpResource path : " + path);
            this.StartCoroutine(DrawReadyVideoRoutine(path,true));
            //isLoop = false;
         }
      }
   }

   public async UniTask LoadDrawReadyVideoRoutine(string path,bool isStop)
   {
      //isLoop = false;
      this.StartCoroutine(DrawReadyVideoRoutine(path,isStop));
   }

   private bool isJump = false;
   private bool isStop_ = false;
   IEnumerator DrawReadyVideoRoutine(string path,bool isStop)
   {
      isStop_ = isStop;
      yield return this.StartCoroutine(VideoRoutine(path));
      yield return new WaitUntil(() => controller.player.status == CriMana.Player.Status.PlayEnd);
      if(isStop)
         controller.player.Stop();
      if(!isJump && isStop)
         OnJump.Invoke(gameObject);
      // if (isLoop)
      //    LoopCharcter();
   }

   void LoopCharcter()
   {
      controller.player.Loop(true);
      this.StartCoroutine(DrawReadyVideoRoutine(loopPath,false));
      //isLoop = false;
   }


   IEnumerator VideoRoutine(string path)
   {
      if (DebugState.isQucikMode())
      {
         yield break;
      }
      controller.player.Stop();
      while (controller.player.status != CriMana.Player.Status.Stop)
      {
         yield return null;
      }

      Graphic target = controller.target;
      if (target == null)
      {
         yield break;
      }

      Canvas canvas = target.GetComponentInParent<Canvas>();
      if (canvas == null)
      {
         yield break;
      }

      canvasRectTransform = canvas.GetComponent<RectTransform>();
      targetTransform = target.GetComponent<RectTransform>();

      path = ResourceManager.Instance.GetNonAbFilePath(path, true);
      controller.player.SetFile(null, path);
      controller.player.PrepareForRendering();
      controller.player.Prepare();

      while (controller.player.status != CriMana.Player.Status.ReadyForRendering)
      {
         yield return null;
      }

      target.gameObject.SetActive(true);
      if ((canvasRectTransform != null) && (targetTransform != null))
      {
         MovieInfo movieInfo = controller.player.movieInfo;
         if (movieInfo != null)
         {
            if ((canvasRectTransform.sizeDelta.x / movieInfo.width >
                 canvasRectTransform.sizeDelta.y / movieInfo.height))
            {
               float y = canvasRectTransform.sizeDelta.x * movieInfo.height / movieInfo.width;
               Utility.SetSizeDelta(targetTransform, canvasRectTransform.sizeDelta.x, y);
            }
            else
            {
               float x = canvasRectTransform.sizeDelta.y * movieInfo.width / movieInfo.height;
               Utility.SetSizeDelta(targetTransform, x, canvasRectTransform.sizeDelta.y);
            }

            frame = controller.player.movieInfo.totalFrames;
            index = 0;
            isStart = true;
         }
         else
         {
            isStop_ = true;
            isStart = false;
         }
      }

      controller.player.Start();
      
   }

   [SerializeField] private AnimationCurve curve;
   private bool isStart = false;
   private long frame = 0;
   private int index = 0;
   private float time = 0;
   private void Update()
   {
      if (isStart && index<= frame)
      {
         time += Time.deltaTime;
         if (time >= (1.0f / frame))
         {
            index++;
            time = 0;
            if (!isStop_ && index == frame- 20 )
            {
               OnJump.Invoke(gameObject);
               isStart = false;
            }
         }
      }
   }

   public override async UniTask HideAsync(UIPageShowType showType = UIPageShowType.Front)
   {
      await base.HideAsync(showType);
      isJump = true;
      
   }

}
