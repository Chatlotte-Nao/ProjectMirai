﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Gacha;
using Spine.Unity;
using UnityEngine.Events;
using UnityEngine.UI;
public class UIGachaMainWindow : UIDialogBase
{
    //TopScenePage
    [SerializeField] UIHomeGachaMainWindowTab tablePrefab;
    [SerializeField] private RectTransform tableContent;
    
	[SerializeField] UIButton leftButton;
	[SerializeField] UIButton rightButton;

    [Space]
    [SerializeField] private UIButton oneButton;
    [SerializeField] private UIButton tenButton;
    [SerializeField] private UIButton paidButton;
    [SerializeField] BaseItem oneConsumeItem;
    [SerializeField] BaseItem tenConumeItem;
    [SerializeField] BaseItem paidConsumeItem;
    
    [SerializeField] BaseItem consumeItem;
    [SerializeField] private UIButton historyButton;
    [SerializeField] private UIButton backButton;
    public ClickEvent OnClickBackButton => backButton.onClick;
    
    // public UIHomeGachaMovieDialog pagePrefab;
    // public UIHomeGachaMovieDialog pagelopplePrefab;
    [SerializeField] private UIGachaCharacterInfo characterInfo;
    [SerializeField] private GameObject characterObj;
    [SerializeField] private RawImage gachaImage;
    public ClickEvent OnOneButton => oneButton.onClick;
    public ClickEvent OnTenButton => tenButton.onClick;
    public ClickEvent OnPaidButton => paidButton.onClick;
    public ClickEvent OnHistoryButton => historyButton.onClick;
    public UIGachaViewModelEvent TabClick = new UIGachaViewModelEvent();
    List<UIHomeGachaMainWindowTab> _tabs = new List<UIHomeGachaMainWindowTab>();
    UIGachaViewModel _model;
    int _index = 0;
    UIRTCamera mRTCamera = null;
    public override async UniTask InitializeAsync()
    {
        leftButton.OnTouchUpInside.Subscribe(leftButtonOnclick).AddTo(mSubscriptions);
        rightButton.OnTouchUpInside.Subscribe(rightButtonOnclick).AddTo(mSubscriptions);
        await base.InitializeAsync();
        gachaImage.gameObject.SetActive(false);
        //pagePrefab.OnJump.GuardSubscribeAsync(ShowCharacrerInfo).AddTo(mSubscriptions);
        var rtc = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/RTCamera");
        mRTCamera = rtc.GetComponent<UIRTCamera>();
    }

    public async UniTask SetupAsync(UIGachaListModel model)
    {
        foreach (var gacha in model.gachaList)
        {
            var table = Instantiate(tablePrefab, this.tableContent, false);
            await table.SetUpAsync(gacha);
            table.OnClick.Subscribe((_) =>
            {
                TabClick.Invoke(gacha);
            }).AddTo(mSubscriptions);
            _tabs.Add(table);
        }
        tableContent.gameObject.SetActive(!(model.gachaList.Count==1));
    }

    public async UniTask LoadContent(UIGachaViewModel viewModel)
    {
        SetLoopPrefab(false);
        _model = viewModel;

        leftButton.gameObject.SetActive(viewModel.master.toggleUnClickImages.Count > 1);
        rightButton.gameObject.SetActive(viewModel.master.toggleUnClickImages.Count > 1);
        paidButton.gameObject.SetActive(viewModel.isDailyLlimit);
        
        var itemNum =  DataManager.Instance.Player.Item.GetCount(viewModel.master.gachaContentId);
        consumeItem.Setup(viewModel.master.gachaContentId, itemNum > 99999 ? "99999+" : itemNum.ToString());
        oneConsumeItem.Setup(viewModel.master.gachaContentId,"x1");
        tenConumeItem.Setup(viewModel.master.gachaContentId,"x10");
        paidConsumeItem.Setup(108000001,$"x{viewModel.master.dailyLimitCost}");
        
        foreach (var tab in _tabs)
        {
            tab.SetBtnAvtive(viewModel.id);
        }

        _index = 0;
        //var page = Instantiate(pagePrefab, this.pageContent, false);
        //characterObj.gameObject.SetActive(false);
        characterInfo.SetUpGachaInfo(viewModel.master.upIconIds[0],_model.closeAt,_model.master);
        // await pagePrefab.SetUpAsync(viewModel);
        // await pagelopplePrefab.SetUpAsync(_model,true,0,true);
        //gachaImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("Gacha/Character", _model.master.icon);
        await LoadSpriteAsync(_model.master);
    }

    void SetLoopPrefab(bool isLoop)
    {
        //pagePrefab.gameObject.SetActive(!isLoop);
        //pagelopplePrefab.gameObject.SetActive(isLoop);
    }

    public async UniTask ShowCharacrerInfo(GameObject o)
    {
        characterObj.gameObject.SetActive(true);
        SetLoopPrefab(true);
      
    }

    private void leftButtonOnclick()
    {
        if (_index > 0)
        {
            _index--;
            characterInfo.gameObject.SetActive(false);
            characterInfo.SetUpGachaInfo(_model.master.upIconIds[_index],_model.closeAt,_model.master);
            //pagePrefab.UpdataUpResource(_index);
            AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(_model.master); });
        }
    }

    private void rightButtonOnclick()
    {
        if (_index < _model.master.toggleUnClickImages.Count - 1)
        {
            _index++;
            characterInfo.gameObject.SetActive(false);
            characterInfo.SetUpGachaInfo(_model.master.upIconIds[_index],_model.closeAt,_model.master);
            //pagePrefab.UpdataUpResource(_index);
            AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(_model.master); });
        }
    }
    private async UniTask LoadSpriteAsync(GachaMaster master)
    {
        //gachaImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("Gacha/TitleIcon", master.icon);
        GameObject loadCharacter =
            await ResourceManager.Instance.LoadPrefabAndInstantiateAsync(
                $"Adventure/Objects/chara/{ master.toggleUnClickImages[_index]}");
        SkeletonAnimation skeletonAnimation = loadCharacter.GetComponent<SkeletonAnimation>();
        skeletonAnimation.Initialize(false);
        skeletonAnimation.Update(0.0f);
        skeletonAnimation.LateUpdate();

        mRTCamera.Setup(loadCharacter);
        gachaImage.texture = mRTCamera.GetRenderTexture();
        gachaImage.gameObject.SetActive(true);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mRTCamera != null)
        {
            mRTCamera.Dispose();
            mRTCamera = null;
        }
    }
}
public class UIGachaViewModelEvent: UnityEvent<UIGachaViewModel>
{
}
