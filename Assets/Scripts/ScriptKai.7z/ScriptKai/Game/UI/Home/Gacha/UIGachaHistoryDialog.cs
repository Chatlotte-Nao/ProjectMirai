﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIGachaHistoryDialog : UIDialogBase
{
    [SerializeField] private UIButton closeCtn;
    [SerializeField] private RectTransform itemContent;
    [SerializeField] private UIHomeGachaHistoryPanel cell;
    public ClickEvent OnCloseHistory => closeCtn.onClick;

    private List<UIHomeGachaHistoryPanel> panels = new List<UIHomeGachaHistoryPanel>();  
    public async UniTask SetupAsync(List<UIGachaHistoryViewModel> models)
    {
        foreach (var item in panels)
        {
            item.gameObject.SetActive(false);
        }
        if (models.Count > 0)
        {
            int index = 0;
            foreach (var data in models)
            {
                if (panels.Count > index)
                {
                    await panels[index].SetUpAsync(data);
                    panels[index].gameObject.SetActive(true);
                }
                else
                {
                    var button = Instantiate(cell, this.itemContent, false);
                    await button.SetUpAsync(data);
                    panels.Add(button);
                }
                index++;
            }
        }
       
    }
}
