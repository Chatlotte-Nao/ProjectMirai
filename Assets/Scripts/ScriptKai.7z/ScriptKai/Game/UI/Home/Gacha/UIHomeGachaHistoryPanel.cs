﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Base.Util;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeGachaHistoryPanel : MonoBehaviour
{
    // [SerializeField] UIHomeGachaResultCell iconCell;
    // [SerializeField] private RectTransform itemContent;
    [SerializeField] UIText gachaTypeText;
    [SerializeField] UIText nameText;
    [SerializeField] UIText dateText;
    private List<UIHomeGachaResultCell> panels = new List<UIHomeGachaResultCell>();
    public async UniTask SetUpAsync(UIGachaHistoryViewModel model)
    {
        //await iconCell.SetUpAsync(model.resultModel,gachaDrawItemType);
        //var character = DataManager.Instance.Master.BattleCharacter[model.resultModel.id].characterResourceId;
        //nameText.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER_NAME, model.resultModel.id.ToString());
        //gachaNameText.SetLabel(LocalizeManager.DATA_TYPE.GACHA, $"Gacha_Name{model.gachaMasterId}");
        dateText.SetRawText(GlobalTime.GetDateTime(model.createdAt).ToString());
        var gachaDrawItemType = DataManager.Instance.Master.GachaMaster[model.gachaMasterId].kind;
        gachaTypeText.SetLabel(LocalizeManager.DATA_TYPE.GACHA,$"Gacha_Type_Name{gachaDrawItemType}");
        switch ((GachaDrawItemType)gachaDrawItemType)
        {
            case GachaDrawItemType.Charater:
                //var resoure = DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[model.resultModel.id].characterResourceId];
                nameText.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER_NAME,model.resultModel.id.ToString());
                break;
            case GachaDrawItemType.Equipment:
                break;
            case GachaDrawItemType.Item:
                break;
        }
        // foreach (var panel in panels)
        // {
        //     panel.gameObject.SetActive(false);
        // }
        // if (model.resultModel.itemList.Count > 0)
        // {
        //     for (int i = 0; i < model.resultModel.itemList.Count; i++)
        //     {
        //         var item = model.resultModel.itemList[i];
        //         if (i < panels.Count)
        //         {
        //             await panels[i].SetUpAsync(item,gachaDrawItemType);
        //             panels[i].gameObject.SetActive(true);
        //         }
        //         else
        //         {
        //             var button = Instantiate(iconCell, this.itemContent, false);
        //             await button.SetUpAsync(item,gachaDrawItemType);
        //             panels.Add(button);
        //             button.gameObject.SetActive(true);
        //         }
        //     }
        //     
        // }
        //iconCell.gameObject.SetActive(false);
    }
}
