﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
public class UIHomeGachaResultCell : MonoBehaviour
{
   [SerializeField] private Image bgImage;
   [SerializeField] protected Image equipmentFrameImage = null;
   [SerializeField] private UITexture iconImage;
   //[SerializeField] private RarityIcon rarityIcon;
   [SerializeField] private GameObject converted;
   [SerializeField] private BaseItem[] convertedItems;
   [SerializeField] private Image maxRarityImage;
   [SerializeField] private GameObject[] stars;
   [SerializeField] private GameObject newObject;
   public async UniTask SetUpAsync(UIGachaResultViewModel model,GachaDrawItemType gachaDrawItemType)
   {
      bgImage.gameObject.SetActive(false);
      equipmentFrameImage.gameObject.SetActive(false);
      maxRarityImage.gameObject.SetActive(false);
      iconImage.gameObject.SetActive(false);
      converted.gameObject.SetActive(false);
      foreach (var convertedItem in convertedItems)
      {
         convertedItem.gameObject.SetActive(false);
      }
      if (gachaDrawItemType == GachaDrawItemType.Charater)
      {
         var resoure = DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[model.id].characterResourceId];
         //rarityIcon.SetRarity(DataManager.Instance.Master.BattleCharacter[model.id].initialRank, RarityIcon.RarityType.CHARACTER);
         //await iconImage.LoadAsync("CharacterMain/BgProfile", resoure.bgProfileName);
         var rank = DataManager.Instance.Master.BattleCharacter[model.id].initialRank;
         SetStarData(rank,model.isConverted);
         int index = 0;
         foreach (var converted in  model.converted)
         {
            convertedItems[index].gameObject.SetActive(true);
            convertedItems[index].Setup(converted.Key,$"x{converted.Value}");
            index++;
         }
         newObject.gameObject.SetActive(model.converted.Count<=0);
         bgImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("CharacterMain/GachaIcon", resoure.bgProfileName);
         //bgImage.sprite = ResourceManager.Instance.LoadSpriteSmall("FrameBg", $"frame_item_{DataManager.Instance.Master.BattleCharacter[model.id].rarity}");
         bgImage.gameObject.SetActive(true);
         maxRarityImage.gameObject.SetActive(rank == 3);
      }
      else  if (gachaDrawItemType == GachaDrawItemType.Equipment)
      {
         var master = DataManager.Instance.Master.Equipment[model.id];
         //rarityIcon.SetRarity(master.initialRank, RarityIcon.RarityType.CHARACTER);
         SetStarData(master.initialRank,false);
         //new
         AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(master); });
         //equipmentFrameImage.sprite = ResourceManager.Instance.LoadSpriteSmall("FrameBg", $"frame_equipment_small_{master.rarity}");
         await iconImage.LoadAsync("Equipment/Icons", master.iconId);
         converted.gameObject.SetActive(false);
         equipmentFrameImage.gameObject.SetActive(true);
      }
   }

   private void SetStarData(int rank,bool isConverted)
   {
      for (int i = 0; i < stars.Length; i++)
      {
         stars[i].SetActive(rank>i);
      }
      AsyncManager.Instance.StartAsync(LoadConverted(isConverted));
   }

   private async UniTask LoadConverted(bool isConverted)
   {
      await UniTask.DelayFrame(50);
      converted.gameObject.SetActive(isConverted);
   }

   private async UniTask LoadSpriteAsync(EquipmentMaster master)
    {
        equipmentFrameImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("FrameBg", $"frame_equipment_small_{master.rarity}");
    }
}
