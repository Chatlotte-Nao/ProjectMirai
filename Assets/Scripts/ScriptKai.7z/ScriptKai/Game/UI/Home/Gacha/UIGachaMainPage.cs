﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIGachaMainPage : UIPageBase
{
    UIGachaMainWindow mMainWindow = null;
    UIGachaResultWindow mResultWindow = null;
    UIHomeGachaMovieDialog mMovieDialog = null;
    UIGachaHistoryDialog mHistoryDialog = null;
    //UIGachaRameDialog mremeDialog = null;
    
    UIGachaListModel mGachaListModel = null;
    UIGachaResultModel mGachaResultModel = null;
    UIHomeHeaderParam headerParam = new UIHomeHeaderParam();
    UIHomeGachaMovieDialog mcharacterMovieDialog = null;
    private GachaDrawType gachaDrawType;
    private GachaDrawItemType gachaDrawItemType;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        if (mGachaListModel == null)
        {
            mGachaListModel = param as UIGachaListModel;
        }
        
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIGachaMainWindow, CanvasType.App0) as UIGachaMainWindow;
        mMainWindow.TabClick.GuardSubscribeAsync(ShowPageContent).AddTo(mSubscriptions);
        mMainWindow.OnOneButton.GuardSubscribeAsync(OneClick).AddTo(mSubscriptions);
        mMainWindow.OnTenButton.GuardSubscribeAsync(TenClick).AddTo(mSubscriptions);
        mMainWindow.OnPaidButton.GuardSubscribeAsync(PaidClick).AddTo(mSubscriptions);
        mMainWindow.OnHistoryButton.GuardSubscribeAsync(OnHistoryClick).AddTo(mSubscriptions);
        mMainWindow.OnClickBackButton.GuardSubscribeAsync(ShowMainMenu).AddTo(mSubscriptions); 
        await mMainWindow.SetupAsync(mGachaListModel);
        
        //Gacha Movie
        mMovieDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeGachaMovieDialog, CanvasType.App1) as UIHomeGachaMovieDialog;
        mMovieDialog.OnJump.GuardSubscribeAsync(ShowCommonDialog).AddTo(mSubscriptions);
        //Gacha Timeline
        // mremeDialog =  await UI.Dialog.CreateAsync(UIPrefabId.UIGachaRameDialog, CanvasType.App1) as UIGachaRameDialog;
        // mremeDialog.OnClick.GuardSubscribeAsync(ShowCommonDialog).AddTo(mSubscriptions);
        //Gacha Result
        mResultWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIGachaResultWindow, CanvasType.App1) as UIGachaResultWindow;
        mResultWindow.OnCloseClick.GuardSubscribeAsync(ClosePageBase).AddTo(mSubscriptions);
        mResultWindow.OnAgainBtutton.GuardSubscribeAsync(AgainClick).AddTo(mSubscriptions);
        //Gacha History
        mHistoryDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIGachaHistoryDialog, CanvasType.App1) as UIGachaHistoryDialog;
        mHistoryDialog.OnCloseHistory.GuardSubscribeAsync(OnCloseHistoryClick).AddTo(mSubscriptions);
        
        headerParam.showResType.Add(UIHeaderResType.GemPaid);
        headerParam.showResType.Add(UIHeaderResType.GemFree);
        headerParam.visiblePlayerStatus = false;
        headerParam.visibleIcon = false;
        headerParam.visibleRightRank = false;
        headerParam.visibleBack = true;
        headerParam.visibleNavigation = true;
        headerParam.visibleHome = true;
        headerParam.visibleItem = true;
        headerParam.conuitemIds.Add(115000001);
    }
    private async UniTask ShowMainMenu(GameObject o)
    {
        
        await UI.Page.CloseCurrentPage();
        // await UI.Page.ChangePage<UIHomeMainPage>();
    }
    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);

        await base.ShowAsync(showType);
        await mMainWindow.ShowAsync();
        await ShowPageContent(mGachaListModel.gachaList[0]);
    }
    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await mMainWindow.HideAsync();
    }
    public async UniTask ShowReme(GameObject o)
    {
        // var list = mGachaResultModel.itemList.Select(a => a.id).ToList();
        // await mremeDialog.SetupAsync(list,gachaDrawType,gachaDrawItemType);
        // await mMovieDialog.HideAsync();
        // await mremeDialog.ShowAsync();
    }

    public async UniTask ShowCommonDialog(GameObject o)
    {
        //await mremeDialog.HideAsync();
        await mMovieDialog.HideAsync();
        var list = mGachaResultModel.itemList.Select(a => a.id).ToList();
         if(gachaDrawItemType == GachaDrawItemType.Charater)
         {
             var firstIds = mGachaResultModel.GetFirstCharacterIds();
             var commonCharacterGetDialog = await UI.Dialog.CreateAsync(UIPrefabId.CommonCharacterGet, CanvasType.App2) as UICommonCharacterGetDialog;
             commonCharacterGetDialog.OnShowMoie.GuardSubscribeAsync(ShowMovie).AddTo(mSubscriptions);
             commonCharacterGetDialog.OnCloseClick.GuardSubscribeAsync(ShowResult).AddTo(mSubscriptions);
             commonCharacterGetDialog.SetupNewCharacterIds(firstIds);
             await commonCharacterGetDialog.Setup(list);
             await commonCharacterGetDialog.ShowAsync();
         }
         else
         {
             var  Equipment = await UI.Popup.ShowEquipmentGetPopupAsync(list);
             Equipment.OnCloseClick.GuardSubscribeAsync(ShowResult).AddTo(mSubscriptions);
         } 
     

    }
    public async UniTask ShowResult(GameObject o)
    {
        PxSoundManager.Instance.PlaySe("feedbackSE_draw_show01");
        await mResultWindow.Setup(mGachaResultModel,gachaDrawType,gachaDrawItemType,_viewModel.master.gachaContentId);
        await mResultWindow.ShowAsync();
  }

    UIGachaViewModel _viewModel;
    public async UniTask ShowPageContent(UIGachaViewModel viewModel)
    {
        if (_viewModel != null && viewModel.id == _viewModel.id) return;
        _viewModel = viewModel;
        await mMainWindow.LoadContent(viewModel);
    }

    private async UniTask AgainClick(GameObject o)
    {
        await StartDrawClick();
    }

    private async UniTask OneClick(GameObject o)
    {
        gachaDrawType = GachaDrawType.One;
        await StartDrawClick();
    }
    private async UniTask TenClick(GameObject o)
    {
        gachaDrawType = GachaDrawType.Ten;
        await StartDrawClick();
    }
    
    private async UniTask PaidClick(GameObject o)
    {
        // if (!GachaUtil.IsGachaContent(108000001, _viewModel.dailyLimitCost))
        if (!_viewModel.isDailyLlimit)
            return;
        gachaDrawType = GachaDrawType.DailyLimit;
        await StartDrawClick();
    }
    
    private async UniTask StartDrawClick()
    {
        int number = 0;
        long itemId = 0;
        string str = "";
        switch (gachaDrawType)
        {
            case GachaDrawType.One:
                itemId = _viewModel.master.gachaContentId;
                number = 1;
                str = "Item_Gacha_Number_Not";
                break;
            case GachaDrawType.Ten:
                itemId = _viewModel.master.gachaContentId;
                number = 10;
                str = "Item_Gacha_Number_Not";
                break;
            case GachaDrawType.DailyLimit:
                itemId = 108000001;
                number = _viewModel.master.dailyLimitCost;
                str = "item_Paid_Number_Not";
                break;
        }
        if (!GachaUtil.IsGachaContent(itemId, number))
        {
            if (gachaDrawType == GachaDrawType.DailyLimit)
            {
                UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.GACHA, "Item_Paid_Number_Not"));
                return;
            }

            var num =  number - DataManager.Instance.Player.Item.GetCount(itemId);
            var paidNumber = DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.GachaGemCost].data * num;
            var strr = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "GACHATICKET_PURCHASE_CONFIRM"),new object[] {paidNumber, num});
            UI.Popup.ShowConfirm(string.Empty, strr, CanvasType.App2, (r)=>
            {
                if (r == UIPopupDialog.Result.OK)
                {
                    if (DataManager.Instance.Player.Wallet.GetCount("FREE_STONE") >= paidNumber)
                    {
                        AsyncManager.Instance.StartAsync(ShowMovieDialog());
                    }
                    else
                    {
                        UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.GACHA, "Item_FREE_Number_Not"));
                    }
                }
            });
        }
        else
        {
            var itemName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ITEM, $"{itemId}_name");
            var strs = string.Format(
                LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "GACHA_CONFIRM_TICKET"),
                new object[] {itemName, number});
            UI.Popup.ShowConfirm(string.Empty, strs, CanvasType.App2, (r) =>
            {
                if (r == UIPopupDialog.Result.OK)
                {
                    AsyncManager.Instance.StartAsync(ShowMovieDialog());
                }
            });
        }
    }

    private async UniTask ShowMovieDialog()
    {
        Game.Sound.SoundPlayer.StopBgm();
        mGachaResultModel = await GachaService.GachaPurchase(_viewModel.id, gachaDrawType == GachaDrawType.Ten,
            gachaDrawType == GachaDrawType.DailyLimit);
        gachaDrawItemType = (GachaDrawItemType) _viewModel.master.kind;
        if (gachaDrawType == GachaDrawType.DailyLimit)
            _viewModel.isDailyLlimit = false;
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHeaderHide);
        var index = GachaUtil.GetGachalotteryIndex(mGachaResultModel, gachaDrawType,gachaDrawItemType);
        await mMovieDialog.ShowAsync();
        await mMovieDialog.SetUpAsync(_viewModel, false,index);
        await mMainWindow.HideAsync();
        await mResultWindow.HideAsync();
        
    }

    
    private async UniTask ShowMovie(string patch)
    {
        if (mcharacterMovieDialog == null)
        {
            mcharacterMovieDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeGachaMovieDialog, CanvasType.App2) as UIHomeGachaMovieDialog;
        }
        mcharacterMovieDialog.OnJump.GuardSubscribeAsync(CloseMovie).AddTo(mSubscriptions);
        await mcharacterMovieDialog.ShowAsync();
        await mcharacterMovieDialog.LoadDrawReadyVideoRoutine(patch,true);
    }
    private async UniTask CloseMovie(GameObject o)
    {
        if (mcharacterMovieDialog != null)
        {
            mcharacterMovieDialog.Dispose();
            mcharacterMovieDialog = null;
        }
    }

    private async UniTask OnHistoryClick(GameObject o)
    {
        var histories = await GachaService.GachaGetHistories();
        await mHistoryDialog.ShowAsync();
        await mHistoryDialog.SetupAsync(histories);
    }
    private async UniTask OnCloseHistoryClick(GameObject o)
    {
        await mHistoryDialog.HideAsync();
    }
    public async UniTask ClosePageBase(GameObject o)
    {
        Game.Sound.SoundPlayer.PlayBgm("M025");
        SignalBus.GlobalSignal.Dispatch<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, headerParam);
        await mMainWindow.ShowAsync();
        await mMainWindow.LoadContent(_viewModel);
        await mResultWindow.HideAsync();
    }
    public override void Dispose()
    {
        base.Dispose();
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }

        if (mMovieDialog != null)
        {
            mMovieDialog.Dispose();
            mMovieDialog = null;
        }
        if (mHistoryDialog != null)
        {
            mHistoryDialog.Dispose();
            mHistoryDialog = null;
        }

        if (mResultWindow != null)
        {
            mResultWindow.Dispose();
            mResultWindow = null;
        }

        // if (mremeDialog != null)
        // {
        //     mremeDialog.Dispose();
        //     mremeDialog = null;
        // }
    }
}

