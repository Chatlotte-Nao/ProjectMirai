﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Playables;
using Spine.Unity;
using System.Linq;
using UnityEngine.UI;
public class UIGachaRameDialog : UIDialogBase
{
    [SerializeField] PlayableDirector playableDirectors = null;
    [SerializeField] List<UIGachaRameCell> _rameCells;
    [SerializeField] UIButton clickHandler;
    public ClickEvent OnClick = new ClickEvent();
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        clickHandler.OnTouchUpInside.GuardSubscribeAsync(OnClickScreen).AddTo(mSubscriptions);
    }

    public async UniTask SetupAsync(List<long> characterIds,GachaDrawType gachaDrawType,GachaDrawItemType gachaDrawItemType)
    {
        foreach (var rameCell in _rameCells)
        {
            rameCell.gameObject.SetActive(false);
        }
        if (gachaDrawType == GachaDrawType.Ten)
        {
            for (int i = 0; i < _rameCells.Count; i++)
            {
                await _rameCells[i].SetupAsync(characterIds[i],gachaDrawItemType);
                _rameCells[i].gameObject.SetActive(true);
            }
        }
        else
        {
            await _rameCells[2].SetupAsync(characterIds[0],gachaDrawItemType);
            _rameCells[2].gameObject.SetActive(true);
        }
        playableDirectors.time = 0;
        playableDirectors.Play();
    }
    private async UniTask OnClickScreen()
    {
        if (playableDirectors.time < 2.0f)
        {
            playableDirectors.time = playableDirectors.duration;
        }
        else
        {
            OnClick.Invoke(this.gameObject);
        }
    }

}
