﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using ExploreBattleZone;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class UIHomeHeader : UIDialogBase
{
    [SerializeField] UIButton popupMapButton;
    [SerializeField] UserIcon userIcon;
    [SerializeField] GameObject playerIcon;
    [SerializeField] UIButton profileButton;
    [SerializeField] GameObject backButton;
    [SerializeField] UIButton backButtonRaw;
    [SerializeField] UIButton homeButton;
    [SerializeField] UIButton navigationButton;
    [SerializeField] GameObject menuButton;
    [SerializeField] GameObject playerStatus;
    [SerializeField] RankIcon leftRank;
    [SerializeField] RankIcon rightRank;

    [SerializeField] UIText playerName;
    [SerializeField] UIHeaderResource[] headerResources;

    [SerializeField] private UIHeaderResource heradePrefab;
    [SerializeField] private RectTransform heradeRectTransform;

  
    
    private Dictionary<UIHeaderResType, UIHeaderResource> headerResDict =
        new Dictionary<UIHeaderResType, UIHeaderResource>();

    private long mStaminaNextUpdateTime = -1;
    private CanvasGroup canvasGroup;

    // public ClickEvent OnHomeButton => homeButton.onClick;
    // ReSharper disable Unity.PerformanceAnalysis
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        canvasGroup ??= GetComponent<CanvasGroup>();
        backButtonRaw.onClick.GuardSubscribeAsync(OnClickBackAsync).AddTo(mSubscriptions);
        profileButton.onClick.GuardSubscribeAsync(OnClickProfile).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe<UIHomeHeaderParam>(UIEventId.UIHomeHeaderUpdate, RefreshLayout)
            .AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe(UIEventId.UIHeaderInfoUpdate, refreshInfo).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe(UIEventId.UIHeaderHide, Hide).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe(UIEventId.UIHeaderShowNavigationGroup, ShowNavigationGroup)
            .AddTo(mSubscriptions);

        homeButton.OnTouchUpInside.GuardSubscribeAsync(onClickHome).AddTo(mSubscriptions);
        navigationButton.OnTouchUpInside.GuardSubscribeAsync(onClickNavigation).AddTo(mSubscriptions);

        foreach (var hr in headerResources)
        {
            headerResDict.Add(hr.resType, hr);
        }
        

        headerResDict[UIHeaderResType.Stamina].OnClick.GuardSubscribeAsync(onClickAddStamina).AddTo(mSubscriptions);

        headerResDict[UIHeaderResType.Stamina].OnIconClick.Subscribe(async (o) => { await onClickShowInfoPopup(110000001); })
            .AddTo(mSubscriptions);
        headerResDict[UIHeaderResType.Coin].OnIconClick.Subscribe(async(o) => {await onClickShowInfoPopup(106000001); })
            .AddTo(mSubscriptions);
        headerResDict[UIHeaderResType.GemFree].OnIconClick.Subscribe(async(o) => {await onClickShowInfoPopup(107000001); })
            .AddTo(mSubscriptions);
        headerResDict[UIHeaderResType.GemPaid].OnIconClick.Subscribe(async(o) => { await onClickShowInfoPopup(108000001); })
            .AddTo(mSubscriptions);
        refreshInfo();
    }

    
    async UniTask onClickHome()
    {
        
        canvasGroup.alpha = 0;
        canvasGroup.blocksRaycasts = false;
        var t = MapSceneManager.Instance.CurrentType;
        switch (t)
        {
            case MapSceneManager.SceneType.None:
                break;
            case MapSceneManager.SceneType.Home:
                await UI.Page.OpenPage<UIHomeSubPage>();
                break;
            case MapSceneManager.SceneType.Adv:
                await UI.Page.OpenPage<UIMapAdvPage>();
                break;
            case MapSceneManager.SceneType.Dungeon:
                break;
            case MapSceneManager.SceneType.Explore:
                await UI.Page.OpenPage<UIExplorePage>();
                break;
            case MapSceneManager.SceneType.BattleZone:                
                await UI.Page.OpenPage<UIMapBattleZonePage>();
                break;
            case MapSceneManager.SceneType.Underground:                
                await UI.Page.OpenPage<UIMapUndergroundPage>();
                break;
            case MapSceneManager.SceneType.Tutorial:
                break;
        }
        MapSceneManager.Instance.CurrentScene.GetCameraController().GetVirtualCameraManager().ZoomPlayer(false,0.6f);

    }

    async void ShowNavigationGroup()
    {
        navigationButton.gameObject.SetActive(true);
        homeButton.gameObject.SetActive(true);
    }


    async UniTask onClickNavigation()
    {
        var dialog =
            await UI.Dialog.CreateAsync(UIPrefabId.UIHomeNavigationWindow, CanvasType.App1) as UIHomeNavigationWindow;
        await dialog.SetUpOutSide();
        await dialog.ShowAsync(UIPageShowType.Front);
        await dialog.OpenNavigationGroupOutSide();
    }

    private async UniTask OnClickBackAsync(GameObject o)
    {
        await UI.Page.CloseCurrentPage();
        ((HomeMapLogic)MapSceneManager.Instance.CurrentLogic).UpdateCharacterInfo();
        if (MapSceneManager.Instance.CurrentScene.gameObject.activeSelf)
        {
            MapSceneManager.Instance.HideCurrent();
            MapSceneManager.Instance.ShowCurrent();
        }
        

    }

    private async UniTask OnClickProfile(GameObject o)
    {
        await UI.Page.OpenPage<UIHomeProfilePage>();
    }

    public void SetToDefault()
    {
        playerIcon.SetActive(false);
        menuButton.SetActive(false);
        backButton.SetActive(false);
        playerStatus.SetActive(false);
        rightRank.gameObject.SetActive(false);
        navigationButton.gameObject.SetActive(false);
        homeButton.gameObject.SetActive(false);
        foreach (var item in headerResDict)
        {
            item.Value.gameObject.SetActive(true);
        }
    }

    public void RefreshLayout(UIHomeHeaderParam param)
    {
//        Log.Info("refresh layout");
        if (menuButton == null)
            return;
        playerIcon.SetActive(param.visibleIcon);
        menuButton.SetActive(param.visibleMenu);
        backButton.SetActive(param.visibleBack);
        navigationButton.gameObject.SetActive(param.visibleNavigation && CommonUtil.IsFunctionUnlock(38));
        homeButton.gameObject.SetActive(param.visibleHome);
        //playerStatus.SetActive(param.visiblePlayerStatus);


        canvasGroup.alpha = 1;
        canvasGroup.blocksRaycasts = true;
        rightRank.gameObject.SetActive(param.visibleRightRank);

        foreach (var item in headerResDict)
        {
            item.Value.gameObject.SetActive(param.showResType.Contains(item.Key));
        }

        if (param.visibleItem)
        {
            RefreshItemInfo(param.conuitemIds);
        }
        else
        {
            foreach (var item in itemResource)
            {
                item.gameObject.SetActive(false);
            }
        }


        Show();
    }

    private void refreshInfo()
    {
        playerName.SetRawText(DataManager.Instance.Player.Player.GetData().Name);

        headerResDict[UIHeaderResType.Stamina].SetText(string.Format("{0}/{1}",
            DataManager.Instance.Player.Player.GetCurrentStaimina(),
            DataManager.Instance.Master.PlayerLevel[DataManager.Instance.Player.Player.GetLevel()].staminaLimit));
        headerResDict[UIHeaderResType.Coin]
            .SetText(DataManager.Instance.Player.Wallet.GetCount("GAME_MONEY").ToString());
        headerResDict[UIHeaderResType.GemFree]
            .SetText(DataManager.Instance.Player.Wallet.GetCount("FREE_STONE").ToString());
        headerResDict[UIHeaderResType.GemPaid]
            .SetText(DataManager.Instance.Player.Wallet.GetCount("PAID_STONE").ToString());

        mStaminaNextUpdateTime = DataManager.Instance.Player.Player.GetNextStaminaUpdateTime();

        long remainExp = DataManager.Instance.Player.Player.GetRemainExp();
        int lv = DataManager.Instance.Player.Player.GetLevel();

        var fill = 0f;
        if (DataManager.Instance.Master.PlayerLevel.ContainsKey(lv + 1))
        {
            fill = (float) remainExp / DataManager.Instance.Master.PlayerLevel[lv + 1].exp;
        }

        leftRank.Set(lv, fill);
        rightRank.Set(lv, fill);


        //userIcon.Setup(DataManager.Instance.Player.Player.GetData().ProfileIconFrame, DataManager.Instance.Player.Player.GetData().ProfileIconId);
        foreach (var shopItem in itemResource)
        {
            if (shopItem.gameObject.activeSelf)
            {
                shopItem.UptateItemValue();
            }
        }
    }
    
    void Update()
    {
        if (mStaminaNextUpdateTime > 0 && GlobalTime.UtcNow.ToUnixTimeSeconds() >= mStaminaNextUpdateTime)
        {
            headerResDict[UIHeaderResType.Stamina].SetText(string.Format("{0}/{1}",
                DataManager.Instance.Player.Player.GetCurrentStaimina(),
                DataManager.Instance.Master.PlayerLevel[DataManager.Instance.Player.Player.GetLevel()].staminaLimit));
            mStaminaNextUpdateTime = DataManager.Instance.Master
                .GlobalConfig[TakashoUtil.GlobalConfigID.StaminaRecoveryCycle].data;
        }
       
    }

    
    public void Hide()
    {
        gameObject.SetActive(false);
    }


    private async UniTask onClickAddStamina()
    {
        //TODO xzf TT版本不要这个
        //await UI.Dialog.CreateAndShowAsync(UIPrefabId.StaminaRecover, CanvasType.App2);
        var transform = headerResDict[UIHeaderResType.Stamina].gameObject.GetComponent<RectTransform>();
        await UI.Dialog.CreateAsync(UIPrefabId.UIStaminaTimeDialog,  transform);
    }

    
    private async UniTask onClickShowInfoPopup(long itemId)
    {
        await UI.Popup.ShowItemInfoPopupAsync(itemId, false);
    }

    private List<UIHeaderResource> itemResource = new List<UIHeaderResource>();

    private void RefreshItemInfo(List<long> itemIds)
    {
        foreach (var item in itemResource)
        {
            item.gameObject.SetActive(false);
        }

        int index = 0;
        foreach (var itemid in itemIds)
        {
            switch (itemid)
            {
                case 110000001:
                    headerResDict[UIHeaderResType.Stamina].gameObject.SetActive(true);
                    break;
                case 106000001:
                    headerResDict[UIHeaderResType.Coin].gameObject.SetActive(true);
                    break;
                case 107000001:
                    headerResDict[UIHeaderResType.GemFree].gameObject.SetActive(true);
                    break;
                case 108000001:
                    headerResDict[UIHeaderResType.GemPaid].gameObject.SetActive(true);
                    break;
                default:
                    if (index < itemResource.Count)
                    {
                        itemResource[index].SetIconImage(itemid);
                        itemResource[index].gameObject.SetActive(true);
                    }
                    else
                    {
                        var cell = Instantiate(heradePrefab, heradeRectTransform);
                        cell.transform.SetSiblingIndex(0);
                        cell.SetIconImage(itemid);
                        cell.gameObject.SetActive(true);
                        itemResource.Add(cell);
                    }

                    break;
            }
        }

        Show();
    }
}


public sealed class UIHomeHeaderParam
{
    /// <summary>メニューボタン表示フラグ</summary>
    public bool visibleMenu = false;

    /// <summary>Back ボタン表示フラグ</summary>
    public bool visibleBack = false;

    /// <summary>Navigation ボタン表示フラグ</summary>
    public bool visibleNavigation = false;

    /// <summary>visibleHome ボタン表示フラグ</summary>
    public bool visibleHome = false;

    /// <summary>プレイヤーアイコン表示フラグ</summary>
    public bool visibleIcon = false;

    /// <summary>プレイヤーステータス表示フラグ</summary>
    public bool visiblePlayerStatus = false;

    /// <summary>ランク表示フラグ</summary>
    public bool visibleRightRank = false;

    public bool visibleItem = false;
    public List<UIHeaderResType> showResType = new List<UIHeaderResType>();
    public List<long> conuitemIds = new List<long>();

    public readonly static UIHomeHeaderParam Default = new UIHomeHeaderParam()
    {
        visibleBack = false,
        visibleNavigation = false,
        visibleHome = false,
        visibleIcon = false,
        visiblePlayerStatus = false,
        visibleRightRank = false,
        visibleItem = false,
        showResType = new List<UIHeaderResType>()
            {UIHeaderResType.Coin, UIHeaderResType.Stamina, UIHeaderResType.GemFree, UIHeaderResType.GemPaid},
    };
}