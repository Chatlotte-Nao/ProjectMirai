using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Battle.Unity.BattleUI;
using DG.Tweening;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.EventSystems;

public class UITutorialGoalDialog : UIDialogBase
{
    [SerializeField] private RectTransform cellsRectTransform;
    [SerializeField] private UITutorialGoalCell goalCellPrefab;
    private Dictionary<int, UITutorialGoalCell> cellList = new Dictionary<int, UITutorialGoalCell>();

    // private UITutorialGoalCell selectCell;
    // private UITutorialGoalCell oldCell;
    private TutorialGoalMaster goalMaster;

    private int goalMasterId;

    private int goalMasterId_ = 0;
    private UIMapNavigationDialog mNavi = null; 

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        mNavi = await UI.Dialog.CreateAsync(UIPrefabId.UIMapNavigationDialog, CanvasType.BG) as UIMapNavigationDialog;
        mNavi.SetTutorial();
        mNavi.OnEndGoal(true);
        await mNavi.ShowAsync();
        SignalBus.GlobalSignal.Subscribe(UIEventId.MapSceneChanged, OnMapChanged).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe(UIEventId.MapTriggerEnter, OnMapTriggerEnter).AddTo(mSubscriptions);
        //SignalBus.GlobalSignal.Subscribe<int>(UIEventId.ExploreAdvNavi, OnClickGoal).AddTo(mSubscriptions);
        UI.Dialog.OnDialogShow.Subscribe(OnDialogShow).AddTo(mSubscriptions);
        
    }
    public void SetRectTransformActive(bool isActive)
    {
        cellsRectTransform.gameObject.SetActive(isActive);
    }

    public async UniTask SetUpAsync(int goalMasterId)
    {
        //Log.Debug("播放新加动画");
        isReturn = false;
        goalMaster = DataManager.Instance.Master.TutorialGoalMaster[goalMasterId];
        //var cell = Instantiate(goalCellPrefab, cellsRectTransform);
        goalCellPrefab.SetUp(goalMasterId);
        goalCellPrefab.OnClick.RemoveAllListeners();
        goalCellPrefab.OnClick.SubscribeAsync(async (_) => await SelectGoal(goalMasterId)).AddTo(mSubscriptions);
        goalCellPrefab.gameObject.SetActive(true);
        goalCellPrefab.PlayNewAnimation();
        
        isFirstAuto = DataManager.Instance.Master.TutorialGoalMaster[goalMasterId].isAuto;
        await SelectGoal(goalMasterId);
       
    }

    private bool isReturn = false;
    private bool isFirstAuto = false;
    private async UniTask SelectGoal(int masterId)
    {
        goalMasterId_ = masterId;
        if (isReturn) return;
        if (goalMasterId_ > 0)
        {
            isReturn = true;
            await OnClickGoal(goalMasterId_);
        }
    }

    void OnMapChanged()
    {
        isReturn = false;
        if (goalMasterId_ > 0)
            this.updateNavi();
    }

    void OnDialogShow(string dialogName)
    {
        if (goalMaster != null && goalMaster.exitCondType == 2 && goalMaster.exitCond == dialogName)
        {
            AsyncManager.Instance.StartAsync(FinishCurrent());
        }
    }

    void OnMapTriggerEnter()
    {
        if (goalMaster != null && goalMaster.exitCondType == 1)
        {
            AsyncManager.Instance.StartAsync(FinishCurrent());
        }
    }

    private async UniTask FinishCurrent()
    {
        await SelectGoal(goalMasterId);
        SignalBus.GlobalSignal.Dispatch<bool>(UIEventId.MapNaviState, false);
        goalCellPrefab.PlayCompletedAnimation();
        await UniTask.DelayFrame(15);
        goalCellPrefab.gameObject.SetActive(false);
        TutorialManager.Instance.FinishCurrentTutorialStep();
    }

    async UniTask OnClickGoal(int goalId)
    {
        if (goalMasterId == goalId)
        {
            SignalBus.GlobalSignal.Dispatch<bool>(UIEventId.MapNaviState, false);
            goalMasterId = 0;
            isReturn = false;
            return;
        }

        goalMasterId = goalId;
        updateNavi();
    }

    private bool isTrigger_;
    public bool IsTrigger => isTrigger_;
    public void updateNavi()
    {
        if (goalMasterId <= 0 || MapSceneManager.Instance.CurrentScene==null)
            return;
        mNavi.OnEndGoal(false);
        var label = MapSceneManager.Instance.CurrentScene.label;
        var master = DataManager.Instance.Master.TutorialGoalMaster[goalMasterId];
        int index = 0;
        string goalRouteValue = "";
        bool isEnd = false;
        int endGoalMasterId = master.exitCondType == 1 ? int.Parse(master.exitCond) : 0;
        TutorialGoalRouteMaster routeMaster = null;
        foreach (var goalRouteData in master.goalRouteDatas)
        {
            var str = goalRouteData.Split(":");
            goalRouteValue = str[1];
            var route = DataManager.Instance.Master.TutorialGoalRouteMaster[int.Parse(str[0])];
            if (route.Location == label)
            {
                routeMaster = route;
                break;
            }
            index++;
        }

        if (routeMaster == null)
        {
            isReturn = false;
            isTrigger_ = false;
            SignalBus.GlobalSignal.Dispatch<bool>(UIEventId.MapNaviState, false);
            return;
        }
        Vector3 targetPosition = Vector3.zero;
        switch (routeMaster.postionType)
        {
            case "Room":
                var rooms = MapSceneManager.Instance.CurrentScene.rooms;
                if (rooms.ContainsKey(goalRouteValue))
                {
                    targetPosition = rooms[goalRouteValue].GetPlayerWaitPostion();
                }
                else
                {
                    Log.Error($"<color=green>Patch Error:</color> Rooms not find {goalRouteValue}");
                }

                break;
            case "ChangeButton":
                var changeButtons = MapSceneManager.Instance.CurrentScene.changeButtons;
                if (changeButtons.ContainsKey(int.Parse(goalRouteValue)))
                {
                    targetPosition = changeButtons[int.Parse(goalRouteValue)].GetPlayerWaitPostion();
                }
                else
                {
                    Log.Error($"<color=green>Patch Error:</color> ChangeButton not find {int.Parse(goalRouteValue)}");
                }
                break;
            case "Point":
                var points = MapSceneManager.Instance.CurrentScene.routePoints;
                if (points.ContainsKey(goalRouteValue))
                {
                    targetPosition = points[goalRouteValue].transform.position;
                }
                else
                {
                    Log.Error($"<color=green>Patch Error:</color> points not find {goalRouteValue}");
                }
                break;
            case "Character":
                var characters = MapSceneManager.Instance.CurrentScene.characters;
                if (characters.ContainsKey(int.Parse(goalRouteValue)))
                {
                    SignalBus.GlobalSignal.Dispatch<bool>(UIEventId.SwitchExploreCommandPage, true);
                    targetPosition = characters[int.Parse(goalRouteValue)].transform.position;
                }
                else
                {
                    Log.Error($"<color=green>Patch Error:</color> Character not find {int.Parse(goalRouteValue)}");
                }
                break;
            case "MapObject":
                var mapObjects = MapSceneManager.Instance.CurrentScene.staticObjects;
                if (mapObjects.ContainsKey(goalRouteValue))
                {
                    targetPosition = mapObjects[goalRouteValue].transform.position;
                }
                else
                {
                    Log.Error($"<color=green>Patch Error:</color> mapObjects not find {goalRouteValue}");
                }
                break;
        }
        isTrigger_ = true;
        if (isFirstAuto)
        {
            SignalBus.GlobalSignal.Dispatch(UIEventId.MapNaviState, true);
        }
        else
        {
            isFirstAuto = true;
        }
        SignalBus.GlobalSignal.Dispatch(UIEventId.MapNaviTarget, targetPosition);
        if (routeMaster.postionType == "Room")
        {
            var interactive =
                DataManager.Instance.Master.InteractiveButtonMaster.FirstOrDefault(a =>
                    a.Value.roomLabel == goalRouteValue).Value;
            if(interactive !=null)
                goalRouteValue = interactive.interactiveTargetId;
        }

        SignalBus.GlobalSignal.Dispatch(UIEventId.GoalTriggerMaster, goalRouteValue);

        if (endGoalMasterId == routeMaster.id)
        {
            if (routeMaster.postionType == "ChangeButton")
            {
                SignalBus.GlobalSignal.Dispatch(UIEventId.GoalEndTriggerChangeButton,int.Parse(goalRouteValue));
            }
            else
            {
                mNavi.OnEndGoal(true);
                SignalBus.GlobalSignal.Dispatch(UIEventId.GoalEndTriggerEnter, true);
            }
        }
        isReturn = false;
    }

    public override void Dispose()
    {
        base.Dispose();

        if (mNavi != null)
        {
            mNavi.Dispose();
            mNavi = null;
        }
    }
}