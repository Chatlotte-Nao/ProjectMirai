﻿using System.Collections;
using System.Collections.Generic;
using Battle.Unity.BattleUI;
using DG.Tweening;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Cysharp.Threading.Tasks.Triggers;
using UnityEngine.EventSystems;

public class  UITutorialOperationDialog : UIDialogBase
{
    [SerializeField] RectTransform focusMask;
    [SerializeField] UIButton screenBtn;
    [SerializeField] RectTransform arrow;
    [SerializeField] RectTransform pointerEffect;
    [SerializeField] UIText infoText;
    [SerializeField] RectTransform infoTextGroup;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        IgnoreTimeScale(arrow.gameObject);

    }

    private void IgnoreTimeScale(GameObject go)
    {
        ParticleSystem[] particles = go.GetComponentsInChildren<ParticleSystem>(true);
        foreach (var particle in particles)
        {
            var mainModule = particle.main;
            mainModule.useUnscaledTime = true; //关键代码
        }
    }

    public void SetupArrowOrEddectActive(int type)
    {
        switch (type)
        {
            case 1:
                arrow.gameObject.SetActive(true);
                pointerEffect.gameObject.SetActive(false);
                break;
            case 2:
                arrow.gameObject.SetActive(false);
                pointerEffect.gameObject.SetActive(true); 
                break;
            default:
                arrow.gameObject.SetActive(true);
                pointerEffect.gameObject.SetActive(true); 
                break;
        }
    }

    public void SetupText(string labelId, int positionType)
    {
        if (positionType == -1)
        {
            infoTextGroup.gameObject.SetActive(false);
            return;
        }
        infoTextGroup.gameObject.SetActive(true);
        infoText.SetLabel(LocalizeManager.DATA_TYPE.TUTORIAL, labelId);
        switch (positionType)
        {
            case 1:
                infoTextGroup.pivot = new Vector2(0.5f,1);
                infoTextGroup.anchorMin = new Vector2(0.5f,1);
                infoTextGroup.anchorMax = new Vector2(0.5f,1);
                infoTextGroup.anchoredPosition = Vector2.zero;
                break;
            case 2:
                infoTextGroup.pivot = new Vector2(0.5f,0);
                infoTextGroup.anchorMin = new Vector2(0.5f,0);
                infoTextGroup.anchorMax = new Vector2(0.5f,0);
                infoTextGroup.anchoredPosition = Vector2.zero;
                break;
            // 3: 指挥棒左上 4: 指挥棒左下 5:指挥棒右上 6:指挥棒右下
            case 3:
                infoTextGroup.pivot = new Vector2(1,0);
                infoTextGroup.anchorMin = new Vector2(0.5f,0.5f);
                infoTextGroup.anchorMax = new Vector2(0.5f,0.5f);
                infoTextGroup.anchoredPosition = arrow.anchoredPosition+new Vector2(-100,100);
                break;
            case 4:
                infoTextGroup.pivot = new Vector2(1,1);
                infoTextGroup.anchorMin = new Vector2(0.5f,0.5f);
                infoTextGroup.anchorMax = new Vector2(0.5f,0.5f);
                infoTextGroup.anchoredPosition = arrow.anchoredPosition+new Vector2(-100,-100);
                break;
            case 5:
                infoTextGroup.pivot = new Vector2(0,0);
                infoTextGroup.anchorMin = new Vector2(0.5f,0.5f);
                infoTextGroup.anchorMax = new Vector2(0.5f,0.5f);
                infoTextGroup.anchoredPosition = arrow.anchoredPosition+new Vector2(100,100);
                break;
            case 6:
                infoTextGroup.pivot = new Vector2(0,1);
                infoTextGroup.anchorMin = new Vector2(0.5f,0.5f);
                infoTextGroup.anchorMax = new Vector2(0.5f,0.5f);
                infoTextGroup.anchoredPosition = arrow.anchoredPosition+new Vector2(100,-100);
                break;
            default:
                break;
        }
    }

    public void SetupButtonOffset(Vector2 offset)
    {
        var screenBtnRect = screenBtn.GetComponent<RectTransform>();
        screenBtnRect.DOPause();
        screenBtnRect.anchoredPosition = focusMask.anchoredPosition+offset;
        if (screenBtnRect.anchoredPosition.x > 0)
        {
            if (screenBtnRect.anchoredPosition.y >= 0)
            {
                screenBtnRect.localRotation = Quaternion.Euler(0,0,-45);
            }
            else
            {
                screenBtnRect.localRotation = Quaternion.Euler(0,0,-135);
            }
        }
        else
        {
            if (screenBtnRect.anchoredPosition.y >= 0)
            {
                screenBtnRect.localRotation = Quaternion.Euler(0,0,45);
            }
            else
            {
                screenBtnRect.localRotation = Quaternion.Euler(0,0,135);
            }
        }
    }

    public void SetupArrowOffset(Vector2 offset)
    {
        arrow.DOPause();
        arrow.anchoredPosition = focusMask.anchoredPosition+offset;
        if (arrow.anchoredPosition.x > 0)
        {
            if (arrow.anchoredPosition.y >= 0)
            {
                arrow.localRotation = Quaternion.Euler(0,0,-45);
            }
            else
            {
                arrow.localRotation = Quaternion.Euler(0,0,-135);
            }
        }
        else
        {
            if (arrow.anchoredPosition.y >= 0)
            {
                arrow.localRotation = Quaternion.Euler(0,0,45);
            }
            else
            {
                arrow.localRotation = Quaternion.Euler(0,0,135);
            }
        }
        //arrow.localRotation = Quaternion.Euler(0,0,Mathf.Atan2(arrow.anchoredPosition.y, arrow.anchoredPosition.x)*Mathf.Rad2Deg-90);
        // arrow.GetComponentInChildren<Animator>().enabled = true;
    }

    public void SetupArrowMove(Vector2 from, Vector2 to)
    {
        arrow.DOPause();
        arrow.anchoredPosition = focusMask.anchoredPosition+from;
        arrow.localRotation = Quaternion.identity;
        arrow.DOLocalMove(focusMask.anchoredPosition + to, 1f).SetLoops(-1, LoopType.Restart);
        arrow.GetComponentInChildren<Animator>().enabled = false;
    }

    public void SetupForPointer(GameObject panel, string buttonName)
    {

        var button = panel.transform.Find(buttonName);
        if (button == null)
        {
            Log.Error($"<color=green>Patch Error:</color> {panel.name} not find {buttonName}");
            return;
        }

        focusMask.gameObject.SetActive(false);
        screenBtn.gameObject.SetActive(true);
        pointerEffect.gameObject.SetActive(false);

        var buttonRect = button.GetComponent<RectTransform>();

        SetFocusPosition(buttonRect);


        screenBtn.OnTouchUpInside.Subscribe(OnClickTarget).AddTo(mSubscriptions);
    }

    public void SetupForPointerMapObject(GameObject target)
    {
        focusMask.gameObject.SetActive(false);
        screenBtn.gameObject.SetActive(true);
        pointerEffect.gameObject.SetActive(false);
        

        SetFocusPosition3D(target.GetComponentInChildren<Renderer>().bounds.center);


        screenBtn.OnTouchUpInside.Subscribe(OnClickTarget).AddTo(mSubscriptions);
    }

    public void SetupForButton(GameObject panel, string buttonName)
    {
        var button = panel.transform.Find(buttonName);
        if (button == null)
        {
            Log.Error($"<color=green>Patch Error:</color> {panel.name } not find  { buttonName}");
            return;
        }
        var buttonRect = button.GetComponent<RectTransform>();
        SetupForButton(buttonRect, buttonRect.gameObject);
    }

    public void SetupForButton(RectTransform buttonRect, GameObject btnGo)
    {
        
        focusMask.gameObject.SetActive(true);
        screenBtn.gameObject.SetActive(false);
        pointerEffect.gameObject.SetActive(false);
        SetFocusPosition(buttonRect);
        SetClickTarget(btnGo);
    }

    public void SetupForClickMapObject(GameObject target)
    {
        focusMask.gameObject.SetActive(true);
        screenBtn.gameObject.SetActive(false);
        pointerEffect.gameObject.SetActive(false);
        

        SetFocusPosition3D(target.GetComponentInChildren<Renderer>().bounds.center);
        SetClickTarget3D(target);
    }

    public void SetupForClickMapRoom(EventTrigger target)
    {
        focusMask.gameObject.SetActive(true);
        screenBtn.gameObject.SetActive(false);
        pointerEffect.gameObject.SetActive(false);
        

        SetFocusPosition3D(target.transform.position);
        SetClickMoveTarget(target);
    }

    public void SetupForSwitchPosition(RectTransform switchPositionRect, GameObject castBoardGo, int characterMasterID, int position)
    {
        
        focusMask.gameObject.SetActive(true);
        screenBtn.gameObject.SetActive(false);
        pointerEffect.gameObject.SetActive(false);
        SetFocusPosition(switchPositionRect);
        pointerEffect.gameObject.SetActive(false);
        
        SwitchPositionRayCastBoard castBoard = castBoardGo.GetComponent<SwitchPositionRayCastBoard>();
        castBoard.switchEvent.Subscribe(
            (int masterid, int pos) =>
            {
                if (characterMasterID == masterid && position == pos)
                {
                    OnClickTarget();
                }
            }
        ).AddTo(mSubscriptions);
    }

    public void SetupForSelectCharacter(RectTransform switchPositionRect, GameObject castBoardGo, int characterMasterID, int position)
    {
        
        focusMask.gameObject.SetActive(true);
        screenBtn.gameObject.SetActive(false);
        pointerEffect.gameObject.SetActive(false);
        SetFocusPosition(switchPositionRect);
        pointerEffect.gameObject.SetActive(false);
        
        SelectCharacterRayCastBoard castBoard = castBoardGo.GetComponent<SelectCharacterRayCastBoard>();
        castBoard.addCharacterEvent.Subscribe(
            (int masterid, int pos) =>
            {
                if (characterMasterID == masterid && position == pos)
                {
                    OnClickTarget();
                }
            }
        ).AddTo(mSubscriptions);
    }

    public void SetupForChild(GameObject panel, string parentName, int idx)
    {

        var parent = panel.transform.Find(parentName);
        if (parent == null)
        {
            Log.Error($"<color=green>Patch Error:</color> {panel.name } not find  { parentName } idx {idx}");
            return;
        }

        focusMask.gameObject.SetActive(true);
        screenBtn.gameObject.SetActive(false);
        pointerEffect.gameObject.SetActive(false);

        
        RectTransform buttonRect = null;

        if (idx >= 0)
        {
            buttonRect = parent.GetChild(idx).GetComponent<RectTransform>();
        }
        else
        {
            print(parent.childCount);
            buttonRect = parent.GetChild(parent.childCount+idx).GetComponent<RectTransform>();
        }

        SetFocusPosition(buttonRect);

        SetClickTarget(buttonRect.gameObject);

    }

    public void SetEffectScale(float scale)
    {
        pointerEffect.localScale = Vector3.one * scale * 0.01f;
    }


    private void SetFocusPosition(RectTransform buttonRect)
    {
        Vector2 size = Vector2.Scale(buttonRect.rect.size, transform.lossyScale);
        var	rect = new Rect((Vector2)buttonRect.position - (size * buttonRect.pivot), size);
        
        var	center	= rect.center;
        var uiCamera = SceneBase.Current.UICamera;
        Vector2 centerScreen = uiCamera.WorldToScreenPoint(center);

        RectTransformUtility.ScreenPointToLocalPointInRectangle(transform.parent.GetComponent<RectTransform>(), centerScreen, uiCamera, out var t);

        //Debug.Log($"center={center}, screenCenter={centerScreen}");

        focusMask.anchoredPosition = t;

        focusMask.sizeDelta = buttonRect.rect.size*buttonRect.localScale;

        SetEffect(t);
    }

    private void SetFocusPosition3D(Vector3 pos)
    {
        Vector2 screenPos = MapSceneManager.Instance.CurrentScene.GetCameraController().GetCamera().WorldToScreenPoint(pos);
        var uiCamera = SceneBase.Current.UICamera;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(transform.parent.GetComponent<RectTransform>(), screenPos, uiCamera, out var t);

        //Debug.Log($"center={center}, screenCenter={centerScreen}");

        focusMask.anchoredPosition = t;

        focusMask.sizeDelta = new Vector2(100,100);

        SetEffect(t);
    }

    private void SetEffect(Vector2 position)
    {
        pointerEffect.anchoredPosition = position;
        pointerEffect.gameObject.SetActive(true);

        var spineAnim = pointerEffect.GetComponent<Spine.Unity.SkeletonGraphic>();
        spineAnim.AnimationState.AddAnimation(0, "loop", true, 0);
    }

    private void SetClickTarget(GameObject obj)
    {
        UIButton btn = obj.GetComponent<UIButton>();
        if (btn == null)
        {
            btn = obj.GetComponent<UIButtonWithNew>();
        }

        var allBtn = obj.GetComponentsInChildren<UIButton>(true);

        if (btn == null && allBtn.Length > 0)
        {
            btn = allBtn[0];
        }

        if (btn == null)
        {
            btn = obj.AddComponent<UIButton>();
        }

        foreach (var item in allBtn)
        {
            if (item == btn) continue;
            item.enabled = false;
        }

        Disposable.Create(()=>
        {
            foreach (var item in allBtn)
            {
                if (item != null)
                {
                    item.enabled = true;
                }
            }
        }).AddTo(mSubscriptions);

        btn.OnTouchUpInside.Subscribe(OnClickTarget).AddTo(mSubscriptions);
    }

    private void SetClickTarget3D(GameObject obj)
    {
        if (obj.GetComponent<Map.AMapRuntimeObject>() != null)
        {
            var c = obj.GetComponent<Map.AMapRuntimeObject>();
            c.GetEventTrigger().triggers[0].callback.AddListener(OnClickTarget3D);
            Disposable.Create(() => c.GetEventTrigger().triggers[0].callback.RemoveListener(OnClickTarget3D)).AddTo(mSubscriptions);

            var raycast = MapSceneManager.Instance.CurrentScene.GetCameraController().GetCamera().GetComponent<PhysicsRaycaster>();
            var evmask = raycast.eventMask;
            raycast.eventMask = 1 << obj.layer;

            Disposable.Create(() => {raycast.eventMask = evmask;}).AddTo(mSubscriptions);
        }
    }

    private void SetClickMoveTarget(EventTrigger c)
    {
        if (c != null)
        {
            c.triggers[0].callback.AddListener(OnClickMoveTarget);
            Disposable.Create(() => c.triggers[0].callback.RemoveListener(OnClickMoveTarget)).AddTo(mSubscriptions);
        }
    }


    private void OnClickTarget()
    {
        mSubscriptions.Clear();
        
        var screenBtnRect = screenBtn.GetComponent<RectTransform>();
        screenBtnRect.anchoredPosition = Vector2.zero;
        screenBtnRect.localRotation = Quaternion.Euler(0,0,0);
        Hide();

        TutorialManager.Instance.FinishCurrentTutorialStep();
    }

    private void OnClickTarget3D(BaseEventData data)
    {
        MapSceneManager.Instance.CurrentScene.GetCameraController().GetVirtualCameraManager().SetFollowPlayer(true);
        mSubscriptions.Clear();
        Hide();

        AsyncManager.Instance.StartGuardAsync(async()=>
        {
            await UniTask.DelayFrame(1);
            await UniTask.WaitUntil(()=>!MapSceneManager.Instance.CurrentScene.player.IsNowMove());
            TutorialManager.Instance.FinishCurrentTutorialStep();
        });
    }

    private void OnClickMoveTarget(BaseEventData data)
    {
        MapSceneManager.Instance.CurrentScene.GetCameraController().GetVirtualCameraManager().SetFollowPlayer(true);
        mSubscriptions.Clear();
        Hide();

        AsyncManager.Instance.StartGuardAsync(async()=>
        {
            await UniTask.DelayFrame(1);
            await UniTask.WaitUntil(()=>!MapSceneManager.Instance.CurrentScene.player.IsNowMove());
            TutorialManager.Instance.FinishCurrentTutorialStep();
        });

        
    }
}
