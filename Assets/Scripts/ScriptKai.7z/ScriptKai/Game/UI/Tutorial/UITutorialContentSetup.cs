using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UITutorialContentSetup : MonoBehaviour
{
    [SerializeField] UIText titleText;
    [SerializeField] UIText captionText;
    [SerializeField] GameObject captionGroup;
    [SerializeField] GameObject upLineGroup;
    [SerializeField] GameObject downLineGroup;
    [SerializeField] UITutorialExplanationCell baseCell;
    [SerializeField] GameObject rightDescGroup;
    [SerializeField] GameObject[] rightDescList;
    [SerializeField] GameObject arrow;
    private List<UITutorialExplanationCell> cellList = new List<UITutorialExplanationCell>();


    private int rightDescIndex = 0;

    public async UniTask Setup(List<TutorialPageMaster> masters)
    {
        string _title = null;
        string _caption = null;

        rightDescIndex = 0;

        //标题文字
        captionGroup.SetActive(false);

        //上面的花纹线
        upLineGroup.SetActive(false);

        //下面的花纹线
        downLineGroup.SetActive(false);


        //图片元素清空
        foreach (var item in cellList)
        {
            Destroy(item.gameObject);
        }

        cellList.Clear();


        foreach (var m in masters)
        {
            if (!string.IsNullOrEmpty(m.localizeTitleId))
                _title = m.localizeTitleId;
            if (!string.IsNullOrEmpty(m.descId))
                _caption = m.descId;

            var o = Instantiate(baseCell.transform, baseCell.transform.position, baseCell.transform.rotation, baseCell.transform.parent);
            o.gameObject.SetActive(true);
            var cell = o.GetComponent<UITutorialExplanationCell>();
            cellList.Add(cell);

            if (m.layoutType == 0)// 两张图片左右分布类型
            {
                await cell.SetupAsync(m.resourceName, m.localizeContentId.Count > 0 ? m.localizeContentId[0] : null);
                rightDescGroup.SetActive(false);
                if (!string.IsNullOrEmpty(_caption))
                {
                    arrow.SetActive(true);
                }
            }
            else if (m.layoutType == 1) // 地图移动方式，右侧有文字版
            {
                await cell.SetupAsync(m.resourceName, null);

                //有下方花纹线和右边栏
                downLineGroup.SetActive(true);
                rightDescGroup.SetActive(true);

                foreach (var item in m.localizeContentId)
                {
                    //最多三条
                    if (rightDescIndex >= rightDescList.Length)
                    {
                        //error
                        Log.Error($"pageId:{m.id} reach desc count max!!");
                        break;
                    }

                    //把东西显示出来
                    var descObject = rightDescList[rightDescIndex++];
                    descObject.SetActive(true);
                    descObject.GetComponentInChildren<UIText>().SetLabel(LocalizeManager.DATA_TYPE.TUTORIAL, item);
                }
            }
        }

        rightDescGroup.transform.SetAsLastSibling();

        //多余的隐去？？
        for (int i = rightDescIndex; i < rightDescList.Length; i++)
        {
            rightDescList[i].SetActive(false);
        }

        //title set
        titleText.SetLabel(LocalizeManager.DATA_TYPE.TUTORIAL, _title);

        //没标题，上花纹启动！有标题，显示标题,箭头启动！
        if (string.IsNullOrEmpty(_caption))
        {
            upLineGroup.SetActive(true);
        }
        else
        {
            captionGroup.SetActive(true);
            captionText.SetLabel(LocalizeManager.DATA_TYPE.TUTORIAL, _caption);
        }

    }
}
