using UnityEngine;
using UnityEngine.EventSystems;
public class ButtonPressedEffect : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    [Range(0,1)]
    [SerializeField] float scale = 0.8f;

    public void OnPointerDown(PointerEventData eventData)
    {
        transform.localScale = Vector3.one * scale;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        transform.localScale = Vector3.one;
    }

}
