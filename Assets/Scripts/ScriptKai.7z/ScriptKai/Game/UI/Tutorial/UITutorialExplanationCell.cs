﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UITutorialExplanationCell : MonoBehaviour
{
    [SerializeField] UITexture image;
    [SerializeField] UIText underDesc;
    [SerializeField] GameObject underDescGroup;


    public async UniTask SetupAsync(string iconId, string descId)
    {
        if (string.IsNullOrEmpty(descId))
        {
            underDescGroup.SetActive(false);
        }
        else
        {
            underDescGroup.SetActive(true);
            underDesc.SetLabel(LocalizeManager.DATA_TYPE.TUTORIAL, descId);
        }
        await image.LoadAsync("Tutorial", iconId, true);
    }
}
