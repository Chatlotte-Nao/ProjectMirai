﻿using System.Collections;
using System.Collections.Generic;
using Battle.Unity.BattleUI;
using DG.Tweening;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.EventSystems;

public class  UITutorialMoveDialog : UIDialogBase
{
    [SerializeField] private RectTransform stickRect;
    [SerializeField] private RectTransform arrowObj;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }

    
    public void SetupMoveButton(GameObject panel, string buttonName,long rotation)
    {
       
        var button = panel.transform.Find(buttonName);
        if (button == null)
        {
            return;
        }
        var buttonRect = button.GetComponent<RectTransform>();
        SetClickTarget(button.gameObject);
        arrowObj.DOLocalMoveY(100, 1.5f).SetLoops(-1,LoopType.Restart);
        stickRect.localRotation = Quaternion.Euler(0,0,-rotation);
    }
    

    private void SetClickTarget(GameObject obj)
    {
        UIButton btn = obj.GetComponent<UIButton>();
        var allBtn = obj.GetComponentsInChildren<UIButton>(true);

        if (btn == null && allBtn.Length > 0)
        {
            btn = allBtn[0];
        }

        if (btn == null)
        {
            btn = obj.AddComponent<UIButton>();
        }
        Disposable.Create(()=>
        {
            foreach (var item in allBtn)
            {
                if (item != null)
                {
                    item.enabled = true;
                }
            }
        }).AddTo(mSubscriptions);

        btn.onClickDown.Subscribe(OnClickTarget).AddTo(mSubscriptions);
    }
    
    private void OnClickTarget(Vector2 o)
    {
        mSubscriptions.Clear();
        Hide();
        TutorialManager.Instance.FinishCurrentTutorialStep();
    }
    

}
