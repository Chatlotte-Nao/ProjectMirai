﻿using System.Collections;
using System.Collections.Generic;
using Battle.Unity.BattleUI;
using DG.Tweening;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.EventSystems;

public class UITutorialBattleCharacterInfoDialog : UIDialogBase
{
    [SerializeField] RectTransform focusMask;
    [SerializeField] UIButton screenBtn;
    [SerializeField] RectTransform arrow;
    [SerializeField] RectTransform pointerEffect;
    [SerializeField] UIText characterName;
    [SerializeField] UIText infoText1;
    [SerializeField] UIText infoText2;
    [SerializeField] RectTransform infoTextGroup;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }

    public void SetEffectScale(float scale)
    {
        pointerEffect.localScale = Vector3.one*scale;
    }


    public void Setup(Vector2 pos, string name, string a, string b, float scale)
    {
        pointerEffect.anchoredPosition = pos;
        pointerEffect.localScale = Vector3.one*scale;
        
        characterName.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER_NAME, name);
        infoText1.SetLabel(LocalizeManager.DATA_TYPE.TUTORIAL, a);
        infoText2.SetLabel(LocalizeManager.DATA_TYPE.TUTORIAL, b);
        screenBtn.OnTouchDown.Subscribe(OnClickTarget).AddTo(mSubscriptions);
        
        var spineAnim = pointerEffect.GetComponent<Spine.Unity.SkeletonGraphic>();
        spineAnim.AnimationState.AddAnimation(0, "loop", true, 0);
        
    }

    private void OnClickTarget()
    {
        mSubscriptions.Clear();
        Hide();

        TutorialManager.Instance.FinishCurrentTutorialStep();
    }

    
}
