﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UITutorialExplanationDialog : UIDialogBase
{
    //[SerializeField] UIText titleText;
    //[SerializeField] UIText captionText;
    //[SerializeField] GameObject captionGroup;
    //[SerializeField] GameObject upLineGroup;
    //[SerializeField] GameObject downLineGroup;
    //[SerializeField] UITutorialExplanationCell baseCell;
    //[SerializeField] GameObject rightDescGroup;
    //[SerializeField] GameObject[] rightDescList;
    [SerializeField] UIButton finishBtn;

    [SerializeField] ScrollPageTool scrollPageTool;
    [SerializeField] GameObject tutorialContentPrefab;
    [SerializeField] Transform tutorialContentParent;
    [SerializeField] GameObject pagesSystemNeed;



    //private int rightDescIndex = 0;
    //private List<UITutorialExplanationCell> cellList = new List<UITutorialExplanationCell>();


    private Dictionary<int, TutorialPageMaster> tutorialPages;

    private Dictionary<int, List<TutorialPageMaster>> pageDic;

    private Queue<TutorialPageMaster> allMasters = new Queue<TutorialPageMaster>();



    private bool isRule = false;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        finishBtn.OnTouchUpInside.Subscribe(onClickFinish).AddTo(mSubscriptions);

    }



    public async UniTask SetupAll()
    {
        pagesSystemNeed.SetActive(true);

        //把TutorialPageMaster表深拷贝过来
        tutorialPages = new Dictionary<int, TutorialPageMaster>(DataManager.Instance.Master.TutorialPage);

        pageDic = new Dictionary<int, List<TutorialPageMaster>>();

        //所有TutorialPageMaster入队
        foreach (var item in tutorialPages.Values)
        {
            allMasters.Enqueue(item);
        }

        //若队列不为空
        while (allMasters.Count > 0)
        {
            //出队
            var master = allMasters.Dequeue();

            //若master的页码在页码--素材字典里，添加素材
            if (pageDic.ContainsKey(master.pageNum))
            {
                pageDic[master.pageNum].Add(master);
            }
            //否则页码--素材字典中加入该页码
            else
            {
                pageDic.Add(master.pageNum, new List<TutorialPageMaster>() { master });
            }
        }

        //页码--素材字典中目前为int页码对应list该页码中的素材

        //设置总页数
        int totalPageNum = pageDic.Count;
        scrollPageTool.totalPage = totalPageNum;

        //生成每一页
        for (int i = 0; i < totalPageNum; i++)
        {
            var tutorialContent = Instantiate(tutorialContentPrefab, tutorialContentParent);
            await tutorialContent.GetComponent<UITutorialContentSetup>().Setup(pageDic[i]);
        }
    }

    private int ruleId_;
    public async UniTask LoadRuleDataAsycn(int ruleId)
    {
        isRule = true;
        ruleId_ = ruleId;
        pageDic = new Dictionary<int, List<TutorialPageMaster>>();
        var pageIds = DataManager.Instance.Master.TutorialFunctionMaster[ruleId].pageIds;
        var tutorialPages = DataManager.Instance.Master.TutorialPage.Values.Where(a=>
            pageIds.Contains(a.id));
        foreach (var page in tutorialPages)
        {
            if (pageDic.ContainsKey(page.pageNum))
            {
                pageDic[page.pageNum].Add(page);
            }
            else
            {
                pageDic.Add(page.pageNum, new List<TutorialPageMaster>() { page });
            }
        }
        
        int totalPageNum = pageDic.Count;
        scrollPageTool.totalPage = totalPageNum;
        pagesSystemNeed.SetActive(totalPageNum>1);
        //生成每一页
        foreach (var pic in pageDic)
        {
            var tutorialContent = Instantiate(tutorialContentPrefab, tutorialContentParent);
            await tutorialContent.GetComponent<UITutorialContentSetup>().Setup(pic.Value);
        }
    }

    public async UniTask Setup(List<TutorialPageMaster> masters)
    {
        pagesSystemNeed.SetActive(false);

        var tutorialContent = Instantiate(tutorialContentPrefab, tutorialContentParent);

        await tutorialContent.GetComponent<UITutorialContentSetup>().Setup(masters);

        //string _title = null;
        //string _caption = null;

        //rightDescIndex = 0;

        ////标题文字
        //captionGroup.SetActive(false);

        ////上面的花纹线
        //upLineGroup.SetActive(false);

        ////下面的花纹线
        //downLineGroup.SetActive(false);


        ////图片元素清空
        //foreach (var item in cellList)
        //{
        //    Destroy(item.gameObject);
        //}

        //cellList.Clear();


        //foreach (var m in masters)
        //{
        //    if (!string.IsNullOrEmpty(m.localizeTitleId))
        //        _title = m.localizeTitleId;
        //    if (!string.IsNullOrEmpty(m.descId))
        //        _caption = m.descId;

        //    var o = Instantiate(baseCell.transform, baseCell.transform.position, baseCell.transform.rotation, baseCell.transform.parent);
        //    o.gameObject.SetActive(true);
        //    var cell = o.GetComponent<UITutorialExplanationCell>();
        //    cellList.Add(cell);

        //    if (m.layoutType == 0)// 两张图片左右分布类型
        //    {
        //        await cell.SetupAsync(m.resourceName, m.localizeContentId.Count > 0 ? m.localizeContentId[0] : null);
        //        rightDescGroup.SetActive(false);
        //    }
        //    else if (m.layoutType == 1) // 地图移动方式，右侧有文字版
        //    {
        //        await cell.SetupAsync(m.resourceName, null);

        //        //有下方花纹线和右边栏
        //        downLineGroup.SetActive(true);
        //        rightDescGroup.SetActive(true);

        //        foreach (var item in m.localizeContentId)
        //        {
        //            //最多三条
        //            if (rightDescIndex >= rightDescList.Length)
        //            {
        //                //error
        //                Log.Error($"pageId:{m.id} reach desc count max!!");
        //                break;
        //            }

        //            //把东西显示出来
        //            var descObject = rightDescList[rightDescIndex++];
        //            descObject.SetActive(true);
        //            descObject.GetComponentInChildren<UIText>().SetLabel(LocalizeManager.DATA_TYPE.TUTORIAL, item);
        //        }
        //    }
        //}

        //rightDescGroup.transform.SetAsLastSibling();

        ////多余的隐去？？
        //for (int i = rightDescIndex; i < rightDescList.Length; i++)
        //{
        //    rightDescList[i].SetActive(false);
        //}

        ////title set
        //titleText.SetLabel(LocalizeManager.DATA_TYPE.TUTORIAL, _title);

        ////没标题，上花纹启动！有标题，显示标题
        //if (string.IsNullOrEmpty(_caption))
        //{
        //    upLineGroup.SetActive(true);
        //}
        //else
        //{
        //    captionGroup.SetActive(true);
        //    captionText.SetLabel(LocalizeManager.DATA_TYPE.TUTORIAL, _caption);
        //}

    }

    void onClickFinish()
    {
        Hide();
        if(!isRule)
            TutorialManager.Instance.FinishCurrentTutorialStep();
    }

    public override void OnHide()
    {
        if (ruleId_ == 11)
        {
            UIHomeButtleTeaData.Instance.isTutoria = false;
        }

        base.OnHide();
        this.Dispose();
    }
}
