using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;

public class UIRuleController : MonoBehaviour
{
    [SerializeField] private int ruleId;
    private UIButton _button;
    private UITutorialExplanationDialog _explanationDialog;
    private TutorialFunctionMaster _master;
   protected void Awake()
   {
       _button = GetComponent<UIButton>();
   }

   private void Start()
   {
       _button.OnTouchUpInside.SubscribeAsync(LoadRuleData);
       _master = DataManager.Instance.Master.TutorialFunctionMaster[ruleId];
       if (_master.isAuto && !DataManager.Instance.Local.Scenarios.RuleFirstIds.Contains(ruleId))
       {
           DataManager.Instance.Local.Scenarios.RuleFirstIds.Add(ruleId);
           DataManager.Instance.Local.Save();
           AsyncManager.Instance.StartAsync(LoadRuleData);;
       }
   }

   private async UniTask LoadRuleData()
   {
       if (ruleId <= 0) return;
       if (ruleId == 11)
       {
           UIHomeButtleTeaData.Instance.isTutoria = true;
       }

       if (_master.type == 1)
       {
           await ShowExplanation();
       }
       else
       {
           await ShowRuleText();
       }
   }

   private async UniTask ShowRuleText()
   {
       var title = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.RULE, "Rule_Title");
       var content = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.RULE, $"Rule_Content_{ruleId}"));
       UI.Popup.ShowRule(title, content, CanvasType.App2);
   }

   private async UniTask ShowExplanation()
   {
       if (_explanationDialog == null)
       {
           _explanationDialog = await UI.Dialog.CreateAsync(UIPrefabId.UITutorialExplanationDialog, CanvasType.App2) as UITutorialExplanationDialog;
       }
       
       await _explanationDialog.LoadRuleDataAsycn(ruleId);
       await _explanationDialog.ShowAsync();
   }
}
