﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Spine.Unity;
using UnityEngine.UI;

public class UITutorialNewTextDialog : UIDialogBase
{
    [SerializeField] private GameObject[] gameObjects;
    [SerializeField] Adventure.UI.RubyTMPTextScroll[] rubyTextScroll;
    //[SerializeField] UIText nameText;
    [SerializeField] UIButton clickButton;
    [SerializeField] RawImage[] charaTexture;
    [SerializeField] private Image[] adcCharaImage;
    [SerializeField] Adventure.UI.RubyTMPTextScroll[] hidesTextScroll;

    Transform characterTrans;
    UIRTCamera rtCamera;
    private int _textType; //0 右 1左

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        var rtc = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/RTCamera");
        rtCamera = rtc.GetComponent<UIRTCamera>();

        clickButton.OnTouchUpInside.Subscribe(OnClickTextBox).AddTo(mSubscriptions);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (rtCamera != null)
        {
            rtCamera.Dispose();
            rtCamera = null;
        }

        foreach (var texture in charaTexture)
        {
            texture.texture = null;
        }
        
    }

    public async UniTask SetTextType(int textType)
    {
        _textType = textType;
        for (int i = 0; i < gameObjects.Length; i++)
        {
            gameObjects[i].SetActive(i == textType);
        }
    }

    public async UniTask SetupCharacter(int type, string resName, string anim, float posX, float posY, float scale,string path)
    {
        charaTexture[_textType].gameObject.SetActive(type==0);
        adcCharaImage[_textType].gameObject.SetActive(type!=0);
        if (type == 0)
        {
            GameObject loadCharacter = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/chara/" + resName);
            SkeletonAnimation skeletonAnimation = loadCharacter.GetComponent<SkeletonAnimation>();
            skeletonAnimation.Initialize(false);
            skeletonAnimation.Update(0.0f);
            skeletonAnimation.LateUpdate();

            //loadCharacter.GetComponent<Renderer>().sortingOrder = 750;
            
            var advSpineMaster = DataManager.Instance.Master.AdvSpine[anim];
            if (!string.IsNullOrEmpty(advSpineMaster.body))
            {
                skeletonAnimation.AnimationState.SetAnimation(0, advSpineMaster.body, false);
            }
            else if (!string.IsNullOrEmpty(advSpineMaster.waiting))
            {
                skeletonAnimation.AnimationState.SetAnimation(0, advSpineMaster.waiting, true);
            }

            if (!string.IsNullOrEmpty(advSpineMaster.expression))
            {
                skeletonAnimation.AnimationState.SetAnimation(1, advSpineMaster.expression, false);
            }
            else if (!string.IsNullOrEmpty(advSpineMaster.expression_loop))
            {
                skeletonAnimation.AnimationState.SetAnimation(1, advSpineMaster.expression_loop, true);
            }

            if (!string.IsNullOrEmpty(advSpineMaster.mouthClosed))
            {
                skeletonAnimation.AnimationState.SetAnimation(2, advSpineMaster.mouthClosed, false);
            }

            /*
            characterTrans = loadCharacter.transform;
            characterTrans.parent = transform;

            characterTrans.localPosition = new Vector3(posX, posY, 0);
            characterTrans.localScale = Vector3.one*scale;

            
            loadCharacter.layer = LayerMask.NameToLayer("UI");
            */

            rtCamera.Setup(loadCharacter);
            charaTexture[_textType].texture = rtCamera.GetRenderTexture();
            charaTexture[_textType].rectTransform.anchoredPosition = new Vector2(posX, posY);
        }
        else
        {
            adcCharaImage[_textType].sprite = await ResourceManager.Instance.LoadSpriteAsync("AdvFaceIcon", path);
            adcCharaImage[_textType].rectTransform.anchoredPosition = new Vector2(posX, posY);
        }
    }

    public void SetupText(string label,int posX,int posY)
    {
        // var nameValue = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER_NAME, name);
        // if (nameValue.Length>0)
        // {
        //     nameValue = $"<color=#e2b35a>{nameValue[0]}</color><size=85%>{nameValue.Substring(1)}";
        // }
        //nameText.SetRawText(nameValue);
        rubyTextScroll[_textType].gameObject.SetActive(false);
        var rectTransform = rubyTextScroll[_textType].GetComponent<RectTransform>();
        rectTransform.anchoredPosition = new Vector2(posX, posY);
        hidesTextScroll[_textType].Setup(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.TUTORIAL, label));
        hidesTextScroll[_textType].End();
        rubyTextScroll[_textType].gameObject.SetActive(true);
        rubyTextScroll[_textType].Setup(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.TUTORIAL, label));
    }

    private void OnClickTextBox()
    {
        Hide();
        if (characterTrans != null)
        {
            Destroy(characterTrans.gameObject);
            characterTrans = null;
        }
        TutorialManager.Instance.FinishCurrentTutorialStep();
    }

}
