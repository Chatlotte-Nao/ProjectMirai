﻿using System.Collections;
using System.Collections.Generic;
using Battle.Unity.BattleUI;
using DG.Tweening;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.EventSystems;

public class  UITutorialWeakDialog : UIDialogBase
{

    [SerializeField] RectTransform pointerEffect;
    
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }

    public void SetupForButton(GameObject panel, string buttonName)
    {
        var button = panel.transform.Find(buttonName);
        if (button == null)
        {
            return;
        }
        var buttonRect = button.GetComponent<RectTransform>();
        var parenRect = panel.GetComponent<RectTransform>();
        SetupForButton(parenRect,buttonRect, buttonRect.gameObject);
    }

    public void SetupForButton(RectTransform parenRect,RectTransform buttonRect, GameObject btnGo)
    {
        pointerEffect.gameObject.SetActive(false);
        SetFocusPosition(parenRect,buttonRect);
        SetClickTarget(btnGo);
    }
    

    public void SetupForChild(GameObject panel, string parentName, int idx)
    {
        var parent = panel.transform.Find(parentName);
        if (parent == null)
        {
            return;
        }
        pointerEffect.gameObject.SetActive(false);
        RectTransform buttonRect = null;

        if (idx >= 0)
        {
            buttonRect = parent.GetChild(idx).GetComponent<RectTransform>();
        }
        else
        {
            print(parent.childCount);
            buttonRect = parent.GetChild(parent.childCount+idx).GetComponent<RectTransform>();
        }

        var parenRect = panel.GetComponent<RectTransform>();
        SetupForButton(parenRect, buttonRect,buttonRect.gameObject);
    }

    public void SetEffectScale(float scale)
    {
        pointerEffect.localScale = Vector3.one*scale;
    }


    private void SetFocusPosition(RectTransform parenRect,RectTransform buttonRect)
    {
        // Vector2 size = Vector2.Scale(buttonRect.rect.size, transform.lossyScale);
        // var	rect = new Rect((Vector2)buttonRect.position - (size * buttonRect.pivot), size);
        //
        // var	center	= rect.center;
        // var uiCamera = SceneBase.Current.UICamera;
        // Vector2 centerScreen = uiCamera.WorldToScreenPoint(center);
        //
        // RectTransformUtility.ScreenPointToLocalPointInRectangle(transform.parent.GetComponent<RectTransform>(), centerScreen, uiCamera, out var t);

        //Debug.Log($"center={center}, screenCenter={centerScreen}");


        //SetEffect(t);
        this.gameObject.transform.SetParent(buttonRect);
        this.transform.localRotation = Quaternion.identity;
        this.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
        this.GetComponent<RectTransform>().sizeDelta = Vector2.zero;
        this.gameObject.transform.SetParent(parenRect);
        pointerEffect.gameObject.SetActive(true);
        var spineAnim = pointerEffect.GetComponent<Spine.Unity.SkeletonGraphic>();
        spineAnim.AnimationState.AddAnimation(0, "loop", true, 0);
    }

  

    private void SetEffect(Vector2 position)
    {
        pointerEffect.anchoredPosition = position;
        pointerEffect.gameObject.SetActive(true);

        var spineAnim = pointerEffect.GetComponent<Spine.Unity.SkeletonGraphic>();
        spineAnim.AnimationState.AddAnimation(0, "loop", true, 0);
    }

    private void SetClickTarget(GameObject obj)
    {
        UIButton btn = obj.GetComponent<UIButton>();
        var allBtn = obj.GetComponentsInChildren<UIButton>(true);

        if (btn == null && allBtn.Length > 0)
        {
            btn = allBtn[0];
        }

        if (btn == null)
        {
            btn = obj.AddComponent<UIButton>();
        }
        Disposable.Create(()=>
        {
            foreach (var item in allBtn)
            {
                if (item != null)
                {
                    item.enabled = true;
                }
            }
        }).AddTo(mSubscriptions);

        btn.OnTouchUpInside.Subscribe(OnClickTarget).AddTo(mSubscriptions);
    }
    

    private void OnClickTarget()
    {
        mSubscriptions.Clear();
        Hide();
        TutorialManager.Instance.FinishCurrentTutorialStep();
    }
    

}
