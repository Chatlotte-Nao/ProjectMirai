using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class UITutorialKeepUpWith : MonoBehaviour
{
    [SerializeField] RectTransform target;
    [SerializeField] Vector3 intercalPos;
    [SerializeField] Vector2 intercalSizeDelta;
    RectTransform thisRect => GetComponent<RectTransform>();
    private void Update()
    {
        //thisRect.position = intercalPos + target.position;
        thisRect.anchoredPosition3D = intercalPos;
        thisRect.sizeDelta = intercalSizeDelta + target.sizeDelta;
    }
}
