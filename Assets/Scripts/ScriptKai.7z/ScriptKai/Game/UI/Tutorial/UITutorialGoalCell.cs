using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using UnityEngine;

public class UITutorialGoalCell : MonoBehaviour
{
    [SerializeField] private UIText goalNamel;
    [SerializeField] private UIButton clickButon;
    [SerializeField] private GameObject newEff;
    [SerializeField] private GameObject completedEff;
    public ClickEvent OnClick => clickButon.onClick;

    public void SetUp(int masterId)
    {
        goalNamel.SetLabel(LocalizeManager.DATA_TYPE.TUTORIAL,$"goal_name_{masterId}");
    }

    public void PlayNewAnimation()
    {
        newEff.SetActive(true);
        completedEff.SetActive(false);
    }

    public void PlayCompletedAnimation()
    {
        newEff.SetActive(false);
        completedEff.SetActive(true);
    }
}
