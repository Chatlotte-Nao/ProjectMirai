﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine.Events;

public class UITutorialEnterNameDialog : UIDialogBase
{
    [SerializeField] UIButton okButton;
    [SerializeField] TMP_InputField inputField;
    [SerializeField] UIText errorText;
    [SerializeField] private GameObject nameObj;
    [SerializeField] private GameObject messageObj;
    [SerializeField] private UIButton continueBtn;
    [SerializeField] Adventure.UI.RubyTMPTextScroll rubyTextScroll;
    public UnityEvent OnSuccess = new UnityEvent();
    public UnityEvent OnSuccessName = new UnityEvent();

    private const int MaxMessageIndex = 7;
    private int index = 1;
    public override async UniTask InitializeAsync()
    {
        nameObj.gameObject.SetActive(true);
        messageObj.gameObject.SetActive(false);
        await base.InitializeAsync();
        okButton.onClick.GuardSubscribeAsync(OnClickOk).AddTo(mSubscriptions);
        continueBtn.onClick.GuardSubscribeAsync(OnContinueClick).AddTo(mSubscriptions);
        index = 1;
    }


    private async UniTask OnClickOk(GameObject o)
    {
        string name = inputField.text;
        if (string.IsNullOrEmpty(name))
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "Change_Name_Null"));

            return;
        }

        await ProfileService.SetUserName(name);
        OnSuccessName.Invoke();
        nameObj.gameObject.SetActive(false);
        messageObj.gameObject.SetActive(true);
        await LoadMissage();
    }

    private async UniTask LoadMissage()
    {
        string str = "";
        if (index == 3)
        {
            str = string.Format(
                LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.TUTORIAL, $"EnterName_Content{index}"),
                inputField.text);
        }
        else
        {
            str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.TUTORIAL, $"EnterName_Content{index}");
        }

        rubyTextScroll.Setup(str);
    }

    private async UniTask OnContinueClick(GameObject o)
    {
        if (rubyTextScroll.GetEnabled())
        {
            rubyTextScroll.End();
            return;
        }
        if (index < MaxMessageIndex)
        {
            index++;
            await LoadMissage();
            return;
        }
        OnSuccess.Invoke();
    }
}
