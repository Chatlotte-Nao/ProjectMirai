using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

//[ExecuteInEditMode]
public class UITutorialContentSize : MonoBehaviour
{
    [SerializeField] ushort lineMaxCount;
    [SerializeField] ushort lineTextMinCount;
    [SerializeField] float textInterval;
    [SerializeField] float lintInterval;
    [SerializeField] Vector2 frameUintWithHright;

    [SerializeField] TextMeshProUGUI upText;
    [SerializeField] TextMeshProUGUI text;
    [SerializeField] RectTransform textRect;
    [SerializeField] RectTransform contentSize;

    [SerializeField] float proportion = 0.75f;
    [SerializeField] Vector2 frameSizeDelat;
    [SerializeField] Vector2 frameMinSizeDelat;
    [SerializeField, Range(0, 1000)] float autoSpeed;

    float temporaryProportion;

    private void OnEnable()
    {
        contentSize.sizeDelta = frameUintWithHright * proportion;
    }
    private void Update()
    {
        Active();
    }
    void Active()
    {
        if (upText.text == null)
        {
            return;
        }
        var textCount = upText.text.Length;
        if (textCount < lineTextMinCount)
        {
            temporaryProportion = proportion;
        }
        else
        {
            temporaryProportion = 1;
        }
        frameSizeDelat = frameUintWithHright * temporaryProportion;
        contentSize.sizeDelta = new Vector2(contentSize.rect.width, frameSizeDelat.y);


        var lineCount = upText.textInfo.lineCount;
        if (lineCount > lineMaxCount)
        {
            contentSize.GetComponent<Image>().enabled = false;
            text.enabled = false;
            contentSize.sizeDelta += new Vector2(autoSpeed * Time.deltaTime, 0);
        }
        else
        {
            contentSize.GetComponent<Image>().enabled = true;
            text.enabled = true;
        }
        //if (lineCount < lineMaxCount && contentSize.sizeDelta.x > (int)frameSizeDelat.x)
        //{
        //    contentSize.sizeDelta += new Vector2(-autoSpeed * Time.deltaTime, 0);
        //}
    }
}
