using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ScrollPageTool : MonoBehaviour, IBeginDragHandler, IEndDragHandler
{
    public float moveSpeed = 0.1F;
    public int startPage = 0;
    public int totalPage = 4;
    public int m_dragNum;// �������볬��һҳ�� (m_dragNum*10)% �򻬶��ɹ�

    public bool buttonPageEnable;//�Ƿ����ð�ť���
    public Button pageLastButton;
    public Button pageNextButton;
    public Text pageNumText;



    private int m_nowPage;//��0��ʼ
    private float m_pageAreaSize;
    private const float SCROLL_MOVE_SPEED = 1F;
    private float scrollMoveSpeed = 0f;
    private bool scrollNeedMove = false;
    private float scrollTargetValue;
    private bool isRegistEvent = false;
    private ScrollRect scrollRect;


    private List<UIButton> starPageButtons = new List<UIButton>();

    [SerializeField] private Transform pageButtonParent;
    [SerializeField] private UIButton starPageButtonPrefab;


    private void Start()
    {
        InitManager(totalPage, startPage, true);
    }


    /// <summary>
    /// ���ú����ð�ť��״̬
    /// </summary>
    public bool SetButtonStatus
    {
        set
        {
            buttonPageEnable = value;
            pageLastButton.interactable = buttonPageEnable && pageLastButton.interactable;
            pageNextButton.interactable = buttonPageEnable && pageNextButton.interactable;
        }
    }




    public void InitManager(int pageNum, int targetPage = 0, bool isShowAnim = false)
    {
        scrollRect = GetComponent<ScrollRect>();
        targetPage = Mathf.Clamp(targetPage, 0, pageNum - 1);
        m_nowPage = targetPage;

        RegistEvent();
        m_pageAreaSize = 1f / (pageNum - 1);

        //page��ť�����¼�
        for (int i = 0; i < totalPage; i++)
        {
            var starPageButton = Instantiate(starPageButtonPrefab, pageButtonParent);
            starPageButton.gameObject.SetActive(true);
            starPageButtons.Add(starPageButton);
            var index = i;
            starPageButton.OnTouchUpInside.Subscribe(() => { ChangePage(index); });
            Debug.Log("i:" + i);
        }

        ChangePage(targetPage, isShowAnim);

    }

    private void RegistEvent()
    {
        if (isRegistEvent)
            return;

        isRegistEvent = true;

        if (pageLastButton != null)
            pageLastButton.onClick.AddListener(delegate { Paging(-1); });
        if (pageNextButton != null)
            pageNextButton.onClick.AddListener(delegate { Paging(1); });
    }


    /// <summary>
    /// ��ť���õķ�ҳ����
    /// </summary>
    /// <param name="num"></param>
    private void Paging(int num)
    {
        //maxNum-1,��0��ʼ
        num = (num < 0) ? -1 : 1;
        int temp = Mathf.Clamp(m_nowPage + num, 0, totalPage - 1);
        if (m_nowPage == temp)
            return;

        ChangePage(temp);
    }


    void Update()
    {
        ScrollControl();

        for (int i = 0; i < totalPage; i++)
        {
            if (m_nowPage == i)
            {
                starPageButtons[i].GetComponent<RectTransform>().sizeDelta = new Vector2(40, 40);
                Color color = starPageButtons[i].GetComponent<Image>().color;
                starPageButtons[i].GetComponent<Image>().color = new Color(color.r, color.g, color.b, 1f);


            }
            else
            {
                starPageButtons[i].GetComponent<RectTransform>().sizeDelta = new Vector2(22, 22);
                Color color = starPageButtons[i].GetComponent<Image>().color;
                starPageButtons[i].GetComponent<Image>().color = new Color(color.r, color.g, color.b, 0.3f);



            }   
        }
    }

    public int GetPageNum { get { return m_nowPage; } }

    //��ҳ����
    private void ScrollControl()
    {
        if (!scrollNeedMove)
            return;

        if (Mathf.Abs(scrollRect.horizontalNormalizedPosition - scrollTargetValue) < 0.01f)
        {
            scrollRect.horizontalNormalizedPosition = scrollTargetValue;
            scrollNeedMove = false;
            return;
        }


        scrollRect.horizontalNormalizedPosition = Mathf.SmoothDamp(scrollRect.horizontalNormalizedPosition, scrollTargetValue, ref scrollMoveSpeed, moveSpeed);
    }

    /// <summary>
    /// �϶���ʼ
    /// </summary>
    /// <param name="eventData"></param>
    public void OnBeginDrag(PointerEventData eventData)
    {
        scrollNeedMove = false;
        scrollTargetValue = 0;


    }


    /// <summary>
    /// �϶�����
    /// </summary>
    /// <param name="eventData"></param>
    public void OnEndDrag(PointerEventData eventData)
    {
        int tempPage = m_nowPage;

        int num = (((scrollRect.horizontalNormalizedPosition - (m_nowPage * m_pageAreaSize)) >= 0) ? 1 : -1);

        if (Mathf.Abs(scrollRect.horizontalNormalizedPosition - (m_nowPage * m_pageAreaSize)) >= (m_pageAreaSize / 10f) * m_dragNum)
        {
            tempPage += num;

        }
        ChangePage(tempPage);

    }

    /// <summary>
    /// ���з�ҳ
    /// </summary>
    /// <param name="pageNum"></param>
    /// <param name="isShowAnim"></param>
    public void ChangePage(int pageNum, bool isShowAnim = true)
    {
        if (pageNum >= totalPage)
            pageNum = totalPage - 1;

        if (pageNum < 0)
            pageNum = 0;

        m_nowPage = pageNum;

        ChangePageText(pageNum);

        if (isShowAnim)
        {
            scrollTargetValue = m_nowPage * m_pageAreaSize;
            scrollNeedMove = true;
            scrollMoveSpeed = 0;
        }
        else
        {
            scrollRect.horizontalNormalizedPosition = m_nowPage * m_pageAreaSize;
        }

        ChangePageText(m_nowPage);

    }





    public void ChangePageText(int num)
    {
        int maxPageTo0Start = totalPage - 1;
        m_nowPage = Mathf.Clamp(num, 0, maxPageTo0Start);

        if (pageNumText != null)
            pageNumText.text = (m_nowPage + 1).ToString() + "/" + totalPage.ToString();

        //only one page
        if (maxPageTo0Start == 0)
        {
            scrollRect.enabled = false;
            pageLastButton.interactable = false;
            pageNextButton.interactable = false;
            return;
        }
        else
        {
            pageLastButton.interactable = true;
            pageNextButton.interactable = true;
            scrollRect.enabled = true;
        }


        //�жϰ�ť��״̬
        SetButtonStatus = buttonPageEnable;

        if (!buttonPageEnable)
            return;

        if (m_nowPage == 0 && pageLastButton.interactable)
            pageLastButton.interactable = false;
        if (m_nowPage >= maxPageTo0Start && pageNextButton.interactable)
            pageNextButton.interactable = false;
        if (m_nowPage > 0 && (!pageLastButton.interactable))
            pageLastButton.interactable = true;
        if (m_nowPage < maxPageTo0Start && (!pageNextButton.interactable))
            pageNextButton.interactable = true;


    }


}


