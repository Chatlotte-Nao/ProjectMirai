﻿

using Map;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using Pheonix.Core;

namespace MapUi
{
	/// <summary>
	/// ヒントボタン挙動管理
	/// </summary>
	public class HintButtonManager : MonoBehaviour
	{
		enum HINT_TYPE
		{
			NONE = 0,
			ROOM,
			ROOM_SECOND,
			OBJRCT,
			ADV,
			BATTLE,
			END_GOOD,
			END_NORMAL,
			NOW_PLAYNG,

		};

		[SerializeField] UIButton hintButton;
		[SerializeField] Image hintButtonImage;
		[SerializeField] Sprite endGoodImage;
		[SerializeField] Sprite endNormalImage;
		[SerializeField] Sprite playingImage;
		[SerializeField] HintDialog hintDialog;

		HINT_TYPE preHintType = HINT_TYPE.NONE;
		List<HINT_TYPE> hintList = new List<HINT_TYPE>();


		public HintDialog HintDialog => hintDialog;

		private void OnDestroy()
		{
			hintButton.OnTouchUpInside.RemoveAllListeners();
			hintButton = null;
		}

		public void Initialize()
		{
			hintButton.OnTouchUpInside.AddListener(() =>
			{
				var list = new List<HINT_TYPE>(hintList);
				if (list.Count >= 2)
				{
					list.Remove(preHintType);
				}
				var displayHint = (list.Count > 0) ? list[UnityEngine.Random.Range(0, list.Count)] : HINT_TYPE.END_NORMAL;
				var hintMaster = DataManager.Instance.Master.Hint[(int)displayHint];
				var text = hintMaster.message[UnityEngine.Random.Range(0, hintMaster.message.Count)];
				text = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.HINT, text);
				hintDialog.Open(text, false);
				preHintType = displayHint;
			});
		}

		public void SetActive(bool isActive)
		{
			hintButton.gameObject.SetActive(isActive);
		}

		public bool IsActive()
		{
			return hintButton.gameObject.activeSelf;
		}

		/// <summary>
		/// ヒント状態を更新する
		/// </summary>
		public void UpdateHint()
		{
			hintList = GetNowHintTypeList();

			if (hintList.Any(h => h == HINT_TYPE.END_GOOD))
			{
				hintButtonImage.sprite = endGoodImage;
			}
			else if (hintList.Any(h => h == HINT_TYPE.END_NORMAL))
			{
				hintButtonImage.sprite = endNormalImage;
			}
			else
			{
				hintButtonImage.sprite = playingImage;
			}
		}

		/// <summary>
		/// 今発生するヒント種類を取得
		/// </summary>
		List<HINT_TYPE> GetNowHintTypeList()
		{
			var list = new List<HINT_TYPE>();
			var map = MapSceneManager.Instance.CurrentScene;

			//今のマップで発生しているADVが残っているか
			var advList = CheckAdvMaster.GetLocationActiveList(map?.GetNowMapLabel());
			if (advList?.Count > 0)
			{
				var player = map.player;
				var roomList = map.rooms.Values.ToList();
				foreach (var adv in advList)
				{
					if (adv.afterBattleNumber > 0)
						list.Add(HINT_TYPE.BATTLE);
					else
						list.Add(HINT_TYPE.ADV);

					if (ScenarioParameterUtil.IsParamValue("HaveBeenRoom_" + adv.entryRoom) &&
						roomList != null && roomList.Any(room => room.label.Equals(adv.entryRoom)))
					{
						list.Add(HINT_TYPE.ROOM_SECOND);
					}

					//発生個所がルート上でない時は、部屋に何かある
					if (!adv.entryRoom.Contains("Route_"))
					{
						list.Add(HINT_TYPE.ROOM);
					}
				}
			}
			
			//重複したものを省く
			list = list.Distinct().ToList();

			if (list.Count > 0)
			{
				list.Add(HINT_TYPE.NOW_PLAYNG);
			}
			else
			{
				var allAdvList = CheckAdvMaster.GetLocationNonPlaySubList(map.GetNowMapLabel());
				//今は発生していないが、ここで発生予定のサブADVがある＝現状とれないものが残っている
				if (allAdvList.Count > 0)
				{
					list.Add(HINT_TYPE.END_NORMAL);
				}
				else
				{
					list.Add(HINT_TYPE.END_GOOD);
				}
			}

			return list;
		}
	}
}
