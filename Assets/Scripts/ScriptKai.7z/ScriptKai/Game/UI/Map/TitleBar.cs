﻿using Game.Ui;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Map
{
	public class TitleBar : MonoBehaviour
	{
		[SerializeField] TextMeshProUGUI sectionTitleText;
		[SerializeField] TextMeshProUGUI titleText;

		public void Set()
		{
			var sectionType = MapManager.GetNowSectionType();
			var color = titleText.color.ToString();
			Debug.Log("textMeshProUGUI:" + color);
			if (sectionType == MapConstants.SECTION_STORY)
			{
				TitleTextManager.SetFirstChangeText(sectionTitleText, LocalizeManager.GetText(LocalizeManager.DATA_TYPE.COMMON, "MAP_TITLE_STORY"));
			}
			else if (sectionType == MapConstants.SECTION_BATTLE || sectionType == MapConstants.SECTION_STORY_EVENT_BATTLE)
			{
				TitleTextManager.SetFirstChangeText(sectionTitleText, LocalizeManager.GetText(LocalizeManager.DATA_TYPE.COMMON, "MAP_TITLE_BATTLE"));
			}
			else if (sectionType == MapConstants.SECTION_DUNGEON)
			{
				TitleTextManager.SetFirstChangeText(sectionTitleText, LocalizeManager.GetText(LocalizeManager.DATA_TYPE.COMMON, "MAP_TITLE_DUNGEON"));
			}
			else
			{
				sectionTitleText.text = string.Empty;
			}
		}

		public void SetTitleName(string name)
		{
			titleText.gameObject.SetActive(true);
			titleText.text = name;
		}

	}
}
