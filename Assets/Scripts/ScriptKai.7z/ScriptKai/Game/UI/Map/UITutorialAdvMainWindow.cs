using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
public class UITutorialAdvMainWindow : UIDialogBase
{
    [SerializeField] GoalMessageController goalMessageController;
    
    public async UniTask ShowGoalMessageAsync(List<int> goalMessageList)
    {
        await goalMessageController.SetCurrentMessageRoutine(goalMessageList);

        //显示弹窗，滑入，关闭弹窗，滑入

        //hintButton.HintDialog.Open(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.GOAL_MESSAGE_HINT, goalMessageController.GetEndHintString()), true);
    }
    public async UniTask ShowGoalCompleteAsync(List<int> goalMessageList)
    {
        await goalMessageController.Clear(goalMessageList);
        //显示弹窗，显示clear，关闭弹窗（清除），滑出
    }
}
