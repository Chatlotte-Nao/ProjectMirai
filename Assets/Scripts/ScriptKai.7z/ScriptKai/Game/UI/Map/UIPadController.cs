﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIPadController : UIDialogBase
{
    public static bool fobird = false;
    [SerializeField] RectTransform padObject;
    [SerializeField] RectTransform stickObject;
    [SerializeField] RectTransform padContainer;
    [SerializeField] UIButton clickHandler;
    [SerializeField] UIButton triggerButton;
    [SerializeField] GameObject talkIcon;
    [SerializeField] GameObject searchIcon;
    [SerializeField] UITexture targetIcon;

    private Map.AMapRuntimeObject currentTarget = null;
    private Camera mCamera = null;
    private float moveStartCameraAngle = 0f;

    private bool mStarted = false;
    private Vector2 mStartPosition = Vector2.zero;

    private Vector2 padInitPosition;

    private float prevStickRotZ = 0;


    void Update()
    {
        if (fobird)
        {
            return;
        }
        if (MapSceneManager.Instance.CurrentScene == null) return;
        
        if (!mStarted)
        {
// #if UNITY_EDITOR
//             DebugInput();
// #endif
            return;
        }
        Vector2 currentpos;

        Vector2 inputPosition = Input.mousePosition;
        if (Input.touchCount > 0)
            inputPosition = Input.GetTouch(0).position;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(padObject, inputPosition, mCamera, out currentpos);

        Vector2 dist = currentpos;
        Vector2 dir = dist.normalized;

        float maxDist = padObject.sizeDelta.x/2;

        if (dist.magnitude > maxDist)
        {
            dist = dir * padObject.sizeDelta.x/2;
        }
        else
        {
            dir *= dist.magnitude/maxDist;
        }

        dir = new Vector2(dir.x*Mathf.Cos(moveStartCameraAngle)-dir.y*Mathf.Sin(moveStartCameraAngle), dir.y*Mathf.Cos(moveStartCameraAngle)+dir.x*Mathf.Sin(moveStartCameraAngle));


        stickObject.anchoredPosition = dist;
        stickObject.localRotation = Quaternion.Euler(0,0,Mathf.Atan2(dist.y, dist.x)*Mathf.Rad2Deg-90);

        // if (Mathf.Abs(stickObject.localRotation.eulerAngles.z - prevStickRotZ) > 1)
        // {
        //     moveStartCameraAngle = -MapSceneManager.Instance.CurrentScene.GetCameraController().GetCamera().transform.eulerAngles.y*Mathf.Deg2Rad;
        //     prevStickRotZ = stickObject.localRotation.eulerAngles.z;
        // }
        moveStartCameraAngle = -MapSceneManager.Instance.CurrentScene.GetCameraController().GetCamera().transform.eulerAngles.y*Mathf.Deg2Rad;

        

        MapSceneManager.Instance.CurrentScene.PlayerPadMove(dir);

        
    }

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        clickHandler.onClickDown.Subscribe(OnStartPad).AddTo(mSubscriptions);
        clickHandler.onClickUp.Subscribe(OnEndPad).AddTo(mSubscriptions);
        mCamera = UI.Canvas.GetCanvas(CanvasType.App0).worldCamera;
        //padObject.gameObject.SetActive(false);

        // triggerButton.OnTouchUpInside.Subscribe(OnClickTrigger).AddTo(mSubscriptions);

        triggerButton.gameObject.SetActive(false);

        padInitPosition = padObject.anchoredPosition;
        padObject.GetComponent<CanvasGroup>().alpha = 0.1f;

        SignalBus.GlobalSignal.Subscribe(UIEventId.MapMovePadEnd, OnEndPadSignal).AddTo(mSubscriptions);
    }

    public override async UniTask HideAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.HideAsync(showType);
        if (mStarted)
        {
            OnEndPad(Vector2.zero);
            triggerButton.gameObject.SetActive(false);
        }
    }


    public override void Dispose()
    {
        base.Dispose();
        currentTarget = null;
    }


    private void OnStartPad(Vector2 position)
    {
        mStarted = true;
        
        RectTransformUtility.ScreenPointToLocalPointInRectangle(padContainer, position, mCamera, out mStartPosition);
        padObject.anchoredPosition = mStartPosition;
        stickObject.anchoredPosition = Vector2.zero;

        padObject.GetComponent<CanvasGroup>().alpha = 1;

        moveStartCameraAngle = -MapSceneManager.Instance.CurrentScene.GetCameraController().GetCamera().transform.eulerAngles.y*Mathf.Deg2Rad;
    }

    private void OnEndPad(Vector2 position)
    {
        mStarted = false;

        if (padObject == null)
        {
            return;
        }
        padObject.GetComponent<CanvasGroup>().alpha = 0.5f;
        padObject.anchoredPosition = padInitPosition;
        stickObject.anchoredPosition = Vector2.zero;
        stickObject.localRotation = Quaternion.identity;

        MapSceneManager.Instance.CurrentScene.PlayerPadMoveEnd();
    }

    private void OnEndPadSignal()
    {
        OnEndPad(Vector2.zero);
    }
}
