﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIMapBattleZonePage : UIPageBase
{
    UIMapBattleZoneMainWindow mMainWindow = null;
    UIMapOperationDialog mOperationDialog = null;
    UIPadController mPad = null;
    UIMapCommandDialog mCommandDialog = null;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIMapBattleZoneMainWindow, CanvasType.App0) as UIMapBattleZoneMainWindow;
        mOperationDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMapOperationDialog, CanvasType.BG) as UIMapOperationDialog;
        mPad = await UI.Dialog.CreateAsync(UIPrefabId.UIPadController, CanvasType.BG) as UIPadController;
        mCommandDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMapCommandDialog, CanvasType.App0) as UIMapCommandDialog;
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);

        await mMainWindow.ShowAsync(showType);
        await mOperationDialog.ShowAsync(showType);
        await mPad.ShowAsync(showType);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);

        await mMainWindow.HideAsync(showType);
        await mOperationDialog.HideAsync();
        await mPad.HideAsync(showType);

    }
    private async UniTask OnNavigationGroup(bool isActive)
    {
        mMainWindow.gameObject.SetActive(!isActive);
        mPad.gameObject.SetActive(!isActive);
        mOperationDialog.gameObject.SetActive(!isActive);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
        if (mPad != null)
        {
            mPad.Dispose();
            mPad = null;
        }
        if (mCommandDialog != null)
        {
            mCommandDialog.Dispose();
            mCommandDialog = null;
        }
        if (mOperationDialog != null)
        {
            mOperationDialog.Dispose();
            mOperationDialog = null;
        }
    }

    private void OnShowCommand()
    {
        AsyncManager.Instance.StartGuardAsync(mCommandDialog.ShowAsync());
    }

}
