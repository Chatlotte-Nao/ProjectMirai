using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UIMapBattleZoneMainWindow : UIDialogBase
{
    [SerializeField] UIButton backButton;
    [SerializeField] UIText placenameText;
    [SerializeField] UIText rewardNum;
    [SerializeField] UIHeaderResource staimina;
    [SerializeField] MapUi.HintButtonManager hintButton;
    [SerializeField] GameObject starRewardGroup;
    [SerializeField] UIButton starRewardButton;
    [SerializeField] UIButton navigationButton;
    [SerializeField] GameObject rewardOffObject;
    [SerializeField] GameObject rewardOnObject;
    [SerializeField] GameObject rewardFinishObject;
    [SerializeField] UIText starRewardNumLabel;
    [SerializeField] UIText starNumText;
    [SerializeField] Toggle skipBattleToggle;
    [SerializeField] private UIHeaderResource musicNum;
    [SerializeField] UIButton characterButton;
    [SerializeField] UIButton equipmentButton;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        placenameText.SetLabel(LocalizeManager.DATA_TYPE.LOCATION_NAME,
            DataManager.Instance.Master.Location[MapSceneManager.Instance.CurrentScene.GetNowMapLabel()].displayName);

        var master = DataManager.Instance.Master.BattleZone[DataManager.Instance.Local.BattleZone.currentBattleZoneId];

        starRewardGroup.SetActive(master.hasStarRewards);

        if (master.hasStarRewards)
        {
            //setup

            starRewardButton.OnTouchUpInside.GuardSubscribeAsync(onClickStarReward).AddTo(mSubscriptions);
            refreshStarReward();
        }

        hintButton.Initialize();

        // if (DataManager.Instance.Player.BattleZone.IsBattleZoneCleared(master.id))
        // {
        //     skipBattleToggle.gameObject.SetActive(true);
        //     skipBattleToggle.isOn = DataManager.Instance.Local.BattleZone.skipBattle;
        //     skipBattleToggle.onValueChanged.Subscribe(onSkipBattleToggle).AddTo(mSubscriptions);
        // }
        // else
        // {
        //     skipBattleToggle.gameObject.SetActive(false);
        // }

        characterButton.OnTouchUpInside.GuardSubscribeAsync(onClickCharacter).AddTo(mSubscriptions);
        equipmentButton.OnTouchUpInside.GuardSubscribeAsync(onClickEquipment).AddTo(mSubscriptions);

        backButton.OnTouchUpInside.Subscribe(OnClickBack).AddTo(mSubscriptions);
        navigationButton.OnTouchUpInside.SubscribeAsync(onClickNavigation).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe(UIEventId.MapSceneChanged, OnMapChanged).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe(UIEventId.UIHeaderInfoUpdate, StaiminaChanged).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe(UIEventId.OpenBattleZoneChest, onOpenChest).AddTo(mSubscriptions);
        staimina.OnClick.GuardSubscribeAsync(onClickAddStamina).AddTo(mSubscriptions);
        musicNum.SetIconImage(103002047);
    }

    public override void OnShow()
    {
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHeaderHide);
        base.OnShow();
    }

    async UniTask onClickNavigation()
    {
        var dialog =
            await UI.Dialog.CreateAsync(UIPrefabId.UIHomeNavigationWindow, CanvasType.App1) as UIHomeNavigationWindow;
        await dialog.SetUpOutSide();
        await dialog.ShowAsync(UIPageShowType.Front);
        await dialog.OpenNavigationGroupOutSide();
    }

    private async UniTask onClickCharacter()
    {
        await UI.Page.OpenPage<UIHomeCharacterMainPage>();
    }

    private async UniTask onClickEquipment()
    {
        await UI.Page.OpenPage<UIHomeEquipmentListPage>();
    }

    private void OnEnable()
    {
        if (AdvManager.Instance.CurrentScenarioId == 0)
        {
            return;
        }

        var sectionModel = StoryUtil.BuildSectionViewModel(AdvManager.Instance.CurrentScenarioId);

        rewardNum.SetRawText(string.Format("{0}/{1}", sectionModel.currentRewardNum, sectionModel.totalRewardNum));
        staimina.SetText(string.Format("{0}/{1}", DataManager.Instance.Player.Player.GetCurrentStaimina(),
            DataManager.Instance.Master.PlayerLevel[DataManager.Instance.Player.Player.GetLevel()].staminaLimit));
    }

    void onOpenChest()
    {
        if (AdvManager.Instance.CurrentScenarioId == 0)
        {
            return;
        }

        var sectionModel = StoryUtil.BuildSectionViewModel(AdvManager.Instance.CurrentScenarioId);

        rewardNum.SetRawText(string.Format("{0}/{1}", sectionModel.currentRewardNum, sectionModel.totalRewardNum));
    }

    void StaiminaChanged()
    {
        staimina.SetText(string.Format("{0}/{1}", DataManager.Instance.Player.Player.GetCurrentStaimina(),
            DataManager.Instance.Master.PlayerLevel[DataManager.Instance.Player.Player.GetLevel()].staminaLimit));
        musicNum.SetIconImage(103002047);
    }

    private void OnMapChanged()
    {
        placenameText.SetLabel(LocalizeManager.DATA_TYPE.LOCATION_NAME,
            DataManager.Instance.Master.Location[MapSceneManager.Instance.CurrentScene.GetNowMapLabel()].displayName);
    }

    private void onSkipBattleToggle(bool val)
    {
        DataManager.Instance.Local.BattleZone.skipBattle = val;
    }

    private async UniTask onClickStarReward()
    {
        var chapterData =
            DataManager.Instance.Player.BattleZone.Get(DataManager.Instance.Local.BattleZone.currentBattleZoneId);
        var master = DataManager.Instance.Master.BattleZone[DataManager.Instance.Local.BattleZone.currentBattleZoneId];
        var starNum = DataManager.Instance.Player.BattleZone.GetStarCount(master.id);
        if (chapterData.StageOneUpdateTime <= 0 && starNum >= master.requireStarNum1)
        {
            await BattleZoneService.GetStarReward(DataManager.Instance.Local.BattleZone.currentBattleZoneId, 1);
            await UI.Popup.ShowItemGetPopupAsync(DataManager.Instance.Master
                .BattleZone[DataManager.Instance.Local.BattleZone.currentBattleZoneId].starRewardContents1);
        }
        else if (chapterData.StageTwoUpdateTime <= 0 && starNum >= master.requireStarNum2)
        {
            await BattleZoneService.GetStarReward(DataManager.Instance.Local.BattleZone.currentBattleZoneId, 2);
            await UI.Popup.ShowItemGetPopupAsync(DataManager.Instance.Master
                .BattleZone[DataManager.Instance.Local.BattleZone.currentBattleZoneId].starRewardContents2);
        }
        else if (chapterData.StageThreeUpdateTime <= 0 && starNum >= master.requireStarNum3)
        {
            await BattleZoneService.GetStarReward(DataManager.Instance.Local.BattleZone.currentBattleZoneId, 3);
            await UI.Popup.ShowItemGetPopupAsync(DataManager.Instance.Master
                .BattleZone[DataManager.Instance.Local.BattleZone.currentBattleZoneId].starRewardContents3);
        }
        else
        {
            if (chapterData.StageOneUpdateTime <= 0)
            {
                await UI.Popup.ShowItemRewardsPopupAsync(DataManager.Instance.Master
                    .BattleZone[DataManager.Instance.Local.BattleZone.currentBattleZoneId].starRewardContents2);
            }
            else if (chapterData.StageTwoUpdateTime <= 0)
            {
                await UI.Popup.ShowItemRewardsPopupAsync(DataManager.Instance.Master
                    .BattleZone[DataManager.Instance.Local.BattleZone.currentBattleZoneId].starRewardContents2);
            }
            else if (chapterData.StageThreeUpdateTime <= 0)
            {
                await UI.Popup.ShowItemRewardsPopupAsync(DataManager.Instance.Master
                    .BattleZone[DataManager.Instance.Local.BattleZone.currentBattleZoneId].starRewardContents2);
            }
        }

        refreshStarReward();
    }

    private void refreshStarReward()
    {
        var master = DataManager.Instance.Master.BattleZone[DataManager.Instance.Local.BattleZone.currentBattleZoneId];
        var starNum = DataManager.Instance.Player.BattleZone.GetStarCount(master.id);
        var chapterData = DataManager.Instance.Player.BattleZone.Get(master.id);
        rewardOnObject.SetActive(false);
        if (chapterData.StageOneUpdateTime <= 0)
        {
            starNumText.SetRawText(string.Format("{0}/{1}", starNum, master.requireStarNum1));
            if (starNum >= master.requireStarNum1)
            {
                rewardOffObject.SetActive(false);
                rewardOnObject.SetActive(true);
            }
            else
            {
                rewardOffObject.SetActive(true);
                // starRewardButton.enabled = false;
            }
        }
        else if (chapterData.StageTwoUpdateTime <= 0)
        {
            starNumText.SetRawText(string.Format("{0}/{1}", starNum, master.requireStarNum2));
            if (starNum >= master.requireStarNum2)
            {
                rewardOffObject.SetActive(false);
                rewardOnObject.SetActive(true);
            }
            else
            {
                rewardOffObject.SetActive(true);
                // starRewardButton.enabled = false;
            }
        }
        else if (chapterData.StageThreeUpdateTime <= 0)
        {
            starNumText.SetRawText(string.Format("{0}/{1}", starNum, master.requireStarNum3));
            if (starNum >= master.requireStarNum3 && chapterData.StageTwoUpdateTime > 0)
            {
                rewardOffObject.SetActive(false);
                rewardOnObject.SetActive(true);
            }
            else
            {
                rewardOffObject.SetActive(true);
                // starRewardButton.enabled = false;
            }
        }
        else
        {
            starNumText.SetRawText(string.Format("{0}/{1}", starNum, master.requireStarNum3));
            rewardOffObject.SetActive(false);
            rewardFinishObject.SetActive(true);
            //starRewardButton.enabled = false;
        }
    }


    private void OnClickBack()
    {
        UI.Popup.ShowConfirm(string.Empty,
            LocalizeManager.Instance.GetCommonText("COMMONMENU_BACK_BUTTON_CONFIRM_MESSAGE"), CanvasType.App2, (r) =>
            {
                if (r == UIPopupDialog.Result.OK)
                {
                    AsyncManager.Instance.StartGuardAsync(async () =>
                    {
                        HomeSceneFromStoryParam p = new HomeSceneFromStoryParam();
                        p.enterType = HomeSceneParam.EnterType.FromStory;
                        p.endChapterMasterId = AdvManager.Instance.CurrentScenarioId;
                        p.isFinish = false;

                        await GameSceneManager.Instance.ChangeSceneAsync<HomeScene>("HomeScene", p);
                    });
                }
            });
    }

    private async UniTask onClickAddStamina()
    {
        await UI.Dialog.CreateAndShowAsync(UIPrefabId.StaminaRecover, CanvasType.App2);
    }
}