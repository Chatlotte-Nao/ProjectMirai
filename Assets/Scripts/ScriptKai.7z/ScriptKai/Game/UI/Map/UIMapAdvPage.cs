﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIMapAdvPage : UIPageBase
{
    UIMapAdvMainWindow mMainWindow = null;
    UIMapOperationDialog mOperationDialog = null;
    UIPadController mPad = null;
    UIMapNavigationDialog mNavi = null;
    
    // UIMapCommandDialog mCommandDialog = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIMapAdvMainWindow, CanvasType.App0) as UIMapAdvMainWindow;
        mOperationDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMapOperationDialog, CanvasType.BG) as UIMapOperationDialog;
        mNavi = await UI.Dialog.CreateAsync(UIPrefabId.UIMapNavigationDialog, CanvasType.BG) as UIMapNavigationDialog;
        mPad = await UI.Dialog.CreateAsync(UIPrefabId.UIPadController, CanvasType.BG) as UIPadController;
        
        // mCommandDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMapCommandDialog, CanvasType.App0) as UIMapCommandDialog;

        SignalBus.GlobalSignal.Subscribe(UIEventId.ADVCommandShow, OnShowCommand).AddTo(mSubscriptions);
        
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHeaderHide);
        await base.ShowAsync(showType);

        await mMainWindow.ShowAsync(showType);
        await mOperationDialog.ShowAsync(showType);
        await mPad.ShowAsync(showType);
        await mNavi.ShowAsync(showType);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);

        await mMainWindow.HideAsync(showType);
        await mOperationDialog.HideAsync();
        await mPad.HideAsync(showType);
        await mNavi.HideAsync(showType);
        // await mCommandDialog.HideAsync(showType);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
        if (mPad != null)
        {
            mPad.Dispose();
            mPad = null;
        }
        // if (mCommandDialog != null)
        // {
        //     mCommandDialog.Dispose();
        //     mCommandDialog = null;
        // }
        if (mOperationDialog != null)
        {
            mOperationDialog.Dispose();
            mOperationDialog = null;
        }
        if (mNavi != null)
        {
            mNavi.Dispose();
            mNavi = null;
        }
    }

    public async UniTask ShowGoalMessageAsync(List<int> goalMessageList)
    {
        await mMainWindow.ShowGoalMessageAsync(goalMessageList);
    }

    public async UniTask ShowGoalCompleteAsync(List<int> goalMessageList)
    {
        await mMainWindow.ShowGoalCompleteAsync(goalMessageList);
    }

    private void OnShowCommand()
    {
        
        // AsyncManager.Instance.StartGuardAsync(mCommandDialog.ShowAsync());
        AsyncManager.Instance.StartGuardAsync(async () =>
        {
            await UI.Page.OpenPage<UIMapCommandPage>();
        });
    }

}
