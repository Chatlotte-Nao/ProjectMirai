﻿
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;


public class UIWorldMapDialogCharaIcon : MonoBehaviour
{
    public TabToggle toggle;
    [SerializeField] private Image charaIcon;

    private void OnEnable()
    {
        toggle.isOn = false;
    }

    public void Init(long charaID)
    {
        toggle.isOn=false;
        gameObject.SetActive(true);
        var characterResourceId = DataManager.Instance.Master.BattleCharacter[charaID].characterResourceId;
        var timelineFaceId = DataManager.Instance.Master.CharacterResource[characterResourceId].timelineFaceId;
        AsyncManager.Instance.StartAsync(async () =>
        {
            charaIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("CharacterMain/Timeline", timelineFaceId);
        });
    }
    
    
    
    
    
    


    
    
    
    
}