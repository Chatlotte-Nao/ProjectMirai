﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIMapTutorialPage : UIPageBase
{
    UIPadController mPad = null;
    UIMapOperationDialog mOperationDialog = null;
    private UITutorialAdvMainWindow mMainWindow = null;
    UIMapNavigationDialog mNavi = null;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        
        mPad = await UI.Dialog.CreateAsync(UIPrefabId.UIPadController, CanvasType.BG) as UIPadController;
        mOperationDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMapOperationDialog, CanvasType.BG) as UIMapOperationDialog;
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UITutorialAdvMainWindow, CanvasType.App0) as UITutorialAdvMainWindow;
        mNavi = await UI.Dialog.CreateAsync(UIPrefabId.UIMapNavigationDialog, CanvasType.BG) as UIMapNavigationDialog;
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await mMainWindow.ShowGoalMessageAsync(new List<int> {24});
        await mPad.ShowAsync();
        await mOperationDialog.ShowAsync();
        await mNavi.ShowAsync();
        await mMainWindow.ShowAsync();
        await base.ShowAsync(showType);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);

        await mPad.HideAsync(showType);
        await mOperationDialog.HideAsync(showType);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mPad != null)
        {
            mPad.Dispose();
            mPad = null;
        }
        if (mOperationDialog != null)
        {
            mOperationDialog.Dispose();
            mOperationDialog = null;
        }
        if (mNavi != null)
        {
            mNavi.Dispose();
            mNavi = null;
        }
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
    }

}
