﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIWorldMapDialog : UIDialogBase
{
    [SerializeField] List<AreaItem> areasList;
    [SerializeField] RectTransform areaParent;
    [SerializeField] UIButton charaIconfoldButton;
    [SerializeField] UIButton areaSelectButton;
    [SerializeField] UIButton closeAreaSelectButton;
    [SerializeField] GameObject areaSelectPanel;
    [SerializeField] UIWorldMapDialogButton baseButton;
    [SerializeField] UIWorldMapDialogToggle baseToggle;
    [SerializeField] UIWorldMapDialogCharaIcon baseCharaIcon;
    [SerializeField] private GameObject baseAreaItem;
    public UnityEvent OnMapHide = new UnityEvent();
    [SerializeField] private UIWorldMapDialogButton playerLocationButton;


    private bool _isIconGroupFolding = false;

    public MapSelectEvent OnSelectTarget = new MapSelectEvent();

    public override void OnHide()
    {
        base.OnHide();
        OnMapHide.Invoke();
        if (_isIconGroupFolding)
        {
            charaIconfoldButton.OnTouchUpInside.Invoke();
        }
    }


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        await LoadMasterData();
        areaSelectButton.OnTouchUpInside.Subscribe(OpenAreaSelectPanel).AddTo(mSubscriptions);
        charaIconfoldButton.OnTouchUpInside.Subscribe(FoldIconGroup).AddTo(mSubscriptions);
        closeAreaSelectButton.OnTouchUpInside.Subscribe(CloseAreaSelectButton).AddTo(mSubscriptions);
      
    }

    private void CloseAreaSelectButton()
    {
        areaSelectPanel.gameObject.SetActive(false);
        closeAreaSelectButton.gameObject.SetActive(false);
    }


    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
    }


    public async UniTask SetUp()
    {
        
        // advPlayerIcon.gameObject.SetActive(false);
        areaSelectPanel.SetActive(false);
        closeAreaSelectButton.gameObject.SetActive(false);
        
        if (DataManager.Instance.Player.Character.GetNewCharaFlag())
        {
            await ExploreService.RequestExploreData();
            DataManager.Instance.Player.Character.SetNewCharaFlag(false);
        }

        await RefreshMasterData();
        // SetPlayerLocationButton
        var playerLocation = DataManager.Instance.Player.Player.GetData().Location;
        foreach (var areaItem in areasList)
        {
            foreach (var button in areaItem.AreaMapButtons)
            {
                if (button.name == playerLocation)
                {
                    playerLocationButton = button;
                    playerLocationButton.ActivePlayerLocationIcon(true);
                }
                else
                {
                    button.ActivePlayerLocationIcon(false);
                }
                button.OnClick.RemoveAllListeners();
                button.OnClick.GuardSubscribeAsync(onClickMapButton).AddTo(mSubscriptions);
                
            }
            
            areaItem.AreaToggle.onValueChanged.Subscribe(isOn =>
            {
                areaItem.AreaObj.SetActive(isOn);
                if (isOn)
                {
                    ActiveCharaIcons(areaItem);
                }
            }).AddTo(mSubscriptions);
            
            
            if (areaItem.AreaCharas != null)
            {
                foreach (var chara in areaItem.AreaCharas)
                {
                    void Handler(bool isOn)
                    {
                        chara.locationRoomButton.ActiveCharaImage(isOn, chara.charaID);
                    }
                    chara.charaIcon.toggle.onValueChanged.Subscribe(Handler).AddTo(mSubscriptions);
                    
                    
                    if (chara.hasInvite) chara.locationRoomButton.SetInviteImage();
                    if (chara.hasEvent) chara.locationRoomButton.SetEventImage();
                }
            }
            
            var isActiveArea = false;
            foreach (var itemButton in areaItem.AreaMapButtons)
            {
                if (playerLocationButton!=null&&itemButton.gameObject.name.Equals(playerLocationButton.gameObject.name))
                {
                    isActiveArea = true;
                    break;
                }
            }
            
            // var rect= areaItem.AreaObj.AddComponent<RectTransform>();
            // rect.anchoredPosition = new Vector2(0, 0);
            // rect.sizeDelta = new Vector2(0, 0); 
            // rect.anchorMax = new Vector2(1, 1);
            // rect.anchorMin = new Vector2(0, 0);
            areaItem.AreaToggle.isOn = isActiveArea;
            areaItem.AreaObj.SetActive(isActiveArea);
            if (isActiveArea)
            {
                ActiveCharaIcons(areaItem);
            }
            
        }

        Invoke(nameof(OpenIconGroup), 0.1f);
    }

    private async UniTask RefreshMasterData()
    {
        foreach (var areaItem in areasList)
        {
            for (int i = 0; i < areaItem.AreaMapButtons.Count; i++)
            {
                Destroy(areaItem.AreaMapButtons[i].gameObject);
            }
            Destroy(areaItem.AreaToggle.gameObject);
            Destroy(areaItem.AreaObj.gameObject);
            if (areaItem.AreaCharas!=null)
            {
                for (int i = 0; i < areaItem.AreaCharas.Count; i++)
                {
                    Destroy(areaItem.AreaCharas[i].charaIcon.gameObject);
                }
            }
        }
        await LoadMasterData();
    }


    void OpenIconGroup()
    {
        
        if (!_isIconGroupFolding)
        {
            charaIconfoldButton.OnTouchUpInside.Invoke();
        }
    }


    void ActiveCharaIcons(AreaItem area)
    {
        foreach (var areaItem in areasList)
        {
            var isCharaInArea = areaItem.AreaObj.name == area.AreaObj.name;
            if (areaItem.AreaCharas != null)
            {
                foreach (var chara in areaItem.AreaCharas)
                {
                    chara.charaIcon.gameObject.SetActive(false);
                    chara.charaIcon.gameObject.SetActive(isCharaInArea);
                }
            }
        }

        // foreach (var areaItem in areasList)
        // {
        //     if (areaItem.AreaCharas != null)
        //     {
        //         foreach (var chara in areaItem.AreaCharas)
        //         {
        //         }
        //     }
        // }

        // RefreshFoldButtonPoisiton
        if (_isIconGroupFolding)
        {
            LayoutRebuilder.ForceRebuildLayoutImmediate(charaIconfoldButton.transform.GetChild(0)
                .GetComponent<RectTransform>());
            var foldGroupRect = charaIconfoldButton.GetComponent<RectTransform>();
            foldGroupRect.anchoredPosition =
                new Vector2(charaIconfoldButton.transform.GetChild(0).GetComponent<RectTransform>().sizeDelta.x + 20,
                    0);
        }

        var noIconActive = true;
        for (int i = 0; i < baseCharaIcon.transform.parent.childCount; i++)
        {
            if (baseCharaIcon.transform.parent.GetChild(i).gameObject.activeSelf)
            {
                noIconActive = false;
                break;
            }
        }

        charaIconfoldButton.GetComponent<CanvasGroup>().alpha = noIconActive ? 0 : 1;
    }

    private void FoldIconGroup()
    {
        _isIconGroupFolding = !_isIconGroupFolding;
        var foldGroupRect = charaIconfoldButton.GetComponent<RectTransform>();
        var xValue = _isIconGroupFolding
            ? charaIconfoldButton.transform.GetChild(0).GetComponent<RectTransform>().sizeDelta.x + 20
            : 0;
        DOTween.To(() => foldGroupRect.anchoredPosition, x => foldGroupRect.anchoredPosition = x,
            new Vector2(xValue, 0), 0.3f);
        charaIconfoldButton.transform.GetChild(1).GetComponent<RectTransform>().localScale =
            _isIconGroupFolding ? new Vector2(-1, 1) : new Vector2(1, 1);
    }

    private void OpenAreaSelectPanel()
    {
        areaSelectPanel.SetActive(true);
        closeAreaSelectButton.gameObject.SetActive(true);
    }

    private async UniTask LoadMasterData()
    {
        var screenSize = new Vector2(Screen.width, Screen.height);
        areasList ??= new List<AreaItem>();
        areasList.Clear();
        var master = DataManager.Instance.Master.WolrdMap;
        foreach (var item in master.Values)
        {
            var areaName = item.areaDisplayName;
            var areaItem = areasList.FirstOrDefault(x => x.AreaObj.name == areaName);
            if (areaItem == null)
            {
                areaItem = new AreaItem();
                areaItem.AreaMapButtons = new List<UIWorldMapDialogButton>();
                areaItem.AreaToggle = Instantiate(baseToggle.gameObject,
                    baseToggle.transform.parent).GetComponent<Toggle>();
                areaItem.AreaToggle.gameObject.name = areaName;
                await areaItem.AreaToggle.GetComponent<UIWorldMapDialogToggle>()
                    .Init(item.areaMiniBG, item.areaDisplayName);
                areaItem.AreaObj = Instantiate(baseAreaItem, areaParent);
                areaItem.AreaObj.name = areaName;
                areaItem.id = item.id;
                var areaObjImage = areaItem.AreaObj.GetComponent<Image>();
                areaObjImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("Map", item.areaBG);
                areasList.Add(areaItem);
            }

            var tempButton = Instantiate(baseButton.gameObject, areaItem.AreaObj.transform)
                .GetComponent<UIWorldMapDialogButton>();

            tempButton.Init(item.label, item.displayName, item.postion,item.visibleLevel,item.linkLineDir,item.unlockId);

            areaItem.AreaMapButtons.Add(tempButton);
        }


        foreach (var chara in DataManager.Instance.Player.Explore.GetData().CurrentBattleCharacters) //所有的角色
        {
            if (chara.ExplorePointMasterId == 0) continue;
            var pmaster = DataManager.Instance.Master.ExplorePoint[chara.ExplorePointMasterId];
            foreach (var areaItem in areasList)
            {
                foreach (var button in areaItem.AreaMapButtons)
                {
                    if (button.name == pmaster.mapId)
                    {
                        var tempIcon = Instantiate(baseCharaIcon.gameObject, baseCharaIcon.transform.parent)
                            .GetComponent<UIWorldMapDialogCharaIcon>();

                        var tempChara = new AreaChara()
                        {
                            charaID = chara.BattleCharacterMasterId,
                            locationRoomButton = button,
                            AreaObj = areaItem.AreaObj,
                            charaIcon = tempIcon,
                        };

                        bool hasInvite = false;
                        foreach (var item in DataManager.Instance.Local.Explore.playerData.eventList)
                        {
                            if (item.Value.Master.battleCharacterMasterId == tempChara.charaID &&
                                item.Value.finishCount == 0 && item.Value.CanStart())
                            {
                                hasInvite = true;
                                break;
                            }
                        }

                        #region 茶歇相关HasNewKeyword设置

                        List<int> masterKeys = new List<int>();
                        List<int> type0Keywords = new List<int>();
                        List<int> type1Keywords = new List<int>();
                        var playerBattleCharacter = DataManager.Instance.Player.Character.TryGet(tempChara.charaID);
                        var isContract = !(playerBattleCharacter.Engaged == 0);
                        long characterMasterId = 0;

                        foreach (var kv in DataManager.Instance.Master.PrivateTalk)
                        {
                            if (kv.Value.battleCharacterMasterId == tempChara.charaID)
                            {
                                characterMasterId = kv.Value.characterMasterId;
                                masterKeys.Add(DataManager.Instance.Master.PrivateTalk[kv.Key].keywordId);
                            }
                        }

                        foreach (var keywordId in masterKeys)
                        {
                            var keywordMaster = DataManager.Instance.Master.Keyword[keywordId];
                            if (keywordMaster.type == 0)
                            {
                                type0Keywords.Add(keywordId);
                            }
                            else if (keywordMaster.type == 1)
                            {
                                type1Keywords.Add(keywordId);
                            }
                        }

                        bool HasNewKeyword = false;

                        foreach (var keywordId in masterKeys)
                        {
                            var keywordMaster = DataManager.Instance.Master.Keyword[keywordId];

                            if (isKeywordLocked())
                            {
                                continue;
                            }
                            if (isReaded(keywordId, characterMasterId))
                            {
                                continue;
                            }
                            else
                            {
                                HasNewKeyword = true;
                                break;
                            }

                            #region 茶歇local函数

                            bool isKeywordLocked()
                            {

                                return (type0Keywords.Contains(keywordId) && (keywordMaster.level > GetBondsLevel(tempChara.charaID)) || (keywordMaster.level >= 4 && !isContract)) || (type1Keywords.Contains(keywordId) && DataManager.Instance.Player.Keyword.TryGet(keywordId) == null);
                            }

                            #endregion
                        }

                        if (!UIInteractiveSecondDialog.IsTeaBreakOpen())
                        {
                            HasNewKeyword = false;
                        }

                        # endregion

                        tempChara.hasInvite = hasInvite || HasNewKeyword;
                        tempIcon.Init(tempChara.charaID);
                        areaItem.AreaCharas ??= new List<AreaChara>();
                        areaItem.AreaCharas.Add(tempChara);
                    }
                }
            }
        }
    }


    private async UniTask onClickMapButton(GameObject o)
    {
        SelectTarget t = new SelectTarget();
        t.mapName = o.name;

        //await HideAsync();

        OnSelectTarget.Invoke(t);
    }

    private async UniTask onClickRoomButton(GameObject o)
    {
        SelectTarget t = new SelectTarget();
        t.mapName = o.transform.parent.name;
        t.roomName = o.name;

        await HideAsync();

        OnSelectTarget.Invoke(t);
    }

    [System.Serializable]
    public class AreaItem
    {
        public GameObject AreaObj;
        public int id;
        public Toggle AreaToggle;
        public List<UIWorldMapDialogButton> AreaMapButtons;
        public List<AreaChara> AreaCharas;
    }

    [Serializable]
    public class AreaChara
    {
        public long charaID;
        public UIWorldMapDialogButton locationRoomButton;
        public UIWorldMapDialogCharaIcon charaIcon;
        public GameObject AreaObj;
        public bool hasInvite;
        public bool hasEvent;
    }

    public class SelectTarget
    {
        public string mapName;
        public string roomName;
    }


    public class MapSelectEvent : UnityEvent<SelectTarget>
    {}

    #region 茶歇判断相关代码

    private bool isReaded(int keywordId, long characterId)
    {
        var keyword = DataManager.Instance.Player.Keyword.TryGet(keywordId);
        if (keyword != null)
        {
            return keyword.CharacterMasterIds.Contains(characterId);
        }

        return false;
    }

    private int GetBondsLevel(long battleCharacterMasterId)
    {
        return DataManager.Instance.Player.Bond.GetLevel(battleCharacterMasterId);
    }

    #endregion
}