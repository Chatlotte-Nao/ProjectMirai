﻿using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;


public class UIWorldMapDialogButton : MonoBehaviour
{
    [SerializeField] public UIButton button;
    [SerializeField] public UIButton disableButton;
    [SerializeField] private Image charaImage;
    [SerializeField] private GameObject eventHintImage;
    [SerializeField] private GameObject inviteHintImage;
    [SerializeField] private UIText text;
    [SerializeField] private GameObject lockGroup;
    [SerializeField] private Animation lockAnimation;
    [SerializeField] GameObject playerLocationIcon;
    public bool _isPlayerInRoom = false;
    [SerializeField] private List<GameObject> LinkLines;

    [SerializeField] private int _unlockId;
    public string roomName => gameObject.name;
    public ClickEvent OnClick => button.onClick;

    // [SerializeField] private int unlockId;
    [SerializeField] private string lockedScenarioId;

    private void OnEnable()
    {
        if (_unlockId!=0)
        {
            
            if (!CommonUtil.IsFunctionUnlock(_unlockId,false))
            {
                lockGroup.SetActive(true);
                button.enabled = false;
                return;
            }
            if (!DataManager.Instance.Local.Scenarios.UnlockWorldMapButtonIds.Contains(_unlockId))
            {
                lockGroup.SetActive(true);
                DataManager.Instance.Local.Scenarios.UnlockWorldMapButtonIds.Add(_unlockId);
                DataManager.Instance.Local.Save();
                lockAnimation.Play();
                PlayAnimation();
            }
        }
    }

    //todo 播adv演出 lockedScenarioId
    private async UniTask CallScenario(string lockedScenarioId)
    {
    }

    private void DisableHint()
    {
        
    }

    public void ActivePlayerLocationIcon(bool isActive)
    {
        playerLocationIcon.gameObject.SetActive(isActive);
        _isPlayerInRoom = isActive;
    }

    private void OnDestroy()
    {
        disableButton.OnTouchUpInside.RemoveAllListeners();
        
    }

    public void ActiveCharaImage(bool isActive, long charaID)
    {
        
        var characterResourceId = DataManager.Instance.Master.BattleCharacter[(int) charaID].characterResourceId;
        var master = DataManager.Instance.Master.CharacterResource[characterResourceId];
        AsyncManager.Instance.StartAsync(async () =>
        {
            charaImage.sprite =await ResourceManager.Instance.LoadSpriteAsync("CharacterMain/BgProfile", master.bgProfileName);
            charaImage.gameObject.SetActive(isActive);
            if (charaImage.gameObject.activeSelf && playerLocationIcon.gameObject.activeSelf)
            {
                playerLocationIcon.SetActive(false);
            }
            
            if (!isActive && _isPlayerInRoom)
            {
                playerLocationIcon.gameObject.SetActive(true);
            }
        });
    }

    public void ShowButton()
    {
        gameObject.SetActive(true);
    }


    public void Init(string label, string textName, string postion,int visibleLevel,string linkLineDir,int unlockId=0)
    {
        
        
        _unlockId = unlockId;
        if (!string.IsNullOrEmpty(linkLineDir))
        {
            LinkLines.Find(x=>x.name==linkLineDir).SetActive(true);
        }
        gameObject.name = label;
        text.SetLabel(LocalizeManager.DATA_TYPE.LOCATION_NAME, textName);
        var t = postion.Split('_');
        var x = Convert.ToSingle(t[0]);
        var y = Convert.ToSingle(t[1]);
        GetComponent<RectTransform>().anchoredPosition = new Vector2(x, y);
        gameObject.SetActive(true);
        if (visibleLevel==1)
        {
            gameObject.SetActive(false);
        }

        _unlockId = unlockId;
        
        disableButton.OnTouchUpInside.SubscribeAsync(async () =>
        {
            var t = _unlockId;
            var t2 = lockedScenarioId;
            if (!string.IsNullOrEmpty(t2))
            {
                await CallScenario(t2);
            }
            CommonUtil.IsFunctionUnlock(t, true);
        });
        
    }

    void PlayAnimation()
    {
        AsyncManager.Instance.StartAsync(PlayAnimationAsync);
    }

    private async UniTask PlayAnimationAsync()
    {
        var time = lockAnimation.clip.length;
        await UniTask.Delay((int)(time * 1000));
        lockGroup.SetActive(false);
        button.enabled = true;
    }

    private void OnDisable()
    {
        HideImages();        

    }

    public void HideImages()
    {
        charaImage.gameObject.SetActive(false);
        playerLocationIcon.gameObject.SetActive(false);
        eventHintImage.gameObject.SetActive(false);
        inviteHintImage.gameObject.SetActive(false);
    }

    public void SetInviteImage()
    {
        inviteHintImage.gameObject.SetActive(true);
    }

    public void SetEventImage()
    {
        eventHintImage.gameObject.SetActive(true);
    }
}