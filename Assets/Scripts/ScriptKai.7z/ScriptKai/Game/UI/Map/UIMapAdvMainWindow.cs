﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIMapAdvMainWindow : UIDialogBase
{
    [SerializeField] UIButton backButton;
    [SerializeField] UIText placenameText;
    [SerializeField] GoalMessageController goalMessageController;
    [SerializeField] Adventure.UI.Clock clock;
    [SerializeField] UIText rewardNum;
    [SerializeField] UIHeaderResource staimina;
    [SerializeField] MapUi.HintButtonManager hintButton;

    [SerializeField] UIButton characterButton;
    [SerializeField] UIButton equipmentButton;
    [SerializeField] UIButton navigationButton;

    private void OnEnable()
    {
        var sectionModel = StoryUtil.BuildSectionViewModel(AdvManager.Instance.CurrentScenarioId);

        rewardNum.SetRawText(string.Format("{0}/{1}", sectionModel.currentRewardNum, sectionModel.totalRewardNum));
        staimina.SetText(string.Format("{0}/{1}", DataManager.Instance.Player.Player.GetCurrentStaimina(), DataManager.Instance.Master.PlayerLevel[DataManager.Instance.Player.Player.GetLevel()].staminaLimit));
    }

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        placenameText.SetLabel(LocalizeManager.DATA_TYPE.LOCATION_NAME, DataManager.Instance.Master.Location[MapSceneManager.Instance.CurrentScene.GetNowMapLabel()].displayName);
        
        
        characterButton.OnTouchUpInside.GuardSubscribeAsync(onClickCharacter).AddTo(mSubscriptions);
        equipmentButton.OnTouchUpInside.GuardSubscribeAsync(onClickEquipment).AddTo(mSubscriptions);
        navigationButton.OnTouchUpInside.GuardSubscribeAsync(onClickNavigation).AddTo(mSubscriptions);

        hintButton.Initialize();

        backButton.OnTouchUpInside.Subscribe(OnClickBack).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe(UIEventId.MapSceneChanged, OnMapChanged).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe(UIEventId.UIHeaderInfoUpdate, refreshInfo).AddTo(mSubscriptions);
        staimina.OnClick.GuardSubscribeAsync(onClickAddStamina).AddTo(mSubscriptions);
    }

    void refreshInfo()
    {
       staimina.SetText(string.Format("{0}/{1}", DataManager.Instance.Player.Player.GetCurrentStaimina(), DataManager.Instance.Master.PlayerLevel[DataManager.Instance.Player.Player.GetLevel()].staminaLimit));
    }
    private long mStaminaNextUpdateTime = -1;
    void Update()
    {
        if (mStaminaNextUpdateTime > 0 && GlobalTime.UtcNow.ToUnixTimeSeconds() >= mStaminaNextUpdateTime)
        {
            staimina.SetText(string.Format("{0}/{1}",
                DataManager.Instance.Player.Player.GetCurrentStaimina(),
                DataManager.Instance.Master.PlayerLevel[DataManager.Instance.Player.Player.GetLevel()].staminaLimit));
            mStaminaNextUpdateTime = DataManager.Instance.Master
                .GlobalConfig[TakashoUtil.GlobalConfigID.StaminaRecoveryCycle].data;
        }
       
    }

    async UniTask onClickNavigation()
    {
        var dialog= await UI.Dialog.CreateAsync(UIPrefabId.UIHomeNavigationWindow, CanvasType.App1) as UIHomeNavigationWindow;
        await dialog.SetUpOutSide();
        await dialog.ShowAsync(UIPageShowType.Front);
        await dialog.OpenNavigationGroupOutSide();
    }

    private async UniTask onClickCharacter()
    {
        await UI.Page.OpenPage<UIHomeCharacterMainPage>(true);
    }

    private async UniTask onClickEquipment()
    {
        await UI.Page.OpenPage<UIHomeEquipmentListPage>();
    }

    private void OnMapChanged()
    {
        placenameText.SetLabel(LocalizeManager.DATA_TYPE.LOCATION_NAME, DataManager.Instance.Master.Location[MapSceneManager.Instance.CurrentScene.GetNowMapLabel()].displayName);
    }


    public async UniTask ShowGoalMessageAsync(List<int> goalMessageList)
    {
        await goalMessageController.SetCurrentMessageRoutine(goalMessageList);

        //显示弹窗，滑入，关闭弹窗，滑入

        //hintButton.HintDialog.Open(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.GOAL_MESSAGE_HINT, goalMessageController.GetEndHintString()), true);
    }

    public async UniTask ShowGoalCompleteAsync(List<int> goalMessageList)
    {
        await goalMessageController.Clear(goalMessageList);
        //显示弹窗，显示clear，关闭弹窗（清除），滑出
    }

    private void OnClickBack()
    {
        UI.Popup.ShowConfirm(string.Empty, LocalizeManager.Instance.GetCommonText("COMMONMENU_BACK_BUTTON_CONFIRM_MESSAGE"), CanvasType.App2, (r)=>
        {
            if (r == UIPopupDialog.Result.OK)
            {
                AsyncManager.Instance.StartGuardAsync(async()=>
                {
                    HomeSceneFromStoryParam p = new HomeSceneFromStoryParam();
                    p.enterType = HomeSceneParam.EnterType.FromStory;
                    p.endChapterMasterId = AdvManager.Instance.CurrentScenarioId;
                    p.isFinish = false;
                    
                    await GameSceneManager.Instance.ChangeSceneAsync<HomeScene>("HomeScene", p);
                    
                    // await ExploreService.RequestExploreData(); 
                    // GameSceneManager.Instance.ChangeScene<ExploreScene>("ExploreScene");
                });
            }
        });
    }

    private async UniTask onClickAddStamina()
    {
        await UI.Dialog.CreateAndShowAsync(UIPrefabId.StaminaRecover, CanvasType.App2);
    }
}
