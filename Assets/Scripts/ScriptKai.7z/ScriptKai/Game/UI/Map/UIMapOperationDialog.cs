using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using Map;

public class UIMapOperationDialog : UIDialogBase
{
    [SerializeField] GameObject baseGroup;
    [SerializeField] UIButton[] objectPointButton;
    [SerializeField] UIButton[] objectTriggerButton;
    [SerializeField] UIButton eventButton;


    Dictionary<int,bool> fadingIndexDic=new Dictionary<int,bool>(){};

    private List<IMapOperationTarget> triggerObjects = new List<IMapOperationTarget>();


    void Update()
    {
        eventButton.gameObject.SetActive(false);
        if (MapSceneManager.Instance.CurrentScene == null || MapSceneManager.Instance.CurrentScene.staticObjects == null)
        {
            baseGroup.SetActive(false);
            return;
        }
        
        if (MapSceneManager.Instance.CurrentScene.player.currentActionObject != null)
        {
            baseGroup.SetActive(false);
        }
        else if (TutorialManager.Instance.GetIsGoalTutorial)
        {
            if (MapSceneManager.Instance.CurrentScene != null &&
                TutorialManager.Instance.GetIsGoalTrigger())
            {
                baseGroup.SetActive(false);
                checkObjectButton(true);
            }
            else
            {
                baseGroup.SetActive(false);
            }
        }
        else
        {
            baseGroup.SetActive(true);

            checkObjectButton();
        }
        
    }


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        //for (int i = 0; i < objectPointButton.Length; i++)
        //{
        //    var idx = i;
        //    objectPointButton[i].OnTouchUpInside.Subscribe(()=>{OnClickObjectTrigger(idx);}).AddTo(mSubscriptions);
        //}
        
        for (int i = 0; i < objectTriggerButton.Length; i++)
        {
            var idx = i;
            objectTriggerButton[i].OnTouchUpInside.Subscribe(()=>{OnClickObjectTrigger(idx);}).AddTo(mSubscriptions);
        }
        
        // eventButton.OnTouchUpInside.Subscribe(()=>{OnClickEventButton();}).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe<string>(UIEventId.GoalTriggerMaster, OnSetTriggerMaster).AddTo(mSubscriptions);
    }

    private Vector3 mTutoriaGoalTraget;
    void OnSetNaviTarget(Vector3 Vector)
    {
        mTutoriaGoalTraget = Vector;
    }

    private string goalTriggerName_;
    void OnSetTriggerMaster(string goalTriggerName)
    {
        goalTriggerName_ =  goalTriggerName;
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
    }

    private bool IsGoalTrigger(string name)
    {
        return name == goalTriggerName_;
    }

    private void checkObjectButton(bool isTrigger = false)
    {
        int idx = 0;
        string nameflag = "";
        triggerObjects.Clear();
        foreach (var item in MapSceneManager.Instance.CurrentScene.staticObjects)
        {
            if (item.Value.CanSelect)
            {
                if (isTrigger && !IsGoalTrigger(item.Key))
                {
                    continue;
                }
                triggerObjects.Add(item.Value);
                if (idx < objectTriggerButton.Length)
                {
                    // objectTriggerButton[idx].gameObject.SetActive(true);
                    
                    FadeButton(objectTriggerButton[idx].gameObject, idx, true);
                    foreach (var name in DataManager.Instance.Master.InteractiveButtonMaster)
                    {
                        if (item.Value.gameObject.gameObject.name== name.Value.interactiveTargetId)
                        {
                            nameflag = name.Value.primaryInteractiveButtonId;
                        }
                    }
                    
                    setupButton(objectTriggerButton[idx].gameObject, LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.EXPLORE, nameflag), 0);
                }
                //if (idx < objectPointButton.Length)
                //{
                //    objectPointButton[idx].gameObject.SetActive(true);
                //    Vector2 screenPos = MapSceneManager.Instance.CurrentScene.GetCameraController().GetCamera().WorldToScreenPoint(item.Value.transform.position);
                //    var uiCamera = SceneBase.Current.UICamera;

                //    RectTransformUtility.ScreenPointToLocalPointInRectangle(transform.parent.GetComponent<RectTransform>(), screenPos, uiCamera, out var t);
                //    objectPointButton[idx].GetComponent<RectTransform>().anchoredPosition = t;
                //}
                
                idx++;
            }
        }

        var pIdx = idx;

        //while (pIdx < objectPointButton.Length)
        //{
        //    objectPointButton[pIdx++].gameObject.SetActive(false);
        //}

        List<Map.AMapRuntimeObject> targetList = new List<Map.AMapRuntimeObject>();
        targetList.AddRange(MapSceneManager.Instance.CurrentScene.characters.Values);
        targetList.AddRange(MapSceneManager.Instance.CurrentScene.iconObjects.Values);
        targetList.AddRange(MapSceneManager.Instance.CurrentScene.enemys.Values);

        float minD = 2f;

        foreach (var t in targetList)
        {
            if (!t.gameObject.activeInHierarchy) continue;
            if (t.getOperationType()== (IMapOperationTarget.OperationTargetType.Enemy)) continue; //怪物改成不显示右下角”战斗“选项框 如改回显示的方案，注释这行
            var d = Vector3.Distance(t.transform.position, MapSceneManager.Instance.CurrentScene.player.transform.position);
            if (isTrigger&&t.getOperationType()== (IMapOperationTarget.OperationTargetType.Chara) && !IsGoalTrigger(t.getCharacterMasterId().ToString())) continue;
            if (d<minD)
            {
                triggerObjects.Add(t);
                if (idx < objectTriggerButton.Length)
                {
                    // objectTriggerButton[idx].gameObject.SetActive(true);
                    FadeButton(objectTriggerButton[idx].gameObject, idx, true);
                    if (t.getOperationType() == IMapOperationTarget.OperationTargetType.Default)
                    {
                        setupButton(objectTriggerButton[idx].gameObject, t.getOperationText(), 0);
                    }
                    else
                    {
                        setupButton(objectTriggerButton[idx].gameObject, t.getOperationText(), 1);
                    }

                    // setupEventButton(triggerObjects[idx].getCharacterMasterId());
                }
                idx++;
            }
        }

        pIdx = idx;

        while (idx < objectTriggerButton.Length)
        {
            FadeButton(objectTriggerButton[idx].gameObject, idx, false);
            idx++;
        }

        if (isTrigger && triggerObjects.Count > 0)
        {
            baseGroup.SetActive(true);
        }
    }


    void FadeButton(GameObject trggierBuuton , int index,bool isIn)
    {
        if (!fadingIndexDic.ContainsKey(index)) fadingIndexDic.Add(index,false);
        if (isIn)
        {
            if (!fadingIndexDic[index])
            {
                objectTriggerButton[index].gameObject.SetActive(true);
                var cg = trggierBuuton.GetComponent<CanvasGroup>();
                fadingIndexDic[index] = true;
                Tween tween = DOTween.To(() => cg.alpha, x => cg.alpha = x, 1, 0.3f);
                tween.onComplete += () => { fadingIndexDic[index] = false; };
            }
        }
        else
        {
            if (!fadingIndexDic[index])
            {
                var cg = trggierBuuton.GetComponent<CanvasGroup>();
                fadingIndexDic[index] = true;
                Tween tween = DOTween.To(() => cg.alpha, x => cg.alpha = x, 0, 0.3f);
                tween.onComplete += () => { fadingIndexDic[index] = false; 
                    objectTriggerButton[index].gameObject.SetActive(false);};
            }
        }
    }

    //0:search 1:talk 2:battle
    private void setupButton(GameObject button, string text, int type)
    {
       // Debug.LogErrorFormat(button,"          ", text,"             ", type);
        var t = button.transform.Find("icon");
        foreach (Transform icon in t)
        {
            if (icon.name == type.ToString())
            {
                icon.gameObject.SetActive(true);
            }
            else
            {
                icon.gameObject.SetActive(false);
            }
        }
        button.GetComponentInChildren<UIText>().SetRawText(text);
    }

    // private ExploreEventViewModel eventModel;
    // private bool ongoing = false;
    // private void setupEventButton(long charaMasterId)
    // {
    //     
    //     //刷新名字
    //     // var text = "";
    //     var data = DataManager.Instance.Local.Explore.playerData;
    //     var sortedList = new List<ExploreEventViewModel>(data.eventList.Values);
    //     var list = new List<ExploreEventViewModel>();
    //     foreach (var item in sortedList)
    //     {
    //         if (item.Master.battleCharacterMasterId == charaMasterId)
    //         {
    //             list.Add(item);
    //         }
    //     }
    //     eventModel = null;
    //     foreach (var Model in list)
    //     {
    //         ongoing = Model.eventStatus == ExploreEventViewModel.EventStatus.Accepted;
    //         if (Model.finishCount == 0 && Model.CanStart())
    //         {
    //             eventModel = Model;
    //             break;
    //         }
    //     }
    //     //显隐
    //     if (eventModel == null) return;
    //     eventButton.gameObject.SetActive(true);
    //     eventButton.GetComponentInChildren<UIText>().SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{eventModel.masterId}_title");
    //
    //
    //     //刷新点击事件
    //
    // }

    private void OnClickObjectTrigger(int idx)
    {
        var obj = triggerObjects[idx];
        
        obj.DoOperation();
    }

    // private async UniTask OnClickEventButton()
    // {
    //     UIExploreEventCheckOutDialog checkOutDialog= await UI.Dialog.CreateAndShowAsync(UIPrefabId.UIExploreEventCheckOutDialog, CanvasType.App1) as UIExploreEventCheckOutDialog;
    //     await checkOutDialog.SetupAsync(eventModel, UIExploreEventCheckOutDialog.ExplorEventCheckOutType.invite, !ongoing);
    //     
    // }
}

public interface IMapOperationTarget
{
    public enum OperationTargetType
    {
        Default=0,
        Chara=1,
        Enemy=2,
    }

    string getOperationText();
    OperationTargetType getOperationType();
    long getCharacterMasterId();
    void DoOperation();
}
