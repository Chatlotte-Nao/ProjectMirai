﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIMapCommandPage : UIPageBase
{
    UIMapCommandDialog mCommandDialog = null;
    

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        
        mCommandDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMapCommandDialog, CanvasType.App0) as UIMapCommandDialog;
        // await mCommandDialog.Setup(param as UIExploreCommandParam);
    }


    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        if (showType == UIPageShowType.Front)
            MapSceneManager.Instance.ShowCurrent();

        await mCommandDialog.ShowAsync(showType);

    }
    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await mCommandDialog.HideAsync();
    }
    public override void Dispose()
    {
        if (mCommandDialog != null)
        {
            mCommandDialog.Dispose();
            mCommandDialog = null;
        }

        base.Dispose();
    }
}