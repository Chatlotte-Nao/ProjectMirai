﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIMapCommandDialog : UIDialogBase
{
    [SerializeField] MapUi.SearchCommandManager commandManager;
    [SerializeField] protected UIButton backButton;


    [SerializeField] private List<float> XOffsetList;
    [SerializeField] private Transform buttonListTr;

    // private GameObject bgObject = null;

    private string currentLabel = null;


    private void SetButtonOffset()
    {
        int activeFlag = 0;
        for (int i = 0; i < buttonListTr.childCount; i++)
        {
            if (buttonListTr.GetChild(i).childCount==0)
            {
                continue;
            }
            var button = buttonListTr.GetChild(i).GetChild(0);
            if (button.gameObject.activeSelf) 
            {
                button.transform.GetComponent<RectTransform>().anchoredPosition=new Vector2(XOffsetList[activeFlag],0);
                activeFlag++;
            }
            else
            {
                button.transform.parent.gameObject.SetActive(false);
            }
        }
    }

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        backButton.onClick.GuardSubscribeAsync(BackClick).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        var label = MapSceneManager.Instance.CurrentScene.label;
        if (label != currentLabel)
        {
            currentLabel = label;
            // if (bgObject != null)
            // {
            //     Destroy(bgObject);
            //     bgObject = null;
            // }

            // var bg = DataManager.Instance.Master.Location[label].advBg;
            // if (!string.IsNullOrEmpty(bg))
            // {
            //     bgObject = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/bg/"+bg, UI.Canvas.GetCanvas(CanvasType.BG).transform);
            //
            //     foreach (var item in bgObject.GetComponentsInChildren<Renderer>())
            //     {
            //         item.gameObject.layer = LayerMask.NameToLayer("UI");
            //     }
            //
            //     bgObject.transform.localPosition = Vector3.zero;
            //     bgObject.transform.localScale = new Vector3(52,52,1);
            //     bgObject.name = "Ezzzzzzz";
            // }
        }
        // else
        // {
        //     if (bgObject != null)
        //     {
        //         bgObject.SetActive(true);
        //         bgObject.name = "Ezzzzzzz";
        //     }
        // }
        


        ZoomPlayer(true, 0.6f);
        commandManager.SetSearchCommand();
        await base.ShowAsync(showType);
        SetButtonOffset();
    }

    public override async UniTask HideAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.HideAsync(showType);
        // if (bgObject != null)
        // {
        //     bgObject.SetActive(false);
        // }
    }

    public async UniTask BackClick(GameObject o)
    {
        commandManager.Dispose();
        await HideAsync();
        await UI.Page.CloseCurrentPage();
    }

    public override void Dispose()
    {
        base.Dispose();

        // if (bgObject != null)
        // {
        //     Destroy(bgObject);
        // }
    }

    public override void OnHide()
    {
        base.OnHide();
        
        ZoomPlayer(false, 0.6f);
    }

    void ZoomPlayer(bool isIn,float duration)
    {
        MapSceneManager.Instance.CurrentScene.GetCameraController().GetVirtualCameraManager().ZoomPlayer(isIn,duration);
    }
}
