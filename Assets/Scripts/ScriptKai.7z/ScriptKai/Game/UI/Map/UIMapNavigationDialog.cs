﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.AI;

public class UIMapNavigationDialog : UIDialogBase
{
    [SerializeField] RectTransform arrowObject;
    [SerializeField] RectTransform container;

    private bool isTrigger = false;
    private bool mOn = false;

    private Vector3 mTarget;

    NavigateLine navigateLine;


    private float nextRefreshTime = 0f;
    NavMeshPath path;
    private int time = 5;
    void Update()
    {
        if (mOn && Time.realtimeSinceStartup >= nextRefreshTime)
        {
            SetNavigationTarget(mTarget);
            nextRefreshTime = Time.realtimeSinceStartup+time;
        }

        if (isTrigger && MapSceneManager.Instance.CurrentScene!=null &&
            Vector3.Distance(mTarget, MapSceneManager.Instance.CurrentScene.player.transform.position) < 2)
        {
            SignalBus.GlobalSignal.Dispatch(UIEventId.MapTriggerEnter);
            isTrigger = false;
        }
    }

    private bool isTutorial_;
    public void SetTutorial()
    {
        isTutorial_ = true;
        time = 5;
    }
    public void OnEndGoal(bool trigger)
    {
        isTrigger = trigger;
    }

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        var lineObject = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Map/Effect/naviLine");
        navigateLine = lineObject.GetComponent<NavigateLine>();
        navigateLine.SetActive(false);

        SignalBus.GlobalSignal.Subscribe<bool>(UIEventId.MapNaviState, OnSetNaviState).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe<Vector3>(UIEventId.MapNaviTarget, OnSetNaviTarget).AddTo(mSubscriptions);

        arrowObject.gameObject.SetActive(false);

        path = new NavMeshPath();
    }

    public override void Dispose()
    {
        base.Dispose();

        if (navigateLine != null)
        {
            Destroy(navigateLine.gameObject);
        }
    }
    private void OnSetNaviState(bool on)
    {
        mOn = on;
        // arrowObject.gameObject.SetActive(on);
        if(navigateLine !=null )
            navigateLine.SetActive(on);
    }
    

    private void OnSetNaviTarget(Vector3 worldPosition)
    {
        SetNavigationTarget(worldPosition);
    }


    public void SetNavigationTarget(Vector3 worldPosition)
    {
        mTarget = worldPosition;
        if (MapSceneManager.Instance.CurrentScene == null) return;
        if (isTutorial_)
        {
            navigateLine.SetPosition(MapSceneManager.Instance.CurrentScene.player.transform.position);
            navigateLine.MoveTo(mTarget);
        }
        else
        {
            NavMesh.CalculatePath(MapSceneManager.Instance.CurrentScene.player.transform.position, worldPosition,
                NavMesh.AllAreas, path);

            List<Vector3> posList = new List<Vector3>();
            posList.Add(MapSceneManager.Instance.CurrentScene.player.transform.position);
            posList.AddRange(path.corners);
            posList.Add(worldPosition);

            navigateLine.SetPoints(posList.ToArray());
        }

        // updatePosition();
    }


    // void LateUpdate()
    // {
    //     if (mOn)
    //     {
    //         updatePosition();
    //     }
    // }


    private void updatePosition()
    {
        Vector2 screenPos = MapSceneManager.Instance.CurrentScene.GetCameraController().GetCamera().WorldToScreenPoint(mTarget);
        var uiCamera = SceneBase.Current.UICamera;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(transform.parent.GetComponent<RectTransform>(), screenPos, uiCamera, out var t);
        if (RectTransformUtility.RectangleContainsScreenPoint(container, screenPos))
        {
            arrowObject.anchoredPosition = t;
        }
        else
        {
            t.x = Mathf.Clamp(t.x, -container.rect.width/2, container.rect.width/2);
            t.y = Mathf.Clamp(t.y, -container.rect.height/2, container.rect.height/2);
            arrowObject.anchoredPosition = t;
        }

        
    }
}
