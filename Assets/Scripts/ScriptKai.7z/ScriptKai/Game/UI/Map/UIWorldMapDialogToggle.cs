﻿
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;


public class UIWorldMapDialogToggle : MonoBehaviour
{
    [SerializeField] private Image areaMiniBG;
    [SerializeField] private UIText nameText;
    [SerializeField] private UIText nameText2;

    public async UniTask Init(string areaMiniBG, string areaDisplayName)
    {
        this.areaMiniBG.sprite=await ResourceManager.Instance.LoadSpriteAsync("Map", areaMiniBG);
        nameText.SetLabel(LocalizeManager.DATA_TYPE.LOCATION_NAME,areaDisplayName);
        nameText2.SetLabel(LocalizeManager.DATA_TYPE.LOCATION_NAME,areaDisplayName);
        gameObject.SetActive(true);
    }

}