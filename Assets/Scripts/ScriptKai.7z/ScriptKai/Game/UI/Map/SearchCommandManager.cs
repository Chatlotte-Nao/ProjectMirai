﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using Map;
using Pheonix.Core;
using Spine.Unity;

namespace MapUi
{
	/// <summary>
	/// 探索コマンド挙動管理処理
	/// </summary>
	public class SearchCommandManager : MonoBehaviour
	{
		/// <summary>
		/// [移動]コマンド名
		/// </summary>
		readonly string MOVE_COMMAND = "MOVE";

		/// <summary>
		/// [何もしない]コマンド名
		/// </summary>
		readonly string NOTHING_COMMAND = "NOTHING";

		/// <summary>
		/// [話す]コマンド名
		/// </summary>
		readonly string TALK_COMMAND = "TALK";

		/// <summary>
		/// コマンド結果格納クラス
		/// </summary>
		public class CommandResult
		{
			public AdvMaster Master { get; private set; }
			public string ScenarioId { get; private set; }

			public int cost { get; private set; }

			public string MoveStartRoomName { get; private set; } = string.Empty;

			public void SetMaster(AdvMaster master)
			{
				this.Master = master;
				this.ScenarioId = string.Empty;
			}
			public void SetScenarioId(string scenarioId, int cost)
			{
				this.Master = null;
				this.ScenarioId = scenarioId;
				this.cost = cost;
			}
			public void SetMove(string moveStartRoomName)
			{
				this.MoveStartRoomName = moveStartRoomName;
			}

			public bool IsHaveMaster()
			{
				return (Master != null);
			}
			public void Reset()
			{
				Master = null;
				ScenarioId = string.Empty;
				cost = 0;
				MoveStartRoomName = string.Empty;
			}
		}

		[SerializeField] GameObject buttonPrefab;
		[SerializeField] GameObject characterButtonPrefab;
		[SerializeField] Transform buttonParent;
		/*
		 * コマンドアイコン
		 * 0：アイコン無し　※コマンド無し
		 * 1：調査する
		 * 2：聞き耳を立てる
		 * 3：話しかける
		 * 4：何もしない
		 * 5：アイテム使う
		 */
		[SerializeField] List<Sprite> iconList;
		[SerializeField] List<Sprite> iconAfterList;

		[SerializeField] List<Sprite> characterIconList;
		[SerializeField] List<Sprite> characterIconAfterList;
		[SerializeField] List<Sprite> parentSprite;

		//TODO character 
		// [SerializeField] private GameObject characterObj;
		[SerializeField] private List<GameObject> buttoObjects;
		// [SerializeField] RawImage characterImage;
		
		List<GameObject> buttonList = new List<GameObject>();
		List<string> setCommandList = new List<string>();

		public CommandResult LastResult { get; private set; } = new CommandResult();

		List<List<Vector2>> buttonPositionList = new List<List<Vector2>>
		{
			new List<Vector2>{ new Vector2(0,15)},
			new List<Vector2>{ new Vector2(-66,0),		new Vector2(66,0)},
			new List<Vector2>{ new Vector2(-111,-10),		new Vector2(0,15),		new Vector2(111,-10)},
			new List<Vector2>{ new Vector2(-100,-28),	new Vector2(-67,77),	new Vector2(67,77),	new Vector2(100,-28)},
			new List<Vector2>{ new Vector2(-75,-75),	new Vector2(-100,8),	new Vector2(0,100),		new Vector2(-100,8),		new Vector2(75,-75)},
		};


		/// <summary>
		/// 今部屋コマンド選択を行っているかどうか
		/// </summary>
		/// <returns></returns>
		public bool IsNowPlay()
		{
			return (buttonParent.gameObject.activeSelf && gameObject.activeSelf);
		}

		public void SetSearchCommand()
		{
			LastResult.Reset();
			//部屋コマンド作成
			var masters = CheckAdvMaster.GetStartMasterList(MapSceneManager.Instance.CurrentScene.GetNowMapLabel())
				.Where(m => !string.IsNullOrEmpty(m.searchCommandId)).ToList();

			foreach (var button in buttonList)
			{
				Destroy(button);
			}
			buttonList.Clear();
			setCommandList.Clear();

			gameObject.SetActive(true);
			buttonParent.gameObject.SetActive(true);

			//今の状況で出る汎用コマンド
			//※2020/06/30 汎用コマンドは一旦無し（「何もしない」以外は全てマスターに入れる形）に変更
			var generalCommands = new List<string>();
			var inCommand = "SEARCH";
			var listenCommand = "LISTEN";
			var talkCommand = "TALK";
			switch (DataManager.Instance.Local.Scenarios.searchState)
			{
				//部屋
				case 1:
//					generalCommands.Add(inCommand);
//					generalCommands.Add(listenCommand);
					break;
				//キャラ
				case 2:
//					generalCommands.Add(talkCommand);
					break;
				//アイテム
				case 3:
//					generalCommands.Add(inCommand);
//					generalCommands.Add(listenCommand);
					break;
				default:
					Debug.LogWarning("コマンド設定時にPARAM_SEARCH_STATEが設定されていません！");
					break;
			}

			//汎用コマンド設定
			if (generalCommands.Contains(inCommand))
				SetGeneralCommand(masters, inCommand, 1, "testRoomIn");
			if (generalCommands.Contains(listenCommand))
				SetGeneralCommand(masters, listenCommand, 0, "testListen");
			if (generalCommands.Contains(talkCommand))
				SetGeneralCommand(masters, talkCommand, 1, "testRoomIn");

			var character = masters.Where(a=>a.searchCommandId.Equals(TALK_COMMAND)).ToArray();
			if (character.Length > 0)
			{
				AsyncManager.Instance.StartAsync(loadCharacterInfo(masters));
			}
			else
			{
				buttonParent.gameObject.SetActive(true);
				//残りのマスター項目のボタン作成
				foreach (var master in masters)
				{
					// characterObj.gameObject.SetActive(false);
					SetButton(master, null, 0, master.searchCommandId);
				}
			}

			//移動がある部屋の場合「移動」もコマンドに追加する
			var roomStartAdv = masters.Find(m => CheckAdvMaster.IsRoomStartAdv(m));
			if (roomStartAdv != null)
			{
				SetMoveCommand(masters, roomStartAdv.entryRoom);
			}

			//「何もしない」コマンド
			//SetButton(null, string.Empty, 0, NOTHING_COMMAND);

			List<Vector2> posList = null;
			//作成したボタン配置
			foreach (var list in buttonPositionList)
			{
				if (list.Count != buttonList.Count)
					continue;
				posList = list;
				break;
			}

		    buttonParent.gameObject.GetComponent<Image>().overrideSprite = buttonList.Count >= 3 ? parentSprite[1] : parentSprite[0];
            
			int setNum = 0;
			if (posList == null)
			{
				Debug.LogWarning("ボタンの配置設定がありません！　ボタン個数：" + buttonList.Count);
				//※本来ここには来ないはずだが、ボタン配置されないのもまずいので、縦に並べておく
				foreach (var button in buttonList)
				{
					button.transform.localPosition = new Vector2(0.0f, setNum * 100.0f);
					setNum++;
				}
			}
			else
			{

				foreach (var button in buttonList)
				{
					button.transform.localPosition = posList[setNum];
					setNum++;
				}
			}
		}

		void SetGeneralCommand(List<AdvMaster> masters, string generalCommand, int generalCost, string generalScenarioId)
		{
			if (!masters.Any(m => generalCommand.Equals(m.searchCommandId)))
			{
				SetButton(null, generalScenarioId, generalCost, generalCommand);
			}
			else
			{
				var master = masters.Find(m => generalCommand.Equals(m.searchCommandId));
				SetButton(master, null, 0, generalCommand);
				masters.Remove(master);
			}
		}

		void SetMoveCommand(List<AdvMaster> masters, string moveStartRoomName)
		{
			if (masters.Any(m => MOVE_COMMAND.Equals(m.searchCommandId)))
				return;
			if (!DataManager.Instance.Master.AdvMap.ContainsKey(moveStartRoomName))
				return;
			var roomMaster = DataManager.Instance.Master.AdvMap[moveStartRoomName];
			
			if (!DataManager.Instance.Master.MapSettingButton.ContainsKey(roomMaster.mapSettingButtonId))
				return;
			var buttonMaster = DataManager.Instance.Master.MapSettingButton[roomMaster.mapSettingButtonId];
			
			SetButton(null, null, 0, MOVE_COMMAND, moveStartRoomName);
		}

		void SetButton(AdvMaster master, string scenarioId, int cost, string searchCommandId, string moveStartRoomName = null)
		{
			var commandMaster = DataManager.Instance.Master.SearchCommand[searchCommandId];

			GameObject obj = Instantiate(buttonPrefab);
			obj.gameObject.SetActive(true);
			obj.transform.SetParent(buttonParent, false);

			var image = obj.GetComponent<Image>();
			var iconNo = (commandMaster == null) ? 0 : commandMaster.iconId;

			//選択済みコマンドの時はアイコンの色を変える
			var isSelected = false;
			//イベントが仕込まれている探索ボタンの選択済み判定
			if (master != null)
			{
				isSelected = ScenarioParameterUtil.IsParamValue("Remain_Read_" + master.routeName);
			}

			//アイコン設定
			if (searchCommandId.Equals(TALK_COMMAND) && master != null)
			{
				image.sprite = GetCharacterButtonSprite(master.miniCharacterId, isSelected);
				obj.GetComponent<RectTransform>().sizeDelta = new Vector2(75, 81);
			}
			else
			{
				var list = iconList;  // (isSelected) ? iconAfterList: iconList;
				image.sprite = (iconNo < list.Count) ? list[iconNo] : null;
				image.SetNativeSize();
			}
			
			//ボタン処理設定
			var button = obj.GetComponent<Button>();
			button.onClick.AddListener(() =>
			{
				PxSoundManager.Instance.PlaySe("feedbackSE_interface_close01");
				buttonParent.gameObject.SetActive(false);
				gameObject.SetActive(false);
				SignalBus.GlobalSignal.Dispatch<string>(UIEventId.ADVCommandExecute, searchCommandId);
			});

			//文章設定
			var text = obj.GetComponentInChildren<TextMeshProUGUI>();
			if (text != null && commandMaster != null)
			{
				text.color = (isSelected) ? Color.yellow : Color.white;
				text.text = LocalizeManager.Instance.GetCommonText(commandMaster.text);
			}
			buttonList.Add(obj);
		}

		Sprite GetCharacterButtonSprite(string miniCharaName, bool isSelected)
		{
			//ToDo:ミニキャラの持ち方をキャラIDに紐づけた形に変える
			int charaId = 0;
			if ("MiniCharaDestiny".Equals(miniCharaName))
				charaId = 1;
			if ("MiniCharaJupiter".Equals(miniCharaName))
				charaId = 2;
			if ("MiniCharaCarmen".Equals(miniCharaName))
				charaId = 3;
			if ("MiniCharaTwinclestar".Equals(miniCharaName))
				charaId = 4;
			if ("MiniCharaWalkure".Equals(miniCharaName))
				charaId = 5;
			if ("MiniCharaMoonlight".Equals(miniCharaName))
				charaId = 6;
			if ("MiniCharaFledermaus".Equals(miniCharaName))
				charaId = 7;
			if ("MiniCharaNutcracker".Equals(miniCharaName))
				charaId = 8;
			//ボレロ
			if ("MiniCharaBolero".Equals(miniCharaName))
				charaId = 9;
			//月光
			if ("MiniCharaMoonlight".Equals(miniCharaName))
				charaId = 10;
			//アリア
			if ("MiniCharaAria".Equals(miniCharaName))
				charaId = 11;
			//ダフクロ
			if ("MiniCharaDaphchlo".Equals(miniCharaName))
				charaId = 12;
			//ベルキス
			if ("MiniCharaBelkis".Equals(miniCharaName))
				charaId = 13;

			var list = characterIconList;//(isSelected) ? characterIconAfterList: characterIconList;
			var sprite = (charaId < list.Count) ? list[charaId] : null;
			return sprite;
		}
		// UIRTCamera mRTCamera = null;
		private GameObject bgObject = null;
		private async UniTask loadCharacterInfo(List<AdvMaster> masters)
		{
			buttonParent.gameObject.SetActive(false);
			// if (mRTCamera == null)
			// {
			// 	var rtc = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/RTCamera");
			// 	mRTCamera = rtc.GetComponent<UIRTCamera>();
			// }
			// characterObj.gameObject.SetActive(true);
			// characterImage.gameObject.SetActive(false);
			int index = 0;
			foreach (var buttoObject in buttoObjects)
			{
				buttoObject.gameObject.SetActive(false);
			}
			foreach (var master in masters)
			{
				SetCharacterButton(master, null, 0, master.searchCommandId,null,index);
				index++;
			}
			
		}

		void SetCharacterButton(AdvMaster master, string scenarioId, int cost, string searchCommandId, string moveStartRoomName = null,int index = 0)
		{
			var commandMaster = DataManager.Instance.Master.SearchCommand[searchCommandId];

			GameObject obj = buttoObjects[index];
			obj.gameObject.SetActive(true);
			
			//アイコン設定
			if (searchCommandId.Equals(TALK_COMMAND) && master != null)
			{
				AsyncManager.Instance.StartAsync(setUpCharacter(master.miniCharacterId));
			}
			//ボタン処理設定
			var button = obj.GetComponent<Button>();
			button.onClick.RemoveAllListeners();
			button.onClick.AddListener(() =>
			{
				PxSoundManager.Instance.PlaySe("feedbackSE_interface_close01");
				// characterObj.gameObject.SetActive(false);
				gameObject.SetActive(false);
				SignalBus.GlobalSignal.Dispatch<string>(UIEventId.ADVCommandExecute, searchCommandId);
			});

			//文章設定
			var text = obj.GetComponentInChildren<TextMeshProUGUI>();
			if (text != null && commandMaster != null)
			{
				text.text = LocalizeManager.Instance.GetCommonText(commandMaster.text);
			}
		}
		public async UniTask setUpCharacter(string characterId)
		{
			//bob Temp Return;
			return;
			var resourceMaster = DataManager.Instance.Master.CharacterResource.FirstOrDefault(a=>a.Value.miniCharacterId.Equals(characterId));
			var loadCharacter = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/chara/" + resourceMaster.Value.advModelId);
			var skeletonAnimation = loadCharacter.GetComponent<SkeletonAnimation>();
			skeletonAnimation.Initialize(false);
			skeletonAnimation.Update(0.0f);
			skeletonAnimation.LateUpdate();

			// mRTCamera.Setup(loadCharacter);
			// characterImage.texture = mRTCamera.GetRenderTexture();
			// characterImage.gameObject.SetActive(true); 
			
		}

		public void Dispose()
		{
			// characterObj.gameObject.SetActive(false);
			// if (mRTCamera != null)
			// {
			// 	mRTCamera.Dispose();
			// 	mRTCamera = null;
			// }
			if (bgObject != null)
			{
				GameObject.Destroy(bgObject.gameObject);
				bgObject = null;
			}
		}
	}
}
