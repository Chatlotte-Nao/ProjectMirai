﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIAdvShowWorldMap : UIDialogBase
{
    [SerializeField] private Image bg;
    [SerializeField] private UIWorldMapDialogButton roomButtonBase;
    [SerializeField] private RectTransform charaHead;
    [SerializeField] private Transform footFx;
    [SerializeField] private float footOffset;
    [SerializeField] private float footOffsetY;
    private string bgPath = "";
    Vector2 endPoint = default;
    Vector2 startPoint = default;

    private void Update()
    {
        //设置脚印方向
        if (startPoint!=default&&endPoint!=default)
        {
            var dir = (endPoint - startPoint).normalized;
            Vector3 cross=Vector3.Cross(dir, Vector2.right);
            var angle = Vector2.Angle(dir, Vector2.right);
            angle = cross.z > 0f ? -angle : angle;
            footFx.rotation=Quaternion.Euler(0f,0f,angle+footOffset);
            footFx.gameObject.transform.position= charaHead.gameObject.transform.position+new Vector3(0,footOffsetY,0);
        }
    }

    public async UniTask LoadBG(string bgPath)
    {
        this.bgPath = bgPath;
        bg.sprite =await ResourceManager.Instance.LoadSpriteAsync("Map", bgPath);
    }

    public async UniTask AdvShow_PlayerMove(string startPointName, string endPointName, float time)
    {
        var master = DataManager.Instance.Master.WolrdMap;
        foreach (var item in master.Values)
        {
            if (item.areaBG==bgPath)
            {
               var button= Instantiate(roomButtonBase,bg.transform).GetComponent<UIWorldMapDialogButton>();
               button.Init(item.label, item.displayName, item.postion,0,item.linkLineDir);
               if (item.label==startPointName)
               {
                   startPoint = button.GetComponent<RectTransform>().anchoredPosition;
               }
               if (item.label==endPointName)
               {
                   endPoint = button.GetComponent<RectTransform>().anchoredPosition;
               }
            }
        }
        
        charaHead.gameObject.SetActive(true);
        charaHead.anchoredPosition = startPoint; 
        var sequence = DOTween.Sequence();
        charaHead.localScale = Vector3.zero;
        charaHead.anchoredPosition += new Vector2(0, 90f);
        
        var t1 = DOTween.To(() => charaHead.localScale, x => charaHead.localScale = x,
            Vector3.one, 1.5f);
        t1.SetEase(Ease.OutElastic);
        
        var wait = DOTween.To(() => charaHead.localScale, x => charaHead.localScale = x,
            Vector3.one, 0.5f);
        
        var t2 = DOTween.To(() => charaHead.anchoredPosition, x => charaHead.anchoredPosition = x,
            endPoint + new Vector2(0, 90f), time/1000f);
        t2.SetEase(Ease.Linear);
        sequence.Append(t1);
        sequence.Append(wait);
        sequence.Append(t2);
    }
}