﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIMapHomePage : UIPageBase
{
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        //await MapSceneManager.Instance.ShowAsync("AdvMap005");
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
    }

    public override void Dispose()
    {

        base.Dispose();
    }
}
