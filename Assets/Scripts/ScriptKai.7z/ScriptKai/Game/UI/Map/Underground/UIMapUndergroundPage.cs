﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using ExploreBattleZone;

public class UIMapUndergroundPage : UIPageBase
{
    UIMapUndergroundMainWindow mMainWindow = null;
    UIMapUndergroundCharacterDialog _characterSelect = null;
    private UIUndergroundRewardDialog _undergroundReward = null;
    
    UIMapUndergroundOperationDialog mOperationDialog = null;
    UIPadController mPad = null;
    UIMapCommandDialog mCommandDialog = null;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        
        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIMapUndergroundMainWindow, CanvasType.App0) as UIMapUndergroundMainWindow;
        _characterSelect = await UI.Dialog.CreateAsync(UIPrefabId.UIMapUndergroundCharacterDialog, CanvasType.App1) as UIMapUndergroundCharacterDialog;
        // _undergroundReward = await UI.Dialog.CreateAsync(UIPrefabId.UIUndergroundRewardDialog, CanvasType.App2) as UIUndergroundRewardDialog;

        
        mOperationDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMapUndergroundOperationDialog, CanvasType.BG) as UIMapUndergroundOperationDialog;
        mPad = await UI.Dialog.CreateAsync(UIPrefabId.UIPadController, CanvasType.BG) as UIPadController;
        mCommandDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIMapCommandDialog, CanvasType.App0) as UIMapCommandDialog;
        // mNavigationWindow =  await UI.Dialog.CreateAsync(UIPrefabId.UIHomeNavigationWindow, CanvasType.App0) as UIHomeNavigationWindow;
        //
        // mNavigationWindow.OnNavigationGroup.GuardSubscribeAsync(OnNavigationGroup).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        SignalBus.GlobalSignal.Dispatch(UIEventId.UIHeaderHide);
        await base.ShowAsync(showType);

        await mMainWindow.ShowAsync(showType);
        await mOperationDialog.ShowAsync(showType);
        await mPad.ShowAsync(showType);
        // await mNavigationWindow.ShowAsync(showType);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);

        await mMainWindow.HideAsync(showType);
        await mOperationDialog.HideAsync();
        await mPad.HideAsync(showType);
        // await mNavigationWindow.HideAsync(showType);

    }
    private async UniTask OnNavigationGroup(bool isActive)
    {
        mMainWindow.gameObject.SetActive(!isActive);
        mPad.gameObject.SetActive(!isActive);
        mOperationDialog.gameObject.SetActive(!isActive);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
        if (mPad != null)
        {
            mPad.Dispose();
            mPad = null;
        }
        if (mCommandDialog != null)
        {
            mCommandDialog.Dispose();
            mCommandDialog = null;
        }
        if (mOperationDialog != null)
        {
            mOperationDialog.Dispose();
            mOperationDialog = null;
        }
        if (_characterSelect != null)
        {
            _characterSelect.Dispose();
            _characterSelect = null;
        }
        if (_undergroundReward != null)
        {
            _undergroundReward.Dispose();
            _undergroundReward = null;
        }
    }

    private void OnShowCommand()
    {
        AsyncManager.Instance.StartGuardAsync(mCommandDialog.ShowAsync());
    }

}
