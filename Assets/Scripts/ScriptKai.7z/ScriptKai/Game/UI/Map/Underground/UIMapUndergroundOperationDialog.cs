using System.Collections;
using System.Collections.Generic;
using System.Linq;
using ExploreBattleZone;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using FlowCanvas.Nodes;
using Map;

namespace ExploreBattleZone
{
    public class UIMapUndergroundOperationDialog : UIDialogBase
{
    [SerializeField] UIButton[] objectTriggerButton;
    [SerializeField] Transform baseGroup;

    private string btnInteractingNameIDBuffer = "";
    private MapSceneBase currentScene;

    private ExploreEventViewModel eventModel;
    private List<UpdateSignalBtnNode> interactiveObjList = new List<UpdateSignalBtnNode>();
    private bool ongoing = false;

    private List<IMapOperationTarget> triggerObjects = new List<IMapOperationTarget>();

    void Update()
    {
        CheckObjectButton();
#if UNITY_EDITOR
        if (Input.GetKeyDown(KeyCode.Space))
        {
            OnClickObjectTrigger(0);
        }
#endif
    }

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        currentScene = MapSceneManager.Instance.CurrentScene;
        for (int i = 0; i < baseGroup.childCount; i++)
        {
            objectTriggerButton[i] = baseGroup.GetChild(i).GetComponent<UIButton>();
        }
        for (int i = 0; i < objectTriggerButton.Length; i++)
        {
            var idx = i;
            objectTriggerButton[i].OnTouchUpInside.Subscribe(()=>{OnClickObjectTrigger(idx);}).AddTo(mSubscriptions);
        }
        AddListener();
    }

    private void AddListener()
    {
        SignalBus.GlobalSignal.AddListener<UpdateSignalBtnNode>(EventID.ShowTriggerButton, ShowTriggerButton);
        SignalBus.GlobalSignal.AddListener<UpdateSignalBtnNode>(EventID.HideTriggerButton, HideTriggerButton);
    }

    private void RemoveListener()
    {
        SignalBus.GlobalSignal.RemoveListener<UpdateSignalBtnNode>(EventID.ShowTriggerButton, ShowTriggerButton);
        SignalBus.GlobalSignal.RemoveListener<UpdateSignalBtnNode>(EventID.HideTriggerButton, HideTriggerButton);
    }

    private void ShowTriggerButton(UpdateSignalBtnNode node)
    {
        // btnInteractingNameIDBuffer = node.BtnInteractingNameID;
        if (!interactiveObjList.Contains(node))
        {
            interactiveObjList.Add(node);
        }
    }

    private void HideTriggerButton(UpdateSignalBtnNode node)
    {
        if (interactiveObjList.Contains(node))
        {
            interactiveObjList.Remove(node);
        }

    }

    private void CheckObjectButton()
    {
        int idx = 0;
        triggerObjects.Clear();
        var player = currentScene.player as UndergroundPlayer;

        if (player.isBlockInput)
        {
        }
        else if (player is not null && player.interactiveObjAction != null)
        {                    
            objectTriggerButton[idx].gameObject.SetActive(true);
            setupButton(objectTriggerButton[idx].gameObject, player.interactiveObjAction.btnNameID, 0);
            idx++;
        }
        else
        {
            foreach (var item in currentScene.staticObjects)
            {
                if (item.Value.CanSelect)
                {
                    triggerObjects.Add(item.Value);
                    if (idx < objectTriggerButton.Length)
                    {
                        objectTriggerButton[idx].gameObject.SetActive(true);
                        setupButton(objectTriggerButton[idx].gameObject, item.Value.getOperationText(), 0);
                    }

                    idx++;
                }
            }

            List<Map.AMapRuntimeObject> targetList = new List<Map.AMapRuntimeObject>();
            targetList.AddRange(currentScene.characters.Values);
            targetList.AddRange(currentScene.iconObjects.Values);
            targetList.AddRange(currentScene.enemys.Values);
            targetList.AddRange(currentScene.chests.Values);

            float minD = 0.95f;

            foreach (var t in targetList)
            {
                if (!t.gameObject.activeInHierarchy) continue;
                if (!t.getEnable()) continue;
                var d = Vector3.Distance(t.transform.position, currentScene.player.transform.position);
                if (d < minD)
                {
                    triggerObjects.Add(t);
                    if (idx < objectTriggerButton.Length)
                    {
                        objectTriggerButton[idx].gameObject.SetActive(true);
                        setupButton(objectTriggerButton[idx].gameObject, t.getOperationText(), 0);
                    }

                    idx++;
                }
            }
            foreach (var t in interactiveObjList)
            {
                if (idx < objectTriggerButton.Length)
                {
                    objectTriggerButton[idx].gameObject.SetActive(true);
                    setupButton(objectTriggerButton[idx].gameObject, t.BtnNameID, 0);
                }

                idx++;
            }
        }
        while (idx < objectTriggerButton.Length)
        {
            objectTriggerButton[idx++].gameObject.SetActive(false);
        }
    }

    //0:search 1:talk 2:battle
    private void setupButton(GameObject button, string text, int type)
    {
        var t = button.transform.Find("icon");
        var localizedText=LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.UNDERGROUND, text);
        foreach (Transform icon in t)
        {
            if (icon.name == type.ToString())
            {
                icon.gameObject.SetActive(true);
            }
            else
            {
                icon.gameObject.SetActive(false);
            }
        }
        button.GetComponentInChildren<UIText>().SetRawText(localizedText);
    }

    private void OnClickObjectTrigger(int idx)
    {
        var player = currentScene.player as UndergroundPlayer;
        if (player.interactiveObjAction !=null)
        {
            AsyncManager.Instance.StartGuardAsync(RunInteractiveObjAction);
        }
        else
        {
            if (idx >= triggerObjects.Count)
            {
                if (interactiveObjList.Count > idx - triggerObjects.Count)
                {
                    var signal = interactiveObjList[idx - triggerObjects.Count];
                    signal.Run();
                }
                return;
            }

            var obj = triggerObjects[idx];
            obj.DoOperation();
        }

    }

    private async UniTask RunInteractiveObjAction()
    {
        var player = currentScene.player as UndergroundPlayer;
        await player.interactiveObjAction.action.Invoke();
    }


    public override void Dispose()
    {
        RemoveListener();
        base.Dispose();
    }
}

}

