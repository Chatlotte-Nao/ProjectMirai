using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UIMapUndergroundMainWindow : UIDialogBase
{
    [SerializeField] UIButton backButton;
    [SerializeField] UIText placenameText;
    
    [SerializeField] Toggle skipBattleToggle;
    [SerializeField] UIButton characterButton;
    [SerializeField] UIButton navigationButton;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        placenameText.SetLabel(LocalizeManager.DATA_TYPE.LOCATION_NAME, DataManager.Instance.Master.Location[MapSceneManager.Instance.CurrentScene.GetNowMapLabel()].displayName);
        skipBattleToggle.onValueChanged.Subscribe(SkipBattle).AddTo(mSubscriptions);
        skipBattleToggle.isOn = DataManager.Instance.Local.BattleZone.skipBattle;
        // var master = DataManager.Instance.Master.BattleZone[DataManager.Instance.Local.BattleZone.currentBattleZoneId];
        //
        //
        // if (DataManager.Instance.Player.BattleZone.IsBattleZoneCleared(master.id))
        // {
        //     skipBattleToggle.gameObject.SetActive(true);
        //     skipBattleToggle.isOn = DataManager.Instance.Local.BattleZone.skipBattle;
        //     skipBattleToggle.onValueChanged.Subscribe(onSkipBattleToggle).AddTo(mSubscriptions);
        // }
        // else
        // {
        //     skipBattleToggle.gameObject.SetActive(false);
        // }
        
        navigationButton.OnTouchUpInside.SubscribeAsync(onClickNavigation).AddTo(mSubscriptions);
        characterButton.OnTouchUpInside.GuardSubscribeAsync(onClickCharacter).AddTo(mSubscriptions);

        backButton.OnTouchUpInside.Subscribe(OnClickBack).AddTo(mSubscriptions);
        SignalBus.GlobalSignal.Subscribe(UIEventId.MapSceneChanged, OnMapChanged).AddTo(mSubscriptions);
    }

    private void SkipBattle(bool arg0)
    {
        if (arg0)
        {
            var text=LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.UNDERGROUND, "Underground_Popup_SkipBattle");
            UI.Popup.ShowPopMessage(text);
        }
        DataManager.Instance.Local.BattleZone.skipBattle = arg0;
    }

    async UniTask onClickNavigation()
    {
        var dialog= await UI.Dialog.CreateAsync(UIPrefabId.UIHomeNavigationWindow, CanvasType.App1) as UIHomeNavigationWindow;
        await dialog.SetUpOutSide();
        await dialog.ShowAsync(UIPageShowType.Front);
        await dialog.OpenNavigationGroupOutSide();
    }
    
    private async UniTask onClickCharacter()
    {
        await UI.Popup.ShowPopupMessageAsync("功能正在研发中...");

        // await UI.Page.OpenPage<UIHomeCharacterMainPage>();
    }

    private async UniTask onClickEquipment()
    {
        await UI.Page.OpenPage<UIHomeEquipmentListPage>();
    }
    
    private void OnMapChanged()
    {
        placenameText.SetLabel(LocalizeManager.DATA_TYPE.LOCATION_NAME, DataManager.Instance.Master.Location[MapSceneManager.Instance.CurrentScene.GetNowMapLabel()].displayName);
    }

    private void onSkipBattleToggle(bool val)
    {
        DataManager.Instance.Local.BattleZone.skipBattle = val;
    }
    
    private void OnClickBack()
    {
        UI.Popup.ShowConfirm(string.Empty, LocalizeManager.Instance.GetCommonText("COMMONMENU_BACK_BUTTON_CONFIRM_MESSAGE"), CanvasType.App2, (r)=>
        {
            if (r == UIPopupDialog.Result.OK)
            {
                AsyncManager.Instance.StartGuardAsync(async()=>
                {            
                    var logic = MapSceneManager.Instance.CurrentLogic as UndergroundMapLogic;
                    logic.SetPause(true);
                    HomeSceneParam p = new HomeSceneParam();
                    p.enterType = HomeSceneParam.EnterType.FromUnderground;
                    MapSceneManager.Instance.Clear();
                    await GameSceneManager.Instance.ChangeSceneAsync<HomeScene>("HomeScene", p);
                });
            }
        });
    }
    
    
}
