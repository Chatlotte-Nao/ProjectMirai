﻿using Base.Util;

using Game.Ui;
using Game.Util;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace MapUi
{
	/// <summary>
	/// ムータがヒントを話している吹き出しダイアログ制御
	/// </summary>
	public class HintDialog : MonoBehaviour
	{
		[SerializeField] Text text;
		[SerializeField] Transform moveTransform;

		const float OPEN_LEST_TIME_MIN = 4.0f;
		const float OPEN_LEST_TIME_DIV = 0.2f;
		const float MOVE_SPD = 4.0f;

		bool isOpen = false;
		bool isAbleOverwrite = false;
		Coroutine moveToken = null;
		float lestTime = 0.0f;

		private void Awake()
		{
			moveTransform.localScale = Vector3.zero;
		}
		private void OnDestroy()
		{
			if (moveToken != null)
			{
				StopCoroutine(moveToken);
				moveToken = null;
			}
		}

		private void Update()
		{
			if (lestTime <= 0.0f)
				return;

			lestTime -= Time.deltaTime;
			if (lestTime > 0.0f)
				return;

			isOpen = false;
			if (moveToken != null)
			{
				StopCoroutine(moveToken);
				moveToken = null;
			}
			moveToken = StartCoroutine(MoveFunction());
		}

		public void Open(string setText, bool isAbleOverwrite)
		{
			gameObject.SetActive(true);
			text.text = setText;

			isOpen = true;
			this.isAbleOverwrite = isAbleOverwrite;
			if (moveToken != null)
			{
				StopCoroutine(moveToken);
				moveToken = null;
			}
			//吹き出しはいったん閉じる
			moveTransform.localScale = Vector3.zero;
			moveToken = StartCoroutine(MoveFunction());
			lestTime = setText.Length * OPEN_LEST_TIME_DIV;
			if (lestTime < OPEN_LEST_TIME_MIN)
				lestTime = OPEN_LEST_TIME_MIN;
		}

		public bool IsOpen()
		{
			return gameObject.activeSelf;
		}
		/// <summary>
		/// 新しくヒントダイアログが開ける状態か
		/// </summary>
		public bool IsAbleOpenHintDialog()
		{
			if (IsOpen() && !isAbleOverwrite)
			{
				return false;
			}
			return true;
		}

		IEnumerator MoveFunction()
		{
			float moveSign = (isOpen) ? 1 : -1;
			while (true)
			{
				var nowSize = moveTransform.localScale;
				nowSize.z = 1.0f;
				if ((isOpen && nowSize.x >= 1) ||
					(!isOpen && nowSize.x <= 0))
				{
					break;
				}
				var plusNum = MOVE_SPD * Time.deltaTime * moveSign;
				nowSize.x += plusNum;
				nowSize.y = nowSize.x;
				moveTransform.localScale = nowSize;
				yield return null;
			}
			moveTransform.localScale = (moveSign > 0) ? Vector3.one : Vector3.zero;
			if (moveSign < 0)
				gameObject.SetActive(false);
			moveToken = null;
		}
	}
}