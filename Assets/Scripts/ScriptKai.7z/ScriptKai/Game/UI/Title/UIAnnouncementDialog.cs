﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;
using Base.Util;
using Takasho;

public class UIAnnouncementDialog : UIDialogBase
{
    //[SerializeField] UIButton[] noticeCategoryBtn;
    [SerializeField] NoticeItem noticeItemPrefab;

    [SerializeField] RectTransform noticeItemRect;

    //[SerializeField] ScrollRect typeScrollRect;
    [SerializeField] RectTransform content;
    [SerializeField] VerticalLayoutGroup contentLayout;
    [SerializeField] RectTransform mainContent;
    [SerializeField] RectTransform announceListRect;
    [SerializeField] UIText titleText;
    [SerializeField] UIText dateText;

    [SerializeField] ScrollRect announcementScroll;

    // [SerializeField] Image activityImage;
    [SerializeField] UIText mainText;
    [SerializeField] Sprite selectedBg;
    [SerializeField] Sprite normalBg;
    [SerializeField] UIButton upButton;

    [SerializeField] UIButton downButton;

    //[SerializeField] ScrollRect mainScroll;
    //[SerializeField] List<AnnouncementInfo> activityList = new List<AnnouncementInfo>();
    // [SerializeField] List<AnnouncementInfo> gameList = new List<AnnouncementInfo>();
    [SerializeField] List<NoticeItem> contentList = new List<NoticeItem>();
    public List<AnnouncementInfo> announcementInfos = new List<AnnouncementInfo>();

    NoticeItem selectItem;
    private float srcollvalue;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        upButton.OnTouchDown.Subscribe(upButtonOnclick).AddTo(mSubscriptions);
        downButton.OnTouchDown.Subscribe(downButtonOnclick).AddTo(mSubscriptions);
    }

    void upButtonOnclick()
    {
        var targetPos = announcementScroll.verticalNormalizedPosition + srcollvalue;
        announcementScroll.verticalNormalizedPosition = targetPos > 1 ? 1 : targetPos;

    }

    void downButtonOnclick()
    {
        var targetPos = announcementScroll.verticalNormalizedPosition - srcollvalue;
        announcementScroll.verticalNormalizedPosition = targetPos < 0 ? 0 : targetPos;
    }

    public async UniTask Init( List<AnnouncementInfo> infos)
    {
        announcementInfos = infos;
        titleText.SetRawText("");
        dateText.SetRawText("");
        mainText.SetRawText("");
        //noticeCategoryBtn[0].OnTouchDown.Subscribe(() => { OnChangeCate(0); }).AddTo(mSubscriptions);
        //noticeCategoryBtn[1].OnTouchDown.Subscribe(() => { OnChangeCate(1); }).AddTo(mSubscriptions);
       

        //if (announcementInfos == null)
        //    return;
        for (int i = 0; i < announcementInfos.Count -1; i++)
        {
            for (int j = 0; j < announcementInfos.Count -1- i; j++)
            {
                if (announcementInfos[j + 1].priority < announcementInfos[j].priority)
                {
                    var temp = announcementInfos[j];
                    announcementInfos[j] = announcementInfos[j + 1];
                    announcementInfos[j + 1] = temp;
                }
            }
        }
        for (int i = 0; i < announcementInfos.Count -1; i++)
        {
            if (announcementInfos[i + 1].priority == announcementInfos[i].priority)
            {
                if (announcementInfos[i + 1].created_at > announcementInfos[i].created_at)
                {
                    var temp = announcementInfos[i];
                    announcementInfos[i] = announcementInfos[i + 1];
                    announcementInfos[i + 1] = temp;
                }
            }
        }
        if(announcementInfos.Count* (noticeItemRect.sizeDelta.y + contentLayout.spacing) > announceListRect.sizeDelta.y)
        {
            upButton.gameObject.SetActive(true);
            downButton.gameObject.SetActive(true);
        }
        srcollvalue = 1.0f / (announcementInfos.Count - 1);
        int index = 0;
        foreach (var notice in announcementInfos)
        {

            //if (!(notice.flag == "true"))
            //{
            //    index++;
            //    continue;
            //}
            var go = GameObject.Instantiate(noticeItemPrefab, content.gameObject.transform);
            go.NoticeIndex = index;
            go.Setup(notice.overview_bar_text, (Tags)notice.overview_bar_tag);
            go.Button.OnTouchDown.Subscribe(() => { OnClickAnnouncement(go.NoticeIndex); }).AddTo(mSubscriptions);
            go.gameObject.SetActive(true);
            content.sizeDelta += new Vector2(0, noticeItemRect.sizeDelta.y + contentLayout.spacing);
            index++;
            contentList.Add(go);
            //if((Tags)notice.overview_bar_tag == Tags.Activity)
            //{
            //    activityList.Add(notice);
            //}
            //else
            //{
            //    gameList.Add(notice);
            //}

        }
        //默认显示第一条信息
        if (contentList.Count != 0)
        {
            
            OnClickAnnouncement(0);

        }

        //foreach (var item in activityList)
        //{
        //    var go = GameObject.Instantiate(noticeItemPrefab, content.transform);
        //    go.NoticeId = item.announcement_id;
        //    go.Setup(item.overview_bar_text, (Tags)item.overview_bar_tag);
        //    go.Button.OnTouchDown.Subscribe(() => { OnLongTouchItem(go.NoticeId); }).AddTo(mSubscriptions);
        //    contentList.Add(go);
        //}

    }

    public override void OnShow()
    {
        base.OnShow();
       
    }


    public void OnClickAnnouncement(int index)
    {
        // mainContent.GetComponent<ContentSizeFitter>().enabled = false;

        
         
        //mainScroll.verticalScrollbar.value = 1;
        foreach (var item in contentList)
        {

            if(item.NoticeIndex == index)
            {
                if (selectItem == item) return;
                titleText.SetRawText(announcementInfos[index].title);
                System.DateTime startTime = System.TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1));//获取时间戳
                System.DateTime dt = startTime.AddSeconds(announcementInfos[index].created_at);
                //System.DateTimeOffset.FromFileTime(announcementInfos[index].created_at).Date
                string t = dt.ToString("yyyy/MM/dd");//转化为日期时间
                
                dateText.SetRawText(t);
               
                mainText.SetRawText(announcementInfos[index].text.ToString());
                //mainContent.GetComponent<RectTransform>().sizeDelta += new Vector2(0, mainText.gameObject.GetComponent<RectTransform>().sizeDelta.y);
                foreach(var fitter in this.GetComponentsInChildren<ContentSizeFitter>())
                {
                    fitter.SetLayoutVertical();
                }
                //LayoutRebuilder.ForceRebuildLayoutImmediate(mainText.gameObject.GetComponent<RectTransform>());
                //LayoutRebuilder.ForceRebuildLayoutImmediate(mainContent.GetComponent<RectTransform>());
                SelectItem(item);

            }
        }

    }

    void SelectItem(NoticeItem item)
    {
        mainContent.anchoredPosition = new Vector2(0, 0);
        if (selectItem != null)
        {
            selectItem.Bg.overrideSprite = normalBg;
            selectItem.text.color = new Color(48.0f/255, 48.0f/ 255, 42.0f/ 255);


            selectItem = null;
        }
        selectItem = item;
        if (item != null)
        {
            item.Bg.overrideSprite = selectedBg;
            item.text.color = new Color(252.0f/255, 244.0f/255, 182.0f/255);
          
           
        }
            
    }

    //public void OnChangeCate(int index)
    //{
    //    switch (index)
    //    {
    //        case 0:
    //            {
    //                ClearList();
    //                foreach (var item in activityList)
    //                {
    //                    var go = GameObject.Instantiate(noticeItemPrefab, content.transform);
    //                    go.NoticeId = item.announcement_id;
    //                    go.Setup(item.overview_bar_text, (Tags)item.overview_bar_tag);
    //                    go.Button.OnTouchDown.Subscribe(() => { OnLongTouchItem(go.NoticeId); }).AddTo(mSubscriptions);
    //                }
    //                break;
    //            }
    //        case 1:
    //            {
    //                ClearList();
    //                foreach (var item in gameList)
    //                {
    //                    var go = GameObject.Instantiate(noticeItemPrefab, content.transform);
    //                    go.NoticeId = item.announcement_id;
    //                    go.Setup(item.overview_bar_text, (Tags)item.overview_bar_tag);
    //                    go.Button.OnTouchDown.Subscribe(() => { OnLongTouchItem(go.NoticeId); }).AddTo(mSubscriptions);
    //                }
    //                break;
    //            }
    //    }
    //}


    public void ClearList()
    {
        for (int i = 0; i < contentList.Count; i++)
        {
            Destroy(contentList[i].gameObject);

        }
        contentList.Clear();
    }

    public void ResetItems()
    {
        titleText.SetRawText("");
        dateText.SetRawText("");
        mainText.SetRawText("");
        mainContent.anchoredPosition = new Vector2(0, 0);
        SelectItem(null);
        ClearList();
    }
}
