﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using IFix;
using UnityEngine.SceneManagement;

public class UITitlePage : UIPageBase
{
    UIAnnouncementDialog mAnnouncementDialog = null;


    AssetDownloadInfo mDownloadInfo = null;
    UIAssetDownloadDialog mDownloadWindow = null;
    UITitleLoginDialog mLoginDialog = null;
    UITitleMain mTitleMain = null;


    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        mTitleMain = await UI.Dialog.CreateAsync(UIPrefabId.UITitleMainWindow, CanvasType.BG) as UITitleMain;

        mDownloadWindow =
            await UI.Dialog.CreateAsync(UIPrefabId.UIAssetDownloadDialog, CanvasType.BG) as UIAssetDownloadDialog;
        mAnnouncementDialog =
            await UI.Dialog.CreateAsync(UIPrefabId.UIAnnouncementDialog, CanvasType.App2) as UIAnnouncementDialog;
        mLoginDialog =
            await UI.Dialog.CreateAsync(UIPrefabId.UITitleLoginDialog, CanvasType.App1) as UITitleLoginDialog;

        mTitleMain.OnOpenningFinish.GuardSubscribeAsync(OnOpenningFinish).AddTo(mSubscriptions);
        mTitleMain.OnProcessAnnouncementBtn.GuardSubscribeAsync(OnOpenAnnouncement).AddTo(mSubscriptions);
        mTitleMain.OnAccountClick.GuardSubscribeAsync(OnAccountClickAsync).AddTo(mSubscriptions);
        mTitleMain.OnGameStart.GuardSubscribeAsync(StartGame).AddTo(mSubscriptions);
        mLoginDialog.OnLoginOK.GuardSubscribeAsync(AfterSignInAsync).AddTo(mSubscriptions);
        mDownloadWindow.onDownloadComplete.GuardSubscribeAsync(onDownloadOK).AddTo(mSubscriptions);

        Score.Render.RenderDef._debugScene = Score.Render.RenderDef.DebugScene.GAME_MAIN;

    }

   

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await mTitleMain.ShowAsync();
        ClientEvent clientEvent = ClientEventUtil.ClientLandInto();
        LCXHandler.Instance.ReportEvent(clientEvent.event_id, clientEvent.payload);
    }

    public override void Dispose()
    {
        if (mTitleMain != null)
        {
            mTitleMain.Dispose();
            mTitleMain = null;
        }

        if (mLoginDialog != null)
        {
            mLoginDialog.Dispose();
            mLoginDialog = null;
        }

        if (mDownloadWindow != null)
        {
            mDownloadWindow.Dispose();
            mDownloadWindow = null;
        }

        if (mAnnouncementDialog != null)
        {
            mAnnouncementDialog.Dispose();
            mAnnouncementDialog = null;
        }

        mDownloadInfo = null;


        base.Dispose();
    }

    async UniTask OnOpenningFinish()
    {
        //lcx登录
        try
        {
            bool loginResult = await LoginService.LoginAsync();
            ClientEvent clientEvent = new ClientEvent();


            if (!loginResult)
            {
                clientEvent = ClientEventUtil.ClientSDKLogin(2);
                LCXHandler.Instance.ReportEvent(clientEvent.event_id, clientEvent.payload);
                return;
            }

            clientEvent = ClientEventUtil.ClientSDKLogin(1);
            LCXHandler.Instance.ReportEvent(clientEvent.event_id, clientEvent.payload);
        }
        catch (System.Exception e)
        {
            Debug.LogError(e);
            return;
        }

        mTitleMain.LoginTrue();
        var announcementInfos = await OutgameService.GetAnnouncementList();
        if (announcementInfos.Count != 0)
        {
            await mAnnouncementDialog.Init(announcementInfos);
        }
        //await AfterSignInAsync();
        await mLoginDialog.onClickLogin();
    }

    async UniTask AfterSignInAsync()
    {
        //await mLoginDialog.HideAsync();

#if !UNITY_EDITOR
        ClientEvent clientEvent;
        clientEvent = ClientEventUtil.ClientUpdateAfterSDK(201, 0, 1);
        LCXHandler.Instance.ReportEvent( clientEvent.event_id, clientEvent.payload);
        mDownloadInfo = await AssetDownloadService.GetAssetInfo();
        clientEvent = ClientEventUtil.ClientUpdateAfterSDK(202, 0, 1);
        LCXHandler.Instance.ReportEvent( clientEvent.event_id, clientEvent.payload);
        if (mDownloadInfo.needUpdateMasterData || mDownloadInfo.needUpdateAssets)
        {
            mDownloadWindow.Setup(mDownloadInfo);
            UI.Loading.Hide();
            await mDownloadWindow.ShowAsync();
            return;
        }
#endif
        
        await onDownloadOK();
    }

    private async UniTask onDownloadOK()
    {
        if (mAnnouncementDialog.announcementInfos.Count != 0)
        {
           await mAnnouncementDialog.ShowAsync();
        }
        ClientEvent clientEvent = ClientEventUtil.ClientUpdateAfterSDK(208, 0, 1);
        LCXHandler.Instance.ReportEvent(clientEvent.event_id, clientEvent.payload);
        // UI.Loading.Show();
        if (mDownloadInfo != null)
        {
            await DataManager.Instance.Master.ReadFromMemory(mDownloadInfo.masterDataVersion, mDownloadInfo.pwd);
            await PxSoundManager.Instance.LoadCueSheets();
        }
        //await mLoginDialog.onClickLogin();
        
        // UI.Loading.Hide();
        await mLoginDialog.Setup();
        await mLoginDialog.ShowAsync();
        mTitleMain.SetTapable();
    }

    async UniTask OnOpenAnnouncement()
    {
        var announcementInfos = await OutgameService.GetAnnouncementList();
        mAnnouncementDialog.ResetItems();
        if (announcementInfos.Count != 0)
        {
            await mAnnouncementDialog.Init(announcementInfos);
        }
        mAnnouncementDialog.Show();
    }

    private async UniTask OnAccountClickAsync(GameObject o)
    {
        await LCXHandler.Instance.ShowUserCenter();
    }

    private async UniTask StartGame()
    {
        HotUpdater.Instance.SetupPatch();
        
        
        if (!mLoginDialog.GetAggreToggleAvtive())
        {
            await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SYSTEM, "PopupMessage_Agreement"));
            //mTitleMain.UndateTapable();
            return;
        }
        PxSoundManager.Instance.PlaySe("feedbackSE_game_open01");
        
        await LoginService.GetPlayerData();
        mTitleMain.StarGameTapable();

        SecureUtil.SetRoleInfo(TakashoHandler.Instance.Account, "", "", "");

        TutorialManager.Instance.Setup();
        await mLoginDialog.HideAsync();
        await mTitleMain.ShowStart();
        // await SceneManager.LoadSceneAsync("BattleBootScene");
//        await UI.ScreenEffect.Fade(1);
        await ResourceManager.Instance.PreloadSprite();
#if QUICK_BATTLE
            TutorialManager.Instance.SetOpeningStep(9);
            //TutorialManager.Instance.FinishCurrentTutorialStep();
            //TutorialManager.Instance.TryStartOpeningTutorial();
            HomeSceneParam param = new HomeSceneParam();
            param.enterType = HomeSceneParam.EnterType.FromTitle;
            GameSceneManager.Instance.ChangeScene<BattleBootScene>("BattleBootScene", param);
           
#else
        if (TutorialManager.Instance.TryStartOpeningTutorial())
        {
            
        }
        else
        {
//            await UI.ScreenEffect.Fade(1);
            await MissionService.RequestMissionData();
            HomeSceneParam param = new HomeSceneParam();
            param.enterType = HomeSceneParam.EnterType.FromTitle;
            GameSceneManager.Instance.ChangeScene<HomeScene>("HomeScene", param);
            LCXHandler.Instance.PutInGameUserInfo(ClientEventUtil.ClientGameUserInfo("StartPlay"));
        }
#endif
      
    }

   
}