﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIDownloadPage : UIPageBase
{
    AssetDownloadInfo mDownloadInfo = null;
    UIAssetDownloadDialog mDownloadWindow = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);
        mDownloadWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIAssetDownloadDialog, CanvasType.BG) as UIAssetDownloadDialog;
        mDownloadWindow.onDownloadComplete.GuardSubscribeAsync(onDownloadOK).AddTo(mSubscriptions);
        mDownloadInfo = param as AssetDownloadInfo;
        mDownloadWindow.Setup(mDownloadInfo);
    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
        await mDownloadWindow.ShowAsync(showType);
    }

    public override async UniTask HideAsync(UIPageShowType showType)
    {
        await base.HideAsync(showType);
        await mDownloadWindow.HideAsync(showType);
    }


    private async UniTask onDownloadOK()
    {
        Log.Debug("download complete!");
        
        
    

        
        await DataManager.Instance.Master.ReadFromMemory(mDownloadInfo.masterDataVersion, mDownloadInfo.pwd);
        await LoginService.GetPlayerData();

        TutorialManager.Instance.Setup();

        if (TutorialManager.Instance.TryStartOpeningTutorial())
        {
            
        }
        else
        {
            HomeSceneParam param = new HomeSceneParam();
            param.enterType = HomeSceneParam.EnterType.FromTitle;
            GameSceneManager.Instance.ChangeScene<HomeScene>("HomeScene", param);
        }
    }


    public override void Dispose()
    {
        base.Dispose();
        if (mDownloadWindow != null)
        {
            mDownloadWindow.Dispose();
            mDownloadWindow = null;
        }
    }
}
