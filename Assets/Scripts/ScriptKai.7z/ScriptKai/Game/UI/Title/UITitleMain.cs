﻿using Base.Ui;
using Base.Util;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using UnityEngine.Events;
using Spine.Unity;

public class UITitleMain : UIDialogBase
{
    [SerializeField] GameObject openning;
    [SerializeField] UIButton clickObject;
    [SerializeField] CanvasGroup uiGroup;
    [SerializeField] UIButton announcementBtn;
    [SerializeField] UIButton ageBtn;
    [SerializeField] UIText versionText;
    [SerializeField] private UIButton accountBtn;
    public UnityEvent OnProcessAnnouncementBtn = new UnityEvent();
    public UnityEvent OnOpenningFinish;
    public UnityEvent OnGameStart;
    float bottom;
    TitleSequence mOpenning = null;
    bool skipped = false;

    public ClickEvent OnAccountClick => accountBtn.onClick;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        clickObject.onClick.Subscribe(OnClickStart).AddTo(mSubscriptions);
        announcementBtn.onClick.Subscribe(OnClickAnnouncement).AddTo(mSubscriptions);
        mOpenning = Instantiate(openning).GetComponent<TitleSequence>();
        mOpenning.tapStart.SetActive(false);
        mOpenning.uiCanvas.worldCamera = SceneBase.Current.UICamera;

        ageBtn.OnTouchUpInside.GuardSubscribeAsync(onClickAge).AddTo(mSubscriptions);

        uiGroup.gameObject.SetActive(false);
        versionText.SetRawText(Application.version);
    }

    public override void OnShow()
    {
        base.OnShow();
        skipped = false;
        StartCoroutine(StartAnimationRoutine());
    }


    public override void Dispose()
    {
        base.Dispose();
        Destroy(mOpenning.gameObject);
        mOpenning = null;
        StopAllCoroutines();
    }

    IEnumerator StartAnimationRoutine()
    {
        clickObject.gameObject.SetActive(false);
        yield return new WaitForSeconds(2f);
        mOpenning.beginAS.volume = DataManager.Instance.Local.Config.bgmVolume;
        if (mOpenning.beginAS.volume > 0f)
        {
            mOpenning.beginAS.Play();
        }

        clickObject.gameObject.SetActive(true);
        yield return new WaitForSeconds(10.77f);
        //yield return new WaitForSeconds(3.0f);
        OnFinishFadeInAnimation();
    }

    void OnFinishFadeInAnimation()
    {
        var skeletonAnimation = mOpenning.skeletonAnimation;
        if (!mOpenning.bgAnimator.GetCurrentAnimatorStateInfo(0).IsName("v0004_loop"))
        {
            mOpenning.bgAnimator.SetBool("Start", true);
            skeletonAnimation.state.ClearTracks();
            skeletonAnimation.state.SetAnimation(0, "wait_motion", true);
        }
         NetWorkReachable();
        
    }
    private void NetWorkReachable()
    {
        if (Application.internetReachability == NetworkReachability.NotReachable)
        {
            UI.Popup.ShowPopup(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ERROR, "ERROR_TITLE"),
                LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ERROR, "NETWORK_ERROR"),
                CanvasType.System, async (r) => { });
        }
        else
        {
           
            OnOpenningFinish.Invoke();
        }

    }

    public void LoginTrue()
    {
        skipped = true;
        uiGroup.gameObject.SetActive(true);
        clickObject.gameObject.SetActive(false);
    }

    public async UniTask ShowStart()
    {
        mOpenning.tapStart.SetActive(false);
        mOpenning.bgAnimator.SetBool("Start", true);
        mOpenning.beginAS.DOFade(0f, 3.9f);
        await UniTask.Delay(3900);
    }


    public void OnClickStart(GameObject o)
    {
        StopAllCoroutines();
        if (skipped)
        {
            // clickObject.gameObject.SetActive(false);
            // uiGroup.gameObject.SetActive(false);
            OnGameStart.Invoke();
            return;
        }
        else
        {
            OnFinishFadeInAnimation();
        }
    }

    public void OnClickAnnouncement(GameObject o)
    {
        OnProcessAnnouncementBtn.Invoke();
    }

    public void StarGameTapable()
    {
        clickObject.gameObject.SetActive(false);
        uiGroup.gameObject.SetActive(false);
    }

    public void UndateTapable()
    {
        uiGroup.gameObject.SetActive(true);
        clickObject.gameObject.SetActive(true);
    }

    public void SetTapable()
    {
        mOpenning.tapStart.SetActive(true);
        clickObject.gameObject.SetActive(true);
    }

    private async UniTask onClickAge()
    {
        var popup = await UI.Dialog.CreateAsync(UIPrefabId.UICommonInfomationDialog,
            CanvasType.System) as UIPopupDialog;
        popup.Setup(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SYSTEM, "AgeInfo_Title"),
            LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SYSTEM, "AgeInfo_Content"));
        await popup.ShowAsync();
    }
}