﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Spine.Unity;

public class TitleSequence : MonoBehaviour
{
    public Animator bgAnimator;
    public Canvas uiCanvas;
    public GameObject tapStart;
    public SkeletonAnimation skeletonAnimation;
    public AudioSource beginAS;
}
