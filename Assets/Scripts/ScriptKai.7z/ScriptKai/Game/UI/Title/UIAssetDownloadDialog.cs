﻿using System.Collections;
using System.Collections.Generic;
using Map;
using UnityEngine;
using Pheonix.Core;
using Spine.Unity;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;
using System.IO;

public class UIAssetDownloadDialog : UIDialogBase
{
    [SerializeField] UIText progressText;
    [SerializeField] Slider progressSlider;
    [SerializeField] private SkeletonGraphic jupiterSkeleton;

    public UnityEvent onDownloadComplete = new UnityEvent();

    private AssetDownloadInfo mDownloadInfo = null;


    public void Setup(AssetDownloadInfo info)
    {
        mDownloadInfo = info;
    }

    public override void OnShow()
    {
        base.OnShow();
        //AsyncManager.Instance.StartAsync(LoadCharacterData);
        AsyncManager.Instance.StartAsync(downloadProcess);
    }


    private async UniTask downloadProcess()
    {
        if (mDownloadInfo.needUpdateMasterData)
        {
            await AssetDownloadService.DownloadMasterData(mDownloadInfo.masterDataVersion, mDownloadInfo.masterDataPath, (p)=>
            {
                progressText.SetFormat(LocalizeManager.DATA_TYPE.SYSTEM, "Download_Format_MasterData", p*100);
                progressSlider.value = p;
            });
        }

        if (mDownloadInfo.needUpdateAssets)
        {
            await HotUpdater.Instance.ParseServerManifest(mDownloadInfo.assetListPath);
            await HotUpdater.Instance.UpdateAll((downloaded, total)=>
            {
                float p = (float)downloaded/total;
                progressText.SetFormat(LocalizeManager.DATA_TYPE.SYSTEM, "Download_Format_Asset", p*100, downloaded/1024, total/1024);
                progressSlider.value = p;
            });

            File.WriteAllText(AssetDownloadService.AssetVersionFile, mDownloadInfo.assetsBundleVersion);
            DataManager.Instance.Local.UserInfo.assetDataVersion = mDownloadInfo.assetsBundleVersion;
        }
        
        
     
        
        

        Hide();
        onDownloadComplete.Invoke();
    }

    private async UniTask LoadCharacterData()
    {
        var co = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Map/MiniCharacter/"+"MiniCharaCarmen");
        
        co.transform.SetParent(jupiterSkeleton.transform);
        jupiterSkeleton.skeletonDataAsset =
            co.transform.GetChild(1).GetComponent<SkeletonAnimation>().skeletonDataAsset;
        co.gameObject.SetActive(false);
        jupiterSkeleton.UpdateMesh();
        jupiterSkeleton.Update();
        jupiterSkeleton.startingAnimation = "walk_01";
        jupiterSkeleton.UpdateMesh();
        jupiterSkeleton.enabled = true;
        jupiterSkeleton.gameObject.SetActive(true);
        jupiterSkeleton.Update();
    }


    public override void Dispose()
    {
        base.Dispose();
        mDownloadInfo = null;
    }
}
