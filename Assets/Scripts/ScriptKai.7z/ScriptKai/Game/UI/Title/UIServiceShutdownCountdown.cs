﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using DG.Tweening;
using UnityEngine.UI;
using TMPro;
using UnityEditor;
using System;

public class UIServiceShutdownCountdown : UIDialogBase
{
    [SerializeField] UIText text;
    private List<string> tempstr = new List<string>(){ "秒","分","时","天"};
    int tempI = 0;
    int jinZhi = 0;
    public void SetTime(long time)
    {
        gameObject.SetActive(true);
        var str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON,"ServiceShutdownCountdown" );
        
        DOTween.To(() => (int)time, timeRemaining => {
            string s = "";
            tempI = 0;
            jinZhi = 0;
            while (timeRemaining > 0)
            {
                switch (tempI)
                {
                    case 0:
                        jinZhi = 60;
                        break;
                    case 1:
                        jinZhi = 60;
                        break;
                    case 2:
                        jinZhi = 24;
                        break;
                    case 3:
                        jinZhi = 365;
                        break;
                    default:
                        break;
                }
                s = timeRemaining % jinZhi + tempstr[tempI] + s;
                timeRemaining /= jinZhi;
                tempI++;
                if (tempI >= tempstr.Count) break;
            }
            //s = "停服倒计时  " + s;
            text.SetRawText($"{str}{s}");
        }, 0, time).SetEase(Ease.Linear).OnUpdate(() => {  }).OnStart(()=> { }).OnComplete(()=> { Hide(); }).SetUpdate(true);
    }
}
