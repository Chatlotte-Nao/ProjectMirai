﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.UI;

public class UITitleLoginDialog : UIDialogBase
{
    public UnityEvent OnLoginOK;

    [SerializeField] TMPLinkText linkText;
    [SerializeField] Toggle agreeToggle;
    [SerializeField] UIButton loginBtn;
    [SerializeField] UIText serverNameText;
    [SerializeField] UIButton changeServerBtn;

    private List<ServerInfo> mServerInfoList = null;
    private int mSelectServerIdx = -1;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        linkText.OnClickLink.GuardSubscribeAsync(onClickLink).AddTo(mSubscriptions);

        loginBtn.OnTouchUpInside.GuardSubscribeAsync(onClickLogin).AddTo(mSubscriptions);
    }
    
    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
    }

    public async UniTask Setup()
    {
        mServerInfoList = await OutgameService.GetServerList();

        // #if BUILD_DEBUG
        // serverNameText.SetRawText(TakashoHandler.Instance.serverUrl);
        serverNameText.SetRawText(mServerInfoList[0].serverName);
        DataManager.Instance.Local.UserInfo.currentServer = mServerInfoList[0];
       
        return;
        // #endif

        // if (mServerInfoList.Count > 0)
        // {
        //     onSelectServer(0);
        // }
        
    }

    private void onSelectServer(int idx)
    {
        mSelectServerIdx = idx;
        serverNameText.SetRawText(mServerInfoList[idx].serverName);
    }

    private async UniTask onClickLink(string str)
    {
        // var popup = await UI.Dialog.CreateAsync(UIPrefabId.UICommonInfomationDialog, CanvasType.System) as UIPopupDialog;
        if (str == "rule")
        {
            await LCXHandler.Instance.ShowUserAgreement();
            // popup.Setup(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SYSTEM, "UserRule_Title"), LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SYSTEM, "UserRule_Content"));
            // await popup.ShowAsync();
        }
        else if (str == "privacy")
        {
            await LCXHandler.Instance.ShowPrivacyAgreement();
            // popup.Setup(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SYSTEM, "Privacy_Title"), LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SYSTEM, "Privacy_Content"));
            // await popup.ShowAsync();
        }
        else
        {
            Log.Error("undefined link!! val=" + str);
            // popup.Dispose();
        }
    }

    public bool GetAggreToggleAvtive()
    {
        return agreeToggle.isOn;
    }

    public async UniTask onClickLogin()
    {
        // if (!agreeToggle.isOn)
        // {
        //     await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SYSTEM, "PopupMessage_Agreement"));
        //     return;
        // }

        //如果在debug界面输入过服务器地址且未进行选服操作，则以debug地址为准
        if (mSelectServerIdx >= 0)
        {
            TakashoHandler.Instance.serverUrl = mServerInfoList[mSelectServerIdx].serverUrl;
            DataManager.Instance.Local.UserInfo.currentServer = mServerInfoList[mSelectServerIdx];
        }

        try
        {

            await LoginService.SignInTakasho(false);
            ClientEvent clientEvent = ClientEventUtil.ClientRoleLogin(1, "");
            LCXHandler.Instance.ReportEvent(clientEvent.event_id, clientEvent.payload);
        }
        catch (System.Exception e)
        {
            Debug.LogError(e);

            ClientEvent clientEvent = ClientEventUtil.ClientRoleLogin(2, e.ToString());
            LCXHandler.Instance.ReportEvent(clientEvent.event_id, clientEvent.payload);
            return;
        }

        OnLoginOK.Invoke();

    }
}
