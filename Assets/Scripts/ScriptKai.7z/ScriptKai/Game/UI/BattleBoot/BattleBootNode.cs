﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class BattleBootNode : MonoBehaviour
{
	class IntUnityEvent : UnityEvent<int> { }
	[System.NonSerialized]
	public UnityEvent<int> OnClick = new IntUnityEvent();

	[SerializeField] Text text;
	[SerializeField] Button button;

	int id;

	private void Awake()
	{
		button.onClick.AddListener(() =>
		{
			OnClick.Invoke(id);
		});
	}

	public void SetData(int id, string name)
	{
		this.id = id;
		text.text = name;
	}
}
