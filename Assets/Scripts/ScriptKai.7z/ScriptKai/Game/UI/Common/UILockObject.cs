﻿ using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UILockObject : UIBehaviourComponent
{
    [SerializeField] UIButton button;
    [SerializeField] int lockId;
    [SerializeField] GameObject isSceneObject;
    [SerializeField] private bool isActive;
    void Awake()
    {
	    if (lockId==0 && isSceneObject == null)
	    {
		    button.SetLock(false);
		    return;
	    }

	    bool isLock = false;


	    if (lockId != 0)
	    {
		    isLock = DataManager.Instance.Master.FunctionUnlock[lockId].requirePlayerLevel >
		             DataManager.Instance.Player.Player.GetLevel();
		    var stageId = DataManager.Instance.Master.FunctionUnlock[lockId].requireStageId;
		    if (!isLock && stageId > 0 && !StoryUtil.IsClear(stageId))
		    {
			    isLock = true;
		    }
	    }

	    if (!isLock && isSceneObject )
	    {
		    isLock = MapSceneManager.Instance.CurrentType != MapSceneManager.SceneType.Home;
		    isSceneObject.SetActive(!isLock);
	    }

	    if (isActive && isLock)
	    {
		    button.gameObject.SetActive(false);
	    }
	
	    button.SetLock(isLock);
	    button.OnTouchUpInsideLock.SubscribeAsync(OnClickLockButton).AddTo(mSubscriptions);
    }

    private async UniTask OnClickLockButton()
    {
	    if (gameObject.name.Equals("StoryButton")&&GameSceneManager.Instance.currentSceneName.Equals("AdvScene"))
	    {
		    
		    var msg = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "PopupHint_AlreadyInTargetScene");
		    
		    await UI.Popup.ShowNavigationPopupMessageAsync(msg);
		    return;
	    }
        if (lockId!=0&&DataManager.Instance.Master.FunctionUnlock[lockId].requirePlayerLevel > DataManager.Instance.Player.Player.GetLevel())
		{
			var msg = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Level_Format"), DataManager.Instance.Master.FunctionUnlock[lockId].requirePlayerLevel);
			UI.Popup.ShowPopMessage(msg);
			return;
		}
        if (isSceneObject)
        {
	        if (MapSceneManager.Instance.CurrentType != MapSceneManager.SceneType.Home)
	        {
		        var msg = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "PopupHint_UnableBeforeExit");
		        await UI.Popup.ShowNavigationPopupMessageAsync(msg);
		        return;
	        }
        }
        var stageId = DataManager.Instance.Master.FunctionUnlock[lockId].requireStageId;
        if (stageId > 0 && !StoryUtil.IsClear(stageId))
        {
            var chapterName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SCENARIO_TITLE, $"{stageId}_name");
            int chapterNum = DataManager.Instance.Master.Chapter[stageId].chapter;
            var msg = string.Format(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "UILock_Stage_Format"), chapterNum, chapterName);
			UI.Popup.ShowPopMessage(msg);
			return;
        }
    }
}
