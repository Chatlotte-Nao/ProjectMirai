﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class SelectableItem : BaseItem
{
    public bool IsSelected { get; private set; }

    [SerializeField] GameObject checkGroup;


    public override void Setup(long itemId, string text)
    {
        base.Setup(itemId, text);
        Select(false);
    }

    public override async UniTask SetupAsync(long itemId, string text)
    {
        await base.SetupAsync(itemId, text);
        Select(false);
    }


    public void SetUpLongClick()
    {
        this.OnLongClick.SubscribeAsync(LongClickAsync);

    }

    public async UniTask LongClickAsync(GameObject o)
    {
        ShowItemInfoPopup(ShowDetailType.ShowSimple);
    }

    public void Select(bool value)
    {
        checkGroup.SetActive(value);
        IsSelected = value;
    }

}
