using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;

public class UITinyGameResultCell : MonoBehaviour
{
   [SerializeField] private Image icon;
   [SerializeField] private UIText addText;
   [SerializeField] private UIText itemName;
   public async UniTask SetUpAsync(long id,string text)
   {
      addText.SetRawText($"+{text}");
     icon.sprite = await  ResourceManager.Instance.LoadSpriteAsync("ItemIcon", id.ToString());
     itemName.SetLabel(LocalizeManager.DATA_TYPE.ITEM,$"{id}_name");
   }
}
