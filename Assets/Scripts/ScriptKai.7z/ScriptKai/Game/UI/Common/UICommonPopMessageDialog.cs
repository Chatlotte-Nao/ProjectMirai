﻿using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine;
using DG.Tweening;

public class UICommonPopMessageDialog : UIDialogBase
{
    [SerializeField]
    UIText titleText;

    //private bool _isUpdate = false;

    private List<string> tempstr = new List<string>() { "秒", "分", "时", "天" };
    int tempI = 0;
    int jinZhi = 0;

    public async void Setup(string message)
    {
        titleText.SetRawText(message);
        await UniTask.Delay(1000);
        Dispose();
    }

    public async void Setup(string message,long time)
    {
        SetTime(message, time);
        await UniTask.Delay(1000);
        Dispose();
    }

    public void SetTime(string message, long time)
    {
        gameObject.SetActive(true);
        var str = message;

        DOTween.To(() => (int)time, timeRemaining => {
            string s = "";
            tempI = 0;
            jinZhi = 0;
            while (timeRemaining > 0)
            {
                switch (tempI)
                {
                    case 0:
                        jinZhi = 60;
                        break;
                    case 1:
                        jinZhi = 60;
                        break;
                    case 2:
                        jinZhi = 24;
                        break;
                    case 3:
                        jinZhi = 365;
                        break;
                    default:
                        break;
                }
                s = timeRemaining % jinZhi + tempstr[tempI] + s;
                timeRemaining /= jinZhi;
                tempI++;
                if (tempI >= tempstr.Count) break;
            }
            titleText.SetRawText($"{str}{s}");
        }, 0, time).SetEase(Ease.Linear).OnUpdate(() => { }).OnStart(() => { }).OnComplete(() => { Hide(); }).SetUpdate(true);
    }

}
