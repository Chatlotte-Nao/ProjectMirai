﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIMiniScene : MonoBehaviour
{
    [SerializeField] UIMiniSceneSlot[] slots;

    public UIIntEvent OnClickEmptySlot = new UIIntEvent();
    public UIIntEvent OnClickCharacter = new UIIntEvent();

    void Start()
    {
        for (int i = 0; i < slots.Length; i++)
        {
            var slot = slots[i];
            var idx = i;
            slot.OnClickCharacter.AddListener((o)=>{OnClickCharacter.Invoke(idx);});
            slot.OnClickEmptySlot.AddListener((o)=>{OnClickEmptySlot.Invoke(idx);});
        }
    }


    public void Setup(UIMiniSceneViewModel model, bool isEditable = false)
    {
        for (int i = 0; i < slots.Length; i++)
        {
            if (!model.characters.ContainsKey(i))
            {
                slots[i].SetupEmpty(isEditable);
            }
            else
            {
                var c = model.characters[i];
                slots[i].Setup(c.id, c.dir, c.action);
            }
        }
    }

    public UIMiniSceneSlot GetSlot(int i)
    {
        return slots[i];
    }
}

public class UIMiniSceneViewModel
{
    public class UIMiniSceneCharacterModel
    {
        public long id;
        public int dir;
        public int action;
    }

    public Dictionary<int, UIMiniSceneCharacterModel> characters = null;
}
