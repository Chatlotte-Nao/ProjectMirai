﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class BaseResource : MonoBehaviour
{
    [SerializeField] protected Image iconImage = null;
    [SerializeField] protected UIText numText = null;

    private bool isNeed = false;
    public long ItemId {get; private set;}


    public virtual void Setup(long itemId, string text)
    {
        AsyncManager.Instance.StartAsync(SetupAsync(itemId, text));
    }

    public virtual async UniTask SetupAsync(long itemId, string text)
    {
        ItemId = itemId;
        numText.SetRawText(text);

        iconImage.sprite = await ResourceManager.Instance.LoadSpriteAsync($"ItemIconS", itemId.ToString());
        
    }

    public virtual void SetupNeed(long itemId, long needNum)
    {
        long cur = DataManager.Instance.Player.Wallet.GetCount(DataManager.Instance.Master.ContentToTakashoResource[itemId].takashoName);
        if ( cur >= needNum)
        {
            isNeed = true;
            AsyncManager.Instance.StartAsync(SetupAsync(itemId, string.Format(LocalizeManager.Instance.GetCommonText("Common_ResourceNeedNum_Format"), needNum)));
        }
        else
        {
            isNeed = false;
            AsyncManager.Instance.StartAsync(SetupAsync(itemId, string.Format(LocalizeManager.Instance.GetCommonText("Common_ResourceNeedNum_Format_NotEnough"), needNum)));
        }
    }

    public virtual async UniTask SetupNeedAsync(long itemId, long needNum)
    {
        long cur = DataManager.Instance.Player.Wallet.GetCount(DataManager.Instance.Master.ContentToTakashoResource[itemId].takashoName);
        isNeed = cur >= needNum;
        if ( cur >= needNum)
        {
            await SetupAsync(itemId, string.Format(LocalizeManager.Instance.GetCommonText("Common_ResourceNeedNum_Format"), needNum));
        }
        else
        {
            await SetupAsync(itemId, string.Format(LocalizeManager.Instance.GetCommonText("Common_ResourceNeedNum_Format_NotEnough"), needNum));
        }
    }
    
    public virtual void SetupMoneyNeed(long needNum)
    {
        SetupNeed(106000001, needNum);
    }

    public bool IsNeed()
    {
        return isNeed;
    }
}
