using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;

public class UIStaminaTimeDialog : UIDialogBase
{
    [SerializeField] private UIText[] stamainaTimeTexts;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        StaminaRecoveryCycle = DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.StaminaRecoveryCycle]
            .data;
        await ShowAsync();
    }
    
    private bool isCountdown = false;
    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        isCountdown = true;
        timeIndex = DataManager.Instance.Player.Player.GetNextCountdown();
        time = 1;
    }
    private int StaminaRecoveryCycle;
    void Update()
    {
        if (isCountdown)
        {
            time += Time.fixedDeltaTime;
            if (time > 1)
            {
                stamainaTimeTexts[0].SetRawText(GlobalTime.Now.ToString("HH:mm:ss"));
                timeIndex--;
                time = 0;
                UpdateStaminaTime();
                if (timeIndex <= 0)
                {
                    timeIndex =  DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.StaminaRecoveryCycle].data;
                }
            }
        }
    }
    private float time = 0;
    private long timeIndex;
    private void UpdateStaminaTime()
    {
        if (DataManager.Instance.Player.Player.GetNextStaminaUpdateTime() <= 0)
        {
            stamainaTimeTexts[1].SetRawText("00:00:00");
            stamainaTimeTexts[2].SetRawText("00:00:00");
        }
        else
        {
            stamainaTimeTexts[1].SetRawText($"{timeIndex/3600:d2}:{timeIndex/60:d2}:{timeIndex%60:d2}");
            var allTime = timeIndex + (DataManager.Instance.Player.Player.GetAllSurplusStaimina()-1) * StaminaRecoveryCycle;
            stamainaTimeTexts[2].SetRawText(FormatTime(allTime));
        }
    }

    public string FormatTime(long totalSeconds)
    {
        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds - hours * 3600) / 60;
        long seconds = totalSeconds - hours * 3600 - minutes * 60;
        return $"{hours:d2}:{minutes:d2}:{seconds:d2}";
    }
    public override void OnHide()
    {
        base.OnHide();
        Dispose();
    }
}
