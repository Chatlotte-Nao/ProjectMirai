﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Cysharp.Threading.Tasks.Triggers;

public class UICommonItemGetDialog : UIDialogBase
{
    [SerializeField] BaseItem itemPrefab;
    [SerializeField] RectTransform itemTransformParent;
    [SerializeField] RectTransform itemMaxTransformParent;
    [SerializeField] private UITexture titleTexture;
    [SerializeField] private UIText titleText;
    private RectTransform transformParent;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        if(titleTexture!=null)
            await titleTexture.LoadAsync("Font", "ty_font_hdwz_01", true);
    }

    public void SetTitleText(string title)
    {
        if(titleText != null)
            titleText.SetRawText(title);
    }

    public async UniTask Setup(Dictionary<long, int> content)
    {
        List<string> contents = new List<string>();
        // SetTransform(content.Count);
        foreach (var item in content)
        {
            // var itemId = item.Key;
            // var itemNum = item.Value;
            // var newItemObj = GameObject.Instantiate(itemPrefab.gameObject);
            // newItemObj.transform.parent = transformParent;
            // newItemObj.transform.localScale = Vector3.one;
            // newItemObj.transform.localRotation = Quaternion.identity;
            // newItemObj.transform.localPosition = Vector3.zero;
            // newItemObj.SetActive(true);
            //
            // var sel = newItemObj.GetComponent<BaseItem>();
            // await sel.SetupAsync(itemId, itemNum.ToString());
            contents.Add($"{item.Key}:{item.Value}");
        }

        await Setup(contents);
    }


    void SetTransform(int count)
    {
        itemTransformParent.gameObject.SetActive(false);
        itemMaxTransformParent.gameObject.SetActive(false);
        transformParent = itemTransformParent;
        if (count > 6)
            transformParent = itemMaxTransformParent;
        transformParent.gameObject.SetActive(true);
    }

    public async UniTask Setup(List<string> content)
    {
        SetTransform(content.Count);
        CommonUtil.SortDictionary(content);
        foreach (var item in content)
        {
            var s = item.Split(':');
            long itemId = 0;
            string itemNum = string.Empty;
            if (s.Length > 1)
            {
                itemId = long.Parse(s[0]);
                itemNum = s[1];
            }
            else
            {
                itemId =  long.Parse(item);
            }

            var newItemObj = GameObject.Instantiate(itemPrefab.gameObject);
            newItemObj.transform.parent = transformParent;
            newItemObj.transform.localScale = Vector3.one;
            newItemObj.transform.localRotation = Quaternion.identity;
            newItemObj.transform.localPosition = Vector3.zero;
            newItemObj.SetActive(true);

            var sel = newItemObj.GetComponent<BaseItem>();
            await sel.SetupAsync(itemId, itemNum);

        }
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        if (DataManager.Instance.Player.Equipment.firstEquipmentIds.Count > 0)
        {
            await showFirstEquipment();
        }
    }

    private async UniTask showFirstEquipment()
    {
       
        this.gameObject.transform.localScale = Vector3.zero;
        var pop = await UI.Popup.ShowEquipmentFullScreenAsync(DataManager.Instance.Player.Equipment.firstEquipmentIds);
        pop.Close.SubscribeAsync(async (_) =>
        {
            this.gameObject.transform.localScale = Vector3.one;
        }).AddTo(mSubscriptions);
    }

    public override void OnHide()
    {
        base.OnHide();
        Dispose();
    }
}
