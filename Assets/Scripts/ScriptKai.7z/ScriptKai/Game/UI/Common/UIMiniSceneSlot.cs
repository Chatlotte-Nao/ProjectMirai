﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Spine.Unity;
using Cysharp.Threading.Tasks;

public class UIMiniSceneSlot : MonoBehaviour
{
    [SerializeField] UIButton emptySlotButton;
    [SerializeField] UIMiniCharacterHolder characterHolder;

    public ClickEvent OnClickEmptySlot => emptySlotButton.onClick;
    public ClickEvent OnClickCharacter => characterHolder.OnClick;

    public UIMiniCharacterHolder CharacterHolder => characterHolder;


    public void Setup(long id, int dir, int action)
    {
        characterHolder.Setup(id, dir, action);
        emptySlotButton.gameObject.SetActive(false);
    }


    public void SetupEmpty(bool showSlot)
    {
        characterHolder.SetEmpty();
        emptySlotButton.gameObject.SetActive(showSlot);
    }
}
