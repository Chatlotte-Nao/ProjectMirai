﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Pheonix.Core;
using TMPro;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIEquipmentPanel : MonoBehaviour
{
    [SerializeField] BaseEquipment equipment;
    [SerializeField] UIText nameText;
    //[SerializeField] UIText skillnameText;
    //[SerializeField] UIText skilldescText;
    [SerializeField] UIButton equipBtn;
    [SerializeField] UIButton unequipBtn;
    [SerializeField] UIButton enhanceBtn;
    [SerializeField] UIButton changeBtn;
    [SerializeField] TabToggle lockToggle;
    //[SerializeField] UIText[] attributeText;
    [SerializeField] private UIText leftAttributeText;
    [SerializeField] private UIText rightAttributeText;
    //[SerializeField] Image jobImage;
    [SerializeField] Transform InfoGroup;
    
    [SerializeField] private BaseAttributeUp prefab; 
    [SerializeField] private RectTransform attributeTransform;
    private List<BaseAttributeUp> attributeList = new List<BaseAttributeUp>();
    public UnityEvent OnClickEquip => equipBtn.OnTouchUpInside;
    public UnityEvent OnClickUnEquip => unequipBtn.OnTouchUpInside;
    public UnityEvent OnClickEnhance => enhanceBtn.OnTouchUpInside;
    public UnityEvent OnClickChange => changeBtn.OnTouchUpInside;

    void Start()
    {
        lockToggle.onValueChanged.GuardSubscribeAsync(OnLockValueChange);
    }

    public void ChangeBtnSetAvtive(bool isAvtive)
    {
        changeBtn.gameObject.SetActive(isAvtive);
    }
    
    public void UnequipBtnSetAvtive(bool isAvtive)
    {
        unequipBtn.gameObject.SetActive(isAvtive);
    }

    public void Setup(EquipmentViewModel model)
    {
        equipment.Setup(model);

        foreach (var attribute in attributeList)
        {
            attribute.gameObject.SetActive(false);
        }
        int index = 1;
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            var value = model.attributeDict[eAtt];
            if (value > 0 )
            {
                if (index < attributeList.Count)
                {
                    attributeList[index].SetupText(eAtt,eAtt.GetAttributePercent(value));
                    attributeList[index].gameObject.SetActive(true);
                }
                else
                {
                    var attribute = Instantiate(prefab, this.attributeTransform, false);
                    attribute.SetupText(eAtt,eAtt.GetAttributePercent(value));
                    attribute.gameObject.SetActive(true);
                    attributeList.Add(attribute);
                }
                index++;
            }
        }
       

        nameText.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT_NAME, $"{model.id}");
        // skillnameText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{equipMaster.skillId}_name");
        // skilldescText.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{equipMaster.skillId}_desc");

        lockToggle.isOn = model.locked;
        lockToggle.RefreshGroup();  
        // var master = DataManager.Instance.Master.Equipment[model.id];
        // if (jobImage != null)
        // {
        //     var jobMaster = DataManager.Instance.Master.Job[master.equipableJobs[0]];
        //     jobImage.sprite = ResourceManager.Instance.LoadSpriteSmall("Job", jobMaster.IconPath);
        // }

    }

    private async UniTask OnLockValueChange(bool v)
    {
        await EquipmentService.SetEquipmentLock(equipment.Model.uniqueId, v);

        equipment.Model.locked = v;
    }
}
