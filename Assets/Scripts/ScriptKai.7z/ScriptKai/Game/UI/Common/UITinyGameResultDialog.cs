using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;

public class UITinyGameResultDialog : UIDialogBase
{
    [SerializeField] private GameObject expObject;
    [SerializeField] private GameObject exploreObject;
    [SerializeField] private RankIcon _rankIcon;
    [SerializeField] private UIText addExpText;
    [SerializeField] private UIText addExploreCoinText;
    [SerializeField] private UIText exploreLimitText;

    [SerializeField] private UITinyGameResultCell cell;
    [SerializeField] private RectTransform cellTransform;
    
    [SerializeField] private UIButton closebtn;

    private List<UITinyGameResultCell> cells = new List<UITinyGameResultCell>();
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        closebtn.onClick.Subscribe((_) =>
        {
            callback_?.Invoke();
            this.Dispose();
        });
    }

    private Action callback_;
    public async UniTask SetUpAsync(int masterId, bool isFirst, bool isWin,Action callback)
    {
        callback_ = callback;
        var master = DataManager.Instance.Master.PuzzleExplore[masterId];
        Dictionary<long, int> rewards = new Dictionary<long, int>();
        if (isFirst)
        {
            expObject.SetActive(true);
            addReward(rewards, master.firstRewards);
            addExpText.SetRawText($"+{rewards[113000001]}");
            long remainExp = DataManager.Instance.Player.Player.GetRemainExp();
            int lv = DataManager.Instance.Player.Player.GetLevel();
            var fill = 0f;
            if (DataManager.Instance.Master.PlayerLevel.ContainsKey(lv + 1))
            {
                fill = (float)remainExp / DataManager.Instance.Master.PlayerLevel[lv + 1].exp;
            }
            _rankIcon.Set(lv, fill);
        }
        else
        {
            expObject.gameObject.SetActive(false);
        }

        addReward(rewards, isWin ? master.winRewards : master.loseRewards);
        var exploreCoinLimit = DataManager.Instance.Player.Player.GetData().ExploreCoinLimit;
        var exploreCoinReceived = DataManager.Instance.Player.Player.GetData().ExploreCoinReceived;
        var oldCoin = DataManager.Instance.Player.Player.GetOldExploreCoin();
        exploreLimitText.SetRawText($"<color=#fbf5ea>{exploreCoinReceived}</color>/{exploreCoinLimit}");
        long allexplore = 0;
        if (rewards.ContainsKey(121000001))
        {
            allexplore += rewards[121000001];
            var num = exploreCoinLimit - oldCoin;
            if (allexplore >= num)
            {
                allexplore = num;
            }
        }
        if (rewards.ContainsKey(121000002))
            allexplore += rewards[121000002];
        addExploreCoinText.SetRawText($"+{allexplore}");
        //exploreObject.SetActive(allexplore>0);

        foreach (var cell in cells)
        {
            cell.gameObject.SetActive(false);
        }
        int index = 0;
        foreach (var reward in rewards)
        {
            if(reward.Key == 121000001 || reward.Key == 121000002 || reward.Key == 113000001) continue;
            if (index < cells.Count)
            {
                await cells[index].SetUpAsync(reward.Key,reward.Value.ToString());
                cells[index].gameObject.SetActive(true);
            }
            else
            {
                var button = Instantiate(cell, this.cellTransform, false);
                await button.SetUpAsync(reward.Key,reward.Value.ToString());
                button.gameObject.SetActive(true);
                cells.Add(button);
            }
            index++;
        }
    }
    
    private void addReward(Dictionary<long, int> result, List<string> rewards)
    {
        foreach (var item in rewards)
        {
            var s = item.Split(':');
            var itemId = long.Parse(s[0]);
            var itemNum = int.Parse(s[1]);
            if (result.ContainsKey(itemId))
            {
                result[itemId] += itemNum;
            }
            else
            {
                result.Add(itemId, itemNum);
            }
            
        }
    }

}
