﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;

public class BaseCharacter : MonoBehaviour
{
    public UnityEvent OnClick => uiButton.OnTouchUpInside;
    public ClickEvent OnLongClick => uiButton.onLongClick;

    public enum IconType
    {
        Base,
        Teabreak
    }

    public long CharacterId {get; private set;}

    [SerializeField] UIButton uiButton;
    [SerializeField] UITexture icon;
    [SerializeField] IconType iconType = IconType.Base;
    [SerializeField] private Image borderImage;

    public void SetBoder(Sprite sprite)
    {
        borderImage.sprite = sprite;
    }

    public virtual void Setup(long id)
    {
        icon.Load(GetIconFolder(), GetIconPath(id));
        CharacterId = id;
    }

    public virtual async UniTask SetupAsync(long id)
    {
        await icon.LoadAsync(GetIconFolder(), GetIconPath(id));
        CharacterId = id;
    }

    public virtual void Setup(CharacterViewModel model)
    {
        icon.Load(GetIconFolder(), GetIconPath(model.id));
        CharacterId = model.id;
    }

    protected string GetIconFolder()
    {
        switch (iconType)
        {
            case IconType.Base:
                return "CommonRoundIcon";
            case IconType.Teabreak:
                return "CommonRoundIcon";
        }

        return null;
    }

    protected string GetIconPath(long battleCharacterMasterId)
    {
        switch (iconType)
        {
            case IconType.Base:
                return DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[battleCharacterMasterId].characterResourceId].userIconId;
            case IconType.Teabreak:
                return DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[battleCharacterMasterId].characterResourceId].userIconId;
        }

        return null;
    }
}


public class UICharacterViewModel
{
    public long Id;
    public int Level;
}