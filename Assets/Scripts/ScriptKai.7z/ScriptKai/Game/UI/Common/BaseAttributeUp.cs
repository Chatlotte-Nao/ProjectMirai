﻿using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;

public class BaseAttributeUp : MonoBehaviour
{
    [SerializeField] private UIText attributeName;
    [SerializeField] private UIText oldAttribute;
    [SerializeField] private UIText newAttribute;
    [SerializeField] private Image attributeImage;
    [SerializeField] private GameObject arrowGameObject;
    [SerializeField] private UIText oldAttribute2;
    [SerializeField] private UIText attributeName2;

    [SerializeField] private GameObject changeObj;
    [SerializeField] private GameObject oneObj;

    public void LoadAttributeData(CharacterAttribute type, string oldValue, string newValue)
    {
        oldAttribute.SetRawText(oldValue);
        newAttribute.SetRawText(newValue);

        changeObj.gameObject.SetActive(true);
        oneObj.gameObject.SetActive(false);
        newAttribute.gameObject.SetActive(true);
        arrowGameObject.gameObject.SetActive(true);

        attributeName.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, $"Attribute_{type}");
        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(type); });
        //attributeImage.sprite = ResourceManager.Instance.LoadSpriteSmall("AttributeIcon", $"attribute_icon_{type}");
    }

    public void SetupText(CharacterAttribute type, string text)
    {
        oldAttribute2.SetRawText(text);

        changeObj.gameObject.SetActive(false);
        oneObj.gameObject.SetActive(true);

        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(type); });
        //attributeImage.sprite = ResourceManager.Instance.LoadSpriteSmall("AttributeIcon", $"attribute_icon_{type}");
        attributeName2.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, $"Attribute_{type}");
    }

    private async UniTask LoadSpriteAsync(CharacterAttribute type)
    {
        attributeImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("AttributeIcon", $"attribute_icon_{type}");
    }
}