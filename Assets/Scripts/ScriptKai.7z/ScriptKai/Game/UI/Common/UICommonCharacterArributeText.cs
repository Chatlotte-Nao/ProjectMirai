using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UICommonCharacterArributeText : MonoBehaviour
{
    [SerializeField] UIText textPrefabNameLabel;
    [SerializeField] UIText textPrefabNumberLabel;
    [SerializeField] Image attributeImage;
    // Start is called before the first frame update
    public async UniTask SetLabel(string str ,CharacterAttribute eAtt)
    {
        textPrefabNumberLabel.SetRawText(str);

        textPrefabNameLabel.SetLabel(LocalizeManager.DATA_TYPE.CHARACTER, $"Attribute_{eAtt}");

        AsyncManager.Instance.StartAsync(async () => { attributeImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("AttributeIcon", $"attribute_icon_{eAtt}"); });

    }
}
