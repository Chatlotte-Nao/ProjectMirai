﻿using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;
public class EquipmentJob : MonoBehaviour
{
    [SerializeField] Image[] jobIcons;
    [SerializeField] GameObject[] jobObjects;
    public void SetUp(List<int> equipableJobs)
    {
        for (int i = 0; i < jobIcons.Length; i++)
        {
            jobObjects[i].gameObject.SetActive(false);
            if (equipableJobs.Count <= 3 && equipableJobs.Count>i)
            {
                jobObjects[i].gameObject.SetActive(true);
                var jobMaster = DataManager.Instance.Master.Job[equipableJobs[i]];
                //new
                AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(i,jobMaster); });
                //jobIcons[i].sprite = ResourceManager.Instance.LoadSpriteSmall("Job", jobMaster.IconPath);
            }
        }
    }

    private async UniTask LoadSpriteAsync(int i,JobMaster jobMaster)
    {
        jobIcons[i].sprite = await ResourceManager.Instance.LoadSpriteAsync("Job", jobMaster.IconPath);
    }
}
