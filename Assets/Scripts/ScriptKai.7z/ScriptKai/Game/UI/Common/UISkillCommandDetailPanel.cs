﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Battle;
using Battle.Unity;
using Battle.Unity.BattleUI;
using Pheonix.Core;
using Spine;
using Spine.Unity;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using CharacterMain.UI;

public class UISkillCommandDetailPanel : MonoBehaviour
{
    [SerializeField] Image skillIcon;
    [SerializeField] UIText costAp;
    [SerializeField] UIText skillName;
    [SerializeField] UIText coolDown;
    [SerializeField] UIText energyDesc;
    [SerializeField] UIText energy;
    [SerializeField] UIText type;
    [SerializeField] UIText range;
    [SerializeField] GameObject detailInfo;
    [SerializeField] UIText detail;
    [SerializeField] CommandPositionView leftCommandPositionView;
    [SerializeField] CommandPositionView rightCommandPositionView;
    [SerializeField] List<GameObject> stress;
    [SerializeField] GameObject max;
    [SerializeField] GameObject spotlight;
    [SerializeField] GameObject EnemyMaskIcon;
    [SerializeField] TargetSizeFitter sizeFitter;
    [SerializeField] GameObject lineImg;


    private SkeletonGraphic character;
    private RectTransform miniCharacter;
    private const float baseNum = 100f;    // 命令详情面板小人比例。 以100为底
    private Dictionary<int, RectTransform> miniCharacterDic;

    public void Refresh(int masterID, long skillID, bool positionEnable)
    {
        var skillMaster = DataManager.Instance.Master.Skill[skillID]; // BattleMain.Instance.masterDataReader.GetMasterData<long, SkillMaster>(skillID);
        skillName.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{skillID}_name");
        foreach (var o in stress)
        {
            o.SetActive(false);
        }
        max.SetActive(false);
        if ((CommandType)skillMaster.skillType == CommandType.PassiveSkill)
        {
            detailInfo.SetActive(false);
            lineImg.SetActive(false);
            sizeFitter.SetVerticalOffset(227);
            if (stress.Count > 0)
            {
                stress[0].SetActive(true);
            }
        }
        else
        {
            if ((CommandType)skillMaster.skillType == CommandType.Skill ||
                (CommandType)skillMaster.skillType == CommandType.NormalAttack)
            {
                if (stress.Count > 1)
                {
                    stress[0].SetActive(true);
                    stress[1].SetActive(true);
                }
            }
            else if ((CommandType)skillMaster.skillType == CommandType.MusicEffect)
            {
                if (stress.Count > 2)
                {
                    stress[0].SetActive(true);
                    stress[1].SetActive(true);
                    stress[2].SetActive(true);
                    max.SetActive(true);
                }
            }

            detailInfo.SetActive(true);
            lineImg.SetActive(true);
            sizeFitter.SetVerticalOffset(375);
            coolDown.SetRawText(skillMaster.cd + LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.BATTLE, "Text_Turn"));
            bool isMusicEffect = (CommandType)skillMaster.skillType == CommandType.MusicEffect;
            List<int> energyNumber = isMusicEffect ? skillMaster.energyDecrease : skillMaster.energyIncrease;
            costAp.SetRawText(skillMaster.apCost.ToString());
            energy.SetRawText($"<color=#FF0000>{energyNumber[2]}</color>/<color=#00FF2C>{energyNumber[1]}</color>/<color=#0067FF>{energyNumber[0]}</color>" + LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.BATTLE, "Text_Energy"));
            energyDesc.SetLabel(LocalizeManager.DATA_TYPE.BATTLE, isMusicEffect ? "Attribute_Energy" : "Attribute_CollectEnergy");
            if ((DamageType)skillMaster.damageType == DamageType.HEAL)
            {
                type.SetLabel(LocalizeManager.DATA_TYPE.BATTLE, "Damage_Heal");
            }
            else if ((DamageType)skillMaster.damageType == DamageType.MAGIC)
            {
                type.SetLabel(LocalizeManager.DATA_TYPE.BATTLE, "Damage_Magical");
            }
            else if ((DamageType)skillMaster.damageType == DamageType.PHYSICAL)
            {
                type.SetLabel(LocalizeManager.DATA_TYPE.BATTLE, "Damage_Physical");
            }

            if ((TargetType)skillMaster.targetType == TargetType.SELF ||
                (TargetType)skillMaster.targetType == TargetType.SELF_PARTY_SINGLE ||
                (TargetType)skillMaster.targetType == TargetType.TARGET_PARTY_SINGLE ||
                (TargetType)skillMaster.targetType == TargetType.TARGET_PARTY_FRONT)
            {
                range.SetLabel(LocalizeManager.DATA_TYPE.BATTLE, "Range_Single");
            }
            else
            {
                range.SetLabel(LocalizeManager.DATA_TYPE.BATTLE, "Range_AOE");
            }
        }

        var rectTransform = detail.GetComponent<RectTransform>();
        rectTransform.rect.Set(rectTransform.rect.x, rectTransform.rect.y, rectTransform.rect.width, 0);

        detail.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{skillID}_desc");

        bool[] selfPosition = skillMaster.selfPosition.ToArray();
        bool[] targetPosition = skillMaster.targetPosition.ToArray();
        if (TargetTypeClassify.selfTargetTypes.Contains((TargetType)skillMaster.targetType))
        {
            targetPosition = new[] { false, false, false, false };
        }

        bool isAOE = TargetTypeClassify.aoeTargetTypes.Contains((TargetType)skillMaster.targetType);

        leftCommandPositionView.Initialize(CommandPositionView.Type.Target, CommandPositionView.Direction.RL);
        rightCommandPositionView.Initialize(CommandPositionView.Type.Self, CommandPositionView.Direction.LR);
        leftCommandPositionView.SetValue(targetPosition, false, isAOE, CommandPositionView.IconType.Aim);
        rightCommandPositionView.SetValue(selfPosition, !positionEnable, false);
        BattleCharacterMaster battleCharacterMaster = DataManager.Instance.Master.BattleCharacter[(long)masterID];
        SetupMiniCharacter(masterID, 0, rightCommandPositionView.GetEnablePointParent(), battleCharacterMaster.characterResourceId);
        string iconPath = skillMaster.iconPath;
        if (!string.IsNullOrEmpty(iconPath))
        {
            var texture = ResourceManager.Instance.LoadSprite("SkillIcon", iconPath);
            skillIcon.sprite = texture;
        }


    }

    public void Show()
    {
        this.gameObject.SetActive(true);
    }


    public void SetupEnemyMaskIconWhenSizeMoreThanOne(long id, int dir)
    {
        if (dir == 0)
        {
            Debug.Log("Player：" + id);
        }
        else
        {
            Debug.Log("Enemy：" + id);
        }

        if (miniCharacter != null)
        {
            miniCharacter.gameObject.SetActive(false);
        }

        EnemyMaskIcon.gameObject.SetActive(true);
    }

    public async UniTask SetupMiniCharacter(long id, int dir, List<Transform> parent, int characterResourceId)
    {
        EnemyMaskIcon.gameObject.SetActive(false);

        if (miniCharacterDic == null)
        {
            miniCharacterDic = new Dictionary<int, RectTransform>();
        }

        if (miniCharacter != null)
        {
            miniCharacter.gameObject.SetActive(false);
        }

        miniCharacterDic.TryGetValue((int)id, out miniCharacter);

        int parentIndex = 0;

        if (parentIndex < parent.Count)
        {
            if (miniCharacter == null)
            {
                var ass = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync(
                    $"{AssetPath.UICharacter}/{id}", parent[parentIndex]);

                miniCharacter = (RectTransform)ass.transform;
                miniCharacterDic.Add((int)id, miniCharacter);
                miniCharacter.gameObject.SetActive(true);
                spotlight.transform.SetParent(miniCharacter);
                spotlight.transform.localPosition = Vector3.zero;
                spotlight.transform.localScale = Vector3.one * 4f;
                spotlight.transform.SetSiblingIndex(0);

                character = miniCharacter.GetComponentInChildren<SkeletonGraphic>();
                if (character != null)
                {
                    character.initialFlipX = (dir == 1);

                    var data = DataManager.Instance.Master.CharacterAnimation[id];
                    var animName = data.attack;

                    BattleCharacterMaster battleCharacterMaster = DataManager.Instance.Master.BattleCharacter[id];
                    CharacterResourceMaster characterResourceMaster = DataManager.Instance.Master.CharacterResource[battleCharacterMaster.characterResourceId];
                    character.gameObject.transform.localScale = Vector3.one * characterResourceMaster.uiCharacterScale / baseNum;
                    character.startingAnimation = animName;
                    character.startingLoop = true;
                    if (character.AnimationState != null)
                    {
                        character.AnimationState.SetAnimation(0, animName, true);
                        character.AnimationState.Complete += delegate (TrackEntry state)
                        {
                            parentIndex++;
                            if (parentIndex >= parent.Count)
                            {
                                parentIndex = 0;
                            }

                            miniCharacter.transform.SetParent(parent[parentIndex]);
                            miniCharacter.GetComponent<RectTransform>().anchoredPosition = Vector2.up * 10;
                        };
                    }
                }
            }
            else
            {
                miniCharacter.gameObject.SetActive(true);
                miniCharacter.transform.SetParent(parent[parentIndex]);
                character = miniCharacter.GetComponentInChildren<SkeletonGraphic>();
                if (character.AnimationState != null)
                {
                    var data = DataManager.Instance.Master.CharacterAnimation[id];
                    var animName = data.attack;

                    character.AnimationState.SetAnimation(0, animName, true);
                    character.AnimationState.Complete += delegate (TrackEntry state)
                    {
                        parentIndex++;
                        if (parentIndex >= parent.Count)
                        {
                            parentIndex = 0;
                        }

                        miniCharacter.transform.SetParent(parent[parentIndex]);
                        miniCharacter.GetComponent<RectTransform>().anchoredPosition = Vector2.up * 10;
                    };
                }
            }

            miniCharacter.GetComponent<RectTransform>().anchoredPosition = Vector2.up * 10;
            miniCharacter.localScale = Vector3.one * 0.25f;
        }
    }

    public void Hide()
    {
        detail.SetRawText("");
        this.gameObject.SetActive(false);
    }
}