﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Game.ScriptEngine;

public class UICommonItemInfoDialog : UIDialogBase
{
    //[SerializeField] UITexture frame;
    [SerializeField] BaseItem icon;
    [SerializeField] UIText nameText;
    [SerializeField] UIText descText;
    [SerializeField] UIText possessionCountText;
    [SerializeField] GameObject obtainWayGroup;
    [SerializeField] ItemObtainWay[] obtainWays;

    [SerializeField]
    private List<long> itemNotNeedNum = new List<long>() { 103002044, 103002045, 103002046 };

    private long mItemId = 0;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        for (int i = 0; i < obtainWays.Length; i++)
        {
            var idx = i;
            obtainWays[i].OnClickGoto.GuardSubscribeAsync(async ()=>
            {
                await OnClickGoto(idx);
            }).AddTo(mSubscriptions);
        }
    }

    public override void OnHide()
    {
        base.OnHide();
        Dispose();
    }

    public async UniTask Setup(long itemId, bool isDetail)
    {
        mItemId = itemId;

        await icon.SetupAsync(itemId,"");

        nameText.SetLabel(LocalizeManager.DATA_TYPE.ITEM, $"{itemId}_name");
        descText.SetLabel(LocalizeManager.DATA_TYPE.ITEM, $"{itemId}_desc");
        if (itemNotNeedNum.Contains(itemId))
        {
            possessionCountText.gameObject.SetActive(false);
        }

        possessionCountText.SetFormat(LocalizeManager.DATA_TYPE.INVENTORY, "INVENTORY_POSSESSNUM_FORMAT", DataManager.Instance.Player.Item.GetCount(itemId));
        var itemType = DataManager.Instance.Master.Content[itemId].contentTypeMasterId;
        long value = 0 ;
        switch (itemType)
        {
            case 106:
                value = DataManager.Instance.Player.Wallet.GetCount("GAME_MONEY");
                break;
            case 107:
                value = DataManager.Instance.Player.Wallet.GetCount("FREE_STONE");
                break;
            case 108:
                value = DataManager.Instance.Player.Wallet.GetCount("PAID_STONE");
                break;
            case 110:
                value = DataManager.Instance.Player.Player.GetCurrentStaimina();
                break;
            case 121:
                value = DataManager.Instance.Player.Item.GetCount(121000001) + DataManager.Instance.Player.Item.GetCount(121000002);
                Debug.Log("121 case" + DataManager.Instance.Player.Item.GetCount(121000001));
                Debug.Log("121 case" + DataManager.Instance.Player.Item.GetCount(121000002));
                break;
            case 113:
                possessionCountText.gameObject.SetActive(false);
                break;
            default:
                value = DataManager.Instance.Player.Item.GetCount(itemId);
                break;
        }
        possessionCountText.SetFormat(LocalizeManager.DATA_TYPE.INVENTORY, "INVENTORY_POSSESSNUM_FORMAT", value);
       
        if (true)
        {
            var master = DataManager.Instance.Master.Item.Values.FirstOrDefault(a => a.id == mItemId);
            if (master == null)
            {
                obtainWayGroup.SetActive(false);
                return;
            }
            obtainWayGroup.SetActive(true);
            //var master = DataManager.Instance.Master.Item[mItemId];
            for (int i = 0; i < obtainWays.Length; i++)
            {
                if (master.ObtainWay.Count > i)
                {
                    obtainWays[i].gameObject.SetActive(true);
                    if (master.getJumpUiId.Count > i)
                    {
                        if (master.getJumpUiId[i] != null)
                        {
                            obtainWays[i].Setup(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.INVENTORY, master.ObtainWay[i]), isDetail);
                        }
                    }
                    else
                        obtainWays[i].Setup(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.INVENTORY, master.ObtainWay[i]), false);
                }
                else
                {
                    obtainWays[i].gameObject.SetActive(false);
                }
            }
            
        }
        else
        {
            obtainWayGroup.SetActive(false);
        }

        
    }

    private async UniTask OnClickGoto(int idx)
    {
        var master = DataManager.Instance.Master.Item.Values.FirstOrDefault(a => a.id == mItemId);
        if (master == null)
        {
            obtainWayGroup.SetActive(false);
            return;
        }
        var jumpContent = master.getJumpUiId[idx];
        await HideAsync();
        await CommonUtil.JumpToTargetPage(jumpContent);
    }
}
