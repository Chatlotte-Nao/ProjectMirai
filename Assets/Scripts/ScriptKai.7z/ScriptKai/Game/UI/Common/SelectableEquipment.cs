﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Takasho.Schema.Score.ResourceCn.Item.V1;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;

public class SelectableEquipment : BaseEquipment
{

    public bool IsSelected {get; private set;}


    [SerializeField] UIText statusText;
    [SerializeField] GameObject checkGroup;
    [SerializeField] UIText numText;
    [SerializeField] GameObject iconObj;
    [SerializeField] GameObject selectObj;
    [SerializeField] UIText selectNumText;
    [SerializeField] UIButton deleteButton;
    [SerializeField] GameObject numGameObject;
    [SerializeField] private Image itemFrame;
    [SerializeField] private GameObject lockObj;
    [SerializeField] private GameObject textObj;
    public UnityEvent OnRemoveClick => deleteButton.OnTouchUpInside;
    public string itemId;
    public override void Setup(EquipmentViewModel model)
    {
        base.Setup(model);
        itemId = model.uniqueId;
        Select(false);
        iconImage.transform.localScale = Vector3.one;
        if(iconObj!=null)
            iconObj.gameObject.SetActive(true);
        borderImage.gameObject.SetActive(true);
        if(numGameObject!=null)
            numGameObject.gameObject.SetActive(false);
        if (itemFrame != null)
        {
            itemFrame.gameObject.SetActive(false);
        }

        if (lockObj != null)
        {
            lockObj.gameObject.SetActive(model.locked);
        }
    }
    public void SetUpItemData(PlayerItem playerItem)
    {
        itemId = playerItem.ItemMasterId.ToString();
        //equipmentType = EquipmentType.PlayerItem;
        iconImage.transform.localScale = new Vector3(.8f,.8f,.8f);
        SetupItem(playerItem.ItemMasterId,playerItem.Count.ToString());
        iconObj.gameObject.SetActive(false);
        //init display
        transform.localScale = Vector3.one;
        transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y, 0);
        gameObject.SetActive(true);
        Select(false);
        borderImage.gameObject.SetActive(false);
        if (itemFrame != null)
        {
            itemFrame.gameObject.SetActive(true);
            var master =  DataManager.Instance.Master.Item[ playerItem.ItemMasterId];
            AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(master); });
            //itemFrame.sprite = ResourceManager.Instance.LoadSpriteSmall("FrameBg", $"frame_item_{master.rarity}");
        }
        if(numGameObject!=null)
            numGameObject.gameObject.SetActive(true);
    }

    public virtual void SetupItem(long itemId, string text)
    {
        AsyncManager.Instance.StartAsync(SetupAsync(itemId, text));
    }

    public virtual async UniTask SetupAsync(long itemId, string text)
    {
        numText.SetRawText(text);
        await iconImage.LoadAsync($"ItemIcon", itemId.ToString());
    }

    public void SetSelectableStatus(bool selectable, string showText = "")
    {
        SetInteractable(selectable);
        statusText.SetRawText(showText);
        if (textObj != null)
        {
            textObj.gameObject.SetActive(showText!="");
        }
    }

    public void Select(bool value)
    {
        checkGroup.SetActive(value);
        IsSelected = value;
        if (selectObj!=null)
            selectObj.SetActive(false);
    }
    public void Select(bool value,long num)
    {
        checkGroup.SetActive(value || num > 0);
        IsSelected = value;
        selectObj.SetActive(value || num >0);
        selectNumText.SetRawText(num.ToString());
    }

    private async UniTask LoadSpriteAsync(ItemMaster master)
    {
        itemFrame.sprite = await ResourceManager.Instance.LoadSpriteAsync("FrameBg", $"frame_item_{master.rarity}");
    }
}
