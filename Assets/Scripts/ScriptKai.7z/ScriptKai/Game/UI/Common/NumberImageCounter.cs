﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NumberImageCounter : MonoBehaviour
{
	[SerializeField] List<Sprite> numberSprites;
	[SerializeField] List<Image> numberImages;


	public void SetNumber(int number)
	{
		if (number < 0) number = 0;

		for (int i = 0; i < numberImages.Count; i++)
		{
			var num = number % 10;
			number /= 10;

			if (num != 0 || number != 0 || i == 0)
			{
				numberImages[i].enabled	= true;
				numberImages[i].sprite	= numberSprites[num];
			}
			else
			{
				numberImages[i].enabled = false;
			}
		}
	}
}
