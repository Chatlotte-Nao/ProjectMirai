﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Playables;
using Spine.Unity;
using System.Linq;
using UnityEngine.UI;
public class UICommonCharacterGetDialog : UIDialogBase
{
    //[SerializeField] UnityEngine.UI.RawImage charaImage;
    [SerializeField] UIButton clickHandler;
    //[SerializeField] PlayableDirector playableDirectors = null;

    [SerializeField] UIButton jumpButton;
    [SerializeField] private UIGachaCharacterInfo characterInfo;
    [SerializeField] private GameObject characterObj;
    public UIHomeGachaMovieDialog gachaMovieDialog;
    private bool isPlaying = false;
    //private List<GameObject> characters = new List<GameObject>();
    private List<long> charaIds = null;
    private int currentIndex = 0;
    //UIRTCamera mRTCamera = null;

    public UIStrEvent OnShowMoie = new UIStrEvent();
    public ClickEvent OnCloseClick = new ClickEvent();
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        // var rtc = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/RTCamera");
        // mRTCamera = rtc.GetComponent<UIRTCamera>();
        clickHandler.OnTouchUpInside.GuardSubscribeAsync(OnClickScreen).AddTo(mSubscriptions);
        jumpButton.OnTouchUpInside.GuardSubscribeAsync(OnJumpClick).AddTo(mSubscriptions);
        gachaMovieDialog.OnJump.GuardSubscribeAsync(OnMovieDialogEnd).AddTo(mSubscriptions);
        //playableDirectors.stopped += OnTimelineEnd;
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        await UI.ScreenEffect.Fade(1);
        currentIndex = 0;
        SetupCharacter();
        isPlaying = true;
        await UI.ScreenEffect.Fade(0);
    }

    private List<long> characterIds = new List<long>();

    public void SetupNewCharacterIds(List<long> ids)
    {
        characterIds = ids;
    }

    public async UniTask Setup(List<long> ids)
    {
        charaIds = ids;
        if (ids.Count < 10)
        {
            jumpButton.gameObject.SetActive(false);
        }
        //characterIds.Clear();
        // foreach (var item in ids)
        // {
        //      var characterMaster = DataManager.Instance.Master.BattleCharacter[item];
        //     // var resourceMaster = DataManager.Instance.Master.CharacterResource[characterMaster.characterResourceId];
        //     //
        //     //
        //     // //temp
        //     // GameObject loadCharacter = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Adventure/Objects/chara/" + resourceMaster.advModelId);
        //     // SkeletonAnimation skeletonAnimation = loadCharacter.GetComponent<SkeletonAnimation>();
        //     // skeletonAnimation.Initialize(false);
        //     // skeletonAnimation.Update(0.0f);
        //     // skeletonAnimation.LateUpdate();
        //     // var animations = skeletonAnimation.AnimationState?.Data?.SkeletonData?.Animations;
        //     // var animation = animations.FirstOrDefault(tempAnimation => tempAnimation.Name.StartsWith("99_"));
        //     // if (animation != null)
        //     // {
        //     //     skeletonAnimation.AnimationState.SetAnimation(0, animation, true);
        //     // }
        //     //
        //     // loadCharacter.transform.parent = transform;
        //     // characters.Add(loadCharacter);
        //     if ( characterMaster.initialRank == 3 && !characterIds.Contains(item))
        //     {
        //         characterIds.Add(item);
        //     }
        //     //loadCharacter.SetActive(false);
        // }
    }

    private async UniTask OnMovieDialogEnd(GameObject o)
    {
        isPlaying = false;
        characterObj.SetActive(true);
    }

    private async UniTask OnClickScreen()
    {
        if (!isPlaying)
        {
            //characters[currentIndex].SetActive(false);
            if (currentIndex < charaIds.Count)
            {
                await UI.ScreenEffect.Fade(1);
                await SetupCharacter();
                await UI.ScreenEffect.Fade(0);
            }
            else
            {
                Game.Sound.SoundPlayer.StopBgm();
                await HideAsync();
            }
        }
    }

    private bool isJump = false;
    private async UniTask OnJumpClick()
    {
        if (characterIds.Count > 0)
        {
            jumpButton.gameObject.SetActive(false);
            charaIds = characterIds;
            currentIndex = 0;
            isJump = true;
            await SetupCharacter();
        }
        else
        {
            Game.Sound.SoundPlayer.StopBgm();
            await HideAsync();
        }
    }

    private async UniTask SetupCharacter()
    {
        // mRTCamera.Setup(characters[currentIndex]);
        // charaImage.texture = mRTCamera.GetRenderTexture();
        //characters[currentIndex].SetActive(true);
        Log.Debug($"xzf >>> SetupCharacter length {charaIds.Count} / {currentIndex}");
        characterInfo.SetUp(charaIds[currentIndex]);
        characterObj.SetActive(false);
        var characterMaster = DataManager.Instance.Master.BattleCharacter[charaIds[currentIndex]];
        var resourceMaster = DataManager.Instance.Master.CharacterResource[characterMaster.characterResourceId];
        var rank = DataManager.Instance.Master.BattleCharacter[charaIds[currentIndex]].initialRank;
        var skillMaster = DataManager.Instance.Master.Skill[characterMaster.musicalEffectId];
       
        await gachaMovieDialog.LoadDrawReadyVideoRoutine($"Movies/{skillMaster.cutinPath}",false);

        if (characterIds.Contains(charaIds[currentIndex]) && !isJump)
        {
            characterIds.Remove(charaIds[currentIndex]);
        }
        if (rank == 3 && resourceMaster.cutinPath != string.Empty)
        {
            Game.Sound.SoundPlayer.StopBgm();
            OnShowMoie?.Invoke($"Movies/Gacha/CharacterShow/{resourceMaster.cutinPath}");
        }
        else
        {
            //jumpButton.gameObject.SetActive(true);
            Game.Sound.SoundPlayer.PlayBgm(resourceMaster.gachaBgm);
        }

        // playableDirectors.time = 0;
        // playableDirectors.Play();
        isPlaying = true;
        currentIndex++;

    }

    public override void OnHide()
    {
        OnCloseClick?.Invoke(this.gameObject);
        base.OnHide();
        Dispose();
    }

    public override void Dispose()
    {
        base.Dispose();
        // if (mRTCamera != null)
        // {
        //     mRTCamera.Dispose();
        //     mRTCamera = null;
        // }
    }
}
