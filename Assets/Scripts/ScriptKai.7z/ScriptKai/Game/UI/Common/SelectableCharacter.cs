﻿using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class SelectableCharacter : BaseCharacter
{
    public bool IsSelected {get; private set;}

    [SerializeField] GameObject checkGroup;
    [SerializeField] UIText selectText;

    public override void Setup(long itemId)
    {
        base.Setup(itemId);
        Select(false);
    }

    public override async UniTask SetupAsync(long itemId)
    {
        
        await base.SetupAsync(itemId);
        Select(false);
    }



    public void Select(bool value)
    {
        checkGroup.SetActive(value);
        IsSelected = value;
        if(IsSelected)
        {
            PxSoundManager.Instance.PlaySe("feedbackSE_date_select01");
        }
      
    }

    public void SetSelectText(string value)
    {
        selectText.SetRawText(value);
    }
}
