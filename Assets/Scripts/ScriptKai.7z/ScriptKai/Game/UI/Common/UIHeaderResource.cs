﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIHeaderResource : MonoBehaviour
{
    


    public UIHeaderResType resType;
    
    [SerializeField] UIText showText;
    [SerializeField] UIButton addBtn;
    [SerializeField] UIButton iconBtn;
    [SerializeField] BaseItem baseItem;
    public UnityEvent OnClick => addBtn.OnTouchUpInside;
    public ClickEvent OnIconClick => iconBtn.onClick;
    public void SetText(string value)
    {
        showText.SetRawText(value);
    }

    private long _itemId;
    public void SetIconImage(long itemId)
    {
        _itemId = itemId;
        if (baseItem != null)
        {
            baseItem.Setup(itemId, "");
            UptateItemValue();
        }
    }

    public void UptateItemValue()
    {
        var value = DataManager.Instance.Player.Item.GetCount(_itemId);
        showText.SetRawText(value.ToString());
    }
}

public enum UIHeaderResType
{
    Coin = 1,
    GemFree,
    GemPaid,
    Stamina,
}