﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;

public class BaseItem : MonoBehaviour
{
    public UnityEvent OnClick => uiButton.OnTouchUpInside;
    public ClickEvent OnLongClick => uiButton.onLongClick;

    public UIButton Button => uiButton;

    public enum ShowDetailType
    {
        Disable = 0,
        ShowDetail,
        ShowSimple,
    }

    [SerializeField] UIButton uiButton;

    [SerializeField] protected Image frameImage = null;
    [SerializeField] protected Image equipmentFrameImage = null;
    [SerializeField] protected UITexture iconImage = null;
    [SerializeField] protected UIText numText = null;
    [SerializeField] protected ShowDetailType showDetailType = ShowDetailType.ShowDetail;
  

    public long ItemId {get; private set;}


    void Awake()
    {
        if (uiButton != null)
            uiButton.OnTouchUpInside.Subscribe(OnClickItem);
    }


    public virtual void Setup(long itemId, string text)
    {
        AsyncManager.Instance.StartAsync(SetupAsync(itemId, text));
    }

    public virtual async UniTask SetupAsync(long itemId, string text)
    {
        if(numText!=null)
            numText.SetRawText(text);
        
        if (itemId != ItemId)
        {
            if (frameImage != null)
                frameImage.gameObject.SetActive(false);
            if (equipmentFrameImage != null)
                equipmentFrameImage.gameObject.SetActive(false);
            ItemId = itemId;
            string id = itemId.ToString();
            string iconPath = "ItemIcon";
            int rarity = 2;
            var ok = DataManager.Instance.Master.Content.TryGetValue(itemId, out var contentMaster);
            if (!ok)
            {
                return;
            }
            var master = DataManager.Instance.Master.Item.TryGetValue(itemId, out var itemMaster);
            if (master)
            {
                rarity = itemMaster.rarity;
            }
            switch (contentMaster.contentTypeMasterId)
            {
                case 102:
                    var equipment = DataManager.Instance.Master.Equipment[itemId];
                    id = equipment.iconId;
                    iconPath = "Equipment/Icons";
                    rarity = equipment.rarity;
                    if (equipmentFrameImage != null)
                    {
                        await SetFrameImage(equipmentFrameImage, $"frame_equipment_small_{rarity}", 1);
                        break;
                    }
                    if (frameImage != null)
                    {
                        await SetFrameImage(frameImage, $"frame_item_{rarity}", 0.8f);
                    }
                    break;
                default:
                    if(frameImage!=null)
                        await SetFrameImage(frameImage,$"frame_item_{rarity}",0.8f);
                    break;
            }
            await iconImage.LoadAsync(iconPath, id.ToString());
        }
        
    }
    async UniTask SetFrameImage(Image image,string rarityPath,float scaleVaule)
    {
        image.gameObject.SetActive(true);
        //new
        image.sprite = await ResourceManager.Instance.LoadSpriteAsync("FrameBg", rarityPath);
        //image.sprite = ResourceManager.Instance.LoadSpriteSmall("FrameBg", rarityPath);
        iconImage.transform.localScale = new Vector3(scaleVaule,scaleVaule,scaleVaule);
    }


    public virtual void SetInteractable(bool value)
    {
        uiButton.GetComponent<Graphic>().enabled = value;
    }

    public virtual void SetupNeed(long itemId, long needNum)
    {
        long cur = DataManager.Instance.Player.Item.GetCount(itemId);
        if ( cur >= needNum)
        {
            AsyncManager.Instance.StartAsync(SetupAsync(itemId, string.Format(LocalizeManager.Instance.GetCommonText("Common_ItemNeedNum_Format"), cur, needNum)));
        }
        else
        {
            AsyncManager.Instance.StartAsync(SetupAsync(itemId, string.Format(LocalizeManager.Instance.GetCommonText("Common_ItemNeedNum_Format_NotEnough"), cur, needNum)));
        }
    }
    private void OnClickItem()
    {
        Debug.Log(ItemId);
        if (showDetailType == ShowDetailType.Disable)
        {
            return;
        }
        ShowItemInfoPopup(showDetailType);
    }

    protected void ShowItemInfoPopup(ShowDetailType showDetailTyp)
    {
        var detailType = showDetailTyp;
        var contentTypeMasterId = DataManager.Instance.Master.Content[ItemId].contentTypeMasterId;
        if (contentTypeMasterId == 102)
        {
            AsyncManager.Instance.StartGuardAsync(UI.Popup.ShowEquipmentInfoPopupAsync(ItemId));
        }
        else if (contentTypeMasterId == 124 || contentTypeMasterId == 125)
        {
            UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.MISSION_DETAILS,
                $"{ItemId}_desc"));
        }
        else
        {
            AsyncManager.Instance.StartGuardAsync(UI.Popup.ShowItemInfoPopupAsync(ItemId,
                detailType == ShowDetailType.ShowDetail));
        }
    }
}
