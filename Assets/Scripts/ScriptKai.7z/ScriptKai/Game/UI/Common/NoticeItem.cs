﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;
using TMPro;

public enum Tags
{
    None = 0,
    News,
    AnnounceMent,
    Activity,
   
}

public class NoticeItem : MonoBehaviour
{
    public UnityEvent OnClick => uiButton.OnTouchUpInside;
    public UIButton Button => uiButton;

    [SerializeField] UIButton uiButton;
    [SerializeField] UIText titleText;
    [SerializeField] public TextMeshProUGUI text;
    [SerializeField] GameObject[] tags;
  
    public Image Bg;
    public int NoticeIndex;
    public virtual void Setup(string text, Tags tag)
    {
        titleText.SetRawText(text);
        if (tag != 0)
        {
            tags[(int)tag].SetActive(true);
          
        }
            
    }

 


}
