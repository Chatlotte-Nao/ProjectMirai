﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UICommonEquipmentInfoDialog : UIDialogBase
{
    [SerializeField] UIButton backButton;
    [SerializeField] UIEquipmentPanel _equipmentPanel;

    public override async UniTask InitializeAsync()
    {
        backButton.OnTouchUpInside.Subscribe(Dispose);
    }

    public async UniTask Setup(long equipmentId)
    {
        var evm = EquipmentUtil.BuildFakeEquipmentViewModel(equipmentId);
        _equipmentPanel.Setup(evm);
    }

    public override void Dispose()
    {
        base.Dispose();
    }
}
