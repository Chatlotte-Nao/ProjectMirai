﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
public class UICommonLevelUpDialog : UIDialogBase
{
    [SerializeField] UIText oldLevelText;
    [SerializeField] UIText newLevelText;
    [SerializeField] UIText oldStaminaMaxText;
    [SerializeField] UIText newStaminaMaxText;
    [SerializeField] UIText staminaText;
    [SerializeField] UIButton cancelButton;
    [SerializeField] private UITexture titleTexture;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        titleTexture.Load("Font", "ty_font_djts_01", true);
        if (cancelButton != null)
            cancelButton.onClick.GuardSubscribeAsync(onClickClose).AddTo(mSubscriptions);
        oldLevelText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "COMMON_LVFORMAT",  DataManager.Instance.Player.Player.GetOldLevel());
        newLevelText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "COMMON_LVFORMAT",  DataManager.Instance.Player.Player.GetLevel());
        oldStaminaMaxText.SetRawText(  DataManager.Instance.Master.PlayerLevel[DataManager.Instance.Player.Player.GetOldLevel()].staminaLimit.ToString());
        newStaminaMaxText.SetRawText( DataManager.Instance.Master.PlayerLevel[DataManager.Instance.Player.Player.GetLevel()].staminaLimit.ToString());
        
        staminaText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "Common_LevelUp_Stamina",  DataManager.Instance.Master.PlayerLevel[DataManager.Instance.Player.Player.GetLevel()].addStamina.ToString());
    }
    public override void OnHide()
    {
        base.OnHide();
        Dispose();
    }
}
