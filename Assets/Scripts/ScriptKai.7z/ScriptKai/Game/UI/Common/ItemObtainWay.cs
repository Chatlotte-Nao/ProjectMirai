﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Events;

public class ItemObtainWay : MonoBehaviour
{
    [SerializeField] UIText descText;
    [SerializeField] UIButton gotoButton;


    public UnityEvent OnClickGoto => gotoButton.OnTouchUpInside;


    public void Setup(string desc, bool showButton)
    {
        descText.SetLabel(LocalizeManager.DATA_TYPE.INVENTORY, desc);
        if (gotoButton != null)
            gotoButton.gameObject.SetActive(showButton && !TutorialManager.Instance.GetIsLockHome()
            && MapSceneManager.Instance.CurrentType == MapSceneManager.SceneType.Home);
    }

}
