﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class RankIcon : MonoBehaviour
{
    [SerializeField] UIText rankText = null;
    // [SerializeField] Image expBar = null;
    public void Set(int rank, float fillAmount = 0f)
    {
        rankText.SetRawText(rank.ToString());
        //if (expBar != null)
        //{
        //    expBar.fillAmount = fillAmount;
        //}

    }
}
