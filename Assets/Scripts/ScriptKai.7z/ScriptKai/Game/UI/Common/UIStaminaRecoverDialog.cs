﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIStaminaRecoverDialog : UIDialogBase
{
    [SerializeField] UIText itemRemainNumText;
    [SerializeField] UIText gemPurchaseRemainTimesText;
    [SerializeField] BaseResource gemText;

    [SerializeField] UIButton itemUseButton;
    [SerializeField] UIButton gemPurchaseButton;

    [SerializeField] UIText staminaNumText;
    
    [SerializeField] UIButton cancelButton;
    private const long itemId = 123000001;

    private int staminaNum;
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        if (cancelButton != null)
            cancelButton.onClick.GuardSubscribeAsync(onClickClose).AddTo(mSubscriptions);
        await RefreshText();
        itemUseButton.OnTouchUpInside.GuardSubscribeAsync(OnClickUseItem).AddTo(mSubscriptions);
        gemPurchaseButton.OnTouchUpInside.GuardSubscribeAsync(OnClickPurchase).AddTo(mSubscriptions);
    }



    async UniTask RefreshText()
    {
        
        itemRemainNumText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "StaminaRecover_RemainItem_Format", DataManager.Instance.Player.Item.GetCount(itemId));

        if (DataManager.Instance.Player.Item.GetCount(itemId) == 0)
        {
            itemUseButton.enabled = false;
        }

        int remainTime = DataManager.Instance.Master.StaminaPurchase.Count;
        remainTime -= (int)DataManager.Instance.Player.Player.GetData().StaminaPurchaseCount;
        if (remainTime <= 0)
        {
            remainTime = 0;
            gemPurchaseButton.enabled = false;
            gemPurchaseRemainTimesText.SetLabel(LocalizeManager.DATA_TYPE.COMMON, "StaminaRecover_MaxTimes");
        }
        else
        {
            var master = DataManager.Instance.Master.StaminaPurchase[(int)DataManager.Instance.Player.Player.GetData().StaminaPurchaseCount+1];
            if (master.requireContent.Count > 0)
            {
                var s = master.requireContent[0].Split(':');
                await gemText.SetupNeedAsync(long.Parse(s[0]), long.Parse(s[1]));
            }
            else
            {
                await gemText.SetupNeedAsync(107000001, 0);
            }
            staminaNumText.SetRawText(master.recoverCount.ToString());
            staminaNum = master.recoverCount;
            gemPurchaseRemainTimesText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "StaminaRecover_RemainTimes_Format", remainTime);
        }

    }


    private async UniTask OnClickUseItem()
    {
        if (DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.StaminaMaxValue].data <= DataManager.Instance.Player.Player.GetCurrentStaimina())
        {
            var  str= LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.INVENTORY, "INVENTORY_STAMINAMAX");
            await UI.Popup.ShowPopupMessageAsync(str);
            return;
        }
        await ItemService.UseItem(itemId, 1);
        List<string> results = new List<string>();
        var sellPrice = DataManager.Instance.Master.Item[itemId].exp;
        results.Add($"110000001:{sellPrice}");
        await UI.Popup.ShowItemGetPopupAsync(results);
        
        await RefreshText();
    }

    private async UniTask OnClickPurchase()
    {
        var master = DataManager.Instance.Master.StaminaPurchase[(int)DataManager.Instance.Player.Player.GetData().StaminaPurchaseCount+1];
        var stoneNeed = long.Parse(master.requireContent[0].Split(':')[1]);
        if (DataManager.Instance.Player.Wallet.GetCount("FREE_STONE")<stoneNeed)
        {
            UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.GACHA, "Item_FREE_Number_Not"));
            return;
        }
            
        
        if (DataManager.Instance.Master.GlobalConfig[TakashoUtil.GlobalConfigID.StaminaMaxValue].data < DataManager.Instance.Player.Player.GetCurrentStaimina() + staminaNum)
        {
            var  str= LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.INVENTORY, "INVENTORY_STAMINAMAX");
            await UI.Popup.ShowPopupMessageAsync(str);
            return;
        }
        await CommonService.PurchaseStamina();
        List<string> results = new List<string>();
        results.Add($"110000001:{staminaNum}");
        await UI.Popup.ShowItemGetPopupAsync(results);
        await RefreshText();
    }

    public override void OnHide()
    {
        base.OnHide();
        Dispose();
    }
}
