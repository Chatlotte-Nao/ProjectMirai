﻿using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;
public class BaseSkillInfo : MonoBehaviour
{
    [SerializeField] private Image skillImage;
    [SerializeField] private UIText skillDesc;
    [SerializeField] private UIText skillName;
     public  void SetUpData(long skillId)
    {
        SkillMaster skillData = DataManager.Instance.Master.Skill[skillId];
        skillName.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{skillData.id}_name");
        skillDesc.SetLabel(LocalizeManager.DATA_TYPE.SKILL, $"{skillData.id}_desc");
        string skillIconPath = skillData.iconPath;

        //new 
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(skillIconPath); });
        //skillImage.sprite =  ResourceManager.Instance.LoadSprite("SkillIcon", skillIconPath);
    }

    private async UniTask LoadSpriteAsync(string skillIconPath)
    {
        skillImage.sprite =  await ResourceManager.Instance.LoadSpriteAsync("SkillIcon", skillIconPath);

    }
}
