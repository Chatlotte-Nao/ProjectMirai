using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UICommonCharacterArributeDetailsDialog : UIDialogBase
{
    [SerializeField] GameObject textPrefab;

    [SerializeField] RectTransform textPrefabPar;

    [SerializeField] Image icon;






    List<GameObject> textPrefabs = new List<GameObject>();
    List<GameObject> useingTextPrefabs = new List<GameObject>();

    public async UniTask SetCampIcon(long id)
    {
        //DataManager.Instance.Player.I
        icon = null;
    }


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        Debug.Log($"arribute  InitializeAsync");
        closeButton.onClick.GuardSubscribeAsync(async (o) =>
        {
            textPrefabs.Clear();
            foreach (var item in useingTextPrefabs)
            {
                textPrefabs.Add(item);
                item.SetActive(false);
            }
            useingTextPrefabs.Clear();
        });
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync();
    }

    public async UniTask SetUp(CharacterViewModel mCharacterViewModel)
    {
        var t = CharacterUtil.BuildViewModel(DataManager.Instance.Player.Character.Get(mCharacterViewModel.id), DataManager.Instance.Player.Equipment.GetList());
        for (int i = 1; i < (int)CharacterAttribute.Max; i++)
        {
            CharacterAttribute eAtt = (CharacterAttribute)i;
            int oldValue = mCharacterViewModel.attributeDict[eAtt] + mCharacterViewModel.equipAttributeDict[eAtt];
            GameObject attribute = null;
            if (textPrefabs.Count != 0)
            {
                attribute = textPrefabs[0];
                textPrefabs.Remove(attribute);
            }
            else
            {
                attribute = Instantiate(textPrefab, this.textPrefabPar, false);
            }
            useingTextPrefabs.Add(attribute);

            await attribute.GetComponent<UICommonCharacterArributeText>().SetLabel(eAtt.GetAttributePercent(oldValue), eAtt);
            
            attribute.gameObject.SetActive(true);
        }
    }
}
