﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Events;

public class BaseEquipment : MonoBehaviour
{
    public UnityEvent OnClick => uiButton.OnTouchUpInside;
    public UnityEvent OnLongClick => uiButton.OnLongTouch;

    public UIButton Button => uiButton;
    [SerializeField] private EquipmentIconType m_IconType = EquipmentIconType.Large;

    [SerializeField] UIButton uiButton;
    [SerializeField] UIText levelText;
    [SerializeField] RarityIcon rarityIcon;
    [SerializeField] protected UITexture iconImage;
    [SerializeField] Image slotBorderImage;
    [SerializeField] Image slotIcon;
    [SerializeField] UITexture equippedCharaIcon;
    [SerializeField] EquipmentJob equipmentJob;
    [SerializeField] Image campcon;
    [SerializeField] protected Image borderImage;
    public EquipmentViewModel Model { get; private set; }
    public virtual void Setup(EquipmentViewModel model)
    {
   
        levelText.SetFormat(LocalizeManager.DATA_TYPE.COMMON, "COMMON_LVFORMAT", model.level);

        var equipMaster = DataManager.Instance.Master.Equipment[model.id];
        //rarityIcon.SetRarity(equipMaster.rarity, RarityIcon.RarityType.EQUIPMENT);
        rarityIcon.SetRarity(model.rank, RarityIcon.RarityType.EQUIPMENT);
        if(slotBorderImage!=null)
            //new
            AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(equipMaster,1); });
            //slotBorderImage.sprite = ResourceManager.Instance.LoadSpriteSmall("EquipmentNew", $"yuezhuang_frame_part{equipMaster.rarity}");
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(equipMaster, 2); });
        //slotIcon.sprite = ResourceManager.Instance.LoadSpriteSmall("RarityIcon", $"slot{equipMaster.position}");
        //slotIcon.SetNativeSize();
        if(equipmentJob!=null)
            equipmentJob.SetUp(equipMaster.equipableJobs);

        //load icon image
        string _iconImagePath = "";
        switch (m_IconType)
        {
            case EquipmentIconType.Large:
                _iconImagePath = "Equipment/RectangleIcons";
                AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(equipMaster,3); });
                //borderImage.sprite = ResourceManager.Instance.LoadSpriteSmall("FrameBg", $"frame_equipment_mid_{equipMaster.rarity}");
                break;
            case EquipmentIconType.Small:
                _iconImagePath = "Equipment/Icons";
                AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(equipMaster,4); });
                //borderImage.sprite = ResourceManager.Instance.LoadSpriteSmall("FrameBg", $"frame_equipment_small_{equipMaster.rarity}");
                break;
            default:
                break;
        }

        if( Model==null || Model.id != model.id)
            iconImage.Load(_iconImagePath, equipMaster.iconId);
        Model = model;
        if (model.equippedCharacter > 0)
        {
            if (equippedCharaIcon != null)
            {
                equippedCharaIcon.gameObject.SetActive(true);
                equippedCharaIcon.Load("CharacterIcon", DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[model.equippedCharacter].characterResourceId].exploreCharacterIcon);
            }
        }
        else
        {
            if (equippedCharaIcon != null)
            {
                equippedCharaIcon.gameObject.SetActive(false);
            }
        }
    }
    
    

    public virtual void SetInteractable(bool value)
    {
        uiButton.GetComponent<Graphic>().enabled = value;
    }

    public void SetupEquipmentData(EquipmentViewModel equipmentViewModel)
    {
        Setup(equipmentViewModel);

        //init display
        transform.localScale = Vector3.one;
        transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y, 0);
        gameObject.SetActive(true);
    }
    
    public void Dispose()
    {
        Model = null;
    }


    private async UniTask LoadSpriteAsync(EquipmentMaster equipMaster,int index)
    {
        switch (index)
        {
            case 1:
                slotBorderImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("EquipmentNew", $"yuezhuang_frame_part{equipMaster.rarity}");
                break;
            case 2:
                slotIcon.sprite = await ResourceManager.Instance.LoadSpriteAsync("RarityIcon", $"slot{equipMaster.position}"); break;
            case 3:
                borderImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("FrameBg", $"frame_equipment_mid_{equipMaster.rarity}");
                break;
            case 4:
                borderImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("FrameBg", $"frame_equipment_small_{equipMaster.rarity}");
                break;
            default:
                break;
        }
    }
}

public enum EquipmentIconType
{
    Large,
    Small
}
