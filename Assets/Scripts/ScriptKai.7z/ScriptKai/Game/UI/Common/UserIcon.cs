﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;

public class UserIcon : MonoBehaviour
{
    [SerializeField] Image frameImage;
    [SerializeField] Image iconImage;


    public void Setup(long frameId, long iconId)
    {
        var userIconId = DataManager.Instance.Master
            .CharacterResource[DataManager.Instance.Master.BattleCharacter[iconId].characterResourceId]
            .userIconId;
        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(userIconId); });
        //iconImage.sprite =   ResourceManager.Instance.LoadSprite("RoundIcon", userIconId);
    }


    private async UniTask LoadSpriteAsync(string userIconId)
    {
        iconImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("CommonRoundIcon", userIconId);
    }
}
