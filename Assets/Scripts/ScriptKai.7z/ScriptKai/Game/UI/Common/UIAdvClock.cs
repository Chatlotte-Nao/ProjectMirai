﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using DG.Tweening;

public class UIAdvClock : MonoBehaviour
{
    [SerializeField] Animator animator;
    [SerializeField] Image fillImage;
    [SerializeField] RectTransform handTransform;


    private int maxValue = 120;
    private int currentValue;

    public void SetMaxValue(int max)
    {
        maxValue = max;
    }

    public void SetValue(int val)
    {
        currentValue = val;
        fillImage.fillAmount = (float)val/maxValue;
        handTransform.localRotation = Quaternion.Euler(0, 0, fillImage.fillAmount*360);
    }

    public async UniTask addTime(int time, float length = 1f)
    {
        await UniTask.Delay(500);
        int start = currentValue;
        int end = currentValue-time;
        float remainTime = length;
        while (remainTime > 0)
        {
            int cur = (int)Mathf.Lerp(end, start, remainTime/length);
            SetValue(cur);
            remainTime -= Time.deltaTime;
            await UniTask.Yield();
        }

        SetValue(end);

        await UniTask.Delay(500);
    }
}
