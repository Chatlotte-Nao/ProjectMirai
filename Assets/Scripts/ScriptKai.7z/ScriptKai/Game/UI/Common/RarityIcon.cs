﻿
using Game.Extensions;
using UnityEngine;
using UnityEngine.UI;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public sealed class RarityIcon : MonoBehaviour
{
	public enum RarityType
	{
		CHARACTER = 0,
		EQUIPMENT,
	}

	[SerializeField] Image rareBg;
	[SerializeField] Image characterRare;
	[SerializeField] Image[] equipmentRare;


	public void SetRarity(int rarity, RarityType rarityType)
	{
		switch (rarityType)
		{
			case RarityType.CHARACTER:
				//new
				AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(rarity); });
				//characterRare.sprite = ResourceManager.Instance.LoadSpriteSmall("RarityIcon", $"c{rarity}");
				rareBg.gameObject.SetActiveOnlyChanged(true);
				characterRare.gameObject.SetActiveOnlyChanged(true);
				//equipmentRare.gameObject.SetActiveOnlyChanged(false);
				foreach (var equipment in equipmentRare)
				{
					equipment.gameObject.SetActive(false);
				}
				break;
			case RarityType.EQUIPMENT:
				// equipmentRare.sprite = ResourceManager.Instance.LoadSpriteSmall("RarityIcon", $"o{rarity}");
				for (int i = 0; i < equipmentRare.Length; i++)
				{
					equipmentRare[i].gameObject.SetActive(i < rarity);
				}
				
				characterRare.gameObject.SetActiveOnlyChanged(false);
				rareBg.gameObject.SetActiveOnlyChanged(false);
				break;
			default:
				break;
		}
	}

	public void ChangeRareImageSize(Vector2 changedSIze)
	{
		var rareRectTransform = (RectTransform)rareBg.gameObject.transform;
		rareRectTransform.sizeDelta = changedSIze;
	}

	private async UniTask LoadSpriteAsync(int rarity)
	{
		characterRare.sprite = await ResourceManager.Instance.LoadSpriteAsync("RarityIcon", $"c{rarity}");
	}
}
