﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.Playables;
using Spine.Unity;
using System.Linq;
using UnityEngine.UI;
public class UICommonEquipmentDialog : UIDialogBase
{
    [SerializeField] Image charaImage;
    [SerializeField] Image[] euqipmentImages;
    [SerializeField] UIButton clickHandler;
    [SerializeField] PlayableDirector playableDirectors = null;
    [SerializeField] UIText nameText;
    //[SerializeField] UIText descText;
    [SerializeField] GameObject[] stars;
    [SerializeField] UIButton jumpButton;
    [SerializeField] Image boardImage;
    [SerializeField] private UIButton euqipmentBtn;
    [SerializeField] Image euqipmentImage;
    private bool isPlaying = false;
    private List<long> equipmentIds = null;
    private List<long> newEquipmentIds = null;
    private int currentIndex = 0;

    private bool isNewEquipment = false;
    public ClickEvent OnCloseClick = new ClickEvent();
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        clickHandler.OnTouchUpInside.GuardSubscribeAsync(OnClickScreen).AddTo(mSubscriptions);
        jumpButton.OnTouchUpInside.GuardSubscribeAsync(OnJumpClick).AddTo(mSubscriptions);
        playableDirectors.stopped += OnTimelineEnd;
        euqipmentBtn.OnTouchUpInside.GuardSubscribeAsync(SetupCharacter).AddTo(mSubscriptions);
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        isPlaying = true;
        currentIndex = 0;
        await SetUpEquipment();
    }

    public async UniTask Setup(List<long> ids)
    {
        equipmentIds = ids;
        newEquipmentIds = DataManager.Instance.Player.Equipment.firstEquipmentIds;
    }

    private void OnTimelineEnd(PlayableDirector director)
    {
        isPlaying = false;
    }

    private async UniTask OnClickScreen()
    {
        if (isPlaying)
        {
            isPlaying = false;
            playableDirectors.time = playableDirectors.duration;
        }
        else
        {
            currentIndex++;
            if (currentIndex >= equipmentIds.Count)
            {
                AsyncManager.Instance.StartAsync(HideAsync());
            }
            else
            {
                await SetUpEquipment();
            }
        }
    }

    private async UniTask OnJumpClick()
    {
        Game.Sound.SoundPlayer.StopBgm();
        AsyncManager.Instance.StartAsync(HideAsync());
    }

    private async UniTask SetUpEquipment()
    {
        var master = DataManager.Instance.Master.Equipment[equipmentIds[currentIndex]];
        if (newEquipmentIds!= null && newEquipmentIds.Count > 0 && newEquipmentIds.Contains(equipmentIds[currentIndex]))
        {
            euqipmentBtn.gameObject.SetActive(true);
            newEquipmentIds.Remove(equipmentIds[currentIndex]);
            euqipmentImage.sprite =  await ResourceManager.Instance.LoadSpriteAsync("Equipment/FullScreenBgs", master.iconId);
        }
        else
        {
            await SetupCharacter();
        }
    }

    private async UniTask SetupCharacter()
    {
        euqipmentBtn.gameObject.SetActive(false);
        var master = DataManager.Instance.Master.Equipment[equipmentIds[currentIndex]];
        await UI.ScreenEffect.Fade(1);

        foreach (var euqipmentImage in euqipmentImages)
        {
            euqipmentImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("Equipment/CardIllusts", master.iconId);
        }
        //new
        AsyncManager.Instance.StartAsync(async () => { await LoadSpriteAsync(master); });
        //boardImage.sprite = ResourceManager.Instance.LoadSpriteSmall("FrameBg", $"frame_equipment_big_{master.rarity}");
        charaImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("Equipment/CardIllustBgs", master.iconId);
        for (int i = 0; i < stars.Length; i++)
        {
            stars[i].SetActive(master.initialRank>=(i+1));
        }
        nameText.SetLabel(LocalizeManager.DATA_TYPE.EQUIPMENT_NAME, master.id.ToString());
        //Game.Sound.SoundPlayer.PlayBgm(resourceMaster.gachaBgm);

        playableDirectors.time = 0;
        playableDirectors.Play();
        isPlaying = true;

        await UI.ScreenEffect.Fade(0);
    }

    public override void OnHide()
    {
        OnCloseClick?.Invoke(this.gameObject);
        base.OnHide();
        Dispose();
    }

    private async UniTask LoadSpriteAsync(EquipmentMaster master)
    {
        boardImage.sprite = await ResourceManager.Instance.LoadSpriteAsync("FrameBg", $"frame_equipment_big_{master.rarity}");
    }
}
