﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NumberMaterialCounter : MonoBehaviour
{
	[SerializeField] List<Material> numberMaterials;
	[SerializeField] List<MeshRenderer> numberRenderers;


	public void SetNumber(int number)
	{
		if (number < 0) number = 0;
		
		for (int i = 0; i < numberRenderers.Count; i++)
		{
			var num = number % 10;
			number /= 10;
			
			numberRenderers[i].material	= numberMaterials[num];
		}
	}
}
