﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Spine.Unity;

public class UIMiniCharacterHolder : MonoBehaviour
{
    [SerializeField] UIButton button = null;


    public long CurrentId {get; private set;}
    public int Direction {get; private set;}
    public int Action {get; private set;}


    public ClickEvent OnClick => button.onClick;


    private SkeletonGraphic character = null;
    private GameObject charaObject = null;


    public void Setup(long id, int dir, int action)
    {
        AsyncManager.Instance.StartAsync(SetupAsync(id, dir, action));
    }

    public void SetEmpty()
    {
        CurrentId = 0;
        Direction = 0;
        Action = 0;
        
        if (charaObject != null)
        {
            Destroy(charaObject);
            charaObject = null;
            character = null;
        }
    }

    public async UniTask SetupAsync(long id, int dir, int action)
    {

        
        Direction = dir;
        Action = action;

        if (id != CurrentId)
        {
            CurrentId = id;
            if (character != null)
            {
                Destroy(character.gameObject);
                character = null;
            }

            if (id == 0) return;


            var newChara = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync($"UICharacter/{id}", transform);
            charaObject = newChara.gameObject;
            character = newChara.GetComponentInChildren<SkeletonGraphic>();

            newChara.transform.localScale = Vector3.one;
            newChara.transform.localPosition = Vector3.zero;
            newChara.transform.localRotation = Quaternion.identity;
            BattleCharacterMaster battleCharacterMaster = DataManager.Instance.Master.BattleCharacter[id];
            CharacterResourceMaster characterResourceMaster = DataManager.Instance.Master.CharacterResource[battleCharacterMaster.characterResourceId];
            character.gameObject.transform.localScale = Vector3.one * characterResourceMaster.uiCharacterScale / 100.0f;
        }

        if (character != null)
        {
            if (character.Skeleton != null)
            {
                character.Skeleton.ScaleX = Direction == 0?1:-1;
            }
            else
            {
                character.initialFlipX = (Direction == 1);
            }

            var data = DataManager.Instance.Master.CharacterAnimation[CurrentId];
            var animName = data.wait;

            switch (action)
            {
                case 0:
                    animName = data.wait;
                    break;
                case 1:
                    animName = data.attack;
                    break;
                default:
                    break;
            }

            
            if (character.AnimationState != null)
            {
                character.AnimationState.SetAnimation(0, animName, true);
            }
            else
            {
                character.startingAnimation = animName;
                character.startingLoop = true;
            }
        }
        
    }

    public void SetDirection(int dir)
    {
        Direction = dir;

        if (character != null)
        {
            character.Skeleton.ScaleX = Direction == 0?1:-1;
        }
    }

    public void SetAction(int action)
    {
        Action = action;

        if (character != null)
        {
            var data = DataManager.Instance.Master.CharacterAnimation[CurrentId];
            switch (action)
            {
                case 0:
                    character.AnimationState.SetAnimation(0, data.wait, true);
                    break;
                case 1:
                    character.AnimationState.SetAnimation(0, data.attack, true);
                    break;
                default:
                    break;
            }
        }
    }
}
