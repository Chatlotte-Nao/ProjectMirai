﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIAdvKeywordGetDialog : UIDialogBase
{
    [SerializeField] UIText keywordText;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }

    public void Setup(int keywordId)
    {
        keywordText.SetLabel(LocalizeManager.DATA_TYPE.KEYWORD, keywordId.ToString());
    }
}
