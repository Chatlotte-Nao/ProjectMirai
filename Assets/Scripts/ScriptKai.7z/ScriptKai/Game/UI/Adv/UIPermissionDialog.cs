using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIPermissionDialog : UIDialogBase
{
    [SerializeField] private List<UIPermissionCell> cells;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        for (int i = 0; i < cells.Count; i++)
        {
            int index = i+1;
            cells[i].OnHelpClick.SubscribeAsync(async (_)=>
            {
                await OnShowHelp(index);
            }).AddTo(mSubscriptions);
            cells[i].OnSetClick.GuardSubscribeAsync(OnSettingClick).AddTo(mSubscriptions);
        }
    }
    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);
        await SetUpAsync();
    }

    private async UniTask SetUpAsync()
    {
        for (int i = 0; i < cells.Count; i++)
        {
            int index = i + 1;
            await cells[i].SetUp(index);
        }
    }

    private async UniTask OnShowHelp(int id)
    {
        UI.Popup.ShowConfirm(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SYSTEM, $"Permission_Name_{id}"), 
            LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.SYSTEM, $"Permission_Content_{id}"),CanvasType.App2);
    }

    private async UniTask OnSettingClick(GameObject o)
    {
        PermissionsState.OpenAppSettings();
    }

    public override void OnHide()
    {
        base.OnHide();
        this.Dispose();
    }
}