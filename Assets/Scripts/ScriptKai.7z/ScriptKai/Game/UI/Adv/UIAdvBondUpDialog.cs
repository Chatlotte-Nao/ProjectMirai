﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using UnityEngine.Playables;
using DG.Tweening;
using System.Linq;

public class UIAdvBondUpDialog : UIDialogBase
{
    [SerializeField] UIButton clickButton;

    [SerializeField] GameObject uiGroup;

    [SerializeField] Image characterIcon;
    [SerializeField] UIText bondAddValueText;
    [SerializeField] UIText bondLevelText;
    [SerializeField] UIText bondTotalValueText;
    [SerializeField] Image bondFillImage;
    [SerializeField] RectTransform bondFillEffect;
    [SerializeField] UIText levelText;

    [SerializeField] PlayableDirector[] playableDirectors = null;

    //
    [SerializeField] UITexture yuanding;
    [SerializeField] Slider slider;
    [SerializeField] UIText newBondTotalValueText;

    private long characterId_;

    private bool mFinished = false;
    private bool stopped = false;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        clickButton.onClickUp.Subscribe(OnClick).AddTo(mSubscriptions);

    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        PxSoundManager.Instance.PlaySe("feedbackSE_player_level01");
        await base.ShowAsync(showType);
        await BarRoutine(startNum_, afterNum_, beforeLevel_, afterLevel_);
        
    }

    private void OnClick(Vector2 p)
    {
        mFinished = true;
    }

    public override void Dispose()
    {
        base.Dispose();
    }

    public async UniTask GaugeUpRoutine(long characterId, int addValue)
    {
        characterId_ = characterId;
        //set icon
		float normalize = Mathf.Abs(addValue);

        // characterIcon.sprite = Resources.Load<Sprite>("Adventure/LogCharas/"+DataManager.Instance.Master.CharacterResource[DataManager.Instance.Master.BattleCharacter[characterId].characterResourceId].bondIcon);

		var result = addValue;
        bondAddValueText.SetFormat(LocalizeManager.DATA_TYPE.BOND, "AddFormat", addValue);

        var maxBondLevel = DataManager.Instance.Master.BondsLvUp.Values.Max(a => a.lv);
        var maxexp = DataManager.Instance.Master.BondsLvUp[maxBondLevel].exp;

        if (result > 0)
        {
            Adventure.Util.SoundExpansion.PlaySe(SoundConstants.SE_ADV_04);

            // int index = 0;
            // float startTime = Time.time;
            int afterLevel = DataManager.Instance.Player.Bond.GetLevel(characterId);
            long afterValue = DataManager.Instance.Player.Bond.TryGet(characterId);
            long beforeValue = afterValue-addValue;
            int beforeLevel = CharacterUtil.CalculateBondLevel(beforeValue);

            Debug.Log("beforelevel：" + beforeLevel);
            Debug.Log("afterLevel：" + afterLevel);
            Debug.Log("beforeValue：" + beforeValue);


            // switch (beforeLevel)
            // {
            //     case 3:
            //     case 4:
            //         index = 1;
            //         break;
            //     case 5:
            //     case 6:
            //         index = 2;
            //         break;
            //     default:
            //         break;
            // }
            // var playableDirector = playableDirectors[index];
            // playableDirector.gameObject.SetActive(true);
            // playableDirector.stopped += OnPlayableDirectorStopped;
            // bondLevelText.SetFormat(LocalizeManager.DATA_TYPE.BOND, "LvFormat", beforeLevel, LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.BOND, beforeLevel.ToString()));
            bondLevelText.SetLabel(LocalizeManager.DATA_TYPE.BOND, beforeLevel.ToString());
            await yuanding.LoadAsync("Bond", beforeLevel.ToString(), false);
            levelText.SetFormat(LocalizeManager.DATA_TYPE.BOND, "LvFormat", beforeLevel);
            

           
            long startNum = beforeValue;
            for (int i = 0; i < Mathf.Min(beforeLevel, maxBondLevel - 1); i++)
            {

                startNum -= DataManager.Instance.Master.BondsLvUp[i+1].exp;
            }

            startNum = (long)Mathf.Clamp(startNum, 0, maxexp);

            long afterNum = afterValue;
            for (int i = 0; i < Mathf.Min(afterLevel, maxBondLevel - 1); i++)
            {
                afterNum -= DataManager.Instance.Master.BondsLvUp[i+1].exp;
            }
            afterNum = (long)Mathf.Clamp(afterNum, 0, maxexp);

            SetBar(beforeLevel, startNum);

            //yield return new WaitForSeconds(1f);
            // while (!mFinished) yield return null;
            startNum_ = startNum;
            afterNum_ = afterNum;
            beforeLevel_ = beforeLevel;
            afterLevel_ = afterLevel;
        }
        await UniTask.Yield();
        uiGroup.SetActive(true);
    }

    private long startNum_;
    private long afterNum_;
    private int beforeLevel_;
    private int afterLevel_;
    async UniTask BarRoutine(long startNumber, long afterNumber, int startLevel, int afterLevel)
    {
        long nowNumber = startNumber;
        float startTime = Time.time;
        float effectTime = 1f;
        int currentLevel = startLevel;
        SetBar(currentLevel, nowNumber);
        while (currentLevel <= afterLevel)
        {
            // bondLevelText.SetFormat(LocalizeManager.DATA_TYPE.BOND, "LvFormat", currentLevel, LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.BOND, currentLevel.ToString()));
            bondLevelText.SetLabel(LocalizeManager.DATA_TYPE.BOND, currentLevel.ToString());
            await yuanding.LoadAsync("Bond", currentLevel.ToString(), false);
            levelText.SetFormat(LocalizeManager.DATA_TYPE.BOND, "LvFormat", currentLevel);
            //do fill
            long finishNumber = 0;
            if (currentLevel == afterLevel)
            {
                finishNumber = afterNumber;
            }
            else
            {
                finishNumber = (long)DataManager.Instance.Master.BondsLvUp[currentLevel+1].exp;
            }
            
            float barStartTime = Time.time;
            while (nowNumber < finishNumber)
            {
                nowNumber = (long)Mathf.Lerp(startNumber, finishNumber, (Time.time-barStartTime)/effectTime);
                SetBar(currentLevel, nowNumber);
                await UniTask.Yield();
            }
            currentLevel++;
            nowNumber = 0;
            startNumber = 0;
            await UniTask.Yield();
        }
        if(afterLevel > startLevel)
           await OpenSignContract(startLevel,afterLevel);
    }

    void SetBar(int level, long val)
    {
        if (DataManager.Instance.Master.BondsLvUp.TryGetValue(level+1, out var nextLevelMaster))
        {
            bondFillImage.fillAmount = (float)val/nextLevelMaster.exp;
            bondTotalValueText.SetRawText($"{val}/{nextLevelMaster.exp}");
            newBondTotalValueText.SetRawText($"{val}/{nextLevelMaster.exp}");
            slider.value = (float)val / nextLevelMaster.exp;
        }
        else
        {
            var exp = DataManager.Instance.Master.BondsLvUp[level].exp;
            bondFillImage.fillAmount = 0f;
            bondTotalValueText.SetRawText($"{val}/{exp}");
            newBondTotalValueText.SetRawText($"{val}/{exp}");
            slider.value = (float)val / DataManager.Instance.Master.BondsLvUp[level].exp;
        }
        bondFillEffect.anchoredPosition = new Vector2(0,-53+110*bondFillImage.fillAmount);
    }

    protected void OnPlayableDirectorStopped(PlayableDirector aDirector)
    {
        stopped = true;
    }

    private async UniTask OpenSignContract(int oldLevel,int newLevel)
    {
        var mSignContract = await UI.Dialog.CreateAsync(UIPrefabId.UIHomeCharacterUnitSignContract, CanvasType.App1) as UIHomeCharacterUnitSignContract;
        await mSignContract.SetUpLevelUpAsync(characterId_,oldLevel,newLevel);
        await mSignContract.ShowAsync();
        await UniTask.WaitUntil(()=>mSignContract == null);
    }
}
