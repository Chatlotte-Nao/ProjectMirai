using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.UI;

public class UIPermissionCell : MonoBehaviour
{
    [SerializeField] private UIButton gotoSetBtn;
    [SerializeField] private UIButton helpBtn;
    [SerializeField] private UIText name;
    [SerializeField] private Image iconImg;
    public ClickEvent OnHelpClick => helpBtn.onClick;
    public ClickEvent OnSetClick => gotoSetBtn.onClick;
    public async UniTask SetUp(int id)
    {
        name.SetLabel(LocalizeManager.DATA_TYPE.SYSTEM,$"Permission_Name_{id}");
    }
}
