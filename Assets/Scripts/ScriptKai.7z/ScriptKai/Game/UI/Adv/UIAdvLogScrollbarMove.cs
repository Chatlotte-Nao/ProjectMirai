using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIAdvLogScrollbarMove : MonoBehaviour
{
    float startPos;
    [SerializeField] RectTransform moveView;
    [SerializeField] [Range(0, 1)] float moveTime = 0.5f;
    //private void OnMouseDown()
    //{
    //    startPos = Input.mousePosition.y;
    //}
    //private void OnMouseDrag()
    //{
    //    moveView.DOAnchorPos3DY(moveView.anchoredPosition3D.y + Input.mousePosition.y - startPos, moveTime).SetEase(Ease.OutCirc);
    //}
    //private void OnMouseExit()
    //{
    //    var distance = moveView.childCount *
    //}
}
