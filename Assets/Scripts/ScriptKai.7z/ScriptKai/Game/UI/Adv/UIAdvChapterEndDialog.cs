﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIAdvChapterEndDialog : UIDialogBase
{
    [SerializeField] UIText[] titleText;

    public void SetupChapterEnd(string chapterTitle)
    {
        foreach (var item in titleText)
        {
            item.SetRawText(chapterTitle);
        }
    }
}
