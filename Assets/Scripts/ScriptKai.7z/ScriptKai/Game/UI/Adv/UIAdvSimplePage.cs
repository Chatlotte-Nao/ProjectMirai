﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIAdvSimplePage : UIPageBase
{
    private UIAdvMessageDialog mMainWindow = null;

    private Adventure.CommandManager commandManager = null;
    public override async UniTask InitializeAsync(object param = null)
    {
        await base.InitializeAsync(param);

        var c = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/CommandManager");
        commandManager = c.GetComponent<Adventure.CommandManager>();

        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvMessageDialog, CanvasType.App0) as UIAdvMessageDialog;


    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
        await mMainWindow.ShowAsync(showType);

    }

    public override void Dispose()
    {
        base.Dispose();
        
        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }

        GameObject.DestroyImmediate(commandManager.gameObject);
        if (Game.ScriptEngine.ScriptEngine.GetInstance().commandManager != null)
            Game.ScriptEngine.ScriptEngine.GetInstance().commandManager = null;
    }
}
