﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Adventure.Controller;

public class UIAdvRequestOrderDialog : UIDialogBase
{
    [SerializeField] RequestQuestController requestQuestController;

    [SerializeField] UIText titleText;
    [SerializeField] UIText descText;
    [SerializeField] UIText targetText;

    [SerializeField] BaseItem itemPrefab;
    [SerializeField] RectTransform itemTransformParent;


    private long mEventMasterId = 0;
    


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        if (Game.ScriptEngine.ScriptEngine.GetInstance().commandManager != null)
        {
            Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.RequestQuestController = requestQuestController;
        }
        
        requestQuestController.OnAccept.GuardSubscribeAsync(OnAccept).AddTo(mSubscriptions);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (Game.ScriptEngine.ScriptEngine.GetInstance().commandManager != null)
        {
            Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.RequestQuestController = null;
        }
    }


    public void Setup(int requestEventId)
    {
        mEventMasterId = requestEventId;

        titleText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{requestEventId}_title");
        descText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{requestEventId}_desc");
        targetText.SetLabel(LocalizeManager.DATA_TYPE.REQUEST, $"{requestEventId}_target");
    }

    private async UniTask OnAccept()
    {
        var ev = DataManager.Instance.Player.Explore.GetEvent(mEventMasterId);
        if (ev != null)
        {
            await ExploreService.StartEvent(ev.ExploreEventMasterId);
            SignalBus.GlobalSignal.Dispatch<long>(UIEventId.ExploreEventStart, ev.ExploreEventMasterId);
        }
        
    }
}
