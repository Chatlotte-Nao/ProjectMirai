﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Adventure.Controller;

public class UIAdvPrivateTalkDialog : UIDialogBase
{
    [SerializeField] PrivateTalkController privateTalkController;
    [SerializeField] PrivateSelectController privateSelectController;

    
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();


        await privateTalkController.Init(Game.ScriptEngine.ScriptEngine.GetInstance().commandManager);
        await privateSelectController.Init(Game.ScriptEngine.ScriptEngine.GetInstance().commandManager);
        
    }
}
