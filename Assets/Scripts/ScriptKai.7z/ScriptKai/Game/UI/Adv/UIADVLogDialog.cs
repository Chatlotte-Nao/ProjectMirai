using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using UnityEngine.UI;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using TMPro;
using UnityEngine.Events;
using System;

public class UIADVLogDialog : UIDialogBase
{
    [SerializeField] List<RectTransform> usingObj = new List<RectTransform>();
    [SerializeField] RectTransform objParent;
    [SerializeField] [Range(0, 200)] float intervalDistance = 50;
    public UIButton image;
    [SerializeField] GameObject mainText;
    [SerializeField] RectTransform arrows;
    public ClickEvent OnClose2 => image.onClick;

    [SerializeField] UIText testText;
    float startPos;
    [SerializeField] RectTransform moveView;
    [SerializeField] [Range(0, 1)] float moveTime = 0.5f;
    private void OnEnable()
    {
        moveView.anchoredPosition3D = new Vector3(0, 50, 0);
    }
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        gameObject.SetActive(false);
        mainText.SetActive(false);

        OnClose2.RemoveAllListeners();
        OnClose2.AddListener(CloseCloick);
    }
    private void CloseCloick(object o)
    {
        gameObject.SetActive(false);
        closeClick.Invoke();
    }
    [SerializeField] Func<UniTask> closeClick;
    public async UniTask Init(GameObject gb,Func<UniTask> func)
    {
        Time.timeScale = 1;
        closeClick = func;
        OnClose2.GuardSubscribeAsync(async (o) => gb.SetActive(true));
    }
    public void SetUp(string name, string take)
    {
        var str = testText.gameObject.GetComponent<TextMeshProUGUI>().text + "\n\n" + name + ": " + take;

        testText.SetRawText(str);
        for (int i = usingObj.Count - 1; i >= 0; i--)
        {
            usingObj[i].anchoredPosition3D += new Vector3(0, intervalDistance, 0);
        }

        var temp = Instantiate(mainText, objParent);
        var cs = temp.GetComponent<UIAdvLogDialogTextParticulars>();
        cs.SetUp(name+":", take);
        temp.SetActive(true);
        usingObj.Add(temp.gameObject.GetComponent<RectTransform>());

        //var posi = cs.take.GetComponent<RectTransform>().anchoredPosition3D;
        //arrows.anchoredPosition3D = new Vector3(posi.x - 80, posi.y - 30, 0);
    }



    private void OnMouseDown()
    {
        startPos = Input.mousePosition.y;
    }
    private void OnMouseDrag()
    {
        var pos = moveView.anchoredPosition3D.y + (Input.mousePosition.y - startPos);
        if (pos <= 50 && pos >= -moveView.childCount * intervalDistance + 200)
        {
            moveView.DOAnchorPos3DY(pos, moveTime).SetEase(Ease.OutCirc).OnStart(()=>
            {
                startPos = Input.mousePosition.y;
            });
        }
    }
}
