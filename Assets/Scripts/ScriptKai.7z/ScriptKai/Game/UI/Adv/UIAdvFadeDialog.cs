﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIAdvFadeDialog : UIDialogBase
{
    [SerializeField] Adventure.Controller.FadeController fadeController;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.BaseFadeController = fadeController;
    }

    public override void Dispose()
    {
        base.Dispose();

        Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.BaseFadeController = null;
    }
}
