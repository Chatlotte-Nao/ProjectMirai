﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using UnityEngine.UI;
using Adventure.UI;
using Base.Sound;
using Game.Sound;

public class UIAdvConfigDialog : UIDialogBase
{
    [SerializeField]
    private Slider bgmSlider = null;
    [SerializeField]
    private Slider seSlider = null;
    [SerializeField]
    private Slider voiceSlider = null;
    [SerializeField]
    private Slider textSpeedSlider = null;
    // [SerializeField]
    // private TMPro.TMP_Dropdown voiceTypeSelect = null;
    [SerializeField]
    
    private RubyTextScroll rubyTextScroll = null;
    [SerializeField]
    private float[] textSpeeds = null;
    [SerializeField]
    private UIButton okButton;
    [SerializeField]
    private UIButton resetButton;
    
    [SerializeField]
    private Toggle voiceToggleChinese;
    [SerializeField]
    private Toggle voiceToggleJapanese;
    [SerializeField]
    private UIButton privacyAgreementButton;
    [SerializeField]
    private UIButton userAgreementButton;
    [SerializeField]
    private UIButton authorityWithdrawalButton;

    [SerializeField] private UIButton close;
    private string defaultSeName = "se_select";
    
    private string defaultVoiceName = "musicart_01_title_001";
    
    
    

    
    
    private float elapsedSeconds = 0.0f;
    private bool textMoving = false;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        bgmSlider.onValueChanged.Subscribe(OnValueChangedBgm).AddTo(mSubscriptions);
        seSlider.onValueChanged.Subscribe(OnValueChangedSe).AddTo(mSubscriptions);
        voiceSlider.onValueChanged.Subscribe(OnValueChangedVoice).AddTo(mSubscriptions);
        textSpeedSlider.onValueChanged.Subscribe(OnValueChangeMessageSpeed).AddTo(mSubscriptions);
        if (DataManager.Instance.Local.Config.voiceType==1)
        {
            voiceToggleChinese.isOn = true;
        }
        else
        {
            voiceToggleJapanese.isOn = true;
        }

        close.onClick.GuardSubscribeAsync(CloseClick).AddTo(mSubscriptions);
        
        
        // voiceTypeSelect.onValueChanged.Subscribe(OnVoiceTypeChange).AddTo(mSubscriptions);

#if BUILD_DEBUG || UNITY_EDITOR
        // voiceTypeSelect.gameObject.SetActive(true);
#endif
        
        okButton.OnTouchUpInside.Subscribe(OnClickOk).AddTo(mSubscriptions);
        resetButton.OnTouchUpInside.Subscribe(OnClickReset).AddTo(mSubscriptions);

        privacyAgreementButton.OnTouchUpInside.GuardSubscribeAsync(OnShowPrivacyAgreement).AddTo(mSubscriptions);
        userAgreementButton.OnTouchUpInside.GuardSubscribeAsync(OnShowUserAgreement).AddTo(mSubscriptions);
        authorityWithdrawalButton.OnTouchUpInside.GuardSubscribeAsync(OnShowAuthorityWithdrawal).AddTo(mSubscriptions);
        // voiceToggleChinese.onValueChanged.Subscribe((isOn)=>{if (isOn) OnSelectTab.Invoke(4);}).AddTo(mSubscriptions);
        
    }

    public override async UniTask ShowAsync(UIPageShowType showType = UIPageShowType.Front)
    {
        await base.ShowAsync(showType);

        OnClickReset();

    }

    public async UniTask CloseClick(GameObject o)
    {
        OnClickReset();
        await HideAsync();
    }

    private void OnValueChangedBgm(float val)
    {
        Base.Sound.SoundManager.GetInstance().SetBgmMasterVolume(bgmSlider.value / bgmSlider.maxValue);
    }

    private void OnValueChangedSe(float val)
    {
        Base.Sound.SoundManager.GetInstance().SetSeMasterVolume(seSlider.value / seSlider.maxValue);
        SoundPlayer.PlaySe(defaultSeName);
    }

    private void OnValueChangedVoice(float val)
    {
        Base.Sound.SoundManager.GetInstance().SetVoiceMasterVolume(voiceSlider.value / voiceSlider.maxValue);
        if (!SoundPlayer.IsPlayingVoice())
        {
            SoundPlayer.PlayVoice(defaultVoiceName);
        }
    }

    private void OnValueChangeMessageSpeed(float val)
    {
        rubyTextScroll.TextSpeed = textSpeeds[(int)textSpeedSlider.value];
    }

    private void OnVoiceTypeChange(int id)
    {
        if (id != DataManager.Instance.Local.Config.voiceType)
        {
            
        }
    }

    private void OnClickReset()
    {
        bgmSlider.value = (DataManager.Instance.Local.Config.bgmVolume * bgmSlider.maxValue);
        seSlider.value = (DataManager.Instance.Local.Config.seVolume * seSlider.maxValue);
        voiceSlider.value = (DataManager.Instance.Local.Config.voiceVolume * voiceSlider.maxValue);
        textSpeedSlider.value = (DataManager.Instance.Local.Config.textSpeed);
        // voiceTypeSelect.value = (DataManager.Instance.Local.Config.voiceType);
        if (DataManager.Instance.Local.Config.voiceType==1)
        {
            voiceToggleChinese.isOn = true;
        }
        else
        {
            voiceToggleJapanese.isOn = true;
        }

    }

    private void OnClickOk()
    {
        DataManager.Instance.Local.Config.bgmVolume = bgmSlider.value / bgmSlider.maxValue;
        DataManager.Instance.Local.Config.seVolume = seSlider.value / seSlider.maxValue;
        DataManager.Instance.Local.Config.voiceVolume = voiceSlider.value / voiceSlider.maxValue;
        DataManager.Instance.Local.Config.textSpeed = (int)textSpeedSlider.value;
        
        
        // DataManager.Instance.Local.Config.voiceType = voiceTypeSelect.value;
        var languageIndex = voiceToggleChinese.isOn ? 1 : 0; 
        if( DataManager.Instance.Local.Config.voiceType != languageIndex)
            UI.Popup.ShowPopMessage(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "Common_Setting_RebootHint"));
        DataManager.Instance.Local.Config.voiceType = languageIndex;

        DataManager.Instance.Local.SaveConfig();
        


        // if (voiceTypeSelect.value != DataManager.Instance.Local.Config.voiceType)
        // {
        //     AsyncManager.Instance.StartAsync(PxSoundManager.Instance.LoadCueSheets());
        // }
       
        Hide();
    }

    private async UniTask OnShowPrivacyAgreement()
    {
        await LCXHandler.Instance.ShowPrivacyAgreement();
    }
    private async UniTask OnShowUserAgreement()
    {
        await LCXHandler.Instance.ShowUserAgreement();
    }
    private async UniTask OnShowAuthorityWithdrawal()
    {
        //await UI.Popup.ShowPopupMessageAsync("暂未开放此功能");
        var permissionDialog = await UI.Dialog.CreateAsync(UIPrefabId.UIPermissionDialog, CanvasType.App2) as UIPermissionDialog;
        await permissionDialog.ShowAsync();
    }
// private void Update()
    // {
    //     if (textMoving)
    //     {
    //         rubyTextScroll.Move();
    //         if (!rubyTextScroll.enabled)
    //         {
    //             elapsedSeconds = Time.unscaledTime;
    //             textMoving = false;
    //         }
    //     }
    //     else
    //     {
    //         if (Time.unscaledTime - elapsedSeconds >= 0.5f)
    //         {
    //             rubyTextScroll.Init();
    //             textMoving = true;
    //         }
    //     }
    // }
}
