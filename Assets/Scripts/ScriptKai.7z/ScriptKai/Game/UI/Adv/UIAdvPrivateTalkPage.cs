﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIAdvPrivateTalkPage : UIPageBase
{
    private UIAdvMessageDialog mMainWindow = null;
    private UIAdvBackgroundDialog mBg = null;
    private UIAdvEmotionalTunerDialog mEmotionalTuner = null;
    private UIAdvFadeDialog mFade = null;
    private UIAdvPrivateTalkDialog mPrivateTalk = null;
    private UIAdvPrivateTalkResultDialog mPrivateTalkResult = null;
    private UIAdvConfigDialog mConfig = null;
    private UIADVLogDialog mLogDiaLog;

    private Adventure.CommandManager commandManager = null;

    public override async UniTask InitializeAsync(object param = null)
    {
        //Debug.Log($"UIAdvPrivateTalkPage   1111");
        await base.InitializeAsync(param);
        //Debug.Log($"UIAdvPrivateTalkPage   2222");
        var c = await ResourceManager.Instance.LoadPrefabAndInstantiateAsync("Misc/CommandManager");
        commandManager = c.GetComponent<Adventure.CommandManager>();

        mMainWindow = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvMessageDialog, CanvasType.App0) as UIAdvMessageDialog;
        mBg = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvBackgroundDialog, CanvasType.BG) as UIAdvBackgroundDialog;
        mEmotionalTuner = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvEmotionalTunerDialog, CanvasType.App0) as UIAdvEmotionalTunerDialog;
        mFade = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvFadeDialog, CanvasType.App1) as UIAdvFadeDialog;
        mPrivateTalk = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvPrivateTalkDialog, CanvasType.App0) as UIAdvPrivateTalkDialog;
        mPrivateTalkResult = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvPrivateTalkResultDialog, CanvasType.App0) as UIAdvPrivateTalkResultDialog;
        mConfig = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvConfigDialog, CanvasType.App2) as UIAdvConfigDialog;
        //mLogDiaLog = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvLogDialog, CanvasType.App2) as UIADVLogDialog;

        //Debug.Log($"UIAdvPrivateTalkPage   3333");
        //await mLogDiaLog.InitializeAsync();
        //await mMainWindow.InitLogDialog(mLogDiaLog);
        mMainWindow.OnClickConfig.GuardSubscribeAsync(OnClickConfig).AddTo(mSubscriptions);

    }

    public override async UniTask ShowAsync(UIPageShowType showType)
    {
        await base.ShowAsync(showType);
        await mBg.ShowAsync(showType);
        
        await mFade.ShowAsync(showType);
        await mPrivateTalk.ShowAsync(showType);

    }
    private async UniTask OnClickConfig()
    {
        await mConfig.ShowAsync();
    }

    public override void Dispose()
    {
        base.Dispose();

        if (mMainWindow != null)
        {
            mMainWindow.Dispose();
            mMainWindow = null;
        }
        if (mBg != null)
        {
            mBg.Dispose();
            mBg = null;
        }
        if (mEmotionalTuner != null)
        {
            mEmotionalTuner.Dispose();
            mEmotionalTuner = null;
        }
        if (mPrivateTalk != null)
        {
            mPrivateTalk.Dispose();
            mPrivateTalk = null;
        }
        if (mFade != null)
        {
            mFade.Dispose();
            mFade = null;
        }
        if (mPrivateTalkResult != null)
        {
            mPrivateTalkResult.Dispose();
            mPrivateTalkResult = null;
        }
        if (mConfig != null)
        {
            mConfig.Dispose();
            mConfig = null;
        }
        if (mLogDiaLog != null)
        {
            mLogDiaLog.Dispose();
            mLogDiaLog = null;
        }

        
        GameObject.DestroyImmediate(commandManager.gameObject);
        if (Game.ScriptEngine.ScriptEngine.GetInstance().commandManager != null)
            Game.ScriptEngine.ScriptEngine.GetInstance().commandManager = null;
    }
}
