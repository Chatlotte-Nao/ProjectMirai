﻿using System;
using System.Collections;
using System.Collections.Generic;
using CriMana;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIAdvMovieDialog : UIDialogBase
{
    [SerializeField] private UIButton activeButton;

    [SerializeField] private UIButton jumpButton;

    //[SerializeField] private GameObject bg;
    private CriManaMovieControllerForUI criManaMovieControllerForUI;


    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        activeButton.onClick.SubscribeAsync(SetActiveJumpBtn).AddTo(mSubscriptions);
        jumpButton.onClick.Subscribe(OnJumpClick).AddTo(mSubscriptions);
        Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.CriManaMovieControllerForUI =
            GetComponent<CriManaMovieControllerForUI>();
        criManaMovieControllerForUI = GetComponent<CriManaMovieControllerForUI>();

        if (!DebugState.canSpeedStory)
        {
            jumpButton.gameObject.SetActive(false);
        }
    }

    // private void Update()
    // {
    //     if(bg.activeSelf != criManaMovieControllerForUI.target.gameObject.activeSelf)
    //         bg.SetActive(criManaMovieControllerForUI.target.gameObject.activeSelf);
    // }

    private async UniTask SetActiveJumpBtn(GameObject o)
    {
        if (!DebugState.canSpeedStory)
        {
            return;
        }
#if !UWA
        activeButton.gameObject.SetActive(false);
        jumpButton.gameObject.SetActive(true);
        var player = criManaMovieControllerForUI.player;
        await UniTask.WaitUntil(() => (player.status == Player.Status.PlayEnd || player.status == Player.Status.Stop));
        if(jumpButton!=null)
            jumpButton.gameObject.SetActive(false);
        //bg.SetActive(false);
#endif
    }

    void OnJumpClick(GameObject o)
    {
        var str = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.COMMON, "Common_Jump_AdvMovie");
        UI.Popup.ShowConfirm(string.Empty, str, CanvasType.App2, (r) =>
        {
            if (r == UIPopupDialog.Result.OK)
            {
                var controller = Game.ScriptEngine.ScriptEngine.GetInstance().commandManager
                    .CriManaMovieControllerForUI;
                controller.player.Stop();
                controller.target.gameObject.SetActive(false);
                jumpButton.gameObject.SetActive(false);
            }
        });
    }

    public override void Dispose()
    {
        base.Dispose();
        Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.CriManaMovieControllerForUI = null;
    }
}