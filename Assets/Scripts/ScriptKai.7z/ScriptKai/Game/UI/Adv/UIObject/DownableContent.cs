﻿using UnityEngine;
using UnityEngine.EventSystems;

namespace Adventure.UI
{
    /// <summary>
    /// ポインタダウン可能なコンテンツ
    /// </summary>
    public class DownableContent : MonoBehaviour, IPointerDownHandler
    {
        /// <summary>
        /// 押された時に呼び出されます
        /// </summary>
        /// <param name="eventData">現在のイベントデータ</param>
        public void OnPointerDown(PointerEventData eventData)
        {
        }
    }
}
