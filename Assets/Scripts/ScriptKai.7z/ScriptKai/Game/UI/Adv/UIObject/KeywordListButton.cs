﻿using Adventure.Controller;
using UnityEngine;
using UnityEngine.UI;

namespace Adventure.UI
{
    /// <summary>
    /// キーワード一覧ボタン
    /// </summary>
    public class KeywordListButton : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("ボタン")]
        private Button button = null;
        [SerializeField]
        [Tooltip("バックボタン")]
        private BackButton backButton = null;

        /// <summary>
        /// セットアップ
        /// </summary>
        /// <param name="fadeController">フェード制御</param>
        public void Setup(FadeController fadeController)
        {

           // KeywordListScene keywordListScene = KeywordListScene.GetInstance();
            //if (keywordListScene == null)
            //{
            //    return;
            //}
       
            //keywordListScene.HideAction = () =>
            //{
            //    fadeController.gameObject.SetActive(true);
            //    fadeController.Copy(keywordListScene.FadeController);
            //};

           // keywordListScene.FadeController.Copy(fadeController);
            fadeController.gameObject.SetActive(false);

            button.gameObject.SetActive(true);
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(() =>
            {
                //if (keywordListScene != null)
                //{
                //    bool backButtonActive = backButton.gameObject.activeSelf;
                //    keywordListScene.Show(() =>
                //    {
                //        backButton.gameObject.SetActive(backButtonActive);
                //    }, () =>
                //    {
                //        backButton.ClickAction?.Invoke();
                //    }, backButton.gameObject.activeInHierarchy);
                //    backButton.gameObject.SetActive(false);
                //}
            });
        }

        private void OnDestroy()
        {
            //BaseSystem.StartCoroutine(KeywordListScene.RemoveScene());
        }
    }
}
