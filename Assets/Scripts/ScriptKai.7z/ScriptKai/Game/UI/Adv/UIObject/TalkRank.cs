﻿using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using Game.Ui;

namespace Adventure.UI
{
    /// <summary>
    /// 会話ランク
    /// </summary>
    public class TalkRank : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("バー画像")]
        private Image barImage = null;
        [SerializeField]
        [Tooltip("バーアニメーター")]
        private Animator barAnimator = null;
        [SerializeField]
        [Tooltip("ランクアニメーター")]
        private Animator rankAnimator = null;
        [SerializeField]
        [Tooltip("レベルアップアニメーター")]
        private Animator[] levelUpAnimators = null;
        [SerializeField]
        [Tooltip("レベルアップの色")]
        private Color[] levelUpColors = null;
        [SerializeField]
        [Tooltip("レベルテキスト")]
        private TMP_Text levelText = null;
        [SerializeField]
        [Tooltip("バー状態名")]
        private string[] barStateNames = new string[] { "TalkRankBarAhead", "TalkRankBarAhead2" };
        [SerializeField]
        [Tooltip("ランクアップ状態名")]
        private string rankUpStateName = "TalkRankUpAhead";
        [SerializeField]
        [Tooltip("ランク1段階アップ状態名")]
        private string rankUpStepStateName = "TalkRankUpStepAhead";
        [SerializeField]
        [Tooltip("レベルアップ状態名")]
        private string levelUpStateName = "NumAnmOnAwake";
        [SerializeField]
        [Tooltip("レベルアップ開始時間(s)")]
        private float levelUpStartTime = 2.27f;
        [SerializeField]
        [Tooltip("バーの充填量")]
        private float[] barFillAmount = new float[] { 0.0f, 0.068f, 0.13f, 0.205f, 0.28f, 0.355f, 0.435f, 0.52f, 0.61f, 0.7f, 0.795f, 0.9f, 1.0f};
        [SerializeField]
        [Tooltip("レベルタイトル")]
        private string levelTitle = "Lv.";
        [SerializeField]
        [Tooltip("開始のレベルアップ")]
        private int startLevelUp = 2;

        private int talkPoint = 0;
        private float levelStartTime = 0.0f;
        private int talkLevel = 0;
        private StringBuilder stringBuilder = new StringBuilder();

        /// <summary>
        /// セットアップ
        /// </summary>
        public void Setup()
        {
            talkPoint = 0;
            barImage.fillAmount = 0.0f;
            levelStartTime = 0.0f;
            barAnimator.enabled = false;

            levelText.text = LocalizeManager.GetCommonText("STATUS_LV")+"1";
        }

        /// <summary>
        /// 会話ポイント追加
        /// </summary>
        /// <param name="addTalkPoint">追加する会話ポイント</param>
        /// <param name="talkLevel">会話レベル</param>
        /// <param name="isTalkLevelUp">会話レベルアップであるか</param>
        public void AddTalkPoint(int addTalkPoint, int talkLevel, bool isTalkLevelUp)
        {
            this.talkLevel = talkLevel;

            talkPoint += addTalkPoint;

            if (isTalkLevelUp)
            {
                rankAnimator.Play(rankUpStepStateName, 0, 0.0f);
                if ((startLevelUp <= talkLevel) && (talkLevel < (levelUpAnimators.Length + startLevelUp)))
                {
                    levelUpAnimators[talkLevel - startLevelUp].Play(levelUpStateName, 0, 0.0f);
                    levelStartTime = Time.time;
                }
            }
            else
            {
                rankAnimator.Play(rankUpStateName, 0, 0.0f);
            }
            PlayBarAnimation(barAnimator, talkPoint, addTalkPoint, barStateNames);
        }

        /// <summary>
        /// バーアニメーション再生
        /// </summary>
        /// <param name="animator">アニメーター</param>
        /// <param name="maxPoint">最大ポイント</param>
        /// <param name="point">ポイント</param>
        /// <param name="stateNames">状態名</param>
        protected void PlayBarAnimation(Animator animator, int maxPoint, int point, string[] stateNames)
        {
            if ((point <= 0) || (stateNames.Length < point) || (barFillAmount.Length <= maxPoint))
            {
                return;
            }
            animator.Play(stateNames[point - 1], 0, 0.0f);
            animator.enabled = true;
        }

        /// <summary>
        /// バーアニメーション後の更新
        /// </summary>
        /// <param name="animator">アニメーター</param>
        /// <param name="image">画像</param>
        /// <param name="point">ポイント</param>
        /// <param name="stateNames">状態名</param>
        protected void LateUpdateBarAnimation(Animator animator, Image image, int point, string[] stateNames)
        {
            if (!animator.enabled)
            {
                return;
            }
            AnimatorStateInfo animatorStateInfo = animator.GetCurrentAnimatorStateInfo(0);
            for (int i = 0; i < stateNames.Length; i++)
            {
                if (animatorStateInfo.IsName(stateNames[i]))
                {
                    float normalizedTime = Mathf.Min(animatorStateInfo.normalizedTime, 1.0f);
                    float rate = image.fillAmount * normalizedTime / barFillAmount[i + 1];

                    int targetIndex = Mathf.Max(point, 0);
                    int baseIndex = Mathf.Max(targetIndex - (i + 1), 0);
                    image.fillAmount = (barFillAmount[targetIndex] - barFillAmount[baseIndex]) * rate + barFillAmount[baseIndex];
                    if (animatorStateInfo.normalizedTime >= 1.0f)
                    {
                        animator.enabled = false;
                    }
                    break;
                }
            }
        }

        private void Update()
        {
            if ((levelStartTime > 0.0f) && ((Time.time - levelStartTime) >= levelUpStartTime))
            {
                stringBuilder.Clear();
                stringBuilder.Append(LocalizeManager.GetCommonText("STATUS_LV"));
                stringBuilder.Append(talkLevel);
                levelText.text = stringBuilder.ToString();

                if ((startLevelUp <= talkLevel) && (talkLevel < levelUpColors.Length + startLevelUp))
                {
                    levelText.color = levelUpColors[talkLevel - startLevelUp];
                }
                levelStartTime = 0.0f;
            }
        }

        private void LateUpdate()
        {
            LateUpdateBarAnimation(barAnimator, barImage, talkPoint, barStateNames);
        }
    }
}
