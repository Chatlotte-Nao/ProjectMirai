﻿using UnityEngine;
using UnityEngine.UI;
using Adventure.Util;

namespace Adventure.UI
{
    /// <summary>
    /// 時計
    /// </summary>
    public class Clock : MonoBehaviour
    {
        /// <summary>
        /// 状態
        /// </summary>
        public enum State
        {
            /// <summary>
            /// 待ち
            /// </summary>
            Wait,
            /// <summary>
            /// 下がってる
            /// </summary>
            Back,
            /// <summary>
            /// 右
            /// </summary>
            Right,
            /// <summary>
            /// 左
            /// </summary>
            Left
        };
        [SerializeField]
        [Tooltip("分バー")]
        private Image minuteBar = null;
        [SerializeField]
        [Tooltip("時バー")]
        private Image hourBar = null;
        [SerializeField]
        [Tooltip("分針")]
        private Transform minuteHand = null;
        [SerializeField]
        [Tooltip("時針")]
        private Transform hourHand = null;
        [SerializeField]
        [Tooltip("分針アニメーター")]
        private Animator minuteHandAnimator = null;
        [SerializeField]
        [Tooltip("時針アニメーター")]
        private Animator hourHandAnimator = null;
        [SerializeField]
        [Tooltip("加算分アニメーター")]
        private Animator addMinuteAnimator = null;
        [SerializeField]
        [Tooltip("加算時アニメーター")]
        private Animator addHourAnimator = null;
        [SerializeField]
        [Tooltip("アクティブアニメーター")]
        private Animator activeAnimator = null;
        [SerializeField]
        [Tooltip("パーティクル")]
        private GameObject particle = null;
        [SerializeField]
        [Tooltip("初期分状態名")]
        private string initMinuteStateName = "Needle";
        [SerializeField]
        [Tooltip("初期時状態名")]
        private string initHourStateName = "Needle2";
        [SerializeField]
        [Tooltip("分先状態名")]
        private string aheadMinuteStateName = "NeedleAhead";
        [SerializeField]
        [Tooltip("時先状態名")]
        private string aheadHourStateName = "Needle2Ahead";
        [SerializeField]
        [Tooltip("加算分状態名")]
        private string addMinuteStateName = "ClockAdd";
        [SerializeField]
        [Tooltip("加算時状態名")]
        private string addHourStateName = "ClockAddNeedle2";
        [SerializeField]
        [Tooltip("アクティブ分状態名")]
        private string activeMinuteStateName = "ClockActiveAhead";
        [SerializeField]
        [Tooltip("アクティブ時状態名")]
        private string activeHourStateName = "ClockActiveAheadNeedle2";

        private int minuteHandNumber = 0;
        private int hourHandNumber = 0;
        private int divisionNumber = 0;
        private int addHourHandNumber = 0;
        private float initAngle = 0.0f;
        private State state = State.Wait;

        /// <summary>
        /// 指定設定で時加算アニメが行えるかどうか
        /// </summary>
        /// <param name="minuteHandNumber">分針の数</param>
        /// <param name="hourHandNumber">時針の数</param>
        /// <param name="divisionNumber">分割数</param>
        public bool IsAbleAddHour(int minuteHandNumber, int hourHandNumber, int divisionNumber)
        {
            //渡した設定値が、hourHandNumber今以上、それ以外がSetupと一緒ならば分加算アニメを動かせる
            return (minuteHandNumber == this.minuteHandNumber &&
                divisionNumber == this.divisionNumber &&
                hourHandNumber > this.hourHandNumber);
        }

        /// <summary>
        /// 指定設定で分加算アニメが行えるかどうか
        /// </summary>
        /// <param name="minuteHandNumber">分針の数</param>
        /// <param name="hourHandNumber">時針の数</param>
        /// <param name="divisionNumber">分割数</param>
        public bool IsAbleAddMinute(int minuteHandNumber, int hourHandNumber, int divisionNumber)
        {
            //渡した設定値が、minuteHandNumberが+1、それ以外がSetupと一緒ならば分加算アニメを動かせる
            return (minuteHandNumber == this.minuteHandNumber + 1 &&
                divisionNumber == this.divisionNumber &&
                hourHandNumber == this.hourHandNumber);
        }

        /// <summary>
        /// 指定のセットアップがすでに行われている状態か
        /// </summary>
        /// <param name="minuteHandNumber">分針の数</param>
        /// <param name="hourHandNumber">時針の数</param>
        /// <param name="divisionNumber">分割数</param>
        public bool IsAlreadySetup(int minuteHandNumber, int hourHandNumber, int divisionNumber)
        {
            return (minuteHandNumber == this.minuteHandNumber &&
                divisionNumber == this.divisionNumber &&
                hourHandNumber == this.hourHandNumber);
        }

        /// <summary>
        /// 状態に応じてセットアップや加算アニメを行う
        /// </summary>
        /// <param name="minuteHandNumber">分針の数</param>
        /// <param name="hourHandNumber">時針の数</param>
        /// <param name="divisionNumber">分割数</param>
        /// <param name="isFirstClockAnimation">最初の設定時にアニメーションを行うか</param>
        public bool SetupFunction(int minuteHandNumber, int hourHandNumber, int divisionNumber, bool isFirstClockAnimation)
        {
            var isSetFirstAnimation = false;
            if (IsAbleAddHour(minuteHandNumber, hourHandNumber, divisionNumber))
            {
                var addHour = hourHandNumber - this.hourHandNumber;
                AddHour(addHour);
            }
            else if (IsAbleAddMinute(minuteHandNumber, hourHandNumber, divisionNumber))
            {
                AddMinute();
            }
            else if (!IsAlreadySetup(minuteHandNumber, hourHandNumber, divisionNumber))
            {
                //最初のアニメーションを行うかどうかで処理を変える
                if (isFirstClockAnimation)
                {
                    Setup(minuteHandNumber, 0, divisionNumber);
                    AddHour(hourHandNumber);
                    isSetFirstAnimation = true;
                }
                else
                {
                    Setup(minuteHandNumber, hourHandNumber, divisionNumber);
                }
            }
            return isSetFirstAnimation;
        }

        /// <summary>
        /// セットアップ
        /// </summary>
        /// <param name="minuteHandNumber">分針の数</param>
        /// <param name="hourHandNumber">時針の数</param>
        /// <param name="divisionNumber">分割数</param>
        public void Setup(int minuteHandNumber, int hourHandNumber, int divisionNumber)
        {
            this.minuteHandNumber = minuteHandNumber;
            this.divisionNumber = divisionNumber;
            this.hourHandNumber = hourHandNumber;

            minuteBar.fillAmount = (float)minuteHandNumber / divisionNumber;
            InitHand(minuteHandAnimator, initMinuteStateName);
            SetHand(minuteHand, minuteHandNumber, divisionNumber);

            hourBar.fillAmount = (float)hourHandNumber / divisionNumber;
            InitHand(hourHandAnimator, initHourStateName);
            SetHand(hourHand, hourHandNumber, divisionNumber);
        }

        /// <summary>
        /// 分加算
        /// </summary>
        public void AddMinute()
        {
            SetHand(minuteHand, minuteHandNumber, divisionNumber);
            PlayHand(minuteHandAnimator, addMinuteAnimator, activeAnimator, aheadMinuteStateName, addMinuteStateName, activeMinuteStateName);
            initAngle = Mathf.Repeat(360.0f - minuteHand.transform.localEulerAngles.z, 360.0f);
            minuteHandNumber++;
            state = State.Wait;
        }

        /// <summary>
        /// 時加算
        /// </summary>
        /// <param name="addHourHandNumber">加算する時針の数</param>
        public void AddHour(int addHourHandNumber = 1)
        {
            if (addHourHandNumber <= 0)
            {
                return;
            }

            this.addHourHandNumber = addHourHandNumber;
            SoundExpansion.PlaySe("14_テンションアップ");
            SetHand(hourHand, hourHandNumber, divisionNumber);
            PlayHand(hourHandAnimator, addHourAnimator, activeAnimator, aheadHourStateName, addHourStateName, activeHourStateName);
            initAngle = Mathf.Repeat(360.0f - hourHand.transform.localEulerAngles.z, 360.0f);
            hourHandNumber += addHourHandNumber;
            state = State.Wait;
        }

        /// <summary>
        /// 分針アニメーションしているかの取得
        /// </summary>
        /// <returns>true:アニメーションしている false:アニメーションしてない</returns>
        public bool GetIsAnimation()
        {
            return minuteHandAnimator.enabled || addMinuteAnimator.gameObject.activeSelf || activeAnimator.enabled;
        }

        /// <summary>
        /// 時針アニメーションしているかの取得
        /// </summary>
        /// <returns>true:アニメーションしている false:アニメーションしてない</returns>
        public bool GetIsHourAnimation()
        {
            return hourHandAnimator.enabled || addHourAnimator.gameObject.activeSelf || activeAnimator.enabled;
        }

        /// <summary>
        /// 針初期化
        /// </summary>
        /// <param name="animator">アニメーター</param>
        /// <param name="stateName">状態名</param>
        protected void InitHand(Animator animator, string stateName)
        {
            animator.enabled = true;
            if (animator.isActiveAndEnabled)
            {
                animator.Play(stateName, 0, 0.0f);
            }
            else
            {
                animator.enabled = false;
            }
        }

        /// <summary>
        /// 針設定
        /// </summary>
        /// <param name="hand">針</param>
        /// <param name="handNumber">針の数</param>
        /// <param name="divisionNumber">分割数</param>
        protected void SetHand(Transform hand, int handNumber, int divisionNumber)
        {
            hand.localEulerAngles = new Vector3(0.0f, 0.0f, -handNumber * 360.0f / divisionNumber);
        }

        /// <summary>
        /// 針再生
        /// </summary>
        /// <param name="handAnimator">針アニメーター</param>
        /// <param name="addAnimator">加算アニメーター</param>
        /// <param name="activeAnimator">アクティブアニメーター</param>
        /// <param name="aheadStateName">先状態名</param>
        /// <param name="addStateName">加算状態名</param>
        /// <param name="activeStateName">アクティブ状態名</param>
        protected void PlayHand(Animator handAnimator, Animator addAnimator, Animator activeAnimator, string aheadStateName, string addStateName, string activeStateName)
        {
            handAnimator.enabled = true;
            handAnimator.Play(aheadStateName, 0, 0.0f);

            addAnimator.gameObject.SetActive(true);
            addAnimator.Play(addStateName, 0, 0.0f);

            activeAnimator.enabled = true;
            activeAnimator.Play(activeStateName, 0, 0.0f);
        }

        /// <summary>
        /// 針更新
        /// </summary>
        /// <param name="animator">アニメーター</param>
        /// <param name="initStateName">初期状態名</param>
        /// <param name="aheadStateName">先状態名</param>
        /// <param name="hand">針</param>
        /// <param name="bar">バー</param>
        protected void UpdateHand(Animator animator, string initStateName, string aheadStateName, Transform hand, Image bar)
        {
            if (!animator.enabled)
            {
                return;
            }

            AnimatorStateInfo animatorStateInfo = animator.GetCurrentAnimatorStateInfo(0);
            if (animatorStateInfo.IsName(aheadStateName))
            {
                float angle = Mathf.Repeat(360.0f - (animator.transform.localEulerAngles.z + hand.transform.localEulerAngles.z), 360.0f);
                switch (state)
                {
                    case State.Wait:
                        if (angle - initAngle >= 270.0f)
                        {
                            angle = 0.0f;
                            state = State.Back;
                        }
                        else if (angle < initAngle)
                        {
                            state = State.Back;
                        }
                        break;
                    case State.Back:
                        if (angle - initAngle >= 270.0f)
                        {
                            angle = 0.0f;
                        }
                        else if (angle >= initAngle)
                        {
                            state = State.Right;
                        }
                        break;
                    case State.Right:
                        if (angle >= 180.0f)
                        {
                            state = State.Left;
                        }
                        break;
                    case State.Left:
                        if (angle < 90.0f)
                        {
                            angle = 360.0f;
                        }
                        break;
                }
                bar.fillAmount = angle / 360.0f;
                if (animatorStateInfo.normalizedTime >= 1.0f)
                {
                    animator.enabled = false;
                }
            }
            else if (animatorStateInfo.IsName(initStateName))
            {
                if (animatorStateInfo.normalizedTime >= 1.0f)
                {
                    animator.enabled = false;
                }
            }
        }

        /// <summary>
        /// 加算更新
        /// </summary>
        /// <param name="animator">アニメーター</param>
        /// <param name="stateName">状態名</param>
        protected void UpdateAdd(Animator animator, string stateName)
        {
            if ((animator == null) || (!animator.gameObject.activeSelf))
            {
                return;
            }

            AnimatorStateInfo animatorStateInfo = animator.GetCurrentAnimatorStateInfo(0);
            if ((!animatorStateInfo.IsName(stateName)) || (animatorStateInfo.normalizedTime < 1.0f))
            {
                return;
            }

            animator.gameObject.SetActive(false);
        }

        /// <summary>
        /// 針後更新
        /// </summary>
        /// <param name="animator">アニメーター</param>
        /// <param name="stateName">状態名</param>
        protected void LateUpdateHand(Animator animator, string stateName)
        {
            if (!animator.enabled)
            {
                return;
            }

            AnimatorStateInfo animatorStateInfo = animator.GetCurrentAnimatorStateInfo(0);
            if (!animatorStateInfo.IsName(stateName))
            {
                return;
            }

            Vector3 localEulerAngles = animator.transform.localEulerAngles;
            localEulerAngles.z *= addHourHandNumber;
            animator.transform.localEulerAngles = localEulerAngles;
        }

        private void Awake()
        {
            addMinuteAnimator.keepAnimatorControllerStateOnDisable = true;
            addHourAnimator.keepAnimatorControllerStateOnDisable = true;
            minuteHandAnimator.keepAnimatorControllerStateOnDisable = true;
            hourHandAnimator.keepAnimatorControllerStateOnDisable = true;
            activeAnimator.keepAnimatorControllerStateOnDisable = true;

            minuteHandAnimator.enabled = false;
            hourHandAnimator.enabled = false;
            activeAnimator.enabled = false;
        }

        // Update is called once per frame
        private void Update()
        {
            UpdateHand(minuteHandAnimator, initMinuteStateName, aheadMinuteStateName, minuteHand, minuteBar);
            UpdateHand(hourHandAnimator, initHourStateName, aheadHourStateName, hourHand, hourBar);

            UpdateAdd(addMinuteAnimator, aheadMinuteStateName);
            UpdateAdd(addHourAnimator, aheadHourStateName);

            if (activeAnimator.enabled)
            {
                AnimatorStateInfo animatorStateInfo = activeAnimator.GetCurrentAnimatorStateInfo(0);
                if (animatorStateInfo.IsName(activeMinuteStateName) || animatorStateInfo.IsName(activeHourStateName))
                {
                    if (animatorStateInfo.normalizedTime >= 1.0f)
                    {
                        activeAnimator.enabled = false;
                    }
                }
            }
        }

        private void LateUpdate()
        {
            LateUpdateHand(hourHandAnimator, aheadHourStateName);
        }

        private void OnDisable()
        {
            particle?.SetActive(false);
        }
    }
}
