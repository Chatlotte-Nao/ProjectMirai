﻿using UnityEngine;
using TMPro;
using System.Text;

namespace Adventure.UI
{
    /// <summary>
    /// ルビテキストメッシュプロスクロール
    /// </summary>
    public class RubyTMPTextScroll : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("テキストメッシュプロテキスト")]
        private TMP_Text tmpText = null;
        [SerializeField]
        [Tooltip("テキストスピード")]
        private float textSpeed = 30.0f;
        [SerializeField]
        [Tooltip("タイムスケールに影響するか")]
        private bool isUnscaledTime = false;

        /// <summary>
        /// 開始タグ左
        /// </summary>
        public const char START_LEFT_TAG = '<';
        /// <summary>
        /// タグ右
        /// </summary>
        public const char RIGHT_TAG = '>';
        /// <summary>
        /// タグ名ruby
        /// </summary>
        public const string TAG_NAME_RUBY = "ruby";
        /// <summary>
        /// タグ名space
        /// </summary>
        public const string TAG_NAME_SPACE = "space";
        /// <summary>
        /// タグ名voffset
        /// </summary>
        public const string TAG_NAME_VOFFSET = "voffset";
        /// <summary>
        /// タグ名mspace
        /// </summary>
        public const string TAG_NAME_MSPACE = "mspace";

        /// <summary>
        /// 改行名
        /// </summary>
        public const char NEW_LINE_NAME = '\n';
        /// <summary>
        /// イコール名
        /// </summary>
        public const char EQUAL_NAME = '=';
        /// <summary>
        /// バックスラッシュ名
        /// </summary>
        public const char BACK_NAME = '/';

        /// <summary>
        /// 閉じタグruby
        /// </summary>
        public const string CLOSING_TAG_RUBY = "</ruby>";
        /// <summary>
        /// 閉じタグvoffset
        /// </summary>
        public const string CLOSING_TAG_VOFFSET = "</voffset>";
        /// <summary>
        /// 閉じタグmspace
        /// </summary>
        public const string CLOSING_TAG_MSPACE = "</mspace>";
        /// <summary>
        /// 閉じタグsize
        /// </summary>
        public const string CLOSING_TAG_SIZE = "</size>";

        /// <summary>
        /// 開始タグruby
        /// </summary>
        public const string START_TAG_RUBY_SIZE = "<size=50%>";

        /// <summary>
        /// 開始タグ左size
        /// </summary>
        public const string START_LEFT_TAG_SIZE = "<size=";

        /// <summary>
        /// y位置のオフセット
        /// </summary>
        public const float OFFSET_Y = 2.0f; 

        private string rubyText = null;
        private float elapsedSeconds = 0.0f;
        private float textLength = 0.0f;
        private int previousTextIndex = 0;
        private StringBuilder stringBuilder = new StringBuilder();

        /// <summary>
        /// テキストスピード
        /// </summary>
        public float TextSpeed
        {
            get => textSpeed;
            set => textSpeed = value;
        }

        /// <summary>
        /// セットアップ
        /// </summary>
        /// <param name="text">テキスト</param>
        public void Setup(string text)
        {
            enabled = true;
            tmpText.text = null;
            elapsedSeconds = GetTime();
            previousTextIndex = -1;
            textLength = 0.0f;
            rubyText = ConvertRuby(text);
        }

        /// <summary>
        /// 終了
        /// </summary>
        public void End()
        {
            tmpText.text = AddCharacter(rubyText, NEW_LINE_NAME,true);
            enabled = false;
        }

        public bool GetEnabled()
        {
            return enabled;
        }

        /// <summary>
        /// ルビタグを置換
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <param name="rowHeights">行の高さ</param>
        /// <returns>置換されたテキスト</returns>
        protected string ReplaceTagRuby(string text, float[] rowHeights)
        {
            int index = 0;
            while (index < text.Length)
            {
                int startLeftIndex = text.IndexOf(START_LEFT_TAG, index);
                if (startLeftIndex >= 0)
                {
                    int startRightIndex = text.IndexOf(RIGHT_TAG, startLeftIndex + 1);
                    if (startRightIndex >= 0)
                    {
                        string tag = text.Substring(startLeftIndex + 1, startRightIndex - startLeftIndex - 1);
                        string[] splitTexts = tag.Split(EQUAL_NAME);
                        if ((splitTexts.Length == 2) && splitTexts[0].Equals(TAG_NAME_RUBY))
                        {
                            int closingIndex = text.IndexOf(CLOSING_TAG_RUBY, startRightIndex + 1);
                            if (closingIndex >= 0)
                            {
                                string target = text.Substring(startRightIndex + 1, closingIndex - startRightIndex - 1);
                                string ruby = splitTexts[1];
                                int count = closingIndex + CLOSING_TAG_RUBY.Length - startLeftIndex;
                                text = ConversionRubyTag(text, target, ruby, startLeftIndex, count, rowHeights);
                            }
                        }
                        index = startRightIndex + 1;
                    }
                    else
                    {
                        index = startLeftIndex + 1;
                    }
                }
                else
                {
                    return text;
                }
            }
            return text;
        }

        /// <summary>
        /// 行の高さ取得
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <returns>行の高さ</returns>
        protected float[] GetRowHeights(string text)
        {
            float[] rowHeights = null;
            string[] splitTexts = text.Split(NEW_LINE_NAME);
            if ((splitTexts == null) || (splitTexts.Length <= 0))
            {
                return rowHeights;
            }
            string startSizeTag = null;
            rowHeights = new float[splitTexts.Length];
            for (int i = 0; i < rowHeights.Length; i++)
            {
                string splitText = splitTexts[i];
                if (startSizeTag == null)
                {
                    int startLeftIndex = splitText.LastIndexOf(START_LEFT_TAG_SIZE);
                    if (startLeftIndex >= 0)
                    {
                        int startRightIndex = splitText.IndexOf(RIGHT_TAG, startLeftIndex + START_LEFT_TAG_SIZE.Length);
                        if (startRightIndex >= 0)
                        {
                            int closingIndex = splitText.IndexOf(CLOSING_TAG_SIZE, startRightIndex + 1);
                            if (closingIndex < 0)
                            {
                                startSizeTag = splitText.Substring(startLeftIndex, startRightIndex - startLeftIndex + 1);
                                stringBuilder.Clear();
                                stringBuilder.Append(splitText);
                                stringBuilder.Append(CLOSING_TAG_SIZE);
                                splitText = stringBuilder.ToString();
                            }
                        }
                    }
                }
                else
                {
                    stringBuilder.Clear();
                    stringBuilder.Append(startSizeTag);
                    stringBuilder.Append(splitText);
                    splitText = stringBuilder.ToString();
                }
                rowHeights[i] = tmpText.GetPreferredValues(splitText).y;
            }
            return rowHeights;
        }

        /// <summary>
        /// 開始タグサイズを置換
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <param name="rowHeights">行の高さ</param>
        /// <returns>置換されたテキスト</returns>
        protected string ReplaceStartTagSize(string text, float[] rowHeights)
        {
            int index = 0;
            while (index < text.Length)
            {
                int startLeftTagIndex = text.IndexOf(START_LEFT_TAG_SIZE, index);
                if (startLeftTagIndex >= 0)
                {
                    int startRightTagIndex = text.IndexOf(RIGHT_TAG, startLeftTagIndex + START_LEFT_TAG_SIZE.Length);
                    if (startRightTagIndex >= 0)
                    {
                        string tag = text.Substring(startLeftTagIndex, startRightTagIndex - startLeftTagIndex + 1);
                        int number = GetWhatLine(text, startRightTagIndex + 1);
                        float size = GetVoffsetTargetNumber(rowHeights[number - 1]);
                        string voffsetTag = CreateStartTag(TAG_NAME_VOFFSET, size.ToString());
                        text = text.Insert(startLeftTagIndex, CLOSING_TAG_VOFFSET);
                        text = text.Insert(startRightTagIndex + CLOSING_TAG_VOFFSET.Length + 1, voffsetTag);
                        index = startRightTagIndex + CLOSING_TAG_VOFFSET.Length + voffsetTag.Length + 1;
                    }
                    else
                    {
                        return text;
                    }
                }
                else
                {
                    return text;
                }
            }
            return text;
        }

        /// <summary>
        /// 閉じタグサイズを置換
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <param name="rowHeights">行の高さ</param>
        /// <returns>置換されたテキスト</returns>
        protected string ReplaceClosingTagSize(string text, float[] rowHeights)
        {
            int index = 0;
            while (index < text.Length)
            {
                int closingIndex = text.IndexOf(CLOSING_TAG_SIZE, index);
                if (closingIndex >= 0)
                {
                    text = text.Insert(closingIndex, CLOSING_TAG_VOFFSET);
                    int offset = closingIndex + CLOSING_TAG_VOFFSET.Length + CLOSING_TAG_SIZE.Length;
                    int number = GetWhatLine(text, offset);
                    float size = GetVoffsetTargetNumber(rowHeights[number - 1]);
                    string voffsetTag = CreateStartTag(TAG_NAME_VOFFSET, size.ToString());
                    text = text.Insert(offset, voffsetTag);
                    index = closingIndex + CLOSING_TAG_SIZE.Length + CLOSING_TAG_VOFFSET.Length + voffsetTag.Length + 1;
                }
                else
                {
                    return text;
                }
            }
            return text;
        }

        /// <summary>
        /// タグサイズを置換
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <param name="rowHeights">行の高さ</param>
        /// <returns>置換されたテキスト</returns>
        protected string ReplaceTagSize(string text, float[] rowHeights)
        {
            text = ReplaceStartTagSize(text, rowHeights);
            text = ReplaceClosingTagSize(text, rowHeights);
            return text;
        }

        /// <summary>
        /// タグのvoffsetの数の取得
        /// </summary>
        /// <param name="height">高さ</param>
        /// <returns>voffsetの数</returns>
        protected float GetVoffsetTargetNumber(float height)
        {
            return tmpText.fontSize / 2.0f - (height - tmpText.fontSize) - OFFSET_Y;
        }

        /// <summary>
        /// ルビに変換
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <returns>変換されたテキスト</returns>
        protected string ConvertRuby(string text)
        {
            if (text == null)
            {
                return null;
            }
            float[] rowHeights = GetRowHeights(text);
            text = ReplaceTagSize(text, rowHeights);
            text = ReplaceTagRuby(text, rowHeights);

            string newText = "";
            string[] splitTexts = text.Split(NEW_LINE_NAME);
            for (int i = 0; i < splitTexts.Length; i++)
            {
                string splitText = splitTexts[i];
                float number = GetVoffsetTargetNumber(rowHeights[i]);
                string voffsetTag = CreateStartTag(TAG_NAME_VOFFSET, number.ToString());

                string startSizeTag = GetStartSizeTagNotClosed(splitText, splitText.Length);
                
                stringBuilder.Clear();
                stringBuilder.Append(newText);
                if (i == 0)
                {
                    stringBuilder.Append(voffsetTag);
                }
                stringBuilder.Append(splitText);
                stringBuilder.Append(CLOSING_TAG_VOFFSET);
                if (startSizeTag != null)
                {
                    stringBuilder.Append(CLOSING_TAG_SIZE);
                }
                stringBuilder.Append(NEW_LINE_NAME);
                if (i < (splitText.Length - 1))
                {
                    if (startSizeTag != null)
                    {
                        stringBuilder.Append(startSizeTag);
                    }
                    stringBuilder.Append(voffsetTag);
                }
                newText = stringBuilder.ToString();
            }
            return newText;
        }

        /// <summary>
        /// 何行目かを取得
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <param name="index">インディクス</param>
        /// <returns>行数</returns>
        protected int GetWhatLine(string text, int index)
        {
            string[] splitTexts = text.Split(NEW_LINE_NAME);
            if ((splitTexts == null) || (splitTexts.Length <= 0))
            {
                return 1;
            }
            int length = 0; 
            for (int i = 0; i < splitTexts.Length; i++)
            {
                length += splitTexts[i].Length + 1;
                if (index <= length)
                {
                    return i + 1;
                }
            }
            return splitTexts.Length;
        }

        /// <summary>
        /// ルビ対象をリッチテキストに変換
        /// </summary>
        /// <param name="target">ルビ対象</param>
        /// <param name="text">テキスト</param>
        /// <param name="index">インディクス</param>
        /// <returns>リッチテキスト</returns>
        protected string ConvertTargetRichText(string target, string text, int index)
        {
            int startLeftTagIndex = text.LastIndexOf(START_LEFT_TAG_SIZE, index);
            if (startLeftTagIndex < 0)
            {
                return target;
            }

            int startRightTagIndex = text.IndexOf(RIGHT_TAG, startLeftTagIndex + 1);
            if (startRightTagIndex <= 0)
            {
                return target;
            }

            int closingTagIndex = text.IndexOf(CLOSING_TAG_SIZE, index);
            if (closingTagIndex <= 0)
            {
                return target;
            }

            string tag = text.Substring(startLeftTagIndex, startRightTagIndex - startLeftTagIndex + 1);
            stringBuilder.Clear();
            stringBuilder.Append(tag);
            stringBuilder.Append(target);
            stringBuilder.Append(CLOSING_TAG_SIZE);
            return stringBuilder.ToString();
        }

        /// <summary>
        /// ルビをリッチテキストに変換
        /// </summary>
        /// <param name="ruby">ルビ</param>
        /// <returns>リッチテキスト</returns>
        protected string ConvertRubyRichText(string ruby)
        {
            stringBuilder.Clear();
            stringBuilder.Append(START_TAG_RUBY_SIZE);
            stringBuilder.Append(ruby);
            stringBuilder.Append(CLOSING_TAG_SIZE);
            return stringBuilder.ToString();
        }

        /// <summary>
        /// 閉じられていない開始サイズタグ取得
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <param name="index">インディクス</param>
        /// <returns>開始サイズタグ(nullならなし)</returns>
        protected string GetStartSizeTagNotClosed(string text, int index)
        {
            if (index <= 0)
            {
                return null;
            }

            int startLeftNumber = text.LastIndexOf(START_LEFT_TAG_SIZE, index - 1);
            if (startLeftNumber < 0)
            {
                return null;
            }

            int contentsIndex = startLeftNumber + START_LEFT_TAG_SIZE.Length;
            int startRightNumber = text.IndexOf(RIGHT_TAG, contentsIndex, index - contentsIndex);
            if (startRightNumber <= contentsIndex)
            {
                return null;
            }

            int endTagSize = text.IndexOf(CLOSING_TAG_SIZE, startRightNumber + 1, index - startRightNumber - 1);
            if (endTagSize >= 0)
            {
                return null;
            }
            return text.Substring(startLeftNumber, startRightNumber - startLeftNumber + 1);
        }

        /// <summary>
        /// ルビに置換
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <param name="tag">タグ</param>
        /// <param name="index">インディクス</param>
        /// <param name="count">タグの文字数</param>
        /// <returns>置換したルビ</returns>
        protected string ReplaceRuby(string text, string tag, int index, int count)
        {
            string previousText = text.Substring(0, index);
            string behindText = text.Substring(index + count);
            stringBuilder.Clear();
            stringBuilder.Append(previousText);
            stringBuilder.Append(tag);
            stringBuilder.Append(behindText);
            return stringBuilder.ToString();
        }

        /// <summary>
        /// ルビタグに変換
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <param name="target">対象のルビ</param>
        /// <param name="ruby">ルビ</param>
        /// <param name="index">インディクス</param>
        /// <param name="count">ルビタグ文字数</param>
        /// <param name="rowHeights">行の高さ</param>
        /// <returns>変換したテキスト</returns>
        protected string ConversionRubyTag(string text, string target, string ruby, int index, int count, float[] rowHeights)
        {
            string targetRichText = ConvertTargetRichText(target, text, index);
            Vector2 targetLength = tmpText.GetPreferredValues(targetRichText);
            string rubyRichText = ConvertRubyRichText(ruby);
            Vector2 rubyLength = tmpText.GetPreferredValues(rubyRichText);

            int line = GetWhatLine(text, index);
            if ((line <= 0) || (line > rowHeights.Length))
            {
                return text;
            }
            float rowHeight = rowHeights[line - 1];
            float voffsetRubyNumber = (tmpText.fontSize / 2.0f) - (targetLength.y - rowHeight) - OFFSET_Y;
            string voffsetRubyTag = CreateStartTag(TAG_NAME_VOFFSET, voffsetRubyNumber.ToString());
            float voffsetTargetNumber = GetVoffsetTargetNumber(rowHeight);
            string voffsetTargetTag = CreateStartTag(TAG_NAME_VOFFSET, voffsetTargetNumber.ToString());

            string sizeTag = GetStartSizeTagNotClosed(text, index);

            if (rubyLength.x > targetLength.x)
            {
                float spaceNumber = -rubyLength.x;
                string startTagSpace = CreateStartTag(TAG_NAME_SPACE, spaceNumber.ToString());
                float mspaceNumber = rubyLength.x / target.Length;
                string startTagMspace = CreateStartTag(TAG_NAME_MSPACE, mspaceNumber.ToString());

                stringBuilder.Clear();
                stringBuilder.Append(startTagMspace);
                stringBuilder.Append(target);
                stringBuilder.Append(CLOSING_TAG_MSPACE);
                stringBuilder.Append(CLOSING_TAG_VOFFSET);
                stringBuilder.Append(voffsetRubyTag);
                if (sizeTag != null)
                {
                    stringBuilder.Append(CLOSING_TAG_SIZE);
                }
                stringBuilder.Append(START_TAG_RUBY_SIZE);
                stringBuilder.Append(startTagSpace);
                stringBuilder.Append(ruby);
                stringBuilder.Append(CLOSING_TAG_SIZE);
                if (sizeTag != null)
                {
                    stringBuilder.Append(sizeTag);
                }
                stringBuilder.Append(CLOSING_TAG_VOFFSET);
                stringBuilder.Append(voffsetTargetTag);
            }
            else
            {
                float spaceNumber = -targetLength.x;
                string startTagSpace = CreateStartTag(TAG_NAME_SPACE, spaceNumber.ToString());
                float mspaceNumber = targetLength.x / ruby.Length;
                string startTagMspace = CreateStartTag(TAG_NAME_MSPACE, mspaceNumber.ToString());

                stringBuilder.Clear();
                stringBuilder.Append(target);
                stringBuilder.Append(CLOSING_TAG_VOFFSET);
                stringBuilder.Append(voffsetRubyTag);
                if (sizeTag != null)
                {
                    stringBuilder.Append(CLOSING_TAG_SIZE);
                }
                stringBuilder.Append(START_TAG_RUBY_SIZE);
                stringBuilder.Append(startTagSpace);
                stringBuilder.Append(startTagMspace);
                stringBuilder.Append(ruby);
                stringBuilder.Append(CLOSING_TAG_MSPACE);
                stringBuilder.Append(CLOSING_TAG_SIZE);
                if (sizeTag != null)
                {
                    stringBuilder.Append(sizeTag);
                }
                stringBuilder.Append(CLOSING_TAG_VOFFSET);
                stringBuilder.Append(voffsetTargetTag);
            }
            string newTag = stringBuilder.ToString();
            return ReplaceRuby(text, newTag, index, count);
        }
        
        /// <summary>
        /// 開始タグ生成
        /// </summary>
        /// <param name="tagName">タグ名</param>
        /// <param name="number">数</param>
        /// <param name="unit">単位</param>
        /// <returns>開始タグ</returns>
        protected string CreateStartTag(string tagName, string number, string unit = null)
        {
            stringBuilder.Clear();
            stringBuilder.Append(START_LEFT_TAG);
            stringBuilder.Append(tagName);
            stringBuilder.Append(EQUAL_NAME);
            stringBuilder.Append(number);
            if (unit != null)
            {
                stringBuilder.Append(unit);
            }
            stringBuilder.Append(RIGHT_TAG);
            return stringBuilder.ToString();
        }

        /// <summary>
        /// 閉じタグ生成
        /// </summary>
        /// <param name="tagName">タグ名</param>
        /// <returns>閉じタグ</returns>
        protected string CreateClosingTag(string tagName)
        {
            stringBuilder.Clear();
            stringBuilder.Append(START_LEFT_TAG);
            stringBuilder.Append(BACK_NAME);
            stringBuilder.Append(tagName);
            stringBuilder.Append(RIGHT_TAG);
            return stringBuilder.ToString();
        }

        /// <summary>
        /// タグを追加した数を取得
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <param name="number">数</param>
        /// <returns>タグを追加した数</returns>
        protected int GetNumberAddTag(string text, int number)
        {
            int index = 0;
            while (number < rubyText.Length)
            {
                int startLeftIndex = rubyText.IndexOf(START_LEFT_TAG, index, number - index + 1);
                if (startLeftIndex < 0)
                {
                    return number;
                }

                int startRightIndex = rubyText.IndexOf(RIGHT_TAG, startLeftIndex + 1);
                if (startRightIndex >= 0)
                {
                    number += startRightIndex - startLeftIndex + 1;
                    index = startRightIndex + 1;
                }
                else
                {
                    index = startLeftIndex + 1;
                }
            }
            return number;
        }
        
        /// <summary>
        /// 欠落しているタグの追加
        /// </summary>
        /// <param name="originalText">元のテキスト</param>
        /// <param name="realText">現実のテキスト</param>
        /// <param name="index">インディクス</param>
        /// <returns>修正したテキスト</returns>
        protected string AddMissingTag(string originalText, string realText, int index)
        {
            int count = 0;
            while (count < index)
            {
                int startLeftIndex = originalText.IndexOf(START_LEFT_TAG, count, index - count + 1);
                if (startLeftIndex < 0)
                {
                    return realText;
                }

                int startRightIndex = originalText.IndexOf(RIGHT_TAG, startLeftIndex + 1);
                if (startRightIndex <= startLeftIndex)
                {
                    count = startLeftIndex + 1;
                    continue;
                }

                if (originalText[startLeftIndex + 1] != BACK_NAME)
                {
                    int equalIndex = originalText.IndexOf(EQUAL_NAME, startLeftIndex + 1, startRightIndex - startLeftIndex - 1);
                    if (equalIndex >= 0)
                    {
                        string tagName = originalText.Substring(startLeftIndex + 1, equalIndex - startLeftIndex - 1);
                        string closingTag = CreateClosingTag(tagName);
                        int oldClosingIndex = originalText.IndexOf(closingTag, startRightIndex + 1);
                        if (oldClosingIndex >= 0)
                        {
                            int closingIndex = originalText.IndexOf(closingTag, startRightIndex + 1, index - startRightIndex);
                            if (closingIndex < 0)
                            {
                                stringBuilder.Clear();
                                stringBuilder.Append(realText);
                                if (closingTag == CLOSING_TAG_SIZE)
                                {
                                    stringBuilder.Append(CLOSING_TAG_VOFFSET);
                                    stringBuilder.Append(CLOSING_TAG_SIZE);
                                }
                                else
                                {
                                    stringBuilder.Append(closingTag);
                                }
                                return stringBuilder.ToString();
                            }
                        }
                    }
                }
                count = startRightIndex + 1;
            }
            return realText;
        }

        /// <summary>
        /// 文字追加
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <param name="character">文字</param>
        /// <returns>文字が追加されたテキスト</returns>
        protected string AddCharacter(string text, char character,bool isEnd = false)
        {
            stringBuilder.Clear();
            stringBuilder.Append(text);
            if(!isEnd)
                stringBuilder.Append(character);
            return stringBuilder.ToString();
        }

        /// <summary>
        /// ゲーム開始からの時間(秒)取得
        /// </summary>
        /// <returns>ゲーム開始からの時間(秒)</returns>
        protected float GetTime()
        {
            return isUnscaledTime ? Time.unscaledTime : Time.time;
        }

        // Update is called once per frame
        private void Update()
        {
            float nowTime = GetTime();
            textLength += (nowTime - elapsedSeconds) * textSpeed;
            elapsedSeconds = nowTime;
            if (textLength <= 0.0f)
            {
                return;
            }
            int nowTextIndex = (int)textLength;
            if (previousTextIndex != nowTextIndex)
            {
                int realTextIndex = GetNumberAddTag(rubyText, nowTextIndex);
                string realText = null;
                if (realTextIndex < rubyText.Length)
                {
                    string realMissingText = rubyText.Substring(0, realTextIndex + 1);
                    realText = AddMissingTag(rubyText, realMissingText, realTextIndex);
                    tmpText.text = AddCharacter(realText, NEW_LINE_NAME);
                }
                else
                {
                    realText = rubyText;
                    enabled = false;
                    tmpText.text = AddCharacter(realText, NEW_LINE_NAME ,true);
                }
                
                previousTextIndex = nowTextIndex;
            }
        }

        private void Awake()
        {
            enabled = false;
            tmpText.text = null;
        }
    }
}
