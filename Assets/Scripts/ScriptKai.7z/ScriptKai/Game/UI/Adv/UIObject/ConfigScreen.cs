﻿using Base.Sound;

using Game.Sound;
using UnityEngine;
using UnityEngine.UI;
using Adventure.Util;

namespace Adventure.UI
{
    /// <summary>
    /// コンフィグ画面
    /// </summary>
    public class ConfigScreen : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("BGMスライダー")]
        private Slider bgmSlider = null;
        [SerializeField]
        [Tooltip("SEスライダー")]
        private Slider seSlider = null;
        [SerializeField]
        [Tooltip("ボイススライダー")]
        private Slider voiceSlider = null;
        [SerializeField]
        [Tooltip("テキストスピードスライダー")]
        private Slider textSpeedSlider = null;
        [SerializeField]
        [Tooltip("デフォルトSE名")]
        private string defaultSeName = "se_select";
        [SerializeField]
        [Tooltip("デフォルトボイス名")]
        private string defaultVoiceName = "test_01_0040";
        [SerializeField]
        [Tooltip("ルビテキストスクロール")]
        private RubyTextScroll rubyTextScroll = null;
        [SerializeField]
        [Tooltip("コマンド管理")]
        private CommandManager commandManager = null;
        [SerializeField]
        [Tooltip("テキストスピード")]
        private float[] textSpeeds = null;
        [SerializeField]
        [Tooltip("初期時のテキストスピードインディクス")]
        private int initTextSpeedIndex = 1;
        [SerializeField]
        [Tooltip("テキスト表示秒")]
        private float textDisplaySecond = 0.5f;

        private float nowTimeScale = 0.0f;
        private float elapsedSeconds = 0.0f;
        private bool textMoving = false;
        private bool seVolumeChanged = false;
        private bool voiceVolumeChanged = false;

        /// <summary>
        /// テキストスピード取得
        /// </summary>
        public float[] TextSpeeds => textSpeeds;

        /// <summary>
        /// 初期化ボタンがクリックした時
        /// </summary>
        public void OnClickInitialize()
        {
            SoundExpansion.PlaySe(SoundConstants.SE_SELECT);
            bgmSlider.value = bgmSlider.maxValue;
            seSlider.value = seSlider.maxValue;
            voiceSlider.value = voiceSlider.maxValue;
            textSpeedSlider.value = initTextSpeedIndex;
            SetBgmVolume();
            SetSeVolume();
            SetVoiceVolume();
            SetTextSpeed();
            seVolumeChanged = false;
            voiceVolumeChanged = false;
        }

        /// <summary>
        /// 戻るボタンがクリックした時
        /// </summary>
        public void OnClickReturn()
        {
            SoundExpansion.PlaySe(SoundConstants.SE_SELECT);

           // SaveData saveData = SaveData.GetInstance();
            //saveData.bgmVolume = (int)(bgmSlider.value * bgmSlider.maxValue);
            //saveData.seVolume = (int)(seSlider.value * seSlider.maxValue);
            //saveData.voiceVolume = (int)(voiceSlider.value * voiceSlider.maxValue);
            //saveData.textSpeedScaleIndex = (int)textSpeedSlider.value;
           // SaveData.Save(true);

            Time.timeScale = nowTimeScale;
            gameObject.SetActive(false);
        }

        /// <summary>
        /// BGMのトグルの値が変更された時
        /// </summary>
        public void OnValueChangedBgm()
        {
            SetBgmVolume();
        }

        /// <summary>
        /// SEのトグルの値が変更された時
        /// </summary>
        public void OnValueChangedSe()
        {
            seVolumeChanged = true;
            SetSeVolume();
        }

        /// <summary>
        /// ボイスのトグルの値が変更された時
        /// </summary>
        public void OnValueChangedVoice()
        {
            voiceVolumeChanged = true;
            SetVoiceVolume();
        }

        /// <summary>
        /// メッセージ速度の値が変更された時
        /// </summary>
        public void OnValueChangeMessageSpeed()
        {
            SetTextSpeed();
        }

        /// <summary>
        /// BGM音量設定
        /// </summary>
        protected void SetBgmVolume()
        {
            SoundManager.GetInstance().SetBgmMasterVolume(bgmSlider.value / bgmSlider.maxValue);
        }

        /// <summary>
        /// SE音量設定
        /// </summary>
        protected void SetSeVolume()
        {
            SoundManager.GetInstance().SetSeMasterVolume(seSlider.value / seSlider.maxValue);
        }

        /// <summary>
        /// ボイス音量設定
        /// </summary>
        protected void SetVoiceVolume()
        {
            SoundManager.GetInstance().SetVoiceMasterVolume(voiceSlider.value / voiceSlider.maxValue);
        }

        /// <summary>
        /// テキストスピード設定
        /// </summary>
        protected void SetTextSpeed()
        {
            rubyTextScroll.TextSpeed = textSpeeds[(int)textSpeedSlider.value];
            commandManager?.TextSpeed.SetTextSpeed(rubyTextScroll.TextSpeed);
        }

        /// <summary>
        /// テキスト準備中設定
        /// </summary>
        protected void SetPreparingText()
        {
            elapsedSeconds = Time.unscaledTime;
            textMoving = false;
        }

        private void OnEnable()
        {
            //SaveData saveData = SaveData.GetInstance();
            //bgmSlider.value = saveData.bgmVolume / bgmSlider.maxValue;
            //seSlider.value = saveData.seVolume / seSlider.maxValue;
            //voiceSlider.value = saveData.voiceVolume / voiceSlider.maxValue;
            textSpeedSlider.maxValue = textSpeeds.Length - 1;
            //textSpeedSlider.value = saveData.textSpeedScaleIndex;
            seVolumeChanged = false;
            voiceVolumeChanged = false;
            nowTimeScale = Time.timeScale;
            Time.timeScale = 0.0f;
            SetPreparingText();
        }

        private void Update()
        {
            if (Input.GetMouseButtonUp(0))
            {
                if (seVolumeChanged)
                {
                    SoundExpansion.PlaySe(defaultSeName);
                    seVolumeChanged = false;
                }
                if (voiceVolumeChanged)
                {
                    SoundPlayer.StopVoice();
                    SoundExpansion.PlayVoice(defaultVoiceName);
                    voiceVolumeChanged = false;
                }
            }
            if (textMoving)
            {
                rubyTextScroll.Move();
                if (!rubyTextScroll.enabled)
                {
                    SetPreparingText();
                }
            }
            else
            {
                if (Time.unscaledTime - elapsedSeconds >= textDisplaySecond)
                {
                    rubyTextScroll.Init();
                    textMoving = true;
                }
            }
        }
    }
}
