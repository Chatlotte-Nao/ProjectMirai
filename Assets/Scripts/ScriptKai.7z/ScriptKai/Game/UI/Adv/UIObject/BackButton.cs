﻿using Game.ScriptEngine;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Adventure.UI
{
    /// <summary>
    /// バックボタン
    /// </summary>
    public class BackButton : MonoBehaviour
    {
        /// <summary>
        /// エンディングのスクリプト名
        /// </summary>
        public const string ENDING_SCRIPT_NAME = "Initialization";
        /// <summary>
        /// エンディングのラベル
        /// </summary>
        public const string ENDING_LABEL = "Ending03";

        [SerializeField]
        [Tooltip("ボタン")]
        private Button button = null;

        /// <summary>
        /// クリックした時のアクション
        /// </summary>
        public UnityAction ClickAction { get; private set; } = null;


        /// <summary>
        /// セットアップ
        /// </summary>
        /// <param name="clickAction">クリックした時のアクション</param>
        /// <param name="endingScriptName">エンディングのスクリプト名</param>
        /// <param name="endingLabel">エンディングのラベル</param>
        public void Setup(UnityAction clickAction = null, string endingScriptName = ENDING_SCRIPT_NAME, string endingLabel = ENDING_LABEL)
        {
            if (button == null)
            {
                return;
            }
            ClickAction = clickAction;

            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(() =>
            {
                clickAction?.Invoke();
                ScriptEngine.GetInstance()?.CallScript(endingScriptName, endingLabel);
                button.onClick.RemoveAllListeners();
            });
        }
    }
}
