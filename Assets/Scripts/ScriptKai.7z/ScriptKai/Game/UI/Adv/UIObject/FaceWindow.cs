﻿using System.Text;
using UnityEngine;
using UnityEngine.UI;

namespace Adventure.UI
{
    /// <summary>
    /// フェイスウィンドウ
    /// </summary>
    public class FaceWindow : MonoBehaviour
    {
        /// <summary>
        /// 顔アイコン
        /// </summary>
        [System.Serializable]
        public class FaceIcon
        {
            [SerializeField]
            [Tooltip("話者名")]
            private string speakerName = null;
            [SerializeField]
            [Tooltip("画像名")]
            private string imageName = null;

            /// <summary>
            /// 話者名
            /// </summary>
            public string SpeakerName => speakerName;

            /// <summary>
            /// 画像名
            /// </summary>
            public string ImageName => imageName;

            /// <summary>
            /// テクスチャ2D
            /// </summary>
            public Texture2D Texture2D { get; set; } = null;
        }

        [SerializeField]
        [Tooltip("顔アイコン")]
        private FaceIcon[] faceIcons = null;
        [SerializeField]
        [Tooltip("画像パス")]
        private string imagePath = null;
        [SerializeField]
        [Tooltip("画像")]
        private Image image = null;

        private StringBuilder stringBuilder = new StringBuilder();

        private void Awake()
        {
            image.enabled = false;
        }

        /// <summary>
        /// アイコン設定
        /// </summary>
        /// <param name="speakerName">話者名</param>
        public void SetIcon(string speakerName)
        {
            for (int i = 0; i < faceIcons.Length; i++)
            {
                FaceIcon faceIcon = faceIcons[i];
                if (faceIcon.SpeakerName == speakerName)
                {
                    if (faceIcon.Texture2D == null)
                    {
                        stringBuilder.Clear();
                        stringBuilder.Append(imagePath);
                        stringBuilder.Append(faceIcon.ImageName);
                        faceIcon.Texture2D = Resources.Load(stringBuilder.ToString()) as Texture2D;
                    }
                    Rect rect = new Rect(0.0f, 0.0f, faceIcon.Texture2D.width, faceIcon.Texture2D.height);
                    image.sprite = Sprite.Create(faceIcons[i].Texture2D, rect, Vector2.zero);
                    image.SetNativeSize();
                    image.enabled = true;
                    return;
                }
            }
            image.sprite = null;
            image.enabled = false;
        }

        /// <summary>
        /// アイコン取得
        /// </summary>
        /// <returns></returns>
        public Sprite GetIcon()
        {
            return image.sprite;
        }
    }
}
