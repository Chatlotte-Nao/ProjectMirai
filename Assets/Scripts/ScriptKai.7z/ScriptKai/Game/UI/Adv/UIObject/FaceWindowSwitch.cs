﻿
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using Cysharp.Threading.Tasks;
using Pheonix.Core;
using TMPro;

namespace Adventure.UI
{
    /// <summary>
    /// 顔ウインドウの切り替え
    /// </summary>
    public class FaceWindowSwitch : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("顔画像左")]
        private Image faceImageLeft = null;
        [SerializeField]
        [Tooltip("顔画像右")]
        private Image faceImageRight = null;
        [SerializeField]
        [Tooltip("背景左")]
        private GameObject backgroundLeft = null;
        [SerializeField]
        [Tooltip("背景右")]
        private GameObject backgroundRight = null;
        [SerializeField]
        [Tooltip("顔画像左アニメーション")]
        private Animator faceLeftAnimator = null;
        [SerializeField]
        [Tooltip("顔画像右アニメーション")]
        private Animator faceRightAnimator = null;
        [SerializeField]
        [Tooltip("名前のトランスフォーム")]
        private Transform characterNameTransform = null;
        [SerializeField]
        [Tooltip("左入場アニメーション")]
        private string leftInAnimationName = "adv_chara_L_in";
        [SerializeField]
        [Tooltip("左待機アニメーション")]
        private string leftWaitAnimationName = "adv_chara_L_wait";
        [SerializeField]
        [Tooltip("左退場アニメーション")]
        private string leftOutAnimationName = "adv_chara_L_out";
        [SerializeField]
        [Tooltip("右入場アニメーション")]
        private string rightInAnimationName = "adv_chara_R_in";
        [SerializeField]
        [Tooltip("右待機アニメーション")]
        private string rightWaitAnimationName = "adv_chara_R_wait";
        [SerializeField]
        [Tooltip("右退場アニメーション")]
        private string rightOutAnimationName = "adv_chara_R_out";
        [SerializeField]
        [Tooltip("顔の左のファイル名のタグ")]
        private string faceLeftTag = "_l";
        [SerializeField]
        [Tooltip("顔の右のファイル名のタグ")]
        private string faceRightTag = "_r";
        [SerializeField]
        [Tooltip("")]
        private Image characterNameDownLine;
        [SerializeField]
        [Tooltip("")]
        private TextMeshProUGUI characterName;
        //[SerializeField] TextMeshProUGUI mainSpeakWindow;

        /// <summary>
        /// 区分なし
        /// </summary>
        public const int SECTION_NONE = 0;
        /// <summary>
        /// 区分の話者名、話者画像左の番号
        /// </summary>
        public const int SECTION_LEFT_SHOW_NUMBER = 1;
        /// <summary>
        /// 区分の話者名左、話者画像無の番号
        /// </summary>
        public const int SECTION_LEFT_NUMBER = 2;
        /// <summary>
        /// 区分の話者名、話者画像右の番号
        /// </summary>
        public const int SECTION_RIGHT_SHOW_NUMBER = 3;
        /// <summary>
        /// 区分の話者名右、話者画像無の番号
        /// </summary>
        public const int SECTION_RIGHT_NUMBER = 4;

        private Dictionary<string, Texture2D> faceLeftTextures = new Dictionary<string, Texture2D>();
        private Dictionary<string, Texture2D> faceRightTextures = new Dictionary<string, Texture2D>();
        private StringBuilder stringBuilder = new StringBuilder();
        private float characterNameLocalLeft = 0.0f;
        private int oldFaceNumber = SECTION_NONE;
        private int leftInId = 0;
        private int rightInId = 0;
        private int leftOutId = 0;
        private int rightOutId = 0;

        /// <summary>
        /// 顔ウィンドウ設定
        /// </summary>
        /// <param name="characterName">キャラ名</param>
        /// <param name="section">区分(1:話者名、話者画像左 2:話者名左、話者画像無 3:話者名、話者画像右 4:話者名右、話者画像無)</param>
        public async UniTask SetFaceWindow(string imageName, int section)
        {
            Pheonix.Core.Log.Info("SetFaceWindow");
            int nowSection = section;
            if (!GetIsSection(nowSection))
            {
                nowSection = SECTION_LEFT_NUMBER;
            }
            if (nowSection == SECTION_RIGHT_SHOW_NUMBER)
            {
                Sprite texture2D = await GetFaceTexture(imageName, faceRightTag);
                if (texture2D == null)
                {
                    nowSection = SECTION_RIGHT_NUMBER;
                }
                else
                {
                    SetFaceRight(texture2D);
                }
            }
            else if (nowSection == SECTION_LEFT_SHOW_NUMBER)
            {
                Sprite texture2D = await GetFaceTexture(imageName, faceLeftTag);
                if (texture2D == null)
                {
                    nowSection = SECTION_LEFT_NUMBER;
                }
                else
                {
                    SetFaceLeft(texture2D);
                }
            }
            // if ((nowSection == SECTION_RIGHT_NUMBER) || (nowSection == SECTION_RIGHT_SHOW_NUMBER))
            // {
            //     SetSpeakerRight();
            // }
            // else
            // {
            //     SetSpeakerLeft();
            // }
            SetSpeakerLeft();
            if (oldFaceNumber != nowSection)
            {
                StartAnimation(nowSection);
            }
            oldFaceNumber = nowSection;
        }

        /// <summary>
        /// 顔ウィンドウ非表示
        /// </summary>
        public void HideFaceWindow()
        {
            backgroundLeft.SetActive(false);
            backgroundRight.SetActive(false);
            oldFaceNumber = SECTION_NONE;
        }

        /// <summary>
        /// 区分であるか
        /// </summary>
        /// <param name="section">区分</param>
        /// <returns>true:区分である false:区分でない</returns>
        public bool GetIsSection(int section)
        {
            return (section == SECTION_LEFT_SHOW_NUMBER) || (section == SECTION_RIGHT_SHOW_NUMBER) || (section == SECTION_LEFT_NUMBER) || (section == SECTION_RIGHT_NUMBER);
        }

        /// <summary>
        /// 顔アニメーション退場
        /// </summary>
        protected void ExitFaceAnimation()
        {
            if (backgroundLeft.activeSelf)
            {
                faceLeftAnimator.Play(leftOutAnimationName);
            }
            if (backgroundRight.activeSelf)
            {
                faceRightAnimator.Play(rightOutAnimationName);
            }
        }

        /// <summary>
        /// 話者名左設定
        /// </summary>
        protected void SetSpeakerLeft()
        {
            Vector3 nameLocalPosition = characterNameTransform.transform.localPosition;
            characterNameDownLine.GetComponent<RectTransform>().localScale = new Vector3(1, 1, 1);
            characterName.alignment = TextAlignmentOptions.MidlineLeft;
            //mainSpeakWindow.alignment = TextAlignmentOptions.TopLeft;
            //nameLocalPosition.x = characterNameLocalLeft;
            nameLocalPosition.x = -285;
            characterNameTransform.transform.localPosition = nameLocalPosition;
        }

        /// <summary>
        /// 顔左設定
        /// </summary>
        /// <param name="texture">テクスチャ</param>
        protected void SetFaceLeft(Sprite texture)
        {
            if (texture == null)
            {
                return;
            }
            SerCharacterNameScale(0);
            faceImageLeft.sprite = texture;
            faceImageLeft.SetNativeSize();

            Vector3 faceLocalPosition = faceImageLeft.transform.localPosition;
            faceLocalPosition.x = -Mathf.Abs(faceImageLeft.transform.localPosition.x);
            faceImageLeft.transform.localPosition = faceLocalPosition;
            backgroundLeft.SetActive(true);
            SerCharacterNameScale(1);
        }

        /// <summary>
        /// 話者名右設定
        /// </summary>
        protected void SetSpeakerRight()
        {
            SerCharacterNameScale(0);
            Vector3 nameLocalPosition = characterNameTransform.transform.localPosition;
            characterNameDownLine.GetComponent<RectTransform>().localScale = new Vector3(-1, 1, 1);
            characterName.alignment = TextAlignmentOptions.MidlineRight;
            //mainSpeakWindow.alignment = TextAlignmentOptions.TopRight;
            //nameLocalPosition.x = -characterNameLocalLeft;
            nameLocalPosition.x = 250;
            characterNameTransform.transform.localPosition = nameLocalPosition;
            SerCharacterNameScale(1);
        }

        private void SerCharacterNameScale(float scale)
        {
            characterNameTransform.GetComponent<RectTransform>().localScale = new Vector3(scale, scale, scale);
        }

        /// <summary>
        /// 顔右設定
        /// </summary>
        /// <param name="texture">テクスチャ</param>
        protected void SetFaceRight(Sprite texture)
        {
            if (texture == null)
            {
                return;
            }
            faceImageRight.sprite = texture;
            faceImageRight.SetNativeSize();

            Vector3 faceLocalPosition = faceImageRight.transform.localPosition;
            faceLocalPosition.x = Mathf.Abs(faceImageRight.transform.localPosition.x);
            faceImageRight.transform.localPosition = faceLocalPosition;
            backgroundRight.SetActive(true);
        }

        /// <summary>
        /// アニメーション開始
        /// </summary>
        protected void StartAnimation(int section)
        {
            if (section == SECTION_LEFT_SHOW_NUMBER)
            {
                if (backgroundLeft.activeSelf)
                {
                    faceLeftAnimator.Play(leftInAnimationName);
                }
                if (backgroundRight.activeSelf)
                {
                    faceRightAnimator.Play(rightOutAnimationName);
                }
            }
            else if (section == SECTION_RIGHT_SHOW_NUMBER)
            {
                if (backgroundLeft.activeSelf)
                {
                    faceLeftAnimator.Play(leftOutAnimationName);
                }
                if (backgroundRight.activeSelf)
                {
                    faceRightAnimator.Play(rightInAnimationName);
                }
            }
            else
            {
                ExitFaceAnimation();
            }
        }

        /// <summary>
        /// アニメーション更新
        /// </summary>
        /// <param name="animator">アニメーター</param>
        /// <param name="inId">入場ID</param>
        /// <param name="outId">退場ID</param>
        /// <param name="waitAnimationName">待機アニメーション名</param>
        /// <param name="background">背景</param>
        protected void UpdateAnimator(Animator animator, int inId, int outId, string waitAnimationName, GameObject background)
        {
            AnimatorStateInfo animatorStateInfo = animator.GetCurrentAnimatorStateInfo(0);
            if (animatorStateInfo.shortNameHash.Equals(inId))
            {
                if (animatorStateInfo.normalizedTime >= 1.0f)
                {
                    animator.Play(waitAnimationName);
                }
            }
            if (animatorStateInfo.shortNameHash.Equals(leftOutId))
            {
                if (animatorStateInfo.normalizedTime >= 1.0f)
                {
                    background.SetActive(false);
                }
            }
        }

        /// <summary>
        /// 顔画像取得
        /// </summary>
        /// <param name="faceTextures">顔画像一覧</param>
        /// <param name="advFaceMaster">advFaceMaster</param>
        /// <param name="characterName">キャラクター名</param>
        /// <param name="faceTag">顔のファイル名のタグ</param>
        /// <returns></returns>
        protected async UniTask<Sprite> GetFaceTexture(string imageName, string faceTag)
        {
            stringBuilder.Clear();
            stringBuilder.Append(imageName);
            stringBuilder.Append(faceTag);
            var newTexture = await ResourceManager.Instance.LoadSpriteAsync("AdvFaceIcon", stringBuilder.ToString());
            return newTexture;
        }

        private void Update()
        {
            UpdateAnimator(faceLeftAnimator, leftInId, leftOutId, leftWaitAnimationName, backgroundLeft);
            UpdateAnimator(faceRightAnimator, rightInId, rightOutId, rightWaitAnimationName, backgroundRight);
        }

        private void Awake()
        {
            characterNameLocalLeft = characterNameTransform.localPosition.x;
            backgroundLeft.SetActive(false);
            backgroundRight.SetActive(false);
            leftInId = Animator.StringToHash(leftInAnimationName);
            leftOutId = Animator.StringToHash(leftOutAnimationName);
            rightInId = Animator.StringToHash(rightInAnimationName);
            rightOutId = Animator.StringToHash(rightOutAnimationName);
            faceLeftAnimator.keepAnimatorControllerStateOnDisable = true;
            faceRightAnimator.keepAnimatorControllerStateOnDisable = true;
        }
    }
}
