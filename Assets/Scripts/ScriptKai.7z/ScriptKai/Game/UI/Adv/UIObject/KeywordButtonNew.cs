using Adventure.Controller;
using Cysharp.Threading.Tasks;
using Game.ScriptEngine;
using static Game.ScriptEngine.ScriptEngine;
using Pheonix.Core;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;
using UnityEngine.UI;

public class KeywordButtonNew : MonoBehaviour
{
    [SerializeField] UIText text;
    [SerializeField] TextMeshProUGUI TMP;
    [SerializeField] Image img1;
    [SerializeField] Image img2;
    [SerializeField] Image img3;
    [SerializeField] Image img4;

    [SerializeField] PrivateTalkController privateTalkController;

    [SerializeField] Button btn;
    [SerializeField] Transform parent;
    [SerializeField] GameObject Tap;
    [SerializeField] GameObject scroll;
    [SerializeField] GameObject bg;
    [SerializeField] GameObject selectKeyParticle;
    [SerializeField] GameObject Mask;


    public void Setup(int keywordId, List<int> deletekeywords, int teabreaklevel, long charaid)
    {
        var keywordMaster = DataManager.Instance.Master.Keyword[keywordId];

        //��id
        var id = DataManager.Instance.Master.PrivateTalk.Values.First(x => x.keywordId == keywordId && x.characterMasterId == charaid).id;

        var master = DataManager.Instance.Master.BattleCharacter.Values.Where(item => item.characterMasterId == charaid).FirstOrDefault();
        var charaName = LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.CHARACTER_NAME, master.id.ToString());

        if (privateTalkController.isKeywordLocked(keywordId, keywordMaster))
        {
            btn.onClick.AddListener(() => { 
                StartCoroutine(ShowParticle(1f, async () => { 
                    selectKeyParticle.SetActive(false);
                    Mask.SetActive(false);
                    await OnInvalidKeywordClick(master.id, charaName, "HAVENT_UNLOCKED");
                }));
            });

            img1.gameObject.SetActive(true);
            TMP.text = "???";
            TMP.color = new Color(119f / 255f, 119f / 255f, 119f / 255f);
            return;
        }
        if (deletekeywords.Contains(id))
        {
            btn.onClick.AddListener(() => {
                StartCoroutine(ShowParticle(1f, async () => {
                    selectKeyParticle.SetActive(false);
                    Mask.SetActive(false);
                    await OnInvalidKeywordClick(master.id, charaName, "Have_Done_This_Time");
                }));
            });

            img2.gameObject.SetActive(true);
            text.SetLabel(LocalizeManager.DATA_TYPE.KEYWORD, keywordId.ToString());
            return;
        }

        if (isReaded(keywordId, charaid))
        {
            btn.onClick.AddListener(() => {
                StartCoroutine(ShowParticle(1f, () => {
                    selectKeyParticle.SetActive(false);
                    Mask.SetActive(false);
                    privateTalkController.SetCharacterPosition(master.id, 0); 
                    SetEnd(keywordId, charaid);
                }));
            });

            img4.gameObject.SetActive(true);
            text.SetLabel(LocalizeManager.DATA_TYPE.KEYWORD, keywordId.ToString());
            return;
        }
        else
        {
            btn.onClick.AddListener(() => {
                StartCoroutine(ShowParticle(1f, () => {
                    selectKeyParticle.SetActive(false);
                    Mask.SetActive(false);
                    privateTalkController.SetCharacterPosition(master.id, 0);
                    SetEnd(keywordId, charaid);
                }));
            });
            img3.gameObject.SetActive(true);
            text.SetLabel(LocalizeManager.DATA_TYPE.KEYWORD, keywordId.ToString());
            return;
        }

    }

    private async UniTask OnInvalidKeywordClick(long battlecharacterId, string charaName, string text)
    {
        Tap.SetActive(true);
        scroll.SetActive(false);
        bg.SetActive(false);
        privateTalkController.SetCharacterPosition(battlecharacterId, 0);
        await GetInstance().commandManager.Text.Execute(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ADV, text), charaName);
    }


    public IEnumerator ShowParticle(float duration, Action action = null)
    {
        Debug.Log("taptap");
        selectKeyParticle.SetActive(true);
        Mask.SetActive(true);
        PxSoundManager.Instance.PlaySe("feedbackSE_interface_open01");
        yield return new WaitForSeconds(duration);
        action?.Invoke();
    }


    private bool isReaded(int keywordId, long characterId)
    {
        var keyword = DataManager.Instance.Player.Keyword.TryGet(keywordId);

        return keyword != null && keyword.CharacterMasterIds.Contains(characterId);
    }

    public void SetEnd(int keywordid, long characterid)
    {
        Debug.Log(keywordid + "    " + characterid);

        privateTalkController.TargetPrivateTalkMaster = DataManager.Instance.Master.PrivateTalk.Values.First(x => x.keywordId == keywordid && x.characterMasterId == characterid);

        Debug.Log(privateTalkController.TargetPrivateTalkMaster.script);

        //��id
        int targetId = privateTalkController.TargetPrivateTalkMaster.id;

        Debug.Log("targetid:" + targetId);

        privateTalkController.masterChoseKeys.Add(targetId);
        privateTalkController.masterDeleteKeys.Add(targetId);

        int i = 1; //��һ����ɾ
        while (i < parent.childCount)
        {
            Destroy(parent.GetChild(i++).gameObject);
        }

        privateTalkController.AddBonds += privateTalkController.TargetPrivateTalkMaster.bondsValue;
        CallScript(privateTalkController.TargetPrivateTalkMaster);
        privateTalkController.enabled = false;
    }

    protected void CallScript(PrivateTalkMaster privateTalkMaster)
    {
        ScriptEngine instance = GetInstance();
        if (instance.scripts.ContainsKey(privateTalkMaster.script))
        {
            Debug.Log("ohhhhhhh");
            instance.CallScript(privateTalkMaster.script);
        }
    }
}
