﻿
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using Pheonix.Core;

namespace Adventure.UI
{
    /// <summary>
    /// キーワードボタン
    /// </summary>
    public class KeywordButton : MonoBehaviour
    {
        /// <summary>
        /// 状態
        /// </summary>
        public enum State
        {
            /// <summary>
            /// 何もしてない
            /// </summary>
            None,
            /// <summary>
            /// 待ち
            /// </summary>
            Wait,
            /// <summary>
            /// 消えてる
            /// </summary>
            Disappear,
            /// <summary>
            /// OK
            /// </summary>
            Ok,
        }

        [SerializeField]
        [Tooltip("ボタン")]
        private Button button = null;
        [SerializeField]
        [Tooltip("テキスト")]
        private UIText text = null;
        [SerializeField]
        [Tooltip("Newマーク")]
        private GameObject newMark = null;
        [SerializeField]
        [Tooltip("アニメーター")]
        private Animator animator = null;
        [SerializeField]
        [Tooltip("okのアニメーションクリップ")]
        private AnimationClip okAnimationClip = null;
        [SerializeField]
        [Tooltip("noのアニメーションクリップ")]
        private AnimationClip noAnimationClip = null;
        [SerializeField]
        private UnityEvent onClick = new UnityEvent();
        [SerializeField]
        private UnityEvent onOk = new UnityEvent();
        [SerializeField]
        private UnityEvent onDisapper = new UnityEvent();

        private int okAnimationId = 0;
        private int noAnimationId = 0;
        private State state = State.None;

        /// <summary>
        /// クリック時のコールバック
        /// </summary>
        public UnityEvent OnClick => onClick;
        /// <summary>
        /// OK時のコールバック
        /// </summary>
        public UnityEvent OnOk => onOk;
        /// <summary>
        /// 消えた時のコールバック
        /// </summary>
        public UnityEvent OnDisapper => onDisapper;

        /// <summary>
        /// プライベート会話マスター
        /// </summary>
        public KeywordMaster Master { get; protected set; } = null;

        /// <summary>
        /// テキスト設定
        /// </summary>
        /// <param name="privateTalkMaster">プライベート会話マスター</param>
        public void SetText(KeywordMaster master, bool isOld)
        {
            enabled = true;
            Master = master;
            text.SetLabel(LocalizeManager.DATA_TYPE.KEYWORD, master.id.ToString());
            newMark.SetActive(!isOld);
            button.onClick.AddListener(() =>
            {
                button.onClick.RemoveAllListeners();
                animator.Play(okAnimationClip.name, 0, 0.0f);
                state = State.Ok;
                onClick.Invoke();
            });
            state = State.Wait;
        }

        /// <summary>
        /// 消える設定
        /// </summary>
        public void SetDisapper()
        {
            animator.Play(noAnimationClip.name, 0, 0.0f);
            button.onClick.RemoveAllListeners();
            state = State.Disappear;
        }

        /// <summary>
        /// 何もない状態設定
        /// </summary>
        protected void SetStateNone()
        {
            state = State.None;
            enabled = false;
        }

        private void Awake()
        {
            okAnimationId = Animator.StringToHash(okAnimationClip.name);
            noAnimationId = Animator.StringToHash(noAnimationClip.name);
            enabled = false;
        }

        private void Update()
        {
            AnimatorStateInfo animatorStateInfo = animator.GetCurrentAnimatorStateInfo(0);
            switch (state)
            {
                case State.Ok:
                    if (animatorStateInfo.shortNameHash.Equals(okAnimationId))
                    {
                        if (animatorStateInfo.normalizedTime >= 1.0f)
                        {
                            SetStateNone();
                            onOk.Invoke();
                        }
                    }
                    break;
                case State.Disappear:
                    if (animatorStateInfo.shortNameHash.Equals(noAnimationId))
                    {
                        if (animatorStateInfo.normalizedTime >= 1.0f)
                        {
                            SetStateNone();
                            onDisapper.Invoke();
                        }
                    }
                    break;
            }
        }
    }
}
