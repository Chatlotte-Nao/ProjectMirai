﻿using UnityEngine.Events;
using UnityEngine.UI;

namespace Adventure.UI
{
    /// <summary>
    /// プライベート選択肢ボタン
    /// </summary>
    public class PrivateSelectionButton : SelectionButton
    {
        /// <summary>
        /// 会話ポイント
        /// </summary>
        public int TalkPoint { get; private set; } = 0;

        /// <summary>
        /// テキスト設定
        /// </summary>
        /// <param name="message">メッセージ</param>
        /// <param name="talkPoint">会話ポイント</param>
        /// <param name="choiceNumber">選択肢数</param>
        public void SetText(string message, int talkPoint, int choiceNumber)
        {
            SetText(message, choiceNumber);   
            TalkPoint = talkPoint;
        }

        /// <summary>
        /// クリック時のイベントの追加
        /// </summary>
        /// <param name="unityAction">クリック時のイベント</param>
        public void OnClickAddListener(UnityAction unityAction)
        {
            Button.onClick.AddListener(unityAction);
        }
    }
}
