﻿using UnityEngine;
using UnityEngine.UI;
using Adventure.Util;

namespace Adventure.UI
{
    /// <summary>
    /// 収納ボタン
    /// </summary>
    public class StorageButton : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("親")]
        private GameObject parent = null;
        [SerializeField]
        [Tooltip("ボタン")]
        private Button button = null;
        [SerializeField]
        [Tooltip("アニメーター")]
        private Animator animator = null;
        [SerializeField]
        [Tooltip("開くトリガー名")]
        private string openTriggerName = "Open";
        [SerializeField]
        [Tooltip("閉じるトリガー名")]
        private string closeTriggerName = "Close";
        [SerializeField]
        [Tooltip("開く状態名")]
        private string openStateName = "Open";
        [SerializeField]
        [Tooltip("閉じる状態名")]
        private string closeStateName = "Close";

        private int openId = 0;
        private int closeId = 0;

        // Start is called before the first frame update
        private void Start()
        {
            button?.onClick.AddListener(() =>
            {
                SoundExpansion.PlaySe(SoundConstants.SE_SELECT);

                if (animator != null)
                {
                    AnimatorStateInfo animatorStateInfo = animator.GetCurrentAnimatorStateInfo(0);
                    if (animatorStateInfo.shortNameHash == openId)
                    {
                        animator.SetTrigger(closeTriggerName);
                    }
                    else if (animatorStateInfo.shortNameHash == closeId)
                    {
                        animator.SetTrigger(openTriggerName);
                    }
                }
            });
        }

        private void Awake()
        {
            if (animator == null)
            {
                return;
            }
            animator.keepAnimatorControllerStateOnDisable = true;

            Vector3 localPosition = parent.transform.localPosition;
            localPosition.x -= Screen.width - Screen.safeArea.max.x;
            parent.transform.localPosition = localPosition;

            openId = Animator.StringToHash(openStateName);
            closeId = Animator.StringToHash(closeStateName);
        }
    }
}
