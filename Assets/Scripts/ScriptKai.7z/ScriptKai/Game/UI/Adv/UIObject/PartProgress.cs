﻿using Game.ScriptEngine;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using static Game.ScriptEngine.ScenarioScript;

namespace Adventure.UI
{
    /// <summary>
    /// パート進捗
    /// </summary>
    public class PartProgress : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("画像")]
        private Image image = null;
        [SerializeField]
        [Tooltip("何タップ以上なら表示")]
        private int showMoreTaps = 5;

        /// <summary>
        /// 設定
        /// </summary>
        /// <param name="scenarioScript">シナリオスクリプト</param>
        /// <param name="startIndex">開始位置</param>
        public void Set(ScenarioScript scenarioScript, int startIndex)
        {
            List<CommandAction> commands = scenarioScript.commands;
            int totalCount = GetTextCommandsNumber(commands, 0);
            if (totalCount < showMoreTaps)
            {
                image.fillAmount = 0.0f;
            }
            else
            {
                int remainingCount = GetTextCommandsNumber(commands, startIndex);
                image.fillAmount = 1.0f - (float)remainingCount / totalCount;
            }
        }

        /// <summary>
        /// テキストコマンド数取得
        /// </summary>
        /// <param name="commands">コマンド</param>
        /// <param name="startIndex">開始位置</param>
        /// <returns></returns>
        protected int GetTextCommandsNumber(List<CommandAction> commands, int startIndex)
        {
            int count = 0;
            for (int i = startIndex; i < commands.Count; i++)
            {
                var commandName = commands[i].command.TrimEnd('&').ToLower();
                if (commandName == "text" || commandName == "msg")
                {
                    count++;
                }
            }
            return count;
        }
    }
}
