﻿using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Adventure.UI
{
    /// <summary>
    /// 制限時間スライダー
    /// </summary>
    public class TimeLimitSlider : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("スライダー")]
        private Slider slider = null;

        private float startSeconds = 0.0f;
        private float timeLimit = 0.0f;
        private UnityAction callTimeOver = null;

        /// <summary>
        /// 実行
        /// </summary>
        /// <param name="timeLimit">制限時間(s)</param>
        /// <param name="callTimeOver">タイムオーバー時に呼ばれる</param>
        public void Run(float timeLimit, UnityAction callTimeOver = null)
        {
            this.timeLimit = timeLimit;
            this.callTimeOver = callTimeOver;
            slider.maxValue = timeLimit;
            slider.value = timeLimit;
            startSeconds = Time.time;
            enabled = true;
        }

        // Update is called once per frame
        void Update()
        {
            float elapsedSeconds = Time.time - startSeconds;
            slider.value = timeLimit - elapsedSeconds;
            if (slider.value <= 0.0f)
            {
                callTimeOver();
                enabled = false;
            }
        }
    }
}
