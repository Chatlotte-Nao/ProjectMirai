﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Adventure.UI
{
    /// <summary>
    /// 選択ボタン
    /// </summary>
    public class SelectionButton : MonoBehaviour
    {
        /// <summary>
        /// 状態
        /// </summary>
        public enum State
        {
            /// <summary>
            /// 何もしてない
            /// </summary>
            None,
            /// <summary>
            /// 準備
            /// </summary>
            Ready,
            /// <summary>
            /// 動作
            /// </summary>
            Move,
        }

        [SerializeField]
        [Tooltip("ボタン")]
        private Button button = null;
        [SerializeField]
        [Tooltip("テキストメッシュプロUGUI")]
        private TextMeshProUGUI textMeshProUGUI = null;
        [SerializeField]
        [Tooltip("選択肢位置")]
        private Vector2[] choicePositions = null;
        [SerializeField]
        [Tooltip("下の選択肢位置")]
        private Vector2 bottmChoicePosition = Vector2.zero;
        [SerializeField]
        [Tooltip("ループ時間(s)")]
        private float roopTime = 2.0f;
        [SerializeField]
        [Tooltip("振幅")]
        private float amplitude = 2.5f;

        /// <summary>
        /// ボタン
        /// </summary>
        public Button Button => button;

        /// <summary>
        /// 画面外のy座標
        /// </summary>
        public const float OFF_SCREEN_Y = 10000.0f;

        private string text = null;
        private float startY = 0.0f;
        private float startTime = 0.0f;
        private State state = State.None;

        /// <summary>
        /// テキスト設定
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <param name="choiceNumber">選択肢数</param>
        /// <param name="isBottomPosition">true:下の位置 false:通常の位置</param>
        public void SetText(string text, int choiceNumber, bool isBottomPosition = false)
        {
            Vector3 localPosition = button.transform.localPosition;
            if (isBottomPosition)
            {
                localPosition = bottmChoicePosition;
            }
            else
            {
                if (choiceNumber <= choicePositions.Length)
                {
                    Vector2 setLocalPosition = choicePositions[choiceNumber - 1];
                    localPosition.x = setLocalPosition.x;
                    localPosition.y = setLocalPosition.y;
                }
            }
            button.gameObject.SetActive(true);

            startY = localPosition.y;
            localPosition.y = OFF_SCREEN_Y;
            button.transform.localPosition = localPosition;
           
            this.text = text;
            state = State.Ready;
        }

        public void SetSelected(bool val)
        {
            GetComponent<CanvasGroup>().alpha = val?0.5f:1f;
        }
        
        private void Update()
        {
            switch (state)
            {
                case State.Ready:
                    {
                        Vector3 localPosition = button.transform.localPosition;
                        localPosition.y = startY;
                        button.transform.localPosition = localPosition;

                        textMeshProUGUI.text = text;

                        startTime = Time.time;

                        state = State.Move;
                    }
                    break;
                case State.Move:
                    {
                        float elapsedTime = (Time.time - startTime) / roopTime;
                        float theta = Mathf.Repeat(elapsedTime * 2.0f * Mathf.PI, 2.0f * Mathf.PI);
                        Vector3 localPosition = button.transform.localPosition;
                        localPosition.y = (amplitude * Mathf.Sin(theta)) + startY;
                        button.transform.localPosition = localPosition;
                    }
                    break;
            }
        }
    }
}
