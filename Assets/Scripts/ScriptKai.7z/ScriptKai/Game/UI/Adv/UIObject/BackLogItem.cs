﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;
using Adventure.Util;

namespace Adventure.UI
{
    /// <summary>
    /// バックログ項目
    /// </summary>
    public class BackLogItem : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("話者名のテキスト")]
        private TextMeshProUGUI speakerText = null;
        [SerializeField]
        [Tooltip("ボイスボタン")]
        private Button voiceButton = null;
        [SerializeField]
        [Tooltip("フェイスウィンドウ")]
        private FaceWindow faceWindow = null;
        [SerializeField]
        [Tooltip("ルビテキストスクロール")]
        private RubyTextScroll rubyTextScroll = null;

        private string voiceName = null;

        /// <summary>
        /// バックログ設定
        /// </summary>
        /// <param name="speakerName">話者名</param>
        /// <param name="speakerNameText">話者名テキスト</param>
        /// <param name="rubyTextScroll">ルビテキストスクロール</param>
        /// <param name="voiceName">ボイス名</param>
        public void SetBackLog(string speakerName, string speakerNameText, RubyTextScroll rubyTextScroll, string voiceName)
        {
            this.voiceName = voiceName;
            speakerText.text = speakerNameText;
            this.rubyTextScroll.SetRuby(rubyTextScroll);
            voiceButton.gameObject.SetActive(string.IsNullOrEmpty(voiceName) ? false : true);
            faceWindow.SetIcon(speakerName);
        }

        /// <summary>
        /// voiceボタンがクリックした時
        /// </summary>
        public void OnClickVoice()
        {
           SoundExpansion.PlayVoice(voiceName);
        }
    }
}
