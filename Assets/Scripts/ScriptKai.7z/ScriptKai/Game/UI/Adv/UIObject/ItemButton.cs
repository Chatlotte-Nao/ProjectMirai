﻿using UnityEngine;
using TMPro;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Adventure.UI
{
    /// <summary>
    /// アイテムボタン
    /// </summary>
    public class ItemButton : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("ボタン")]
        private Button button = null;
        [SerializeField]
        [Tooltip("アイコン画像")]
        private Image iconImage = null;
        [SerializeField]
        [Tooltip("個数テキスト")]
        private TMP_Text numberText = null;

        private UnityAction onClick = null;

        private string initNumber = null;

        /// <summary>
        /// セットアップ
        /// </summary>
        /// <param name="number">個数</param>
        /// <param name="sprite">スプライト</param>
        /// <param name="onClick">クリックした時のコールバック</param>
        public void Setup(int number, Sprite sprite, UnityAction onClick = null)
        {
            if (this.onClick != null)
            {
                button.onClick.RemoveListener(this.onClick);
            }
            this.onClick = onClick;

            if (numberText != null)
            {
                if (initNumber == null)
                {
                    initNumber = numberText.text;
                }
                numberText.text = string.Format(initNumber, number);
            }

            if (iconImage != null)
            {
                iconImage.sprite = sprite;
                iconImage.SetNativeSize();
            }

            button.interactable = number > 0 ? true : false;
            button.onClick.AddListener(onClick);
        }
    }
}
