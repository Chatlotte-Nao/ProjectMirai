﻿using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Adventure.UI
{
    /// <summary>
    /// ルビテキストスクロール
    /// </summary>
    public class RubyTextScroll : UIBehaviour, IMeshModifier
    {
        /// <summary>
        /// ルビ
        /// </summary>
        public class Ruby
        {
            /// <summary>
            /// ルビ名
            /// </summary>
            public string rubyName { set; get; } = null;
            /// <summary>
            /// 対象となる名前
            /// </summary>
            public string targetName { set; get; } = null;
            /// <summary>
            /// 開始時の対象索引
            /// </summary>
            public int startTargetIndex { set; get; } = 0;
            /// <summary>
            /// 開始時のルビ索引
            /// </summary>
            public int startRubyIndex { set; get; } = 0;
            /// <summary>
            /// 終了時の対象索引
            /// </summary>
            public int endTargetIndex { set; get; } = 0;
            /// <summary>
            /// 終了時のルビ索引
            /// </summary>
            public int endRubyIndex { set; get; } = 0;
            /// <summary>
            /// 対象の幅
            /// </summary>
            public float targetWidth { set; get; } = 0.0f;
            /// <summary>
            /// ルビの幅
            /// </summary>
            public float rubyWidth { set; get; } = 0.0f;
        }
        [SerializeField]
        [Tooltip("メッセージテキスト")]
        private Text messageText = null;
        [SerializeField]
        [Tooltip("テキストスピード")]
        private float textSpeed = 30.0f;
        [SerializeField]
        [Tooltip("ルビのスケールy座標")]
        private float rubyScaleY = 0.87f;
        [SerializeField]
        [Tooltip("タイムスケールに影響するか")]
        private bool isUnscaledTime = false;

        /// <summary>
        /// タグ右
        /// </summary>
        public const string RIGHT_TAG = ">";
        /// <summary>
        /// タグ名size
        /// </summary>
        public const string TAG_NAME_SIZE = "size";
        /// <summary>
        /// タグ名ruby
        /// </summary>
        public const string TAG_NAME_RUBY = "ruby";
        /// <summary>
        /// 開始タグ左
        /// </summary>
        public const string START_LEFT_TAG = "<";
        /// <summary>
        /// 終了タグ左
        /// </summary>
        public const string END_LEFT_TAG = "</";

        private List<Ruby> rubies = new List<Ruby>();
        private string startLeftTagRuby = null;
        private string startLeftTagSize = null;
        private string endTagRuby = null;
        private string endTagSize = null;
        private int rubyFontSize = 0;
        private StringBuilder stringBuilder = new StringBuilder();
        private string startTagSize = null;
        private string nowText = null;
        private float elapsedSeconds = 0.0f;
        private int previousTextIndex = 0;
        private int nowRubyIndex = 0;
        private float textLength = 0.0f;
        private int characterCount = 0;
        private TextGenerator textGenerator = null;
        private TextGenerationSettings textGenerationSettings;

        /// <summary>
        /// テキスト
        /// </summary>
        public string Text { get; private set; } = null;
        /// <summary>
        /// オリジナルテキスト
        /// </summary>
        public string OriginalText { get; set; } = null;
        
        /// <summary>
        /// テキストスピード
        /// </summary>
        public float TextSpeed
        {
            get => textSpeed;
            set => textSpeed = value;
        }

        /// <summary>
        /// 初期化
        /// </summary>
        public void Init()
        {
            enabled = true;

            rubies.Clear();

            rubyFontSize = GetRubyFontSize();
            string fontSizeText = rubyFontSize.ToString();

            stringBuilder.Clear();
            stringBuilder.Append(startLeftTagSize);
            stringBuilder.Append(fontSizeText);
            stringBuilder.Append(RIGHT_TAG);
            startTagSize = stringBuilder.ToString();

            int characterCount = 0;
            for (int i = 0; i < OriginalText.Length; i++)
            {
                int tagLeftNumber = OriginalText.IndexOf(startLeftTagRuby, i);
                if (tagLeftNumber >= 0)
                {
                    int tagRightNumber = OriginalText.IndexOf(RIGHT_TAG, tagLeftNumber + startLeftTagRuby.Length);
                    if (tagRightNumber > 0)
                    {
                        for (int j = i; j < tagLeftNumber; j++)
                        {
                            if ((OriginalText[j] != '\n') && (!GetIsBlank(OriginalText[j])))
                            {
                                characterCount++;
                            }
                        }
                        int tagEndRightNumber = OriginalText.IndexOf(endTagRuby, tagRightNumber);

                        Ruby ruby = new Ruby();
                        ruby.targetName = OriginalText.Substring(tagRightNumber + 1, tagEndRightNumber - tagRightNumber - 1);
                        ruby.rubyName = OriginalText.Substring(tagLeftNumber + startLeftTagRuby.Length, tagRightNumber - tagLeftNumber - startLeftTagRuby.Length);
                        ruby.startTargetIndex = characterCount;
                        ruby.endTargetIndex = GetEndTargetIndex(ruby);
                        ruby.startRubyIndex = GetStartRubyIndex(ruby);
                        ruby.endRubyIndex = GetEndRubyIndex(ruby);
                        ruby.targetWidth = GetTargetWidth(ruby.targetName);
                        ruby.rubyWidth = GetRubyWidth(ruby.rubyName);
                        rubies.Add(ruby);
                        characterCount += ruby.targetName.Length + ruby.rubyName.Length;
                        i = tagEndRightNumber + endTagRuby.Length - 1;
                        continue;
                    }
                }
                if ((OriginalText[i] != '\n') && (!GetIsBlank(OriginalText[i])))
                {
                    characterCount++;
                }
            }

            string text = OriginalText;
            for (int i = 0; i < rubies.Count; i++)
            {
                stringBuilder.Clear();
                stringBuilder.Append(startLeftTagRuby);
                stringBuilder.Append(rubies[i].rubyName);
                stringBuilder.Append(RIGHT_TAG);
                stringBuilder.Append(rubies[i].targetName);
                string oldText = stringBuilder.ToString();

                stringBuilder.Clear();
                stringBuilder.Append(rubies[i].targetName);
                stringBuilder.Append(startTagSize);
                stringBuilder.Append(rubies[i].rubyName);
                string newText = stringBuilder.ToString();

                text = text.Replace(oldText, newText);
            }
            Text = text.Replace(endTagRuby, endTagSize);
            InitText();
            previousTextIndex = -1;
            elapsedSeconds = GetTime();
        }

        /// <summary>
        /// 動作
        /// </summary>
        public void Move()
        {
            float nowTime = GetTime();
            textLength += (nowTime - elapsedSeconds) * TextSpeed;
            elapsedSeconds = nowTime;
            if (textLength == 0.0f)
            {
                return;
            }
            int nowTextIndex = (int)textLength;
            if (previousTextIndex != nowTextIndex)
            {
                characterCount = 0;
                previousTextIndex = nowTextIndex;
                nowRubyIndex = 0;
                if (nowTextIndex < Text.Length)
                {
                    for (int i = 0; i <= nowTextIndex; i++)
                    {
                        int tagLeftNumber = Text.IndexOf(START_LEFT_TAG, i, nowTextIndex - i + 1);
                        if (tagLeftNumber >= 0)
                        {
                            int tagRightNumber = Text.IndexOf(RIGHT_TAG, tagLeftNumber + 1);
                            if (tagRightNumber >= 0)
                            {
                                for (int j = i; j < tagLeftNumber; j++)
                                {
                                    if ((Text[j] != '\n') && (!GetIsBlank(Text[j])))
                                    {
                                        characterCount++;
                                    }
                                }
                                nowTextIndex += tagRightNumber - tagLeftNumber + 1;
                                if ((nowRubyIndex < rubies.Count) && (characterCount == rubies[nowRubyIndex].startRubyIndex))
                                {
                                    characterCount += rubies[nowRubyIndex].rubyName.Length;
                                    nowTextIndex += rubies[nowRubyIndex].rubyName.Length + endTagSize.Length;
                                    i = tagRightNumber + rubies[nowRubyIndex].rubyName.Length + endTagSize.Length;
                                    nowRubyIndex++;
                                }
                                else
                                {
                                    i = tagRightNumber;
                                }
                                if (nowTextIndex >= Text.Length)
                                {
                                    break;
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        }
                        else
                        {
                            if ((nowRubyIndex < rubies.Count) && (characterCount == (rubies[nowRubyIndex].startTargetIndex + rubies[nowRubyIndex].targetName.Length)))
                            {
                                int startTagNumber = startLeftTagSize.Length + rubyFontSize.ToString().Length + RIGHT_TAG.Length;
                                nowTextIndex += startTagNumber + rubies[nowRubyIndex].rubyName.Length + endTagSize.Length;
                                nowRubyIndex++;
                            }
                        }
                        for (int j = i; j <= nowTextIndex; j++)
                        {
                            if ((j < Text.Length) && (Text[j] != '\n') && (!GetIsBlank(Text[j])))
                            {
                                characterCount++;
                            }
                        }
                        break;
                    }
                }
                if (nowTextIndex >= Text.Length)
                {
                    messageText.text = Text;
                    if (nowRubyIndex > 0)
                    {
                        Ruby ruby = rubies[nowRubyIndex - 1];
                        ruby.endRubyIndex = GetEndRubyIndex(ruby);
                    }
                    enabled = false;
                }
                else
                {
                    ResetRubyIndex();
                    nowText = Text.Substring(0, nowTextIndex + 1);
                    int tagLeftNumber = nowText.LastIndexOf(START_LEFT_TAG);
                    if (tagLeftNumber > nowText.LastIndexOf(END_LEFT_TAG))
                    {
                        int tagEndRightNumber = Text.IndexOf(RIGHT_TAG, nowTextIndex);
                        int tagEndLeftNumber = Text.IndexOf(END_LEFT_TAG, nowTextIndex);
                        stringBuilder.Clear();
                        stringBuilder.Append(nowText);
                        stringBuilder.Append(Text.Substring(tagEndLeftNumber, tagEndRightNumber - tagEndLeftNumber + 1));
                        nowText = stringBuilder.ToString();
                    }
                    messageText.text = nowText;
                }
            }
            if ((rubies.Count > 0) && (nowRubyIndex < rubies.Count))
            {
                Ruby ruby = rubies[nowRubyIndex];
                int textIndex = characterCount - 1;
                if ((ruby.startTargetIndex <= textIndex) && (textIndex <= ruby.endTargetIndex))
                {
                    float nowTargetIndex = textIndex - ruby.startTargetIndex + textLength - (int)textLength;
                    float nowRubyIndex = nowTargetIndex * ruby.rubyName.Length / ruby.targetName.Length;
                    ruby.endTargetIndex = ruby.startTargetIndex + (int)nowTargetIndex;
                    ruby.startRubyIndex = ruby.endTargetIndex + 1;
                    ruby.endRubyIndex = ruby.startRubyIndex + (int)nowRubyIndex;
                    stringBuilder.Clear();
                    stringBuilder.Append(nowText);
                    stringBuilder.Append(startTagSize);
                    stringBuilder.Append(ruby.rubyName.Substring(0, (int)nowRubyIndex));
                    stringBuilder.Append(endTagSize);
                    messageText.text = stringBuilder.ToString();
                }
            }
        }

        /// <summary>
        /// ルビ設定
        /// </summary>
        /// <param name="rubyTextScroll">ルビテキストスクロール</param>
        public void SetRuby(RubyTextScroll rubyTextScroll)
        {
            messageText.text = rubyTextScroll.Text;
            Text = rubyTextScroll.Text;
            OriginalText = rubyTextScroll.OriginalText;
            rubyFontSize = GetRubyFontSize();
            rubies.Clear();
            for (int i = 0; i < rubyTextScroll.rubies.Count; i++)
            {
                rubies.Add(rubyTextScroll.rubies[i]);
            }
        }

        /// <summary>
        /// 終了
        /// </summary>
        public void End()
        {
            for (int i = 0; i < rubies.Count; i++)
            {
                Ruby ruby = rubies[i];
                ruby.endTargetIndex = GetEndTargetIndex(ruby);
                ruby.startRubyIndex = GetStartRubyIndex(ruby);
                ruby.endRubyIndex = GetEndRubyIndex(ruby);
            }
        }

        /// <summary>
        /// ルビのフォントサイズ取得
        /// </summary>
        /// <returns></returns>
        public int GetRubyFontSize()
        {
            return messageText.fontSize / 2;
        }

        /// <summary>
        /// ゲーム開始からの時間(秒)取得
        /// </summary>
        /// <returns></returns>
        protected float GetTime()
        {
            return isUnscaledTime ? Time.unscaledTime : Time.time;
        }

        /// <summary>
        /// 開始時のルビ索引取得
        /// </summary>
        /// <param name="ruby">ルビ</param>
        /// <returns></returns>
        protected int GetStartRubyIndex(Ruby ruby)
        {
            return ruby.startTargetIndex + DeleteBlank(ruby.targetName).Length;
        }

        /// <summary>
        /// 終了時の対象索引取得
        /// </summary>
        /// <param name="ruby"></param>
        /// <returns></returns>
        protected int GetEndTargetIndex(Ruby ruby)
        {
            return ruby.startTargetIndex + DeleteBlank(ruby.targetName).Length - 1;
        }

        /// <summary>
        /// 終了時のルビ索引取得
        /// </summary>
        /// <param name="ruby">ルビ</param>
        /// <returns></returns>
        protected int GetEndRubyIndex(Ruby ruby)
        {
            return ruby.startRubyIndex + ruby.rubyName.Length - 1;
        }

        /// <summary>
        /// テキストの初期化
        /// </summary>
        protected void InitText()
        {
            messageText.text = null;
            textLength = 0.0f;
        }

        /// <summary>
        /// ルビ索引のリセット
        /// </summary>
        protected void ResetRubyIndex()
        {
            for (int i = 0; i < rubies.Count; i++)
            {
                Ruby ruby = rubies[i];
                ruby.startRubyIndex = GetStartRubyIndex(ruby);
                ruby.endRubyIndex = GetEndRubyIndex(ruby);
                ruby.endTargetIndex = GetEndTargetIndex(ruby);
            }
        }

        /// <summary>
        /// メッシュを修正
        /// </summary>
        /// <param name="mesh">メッシュ</param>
        public void ModifyMesh(Mesh mesh)
        {
        }

        /// <summary>
        /// メッシュを修正
        /// </summary>
        /// <param name="verts">頂点情報</param>
        public void ModifyMesh(VertexHelper verts)
        {
            List<UIVertex> vertexList = new List<UIVertex>();
            verts.GetUIVertexStream(vertexList);

            ModifyVertices(vertexList);

            verts.Clear();
            verts.AddUIVertexTriangleStream(vertexList);
        }

        /// <summary>
        /// 頂点を修正
        /// </summary>
        /// <param name="vertexList">頂点リスト</param>
        protected void ModifyVertices(List<UIVertex> vertexList)
        {
            const int CHARACTER_VERTEX_NUMBER = 6;
            char[] characters = messageText.text.ToCharArray();
            float offsetX = 0.0f;
            float offsetSpaceX = 0.0f;
            float offsetY = 0.0f;
            float rubyLength = 0.0f;
            float targetLength = 0.0f;
            float startTargetX = 0.0f;
            int rubyIndex = 0;
            int characterIndex = 0;
            for (int i = 0; i < vertexList.Count; i += CHARACTER_VERTEX_NUMBER)
            {
                offsetY = 0.0f;
                int index = i / CHARACTER_VERTEX_NUMBER;
                bool isTag = false;
                while (characterIndex < characters.Length)
                {
                    if (characters[characterIndex] == '<')
                    {
                        characterIndex++;
                        isTag = true;
                    }
                    else if (characters[characterIndex] == '>')
                    {
                        characterIndex++;
                        isTag = false;
                    }
                    else if (characters[characterIndex] == '\n')
                    {
                        offsetX = 0.0f;
                        characterIndex++;
                    }
                    else if (GetIsBlank(characters[characterIndex]))
                    {
                        characterIndex++;
                    }
                    else if (isTag)
                    {
                        characterIndex++;
                    }
                    else
                    {
                        break;
                    }
                }
                if ((0 < rubies.Count) && (rubyIndex < rubies.Count))
                {
                    Ruby ruby = rubies[rubyIndex];
                    if ((ruby.startTargetIndex <= index) && (index <= ruby.endTargetIndex))
                    {
                        if (index == ruby.startTargetIndex)
                        {
                            targetLength = ruby.targetWidth;
                            rubyLength = ruby.rubyWidth;
                            int startTargetNumber = CHARACTER_VERTEX_NUMBER * ruby.startTargetIndex;
                            startTargetX = vertexList[startTargetNumber].position.x;
                            if (targetLength < rubyLength)
                            {
                                offsetSpaceX = (rubyLength - targetLength) / (2.0f * ruby.targetName.Length);
                            }
                            else
                            {
                                offsetSpaceX = 0.0f;
                            }
                        }
                        else
                        {
                            if (targetLength < rubyLength)
                            {
                                offsetSpaceX += (rubyLength - targetLength) / ruby.targetName.Length;
                            }
                        }
                    }
                    else if ((ruby.startRubyIndex <= index) && (index <= ruby.endRubyIndex))
                    {
                        offsetY = rubyScaleY * messageText.fontSize;
                        if (index == ruby.startRubyIndex)
                        {
                            float targetWidth = vertexList[i].position.x - startTargetX;
                            if (targetLength > rubyLength)
                            {
                                offsetX -= rubyLength;
                                offsetSpaceX = ((targetLength - rubyLength) / (2.0f * ruby.rubyName.Length)) + (rubyLength - targetWidth);
                            }
                            else
                            {
                                offsetX -= targetWidth;
                                offsetSpaceX = 0.0f;
                            }
                        }
                        else
                        {
                            if (targetLength > rubyLength)
                            {
                                offsetSpaceX += (targetLength - rubyLength) / ruby.rubyName.Length;
                            }
                        }
                        if (index == (ruby.startRubyIndex + ruby.rubyName.Length - 1))
                        {
                            rubyIndex++;
                        }
                    }
                    else
                    {
                        offsetSpaceX = 0.0f;
                    }
                }
                else
                {
                    offsetSpaceX = 0.0f;
                }
                for (int j = 0; j < CHARACTER_VERTEX_NUMBER; j++)
                {
                    UIVertex element = vertexList[i + j];
                    element.position = new Vector3(element.position.x + offsetX + offsetSpaceX, element.position.y + offsetY, element.position.z);
                    vertexList[i + j] = element;
                }
                characterIndex++;
            }
        }

        /// <summary>
        /// 開始タグ左辺取得
        /// </summary>
        /// <param name="tagName">タグ名</param>
        /// <returns></returns>
        protected string GetStartLeftTag(string tagName)
        {
            stringBuilder.Clear();
            stringBuilder.Append(START_LEFT_TAG);
            stringBuilder.Append(tagName);
            stringBuilder.Append("=");
            return stringBuilder.ToString();
        }

        /// <summary>
        /// 終了タグ取得
        /// </summary>
        /// <param name="tagName">タグ名</param>
        /// <returns></returns>
        protected string GetEndTag(string tagName)
        {
            stringBuilder.Clear();
            stringBuilder.Append(END_LEFT_TAG);
            stringBuilder.Append(tagName);
            stringBuilder.Append(RIGHT_TAG);
            return stringBuilder.ToString();
        }

        /// <summary>
        /// 対象の幅を取得
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <returns></returns>
        protected float GetTargetWidth(string text)
        {
            return textGenerator.GetPreferredWidth(text, textGenerationSettings) / textGenerationSettings.scaleFactor;
        }

        /// <summary>
        /// ルビの幅を取得
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <returns></returns>
        protected float GetRubyWidth(string text)
        {
            stringBuilder.Clear();
            stringBuilder.Append(startTagSize);
            stringBuilder.Append(text);
            stringBuilder.Append(endTagSize);
            return GetTargetWidth(stringBuilder.ToString());
        }

        /// <summary>
        /// 空白除去
        /// </summary>
        /// <param name="text">テキスト</param>
        /// <returns>空白除去されたテキスト</returns>
        protected string DeleteBlank(string text)
        {
            return text.Replace(" ", "").Replace("　", "");
        }
        
        /// <summary>
        /// 空白であるかの取得
        /// </summary>
        /// <param name="character">文字</param>
        /// <returns>true:空白である false:空白でない</returns>
        protected bool GetIsBlank(char character)
        {
            return (character == ' ') || (character == '　');
        }

        private new void Awake()
        {
            base.Awake();
            startLeftTagSize = GetStartLeftTag(TAG_NAME_SIZE);
            startLeftTagRuby = GetStartLeftTag(TAG_NAME_RUBY);
            endTagSize = GetEndTag(TAG_NAME_SIZE);
            endTagRuby = GetEndTag(TAG_NAME_RUBY);
            OriginalText = messageText.text;
            Text = OriginalText;
            InitText();
            RectTransform textRectTransform = messageText.GetComponent<RectTransform>();
            textGenerator = new TextGenerator();
            textGenerationSettings = messageText.GetGenerationSettings(textRectTransform.sizeDelta);
            enabled = false;
        }
    }
}
