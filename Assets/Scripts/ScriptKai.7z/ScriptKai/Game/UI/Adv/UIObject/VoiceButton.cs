﻿using Adventure.Controller;
using Base.Sound;
using Game.Sound;
using UnityEngine;
using UnityEngine.UI;
using Adventure.Util;

namespace Adventure.UI
{
    /// <summary>
    /// ボイスボタン
    /// </summary>
    public class VoiceButton : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("ボタン")]
        private Button button = null;
        [SerializeField]
        [Tooltip("テキストコントローラー")]
        private TextController textController = null;
        [SerializeField]
        [Tooltip("OnOff画像")]
        private OnOffImage onOffImage = null;

        private bool isPlaying = false;
        private Color initDisabledColor;

        /// <summary>
        /// On設定
        /// </summary>
        /// <param name="isOn">true:on false:off</param>
        public void SetOn(bool isOn)
        {
            button.interactable = isOn;
            ColorBlock colors = button.colors;
            if (isOn)
            {
                colors.disabledColor = Color.white;
            }
            else
            {
                colors.disabledColor = initDisabledColor;
                if (onOffImage != null)
                {
                    onOffImage.SetOn(isOn);
                }
            }
            button.colors = colors;
        }

        private void Awake()
        {
            initDisabledColor = button.colors.disabledColor;
            button.onClick.AddListener(() =>
            {
                SoundExpansion.PlaySe(SoundConstants.SE_SELECT);
                textController.PlayVoice();
                button.interactable = false;
                if (onOffImage != null)
                {
                    onOffImage.SetOn(true);
                }
                isPlaying = true;
            });
        }

        private void Update()
        {
            if (isPlaying)
            {
				if (!SoundManager.IsPlayingVoice())
                {
                    SoundPlayer.StopVoice();
                    button.interactable = true;
                    if (onOffImage != null)
                    {
                        onOffImage.SetOn(false);
                    }
                    isPlaying = false;
                }
            }
        }
    }
}
