﻿using Adventure.Util;
using UnityEngine;
using UnityEngine.UI;

namespace Adventure.UI
{
    /// <summary>
    /// ウィンドウボタン
    /// </summary>
    public class WindowButton : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("ボタン")]
        private Button button = null;
        [SerializeField]
        [Tooltip("ウィンドウ")]
        private GameObject window = null;
        [SerializeField]
        [Tooltip("タッチスクリーン")]
        private GameObject touchScreen = null;

        private void Awake()
        {
            button.onClick.AddListener(() =>
            {
                SoundExpansion.PlaySe(SoundConstants.SE_SELECT);
                window.SetActive(false);
                touchScreen.SetActive(false);
            });
        }
    }
}