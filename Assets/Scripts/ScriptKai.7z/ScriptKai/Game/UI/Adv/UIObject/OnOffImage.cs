﻿using UnityEngine;
using UnityEngine.UI;

namespace Adventure.UI
{
    /// <summary>
    /// OnOff画像
    /// </summary>
    public class OnOffImage : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("画像")]
        private Image image = null;
        [SerializeField]
        [Tooltip("オン画像")]
        private Sprite onSprite = null;
        [SerializeField]
        [Tooltip("オフ画像")]
        private Sprite offSprite = null;
        [SerializeField]
        [Tooltip("オンゲームオブジェクト")]
        private GameObject onGameObject = null;
        [SerializeField]
        [Tooltip("オフゲームオブジェクト")]
        private GameObject offGameObject = null;

        /// <summary>
        /// true:on false:off
        /// </summary>
        public bool IsOn { get; private set; } = false;

        /// <summary>
        /// On設定
        /// </summary>
        /// <param name="isOn">true:on false:off</param>
        public void SetOn(bool isOn)
        {
            image.sprite = isOn ? onSprite : offSprite;
            image.SetNativeSize();
            IsOn = isOn;
            if (onGameObject != null)
            {
                onGameObject.SetActive(isOn);
            }
            if (offGameObject != null)
            {
                offGameObject.SetActive(!isOn);
            }
        }
    }
}
