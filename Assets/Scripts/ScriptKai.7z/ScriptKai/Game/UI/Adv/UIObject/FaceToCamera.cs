using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Pheonix.Core;
using TMPro;
using System.Linq;
using UnityEngine.Events;

public class FaceToCamera : MonoBehaviour
{
    [SerializeField] public Button btn;
    [SerializeField] Image bg;
    [SerializeField] UIText text;
    [SerializeField] TextMeshProUGUI TMP;
    [SerializeField] Image img1;
    [SerializeField] Image img2;
    [SerializeField] Image img3;
    [SerializeField] Image img4;
    Camera cam;
    Transform parent;


    // Start is called before the first frame update
    void Start()
    {
        cam = Camera.main;
        parent = transform.parent;
    }

    // Update is called once per frame
    void Update()
    {
        transform.LookAt(transform.position + cam.transform.rotation * Vector3.forward, cam.transform.rotation * Vector3.up);
        float _dot = Vector3.Dot(transform.forward, transform.position - parent.position);
        if (_dot >= 0)
        {
            btn.gameObject.SetActive(false);
            //bg.gameObject.SetActive(false);
        }
        else
        {
            btn.gameObject.SetActive(true);
            //bg.gameObject.SetActive(true);
        }
    }

    public void Setup(int keywords, List<int> deletekeywords,int teabreaklevel,long charaid)
    {
        var keywordMaster = DataManager.Instance.Master.Keyword[keywords];
        var id = DataManager.Instance.Master.PrivateTalk.Values.First(x => x.keywordId == keywords && x.characterMasterId == charaid).id;
        if (keywordMaster.level > teabreaklevel)
        {
            btn.onClick.RemoveAllListeners();
            img1.gameObject.SetActive(true);
            TMP.text = "???";
            TMP.color = new Color(119f / 255f, 119f / 255f, 119f / 255f);
            //text.SetLabel(LocalizeManager.DATA_TYPE.KEYWORD, keywords.ToString());
            return;
        }
        if (deletekeywords.Contains(id))
        {
            btn.onClick.RemoveAllListeners();
            btn.onClick.AddListener(async () => { await UI.Popup.ShowPopupMessageAsync(LocalizeManager.Instance.GetText(LocalizeManager.DATA_TYPE.ADV, "Have_Done_This_Time")); });
            img2.gameObject.SetActive(true);
            text.SetLabel(LocalizeManager.DATA_TYPE.KEYWORD, keywords.ToString());
            return;
        }
        if (isReaded(keywords, charaid))
        {
            img4.gameObject.SetActive(true);
            text.SetLabel(LocalizeManager.DATA_TYPE.KEYWORD, keywords.ToString());
            return;
        }
        else
        {
            img3.gameObject.SetActive(true);
            text.SetLabel(LocalizeManager.DATA_TYPE.KEYWORD, keywords.ToString());
            return;
        }

    }

    

    private bool isReaded(int keywordId, long characterId)
    {
        var keyword = DataManager.Instance.Player.Keyword.TryGet(keywordId);
        if (keyword != null)
        {
            return keyword.CharacterMasterIds.Contains(characterId);
        }

        return false;
    }
}
