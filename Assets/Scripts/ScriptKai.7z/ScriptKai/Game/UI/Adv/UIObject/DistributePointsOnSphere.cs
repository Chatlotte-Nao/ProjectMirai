using Adventure.Controller;
using Game.ScriptEngine;
using static Game.ScriptEngine.ScriptEngine;
using Pheonix.Core;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;

public class DistributePointsOnSphere : MonoBehaviour, IDragHandler, IBeginDragHandler
{

    [SerializeField] Transform parent;
    [SerializeField] GameObject buttonPrefab;
    [SerializeField] Transform bg;
    Transform[] kids;
    public int num = 30;
    public float size = 1f;

    [SerializeField] PrivateTalkController privateTalkController;

    private Vector3 fixedPos;
    private Quaternion fixedRot;

    private void Start()
    {
        fixedPos = bg.position;
        fixedRot = bg.rotation;
    }

    private void Update()
    {
        bg.position = fixedPos;
        bg.rotation = fixedRot;
    }


    public void CalculateSphere(List<int> keywords, List<int> deletekeywords,int teavreaklevel,long characterid)
    {
        bg.gameObject.SetActive(true);

        num = keywords.Count;
        float inc = Mathf.PI * (3.0f - Mathf.Sqrt(5.0f));
        float off = 2.0f / num;

        kids = new Transform[num];
        for (int i = 0; i < num; i++)
        {
            float y = i * off - 1.0f + (off / 2.0f);
            float r = Mathf.Sqrt(1.0f - y * y);
            float phi = i * inc;
            Vector3 pos = new Vector3(Mathf.Cos(phi) * r * size, y * size, Mathf.Sin(phi) * r * size);
            GameObject Go = Instantiate(buttonPrefab);
            var index = i;
            Go.GetComponent<FaceToCamera>().btn.onClick.AddListener(() => { Debug.Log("coming!!!!!"); SetEnd(keywords[index], characterid); });
            Go.GetComponent<FaceToCamera>().Setup(keywords[i], deletekeywords, teavreaklevel, characterid);
            Go.transform.parent = parent;
            Go.transform.localPosition = pos;
            Go.SetActive(true);
            kids[i] = Go.transform;
        }
    }




    public void SetEnd(int keywordid, long characterid)
    {
        Debug.Log(keywordid + "    " + characterid);
        privateTalkController.TargetPrivateTalkMaster = DataManager.Instance.Master.PrivateTalk.Values.First(x => x.keywordId == keywordid && x.characterMasterId == characterid);

        Debug.Log(privateTalkController.TargetPrivateTalkMaster.script);
        int targetId = privateTalkController.TargetPrivateTalkMaster.id;
        Debug.Log("targetid:" + targetId);
        privateTalkController.masterChoseKeys.Add(targetId);
        privateTalkController.masterDeleteKeys.Add(targetId);

        //bg.gameObject.SetActive(false);

        int i = 2; //��һ,������ɾ
        while (i < transform.childCount)
        {
            Destroy(transform.GetChild(i++).gameObject);
        }


        privateTalkController.AddBonds += privateTalkController.TargetPrivateTalkMaster.bondsValue;
        CallScript(privateTalkController.TargetPrivateTalkMaster);
        privateTalkController.enabled = false;
    }

    protected void CallScript(PrivateTalkMaster privateTalkMaster)
    {
        ScriptEngine instance = GetInstance();
        if (instance.scripts.ContainsKey(privateTalkMaster.script))
        {
            Debug.Log("ohhhhhhh");
            instance.CallScript(privateTalkMaster.script);
        }
    }




    private Vector3 startPosition;
    private Vector3 currentPosition;
    private Vector3 previousPosition;

    [Tooltip("sphere target")]
    public Transform target;

    [Tooltip("sphere rotate speed")]
    [Range(0, 10)]
    public float speed = 1f;

    public void OnDrag(PointerEventData eventData)
    {

        currentPosition = eventData.position;

        //��Ļ����
        Vector3 offset = currentPosition - previousPosition;

        previousPosition = eventData.position;
 
        Vector3 Xoffset = new Vector3(offset.x, offset.y, 0);

        transform.Rotate(Vector3.Cross(Xoffset, Vector3.forward).normalized, offset.magnitude, Space.World);
    }

    //��ʼ����
    public void OnBeginDrag(PointerEventData eventData)
    {
        startPosition = eventData.position;
        previousPosition = eventData.position;
    }



}
