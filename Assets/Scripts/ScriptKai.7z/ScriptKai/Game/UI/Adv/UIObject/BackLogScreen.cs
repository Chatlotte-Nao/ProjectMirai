﻿using Base.Sound;
using Game.Sound;
using UnityEngine;
using UnityEngine.UI;
using Adventure.Util;

namespace Adventure.UI
{
    /// <summary>
    /// バックログ画面
    /// </summary>
    public class BackLogScreen : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("バックログ項目")]
        private BackLogItem backLogItemPrefab = null;
        [SerializeField]
        [Tooltip("中身")]
        private Transform content = null;
        [SerializeField]
        [Tooltip("スクロールレクト")]
        private ScrollRect scrollRect = null;

        private float nowTimeScale = 0.0f;
        private bool isInit = false;

        /// <summary>
        /// 追加
        /// </summary>
        /// <param name="speakerName">話者名</param>
        /// <param name="speakerNameText">話者名テキスト</param>
        /// <param name="rubyTextScroll">ルビテキストスクロール</param>
        /// <param name="voiceName">ボイス名</param>
        public void Add(string speakerName, string speakerNameText, RubyTextScroll rubyTextScroll, string voiceName)
        {
            BackLogItem backLogItem = Instantiate(backLogItemPrefab);
            backLogItem.SetBackLog(speakerName, speakerNameText, rubyTextScroll, voiceName);
            backLogItem.transform.SetParent(content, false);
        }

        /// <summary>
        /// 閉じるボタンが押された時
        /// </summary>
        public void OnClickClose()
        {
            SoundManager.StopVoice();
            SoundExpansion.PlaySe(SoundConstants.SE_SELECT);
            Time.timeScale = nowTimeScale;
            gameObject.SetActive(false);
        }

        private void OnEnable()
        {
            nowTimeScale = Time.timeScale;
            Time.timeScale = 0.0f;
            isInit = true;
        }
        
        private void Update()
        {
            if (isInit)
            {
                scrollRect.verticalNormalizedPosition = 0.0f;
                isInit = false;
            }
        }
    }
}
