﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Adventure.UI
{
    /// <summary>
    /// アイテムピース
    /// </summary>
    public class ItemPiece : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("個数のテキスト")]
        private TMP_Text numberText = null;
        [SerializeField]
        [Tooltip("アイテム名のテキストl")]
        private TMP_Text itemNameText = null;
        [SerializeField]
        [Tooltip("画像")]
        private Image image = null;

        private string defaulltNumberText = null;
        private Sprite defaultSprite = null;

        /// <summary>
        /// セットアップ
        /// </summary>
        /// <param name="sprite">スプライト</param>
        /// <param name="number">個数</param>
        public void Setup(Sprite sprite, int number)
        {
            if ((image == null) || (numberText == null))
            {
                return;
            }

            SetDefault();

            SetImage(sprite);
            SetNumberText(number);
            itemNameText?.gameObject?.SetActive(false);
        }

        /// <summary>
        /// セットアップ
        /// </summary>
        /// <param name="itemName">アイテム名</param>
        /// <param name="number">個数</param>
        public void Setup(string itemName, int number)
        {
            if ((itemNameText == null) || (numberText == null))
            {
                return;
            }

            SetDefault();

            SetImage(defaultSprite);
            SetNumberText(number);
            itemNameText.gameObject?.SetActive(true);
            itemNameText.text = itemName;
        }

        /// <summary>
        /// デフォルト設定
        /// </summary>
        protected void SetDefault()
        {
            if (defaulltNumberText == null)
            {
                defaulltNumberText = numberText.text;
            }
            if (defaultSprite == null)
            {
                defaultSprite = image.sprite;
            }
        }

        /// <summary>
        /// 個数のテキスト設定
        /// </summary>
        /// <param name="number">個数</param>
        protected void SetNumberText(int number)
        {
            numberText.text = string.Format(defaulltNumberText, number);
        }

        /// <summary>
        /// 画像設定
        /// </summary>
        /// <param name="sprite">スプライト</param>
        protected void SetImage(Sprite sprite)
        {
            image.sprite = sprite;
            image.SetNativeSize();
        }
    }
}
