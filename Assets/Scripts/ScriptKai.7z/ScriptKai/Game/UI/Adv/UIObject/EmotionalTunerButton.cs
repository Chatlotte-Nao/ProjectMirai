﻿using Adventure.Util;
using Base.Sound;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using static Adventure.Controller.EmotionalTunerController;

namespace Adventure.UI
{
    /// <summary>
    /// エモーショナルチューナーボタン
    /// </summary>
    public class EmotionalTunerButton : MonoBehaviour
    {
        /// <summary>
        /// 状態
        /// </summary>
        public enum State
        {
            /// <summary>
            /// 何もしてない
            /// </summary>
            None,
            /// <summary>
            /// 現れる
            /// </summary>
            Appear,
            /// <summary>
            /// 待ち
            /// </summary>
            Wait,
            /// <summary>
            /// 通常
            /// </summary>
            Normal,
            /// <summary>
            /// OK
            /// </summary>
            Ok,
        }
        /// <summary>
        /// アニメーションの種類
        /// </summary>
        [Serializable]
        public class AnimationType
        {
            [SerializeField]
            [Tooltip("通常のアニメーション名")]
            private string normalAnimationName = null;
            [SerializeField]
            [Tooltip("OKのアニメーション名")]
            private string okAnimationName = null;
            [SerializeField]
            [Tooltip("バー画像")]
            private Image barImage = null;
            
            /// <summary>
            /// 通常のアニメーション名
            /// </summary>
            public string NormalAnimationName => normalAnimationName;
            /// <summary>
            /// OKのアニメーション名
            /// </summary>
            public string OKAnimationName => okAnimationName;
            /// <summary>
            /// バー画像
            /// </summary>
            public Image BarImage => barImage;
        }
        /// <summary>
        /// 段階情報
        /// </summary>
        [Serializable]
        public class StageInfo
        {
            [SerializeField]
            [Tooltip("背景")]
            private GameObject background = null;
            [SerializeField]
            [Tooltip("点")]
            private GameObject[] points = null;

            /// <summary>
            /// 背景の取得
            /// </summary>
            public GameObject Background => background;
            /// <summary>
            /// 点の取得
            /// </summary>
            public GameObject[] Points => points;
            /// <summary>
            /// アニメーション種類番号
            /// </summary>
            public int AnimationTypeNumber { get; set; } = 0;
            /// <summary>
            /// 溜め秒
            /// </summary>
            public float SaveSeconds { get; set; } = 0.0f;
        }
        [SerializeField]
        [Tooltip("アニメーター")]
        private Animator[] animators = null;
        [SerializeField]
        [Tooltip("ゲージアニメーター")]
        private Animator gageAnimator = null;
        [SerializeField]
        [Tooltip("入力待ちアニメーション名")]
        private string waitAnimationName = "0_wait";
        [SerializeField]
        [Tooltip("ゲージ入力待ちアニメーション名")]
        private string gageWaitAnimationName = "Gage_0_wait";
        [SerializeField]
        [Tooltip("ゲージ通常アニメーション名")]
        private string gageNormalAnimationName = "Gage_1";
        [SerializeField]
        [Tooltip("ゲージOKアニメーション名")]
        private string gageOkAnimationName = "Gage_1_ok";
        [SerializeField]
        [Tooltip("アニメーション種類")]
        private AnimationType[] animationTypes = null;
        [SerializeField]
        [Tooltip("段階情報")]
        private StageInfo[] stageInfos = null;
        [SerializeField]
        [Tooltip("テキストメッシュプロUGUI")]
        private TextMeshProUGUI[] textMeshProUGUIs = null;
        [SerializeField]
        [Tooltip("ボタン")]
        private GameObject button = null;
        [SerializeField]
        private UnityEvent onStart = new UnityEvent();
        [SerializeField]
        private UnityEvent onEnd = new UnityEvent();

        /// <summary>
        /// okアニメーションが終了する正規化された時間
        /// </summary>
        public const float OK_END_NORMALIZED_TIME = 4.0f;
        /// <summary>
        /// バーが開始する割合
        /// </summary>
        public const float BAR_START_RATE = 0.1f;
        /// <summary>
        /// バーの割合の範囲
        /// </summary>
        public const float BAR_RANGE_RATE = 0.8f;

        /// <summary>
        /// 開始時のコールバック
        /// </summary>
        public UnityEvent OnStart => onStart;
        /// <summary>
        /// 終了時のコールバック
        /// </summary>
        public UnityEvent OnEnd => onEnd;

        /// <summary>
        /// テキストメッシュプロUGUI取得
        /// </summary>
        public TextMeshProUGUI[] TextMeshProUGUIs => textMeshProUGUIs;

        private float startSeconds = 0.0f;
        private Selection[] selections = null;
        private State state = State.Wait;
        private AnimatorStateInfo[] animatorStateInfos = null;
        private float totalSeconds = 0.0f;
        private int saveAudioNumber = -1;

        /// <summary>
        /// 段階
        /// </summary>
        public int Stage { get; private set; } = 0;

        /// <summary>
        /// 初期化
        /// </summary>
        /// <param name="selections">選択内容</param>
        public void Init(Selection[] selections)
        {
            this.selections = selections;
            Stage = 0;
            totalSeconds = 0.0f;
            int maxStage = GetMaxStage();
            for (int i = 0; i < maxStage; i++)
            {
                int animationTypeNumber = GetAnimationTypeNumber(selections[i].AnimationName);
                stageInfos[i].AnimationTypeNumber = animationTypeNumber == -1 ? i : animationTypeNumber;
                totalSeconds += selections[i].SaveSeconds;
                stageInfos[i].SaveSeconds = totalSeconds;
            }
            for (int i = 0; i < animationTypes.Length; i++)
            {
                animationTypes[i].BarImage.fillAmount = 0.0f;
            }
            for (int i = maxStage - 1; i >= 0; i--)
            {
                AnimationType animationType = GetAnimationType(i);
                animationType.BarImage.transform.SetAsLastSibling();
            }
            for (int i = 0; i < stageInfos.Length; i++)
            {
                if (stageInfos[i].Background != null)
                {
                    stageInfos[i].Background.SetActive(i == selections.Length - 1);
                }
                if (stageInfos[i].Points != null)
                {
                    for (int j = 0; j < stageInfos[i].Points.Length; j++)
                    {
                        stageInfos[i].Points[j].SetActive(false);
                    }
                }
            }
            SetStage();
            state = State.Appear;
        }

        /// <summary>
        /// 押した時呼ばれる
        /// </summary>
        public void OnPointerDown()
        {
            if (state != State.Wait)
            {
                return;
            }

            saveAudioNumber = SoundExpansion.PlaySe("10_選択肢長押し");

            StartNormalAnimation();
            gageAnimator.Play(gageNormalAnimationName, 0, 0.0f);
            SetPoint();
            startSeconds = Time.time;
            state = State.Normal;
        }

        /// <summary>
        /// 離した時呼ばれる
        /// </summary>
        public void OnPointerUp()
        {
            if (state != State.Normal)
            {
                return;
            }

            SoundManager.StopSe(saveAudioNumber);
            SoundExpansion.PlaySe("11_選択肢決定");

            AnimationType animationType = GetAnimationType(Stage);
            for (int i = 0; i < animators.Length; i++)
            {
                animators[i].Play(animationType.OKAnimationName, 0, 0.0f);
            }
            gageAnimator.Play(gageOkAnimationName, 0, 0.0f);

            state = State.Ok;
        }

        /// <summary>
        /// アニメーション種類番号取得
        /// </summary>
        /// <param name="animationName">アニメーション名</param>
        /// <returns>アニメーション種類番号(-1は一致するものがなかった)</returns>
        protected int GetAnimationTypeNumber(string animationName)
        {
            for (int i = 0; i < animationTypes.Length; i++)
            {
                if (animationName == animationTypes[i].NormalAnimationName)
                {
                    return i;
                }
            }
            return -1;
        }

        /// <summary>
        /// 通常アニメーション開始
        /// </summary>
        protected void StartNormalAnimation()
        {
            AnimationType animationType = GetAnimationType(Stage);
            for (int i = 0; i < animators.Length; i++)
            {
                animators[i].Play(animationType.NormalAnimationName, 0, 0.0f);
            }
        }

        /// <summary>
        /// 段階設定
        /// </summary>
        protected void SetStage()
        {
            for (int i = 0; i < TextMeshProUGUIs.Length; i++)
            {
                TextMeshProUGUIs[i].text = selections[Stage].Text;
            }
        }

        /// <summary>
        /// ポイント設定
        /// </summary>
        protected void SetPoint()
        {
            int maxStage = GetMaxStage();
            if (stageInfos[maxStage - 1].Points != null)
            {
                stageInfos[maxStage - 1].Points[Stage].SetActive(true);
            }
        }

        /// <summary>
        /// アニメーション種類の取得
        /// </summary>
        /// <param name="Stage">段階</param>
        /// <returns>アニメーションの種類</returns>
        protected AnimationType GetAnimationType(int Stage)
        {
            int animationTypeNumber = stageInfos[Stage].AnimationTypeNumber;
            return animationTypes[animationTypeNumber];
        }

        /// <summary>
        /// 今のアニメーション名であるかの取得
        /// </summary>
        /// <param name="effectAnimationName">エフェクトアニメーション名</param>
        /// <param name="gageAnimationName">ゲージアニメーション名</param>
        /// <returns></returns>
        protected bool IsNowAnimationName(string effectAnimationName, string gageAnimationName)
        {
            for (int i = 0; i < animatorStateInfos.Length; i++)
            {
                if (!animatorStateInfos[i].IsName(effectAnimationName))
                {
                    return false;
                }
            }
            AnimatorStateInfo gageStateInfo = gageAnimator.GetCurrentAnimatorStateInfo(0);
            if (!gageStateInfo.IsName(gageAnimationName))
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// 最大段階の取得
        /// </summary>
        /// <returns>最大段階</returns>
        protected int GetMaxStage()
        {
            return Mathf.Min(selections.Length, stageInfos.Length);
        }

        private void Awake()
        {
            animatorStateInfos = new AnimatorStateInfo[animators.Length];
        }

        // Update is called once per frame
        private void Update()
        {
            for (int i = 0; i < animatorStateInfos.Length; i++)
            {
                animatorStateInfos[i] = animators[i].GetCurrentAnimatorStateInfo(0);
            }
            AnimatorStateInfo gageStateInfo = gageAnimator.GetCurrentAnimatorStateInfo(0);
            AnimationType stageAnimation = GetAnimationType(Stage);
            switch (state)
            {
                case State.Appear:
                    if (IsNowAnimationName(waitAnimationName, gageWaitAnimationName))
                    {
                        onStart?.Invoke();
                        button.SetActive(true);
                        state = State.Wait;
                    }
                    break;
                case State.Normal:
                    float rate = (Time.time - startSeconds) * BAR_RANGE_RATE / totalSeconds + BAR_START_RATE;
                    int maxStage = GetMaxStage();
                    for (int i = Stage; i < maxStage; i++)
                    {
                        AnimationType animationType = GetAnimationType(i);
                        animationType.BarImage.fillAmount = rate;
                    }
                    float elapsedSeconds = Time.time - startSeconds;
                    if (elapsedSeconds >= stageInfos[Stage].SaveSeconds)
                    {
                        Stage++;
                        if (Stage >= maxStage)
                        {
                            Stage = maxStage - 1;
                            OnPointerUp();
                        }
                        else
                        {
                            SoundManager.StopSe(saveAudioNumber);
                            saveAudioNumber = SoundExpansion.PlaySe("10_選択肢長押し");

                            SetStage();
                            StartNormalAnimation();
                            SetPoint();
                        }
                    }
                    break;
                case State.Ok:
                    if (IsNowAnimationName(stageAnimation.OKAnimationName, gageOkAnimationName))
                    {
                        if (animatorStateInfos[0].normalizedTime >= OK_END_NORMALIZED_TIME)
                        {
                            button.SetActive(false);
                            state = State.None;
                            onEnd.Invoke();
                        }
                    }
                    break;
            }
        }
    }
}
