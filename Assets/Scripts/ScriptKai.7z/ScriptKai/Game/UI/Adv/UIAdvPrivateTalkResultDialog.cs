﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Adventure.Controller;

public class UIAdvPrivateTalkResultDialog : UIDialogBase
{
    [SerializeField] SummaryController summaryController;

    
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();

        Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.SummaryController = summaryController;
    }

    public override void Dispose()
    {
        base.Dispose();

        Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.SummaryController = null;
    }
}