﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIAdvBackgroundDialog : UIDialogBase
{
    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
    }
}
