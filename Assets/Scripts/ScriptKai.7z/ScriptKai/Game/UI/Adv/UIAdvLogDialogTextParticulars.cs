using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;

public class UIAdvLogDialogTextParticulars : MonoBehaviour
{
    public UIText characterName;
    public UIText take;
    public async UniTask SetUp(string characterName,string take)
    {
        this.characterName.SetRawText(characterName);
        this.take.SetRawText(take);
    }
}
