﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using Cysharp.Threading.Tasks;
using Adventure.Controller;
using UnityEngine.Events;

public class UIAdvMessageDialog : UIDialogBase
{
    [SerializeField] UIButton clickButton;
    [SerializeField] GameObject uiGroup;
    [SerializeField] UIButton hideOffButton;

    [SerializeField] MoveWordController moveWordController;
    [SerializeField] TextController textController;
    [SerializeField] SelectController selectController;
    [SerializeField] UIADVLogDialog mLogDiaLog;
    [SerializeField] GameObject adv_text_window;

    [SerializeField] UIButton autoButton;
    [SerializeField] UIButton skipButton;
    [SerializeField] UIButton configButton;
    [SerializeField] UIButton backlogButton;
    [SerializeField] UIButton hideButton;
    [SerializeField] UIButton menuButton;
    [SerializeField] ParticleSystem particlesEffect;

    public UnityEvent OnClickConfig => configButton.OnTouchUpInside;

    public override async UniTask InitializeAsync()
    {
        await base.InitializeAsync();
        clickButton.onClickUp.Subscribe(OnClick).AddTo(mSubscriptions);

        Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.TextController = textController;
        Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.MessageMoveWordController = moveWordController;
        Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.SelectController = selectController;

        autoButton.onClick.Subscribe(OnClickAuto).AddTo(mSubscriptions);
        skipButton.onClick.Subscribe(OnClickSkip).AddTo(mSubscriptions);
        hideButton.onClick.Subscribe(OnClickHide).AddTo(mSubscriptions);
        hideOffButton.onClick.Subscribe(OnClickHideOff).AddTo(mSubscriptions);
        menuButton.onClick.Subscribe(OnClickMenu).AddTo(mSubscriptions);
        backlogButton.OnTouchDown.GuardSubscribeAsync(BacklogClick).AddTo(mSubscriptions);

        if (textController.logDialog == null)
        {
            mLogDiaLog = await UI.Dialog.CreateAsync(UIPrefabId.UIAdvLogDialog, CanvasType.App2) as UIADVLogDialog;
            textController.logDialog = mLogDiaLog;
        }
    }

    private async UniTask BacklogClick()
    {
        Time.timeScale = 1;
        await textController.logDialog.Init(adv_text_window, async () =>
        {
            OnClickSkip(gameObject);
            OnClickSkip(gameObject);
        });
        await textController.logDialog.ShowAsync();
        adv_text_window.SetActive(false);
    }

    private void OnClick(Vector2 p)
    {
        particlesEffect.gameObject.SetActive(false);
        Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.PressScreen();
    }

    public async UniTask InitLogDialog(UIADVLogDialog logDialog)
    {
        textController.logDialog = logDialog;
    }

    public override void Dispose()
    {
        base.Dispose();
        if (Game.ScriptEngine.ScriptEngine.GetInstance().commandManager != null)
        {
            Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.TextController = null;
            Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.MessageMoveWordController = null;
            Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.SelectController = null;
        }
    }


    private void OnClickAuto(GameObject o)
    {

        Adventure.Util.SoundExpansion.PlaySe(SoundConstants.SE_SELECT);
        Game.ScriptEngine.ScriptEngine.GetInstance().commandManager.FastForward.Execute(false);
        textController.SetAutoPlay(!textController.IsAutoPlay);
        if (textController.IsAutoPlay)
        {
            particlesEffect.transform.localPosition = autoButton.gameObject.transform.localPosition;
            particlesEffect.gameObject.SetActive(true);
            particlesEffect.Play();
        }
        else particlesEffect.gameObject.SetActive(false);
    }

    private void OnClickSkip(GameObject o)
    {
        // #if !UNITY_EDITOR
        // //TT skip
        // UI.Popup.ShowPopMessage("测试版本跳过功能无法使用，敬请谅解");
        // return;
        // #endif
        if (!DebugState.canSpeedStory)
        {
            UI.Popup.ShowPopMessage("测试版本跳过功能无法使用，敬请谅解");
            return;
        }

#if !UWA
        Adventure.Util.SoundExpansion.PlaySe(SoundConstants.SE_SELECT);
        if (SkipEnable())
        {
            var commandManager = Game.ScriptEngine.ScriptEngine.GetInstance().commandManager;
            commandManager.TextController.SetAutoPlay(false);
            commandManager.FastForward.Execute(!commandManager.TextController.IsFastForward);
            particlesEffect.transform.localPosition = autoButton.gameObject.transform.localPosition;
            particlesEffect.gameObject.SetActive(true);
            particlesEffect.Play();
        }
        else particlesEffect.gameObject.SetActive(false);

#endif
    }

    private void OnClickMenu(GameObject o)
    {
        particlesEffect.gameObject.SetActive(false);
    }

    private bool SkipEnable()
    {
        var commandManager = Game.ScriptEngine.ScriptEngine.GetInstance().commandManager;
        if (commandManager.SelectController != null && commandManager.SelectController.enabled)
        {
            return false;
        }

        if (commandManager.EmotionalTunerController != null && commandManager.EmotionalTunerController.enabled)
        {
            return false;
        }

        // if (commandManager.PrivateWordController != null && commandManager.PrivateWordController.enabled)
        // {
        //     return false;
        // }
        // if (commandManager.PrivateTalkController != null && commandManager.PrivateTalkController.enabled)
        // {
        //     return false;
        // }
        if (commandManager.PrivateSelectController != null && commandManager.PrivateSelectController.enabled)
        {
            return false;
        }

        return true;
    }

    private async UniTask OnClickBacklog()
    {
        AsyncManager.Instance.StartGuardAsync(UI.Dialog.CreateAsync(UIPrefabId.UIAdvBackLogDialog, CanvasType.App2));
    }

    private void OnClickHide(GameObject o)
    {
        uiGroup.SetActive(false);
        hideOffButton.gameObject.SetActive(true);
    }

    private void OnClickHideOff(GameObject o)
    {
        particlesEffect.gameObject.SetActive(false);
        uiGroup.SetActive(true);
        hideOffButton.gameObject.SetActive(false);
    }
}