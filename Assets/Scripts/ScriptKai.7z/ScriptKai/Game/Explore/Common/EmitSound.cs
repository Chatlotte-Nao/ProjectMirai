using System;
using UnityEngine;
using UnityEngine.Timeline;

[Serializable]
[CustomStyle("SignalEmitter")]
[ExcludeFromPreset]
public class EmitSound : SignalEmitter
{
    [SerializeField] public string m_parameter;
    
    public string parameter
    {
        get { return m_parameter; }
        set { m_parameter = value; }
    }
}