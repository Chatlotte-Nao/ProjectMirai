using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Pheonix.Core;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Playables;
using UnityEngine.Timeline;




public class ExploreTimelineEventer : MonoBehaviour, INotificationReceiver
{
    private void Start()
    {
        PxSoundManager.CreateInstance();
    }

    public void OnNotify(Playable origin, INotification notification, object context)
    {
        if (notification is EmitSound)
        {
            var sewb = notification as EmitSound;
            if (!string.IsNullOrEmpty(sewb.parameter))
            {
                PxSoundManager.Instance.PlaySe(sewb.parameter);
            }
        }
    }
}