using System;
using System.Collections;
using System.Collections.Generic;
using Map;
using UnityEngine;

public class ExploreLight : MonoBehaviour
{
    public enum LType
    {
        POINT,
        DIRECTIONAL,
        SELF,
    }


    void Start()
    {
        ExploreEnvironment.GetSingle().RegLight(this);
        AttChange();
    }


    public void RefreshChaList()
    {
        _chaList.Clear();
        //bob todo: temp
        var clist = GameObject.FindObjectsOfType<ELightRecer>();
        for (int i = 0; i < clist.Length; i++)
        {
            _chaList.Add(clist[i]);
        }
    }

    private void Update()
    {
        // bool ditry = false;
        // if (transform.position != _lastPos)
        // {
        //     _lastPos = transform.position;
        //     ditry = true;
        // }
        //
        // if (transform.rotation != _lastRot)
        // {
        //     _lastRot = transform.rotation;
        //     ditry = true;
        // }
        //
        // if (_type == LType.SELF)
        // {
        //     //bob todo: need refracter
        //     ditry = true;
        // }
        //
        // if (ditry)
        // {
        //     ApplyChange();
        // }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = _color;
        if (_showArea || _showRay)
        {
            //show center
            Gizmos.DrawSphere(transform.position, 0.1f);
        }

        if (_showArea)
        {
            Gizmos.DrawWireSphere(transform.position, _range);
        }

        if (!_showRay)
        {
            return;
        }


        if (Time.time - _refreshTime >= REFRESH_CD)
        {
            RefreshChaList();
            _refreshTime = Time.time;
            // Debug.LogWarning("RefreshList");
        }


        switch (_type)
        {
            case LType.POINT:
            {
                for (int i = 0; i < _chaList.Count; i++)
                {
                    var c = _chaList[i];
                    if (!IsFit(c))
                    {
                        continue;
                    }

                    var dir = transform.position - c.GetCenter();
                    dir.Normalize();
                    Gizmos.DrawLine(c.GetCenter(), transform.position);
                }
            }
                break;
            case LType.DIRECTIONAL:
            {
                Gizmos.DrawRay(transform.position, -transform.forward);
                for (int i = 0; i < _chaList.Count; i++)
                {
                    var c = _chaList[i];
                    if (!IsFit(c))
                    {
                        continue;
                    }

                    Gizmos.DrawRay(c.GetCenter(), -transform.forward);
                }
            }
                break;
            case LType.SELF:
            {
                for (int i = 0; i < _chaList.Count; i++)
                {
                    var c = _chaList[i];
                    if (!IsFit(c))
                    {
                        continue;
                    }

                    var wDis = c.transform.localToWorldMatrix.MultiplyVector(transform.forward);
                    Gizmos.DrawRay(c.GetCenter(), wDis);
                }
            }
                break;
        }
    }

    public bool IsFit(ELightRecer c)
    {
        if (c == null)
        {
            return false;
        }

        if (!gameObject.activeInHierarchy)
        {
            return false;
        }


        if (Vector3.Distance(c.transform.position, transform.position) > _range)
        {
            return false;
        }

        if (_whiteNameList.Count > 0)
        {
            bool fit = false;
            for (int j = 0; j < _whiteNameList.Count; j++)
            {
                var wn = _whiteNameList[j];
                if (!string.IsNullOrEmpty(wn))
                {
                    if (c.name.Contains(wn))
                    {
                        fit = true;
                        break;
                    }
                }
            }

            if (!fit)
            {
                return false;
            }
        }

        return true;
    }


    public void ApplyChange(ELightRecer c)
    {
        if (!IsFit(c))
        {
            return;
        }

        switch (_type)
        {
            case LType.POINT:
            {
                var dir = transform.position - (c.GetCenter());
                dir.Normalize();
                c.SetMpVector("_ChaLightDir", dir);
            }
                break;
            case LType.DIRECTIONAL:
            {
                var dir = transform.forward;
                c.SetMpVector("_ChaLightDir", dir);
            }
                break;
            case LType.SELF:
            {
                var wDis = c.transform.localToWorldMatrix.MultiplyVector(transform.forward);
                c.SetMpVector("_ChaLightDir", wDis);
            }
                break;
        }

        c.SetMpColor("_LightColor", _color);
        c.SetMpColor("_DarkColor", _darkColor);
        c.SetMpFloat("_LightIntensity", _intensity);

        c.SetMpFloat("_PShadowHeight", c.transform.position.y + _shadowHeightOffset + c._shadow_offset_y);
        c.SetMpColor("_PShadowColor", _shadowColor);
        c.SetMpFloat("_PShadowFalloff", _shaodwFalloff);
        if (_autoShadow)
        {
            var sdir = c.transform.position - transform.position;
            //sdir.Normalize();
            c.SetMpVector("_PSLightDir", sdir);
        }
        else
        {
            c.SetMpVector("_PSLightDir", _shadowDir);
        }


        c.ApplyMPB();
    }


    public void AttChange()
    {
        if (!Application.isPlaying)
        {
            return;
        }

        if (_realLightOn)
        {
            if (_realLight == null)
            {
                var lightGo = new GameObject("light");
                _realLight = lightGo.AddComponent<Light>();
                _realLight.type = LightType.Point;
                //_realLight.lightmapBakeType = LightmapBakeType.Realtime;
                _realLight.transform.parent = transform;
                _realLight.transform.localPosition = Vector3.zero;
                string[] layerList = {"SceneBase"};
                _realLight.cullingMask = LayerMask.GetMask(layerList);
            }
        }
        else
        {
            if (_realLight != null)
            {
                _realLight.enabled = false;
            }
        }

        ReallightUpdate();
    }

    void ReallightUpdate()
    {
        if (_realLight != null)
        {
            _realLight.color = _color;
            _realLight.intensity = _intensity;
            _realLight.range = _range;
        }
    }


    // public void ApplyChange()
    // {
    //     for (int i = 0; i < _chaList.Count; i++)
    //     {
    //         var c = _chaList[i];
    //
    //         if (!IsFit(c))
    //         {
    //             continue;
    //         }
    //
    //
    //
    //         switch (_type)
    //         {
    //             case LType.POINT:
    //             {
    //                 var dir = transform.position - c.transform.position;
    //                 dir.Normalize();
    //                 c.SetMpVector("_ChaLightDir", dir);
    //             }
    //                 break;
    //             case LType.DIRECTIONAL:
    //             {
    //                 var dir = transform.forward;
    //                 c.SetMpVector("_ChaLightDir", dir);
    //             }
    //                 break;
    //             case LType.SELF:
    //             {
    //                 var wDis = c.transform.localToWorldMatrix.MultiplyVector(transform.forward);
    //                 c.SetMpVector("_ChaLightDir", wDis);
    //             }
    //                 break;
    //         }
    //
    //         c.SetMpColor("_LightColor", _color);
    //         c.SetMpColor("_DarkColor", _darkColor);
    //         c.SetMpFloat("_LightIntensity", _intensity);
    
    //         c.ApplyMPB();
    //         //c.SetMpVector();
    //     }
    // }


    public string ToExcelStr()
    {
        var str = "stage_show_elight";
        str += '\t';
        str += ((int) _type).ToString();
        str += '\t';
        str += $"{transform.position.x},{transform.position.y},{transform.position.z}";
        str += "\t";
        str += _intensity.ToString("0.0");
        str += "\t";
        str +=
            $"{transform.rotation.eulerAngles.x},{transform.rotation.eulerAngles.y},{transform.rotation.eulerAngles.z}";
        str += "\t";
        str += $"{_color.r},{_color.g},{_color.b}";
        str += "\t";
        return str;
    }

    private Vector3 _lastPos;
    private Quaternion _lastRot;

    public LType _type = LType.POINT;
    public float _range = 10f;
    public Color _color = Color.white;
    public Color _darkColor = Color.gray;
    public float _intensity = 1f;
    private List<ELightRecer> _chaList = new List<ELightRecer>();


    public List<string> _whiteNameList = new List<string>();

    public bool _showArea;
    public bool _showRay;

    private float _refreshTime = 0f;
    private const float REFRESH_CD = 10f;

    public int _priority = 0;


    public float _shadowHeightOffset = 0f;
    public Color _shadowColor = Color.black;
    public float _shaodwFalloff = 0.05f;
    public Vector3 _shadowDir = new Vector3(0f, 1f, 0f);


    public bool _realLightOn = false;
    private Light _realLight;

    public bool _autoShadow = false;
}