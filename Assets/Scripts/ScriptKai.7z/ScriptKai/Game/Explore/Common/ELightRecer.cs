using System;
using UnityEngine;
using System.Collections.Generic;

public class ELightRecer : MonoBehaviour
{
    private void Awake()
    {
        var smrList = gameObject.GetComponentsInChildren<Renderer>();
        for (int i = 0; i < smrList.Length; i++)
        {
            if (smrList[i] is ParticleSystemRenderer)
            {
                continue;
            }
            _renderList.Add(smrList[i]);
            _mpbList.Add(new MaterialPropertyBlock());
            //smrList[i].material.
        }
    }

    void Update()
    {
       // if (transform.position != _lastPos)
        {
            _lastPos = transform.position;
            for (int i = 0; i < _renderList.Count; i++)
            {
                var mbp = _mpbList[i];
                var pos = transform.position;
                //transform.GetChild(0).position
                mbp.SetVector("_ChaPos", GetCenter());
                // var wDis = transform.localToWorldMatrix.MultiplyVector(Vector3.Normalize(_chaLightDir));
                // mbp.SetVector("_ChaLightDir", wDis);
                //_renderList[i].SetPropertyBlock(mbp);
            }
        }

        var light = ExploreEnvironment.GetSingle().FetchLight(this);
        if (light == null)
        {
            //back to defualt
            SetDefaultLight();
        }
        else
        {
            light.ApplyChange(this);
            SwitchKeyWorld("_NOR_LIGHT", false);
        }
    }

    void SetDefaultLight()
    {
        //SetMpFloat("_LightIntensity", 1.0f, true);
        SwitchKeyWorld("_NOR_LIGHT", true);
    }

    //mbp
    public void SetMpColor(string _name, Color _value,
        bool _refreshNow = true)
    {
        for (int i = 0; i < _renderList.Count; i++)
        {
            var mbp = _mpbList[i];
            mbp.SetColor(_name, _value);
            if (_refreshNow)
            {
                _renderList[i].SetPropertyBlock(mbp);
            }
        }
    }

    public void SetMpVector(string _name, Vector3 _value,
        bool _refreshNow = true)
    {
        for (int i = 0; i < _renderList.Count; i++)
        {
            var mbp = _mpbList[i];
            mbp.SetVector(_name, _value);
            if (_refreshNow)
            {
                _renderList[i].SetPropertyBlock(mbp);
            }
        }
    }

    public void SetMpFloat(string _name, float _value,
        bool _refreshNow = true)
    {
        for (int i = 0; i < _renderList.Count; i++)
        {
            var mbp = _mpbList[i];
            mbp.SetFloat(_name, _value);
            if (_refreshNow)
            {
                _renderList[i].SetPropertyBlock(mbp);
            }
        }
    }

    public void ApplyMPB()
    {
        for (int i = 0; i < _renderList.Count; i++)
        {
            var mbp = _mpbList[i];
            _renderList[i].SetPropertyBlock(mbp);
        }
    }

    public void SwitchKeyWorld(string key, bool isSwitch)
    {
        for (int i = 0; i < _renderList.Count; i++)
        {
            if (isSwitch)
            {
                _renderList[i].material.EnableKeyword(key);
            }
            else
            {
                _renderList[i].material.DisableKeyword(key);
            }
        }
    }


    private void OnDrawGizmosSelected()
    {
        var wDis = transform.localToWorldMatrix.MultiplyVector(Vector3.Normalize(_chaLightDir));
        Gizmos.DrawLine(transform.position, transform.position + wDis);
    }

    public Vector3 GetCenter()
    {
        return transform.position + new Vector3(0f, _center_y, 0f);
    }

    public Vector3 _chaLightDir = new Vector3(1f, 0f, 1f);
    private Vector3 _lastPos;
    private List<Renderer> _renderList = new List<Renderer>();
    private List<MaterialPropertyBlock> _mpbList = new List<MaterialPropertyBlock>();
    //public static readonly float DIV_Y_CHARACTER_CENTER = 0.5f;
    public float _center_y = 0.5f;
    public float _shadow_offset_y = 0f;
}