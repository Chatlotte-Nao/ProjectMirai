using System;
using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using UnityEngine;
using Cysharp.Threading.Tasks;
using SRF;

namespace Score.Base
{
    public enum ExploreResType
    {
        PLAYER,
        DATE,
        ACTOR,
        FOLLOWER,
        DUNGEION,
        STORY,
    }
    class ExploreResObj
    {
        public string name;
        public GameObject gameObject;
        public bool isFree = true;

        public void Print()
        {
            Debug.Log($"{name} isFree {isFree}");
        }
    }

    public struct ExploreResResult
    {
        public GameObject ins;
        public bool needInit;
    } 


    public class ExploreResMgr : SingletonMonoBehaviour<ExploreResMgr>
    {
        public async UniTask<ExploreResResult> SpawnMiniCharacter(string resName,ExploreResType etype)
        {
            if (string.IsNullOrEmpty(resName))
            {
                return new ExploreResResult(){ins=null,needInit = false};
            }

            ExploreResResult reslut = new ExploreResResult();
            reslut.needInit = false;
            var name = $"{resName}_{etype}";
            
            //Log.Info($"BobDebug ExploreResMgr.Spawn {name}");
            if (!_chaPreDic.ContainsKey(name))
            {
                //load prefab
                var prefab = await ResourceManager.Instance.LoadPrefabAsync("Map/MiniCharacter3D/" + resName);
                _chaPreDic[name] = prefab;
            }
            var ins = GetInsGo(name);
            if (ins == null)
            {
                ins = GameObject.Instantiate(_chaPreDic[name]) as GameObject;
                ins.name = ins.name.Replace("(Clone)", "", StringComparison.Ordinal);
                ExploreResObj ero = new ExploreResObj();
                ero.name = name;
                ero.gameObject = ins;
                ero.isFree = false;
                _chaGoList.Add(ero);
                reslut.needInit = true;
            }
            reslut.ins = ins;
            ins.SetActive(true);
            return reslut;
        }


        GameObject GetInsGo(string name)
        {
            AutoClear();
            for (int i = 0; i < _chaGoList.Count; ++i)
            {
                var item = _chaGoList[i];
                if (item.isFree && (item.name == name))
                {
                    item.isFree = false;
                    return item.gameObject;
                }
            }
            return null;
        }
   
        void AutoClear()
        {
            clearList.Clear();
            for (int i = 0; i < _chaGoList.Count; i++)
            {
                if (_chaGoList[i].gameObject == null)
                {
                    clearList.Add(_chaGoList[i]);
                }
            }

            for (int i = 0; i < clearList.Count; i++)
            {
                _chaGoList.Remove(clearList[i]);
            }
            clearList.Clear();
        }

        public bool DeSpawnMiniCharacter(GameObject go)
        {
            if (go == null)
            {
                return false;
            }
            //Log.Info($"BobDebug ExploreResMgr.DeSpawn {go.name}");
            for (int i = 0; i < _chaGoList.Count; i++)
            {
                var ins = _chaGoList[i];
                if (ins.gameObject == go)
                {
                    ins.gameObject.SetActive(false);
                    ins.gameObject.transform.parent = transform;
                    ins.isFree = true;
                    return true;
                }
            }
            return false;
        }

        void DebugInfo()
        {
            Debug.Log($"=============ExploreResMgr.chaGoList.Count={_chaGoList.Count}");
            for (int i = 0; i < _chaGoList.Count; ++i)
            {
                _chaGoList[i].Print();
            }
        }

        #if UNITY_EDITOR
        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.M))
            {
                DebugInfo();
            }
        }
        #endif

        private List<ExploreResObj> _chaGoList = new List<ExploreResObj>();
        private Dictionary<string, GameObject> _chaPreDic = new Dictionary<string, GameObject>();
        private List<ExploreResObj> clearList = new List<ExploreResObj>();
    }
}