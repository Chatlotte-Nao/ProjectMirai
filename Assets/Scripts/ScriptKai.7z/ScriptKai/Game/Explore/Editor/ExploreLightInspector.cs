using System;
using System.Collections;
using System.Collections.Generic;
using Pheonix.Core;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(ExploreLight)), CanEditMultipleObjects]
public class ExploreLightInspector : Editor
{
    private void OnEnable()
    {
        owner = (ExploreLight) serializedObject.targetObject;
    }

    public override void OnInspectorGUI()
    {
        EditorGUI.BeginChangeCheck();
        owner._priority = EditorGUILayout.IntField("优先级", owner._priority);
        owner._type = (ExploreLight.LType) EditorGUILayout.EnumPopup("类型", (Enum) owner._type);
        owner._range = EditorGUILayout.FloatField("范围", owner._range);
        owner._intensity = EditorGUILayout.FloatField("强度", owner._intensity);
        owner._color = EditorGUILayout.ColorField("颜色", owner._color);
        owner._darkColor = EditorGUILayout.ColorField("暗部颜色", owner._darkColor);
        ShowWitheList();


        //shadow
        _shadowPanel = EditorGUILayout.Foldout(_shadowPanel, "阴影");
        if (_shadowPanel)
        {
            owner._shadowHeightOffset = EditorGUILayout.FloatField("高度偏移", owner._shadowHeightOffset);
            owner._shadowColor = EditorGUILayout.ColorField("颜色", owner._shadowColor);
            owner._shaodwFalloff = EditorGUILayout.FloatField("衰减", owner._shaodwFalloff);
            owner._shadowDir = EditorGUILayout.Vector3Field("方向", owner._shadowDir);
            // if (GUILayout.Button("跟随光照"))
            // {
            //     owner._shadowDir = owner.transform.forward;
            // }
            owner._autoShadow = EditorGUILayout.Toggle("自动投影", owner._autoShadow);
        }


        owner._realLightOn = EditorGUILayout.Toggle("附加动态光", owner._realLightOn);


        if (EditorGUI.EndChangeCheck())
        {
            owner.AttChange();
        }


        _showTemplate = EditorGUILayout.Foldout(_showTemplate, "快速模板");
        if (_showTemplate)
        {
            if (GUILayout.Button("左脸16度美男"))
            {
                owner._type = ExploreLight.LType.SELF;
                owner.transform.rotation = Quaternion.Euler(0f, -16f, 0f);
            }

            if (GUILayout.Button("正道的光"))
            {
                if (Camera.main != null)
                {
                    owner._type = ExploreLight.LType.DIRECTIONAL;
                    owner.transform.rotation = Quaternion.LookRotation(-Camera.main.transform.forward);
                }
            }

            if (GUILayout.Button("逆光腹黑"))
            {
                if (Camera.main != null)
                {
                    owner._type = ExploreLight.LType.DIRECTIONAL;
                    owner.transform.rotation = Quaternion.LookRotation(Camera.main.transform.forward);
                }
            }

            if (GUILayout.Button("普通点光"))
            {
                owner._type = ExploreLight.LType.POINT;
                owner.transform.position = new Vector3(owner.transform.position.x, 0.5f,
                    owner.transform.position.z);
            }
        }


        EditorGUILayout.Space();
        _isDebug = EditorGUILayout.Foldout(_isDebug, "调试选项");
        if (_isDebug)
        {
            
            if (GUILayout.Button("复制属性"))
            {
                var str = owner.ToExcelStr();
                Debug.Log("======复制属性成功======");
                Debug.Log(str);
                GUIUtility.systemCopyBuffer = str;
            }
            
            if (GUILayout.Button("刷新角色"))
            {
                owner.RefreshChaList();
            }

            owner._showArea = EditorGUILayout.Toggle("显示范围", owner._showArea);
            owner._showRay = EditorGUILayout.Toggle("显示光线", owner._showRay);
        }
    }

    void ShowWitheList()
    {
        EditorGUILayout.Space();
        var list = owner._whiteNameList;
        int newCount = Mathf.Max(0, EditorGUILayout.IntField("白名单数量", list.Count));
        while (newCount < list.Count)
            list.RemoveAt(list.Count - 1);
        while (newCount > list.Count)
            list.Add(null);

        for (int i = 0; i < list.Count; i++)
        {
            list[i] = EditorGUILayout.TextField(list[i]);
        }

        owner._whiteNameList = list;
    }


    private ExploreLight owner;
    private bool _isDebug = true;

    private bool _showTemplate = true;
    private bool _shadowPanel = true;
}