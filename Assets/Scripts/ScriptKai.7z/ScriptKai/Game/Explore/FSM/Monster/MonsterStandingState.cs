﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ExploreBattleZone;
using Pheonix.Core;

namespace Pheonix.Explore
{
    public class MonsterStandingState : FSMState<UndergroundMonster, eMonsterStateDefine>
    {
        protected override eMonsterStateDefine FSMStateID()
        {
            return eMonsterStateDefine.Standing;
        }

        public override void Enter(UndergroundMonster owner, eMonsterStateDefine previousState)
        {
            owner.animator.SetBool(Define.mHashRun, false);
        }

        public override void ReEnter(UndergroundMonster owner)
        {

        }

        public override void Update(UndergroundMonster owner, float deltaTime)
        {
            base.Update(owner, deltaTime);

            if (owner.isPause || !owner.isActive)
            {
                return;
            }

            var distance = Vector3.Distance(MapSceneManager.Instance.CurrentScene.player.transform.position, owner.transform.position);
            if (distance <= owner.enterBattleRadius)
            {
                AsyncManager.Instance.StartGuardAsync(MapSceneManager.Instance.CurrentLogic.OnEnterEnemy(owner));
            }
        }

        public override void Exit(UndergroundMonster owner, eMonsterStateDefine nextState)
        {
            base.Exit(owner, nextState);

        }
    }
}
