﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ExploreBattleZone;
using Pheonix.Core;

namespace Pheonix.Explore
{
    public class MonsterDieState : FSMState<UndergroundMonster, eMonsterStateDefine>
    {
        float _dropDownDuration = 10; //死亡后，往下沉的时间
        float _dropDownSpeed = 1; //下沉的速度
        float _duration = 0;
        UndergroundMonster _owner;

        protected override eMonsterStateDefine FSMStateID()
        {
            return eMonsterStateDefine.Die;
        }

        public override void Enter(UndergroundMonster owner, eMonsterStateDefine previousState)
        {
            _owner = owner;
            owner.animator.SetBool(Define.mHashDie, true);
            owner.died = true;
            owner.SetBubbleActive(false);
            owner.charCtrl.enabled = false;
            _duration = 0;
            Game.Sound.SoundPlayer.PlaySe("SE_Mon_DieOut");
        }

        public override void ReEnter(UndergroundMonster owner)
        {

        }

        public override void Update(UndergroundMonster owner, float deltaTime)
        {
            base.Update(owner, deltaTime);

            _duration += deltaTime;

            if (_duration > Define.kMonsterDieLength && _duration <= Define.kMonsterDieLength + _dropDownDuration)
            {
                owner.transform.position += Vector3.down * (_dropDownSpeed * deltaTime);
            }
            else if (_duration > Define.kMonsterDieLength + _dropDownDuration)
            {
                owner.gameObject.SetActive(false);
            }

            if (owner.isPause)
            {
                return;
            }
        }

        public override void Exit(UndergroundMonster owner, eMonsterStateDefine nextState)
        {
            base.Exit(owner, nextState);
            owner.died = false;
        }
    }
}
