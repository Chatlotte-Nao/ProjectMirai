﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ExploreBattleZone;
using Pheonix.Core;

namespace Pheonix.Explore
{
    public class MonsterRunState : FSMState<UndergroundMonster, eMonsterStateDefine>
    {
        protected override eMonsterStateDefine FSMStateID()
        {
            return eMonsterStateDefine.Run;
        }

        public override void Enter(UndergroundMonster owner, eMonsterStateDefine previousState)
        {
            owner.animator.SetBool(Define.mHashRun, true);
            owner.moveSpeed = Define.kMonsterRunSpeed;
        }

        public override void ReEnter(UndergroundMonster owner)
        {
            owner.animator.SetBool(Define.mHashRun, true);
        }

        public override void Update(UndergroundMonster owner, float deltaTime)
        {
            base.Update(owner, deltaTime);
            
            if (owner.isPause || !owner.isActive)
            {
                return;
            }

            var targetRotation = Quaternion.LookRotation(owner.moveDirection);
            owner.transform.rotation = Quaternion.Slerp(owner.transform.rotation, targetRotation, owner.rotationSpeed * deltaTime);

            owner.charCtrl.Move(owner.moveDirection * owner.moveSpeed * deltaTime);

            var distance = Vector3.Distance(MapSceneManager.Instance.CurrentScene.player.transform.position, owner.transform.position);
            if (distance <= owner.enterBattleRadius)
            {
                AsyncManager.Instance.StartGuardAsync(MapSceneManager.Instance.CurrentLogic.OnEnterEnemy(owner));
            }
        }

        public override void Exit(UndergroundMonster owner, eMonsterStateDefine nextState)
        {
            base.Exit(owner, nextState);

        }
    }
}
