﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ExploreBattleZone;
using Pheonix.Core;

namespace Pheonix.Explore
{
    public class MonsterShowUpState : FSMState<UndergroundMonster, eMonsterStateDefine>
    {
        protected override eMonsterStateDefine FSMStateID()
        {
            return eMonsterStateDefine.ShowUp;
        }

        public override void Enter(UndergroundMonster owner, eMonsterStateDefine previousState)
        {
            owner.animator.SetTrigger(Define.mHashShowUp);
        }

        public override void ReEnter(UndergroundMonster owner)
        {

        }

        public override void Update(UndergroundMonster owner, float deltaTime)
        {
            base.Update(owner, deltaTime);

            if (owner.isPause)
            {
                return;
            }
        }

        public override void Exit(UndergroundMonster owner, eMonsterStateDefine nextState)
        {
            base.Exit(owner, nextState);

        }
    }
}
