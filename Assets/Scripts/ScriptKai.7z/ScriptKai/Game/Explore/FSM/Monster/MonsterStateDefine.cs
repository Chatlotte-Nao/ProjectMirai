﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Pheonix.Explore
{
    /// <summary>
    /// 怪物状态定义
    /// </summary>
    public enum eMonsterStateDefine
    {
        None,
        /// <summary>
        /// 站立
        /// </summary>
        Standing,
        /// <summary>
        /// 跑步
        /// </summary>
        Run,
        /// <summary>
        /// 死亡
        /// </summary>
        Die,
        /// <summary>
        /// 登场
        /// </summary>
        ShowUp,
    }
}
