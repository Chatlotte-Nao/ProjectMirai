﻿namespace Pheonix.Explore
{
    /// <summary>
    /// 有限状态机的基类
    /// </summary>
    /// <typeparam name="T">状态机拥有者的类型</typeparam>
    /// <typeparam name="E">状态枚举</typeparam>
    public abstract class FSMState<T, E>
    {
        protected abstract E FSMStateID();

        public E StateId
        {
            get
            {
                return FSMStateID();
            }
        }

        /// <summary>
        /// 进入状态时调用
        /// </summary>
        /// <param name="owner"></param>
        /// <param name="previousState"></param>
        public virtual void Enter(T owner, E previousState) { }
        /// <summary>
        /// 重复进入当前状态
        /// </summary>
        /// <param name="owner"></param>
        public virtual void ReEnter(T owner) { }
        /// <summary>
        /// 更新函数
        /// </summary>
        /// <param name="owner"></param>
        /// <param name="deltaTime"></param>
        /// <param name="isFixed"></param>
        public virtual void Update(T owner, float deltaTime) { }
        /// <summary>
        /// 退出时调用
        /// </summary>
        /// <param name="owner"></param>
        /// <param name="nextState"></param>
        public virtual void Exit(T owner, E nextState) { }
    }
}
