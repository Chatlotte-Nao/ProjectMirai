﻿using System.Collections.Generic;

namespace Pheonix.Explore
{
    /// <summary>
    /// A Finite State Machine System
    /// </summary>
    /// <typeparam name="T">class type of the owner who own and use this FSM</typeparam>
    /// <typeparam name="E">enum type of the states the owner maybe have</typeparam>
    public class FSMSystem<T, E>
    {
        private Dictionary<E, FSMState<T, E>> _states;
        private E _currentStateId;
        private FSMState<T, E> _currentState;
        private T _owner;
        private E _previousStateId;
        private E _nullStateId;

        #region public members
        /// <summary>
        /// 当前状态
        /// </summary>
        public FSMState<T, E> CurrentState
        {
            get
            {
                return _currentState;
            }
        }

        /// <summary>
        /// 当前状态枚举
        /// </summary>
        public E CurrentStateId
        {
            get
            {
                return _currentStateId;
            }
        }

        /// <summary>
        /// 上一个状态枚举
        /// </summary>
        public E PreviousStateId
        {
            get
            {
                return _previousStateId;
            }
        }

        /// <summary>
        /// constructor, initialize the members
        /// </summary>
        /// <param name="owner">the owner of this FSM</param>
        /// <param name="nullStateId">the default null state. 
        /// when FSMS' current state is this null state, nothing will been execute when Update is called</param>
        public FSMSystem(T owner, E nullStateId)
        {
            _owner = owner;
            _nullStateId = nullStateId;
            _states = new Dictionary<E, FSMState<T, E>>();
            _states.Add(nullStateId, null);
            _currentStateId = _nullStateId;
            _currentState = null;
            _previousStateId = _nullStateId;
        }

        /// <summary>
        /// 添加状态
        /// </summary>
        /// <param name="state"></param>
        /// <returns></returns>
        public bool AddState(FSMState<T, E> state)
        {
            if (!_states.ContainsKey(state.StateId))
            {
                _states.Add(state.StateId, state);
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 更新函数，需要在状态机拥有者中调用
        /// </summary>
        /// <param name="deltaTime"></param>
        public void Update(float deltaTime)
        {
            if (!_currentStateId.Equals(_nullStateId))
            {
                _currentState.Update(_owner, deltaTime);
            }
        }

        /// <summary>
        /// 改变状态
        /// </summary>
        /// <param name="stateId"></param>
        public void ChangeState(E stateId)
        {
            if (_currentStateId.Equals(stateId))
            {
                _currentState.ReEnter(_owner);
                return;
            }
            _previousStateId = _currentStateId;
            if (!_currentStateId.Equals(_nullStateId))
            {
                _currentState.Exit(_owner, stateId);
            }
            KeyValuePair<E, FSMState<T, E>> pair = GetStateById(stateId);
            _currentStateId = pair.Key;
            _currentState = pair.Value;
            if (!_currentStateId.Equals(_nullStateId))
            {
                _currentState.Enter(_owner, _previousStateId);
            }
        }

        /// <summary>
        /// 返回到上一个状态
        /// </summary>
        public void RevertToPreviousState()
        {
            ChangeState(_previousStateId);
        }
        #endregion

        #region private function members
        private KeyValuePair<E, FSMState<T, E>> GetStateById(E stateId)
        {
            if (_states.ContainsKey(stateId))
            {
                return new KeyValuePair<E, FSMState<T, E>>(stateId, _states[stateId]);
            }
            else
            {
                return new KeyValuePair<E, FSMState<T, E>>(_nullStateId, null);
            }
        }
        #endregion
    }
}
