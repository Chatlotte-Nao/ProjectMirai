﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ExploreBattleZone;

namespace Pheonix.Explore
{
    public class PlayerCelebrateState : FSMState<UndergroundPlayer, ePlayerStateDefine>
    {
        UndergroundPlayer _owner;

        protected override ePlayerStateDefine FSMStateID()
        {
            return ePlayerStateDefine.Celebrate;
        }

        public override void Enter(UndergroundPlayer owner, ePlayerStateDefine previousState)
        {
            _owner = owner;
            owner.movementInput = Vector2.zero;
            owner.animator.SetTrigger(Define.mHashCelebrate);
        }

        public override void ReEnter(UndergroundPlayer owner)
        {
            _owner = owner;
        }

        public override void Update(UndergroundPlayer owner, float deltaTime)
        {
            base.Update(owner, deltaTime);
        }

        public override void Exit(UndergroundPlayer owner, ePlayerStateDefine nextState)
        {
            base.Exit(owner, nextState);
        }
    }
}
