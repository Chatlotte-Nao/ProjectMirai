﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ExploreBattleZone;

namespace Pheonix.Explore
{
    public class PlayerOperateState : FSMState<UndergroundPlayer, ePlayerStateDefine>
    {
        UndergroundPlayer _owner;
        float _duration;

        protected override ePlayerStateDefine FSMStateID()
        {
            return ePlayerStateDefine.Operate;
        }

        public override void Enter(UndergroundPlayer owner, ePlayerStateDefine previousState)
        {
            _owner = owner;
            owner.SetInputBlock(true);
            owner.battleZoneAnimator.SetBool(Define.mHashRun, false);
            owner.battleZoneAnimator.SetTrigger(Define.mHashOperate);
            _duration = 0;
        }

        public override void ReEnter(UndergroundPlayer owner)
        {
            _owner = owner;
        }

        public override void Update(UndergroundPlayer owner, float deltaTime)
        {
            base.Update(owner, deltaTime);
            _duration += deltaTime;
            if (_duration > Define.kPlayerOperateLength)
            {
                owner.playerFSM.ChangeState(ePlayerStateDefine.Standing);
            }
            else
            {

            }
        }

        public override void Exit(UndergroundPlayer owner, ePlayerStateDefine nextState)
        {
            base.Exit(owner, nextState);
            owner.SetInputBlock(false);
        }
    }
}
