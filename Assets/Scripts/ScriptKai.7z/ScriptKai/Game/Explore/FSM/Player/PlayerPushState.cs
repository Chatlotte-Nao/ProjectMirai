﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ExploreBattleZone;
using Game.Sound;

namespace Pheonix.Explore
{
    public class PlayerPushState : FSMState<UndergroundPlayer, ePlayerStateDefine>
    {
        UndergroundPlayer _owner;
        int _seIndex = 0;

        protected override ePlayerStateDefine FSMStateID()
        {
            return ePlayerStateDefine.Push;
        }

        public override void Enter(UndergroundPlayer owner, ePlayerStateDefine previousState)
        {
            _owner = owner;
            _owner.moveSpeed = Define.kPlayerPushBoxSpeed;
            _owner.battleZoneAnimator.SetBool(Define.mHashPush, true);
            _seIndex = SoundPlayer.PlaySe(Define.kPushPullChestSE, true);
            _owner.RotateToTarget(_owner.pushableBox.transform);
        }

        public override void ReEnter(UndergroundPlayer owner)
        {
            _owner = owner;
        }

        public override void Update(UndergroundPlayer owner, float deltaTime)
        {
            base.Update(owner, deltaTime);
            if (owner.pushableBox != null)
            {
                var _moveOffset = owner.moveDirection * owner.moveSpeed * Time.smoothDeltaTime;
                owner.charCtrl.Move(_moveOffset);
                owner.pushableBox.transform.position += _moveOffset;
            }
        }

        public override void Exit(UndergroundPlayer owner, ePlayerStateDefine nextState)
        {
            base.Exit(owner, nextState);
            _owner.battleZoneAnimator.SetBool(Define.mHashPush, false);
            SoundPlayer.StopSe(_seIndex);
        }
    }
}
