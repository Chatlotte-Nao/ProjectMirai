﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ExploreBattleZone;

namespace Pheonix.Explore
{
    public class PlayerSetState : FSMState<UndergroundPlayer, ePlayerStateDefine>
    {
        UndergroundPlayer _owner;

        protected override ePlayerStateDefine FSMStateID()
        {
            return ePlayerStateDefine.Set;
        }

        public override void Enter(UndergroundPlayer owner, ePlayerStateDefine previousState)
        {
            _owner = owner;
            _owner.battleZoneAnimator.SetBool(Define.mHashSet, true);
            owner.movementInput = Vector2.zero;
        }

        public override void ReEnter(UndergroundPlayer owner)
        {
            _owner = owner;
        }

        public override void Update(UndergroundPlayer owner, float deltaTime)
        {
            base.Update(owner, deltaTime);
        }

        public override void Exit(UndergroundPlayer owner, ePlayerStateDefine nextState)
        {
            base.Exit(owner, nextState);
            _owner.battleZoneAnimator.SetBool(Define.mHashSet, false);
        }
    }
}
