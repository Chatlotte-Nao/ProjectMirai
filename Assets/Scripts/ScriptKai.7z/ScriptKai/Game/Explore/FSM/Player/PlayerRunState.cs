﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ExploreBattleZone;

namespace Pheonix.Explore
{
    public class PlayerRunState : FSMState<UndergroundPlayer, ePlayerStateDefine>
    {
        UndergroundPlayer _owner;

        private int? stepSoundIndex = null;

        protected override ePlayerStateDefine FSMStateID()
        {
            return ePlayerStateDefine.Run;
        }

        public override void Enter(UndergroundPlayer owner, ePlayerStateDefine previousState)
        {
            _owner = owner;
            owner.moveSpeed = Define.kPlayerRunSpeed;
            owner.battleZoneAnimator.SetBool(Define.mHashRun, true);
            
            stepSoundIndex = Game.Sound.SoundPlayer.PlaySe("SE_Walk01", true);
        }

        public override void ReEnter(UndergroundPlayer owner)
        {
            _owner = owner;
        }

        public override void Update(UndergroundPlayer owner, float deltaTime)
        {
            base.Update(owner, deltaTime);
            var targetRotation = Quaternion.LookRotation(owner.currentMovement);
            owner.transform.rotation = Quaternion.Slerp(owner.transform.rotation, targetRotation, owner.rotationSpeed * deltaTime);
            var isBlock = Physics.Raycast(owner.transform.position, owner.transform.forward, out RaycastHit hit, owner.moveSpeed * deltaTime);
            if (isBlock)
            {
                var triggerObject = hit.transform.GetComponent<TriggerObject>();
                if (triggerObject != null)
                {
                    return;
                }
            }
            owner.charCtrl.Move(owner.transform.forward * owner.moveSpeed * deltaTime);
        }

        public override void Exit(UndergroundPlayer owner, ePlayerStateDefine nextState)
        {
            base.Exit(owner, nextState);
            owner.battleZoneAnimator.SetBool(Define.mHashRun, false);

            if (stepSoundIndex != null)
            {
                Game.Sound.SoundPlayer.StopSe(stepSoundIndex.Value);
                stepSoundIndex = null;
            }

        }
    }
}
