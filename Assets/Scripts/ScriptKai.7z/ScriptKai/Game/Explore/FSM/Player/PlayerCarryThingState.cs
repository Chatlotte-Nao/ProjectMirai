﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ExploreBattleZone;

namespace Pheonix.Explore
{
    public class PlayerCarryThingState : FSMState<UndergroundPlayer, ePlayerStateDefine>
    {
        UndergroundPlayer _owner;

        private bool lastUpdateMoving = false;
        private int? stepSoundIndex = null;

        protected override ePlayerStateDefine FSMStateID()
        {
            return ePlayerStateDefine.CarryThing;
        }

        public override void Enter(UndergroundPlayer owner, ePlayerStateDefine previousState)
        {
            _owner = owner;
            owner.moveSpeed = Define.kPlayerCarryingSpeed;

            lastUpdateMoving = false;
        }

        public override void ReEnter(UndergroundPlayer owner)
        {
            _owner = owner;
        }


        public override void Update(UndergroundPlayer owner, float deltaTime)
        {
            base.Update(owner, deltaTime);

            if (!lastUpdateMoving && owner.isMoving)
            {
                StartMoving(owner, deltaTime);
            }
            else if (owner.isMoving)
            {
                DoMoving(owner, deltaTime);
            }
            else if (lastUpdateMoving && !owner.isMoving)
            {
                StopMoving(owner, deltaTime);
            }
            lastUpdateMoving = owner.isMoving;
        }

        private void StartMoving(UndergroundPlayer owner, float deltaTime)
        {
            owner.battleZoneAnimator.SetBool(Define.mHashCarryingforward, true);
            stepSoundIndex = Game.Sound.SoundPlayer.PlaySe("SE_Walk01", true);
        }

        private void DoMoving(UndergroundPlayer owner, float deltaTime)
        {
            owner.charCtrl.Move(owner.transform.forward * owner.moveSpeed * deltaTime);
            var targetRotation = Quaternion.LookRotation(owner.currentMovement);
            owner.transform.rotation = Quaternion.Slerp(owner.transform.rotation, targetRotation, owner.rotationSpeed * deltaTime);
        }

        private void StopMoving(UndergroundPlayer owner, float deltaTime)
        {
            owner.battleZoneAnimator.SetBool(Define.mHashCarryingforward, false);
            if (stepSoundIndex != null)
            {
                Game.Sound.SoundPlayer.StopSe(stepSoundIndex.Value);
                stepSoundIndex = null;
            }
        }

        public override void Exit(UndergroundPlayer owner, ePlayerStateDefine nextState)
        {
            base.Exit(owner, nextState);
            StopMoving(owner, 0);
        }
    }
}
