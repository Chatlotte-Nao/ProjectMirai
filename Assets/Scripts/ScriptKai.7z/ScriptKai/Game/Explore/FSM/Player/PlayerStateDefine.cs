﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Pheonix.Explore
{
    /// <summary>
    /// 玩家常规状态定义
    /// </summary>
    public enum ePlayerStateDefine
    {
        None,
        /// <summary>
        /// 站立
        /// </summary>
        Standing,
        /// <summary>
        /// 跑步
        /// </summary>
        Run,
        /// <summary>
        /// 操作某物
        /// </summary>
        Operate,
        /// <summary>
        /// 行走
        /// </summary>
        Walk,
        /// <summary>
        /// 拾取
        /// </summary>
        PickUp,
        /// <summary>
        /// 搬东西
        /// </summary>
        CarryThing,
        /// <summary>
        /// 放下
        /// </summary>
        PutDown,
        /// <summary>
        /// 踢东西
        /// </summary>
        Kick,
        /// <summary>
        /// 手放在箱子上
        /// </summary>
        Set,
        /// <summary>
        /// 推箱子
        /// </summary>
        Push,
        /// <summary>
        /// 拉箱子
        /// </summary>
        Pull,
        /// <summary>
        /// 获得道具
        /// </summary>
        GetItem,
        /// <summary>
        /// 持续操作某物
        /// </summary>
        Operating,
        /// <summary>
        /// 庆祝
        /// </summary>
        Celebrate,
    }
}
