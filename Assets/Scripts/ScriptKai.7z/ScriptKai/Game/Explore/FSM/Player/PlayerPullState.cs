﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ExploreBattleZone;
using Game.Sound;

namespace Pheonix.Explore
{
    public class PlayerPullState : FSMState<UndergroundPlayer, ePlayerStateDefine>
    {
        UndergroundPlayer _owner;
        int _seIndex = 0;

        protected override ePlayerStateDefine FSMStateID()
        {
            return ePlayerStateDefine.Pull;
        }

        private Vector3 diff;
        public override void Enter(UndergroundPlayer owner, ePlayerStateDefine previousState)
        {
            _owner = owner;
            _owner.moveSpeed = Define.kPlayerPushBoxSpeed;
            _owner.battleZoneAnimator.SetBool(Define.mHashPull, true);
            _seIndex = SoundPlayer.PlaySe(Define.kPushPullChestSE, true);
            _owner.RotateToTarget(_owner.pushableBox.transform);

            diff = owner.pushableBox.transform.position - owner.charCtrl.transform.position;
        }

        public override void ReEnter(UndergroundPlayer owner)
        {
            _owner = owner;
        }

        public override void Update(UndergroundPlayer owner, float deltaTime)
        {
            base.Update(owner, deltaTime);
            
            if (owner.pushableBox != null)
            {
                var _moveOffset = owner.moveDirection * owner.moveSpeed * Time.smoothDeltaTime;
                owner.charCtrl.Move(_moveOffset);
                var p = owner.charCtrl.transform.position;

                var boxPos = new Vector3(diff.x + p.x, owner.pushableBox.transform.position.y, diff.z + p.z);
                
                owner.pushableBox.transform.position = boxPos;
            }
        }

        public override void Exit(UndergroundPlayer owner, ePlayerStateDefine nextState)
        {
            base.Exit(owner, nextState);
            _owner.battleZoneAnimator.SetBool(Define.mHashPull, false);
            SoundPlayer.StopSe(_seIndex);
        }
    }
}
