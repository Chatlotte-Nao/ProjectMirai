﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum GameQualityLevel
{
    High,
    Middle,
    Low
}

[CreateAssetMenu(menuName = "QualityLevelConfig", fileName = "QualityLevelConfig")]
public class QualityLevelConfig : ScriptableObject
{
    public int hardwareScore = 90; //硬件配置的分数,根据此分数确定品质级别
    [Space]
    public GameQualityLevel qualityLevel = GameQualityLevel.High; //品质级别
    [Space]
    public int FPS = 30; //帧率
    [Space]
    public int resolutionHeight = 1080; //屏幕高度分辨率
    [Space]
    public int resolutionHeightFloor = 1080; //最低屏幕高度分辨率
    [Space]
    public float shaderLOD = 400; //高->400,中->250,低->150
}
