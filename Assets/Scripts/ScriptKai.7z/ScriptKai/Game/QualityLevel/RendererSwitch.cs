﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.Universal;

public class RendererSwitch : MonoBehaviour
{
    public int rendererIndex = 0;
    Camera _camera = null;

    private void OnEnable()
    {
        // if (!_camera)
        //     _camera = GetComponent<Camera>();
        // if (QualityLevelController.Instance.CurGameQualityLevel != GameQualityLevel.High)
        // {
        //     var cameraData = _camera.GetUniversalAdditionalCameraData();
        //     cameraData.SetRenderer(rendererIndex);
        //     Pheonix.Core.Log.Debug("RendererSwitch index is " + rendererIndex);
        // }
    }
}
