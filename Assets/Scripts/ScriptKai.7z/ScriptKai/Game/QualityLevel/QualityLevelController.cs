﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pheonix.Core;
using UnityEngine.Rendering.Universal;
using UnityEngine.Rendering;

public class QualityLevelController : SingletonMonoBehaviour<QualityLevelController>
{
    private const float AVG_FPS_FRAME_TIME = 3f; //统计平均帧率的时间
    private const int WARING_FPS_LIMIT = 20;
    private const int WARING_FPS_RANGE = 1;
    private const float DYN_SCALE_SPEED = 0.3f; //每秒调整RenderScale的值;
    const float PAUSE_CD = 10f;
    private const float ADJUST_KEEP_TIME = 1f;
    readonly string[] _configsPath = new string[] { "QualityLevelConfig/QualityLevelConfig_High", "QualityLevelConfig/QualityLevelConfig_Middle", "QualityLevelConfig/QualityLevelConfig_Low" };
    private float _adjustCD = -1f;
    private bool _adjustDown = true;
    private float _avgFps;

    GameQualityLevel _curGameQualityLevel = GameQualityLevel.Low; //当前的质量级别
    private float _curRenderScale = 1f;
    private float _curRenderScaleFloor = 1f;
    private float _fpsPauseCD = -1f;
    private int _frameCount = 0;

    Dictionary<GameQualityLevel, QualityLevelConfig> _qualityLevelConfig =
        new Dictionary<GameQualityLevel, QualityLevelConfig>();

    int _refGraphicsMemorySize = 2048;
    int _refGraphicsMemorySizeScore = 10; //参考的显存分数
    int _refProcessorCount = 8;
    int _refProcessorCountScore = 30; //参考的处理器核心数分数

    //参考芯片骁龙888，此配置对标高配
    int _refProcessorFrequency = 5683;

    int _refProcessorFrequencyScore = 50; //参考的处理器频率分数
    int _refSystemMemorySize = 7266;
    int _refSystemMemorySizeScore = 10; //参考的内存分数
    private int _screenWidth, _screenHeight;

    private float _totalFps;
    private UniversalRenderPipelineAsset _urpAsset;
    private int _warningFPS = 24; //低于此帧数会降低RenderScale
    private int avg_fps_frame_count = 10 * 30;

    /// <summary>
    /// 当前质量级别
    /// </summary>
    public GameQualityLevel CurGameQualityLevel
    {
        get { return _curGameQualityLevel; }
    }

    /// <summary>
    /// 当前质量级别配置
    /// </summary>
    public QualityLevelConfig CurQualityLevelConfig
    {
        get { return _qualityLevelConfig[_curGameQualityLevel]; }
    }

    void Update()
    {
        //bob todo: reactive dyn scale in sometime
        return;


        if (!IsOpenDynamicResolution())
        {
            return;
        }

        //PauseLogic
        if (_fpsPauseCD > 0f)
        {
            _fpsPauseCD -= Time.deltaTime;
            return;
        }

        //AvgFpsCal
        _frameCount++;
        if (_frameCount > avg_fps_frame_count)
        {
            _avgFps = _totalFps / _frameCount;
            _frameCount = 0;
            _totalFps = 0f;
        }
        else
        {
            _totalFps += 1.0f / Time.deltaTime;
        }

        //DynScaleLogic
        //BobTemp Return
        return;
        if (_avgFps < _warningFPS)
        {
            if (!_adjustDown)
            {
                _adjustCD += Time.deltaTime;
                if (_adjustCD >= ADJUST_KEEP_TIME)
                {
                    _adjustCD = 0f;
                    _adjustDown = true;
                }
            }
            else
            {
                _curRenderScale -= Time.deltaTime * DYN_SCALE_SPEED;
                UpdateRenderScale();
            }
        }
        else
        {
            if (_curRenderScale < 1f)
            {
                if (_adjustDown)
                {
                    _adjustCD += Time.deltaTime;
                    if (_adjustCD >= ADJUST_KEEP_TIME)
                    {
                        _adjustCD = 0f;
                        _adjustDown = false;
                    }
                }
                else
                {
                    _curRenderScale += Time.deltaTime * DYN_SCALE_SPEED;
                    UpdateRenderScale();
                }
            }
        }
    }

    public void Init()
    {
        _urpAsset = (UniversalRenderPipelineAsset)GraphicsSettings.currentRenderPipeline;
        Log.Info("-QC- QualityLevelController Init");
        for (int i = 0; i < _configsPath.Length; ++i)
        {
            var config = Resources.Load<QualityLevelConfig>(_configsPath[i]);
            _qualityLevelConfig.Add((GameQualityLevel)i, config);
        }
        SaveResolution();
        int score = GetHardwareScore();
        Log.Info("-QC- Hardware Score->" + score);
        GetQualityLevel(score);
        SetGameQuality();

#if UNITY_EDITOR
        SetRenderScale(1);//编辑器默认为1，美术需要调效果
#endif
    }

    /// <summary>
    /// 是否开启动态分辨率
    /// </summary>
    /// <returns></returns>
    bool IsOpenDynamicResolution()
    {
        if (Application.isEditor)
        {
            return false;
        }

        return true;
    }

    /// <summary>
    /// 获取硬件的评分
    /// </summary>
    /// <returns></returns>
    int GetHardwareScore()
    {
        int result;

        int processorFrequency = SystemInfo.processorFrequency;
        Log.Info("-QC- processorFrequency->" + processorFrequency);

        int processorCount = SystemInfo.processorCount;
        Log.Info("-QC- processorCount->" + processorCount);

        int systemMemorySize = SystemInfo.systemMemorySize;
        Log.Info("-QC- systemMemorySize->" + systemMemorySize);

        int graphicsMemorySize = SystemInfo.graphicsMemorySize;
        Log.Info("-QC- graphicsMemorySize->" + graphicsMemorySize);

        int processorFrequencyScore =
            (int)(((float)processorFrequency / _refProcessorFrequency) * _refProcessorFrequencyScore);
        int processorCountScore = (int)(((float)processorCount / _refProcessorCount) * _refProcessorCountScore);
        int systemMemorySizeScore =
            (int)(((float)systemMemorySize / _refSystemMemorySize) * _refSystemMemorySizeScore);
        int graphicsMemorySizeScore =
            (int)(((float)graphicsMemorySize / _refGraphicsMemorySize) * _refGraphicsMemorySizeScore);

        Log.Info("-QC- processorFrequencyScore->" + processorFrequencyScore + "，processorCountScore->" +
                 processorCountScore
                 + "，systemMemorySizeScore->" + systemMemorySizeScore + "，graphicsMemorySizeScore->" +
                 graphicsMemorySizeScore);

        result = processorFrequencyScore + processorCountScore + systemMemorySizeScore + graphicsMemorySizeScore;

        return result;
    }

    void GetQualityLevel(float score)
    {
        foreach (var item in _qualityLevelConfig)
        {
            if (score >= item.Value.hardwareScore)
            {
                _curGameQualityLevel = item.Key;
                break;
            }
        }
#if UNITY_IOS
        _curGameQualityLevel = GameQualityLevel.High;
        Log.Info("-QC- IOS FIXED TO High");
#endif
#if UWA||TEST_BIRD
        if (_curGameQualityLevel == GameQualityLevel.High)
        {
             _curGameQualityLevel =  GameQualityLevel.Middle;
        }
#endif
    }

    void SetGameQuality()
    {
        int systemMemorySize = SystemInfo.systemMemorySize;
        if (systemMemorySize > 1024 * 8)
        {
            QualitySettings.asyncUploadBufferSize = 16;
            Log.Info("-QC- asyncUploadBufferSize->" + 16);
        }
        else if (systemMemorySize > 1024 * 4)
        {
            QualitySettings.asyncUploadBufferSize = 8;
            Log.Info("-QC- asyncUploadBufferSize->" + 8);
        }
        else
        {
            QualitySettings.asyncUploadBufferSize = 4;
            Log.Info("-QC- asyncUploadBufferSize->" + 4);
        }


        UniversalRenderPipelineAsset urpPipelineAsset = (UniversalRenderPipelineAsset)GraphicsSettings.currentRenderPipeline;
#if UNITY_EDITOR
        urpPipelineAsset.msaaSampleCount = 0;
#else
        urpPipelineAsset.msaaSampleCount = 0;
#endif


        SetFPS();
        QuickDebug();
#if UNITY_EDITOR
        _curRenderScale = 1f;
        UpdateRenderScale();
#endif
        if (!IsOpenDynamicResolution())
        {
            return;
        }
        _warningFPS = Mathf.Max(CurQualityLevelConfig.FPS - WARING_FPS_RANGE, WARING_FPS_LIMIT);
        Log.Info("-QC- WaringFPS->" + _warningFPS);
        Log.Info("-QC- GameQuality->" + _curGameQualityLevel);
        _avgFps = _qualityLevelConfig[_curGameQualityLevel].FPS;
        avg_fps_frame_count = Mathf.FloorToInt(_qualityLevelConfig[_curGameQualityLevel].FPS * AVG_FPS_FRAME_TIME);
        SetScreenResolution();
    }

    void QuickDebug()
    {
        // var testUrl =
        //     "https://score-obs-qa.mbgadev.cn/assets/abs/b5/b5939ac414ff07207a1c750dd8d1179e/Movies/D2_Appear.usm ";
        //         var headIndex = 7;
        //         var headStr = testUrl.Substring(0, headIndex + 1);
        //         var encordUrl = headStr+WWW.EscapeURL(testUrl.Substring(headIndex,testUrl.Length-headIndex-1));
        //         Log.Info($"raw url:{testUrl}  final url:{encordUrl}");
    }

    void SetFPS()
    {
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = CurQualityLevelConfig.FPS;
        if (_warningFPS == CurQualityLevelConfig.FPS)
        {
            _warningFPS = CurQualityLevelConfig.FPS - 2;
        }
    }

    void SetScreenResolution()
    {
        //兼容性考虑，使用传统的Handle ScreenSize。
        var targetHeight = _qualityLevelConfig[_curGameQualityLevel].resolutionHeight;
#if UWA
        targetHeight = Mathf.Min(targetHeight, 960); 
#endif
        var currentHeight = Screen.currentResolution.height;
        Log.Info("-QC- RawResolution:" + Screen.currentResolution.width + "x" + Screen.currentResolution.height);

        if (currentHeight > targetHeight)
        {
            var newWidth = Mathf.FloorToInt(targetHeight / (float)(currentHeight) * Screen.currentResolution.width);
            Screen.SetResolution(newWidth, targetHeight, true);
            Log.Info("-QC- SetResolution:" + newWidth + "x" + targetHeight);
            currentHeight = targetHeight;
        }

        _curRenderScaleFloor = CurQualityLevelConfig.resolutionHeightFloor / (float)currentHeight;
        _curRenderScaleFloor = Mathf.Clamp(_curRenderScaleFloor, 0.5f, 1.0f);
        Log.Info("-QC- RenderScaleFloor:" + _curRenderScaleFloor);
    }

    public void SaveResolution()
    {
        _screenWidth = Screen.currentResolution.width;
        _screenHeight = Screen.currentResolution.height;
    }

    public void ResumeResolution()
    {
        Log.Info("-ResumeResolution currentResolution:" + Screen.currentResolution.width + "x" + Screen.currentResolution.height);
        Log.Info("-ResumeResolution To:" + _screenWidth + "x" + _screenHeight);
        Screen.SetResolution(_screenWidth, _screenHeight, true);
    }

    public void SetResolution(int screenWidth, int screenHeight)
    {
        Log.Info("-SetResolution currentResolution:" + Screen.currentResolution.width + "x" + Screen.currentResolution.height);
        Log.Info("-SetResolution to:" + screenWidth + "x" + screenHeight);
        Screen.SetResolution(screenWidth, screenHeight, true);
    }

    void UpdateRenderScale()
    {
        _curRenderScale = Mathf.Clamp(_curRenderScale, _curRenderScaleFloor, 1f);
        _urpAsset.renderScale = _curRenderScale;
        //Log.Info("-QC- UpdateRenderScale->" + _curRenderScale);
    }

    public void SetRenderScale(float scale)
    {
        _urpAsset.renderScale = scale;
    }

    /// <summary>
    /// 设置质量级别
    /// </summary>
    /// <param name="qualityLevel"></param>
    public void SetGameQuality(GameQualityLevel qualityLevel)
    {
        _curGameQualityLevel = qualityLevel;
        SetGameQuality();
    }

    /// <summary>
    /// 暂停修改RenderScale
    /// </summary>
    /// <param name="isPause">是否暂停</param>
    public void PauseDynScale(bool isPause)
    {
        //        Log.Info("-QC- PauseDynScale->" + isPause);
        if (isPause)
        {
            _fpsPauseCD = PAUSE_CD;
        }
        else
        {
            _fpsPauseCD = -1f;
        }
    }

    //#if BUILD_DEBUG
    //    private void OnGUI()
    //    {
    //        var op1 = GUILayout.MinWidth(150);
    //        var op2 = GUILayout.MinHeight(60);
    //        if (GUILayout.Button("Game Quality High", op1, op2))
    //        {
    //            _curGameQualityLevel = GameQualityLevel.High;
    //            SetGameQuality();
    //        }
    //        if (GUILayout.Button("Game Quality Middle", op1, op2))
    //        {
    //            _curGameQualityLevel = GameQualityLevel.Middle;
    //            SetGameQuality();
    //        }
    //        if (GUILayout.Button("Game Quality Low", op1, op2))
    //        {
    //            _curGameQualityLevel = GameQualityLevel.Low;
    //            SetGameQuality();
    //        }
    //    }
    //#endif
}
