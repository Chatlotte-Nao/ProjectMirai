﻿using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MuTaCtrl : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject eff;
    public Animator animator;
    public float time=5f;

    void Start()
    {
        eff.SetActive(false);
        if (gameObject.GetComponent<Animation>()!=null)
        {
            animator = gameObject.GetComponent<Animator>();
        }    
    }

    void Update()
    {      
        if (GameSceneManager.Instance.currentSceneName=="ExploreScene"|| GameSceneManager.Instance.currentSceneName == "AdvScene"||eff==null)
        {
            return;
        }
        if (UIInteractiveSecondDialog.SecondTime)
        {
            if (!eff.activeSelf)
            {
                return;
            }
            eff.SetActive(false);
            return;
        }
        if (MapSceneManager.Instance.CurrentScene != null&&MapSceneManager.Instance.CurrentScene.player!=null&&Vector3.Distance(MapSceneManager.Instance.CurrentScene.player.transform.position, gameObject.transform.position) <= 5f)
        {
            
            if (eff.activeSelf)
            {                
                return;
            }
           
            eff.SetActive(true);
        }
        else
        {
            if (!eff.activeSelf)
            {
                return;
            }
            eff.GetComponent<TriggetTips>().Close();
            eff.SetActive(false);
        }

    }

    // Update is called once per frame
    private void LateUpdate()
    {
        if (animator==null)
        {
            return;
        }
        time -= Time.deltaTime;
        if (time <= 0)
        {
            //todo: guyu 扭蛋机上为啥会要绑这个脚本?
            int a = Random.Range(1, 3);
            animator.SetTrigger(a.ToString());
            time = 5f;
        }
    }
}
