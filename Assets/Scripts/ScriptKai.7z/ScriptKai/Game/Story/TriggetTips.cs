using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggetTips : MonoBehaviour
{
    public Animator ani;
    // Start is called before the first frame update
    void Start()
    {
        
    }
    public void Close()
    {
        ani.SetTrigger("level");
    }

    // Update is called once per frame
    void Update()
    {
        if (RenderHandler.Instance.GetMainCamera() != null)
        {
            var rotation = Quaternion.LookRotation(
                RenderHandler.Instance.GetMainCamera().transform.TransformVector(Vector3.forward),
                RenderHandler.Instance.GetMainCamera().transform.TransformVector(Vector3.up));
            rotation = new Quaternion(0, rotation.y, 0, rotation.w);
            gameObject.transform.rotation = rotation;
        }
    }
}
