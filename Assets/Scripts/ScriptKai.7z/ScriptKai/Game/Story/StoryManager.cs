using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using FlowCanvas;
using Pheonix.Core;
using UnityEngine;

namespace Score.Story
{
    public class StoryManager : SingletonMonoBehaviour<StoryManager>
    {
        private ConcurrentDictionary<string, FlowScript> _dictStoryFlowScript =
            new ConcurrentDictionary<string, FlowScript>(2, 32);

        private FlowScriptController _storyFSController;

        private void Awake()
        {
            _storyFSController = GetComponent<FlowScriptController>();
        }

        void Start()
        {
            // _dictStoryFlowScript.TryAdd(StoryTest1, _storyFSController.)
        }

        void Update()
        {
        }

        public void StartPlayerMovement()
        {
            if (_storyFSController == null)
            {
                return;
            }

            _storyFSController.SendEvent("StoryTest1");
        }

        void LoadFCScript(string name)
        {
            if (!_dictStoryFlowScript.TryGetValue(name, out var flowScript))
            {
            }
        }

        FlowScript GetFCScript(string name, bool isLoadForce = false)
        {
            if (!_dictStoryFlowScript.TryGetValue(name, out var flowScript))
            {
                if (isLoadForce)
                {
                    LoadFCScript(name);
                }
            }

            return flowScript;
        }

        public void SendEvent(string msg)
        {
            if (_storyFSController == null)
            {
                return;
            }

            _storyFSController.SendEvent(msg);
        }

        public void SendEvent<T>(string msg, T eventValue)
        {
            if (_storyFSController == null)
            {
                Log.Warn($"FSController null");
                return;
            }

            _storyFSController.SendEvent<T>(msg, eventValue);
        }
    }
}