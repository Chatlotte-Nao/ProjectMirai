﻿using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomObjectCtrl : MonoBehaviour
{
    public GameObject eff;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (GameSceneManager.Instance.currentSceneName == "ExploreScene" || GameSceneManager.Instance.currentSceneName == "AdvScene" || eff == null)
        {
            if (!eff.activeSelf)
            {
                return;
            }
            eff.SetActive(false);
            return;
        }
        if (UIInteractiveSecondDialog.SecondTime)
        {
            if (!eff.activeSelf)
            {
                return;
            }
            eff.SetActive(false);
            return;
        }
        if (MapSceneManager.Instance.CurrentScene != null && MapSceneManager.Instance.CurrentScene.player != null && Vector3.Distance(MapSceneManager.Instance.CurrentScene.player.transform.position, gameObject.transform.position) <= 5f)
        {

            if (eff.activeSelf)
            {
                return;
            }

            eff.SetActive(true);
        }
        else
        {
            if (!eff.activeSelf)
            {
                return;
            }
            eff.GetComponent<TriggetTips>().Close();
            eff.SetActive(false);
        }

    }
}
