//Story
//Ash nazg durbatulûk, ash nazg gimbatul, ash nazg thrakatulûk, agh burzum-ishi krimpatul

using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using Game.ScriptEngine;
using UnityEngine;

namespace Score.Story
{
    public class StoryText : ScriptableObject
    {
        [System.Serializable]
        public class StoryTextPara
        {
            public List<string> args = new List<string>();
        }

        public List<StoryTextPara> argList = new List<StoryTextPara>();

        public void Load(string script)
        {
            var sr = new StringReader(script);
            var line = "";

            var r = new Regex(@"^\s*(\w+(&)?)(\s*)?(.+)?");
            var areg = new Regex(@"(?<!\\),");

            while ((line = sr.ReadLine()) != null)
            {
                if (string.IsNullOrEmpty(line)) continue;

                if (line.StartsWith("#")) continue;
                if (line.StartsWith(":")) continue;
                
                var m = r.Match(line);
                if (!m.Success) continue;

                var para = new StoryTextPara();
                
                var args = areg.Split(m.Groups[4].Value);
                foreach (var a in args)
                {
                    para.args.Add(ReplaceNewLineCode(a));
                }

                argList.Add(para);
           }
        }

        static string ReplaceNewLineCode(string s)
        {
            if (s != null) return s.Replace("\\n", "\n");
            return null;
        }

        public ScenarioScript ConvertToCommandAction()
        {
            ScenarioScript result = ScriptableObject.CreateInstance<ScenarioScript>();
            for (int i = 0; i < argList.Count; i++)
            {
                StoryTextPara arg = argList[i];
                //play face animation
                //play body animation
                if (arg.args.Count > 6 && !string.IsNullOrEmpty(arg.args[6]))
                {
                    ScenarioScript.CommandAction newObjcommand = new ScenarioScript.CommandAction();
                    newObjcommand.command = "newobject";
                    newObjcommand.args.Add(arg.args[6]);
                    result.commands.Insert(0,newObjcommand);
                    if (arg.args.Count > 7 && !string.IsNullOrEmpty(arg.args[7]))
                    {
                        ScenarioScript.CommandAction showObjcommand = new ScenarioScript.CommandAction();
                        showObjcommand.command = "showobject";
                        showObjcommand.args.Add(arg.args[6]);
                        result.commands.Add(showObjcommand);
                        ScenarioScript.CommandAction command = new ScenarioScript.CommandAction();
                        command.command = "playspineanimation_body";
                        command.args.Add(arg.args[6]);
                        command.args.Add(arg.args[7]);
                        command.args.Add("FALSE");
                        command.args.Add("FALSE");
                        result.commands.Add(command);
                    }
                    if (arg.args.Count > 8 && !string.IsNullOrEmpty(arg.args[8]))
                    {
                        ScenarioScript.CommandAction showObjcommand = new ScenarioScript.CommandAction();
                        showObjcommand.command = "showobject";
                        showObjcommand.args.Add(arg.args[6]);
                        result.commands.Add(showObjcommand);
                        ScenarioScript.CommandAction command = new ScenarioScript.CommandAction();
                        command.command = "playspineanimation_face";
                        command.args.Add(arg.args[6]);
                        command.args.Add(arg.args[8]);
                        command.args.Add("FALSE");
                        command.args.Add("TRUE");
                        result.commands.Add(command);
                    }
                }
                
                //Text
                ScenarioScript.CommandAction textCommand = new ScenarioScript.CommandAction();
                textCommand.command = "Text";
                textCommand.args = arg.args;
                result.commands.Add(textCommand);

                if (arg.args.Count > 6 && !string.IsNullOrEmpty(arg.args[6]))
                {
                    if (int.TryParse(arg.args[5], out int _end) && _end == 0)
                    {
                        ScenarioScript.CommandAction hideObjcommand = new ScenarioScript.CommandAction();
                        hideObjcommand.command = "hideObject";
                        hideObjcommand.args.Add(arg.args[6]);
                        result.commands.Add(hideObjcommand);
                    }
                }
            }
            //ret
            ScenarioScript.CommandAction retCommand = new ScenarioScript.CommandAction();
            retCommand.command = "Ret";
            result.commands.Add(retCommand);
            return result;
        }
    }
}