﻿using Pheonix.Core;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NamePlateCtrl : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (MapSceneManager.Instance.CurrentScene != null && MapSceneManager.Instance.CurrentScene.player!=null&&Vector3.Distance(MapSceneManager.Instance.CurrentScene.player.transform.position, gameObject.transform.position) <= 10f)
        {
            if (gameObject.transform.GetChild(0).gameObject.activeSelf)
            {
                return;
            }
            gameObject.transform.GetChild(0).gameObject.SetActive(true);
        }
        else
        {
            if (!gameObject.transform.GetChild(0).gameObject.activeSelf)
            {
                return;
            }
            gameObject.transform.GetChild(0).gameObject.SetActive(false);
        }
  
    }
}
