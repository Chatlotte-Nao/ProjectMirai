//Story
//Ash nazg durbatulûk, ash nazg gimbatul, ash nazg thrakatulûk, agh burzum-ishi krimpatul
namespace Score.Story
{
    public class StoryDef
    {
        public enum eTypeScene {
            AdvMap005,
            AdvMap006_1,
            AdvMap006_wing_2_1,
            AdvMap006_wing_3_1,
            AdvMap006_0,
            AdvMap006_2,
            AdvMap005_Underground,
            AdvMap007_Outside,
            AdvMap008_1,
            AdvMap008_2,
            AdvMap008_3,
            AdvMap007_Lab_1,
            AdvMap007_Lab_2_East,
            AdvMap007_Lab_2_West,
            AdvMap101_DungeonTest,
            AdvMap102_Dungeon21,
            AdvMap103_Dungeon31,
            AdvMap007_0,
            AdvMap008_0,
            BattleMap001,
            BattleMap002,
            BattleMap003,
            AdvMap001,

        }

        public static string[] sysdMsgTypeList =
        {
            "BeforeBattle",
            "WinBattle",
            "TalkToActor",
            "ObjectStateChange",
            "Oprate",
            "EnterScene",
            "LeaveScene",
            "ActorEnterTrigger",
            "ItemGet",
            "ValueChange"
        };

        public static string[] sysMsgTypeNameList =
        {
            "战斗开始",
            "战斗结束",
            "对话",
            "机关状态",
            "操作",
            "进入场景",
            "离开场景",
            "触发区",
            "获取物品",
            "变量变化"
        };
    }
}