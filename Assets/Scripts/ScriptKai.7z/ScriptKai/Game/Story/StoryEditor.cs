using Pheonix.Core;
using UnityEngine;
using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using Adventure;
using Game.ScriptEngine;
using Map;
using Score.Story;
using Random = UnityEngine.Random;

//Story启动器
public class StoryEditor : MonoBehaviour
{
    public int _debugStoryID = 1;
    public StoryDef.eTypeScene typeScene = StoryDef.eTypeScene.AdvMap007_0;
    private string _debugScene = "AdvMap006_0";

    void Awake()
    {
        if (!AsyncManager.HasInstance)
        {
            AsyncManager.CreateInstance();
            AsyncManager.Instance.StartAsync(APPInitAsync());
        }
        GameObject.DontDestroyOnLoad(this);
    }

    void OnGUI() 
    {
        _debugScene = typeScene.ToString();
        Rect rect = new Rect(0, 0, 200, 50);
        if (GUI.Button(rect, "PlayADV"))
        {
            StoryManager.Instance.SendEvent("TestADV");
        }

        rect.y += 50;
        if (GUI.Button(rect, "EnterScene"))
        {
            // MapSceneManager.Instance.CurrentScene.player.MoveTo(new Vector3(UnityEngine.Random.Range(-3f, 3f), 0, Random.Range(-2f, -7f)));
            StoryManager.Instance.StartPlayerMovement(); 
            //Debug.Log("下楼随机走走");
            //StoryManager.Instance.SendEvent("EnterScene");
        }
        
        rect.y += 50;
        if (GUI.Button(rect, "Scenario脚本测试")) {
            QuickScenarioCommand("NewTutorial03");
        }
    }

    private async UniTask APPInitAsync()
    {
        if (!GameInitializer.HasInstance)
        {
            GameInitializer.CreateInstance();
            await GameInitializer.Instance.InitializeAsync();
        }

        await InitializeAsync();
    }

    void SetupCanvas()
    {
        UI.Canvas.RemoveSceneCanvas();
        Transform canvasRoot = GameObject.Find("CanvasRoot").transform;
        foreach (Transform c in canvasRoot)
        {
            CanvasType cType = (CanvasType) Enum.Parse(typeof(CanvasType), c.name);
            UI.Canvas.AddCanvas(cType, c.GetComponent<Canvas>());
        }

        UI.Canvas.BuildTutorialCanvas();
    }


    async UniTask InitializeAsync()
    {
        SetupCanvas();
        DataManager.Instance.Local.Story.OngoingStoryId = _debugStoryID;
        await InitScene();
        await InitActors();
        MapSceneManager.Instance.StageManager.Start();
        UI.Page.OpenPage<UIAdvMainPage>();
    }

    //初始化场景
    async UniTask InitScene()
    {
        StorySceneParam param = new StorySceneParam()
        {
            storyID = _debugStoryID,
        };
        await GameSceneManager.Instance.ChangeSceneAsync<StoryScene>("StoryScene", param);
        await MapSceneManager.Instance.ShowAsync(_debugScene, null, null, MapSceneManager.SceneType.Story,
            DataManager.Instance.Local.Story.currentRouteName);
    }

    //初始化人物
    async UniTask InitActors()
    {
        MapSceneManager.Instance.CurrentScene.player.MoveTo(new Vector3(0, 0, -5f));
    }

    public async UniTask QuickCommand(string cmd)
    {
        Debug.Log(cmd);
        StoryText script = await ResourceManager.Instance.LoadLocalizeAssetAsync<StoryText>("Story/" + cmd);
        ScriptEngine.GetInstance().LoadScript(cmd, script.ConvertToCommandAction());
        ScriptEngine.GetInstance().SetStartScript(cmd);
    }

    public async void QuickScenarioCommand(string cmd) {
        await QuickScenarioCommandAsync(cmd);
    }

    //NewTutorial03
    public async UniTask QuickScenarioCommandAsync(string cmd)
    {
        Log.Info($"QuickScenarioCommand {cmd}");

        ScenarioScript script1 = await ResourceManager.Instance.LoadLocalizeAssetAsync<ScenarioScript>("Scenario/" + cmd);//story00_03_main03_010

        ScriptEngine.GetInstance().LoadScript(cmd, script1);
        ScriptEngine.GetInstance().SetStartScript(cmd, null, (s)=> {
            AsyncManager.Instance.StartAsync(async ()=> {
                Log.Info($"QuickScenarioCommand {cmd} end");
                // var page = UI.Page.Current as UIMapTutorialPage;
                // await page.ShowMainWindow();
                // TutorialManager.Instance.StartFunctionTutorial(16001);
            });
        });
    }
}